<?php
include_once 'KALS_resource.php';
/**
 * Annotation
 *
 * 標註
 *
 * @package		KALS
 * @category		Libraries
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/7/5 下午 10:40:15
 * @property Annotation_type_factory $type_factory
 * @property Authorize_manager $auth
 * @property Segmentor segmentor
 * @property Annotation_scope_collection $scope_coll
 * @property Annotation_score_collection $score_coll
 * @property Annotation_collection $respond_to_coll
 */
class Annotation extends KALS_resource {

    public $resource_type_id = 3;

    protected $table_name = 'annotation';
    protected $table_fields = array('annotation_id', 'create_timestamp', 'update_timestamp', 'deleted', 'user_id', 'annotation_type_id', 'note', 'note_index');
    protected $primary_key = 'annotation_id';
    protected $not_null_field = array('user_id', 'annotation_type_id');
    protected $except_bind_fields = array('note_index');
    protected $fake_delete = 'deleted';

    private $auth;
    private $type_factory;
    private $segmentor;
    private $scope_coll;
    private $score_coll;

    protected function  _pre_construct() {
        $this->CI->load->library('policy/Authorize_manager', NULL, 'authorize_manager');
        $this->auth = $this->CI->authorize_manager;
        $this->auth->set_resource($this);
        $this->auth->set_throw_exception(TRUE);
    }

    private function _load_type_factory()
    {
        if (is_null(($this->type_factory)))
        {
            $this->_CI_load('library', 'type/Annotation_type_factory', 'annotation_type_factory');
            $this->type_factory = $this->CI->annotation_type_factory;
        }
    }

    private function _load_user()
    {
        if (is_null(($this->CI->user)))
        {
            $this->_CI_load('library', 'kals_actor/User', 'user');
        }
    }

    protected function _pre_update($data)
    {
        //檢查權限
        $this->auth->is_admin();

        //檢查note_index，加入斷詞
        if (isset($data['note']))
        {
            $this->_load_segmentor();
            $data['note_index'] = $this->segmentor->text_to_index($data['note']);
        }
        if (FALSE === isset($data['annotation_type_id']))
        {
            $data['annotation_type_id'] = 1;
        }

        return $data;
    }

    protected function  _post_update() {
        if (isset($this->scope_coll))
        {
            $this->scope_coll->set_annotation($this->get_id());
            $this->scope_coll->update();
        }

        $this->update_respond_to_topic();
        $this->update_respond_to_coll();

    }

    private function _load_segmentor()
    {
        if (is_null($this->segmentor))
        {
            $this->_CI_load('library', 'scope/Segmentor_factory', 'segmentor_factory');
            $this->segmentor = Segmentor_factory::create();
        }
        return $this;
    }

    protected function _pre_delete()
    {
        //檢查權限
        $this->auth->is_admin();
    }

    //-------------------------------------------------

    public function set_user($user_id)
    {
        $this->_load_user();
        $user_id = $this->CI->user->filter_id($user_id);

        return $this->set_field('user_id', $user_id);
    }

    public function get_user()
    {
        $user_id = $this->get_field('user_id');
        $this->_load_user();
        return new User($user_id);
    }

    public function set_type($type_id)
    {
        $this->_load_type_factory();
        $type_id = $this->type_factory->filter_type_id($type_id);
        return $this->set_field('annotation_type_id', $type_id);
    }
    /**
     * @return Annotation_type
     */
    public function get_type()
    {
        $this->_load_type_factory();
        $type_id = $this->get_field('annotation_type_id');
        $type_id = intval($type_id);
        return $this->type_factory->create($type_id);
    }

    public function set_note($value)
    {
        return $this->set_field('note', $value);
    }

    public function get_note()
    {
        return $this->get_field('note');
    }

    //---------------------------------------------------
    //跟respond & topic相關

    private $topic;
    private $topic_modified = FALSE;
    public function set_respond_to_topic($topic)
    {
        $topic = $this->filter_object($topic);
        if (is_null($topic) 
            OR (is_object($topic) && $topic->get_id() != $this->get_id()) )
        {
            $this->topic = $topic;
            $this->topic_modified = TRUE;
        }
        return $this;
    }

    public function update_respond_to_topic()
    {
        if (FALSE === $this->topic_modified)
            return $this;

        $topic = $this->topic;
        
        $topic_id = NULL;
        if (NULL !== $topic)
            $topic_id = $topic->get_id();

        //加入資料庫當中
        $id = $this->get_id();
        $table_name = 'annotation2topic';

        $db = $this->db;
        $db->where('respond_id', $id);
        if ($db->count_all_results($table_name) > 0)
        {
            $db->where('respond_id', $id);
            if (is_null($topic))
            {
                $db->delete($table_name);
            }
            else
            {
                $db->set('topic_id', $topic_id);
                $db->update($table_name);
            }
        }
        else if (isset($topic))
        {
            $set = array(
                'topic_id' => $topic_id,
                'respond_id' => $id
            );
            $db->insert($table_name, $set);
        }
        $this->topic_modified = FALSE;
        return $this;
    }

    public function get_respond_to_topic()
    {
        if (is_null($this->topic))
        {
            if ($this->is_deleted())
                return NULL;

            $table = 'annotation2topic';
            $id = $this->get_id();
            $db = $this->db;

            $db->from($table);
            $db->join($this->table_name, $this->table_name.'.'.$this->primary_key.' = '.$table.'.topic_id');
            $db->select($this->table_name.'.*');
            $db->where('respond_id', $id);
            $db->where($this->table_name.'.'.$this->fake_delete, 'FALSE');
            $db->limit(1);
            $query = $db->get();

            if ($query->num_rows() > 0)
            {
                $row = $query->row_array();
                $topic = new Annotation($row);
                $this->topic = $topic;
            }
        }
        return $this->topic;
    }

    private $respond_to_coll;
    private $respond_to_coll_modified;
    public function set_respond_to_coll($coll)
    {
//        $id = $this->get_id();
//        $id_list = NULL;
//        if (count($list) > 0 && is_int($list[0]))
//        {
//            $id_list = $list;
//            $list = array();
//            foreach($id_list AS $new_id)
//            {
//                if ($new_id == $id)
//                    continue;
//
//                $annotation = new Annotation($new_id);
//                array_push($list, $annotation);
//            }
//        }
//
//        //剔除掉自身的
//        foreach ($list AS $key => $respond_to)
//        {
//            $respond_to_id = $respond_to->get_id();
//            if ($respond_to_id == $id)
//                unset($list[$key]);
//        }


        if (is_int($coll))
        {
            $annotation = $this->filter_object($coll);
            $this->_CI_load('library', 'annotation/Annotation_collection');
            $coll = new Annotation_collection ($annotation);
        }
        if (is_class($coll, 'Annotation'))
        {
            $this->_CI_load('library', 'annotation/Annotation_collection');
            $coll = new Annotation_collection ($coll);
        }

        if (is_class($coll, 'Annotation_collection'))
        {
            $this->respond_to_coll = $coll;
            $this->respond_to_coll_modified = TRUE;
        }
        return $this;
    }

    public function update_respond_to_coll()
    {
        if (FALSE === $this->respond_to_coll_modified)
            return $this;

        //--------------------------------------
        //資料庫處理

        $coll = $this->respond_to_coll;
        if (is_null($coll))
            return $this;

        $db = $this->db;
        $id = $this->get_id();
        $table = 'annotation2respond';

        if ($coll->length() == 0)
        {
            $where = array('annotation_id' => $id);
            $db->delete($table, $where);
        }
        else
        {
            $id_list = array();
            foreach ($coll AS $annotation)
                $id_list[] = $annotation->get_id();

            $db->where('annotation_id' , $id);
            $db->select('respond_to');
            $query = $db->get($table);

            $old_list = array();
            foreach ($query->result_array() AS $row)
            {
                $old_id = intval($row['respond_to']);
                array_push($old_list, $old_id);
            }

            //插入新的
//            $insert_list = array();
//            foreach ($id_list AS $new_id)
//            {
//                if (FALSE === in_array($new_id, $old_list))
//                    $insert_list[] = $new_id;
//            }
            $insert_list = array_cut($id_list, $old_list);

            foreach ($insert_list AS $respond_to)
            {
                $set = array(
                    'annotation_id' => $id,
                    'respond_to' => $respond_to
                );
                $db->insert($table, $set);
            }

            //刪除之外的
//            $delete_list = array();
//            foreach ($old_list AS $old_id)
//            {
//                if (FALSE === in_array($old_id, $id_list))
//                    $delete_list[] = $old_id;
//            }
            $delete_list = array_cut($old_list, $id_list);
            //DELETE FROM products WHERE price = 10;
            if (count($delete_list) > 0)
            {
//                $where_or = '';
//                foreach ($delete_list AS $respond_to)
//                {
//                    if ($where_or != '')
//                        $where_or .= ' OR ';
//                    $where_or .= ' respond_id = '.$respond_to;
//                }
//                $sql = 'DELETE FROM '.$table.' WHERE annotation_id = '.$id. ' AND ('.$where_or.') ';
//                $db->query($sql);
                $db->where('annotation_id', $id);
                $db->where_in('respond_id', $delete_list);
                $db->delete($table);
            }
        }
        $this->respond_to_coll_modified = FALSE;
        return $this;
    }

    /**
     * @return Annotation_collection
     */
    public function get_respond_to_coll()
    {
        if (is_null($this->respond_to_coll))
        {
            if ($this->is_deleted())
                return NULL;

            $this->_CI_load('library', 'annotation/Annotation_collection', 'annotation_collection');
            $this->respond_to_coll = new Annotation_collection();
            $this->respond_to_coll->set_load_callback('load_respond_to_coll', $this);
        }
        return $this->respond_to_coll;
    }

    public function load_respond_to_coll(Collection $coll)
    {
        $table = 'annotation2respond';
        $id = $this->get_id();
        $db = $this->db;

        $db->from($table);
        $db->join($this->table_name, $this->table_name.'.'.$this->primary_key.' = '.$table.'.respond_to');
        $db->select($this->table_name.'.*');
        $db->where($this->table_name.'.'.$this->fake_delete, 'FALSE');
        $db->distinct();
        $db->where($table.'.annotation_id', $id);
        $query = $db->get();

        if ($query->num_rows() > 0)
        {
            //$list = array();
            foreach ($query->result_array() AS $row)
            {
                $respond_to = new Annotation($row);
                //array_push($list, $respond_to);
                $coll->add_item($respond_to);
            }
            //$this->respond_to_list-> = $list;
        }
        return TRUE;
    }

    /**
     * Topic Annotation底下的list
     */
    public function get_topic_responded_coll()
    {
        
    }
    
    //------------------------------------------
    //跟Annotation_scope_collection相關

    public function create_annotation($user_id, $scope_coll, $do_update = TRUE)
    {
        $this->_load_user();
        $user_id = $this->CI->user->filter_id($user_id);

        $annotation = new Annotation();
        $annotation->set_scopes($scope_coll);
        $annotation->set_user($user_id);
        if ($do_update)
            $annotation->update();

        return $annotation;
    }

    public function set_scopes($scope_coll)
    {
        if (is_object($scope_coll) && get_class($scope_coll) == 'Annotation_scope')
        {
            $scope = $scope_coll;
            //$this->CI->load->library('scope/Annotation_scope_collection');
            $this->_CI_load('library', 'scope/Annotation_scope_collection', 'annotation_scope_collection');
            $scope_coll = new Annotation_scope_collection();
            $scope_coll->set_scopes($scope);
        }

        if (is_class($scope_coll, 'Annotation_scope_collection'))
        {
            $id = $this->get_id();
            if (isset($id))
                $scope_coll->set_annotation($id);
            $this->scope_coll = $scope_coll;
        }
        return $this;
    }

    /**
     * @return Annotation_scope_collection
     */
    public function get_scopes()
    {
        if (is_null($this->scope_coll))
        {
            //$this->CI->load->library('scope/Annotation_scope_collection');
            $this->_CI_load('library', 'scope/Annotation_scope_collection');
            //$this->scope_coll = $this->CI->annotation_scope_collection->retrieve($this);
            $this->scope_coll = new Annotation_scope_collection($this->get_id());
        }
        return $this->scope_coll;
    }
//
//    public function _load_scope(Annotation_scope_collection $scope_coll)
//    {
//        $annotation_id = $scope_coll->get_annotation_id();
//        $annotation_id = $this->filter_id($annotation_id);
//
//        $table = 'annotation2scope';
//        $this->db->from($table);
//        $this->db->join('scope', $table.'.scope_id = scope.scope_id');
//
//        $select_fields = $table.'.scope_id, webpage_id, from_index, to_index, anchor_text_id';
//        if ($with_anchor_text)
//        {
//            $select_fields .= ', anchor_text.anchor_text_id, text, segmented';
//            $this->db->join('anchor_text', 'scope.anchor_text_id, anchor_text.anchor_text_id');
//        }
//        $this->db->select($select_fields);
//
//        $this->db->where('annotation_id', $annotation_id);
//        $query = $this->db->get();
//
//        $this->_CI_load('library', 'scope/Annotation_scope');
//        $scopes = array();
//        foreach($query->result_array() AS $row)
//        {
//            $scope = new Annotation_scope($row);
//            $scopes[] = $scope;
//        }
//
//        $scope_coll->set_scopes($scopes);
//        $scope_coll->force_sorted();
//        return $scope_coll;
//    }

    public function get_anchor_text()
    {
        $scope_coll = $this->get_scope();
        return $scope_coll->get_anchor_text();
    }

    public function get_anchor_speech()
    {
        $scope_coll = $this->get_scope();
        return $scope_coll->get_anchor_speech();
    }
    
    //------------------------------------------
    //跟webpage2annotation相關

    private function _load_webpage()
    {
        if (is_null(($this->CI->webpage)))
        {
        	$this->_CI_load('library', 'kals_resource/Webpage', 'webpage');
        }
    }

    private $appended_webpages;
    public function get_appended_webpages()
    {
        if (is_null($this->appended_webpages))
        {
            $scope_coll = $this->get_scopes();
            $this->appended_webpages = $scope_coll->get_appended_webpages();
        }
        return $this->appended_webpages;
    }


    //----------------------------------------------
    //跟Annotation_feature_factory相關

    public function set_feature($feature_type_id, $value)
    {

        return $this;
    }

    public function get_feature($feature_type_id)
    {

    }

    //---------------------------------------------
    //Annotation_like_collection相關

    public function add_like($user_id)
    {
        return $this;
    }

    public function remove_like($user_id)
    {
        return $this;
    }

    public function get_like()
    {

    }

    //------------------------------------------------
    //跟Annotation_score_collection相關

    public function set_score($score_coll)
    {
        return $this;
    }

    public function get_score()
    {

    }

    //-------------------------------------------------
    //跟recommend相關

    public function get_recommend()
    {

    }
}


/* End of file Annotation.php */
/* Location: ./system/application/libraries/kals_resource/Annotation.php */