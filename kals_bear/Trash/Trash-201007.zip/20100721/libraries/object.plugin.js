/**
 * object.plugin
 *
 * @package		KALS
 * @category		JavaScript Libraries
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/7/21 上午 08:54:10
 * @requires jQuery
 */

/**
 * Method String.endsWith
 *
 * @param suffix 要比對的字串
 * @type boolean
 */
Object.prototype.ends_with = function(suffix)
{
    var len = suffix.length;
    var start = 0 - len;
    if (this.substr(start, len) == suffix)
        return true;
    else
        return false;
}

Object.prototype.starts_with = function(prefix)
{
    var len = prefix.length;
    var start = 0;
    if (this.substr(start, len) == prefix)
        return true;
    else
        return false;
}

Object.prototype.appends_with = function(suffix)
{
    if (this.endsWith(suffix) == false)
        return this + suffix;
    else
        return this;
}

/**
 * 判斷字首是否是prefix，否則加上prefix
 *
 * @param Object prefix
 * @type boolean
 */
Object.prototype.prepends_with = function(prefix)
{
    if (this.startsWith(prefix) == false)
        return this + prefix;
    else
        return this;
}

Object.prototype.trim = function()
{
    return $.trim(this);
}

Object.prototype.is_null = function ()
{
    if (typeof(this) == 'undefined')
        return TRUE;
    else
        return (this == null);
}

Object.prototype.is_string = function ()
{
    return (typeof(this) == 'string')
}

Object.prototype.is_number = function ()
{
    return (typeof(this) == 'number')
}

Object.prototype.is_function = function ()
{
    return (typeof(this) == 'function')
}



//Object.prototype.method = function (param)
//{
//    return param;
//}

/* End of file Object.plugin */
/* Location: ./libraries/helpers/Object.plugin.js */