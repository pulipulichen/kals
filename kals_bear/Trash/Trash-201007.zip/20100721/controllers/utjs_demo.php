<?php
/**
 * utjs
 *
 * ut_js full description.
 *
 * @package		KALS
 * @category		Unit Tests
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/7/20 下午 02:12:44
 */
class Utjs_demo extends Controller {

    function __construct()
    {
        parent::Controller();
    }

    function index()
    {
        $this->load->view('misc/utjs-demo');
    }
}
/* End of file utjs.php */
/* Location: ./system/application/controllers/utjs.php */