<?php
/**
 * Qunit
 *
 * @package		KALS
 * @category		Unit Tests
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/7/20 下午 03:26:32
 */
class Qunit extends Controller {

    public $ut_title;
    public $js_files = array();

    function __construct()
    {
        parent::Controller();
        $this->load->helper('unit_test');
        $this->load->helper('url');

    }

    function index()
    {
        $this->js_files[] = 'xxs_getter.js';
    }

    function _output($output)
    {
        if (isset($this->ut_title))
            echo qunit_report($this, $this->ut_title);
        else
            echo qunit_report($this);
        //$outout =  . $output;
        echo $output;
    }
}
/* End of file Utjs.php */
/* Location: ./system/application/controllers/Utjs.php */