
function xxs_getter(url)
{
//    if (typeof(url) == 'undefined')
//        var url = 'http://localhost/CodeIgniter_1.7.2/qunit_feed/index/callback';
//    alert(url);
//    $.getJSON(url, function (data) {
//        alert(data);
//    });

    if (typeof(url) == 'undefined')
            var url = 'http://localhost/CodeIgniter_1.7.2/qunit_feed/index/callback';
    $.getJSON(url, function(data) {
//      $('.result').html('<p>' + data.foo + '</p>'
//        + '<p>' + data.baz[1] + '</p>');
        alert(data);
    });
}


