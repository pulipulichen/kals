<?php

$c = $_GET['c'];
$a = intval($_GET['a']);
$b = intval($_GET['b']);
$p = $a + $b;

echo $c.'('.$p.');';
