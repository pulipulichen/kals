<?php
$path = $_GET['path'];
$callback = $_GET['callback'];

$self = $_SERVER["PHP_SELF"];
$self = substr($self, 0, strpos($self, '/', 1));
$root = 'http://'.$_SERVER["SERVER_NAME"].$self.'/';
$data = file_get_contents($root.$path);
echo $callback.'('.$data.')';
