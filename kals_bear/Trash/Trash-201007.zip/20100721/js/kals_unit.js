/**
 * KALS_Unit
 *
 * KALS程式使用到的工具箱
 *
 * @package		KALS
 * @category		JavaScript
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/7/20 下午 10:17:42
 */

Object.prototype._substr = String.prototype.substr;
Object.prototype.substr = function(start, length)
{
    if (start < 0)
        start = this.length - 1 + start;
    return this._substr(start, length);
}

/**
 * Method String.endsWith
 *
 * @param string suffix 要比對的字串
 * @return boolean
 */
Object.prototype.endsWith = function(suffix)
{
    var len = suffix.length;
    var start = 0 - len;
    if (this.substr(start, len) == suffix)
        return true;
    else
        return false;
}

Object.prototype.startsWith = function(prefix)
{
    var len = prefix.length;
    var start = 0;
    if (this.substr(start, len) == prefix)
        return true;
    else
        return false;
}

Object.prototype.appendWith = function(suffix)
{
    if (this.endsWith(suffix) == false)
        return this + suffix;
    else
        return this;
}

/**
 * 判斷字首是否是prefix，否則加上prefix
 *
 * @param Object prefix
 * @type boolean
 */
Object.prototype.prependWith = function(prefix)
{
    if (this.startsWith(prefix) == false)
        return this + prefix;
    else
        return this;
}

/**
 * KALS constructor.
 */
function KALS () {

}

/**
 * Method KALS.test.
 */
KALS.prototype.test = function (){

}


KALS_Unit = {
    test: 'test',
    /**
     *  改寫jQuery的$.getJSON方法
     *
     * @param KALS url
     * @param json
     * @param callback
     */
    getJSON: function(url, json, callback)
    {
        json = encodeURIComponent(json);
        json = escape(json);
        url = url.appendWith('/');
        url = url + json + '/callback=?';
        $.getJSON(url, callback);
    }
};