<?php
require_once 'Segmentor.php';
/**
 * Segmentor_CKIP
 *
 * 以CKIP為主的斷詞工具
 *
 * @package		KALS
 * @category		Library
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/7/1 下午 03:12:10
 */
class Segmentor_Yahoo_CAS extends Segmentor {

    #Memver Varibles
    public $name = 'segmentor.yahoo_cas';

    private $app_id = '';

    #Methods
    public function  __construct() {
        parent::__construct();
        $this->CI->config->load('kals');
        $this->app_id = $this->CI->config->item('yahoo.app_id');
    }

    public function  text_to_segment($text, $with_speech = FALSE) {
        $result = $this->get_analyze_result($text);

        $output = '';
        test_msg(count($result));
        foreach($result AS $r)
        {
            $output .= $r['keyword'].Segmentor::$speech_separator.$r['score'].' ';
        }
        return $output;
    }

    private function get_analyze_result($content) {
      //$request_url = 'http://asia.search.yahooapis.com/cas/v1/ke';    //文章關鍵字擷取(Keyword Extraction)
      $request_url = 'http://asia.search.yahooapis.com/cas/v1/ws';  //詞性標註(Word Segmentation)
      $appid = $this->app_id;  // 自己的Yahoo! APPID
      $ch = curl_init();
      $curl_opts = array(
        CURLOPT_URL  =>  $request_url,
        CURLOPT_POST  =>  true,
        CURLOPT_POSTFIELDS =>  array('appid'=>$appid, 'content'=>$content),
        CURLOPT_RETURNTRANSFER  =>  true
      );
      curl_setopt_array($ch, $curl_opts);
      $ret = curl_exec($ch);
      curl_close($ch);

      $xml = new simpleXMLElement($ret);
      test_msg($xml);
      $output = array();
      foreach ($xml->Keyword as $k) {
        $output[] = array('keyword'=>$k->token, 'score'=>$k->score);
      }
      return $output;
    }

    private function _speech_filter($speech)
    {
        return $speech;
    }
}


/* End of file Segmentor_CKIP.php */
/* Location: ./system/application/libraries/annotation/Segmentor_CKIP.php */