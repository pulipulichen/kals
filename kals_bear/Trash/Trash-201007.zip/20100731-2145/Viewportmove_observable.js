/**
 * Viewportmove_observable
 *
 * window.onresize事件的觀察者模式
 *
 * @package		KALS
 * @category		Webpage Application Libraries
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/7/28 下午 03:36:17
 * @constructor Resize_observable()
 * @requires jQuery
 * @requires Other_class
 */

/**
 * @class Viewportmove_obserable
 * @constructor
 * @extends Observable
 */
function Viewportmove_observable() {
    var _this = this;
    this.event_name = 'onviewportmove';
    var _event = function(){
        _this.notifyObservers(_this);
    };
    window.addEventListener("scroll", _event, false);
    window.addEventListener("resize", _event, false);
    window.addEventListener("load",   _event, false);
    return this;
}

// 繼承
Viewportmove_observable.prototype = new Observable();
Viewportmove_observable.prototype.event_name = 'onviewportmove';

/* End of file Viewportmove_observable */
///* Location: ./system/application/views/web_apps/toolkit/Viewportmove_observable.js */