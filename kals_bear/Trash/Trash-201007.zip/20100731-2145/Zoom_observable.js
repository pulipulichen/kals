/**
 * Zoom_observable
 *
 * 視窗縮放事件的觀察者模式
 *
 * @package		KALS
 * @category		Webpage Application Libraries
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/7/28 下午 03:36:17
 * @constructor Resize_observable()
 * @requires {jQuery} 以及jquery.extends.js
 * @requires {Observable} 
 */

/**
 * Zoom_observable
 * @class Zoom_observable 
 * @constructor Zoom_observable
 * @extends Observable
 * @property zoom_scale
 */
function Zoom_observable() {
    var _this = this;
    this.setup_zoom_detector();
    this.zoom_scale = 1;
    this.event_name = 'onzoom';
    this.detect_interval = 1000;
    return this;
}

Zoom_observable.prototype = new Observable();

/**
 * @memberOf {Zoom_observable}
 * @class {Zoom_observable}
 * @type {string}
 */
Zoom_observable.prototype.event_name = 'onzoom';

/**
 * Zoom通知
 * @param {Zoom_observable} _this
 */
Zoom_observable.prototype.notify_observers = function ()
{
    for (var _i in this.observers)
    {
        if ($.isset(this.observers[_i])
            && typeof(this.observers[_i].onzoom) == 'function')
            this.observers[_i].onzoom(this);
    }
    return this;
};

/**
 * zoom_scale
 * 
 * 目前縮放的比例
 * @class Zoom_observable
 * @type number
 */
Zoom_observable.prototype.zoom_scale = 1;

/**
 * 可視範圍的相素
 * @type number
 */
Zoom_observable.prototype.viewport_width = window.innerWidth;

/**
 * 調整是否為強制啟動。
 * 一般情況下，只有在mobile mode當中才會啟動。
 * @member Zoom_observable
 * @type boolean
 */
Zoom_observable.prototype.force_enable = false;

/**
 * 看看是否強制性啟動
 * 
 * @memberOf {Zoom_observable}
 * @param {boolean} _enable
 */
Zoom_observable.prototype.set_force_enable = function (_enable)
{
    this.force_enable = _enable;
    return this;
};

/**
 * 設定縮放偵測器
 * 
 * Provides a device_scale class on iOS devices for scaling user
 * interface elements relative to the current zoom factor.
 * 
 * http://37signals.com/svn/posts/2407-device-scale-user-interface-elements-in-ios-mobile-safari
 * Copyright (c) 2010 37signals.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @memberOf {Zoom_observable}
 * @copyright http://37signals.com/svn/posts/2407-device-scale-user-interface-elements-in-ios-mobile-safari
 * @author Copyright (c) 2010 37signals.
 */
Zoom_observable.prototype.setup_zoom_detector = function () {
    
    if (this.force_enable == false &&
        (typeof(jQuery) != 'undefined' 
         && typeof(jQuery.is_mobile_mode) == 'function'
         && jQuery.is_mobile_mode() == false))
        return;
    
    //原程式有這一段，但是用意不明，所以我先把他刪掉了
    //var _hasTouchSupport = "createTouch" in document;
    //if (!hasTouchSupport) return;
    
    var _headElement  = document.getElementsByTagName("head")[0];
    var _styleElement = document.createElement("style");
    
    _styleElement.setAttribute("type", "text/css");
    _headElement.appendChild(_styleElement);
    this.width_stylesheet = _styleElement.sheet;
    
    //設置寬度偵測器
    var _padding_text = 'a';
    for (var _i = 0; _i < 2000; _i++)
        _padding_text = _padding_text + ' a';
    
    var _width_detector_container = $('<div><span class="detector">'+_padding_text+'</span></div>')
        //.css('max-height', '0px')
        .css('overflow', 'hidden')
        .css('margin', '0')
        .css('padding', '0')
        .css('font-size', '1px')
        //.css('position', 'absolute')
        //.css('left', 0)
        .appendTo($('body'));
        _width_detector_container.find('span').css('background-color', 'red');
    this.width_detector = _width_detector_container.find('.detector');
    
    //其他的捲軸移動事件由Viewportview_observable去偵測
    //window.addEventListener("scroll", updateDeviceScaleStyle, false);
    //window.addEventListener("resize", updateDeviceScaleStyle, false);
    //window.addEventListener("load",   updateDeviceScaleStyle, false);
    
    this.update_device_scale_style();
    
    var _this = this;
    setInterval(function () {
        
        var _detect_width = _this.get_detector_width();
        var _viewport_width = _this.get_viewport_width();
        
        //如果偵測到的寬度與之前設定的寬度不同，則觸發事件
        if (_detect_width != _viewport_width) 
        {
            //將偵測到的寬度存成設定的寬度
            _this.viewport_width = _detect_width;
            _this.update_device_scale_style();
            _this.setChanged();
            _this.notifyObservers();
        }
    }, this.detect_interval);
    
    return this;
};

/**
 * 偵測的間隔時間，單位是毫秒
 * @type {number}
 */
Zoom_observable.prototype.detect_interval = 1000;

/**
 * @type {jQuery}
 */
Zoom_observable.prototype.width_detector = null;

Zoom_observable.prototype.width_stylesheet = null;

Zoom_observable.prototype.get_viewport_width = function () {
    return this.viewport_width;
};

Zoom_observable.prototype.get_detector_width = function () {
    var _width = this.width_detector.width();
    var _body = $('body');
    var _body_margin_left = _body.css('margin-left');
        _body_margin_left = _body_margin_left.substr(0, _body_margin_left.length - 2); 
    var _body_margin_right = _body.css('margin-right');
        _body_margin_right = _body_margin_right.substr(0, _body_margin_right.length - 2);
    var _max_width = $(document).width();
    
    var _screen_x = window.screenLeft;
    
    
    
    //$.test_msg($(document).width(), [_body_width, _body_margin_left, _body_margin_right, _width]);
    
    if ((_max_width - _body_margin_left - _body_margin_right) == _width) {
        _width = eval(parseInt(_width) + parseInt(_body_margin_left) + parseInt(_body_margin_right));
        _width = _width + _screen_x * 2;
        
    }
    else {
        //_width = eval(parseInt(_width) + parseInt(_body_margin_left));
        //_width = _width + _screen_x * 2 + $.getScrollbarWidth();
        
        _width = eval(parseInt(_width) + parseInt(_body_margin_left) + parseInt(_body_margin_right));
        _width = _width + _screen_x * 2;
    }
    
    /*
    var _scrollbar = $.getScrollbarWidth();
    if (_scrollbar > 0)
        _scrollbar = _scrollbar + 3;
    
    _width = eval(parseInt(_width) + parseInt(_body_margin_left) + parseInt(_body_margin_right));
        _width = _width + _screen_x * 2 + _scrollbar;
        */
    
    return _width;
};

Zoom_observable.prototype.get_device_scale = function()
{
    var _deviceWidth = null;
    //偵測方向
    var _landscape = Math.abs(window.orientation) == 90;
    
    //if (_landscape) {
      // iPhone OS < 3.2 reports a screen height of 396px
      // Android沒有辦法偵測到landscape，所以這條規則無效
      //_deviceWidth = Math.max(480, screen.height);
    //} else {
      //_deviceWidth = screen.width;
    //}
    var _deviceWidth = this.get_detector_width();
    
    //var _result = _width_detector.find('.detector').width() / _deviceWidth;
    var _result = _deviceWidth / window.outerWidth;
    
    // 加入平滑化(smooth)修正比例參數
    for (var _i = 0; _i < this.scale_range.length-1; _i++)
    {
        var _range1 = this.scale_range[_i];
        var _range2 = this.scale_range[(_i+1)];
        
        if (_result == _range1)
            break;
        
        if (_result < _range1 
            && _result > _range2)
        {
            var _middle = (_range1 + _range2) / 2;
            if (_result > _middle)
                _result = _range1;
            else
                _result = _range2;
            break;
        }
    }
    
    return _result;
};

Zoom_observable.prototype.scale_range = [2.5, 2, 1.5, 1.25, 1, 0.75, 0.625, 0.5, 0.375, 0.3125, 0.25, 0.2];

Zoom_observable.prototype.update_device_scale_style = function () 
{
    var _stylesheet = this.width_stylesheet;
    if (typeof(_stylesheet.cssRules) != 'undefined' 
        && _stylesheet.cssRules.length) 
    {
        _stylesheet.deleteRule(0);
    }
    
    var _scale = this.get_device_scale();
    
    _stylesheet.insertRule(
      ".device_scale {-webkit-transform:scale(" + _scale + ")}", 0
    );
    
    this.zoom_scale = _scale;
};

/* End of file Resize_observable */
///* Location: ./system/application/views/web_apps/toolkit/Resize_observable.js */