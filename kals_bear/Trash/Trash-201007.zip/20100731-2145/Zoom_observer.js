/**
 * Zoom_observer
 *
 * Interface
 *
 * @package		KALS
 * @category		Webpage Application Libraries
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/7/28 下午 03:55:07
 * @requires {KALS_context}
 */

/**
 * Zoom_observer介面
 */
if (typeof(INTERFACES) == 'undefined') INTERFACES = {};
INTERFACES.Zoom_observer = {
    onzoom: function () {}
};

/**
 * Zoom事件觀察者
 * 
 * @constructor {Zoom_observer}
 * @param {jQuery} _elem 物件本身
 * @param {function} _onzoom 當zoom事件發生時，呼叫的物件
 */
function Zoom_observer(_elem, _onzoom)
{
    this.element = _elem;
    this.onzoom_event = _onzoom;
    
    if (typeof(KALS_context) != 'undefined')
        KALS_context.get_zoom_observable().addObserver(this);

    return this;
}

/**
 * 執行onzoom事件
 * @param {Zoom_observable} _zoom_obs
 */
Zoom_observer.prototype.onzoom = function (_zoom_obs)
{
    if ($.is_function(this.onzoom_event))
        this.onzoom_event(this.element, _zoom_obs);
};

/* End of file Zoom_observer */
/* Location: ./system/application/views/web_apps/toolkit/Zoom_observer.js */