<?php
//require_once '';
/**
 * Policy_collection
 *
 * 權限集合
 *
 * @package		KALS
 * @category		Library
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/6/25 下午 08:05:32
 * @property CI_DB_active_record $db
 * @property CI_Base $CI
 * @property CI_Language $lang
 * @property KALSResource $resource
 * @property Action $action
 * @property Action_factory $action_factory
 */
class Policy_collection extends Generic_attribute_collection {

    protected $id = array(
        'resource_type_id' => NULL,
        'resource_id' => NULL
    );
    protected $table_name = 'policy';
    protected $data_fields = array('policy_id', 'action_id', 'resource_type_id', 'resource_id');
    protected $index_field = array('resource_type_id', 'resource_id');
    protected $type_field = 'action_id';

    protected $class_name = 'Policy';
    protected $class_dir = 'policy/';

    function  __construct($id = NULL) {
        parent::__construct($id);
        $this->_CI_load('library', 'policy/Action_factory', 'action_factory');
        $this->action_factory = $this->CI->action_factory;
    }

    public function get_id()
    {
        if (is_null($this->id) && isset($this->index_object))
        {
            $obj = $this->index_object;
            $this->id['resource_type_id'] = $obj->get_type_id();
            $this->id['resource_id'] = $obj->get_id();
        }
        return $this->id;
    }

    public function set_index_object(KALS_resource $obj)
    {
        $this->index_object = $obj;
        $this->id['resource_type_id'] = $obj->get_type_id();
        $this->id['resource_id'] = $obj->get_id();
        $this->is_loaded = FALSE;
        return $this;
    }

    protected function _load_default_index_where($db, $id)
    {
        foreach($this->index_field AS $field)
        {
            $db->where($this->table_name.'.'.$field, $id[$field]);
        }
    }

    /**
     * @param int $action_id
     * @return Policy
     */
    public function  get_item($action_id) {
        return parent::get_item($action_id);
    }

    public function allow(Action $action, KALS_actor $actor)
    {
        $policy = $this->get_policy($action);
        if (is_null($policy)) return $this;

        $actor_coll = $policy->actor_coll;
        $existed = $actor_coll->exist_actor($actor);
        
        if ($existed)
            return TRUE;
        else
            return $action->default_allow;
    }

    public function add_actor(Action $action, KALS_actor $actor)
    {
        $policy = $this->get_policy($action);
        if (is_null($policy)) return $this;
        $actor_coll = $policy->actor_coll;
        $actor_coll->add_actor($actor);
        return $this;
    }

    public function get_policy(Action $action)
    {
        if (FALSE === $action->is_applicable($this->index_object))
            return NULL;
        return $this->get_item($action->get_id());
    }

    public function remove_actor(Action $action , KALS_actor $actor)
    {
        $policy = $this->get_policy($action);
        if (is_null($policy)) return $this;

        $policy->actor_coll->remove_actor($actor);
        return $this;
    }

    public function remove_policy(Action $action)
    {
        $policy = $this->get_policy($action);
        if (is_null($policy)) return $this;

        $policy->delete();
        return $this;
    }
}


/* End of file Policy_collection.php */
/* Location: ./system/application/libraries/policy/Policy_collection.php */