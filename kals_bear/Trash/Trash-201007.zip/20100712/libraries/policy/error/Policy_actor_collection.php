<?php
/**
 * Policy_actor_collection
 *
 * 權限與行動者的集合
 *
 * @package		KALS
 * @category		Libraries
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/7/10 上午 01:35:59
 */
class Policy_actor_collection extends Generic_attribute_collection {

    # Memver Varibles
    protected $table_name = 'policy2actor';
    protected $index_field = 'policy_id';
    protected $type_field = 'actor_type_id';
    protected $data_fields = array('policy2actor_id', 'policy_id','actor_type_id', 'actor_id');

    protected $class_name = 'Policy_actor';
    protected $class_dir = 'policy/';

    public function exist_actor(KALS_actor $actor)
    {
        $key = $this->_filter_type_id($actor);
        return $this->exists($key);
    }
    
    protected function _load_default_setup_member($row, $member)
    {
        $type_id = $this->_filter_type_id($row['actor_type_id'], $row['actor_id']);
        $this->members[$type_id] = $member;
    }
    
    private function _filter_type_id($type_id, $id = NULL)
    {
        if (is_object($type_id))
        {
            $actor = $type_id;
            $id = $actor->get_id();
            $type_id = $actor->get_type_id();
        }
        return $type_id.'-'.$id;
    }

    public function  add_actor(KALS_actor $actor) {
        if ($this->exist_actor($actor))
            return $this;

        $type_id = $this->_filter_type_id($actor);
        $policy_actor = $this->_setup_policy_actor($actor);
        return parent::add_item($policy_actor, $type_id);
    }

    public function  remove_actor(KALS_actor $actor) {
        $type_id = $this->_filter_type_id($actor);
        return parent::remove_item($type_id);
    }

    public function  get_actor(KALS_actor $actor) {
        $type_id = $this->_filter_type_id($actor);
        if (FALSE === $this->exist_actor($actor))
            return NULL;
        $item = parent::get_item($type_id);
        return $item;
    }

    private function _setup_policy_actor(KALS_actor $actor)
    {
        $this->_CI_load('library', $this->class_dir.$this->class_name, strtolower($this->class_name));
        $policy_actor = new Policy_actor();
        $policy_actor->set_field($this->index_field, $this->get_id());
        $policy_actor->set_field('actor_type_id', $actor->get_type_id());
        $policy_actor->set_field('actor_id', $actor->get_id());
        return $policy_actor;
    }
}


/* End of file Policy_actor_collection.php */
/* Location: ./system/application/libraries/policy/Policy_actor_collection.php */