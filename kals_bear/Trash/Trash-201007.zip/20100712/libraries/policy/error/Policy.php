<?php
/**
 * Policy
 *
 * 權限
 *
 * @package		KALS
 * @category		Libraries
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/7/6 下午 09:47:16
 * @property Policy_actor_collection $actor_coll
 */
class Policy extends Generic_attribute_object {

    //------------------------------------
    # Generic Attribute Object

    protected $table_name = 'policy';
    protected $primary_key = 'policy_id';
    protected $table_fields = array('policy_id', 'action_id', 'resource_type_id', 'resource_id');
    protected  $not_null_field = array('action_id', 'resource_type_id', 'resource_id');
    protected  $unique_restriction = array('action_id', 'resource_type_id', 'resource_id');

    protected $type_field = 'action_id';

    public $actor_coll;
    protected function  _post_construct($table_name = NULL, $id = NULL) {
        parent::_post_construct($table_name, $id);

        $this->_CI_load('library', 'policy/Policy_actor_collection', 'policy_actor_collection');
        $this->actor_coll = new Policy_actor_collection($this);
    }

    protected function  _post_update() {
        $this->actor_coll->update();
    }

    protected function  _pre_delete() {
        $this->actor_coll->remove_members();
    }

    public function get_actors()
    {
        $actors = array();
        foreach ($this->actor_coll AS $actor)
        {
            $actors[] = $actor;
        }
        return $actors;
    }
}


/* End of file Policy_actors.php */
/* Location: ./system/application/libraries/policy/Policy_actors.php */