<?php
/**
 * Policy_actor
 *
 * 權限對應的使用者或群組
 *
 * @package		KALS
 * @category		Libraries
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/7/6 下午 09:47:16
 */
class Policy_actor extends Generic_attribute_object {

    //------------------------------------
    # Generic Attribute Object

    protected $table_name = 'policy2actor';
    protected $primary_key = 'policy2actor_id';
    protected $table_fields = array('policy2actor_id', 'policy_id', 'actor_type_id', 'actor_id');
    protected  $not_null_field = array('policy_id' , 'actor_type_id', 'actor_id');
    protected  $unique_restriction = array('policy_id' , 'actor_type_id', 'actor_id');

    //protected $type_field = array('actor_type_id', 'actor_id');

    
}


/* End of file Policy_actors.php */
/* Location: ./system/application/libraries/policy/Policy_actors.php */