/**
 * jquery.extends
 *
 * @package		KALS
 * @category		JavaScript Libraries
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/7/22 下午 09:25:20
 * @requires jQuery
 * @memberOf {jQUery}
 * @alias $
 */

// Deny defined again.
if (typeof($jquery_extends) == 'undefined') {

// --------
// 字串處理
// --------

/**
 * 擷取字串
 * @param {string} _str 要被擷取的字串
 * @param {number} _start 起始位置。如果是負數，則從最後面開始算
 * @param {number} _length 長度
 */
jQuery.substr = function(_str, _start, _length)
{
    if (_start < 0)
        _start = _str.length + _start;
    if (this.isset(_length) == false)
    {
        return _str.substr(_start);
    }
    else
    {
        return _str.substr(_start, _length);
    }
};

jQuery.endsWith = function(_str, _suffix)
{
    var _len = _suffix.length;
    var _start = 0 - _len;
    if (this.substr(_str, _start, _len) == _suffix)
        return true;
    else
        return false;
};

/**
 * 測試_str的開頭是否為_prefix
 * @param {Object} _str
 * @param {Object} _prefix
 */
jQuery.startsWith = function(_str, _prefix)
{
    var _len = _prefix.length;
    var _start = 0;
    if (_str.substr(_start, _len) == _prefix)
        return true;
    else
        return false;
};

jQuery.appendsWith = function(_str, _suffix)
{
    if (this.endsWith(_str, _suffix) == false)
        return _str + _suffix;
    else
        return _str;
};

/**
 * 判斷字首是否是prefix，否則加上prefix
 *
 * @param _str
 * @param _prefix
 * @type boolean
 */
jQuery.prependsWith = function(_str, _prefix)
{
    if (this.startsWith(_str, _prefix) == false)
        return _str + _prefix;
    else
        return _str;
};

jQuery.str_replace = function (_search, _replace, _subject, _count) {
    // http://kevin.vanzonneveld.net
    // +   original by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
    // +   improved by: Gabriel Paderni
    // +   improved by: Philip Peterson
    // +   improved by: Simon Willison (http://simonwillison.net)
    // +    revised by: Jonas Raoni Soares Silva (http://www.jsfromhell.com)
    // +   bugfixed by: Anton Ongson
    // +      input by: Onno Marsman
    // +   improved by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
    // +    tweaked by: Onno Marsman
    // +      input by: Brett Zamir (http://brett-zamir.me)
    // +   bugfixed by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
    // +   input by: Oleg Eremeev
    // +   improved by: Brett Zamir (http://brett-zamir.me)
    // +   bugfixed by: Oleg Eremeev
    // %          note 1: The count parameter must be passed as a string in order
    // %          note 1:  to find a global variable in which the result will be given
    // *     example 1: str_replace(' ', '.', 'Kevin van Zonneveld');
    // *     returns 1: 'Kevin.van.Zonneveld'
    // *     example 2: str_replace(['{name}', 'l'], ['hello', 'm'], '{name}, lars');
    // *     returns 2: 'hemmo, mars'

    var _i = 0, _j = 0, _temp = '', _repl = '', _sl = 0, _fl = 0,
            _f = [].concat(_search),
            _r = [].concat(_replace),
            _s = _subject,
            _ra = _r instanceof Array, _sa = _s instanceof Array;
    _s = [].concat(_s);
    if (_count) {
        this.window[_count] = 0;
    }

    for (_i=0, _sl=_s.length; _i < _sl; _i++) {
        if (_s[_i] === '') {
            continue;
        }
        for (_j=0, _fl=_f.length; _j < _fl; _j++) {
            _temp = _s[_i]+'';
            _repl = _ra ? (_r[_j] !== undefined ? _r[_j] : '') : _r[0];
            _s[_i] = (_temp).split(_f[_j]).join(_repl);
            if (_count && _s[_i] !== _temp) {
                this.window[_count] += (_temp.length-_s[_i].length)/_f[_j].length;}
        }
    }
    return _sa ? _s : _s[0];
};

// --------
// JSON與AJAX
// --------

jQuery.json_encode = function (_json)
{
    if (this.is_number(_json))
        return _json;
    else if(this.is_string(_json))
        return this.serializeString(_json);
    else if (this.is_array(_json))
        return this.serializeArray(_json);
    else
        return this.serializeJSON(_json);
};

jQuery.serializeJSON = function (_json)
{
    if (this.is_number(_json))
        return _json;
    else if(this.is_string(_json))
        return this.serializeString(_json);
    else if (this.is_array(_json))
        return this.serializeArray(_json);

    var _output = '';

    for (var _key in _json)
    {
        var _attr = '"'+_key+'":';
        var _value = _json[_key];
        if (this.is_number(_value))
            _attr += _value;
        else if (this.is_string(_value))
            _attr += this.serializeString(_value);
        else if (this.is_array(_value))
            _attr += this.serializeArray(_value);
        else if (this.is_object(_value))
            _attr += this.serializeJSON(_value);

        _output = this.combine_comma(_output);
        _output += _attr;
    }

    _output = '{' + _output + '}';
    return _output;
};

jQuery.serializeArray = function (_array)
{
    if (this.is_number(_array))
        return _array;
    else if(this.is_string(_array))
        return this.serializeString(_array);
    else if (this.is_object(_array))
        return this.serializeJSON(_array);

    var _output = '';

    for (var _key in _array)
    {
        var _attr = "";
        var _value = _array[_key];
        if (this.is_number(_value))
            _attr += _value;
        else if (this.is_string(_value))
            _attr += this.serializeString(_value);
        else if (this.is_array(_value))
            _attr += this.serializeArray(_value);
        else if (this.is_object(_value))
            _attr += this.serializeJSON(_value);

        _output = this.combine_comma(_output);
        _output += _attr;
    }

    _output = '[' + _output + ']';
    return _output;
};

jQuery.serializeString = function (_str)
{
    if (this.is_number(_str))
        return _str;
    else if (this.is_array(_str))
        return this.serializeArray(_str);
    else if (this.is_object(_str))
        return this.serializeJSON(_str);

    _str = this.addslashes(_str);
    return '"'+_str+'"';
};

jQuery.addslashes = function (_str) {
    // http://kevin.vanzonneveld.net
    // +   original by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
    // +   improved by: Ates Goral (http://magnetiq.com)
    // +   improved by: marrtins
    // +   improved by: Nate
    // +   improved by: Onno Marsman
    // +   input by: Denny Wardhana
    // +   improved by: Brett Zamir (http://brett-zamir.me)
    // +   improved by: Oskar Larsson Högfeldt (http://oskar-lh.name/)
    // *     example 1: addslashes("kevin's birthday");
    // *     returns 1: 'kevin\'s birthday'

    return (_str+'').replace(/[\\"']/g, '\\$&').replace(/\u0000/g, '\\0');
};

jQuery.combine_comma = function (_str)
{
    if (_str != '')
        _str += ',';
    return _str;
};

jQuery.loadStyle = function (_url, _callback)
{
    var _selector = 'link[type=text/css][rel=stylesheet][href='+_url+']';

    //防止重複載入
    var _style = this(_selector);
    if (_style.length > 0)
        _style.remove();

    var _this = this;
    _style = this('<link type="text/css" rel="stylesheet" />')
        .attr('href', _url)
        .appendTo(this('head'))
        .ready(function () {
            if (_this.is_function(_callback))
                _callback();
        });
};

jQuery.loadScript = function (_url, _callback)
{
    var _selector = 'script[type=text/javascript][src='+_url+']';

    //防止重複載入
    var _script = this(_selector);
    if (_script.length > 0)
        _script.remove();

    var _this = this;
    _script = this('<script type="text/javascript"></script>')
        .attr('src', _url)
        .appendTo(this('head'))
        .ready(function () {
            if (_this.is_function(_callback))
                _callback();
        });
};

// --------
// 驗證類
// --------

jQuery.get_class = function (_obj) {
    // http://kevin.vanzonneveld.net
    // +   original by: Ates Goral (http://magnetiq.com)
    // +   improved by: David James
    // *     example 1: get_class(new (function MyClass() {}));
    // *     returns 1: "MyClass"
    // *     example 2: get_class({});
    // *     returns 2: "Object"
    // *     example 3: get_class([]);
    // *     returns 3: false
    // *     example 4: get_class(42);
    // *     returns 4: false
    // *     example 5: get_class(window);
    // *     returns 5: false
    // *     example 6: get_class(function MyFunction() {});
    // *     returns 6: false

    if (_obj instanceof Object
        && !(_obj instanceof Array)
        && !(_obj instanceof Function)
        && _obj.constructor
        && _obj != this.window)
    {
        var _arr = _obj.constructor.toString().match(/function\s*(\w+)/);
        if (_arr && _arr.length == 2) {
            return _arr[1];
        }
        else
        {
            var _class_name = _obj.constructor.toString();
            if (this.startsWith(_class_name, '[object '))
                _class_name = _class_name.substring(8, _class_name.length);
            else
                return false;
            
            if (this.endsWith(_class_name, ']'))
                _class_name = _class_name.substring(0, _class_name.length-1);
            return _class_name;
        }
    }

    return false;
};

jQuery.is_null = function (_obj)
{
    if (typeof(_obj) == 'undefined')
        return true;
    else
        return (_obj == null);
};

jQuery.is_class = function(_obj, _class_name)
{
    return (typeof(_obj) == 'object' && (_obj instanceof _class_name));
};

jQuery.is_boolean = function(_obj)
{
    return (typeof(_obj) == 'boolean');
};

/**
 * 驗證是否為陣列
 *
 * @param _obj
 * @return 驗證結果
 * @type boolean
 */
jQuery.is_array = function(_obj)
{
    return (typeof(_obj) == 'object' && (_obj instanceof Array));
};

jQuery.is_string = function (_obj)
{
    return (typeof(_obj) == 'string');
};

jQuery.is_number = function (_obj)
{
    return (typeof(_obj) == 'number');
};

jQuery.is_object = function (_obj)
{
    return (typeof(_obj) == 'object' && !(_obj instanceof Array));
};

jQuery.is_function = function (_obj)
{
    return (typeof(_obj) == 'function');
};

jQuery.is_jquery = function (_obj)
{
    return (typeof(_obj) == 'object' && (_obj instanceof jQuery));
};

/**
 * 驗證是否物件_element為HTML物件
 * @param {Object} _element
 */
jQuery.is_html_element = function (_element)
{
    var _class_name = this.get_class(_element);
    
    if (_class_name == false)
        return false;
    if (this.startsWith(_class_name, 'HTML')
        && this.endsWith(_class_name, 'Element'))
        return true;
    else
        return false;
};

jQuery.isset = function (_obj)
{
    if (typeof(_obj) == "undefined"
        || this.is_null(_obj) == true)
        return false;
    else
        return true;
};

// --------
// URL類
// --------

jQuery.is_link = function(_url)
{
    if (this.startsWith(_url, 'http://')
        || this.startsWith(_url, 'https://')
        || this.startsWith(_url, 'ftp://'))
        return true;
    else
        return false;
};

jQuery.parse_url = function (_str, _component) {
    // http://kevin.vanzonneveld.net
    // +      original by: Steven Levithan (http://blog.stevenlevithan.com)
    // + reimplemented by: Brett Zamir (http://brett-zamir.me)
    // %          note: Based on http://stevenlevithan.com/demo/parseuri/js/assets/parseuri.js
    // %          note: blog post at http://blog.stevenlevithan.com/archives/parseuri
    // %          note: demo at http://stevenlevithan.com/demo/parseuri/js/assets/parseuri.js
    // %          note: Does not replace invaild characters with '_' as in PHP, nor does it return false with
    // %          note: a seriously malformed URL.
    // %          note: Besides function name, is the same as parseUri besides the commented out portion
    // %          note: and the additional section following, as well as our allowing an extra slash after
    // %          note: the scheme/protocol (to allow file:/// as in PHP)
    // *     example 1: parse_url('http://username:password@hostname/path?arg=value#anchor');
    // *     returns 1: {scheme: 'http', host: 'hostname', user: 'username', pass: 'password', path: '/path', query: 'arg=value', fragment: 'anchor'}

    var  _o   = {
        strictMode: false,
        key: ["source","protocol","authority","userInfo","user","password","host","port","relative","path","directory","file","query","anchor"],
        q:   {
            name:   "queryKey",
            parser: /(?:^|&)([^&=]*)=?([^&]*)/g
        },
        parser: {
            strict: /^(?:([^:\/?#]+):)?(?:\/\/((?:(([^:@]*):?([^:@]*))?@)?([^:\/?#]*)(?::(\d*))?))?((((?:[^?#\/]*\/)*)([^?#]*))(?:\?([^#]*))?(?:#(.*))?)/,
            loose:  /^(?:(?![^:@]+:[^:@\/]*@)([^:\/?#.]+):)?(?:\/\/\/?)?((?:(([^:@]*):?([^:@]*))?@)?([^:\/?#]*)(?::(\d*))?)(((\/(?:[^?#](?![^?#\/]*\.[^?#\/.]+(?:[?#]|$)))*\/?)?([^?#\/]*))(?:\?([^#]*))?(?:#(.*))?)/ // Added one optional slash to post-protocol to catch file:/// (should restrict this)
        }
    };

    var _m   = _o.parser[_o.strictMode ? "strict" : "loose"].exec(_str),
    uri = {},
    i   = 14;
    while (i--) {uri[_o.key[i]] = _m[i] || "";}
    // Uncomment the following to use the original more detailed (non-PHP) script

    //    uri[o.q.name] = {};
    //    uri[o.key[12]].replace(o.q.parser, function ($0, $1, $2) {
    //    if ($1) uri[o.q.name][$1] = $2;
    //    });
    //    return uri;


    switch (_component) {
        case 'PHP_URL_SCHEME':
            return uri.protocol;
        case 'PHP_URL_HOST':
            return uri.host;
        case 'PHP_URL_PORT':
            return uri.port;
        case 'PHP_URL_USER':
            return uri.user;
        case 'PHP_URL_PASS':
            return uri.password;
        case 'PHP_URL_PATH':
            return uri.path;
        case 'PHP_URL_QUERY':
            return uri.query;
        case 'PHP_URL_FRAGMENT':
            return uri.anchor;
        default:
            var _retArr = {};
            if (uri.protocol !== '') {_retArr.scheme=uri.protocol;}
            if (uri.host !== '') {_retArr.host=uri.host;}
            if (uri.port !== '') {_retArr.port=uri.port;}
            if (uri.user !== '') {_retArr.user=uri.user;}
            if (uri.password !== '') {_retArr.pass=uri.password;}
            if (uri.path !== '') {_retArr.path=uri.path;}
            if (uri.query !== '') {_retArr.query=uri.query;}
            if (uri.anchor !== '') {_retArr.fragment=uri.anchor;}
            return _retArr;
    }
};

jQuery.is_image = function(_url)
{
    if (false == this.is_link(_url))
        return false;
    var _param = this.parse_url(_url);
    if (this.is_null(_param) || this.is_null(_param.path))
        return false;
    var _path = _param.path;
    var _ext = this.parse_extension_name(_path);
    if (this.is_null(_ext))
        return false;
    if (this.inArray(_ext, ['jpg', 'jpeg', 'gif', 'png']) != -1)
        return true;
    else
        return false;
};

jQuery.parse_extension_name = function (_path)
{
    var _dot = _path.lastIndexOf('.');
    var _slash = _path.lastIndexOf('/');
    if (_dot == -1
        || _dot < _slash)
        return null;
    else
    {
        var _ext = _path.substr(_dot+1);
        return _ext;
    }
};

jQuery.get_time_interval = function (_time)
{
    // @todo 留到server端去做

};

jQuery.fn.exists = function () {
    return (this.length > 0);
};

jQuery.initedFlag = 'inited';
jQuery.fn.hasInited = function () {
    return this.hasClass(this.initedFlag);
};

jQuery.fn.setInited = function () {
    return this.addClass('inited');
};

jQuery.extend({
    init: function (_callback)
    {
        if (false == $(this).hasClass('inited'))
        {
            if (this.is_function(_callback))
                _callback(this);
            $(this).addClass('inited');
        }
        return this;
    }
});

jQuery.fn.extend({
    /**
     * 元素水平對齊
     * @memberOf {jQuery}
     * @param {Object} _options
     * 選項有三個
     * - option: 'left', 'middle', 'right'
     * - offset: 位移。會受到scale影響。
     * - scale: 手機模式用的縮放比例
     */
    align: function (_options) 
    {        
        var _option = $.get_parameter(_options, 'option');
        if ($.is_null(_option))
            return this;
        var _scale = $.get_parameter(_options, 'scale', 1);
        var _offset = $.get_parameter(_options, 'offset', 0);
        _offset = $.css_scale(_offset, _scale);
        _offset = $.strip_unit(_offset);
    
        var _this = $(this);
        //var position = _this.css('position');
        
        var _mobile_mode = $.is_mobile_mode();
        
        if (_this.is_layer()) 
        {
            if (_mobile_mode)
                _this.css('position', 'absolute');
            else
                _this.css('position', 'fixed');
            
            var _direction = 'left';
            
            //探測螢幕寬度
            var _max_width = window.innerWidth;
            if (window.innerWidth > window.outerWidth) {
                _max_width = window.outerWidth;
            }
            _max_width = _max_width * _scale;
            
            
            if (_option == 'left') 
            {
                if (_mobile_mode) {
                    _option = window.pageXOffset;
                    _option = _option + _offset;
                }
                else {
                    _option = _offset;
                }
            }
            else if (_option == 'right') {
               
               _direction = 'right';
               if (_mobile_mode) {
                   _option = window.screen.width 
                       - window.pageXOffset 
                       - _max_width
                       + _offset;
               }
               else
               {
                   _direction = 'right';
                   _option = _offset;    
               }
            }
            else if (_option == 'center') 
            {
                var _width = _this.width();
                _option = (_max_width - _width) / 2 
                    + _offset;
                
                if (_mobile_mode)
                    _option = _option + window.pageXOffset;
            }
            
            if (_mobile_mode) 
                _this.css(_direction, _option + 'px');
            else {
                var _animate_option = {};
                _animate_option[_direction] = _option + 'px';
                _this.animate(_animate_option);
            }
        }
        //if (position != 'static')
        /*
        if (_this.is_layer()) 
        {
            var _direction = 'left';
            
            if (_option == 'left') 
                _option = 0;
            else 
                if (_option == 'right') {
                    _option = 0;
                    _direction = 'right';
                }
            if (_option == 'center') {
                //var _left = _this.offset().left;
                //var _max_width = window.innerWidth;
                var _max_width = $('body').width();
                var _width = _this.width();
                _option = (_max_width - _width) / 2;
                _option = _option + 'px';
            }
            
            _this.css(_direction, _option);
        }
        */
        else
        {
            if (_option == 'left')
            {
                _this.css('margin-left', 0)
                    .css('float', 'none');
            }
            else if (_option == 'right')
            {
                _this.css('margin-right', 0)
                    .css('float', 'right');
            }
            else if (_option == 'center')
            {
                _this.css('margin-right', 'auto')
                    .css('margin-left', 'auto')
                    .css('float', 'none');
            }
            else
            {
                _this.css('margin-left', _option)
                    .css('float', 'none');
            }
        }
        return this;
    },
    /**
     * 元素垂直對齊
     * @memberOf {jQuery}
     * @param {Object} _options
     * 選項有三個
     * - option: 'left', 'middle', 'right'
     * - offset: 位移。會受到scale影響。
     * - scale: 手機模式用的縮放比例
     */
    valign: function (_options) 
    {
        var _option = $.get_parameter(_options, 'option');
        if ($.is_null(_option))
            return this;
        var _scale = $.get_parameter(_options, 'scale', 1);
        var _offset = $.get_parameter(_options, 'offset', 0);
        _offset = $.css_scale(_offset, _scale);
        _offset = $.strip_unit(_offset);
        
        var _this = $(this);
        //var _position = _this.css('position');
        
        if ($.is_null(_scale))
            _scale = 1;
            
        var _mobile_mode = $.is_mobile_mode();
        
        //if (_position != 'static')
        if (_this.is_layer()) 
        {
            if (_mobile_mode)
                _this.css('position', 'absolute');
            else
                _this.css('position', 'fixed');
            
            //探測螢幕高度
            var _max_height = window.innerHeight;
            if (window.innerHeight > window.outerHeight) {
                _max_height = window.outerHeight;
                //_max_height = _max_height - window.screenTop;
            }
            _max_height = _max_height * _scale;
            
            var _direction = 'top';
            
            
            if (_option == 'top') {
                if (_mobile_mode) {
                    _option = window.pageYOffset
                        + _offset;
                }
                else
                {
                    _option = _offset;    
                }
            }
            else if (_option == 'bottom') {
                _direction = 'bottom';
                _option = _offset;
                if (_mobile_mode) {
                    _option = window.screen.height 
                        - window.pageYOffset 
                        - _max_height
                        + _offset;
                }
                
            }
            else if (_option == 'middle') 
            {
                var _height = _this.height();
                _option = (_max_height - _height) / 2 + _offset;
                if (_mobile_mode) {
                    _option = _option + window.pageYOffset;
                }
            }
            
            if (_mobile_mode) 
                _this.css(_direction, _option + 'px');
            else {
               var _animate_option = {};
               _animate_option[_direction] = _option + 'px';
               _this.animate(_animate_option);
            }
        }
        else
        {
            if (_option == 'top')
            {
                _this.css('margin-top', 0);
            }
            else if (_option == 'bottom')
            {
                _this.css('margin-bottom', 0);
            }
            else if (_option == 'middle')
            {
                _this.css('margin-top', 0)
                    .css('margin-bottom', 0);
            }
            else
            {
                _this.css('margin-top', _option);
            }
        }
        
        /*
        if (_this.is_layer()) 
        {
            var _direction = 'top';
            
            if (_option == 'top') 
                _option = 0;
            else 
                if (_option == 'bottom') {
                    _direction = 'bottom';
                }
            if (_option == 'middle') {
                //var _left = _this.offset().left;
                //var _max_height = $('body').height();
                var _max_height = window.innerHeight;
                var _height = _this.height();
                _option = (_max_height - _height) / 2;
                _option = _option + 'px';
            }
            _this.css(_direction, _option);
        }
        else
        {
            if (_option == 'top')
            {
                _this.css('margin-top', 0);
            }
            else if (_option == 'bottom')
            {
                _this.css('margin-bottom', 0);
            }
            else if (_option == 'middle')
            {
                _this.css('margin-top', 0)
                    .css('margin-bottom', 0);
            }
            else
            {
                _this.css('margin-top', _option);
            }
        }
        */
        return this;
    },
    is_layer: function () {
        var _this = $(this);
        var _position = _this.css('position');
        return (_position != 'static');
    },
    visible: function () {
        var _this = $(this);
        if (_this.css('display') == 'none')
            return false;
        else if (_this.css('visibility') == 'hidden')
            return false;
        return true;
    },
    /**
     * 將物件寬度成到畫面寬度
     * 
     * @memberOf {jQuery}
     * @class {jQuery}
     * @param {Object} _scale 縮放比率
     */
    fullscreen_width: function (_scale)
    {
        /*
        var _this = $(this);
        
        if (false == _this.hasAttr('fullscreen_width')) {
            var _width = _this.get_width();
            _this.attr('fullscreen_width', _width);
        }
        
        var _max_width = null;
        if (_this.is_layer()) 
        {
            _max_width = '100%';
            //_max_width = '90%';
        }   
        else 
        {
            var _parent = _this.parent();
            //_max_width = _parent.width();
            _max_width = '100%';
            var _padding_left = _parent.css('padding-left');
            if ($.is_null(_padding_left))
                _padding_left = 0;
            var _padding_right = _parent.css('padding-right');
            if ($.is_null(_padding_right))
                _padding_right = 0;
            _max_width = _max_width - _padding_left - _padding_right;
        }
        
        setTimeout(function () {
            if (_this.is_layer())
            {
                _this.css_to_attr('left', 'fullscreen_left', 0);
                _this.css_to_attr('right', 'fullscreen_right', 0);
                //_this.css_to_attr('border-left-width', 'fullscreen_border_left_width', 0);
                //_this.css_to_attr('border-right-width', 'fullscreen_border_right_width', 0);    
            }
            
            _this.css('width', _max_width);
            _this.addClass('fullscreen');
            
        }, 10);
        */
       
        var _this = $(this);
        
        if ($.is_null(_scale))
            _scale = 1;
        
        //探測螢幕寬度
        var _max_width = window.innerWidth;
        if (window.innerWidth > window.outerWidth) {
            _max_width = window.outerWidth;
        }
        _max_width = _max_width * _scale;
        
        _this.css('width', _max_width+'px')
            .css('border-right-width', 0)
            .css('border-left-width', 0);
        
        return this;
    },
    fullscreen_height: function (_scale)
    {
        /*
        var _this = $(this);
        
        
        if (false == _this.hasAttr('fullscreen_height')) {
            var _height = _this.get_height();
            _this.attr('fullscreen_height', _height);
        }
        
        var _max_height = null;
        if (_this.is_layer()) {
            _max_height = '100%';
        }
        else {
            var _parent = _this.parent();
            _max_height = _parent.height();
            var _padding_top = _parent.css('padding-top');
            if ($.is_null(_padding_top)) 
                _padding_top = 0;
            var _padding_bottom = _parent.css('padding-bottom');
            if ($.is_null(_padding_bottom)) 
                _padding_bottom = 0;
            _max_height = _max_height - _padding_height - _padding_height;
        }
        
        setTimeout(function () {
            if (_this.is_layer())
            {
                _this.css_to_attr('top', 'fullscreen_top', 0);
                _this.css_to_attr('bottom', 'fullscreen_bottom', 0);
                _this.css_to_attr('border-top-width', 'fullscreen_border_top_width', 0);
                _this.css_to_attr('border-bottom-width', 'fullscreen_border_bottom_width', 0);                
            }
            
            _this.addClass('fullscreen');
            _this.css('height', _max_height);    
        }, 10);
        */
       
        var _this = $(this);
        
        if ($.is_null(_scale))
            _scale = 1;
        
        //探測螢幕高度
        var _max_height = window.innerHeight;
        if (window.innerHeight > window.outerHeight) {
            _max_height = window.outerHeight;
            //_max_height = _max_height - window.screenTop;
        }
        _max_height = _max_height * _scale;
        
    
        _this.css('height', _max_height+'px')
            .css('border-top-width', 0)
            .css('border-bottom-width', 0);
        
        return this;
    },
    /**
     * 將元素伸展到螢幕寬度及高度
     * @memberOf {jQuery}
     * @class {jQuery}
     * @param {string} _option "width", "height", "x", "y"
     * @param {number} _scale 比例
     */
    fullscreen: function (_option, _scale)
    {
        var _this = $(this);
        if ($.is_number(_option) && $.is_null(_scale))
        {
            _scale = _option;
            _option = null;
        }
        if ($.is_null(_scale))
            _scale = 1;
        
        if (_option == 'width' || _option == 'x')
            _this.fullscreen_width(_scale);
        else if (_option == 'height' || _option == 'y')
            _this.fullscreen_height(_scale);
        else
        {
            _this.fullscreen_width(_scale);
            _this.fullscreen_height(_scale);
            
        }
        return this;
    },
    /**
     * 從全螢幕模式中恢復
     * 但是不使用了
     */
    restore: function ()
    {
        var _this = $(this);
        if (false == _this.hasClass('fullscreen'))
            return;
            
        _this.removeClass('fullscreen');
        
        var _width = _this.attr('fullscreen_width');
        if ($.isset(_width))
        {
            _width = $.append_unit(_width);
            _this.css('width', _width);
            _this.removeAttr('fullscreen_width');
            
            _this.attr_to_css('fullscreen_left', 'left');
            _this.attr_to_css('fullscreen_right', 'right');
            _this.attr_to_css('fullscreen_border_left_width', 'border-left-width');
            _this.attr_to_css('fullscreen_border_right_width', 'border-right-width');
        }
        
        var _height = _this.attr('fullscreen_height');
        if ($.isset(_height))
        {
            _height = $.append_unit(_height);
            _this.css('height', _height);
            _this.removeAttr('fullscreen_height');
            
            _this.attr_to_css('fullscreen_top', 'top');
            _this.attr_to_css('fullscreen_bottom', 'bottom');
            _this.attr_to_css('fullscreen_border_top_width', 'border-top-width');
            _this.attr_to_css('fullscreen_border_bottom_width', 'border-bottom-width');
        }
        
        return this;
    },
    /**
     * 將屬性回存到CSS當中
     * @param {string} _attr 屬性
     * @param {string} _css CSS項目
     * @param {string|null} _reset 回存之後，屬性的值。空值則刪除此屬性 
     */
    attr_to_css: function (_attr, _css, _reset) {
        var _this = $(this);
        var _value = _this.attr(_attr);
        if ($.isset(_value))
        {
            _this.css(_css, _value);
            //alert([$.is_null(_reset), _reset]);
            if ($.is_null(_reset)) {
                //alert('remove: ' + _attr);
                _this.removeAttr(_attr);
            }
            else 
                _this.attr(_attr, _reset);
        }
        return this;
    },
    css_to_attr: function (_css, _attr, _reset) {
        var _this = $(this);
        if (_this.hasAttr(_attr))
            return this;
        
        var _value = _this.css(_css);
        if ($.isset(_value) && _value != 0 && _value != '')
        {
            _this.attr(_attr, _value);
            if ($.isset(_reset))
                _this.css(_css, _reset);
        }
        return this;
    },
    /**
     * 取得物件的寬度
     * @type {number}
     */
    get_width: function () {
        var _this = $(this);
        var _length = _this.css('width');
        if ($.is_null(_length)) {
            _length = _this.width();
            _length = $.append_unit(_length);
        }
        return _length;
    },
    /**
     * 取得物件的高度
     * @type {number}
     */
    get_height: function () {
        var _this = $(this);
        var _length = _this.css('height');
        if ($.is_null(_length)) {
            _length = _this.height();
            _length = $.append_unit(_length);
        }
        return _length;
    },
    /**
     * 是否擁有屬性
     * @param {string} _attr
     * @type {boolean}
     */
    hasAttr: function (_attr) {
        var _this = $(this);
        var _value = _this.attr(_attr);
        return ($.isset(_value));
    },
    /**
     * 按照比例調整jQuery物件本身的CSS值
     * @memberOf {jQuery}
     * @class {jQuery}
     * @param {string} _css 指定CSS項目
     * @param {string|number} _expect 預期值
     * @param {number|null} _scale 比例值
     */
    css_scale: function (_css, _expect, _scale)
    {   
        if ($.is_object(_css) && $.is_null(_scale))
        {
            _scale = _expect;
            _expect = _css.expect;
            _css = _css.css;
        }
    
        if ($.is_array(_css))
        {
            for (var _i in _css)
            {
                this.css_scale(_css[_i], _expect, _scale);
            }
            return this;
        }
        
        if ($.is_null(_scale))
            _scale = 1;
        //var _this = $(this);
        
        //var _value = this.css(_css);
        
        if ($.is_null(_expect)
            || _expect == 0
            || _expect == '')
            return this;
        
        var _scale_length = function (_expect, _scale) {
            if ($.is_number(_expect)) {
                _expect = _expect * _scale;
                if (_expect < 1) 
                    _expect = 1;
            }
            else {
                if ($.is_string(_expect)) {
                    if ($.endsWith(_expect, '%')) {
                        _expect = _expect.substr(0, _expect.length - 1);
                        _expect = _expect * _scale;
                        if (_expect < 1) 
                            _expect = 1;
                        _expect = _expect + '%';
                    }
                    else {
                        if ($.endsWith(_expect, 'px') ||
                        $.endsWith(_expect, 'em') ||
                        $.endsWith(_expect, 'cm') ||
                        $.endsWith(_expect, 'pt') ||
                        $.endsWith(_expect, 'ex') ||
                        $.endsWith(_expect, 'px') ||
                        $.endsWith(_expect, 'in') ||
                        $.endsWith(_expect, 'mm') ||
                        $.endsWith(_expect, 'pc')) {
                            var _len = _expect.length;
                            var _unit = _expect.substr(_len - 2, _len);
                            _expect = _expect.substr(0, _len - 2);
                            _expect = _expect * _scale;
                            
                            if (_expect < 1) 
                                _expect = 1;
                            
                            _expect = _expect + _unit;
                        }
                        else 
                            return null;
                    }
                }
            }
            return _expect;
        };
        
        if ($.is_string(_expect) && _expect.indexOf(' ') > -1)
        {
            var _expects = _expect.split(' ');
            for (var _key in _expects)
            {
                _expects[_key] = _scale_length(_expects[_key], _scale);
            }
            _expect = _expects.join(' ');
        }
        else
        {
            _expect = _scale_length(_expect, _scale);
        }
        if ($.is_null(_expect))
            return this;
        
        this.css(_css, _expect);
        return this;
    }
});

/**
 * 將CSS值加入單位。如果已經有單位，則不做調整
 * @param {string|number} _length CSS值
 * @param {string} _default_unit 預設單位
 * @type {type}
 */
jQuery.append_unit = function (_length, _default_unit) {
    if (this.is_null(_default_unit))
        _default_unit = 'px';
    
    if (this.is_number(_length))
        return _length + _default_unit;
    else
    {
        if (this.endsWith(_length, 'px')
            || this.endsWith(_length, '%')
            || this.endsWith(_length, 'em')
            || this.endsWith(_length, 'cm')
            || this.endsWith(_length, 'pt')
            || this.endsWith(_length, 'ex')
            || this.endsWith(_length, 'px')
            || this.endsWith(_length, 'in')
            || this.endsWith(_length, 'mm')
            || this.endsWith(_length, 'pc'))
            return _length;
        else
            return _length + _default_unit;
    }
};

/**
 * 去除CSS值的單位
 * @param {string|number} _length CSS值
 * @type {number}
 */
jQuery.strip_unit = function (_length) {
    if (this.is_number(_length))
        return _length;
    else
    {
        if (this.endsWith(_length, '%'))
            _length = _length.substr(0, _length.length -1);
        if (this.endsWith(_length, 'px')
            || this.endsWith(_length, 'em')
            || this.endsWith(_length, 'cm')
            || this.endsWith(_length, 'pt')
            || this.endsWith(_length, 'ex')
            || this.endsWith(_length, 'px')
            || this.endsWith(_length, 'in')
            || this.endsWith(_length, 'mm')
            || this.endsWith(_length, 'pc'))
            _length = _length.substr(0, _length.length -2);
        return parseInt(_length);
    }
};

/**
 * 取得CSS值的單位
 * @param {string|number} _length
 * @type {string}
 */
jQuery.get_unit = function (_length) {
    var _unit = null;
    if (this.is_number(_length))
        return _unit;
    else
    {
        var _len = _length.length;
        if (this.endsWith(_length, '%'))
            _unit = _length.substr(_len -1, _len);
        if (this.endsWith(_length, 'px')
            || this.endsWith(_length, 'em')
            || this.endsWith(_length, 'cm')
            || this.endsWith(_length, 'pt')
            || this.endsWith(_length, 'ex')
            || this.endsWith(_length, 'px')
            || this.endsWith(_length, 'in')
            || this.endsWith(_length, 'mm')
            || this.endsWith(_length, 'pc'))
            _unit = _length.substr(_len -2, _len);
        return _unit;
    }
};

/**
 * 縮放CSS單位的數值
 * @param {string|number} _length 要縮放的數值 
 * @param {number} _scale 比例
 */
jQuery.css_scale = function (_length , _scale) {
    if (_scale != 1 && _length != 0) {
        var _unit = $.get_unit(_length);
        _length = $.strip_unit(_length) * _scale;
        _length = _length + _unit;
    }
    return _length;
};

/**
 * 建立HTML元素，並附加在body之後。
 * @param {string} _html
 * @memberOf {jQuery}
 * @type {jQuery}
 */
jQuery.create_once = function (_html, _append_to) {
    
    if (this.is_null(_append_to))
        _append_to = this('body');
    
    var _temp_obj = this(_html);
    var _tag_name = _temp_obj.attr('tagName');

    var _class_name = _temp_obj.attr('class');
    if (_class_name != '' && _class_name != null)
    {
        var _classes = _class_name.split(' ');
        _class_name = '';
        for (var _key in _classes)
        {
            _class_name += '.'+_classes[_key];
        }
    }
    else
        _class_name = '';

    var _id = _temp_obj.attr('id');
    if (_id != '' && _id != null)
        _id = '#'+_id;
    else
        _id = '';


    if (_class_name == '' && _id == '')
    {
        _temp_obj.appendTo(_append_to);
        return _temp_obj;
    }
    else
    {
        var _selector = _tag_name+_class_name+_id;
        var _obj = this(_selector);
        if (false == _obj.exists())
        {
            _temp_obj.appendTo(_append_to);
            _obj = _temp_obj;
        }
        return _obj;
    }
};

/**
 * 顯示測試訊息
 * @param {string} _title
 * @param {Object} _test
 */
jQuery.test_msg = function (_title, _test)
{
    var _info_box = this('#info_box');
    if (_info_box.length == 0)
    {
         _info_box = this('<fieldset id="info_box" style="margin-bottom:1em;"><legend>Test Message Box</legend></fieldset>')
            .prependTo(this('body'));
    }
    //alert([this.isset(title), this.is_null(test)]);
    if (this.isset(_title) && this.is_null(_test))
    {
        _test = _title;
        _title = null;
    }
    else if (this.is_null(_title) && this.is_null(_test))
    {
        this('<hr />').appendTo(_info_box);
        return;
    }
    
    if (this.is_object(_test))
    {
        _test = '[Object: '+this.json_encode(_test)+']';
    }

    var _info = this('<pre>'+_test+'</pre>')
        .attr('style', 'display:block;border:1px solid #CCCCCC;padding: 5px;')
        .appendTo(this('#info_box'));

    if (this.isset(_title))
        _info.prepend('<span>'+_title+': </span>');
};

/**
 * 檢查是否符合Interface
 * @param {Object} _theObject
 * @param {Object} _theInterface
 * @type {boolean}
 */
jQuery.checkInterface = function(_theObject, _theInterface) {
    for (var _member in _theInterface) {
        if ( (typeof _theObject[_member] != typeof _theInterface[_member]) ) {
            this.test_msg("object failed to implement interface member ", _member);
            return false;
        }
    }
    //if we get here, it passed the test, so return true
    return true;
};

jQuery.scrollbarWidth = null;
/**
 * 取得捲軸的寬度。但是似乎不太有效。
 * @type {number}
 * @return 單位是px
 */
jQuery.getScrollbarWidth = function() {
    //if ($.scrollbarWidth == null) {
    
        var _scr = null;
        var _inn = null;
        var _wNoScroll = 0;
        var _wScroll = 0;
        
        // Outer scrolling div
        _scr = document.createElement('div');
        _scr.style.position = 'absolute';
        _scr.style.top = '-1000px';
        _scr.style.left = '-1000px';
        _scr.style.width = '100px';
        _scr.style.height = '50px';
        // Start with no scrollbar
        _scr.style.overflow = 'hidden';
        
        // Inner content div
        _inn = document.createElement('div');
        _inn.style.width = '100%';
        _inn.style.height = '200px';
        
        // Put the inner div in the scrolling div
        _scr.appendChild(_inn);
        // Append the scrolling div to the doc
        document.body.appendChild(_scr);
        
        // Width of the inner div sans scrollbar
        _wNoScroll = _inn.offsetWidth;
        // Add the scrollbar
        _scr.style.overflow = 'auto';
        // Width of the inner div width scrollbar
        _wScroll = _inn.offsetWidth;
        
        // Remove the scrolling div from the doc
        document.body.removeChild(document.body.lastChild);
        
        // Pixel width of the scroller
        return (_wNoScroll - _wScroll);
    //    $.scrollbarWidth = (_wNoScroll - _wScroll);
    //}
    //return $.scrollbarWidth;
};

/**
 * 去除HTML標籤
 * @memberOf {jQuery}
 * @param {string} _html 含有HTML標籤的字串
 * @type {string}
 */
jQuery.stripHTMLTag = function(_html)
{
    //var _reTag = /<(?:.|\s)*?/g;
    var _reTag = /<[^>].*?>/g;
    return _html.replace(_reTag,"");
};

/**
 * CSS框線圓角的名稱區
 */
jQuery.css_border_radius = { 
    moz: [
        '-moz-border-radius-topleft' ,
        '-moz-border-radius-topright' , 
        '-moz-border-radius-bottomleft' ,
        '-moz-border-radius-bottomright'
    ],
    webkit: [
        'border-top-left-radius' ,
        'border-top-right-radius' ,
        'border-bottom-left-radius' ,
        'border-bottom-right-radius'
    ]
};

/**
 * 適合手指的格式儲存區
 */
jQuery.css_finger_friendly = {
    'button': [
        {css: 'font-size', expect: '30px'},
        {css: 'border-width', expect: '3px'},
        {css: 'padding', expect: '5px'},
        {css: jQuery.css_border_radius.moz, expect: '10px'},
        {css: jQuery.css_border_radius.webkit, expect: '10px 10px'}
    ]
};

/**
 * 手機模式的暫存區
 * @type {boolean}
 */
jQuery.mobile_mode = null;

/**
 * 是否為手機模式
 * @type {boolean}
 */
jQuery.is_mobile_mode = function ()
{
    if (this.mobile_mode == null) {
        var _this = this;
        YUI().use("", function(Y){
            var _mode = (!$.is_null(Y.UA.mobile));
            _this.mobile_mode = _mode;
        });
    }
    return this.mobile_mode;
};

// ---------
// 相關介面
// ---------

jQuery.fn.extend({
    /**
     * 對應到Zoom觀察者的方法
     * @param {Zoom_observable} _zoom_observable
     */
    onzoom: function (_zoom_observable) {
        
    },
    onviewportmove: function() {
        
    }
});

jQuery.get_parameter = function(_parameters, _name, _default_value) 
{
    if ($.isset(_parameters[_name])) 
        return _parameters[_name];
    else {
        if ($.isset(_default_value))
            return _default_value;
        else
            return null;
    }
};

// 防止重複讀取
$jquery_extends = true;

}   //if (typeof(...

/* End of file jquery.extends */
/* Location: ./libraries/helpers/jquery.extends.js */