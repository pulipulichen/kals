<?php
include_once 'web_apps/web_apps_controller.php';
/**
 * Web_apps
 *
 * 讀取Web_apps所需要的資料
 *
 * @package		KALS
 * @category		Controllers
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/7/23 上午 11:16:40
 */

class Web_apps extends Web_apps_controller {

}

/* End of file web_apps.php */
/* Location: ./system/application/controllers/web_apps.php */