/**
 * KALS_setup
 *
 * @package		KALS
 * @category		JavaScript Libraries
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/7/22 下午 10:13:01
 * @constructor KALS_setup()
 * @requires jQuery
 * @requires Other_class
 */

// Deny defined again.
if (typeof(KALS_setup) == 'undefined') {

/**
 * @class KALS_setup
 * @constructor KALS_setup
 */
KALS_setup = function () {
    return this;
};


// --------
// 安裝程序
// --------

/**
 * 執行各物件的安裝
 */
KALS_setup.prototype.setup = function ()
{

};

/**
 * Setup完畢之後，接下來要開始跟伺服器取得資料，進行初始化。
 */
KALS_setup.prototype.initialize = function (email)
{

};

/**
 * 初始化完畢、也取得伺服器資料之後，接下來就進行更進一步的設置。
 */
KALS_setup.prototype.ready = function ()
{

};

/**
 * 上述工作完成之後，最後的設定。
 */
KALS_setup.prototype.complete = function ()
{

};

// Initilaize
KALS_setup = new KALS_setup();

}   //if (typeof(...

/* End of file KALS_setup */
/* Location: ./libraries/core/KALS_setup.js */