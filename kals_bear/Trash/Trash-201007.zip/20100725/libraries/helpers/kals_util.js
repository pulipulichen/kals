/**
 * KALS_util
 *
 * KALS程式使用到的工具箱，KALS_util
 *
 * @package		KALS
 * @category		JavaScript Libraries
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/7/20 下午 10:17:42
 * @requires jQuery
 */

if (typeof(KALS_util) == 'undefined') {

/**
 * @class $KU
 * @constructor $KU
 */
KALS_util = function()  {
    return this;
};

//KALS_util.prototype.url_anchor = new URL_anchor();
//KALS_util.prototype.lang = new KALS_language();
//KALS_util.prototype.auth = new KALS_authentication();

// --------
// KALS專案使用工具
// --------

/**
 *  改寫jQuery的$.getJSON方法
 *
 * @param $url 網址
 * @param $json 要傳遞的參數
 * @param $callback 回呼函數
 */
KALS_util.prototype.ajax_get = function ($url, $json, $callback)
{
    if ($.is_function($json) && $.is_null($callback))
    {
        $callback = $json;
        $json = null;
    }
    $json = encodeURIComponent($json);
    $json = escape($json);
    $url = $.appendsWith($url, '/');
    $url = $url + $json + '/callback=?';
    $.getJSON($url, $callback);
};

KALS_util.prototype.ajax_load_style = function ($url, $title)
{
    
};

KALS_util.prototype.ajax_load_script = function ($url, $title)
{
    
};

// --------
// 常用UI
// --------

KALS_util.prototype.show_excetion = function ($heading, $message)
{

};

KALS_util.prototype.alert = function ($heading, $message)
{

};

/**
 * KALS版本的confirm視窗，注意參數與一般的confirm並不相同，結果取得也是使用callback來進行。
 *
 * @param $heading 標題
 * @param $message 內文
 * @param $option 選項。這個選項必須由JSON組成，格式如下：
 * var option = {
 *      name1: value1,
 *      name2: value2,
 *      name3: function (value3) { //do something... }
 * };
 * value可以輸入函數，則點選時會直接呼叫此函數。
 * @param $callback 傳遞結果的回呼函數，格式如下：
 * var callback = function (value) {
 *      //use value do something
 * };
 * 如果option的value是函數的話，則不會呼叫callback。
 */
KALS_util.prototype.confirm = function ($heading, $message, $option, $callback)
{

};
// ---------

KALS_util = new KALS_util();

}   //if (typeof(...

/* End of file KALS_unit */
/* Location: ./libraries/helpers/kals_unit.js */