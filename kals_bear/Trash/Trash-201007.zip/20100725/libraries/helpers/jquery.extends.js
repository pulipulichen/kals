/**
 * jquery.extends
 *
 * @package		KALS
 * @category		JavaScript Libraries
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/7/22 下午 09:25:20
 * @requires jQuery
 */

// Deny defined again.

if (typeof(jquery_extends) == 'undefined') {

jQuery.json_encode = function ($json)
{
    if (this.is_number($json))
        return $json;
    else if(this.is_string($json))
        return this.serializeString($json);
    else if (this.is_array($json))
        return this.serializeArray($json);
    else
        return this.serializeJSON($json);
};

jQuery.serializeJSON = function ($json)
{
    if (this.is_number($json))
        return $json;
    else if(this.is_string($json))
        return this.serializeString($json);
    else if (this.is_array($json))
        return this.serializeArray($json);

    var $output = '';

    for (var $key in $json)
    {
        var $attr = '"'+$key+'":';
        var $value = $json[$key];
        if (this.is_number($value))
            $attr += $value;
        else if (this.is_string($value))
            $attr += this.serializeString($value);
        else if (this.is_array($value))
            $attr += this.serializeArray($value);
        else if (this.is_object($value))
            $attr += this.serializeJSON($value);

        $output = this.combine_comma($output);
        $output += $attr;
    }

    $output = '{' + $output + '}';
    return $output;
};

jQuery.serializeArray = function ($array)
{
    if (this.is_number($array))
        return $array;
    else if(this.is_string($array))
        return this.serializeString($array);
    else if (this.is_object($array))
        return this.serializeJSON($array);

    var $output = '';

    for (var $key in $array)
    {
        var $attr = "";
        var $value = $array[$key];
        if (this.is_number($value))
            $attr += $value;
        else if (this.is_string($value))
            $attr += this.serializeString($value);
        else if (this.is_array($value))
            $attr += this.serializeArray($value);
        else if (this.is_object($value))
            $attr += this.serializeJSON($value);

        $output = this.combine_comma($output);
        $output += $attr;
    }

    $output = '[' + $output + ']';
    return $output;
};

jQuery.serializeString = function ($str)
{
    if (this.is_number($str))
        return $str;
    else if (this.is_array($str))
        return this.serializeArray($str);
    else if (this.is_object($str))
        return this.serializeJSON($str);

    $str = this.addslashes($str);
    return '"'+$str+'"';
};

jQuery.addslashes = function ($str) {
    // http://kevin.vanzonneveld.net
    // +   original by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
    // +   improved by: Ates Goral (http://magnetiq.com)
    // +   improved by: marrtins
    // +   improved by: Nate
    // +   improved by: Onno Marsman
    // +   input by: Denny Wardhana
    // +   improved by: Brett Zamir (http://brett-zamir.me)
    // +   improved by: Oskar Larsson Högfeldt (http://oskar-lh.name/)
    // *     example 1: addslashes("kevin's birthday");
    // *     returns 1: 'kevin\'s birthday'

    return ($str+'').replace(/[\\"']/g, '\\$&').replace(/\u0000/g, '\\0');
}

jQuery.combine_comma = function ($str)
{
    if ($str != '')
        $str += ',';
    return $str;
};

jQuery.substr = function($str, $start, $length)
{
    if ($start < 0)
        $start = $str.length + $start;
    if (this.isset($length) == false)
    {
        return $str.substr($start);
    }
    else
    {
        return $str.substr($start, $length);
    }
};

jQuery.endsWith = function($str, $suffix)
{
    var $len = $suffix.length;
    var $start = 0 - $len;
    if (this.substr($str, $start, $len) == $suffix)
        return true;
    else
        return false;
};

jQuery.startsWith = function($str, $prefix)
{
    var $len = $prefix.length;
    var $start = 0;
    if ($str.substr($start, $len) == $prefix)
        return true;
    else
        return false;
};

jQuery.appendsWith = function($str, $suffix)
{
    if (this.endsWith($str, $suffix) == false)
        return $str + $suffix;
    else
        return $str;
};

/**
 * 判斷字首是否是prefix，否則加上prefix
 *
 * @prarm $str
 * @param $prefix
 * @type $boolean
 */
jQuery.prependsWith = function($str, $prefix)
{
    if (this.startsWith($str, $prefix) == false)
        return $str + $prefix;
    else
        return $str;
};

jQuery.is_null = function ($obj)
{
    if (typeof($obj) == 'undefined')
        return true;
    else
        return ($obj == null);
};

jQuery.is_class = function($obj, $class_name)
{
    return (typeof($obj) == 'object' && ($obj instanceof $class_name));
};

jQuery.is_boolean = function($obj)
{
    return (typeof($obj) == 'boolean');
};

jQuery.is_array = function ($obj)
{
    return (typeof($obj) == 'object' && ($obj instanceof Array))
};

jQuery.is_string = function ($obj)
{
    return (typeof($obj) == 'string')
};

jQuery.is_number = function ($obj)
{
    return (typeof($obj) == 'number')
};

jQuery.is_object = function ($obj)
{
    return (typeof($obj) == 'object' && !($obj instanceof Array))
};

jQuery.is_function = function ($obj)
{
    return (typeof($obj) == 'function')
};

jQuery.isset = function ($obj)
{
    if (typeof($obj) == "undefined"
        || this.is_null($obj) == true)
        return false;
    else
        return true;
};

jQuery.is_link = function($url)
{
    if ($.startsWith($url, 'http://')
        || $.startsWith($url, 'https://')
        || $.startsWith($url, 'ftp://'))
        return true;
    else
        return false;
};

jQuery.parse_url = function ($str, $component) {
    // http://kevin.vanzonneveld.net
    // +      original by: Steven Levithan (http://blog.stevenlevithan.com)
    // + reimplemented by: Brett Zamir (http://brett-zamir.me)
    // %          note: Based on http://stevenlevithan.com/demo/parseuri/js/assets/parseuri.js
    // %          note: blog post at http://blog.stevenlevithan.com/archives/parseuri
    // %          note: demo at http://stevenlevithan.com/demo/parseuri/js/assets/parseuri.js
    // %          note: Does not replace invaild characters with '_' as in PHP, nor does it return false with
    // %          note: a seriously malformed URL.
    // %          note: Besides function name, is the same as parseUri besides the commented out portion
    // %          note: and the additional section following, as well as our allowing an extra slash after
    // %          note: the scheme/protocol (to allow file:/// as in PHP)
    // *     example 1: parse_url('http://username:password@hostname/path?arg=value#anchor');
    // *     returns 1: {scheme: 'http', host: 'hostname', user: 'username', pass: 'password', path: '/path', query: 'arg=value', fragment: 'anchor'}

    var  $o   = {
        strictMode: false,
        key: ["source","protocol","authority","userInfo","user","password","host","port","relative","path","directory","file","query","anchor"],
        q:   {
            name:   "queryKey",
            parser: /(?:^|&)([^&=]*)=?([^&]*)/g
        },
        parser: {
            strict: /^(?:([^:\/?#]+):)?(?:\/\/((?:(([^:@]*):?([^:@]*))?@)?([^:\/?#]*)(?::(\d*))?))?((((?:[^?#\/]*\/)*)([^?#]*))(?:\?([^#]*))?(?:#(.*))?)/,
            loose:  /^(?:(?![^:@]+:[^:@\/]*@)([^:\/?#.]+):)?(?:\/\/\/?)?((?:(([^:@]*):?([^:@]*))?@)?([^:\/?#]*)(?::(\d*))?)(((\/(?:[^?#](?![^?#\/]*\.[^?#\/.]+(?:[?#]|$)))*\/?)?([^?#\/]*))(?:\?([^#]*))?(?:#(.*))?)/ // Added one optional slash to post-protocol to catch file:/// (should restrict this)
        }
    };

    var $m   = $o.parser[$o.strictMode ? "strict" : "loose"].exec($str),
    uri = {},
    i   = 14;
    while (i--) {uri[$o.key[i]] = $m[i] || "";}
    // Uncomment the following to use the original more detailed (non-PHP) script
    /*
        uri[o.q.name] = {};
        uri[o.key[12]].replace(o.q.parser, function ($0, $1, $2) {
        if ($1) uri[o.q.name][$1] = $2;
        });
        return uri;
    */

    switch ($component) {
        case 'PHP_URL_SCHEME':
            return uri.protocol;
        case 'PHP_URL_HOST':
            return uri.host;
        case 'PHP_URL_PORT':
            return uri.port;
        case 'PHP_URL_USER':
            return uri.user;
        case 'PHP_URL_PASS':
            return uri.password;
        case 'PHP_URL_PATH':
            return uri.path;
        case 'PHP_URL_QUERY':
            return uri.query;
        case 'PHP_URL_FRAGMENT':
            return uri.anchor;
        default:
            var $retArr = {};
            if (uri.protocol !== '') {$retArr.scheme=uri.protocol;}
            if (uri.host !== '') {$retArr.host=uri.host;}
            if (uri.port !== '') {$retArr.port=uri.port;}
            if (uri.user !== '') {$retArr.user=uri.user;}
            if (uri.password !== '') {$retArr.pass=uri.password;}
            if (uri.path !== '') {$retArr.path=uri.path;}
            if (uri.query !== '') {$retArr.query=uri.query;}
            if (uri.anchor !== '') {$retArr.fragment=uri.anchor;}
            return $retArr;
    }
};

jQuery.is_image = function($url)
{
    if (false == this.is_link($url))
        return false;
    var $param = this.parse_url($url);
    if (this.is_null($param) || this.is_null($param.path))
        return false;
    var $path = $param.path;
    var $ext = this.parse_extension_name($path);
    if (this.is_null($ext))
        return false;
    if (this.inArray($ext, ['jpg', 'jpeg', 'gif', 'png']) != -1)
        return true;
    else
        return false;
};

jQuery.parse_extension_name = function ($path)
{
    var $dot = $path.lastIndexOf('.');
    var $slash = $path.lastIndexOf('/');
    if ($dot == -1
        || $dot < $slash)
        return null;
    else
    {
        var $ext = $path.substr($dot+1);
        return $ext;
    }
};

jQuery.get_time_interval = function ($time)
{

};


/**
 * 顯示測試訊息
 */
jQuery.test_msg = function ($title, $test)
{
    var $info_box = $('#info_box');
    if ($info_box.length == 0)
    {
         $info_box = $('<fieldset id="info_box" style="margin-bottom:1em;"><legend>Test Message Box</legend></fieldset>')
            .prependTo($('body'));
    }

    //alert([this.isset(title), this.is_null(test)]);
    if (this.isset($title) && this.is_null($test))
    {
        $test = $title;
        $title = null;
    }
    else if (this.is_null($title) && this.is_null($test))
    {
        $('<hr />').appendTo($info_box);
        return;
    }

    var $info = $('<pre>'+$test+'</pre>')
        .attr('style', 'display:block;border:1px solid #CCCCCC;padding: 5px;')
        .appendTo($('#info_box'));

    if (this.isset($title))
        $info.prepend('<span>'+$title+': </span>');
}

// Initilaize
jquery_extends = true;
//$.prototype = jQuery.prototyp;

}   //if (typeof(...

/* End of file jquery.extends */
/* Location: ./libraries/helpers/jquery.extends.js */