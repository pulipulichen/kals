<?php
/**
 * Annotation_scope_collection
 *
 * Scope的集合
 *
 * @package		KALS
 * @category		Library
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/7/5 下午 03:16:30
 */
class Annotation_scope_collection extends Collection {

    # Memver Varibles
    private $annotation_id;
    protected $_members = array();
    private $_sorted = TRUE;
    private $_modified = FALSE;

    protected $table_name = 'annotation2scope';

    # Methods
    function  __construct($annotation_id = NULL) {
        //$this->CI->load->library('kals_resource/Annotation');
        parent::__construct();
        $this->_CI_load('library', 'scope/Annotation_scope', 'annotation_scope');

        if (isset($annotation_id))
        {
            $this->set_load_callback('load_annotation_scopes', $this);
            $this->set_annotation($annotation_id);
        }
        return $this;
    }

    public function get_annotation_id()
    {
        return $this->annotation_id;
    }

    protected function _check_callback()
    {
        if (isset($this->_onload) && FALSE === $this->_is_loaded)
        {
            $this->_is_loaded = call_user_func($this->_onload);
            if (is_null($this->_is_loaded))
                $this->_is_loaded = TRUE;
        }
    }

    //public function retrieve($annotation_id, $with_anchor_text = FALSE)
    public function load_annotation_scopes()
    {
        if (is_null($this->annotation_id))
            return $this;
        $annotation_id = $this->annotation_id;

        $with_anchor_text = FALSE;

        $annotation_id = $this->CI->annotation->filter_id($annotation_id);

        $this->db->from($this->table_name);
        $this->db->join('scope', $this->table_name.'.scope_id = scope.scope_id');

        $select_fields = $this->table_name.'.scope_id, webpage_id, from_index, to_index, anchor_text_id';
        if ($with_anchor_text)
        {
            $select_fields .= ', anchor_text.anchor_text_id, text, segmented';
            $this->db->join('anchor_text', 'scope.anchor_text_id, anchor_text.anchor_text_id');
        }
        $this->db->select($select_fields);

        $this->db->where('annotation_id', $annotation_id);
        $query = $this->db->get();

        $scopes = array();
        foreach($query->result_array() AS $row)
        {
            $scope = new Annotation_scope($row);
            $scopes[] = $scope;
        }

        $this->set_scopes($scopes);
        $this->set_annotation($annotation_id);
        $this->force_sorted();
        $this->force_modified();

        return $this;
    }

    public function update()
    {
        if ($this->_modified == FALSE)
            return $this;

        $this->_sort();

        $scope_id_array = array();
        foreach ($this->_members AS $scope)
        {
            $scope->update();
            $scope_id_array[] = $scope->get_id();
        }

        if (isset($this->annotation_id))
        {
            array_unique($scope_id_array);

//            $this->delete_annotation_scope($this->annotation_id);
//            foreach ($scope_id_array AS $scope_id)
//            {
//                $data = array(
//                    'annotation_id' => $this->annotation_id,
//                    'scope_id' => $scope_id
//                );
//
//                $this->CI->db->insert($this->table_name, $data);
//            }

            $db = $this->db;
            $db->select('scope_id');
            $db->from($this->table_name);
            $db->distinct();
            $db->where('annotation_id', $this->annotation_id);
            $query = $db->get();

            $old_id_array = array();
            foreach ($query->result_array() AS $row)
            {
                $old_id_array[] = $row['scope_id'];
            }

            $delete_id_array = array_cut($old_id_array, $scope_id_array);
            if (count($delete_id_array) > 0)
            {
                $db->where('annotation_id', $this->annotation_id);
                $db->where_in('scope_id', $delete_id_array);
                $db->delete($this->table_name);
            }

            $insert_id_array = array_cut($scope_id_array, $old_id_array);

            foreach ($insert_id_array AS $insert_id)
            {
                $set = array(
                    'annotation_id' => $this->annotation_id,
                    'scope_id' => $insert_id
                );
                $db->insert($this->table_name, $set);
            }
        }

        $this->_modified = FALSE;

        return $this;
    }

    public function force_sorted()
    {
        $this->_sorted = TRUE;
        return $this;
    }

    public function force_modified()
    {
        $this->_modified = FALSE;
        return $this;
    }

    public function delete_annotation_scope($annotation_id)
    {
        //$this->CI->load->library('kals_resource/Annotation');
        $this->_CI_load('library', 'kals_resource/Annotation', 'annotation');
        $annotation_id = $this->CI->annotation->filter_id($annotation_id);

        $this->CI->db->delete($this->table_name, array('annotation_id' => $annotation_id));
    }

    public function get_appended_webpages()
    {
        if (is_null($this->annotation_id))
            return NULL;

        $db = $this->db;
        $db->from('annotation2scope');
        $db->join('scope', 'annotation2scope.scope_id = scope.scope_id');
        $db->join('webpage', 'webpage.webpage_id = scope.webpage_id');
        //$db->group_by('webpage.webpage_id, webpage.uri, webpage.title, webpage.domain_id');
        $db->distinct();
        $db->where('annotation_id', $this->annotation_id);
        $db->select('webpage.*');

        $query = $db->get();
        if (is_null($this->CI->webpage))
            $this->CI->load->library ('kals_resource/Webpage');

        $webpages = array();
        foreach ($query->result_array() AS $row)
        {
            $webpage = new Webpage($row);
            array_push($webpages, $webpage);
        }
        return $webpages;
    }

    //-------------------------------------------------
    //以下是基本操作

    public function create_scope($from, $to, $anchor_text_id = NULL)
    {
        $scope = new Annotation_scope();
        $scope->set_index($from, $to);
        if (NULL != $anchor_text_id)
            $scope->set_anchor_text($anchor_text_id);

        $coll = new Annotation_scope_collection();
        $coll->set_scopes(array($scope));
        return $coll;
    }

    public function set_scopes($scopes)
    {
        //$scopes = self::sort_scopes($scopes);
        if (is_object($scopes) && FALSE === is_array($scopes))
        {
            $scopes = array($scopes);
        }

        $this->_members = $scopes;
        $this->_modified = TRUE;
        $this->_sorted = FALSE;
        return $this;
    }

    public function get_scopes()
    {
        $this->_sort();
        return $this->_members;
    }

    public function add_scope($scope)
    {
        array_push($this->_members, $scope);
        //$this->_members = self::sort_scopes($this->_members);
        $this->_modified = TRUE;
        $this->_sorted = FALSE;
        return $this;
    }

    public function add_scope_collection($scope_collection)
    {
        $another_scopes = $scope_collection->get_scopes();
        foreach ($another_scopes AS $scope)
        {
            $this->_members[] = $scope;
        }

        $this->_modified = TRUE;
        $this->_sorted = FALSE;
        return $this;
    }

    public function exclude_scope($scope)
    {
        $this->_check_callback();
        $this->_members = self::exclude_scopes($this->_members, array($scope));
        $this->_modified = TRUE;
        $this->_sorted = FALSE;
        return $this;
    }

    public function exclude_scope_collection($scope_collection)
    {
        $this->_members = self::exclude_scopes($this->_members, $scope_collection->get_scopes());
        
        $this->_modified = TRUE;
        $this->_sorted = FALSE;
        return $this;
    }

    public function get_length()
    {
        $this->_sort();

        $len = 0;
        foreach ($this->_members AS $scope)
        {
            $len = $len + $scope->get_length();
        }
        return $len;
    }

    public function set_annotation($annotation_id)
    {
        $this->CI->load->library('kals_resource/Annotation');
        $annotation_id = $this->CI->annotation->filter_id($annotation_id);

        $this->annotation_id = $annotation_id;
    }

    private function _sort()
    {
        $this->_check_callback();
        if ($this->_sorted === FALSE)
        {
            $this->_members = self::sort_scopes($this->_members);
            $this->_sorted = TRUE;
        }
        return $this;
    }

    static public function sort_scopes($scopes)
    {
        if (count($scopes) < 2)
            return $scopes;
        //先依照from來sort $scopes吧
        $from_array = array();

        foreach ($scopes AS $key => $scope)
        {
            $from_array[$key] = $scope->get_from_index();
        }

        asort($from_array);

        $sort_scopes = array();
        foreach ($from_array AS $key => $from)
        {
            $sort_scopes[] = $scopes[$key];
        }

        //再來做比較
        $output_scopes = array();
        $hold = FALSE;

        for ($i = 0; $i < count($sort_scopes); $i++)
        {
            if ($i == count($sort_scopes) - 1)
            {
                if ($hold === FALSE)
                    $output_scopes[] = $sort_scopes[$i];
                break;
            }

            $from = $sort_scopes[$i]->get_from_index();
            $to = $sort_scopes[$i]->get_to_index();
            $next_from = $sort_scopes[($i+1)]->get_from_index();
            $next_to = $sort_scopes[($i+1)]->get_to_index();
            if ($to + 1 < $next_from)
            {
                // NOW    ##########
                // NEXT                  ##############

                // NOW    ##########
                // NEXT              ##############
                $output_scopes[] = $sort_scopes[$i];
                $hold = FALSE;
                continue;
            }
            else
            {
                // NOW    ##########
                // NEXT             ##############

                // NOW    ##########
                // NEXT            ##############

                // NOW    ##########
                // NEXT   ##############

                // NOW    ##########
                // NEXT   #######

                $scope = new Annotation_scope();

                $new_from = $from;
                $new_to = max(array($to, $next_to));

                $scope->set_index($new_from, $new_to);

                //考慮文字的部份
                $text = $sort_scopes[$i]->get_text();
                if (NULL !== $text)
                {
                    $anchor_text = $sort_scopes[($i+1)]->get_anchor_text();
                    $next_text = $anchor_text->get_text();

                    $cover = $to - $next_from;
                    if ($cover > 0 && $cover < strlen($next_text))
                    {
                        $text = $text . substr($next_text, $cover);
                    }
                    $scope->set_anchor_text($text);
                }

                if ($hold === FALSE)
                    $output_scopes[] = $scope;
                else
                    $output_scopes[count($output_scopes)-1] = $scope;

                $sort_scopes[($i+1)] = $scope;

                $hold = TRUE;
                continue;
            }
        }
        return $output_scopes;
    }

    static public function exclude_scopes($scopes, $exclude_scopes)
    {
        foreach ($exclude_scopes AS $ex)
        {
            $ex_from = $ex->get_from_index();
            $ex_to = $ex->get_to_index();

            foreach ($scopes AS $key => $s)
            {
                $from = $s->get_from_index();
                $to = $s->get_to_index();
                if ($to < $ex_from
                    OR $from > $ex_to)
                {
                    //SCOPE     ##########
                    //EXCLUDE               ######
                    //NEW       ##########

                    //SCOPE            ##########
                    //EXCLUDE   ######
                    //NEW              ##########

                    continue;
                }
                else if (($from == $ex_from && $to == $ex_to)
                    OR ($from >= $ex_from && $to <= $ex_to))
                {
                    //SCOPE     ######
                    //EXCLUDE   ######

                    //SCOPE      ######
                    //EXCLUDE   ########

                    //SCOPE       ######
                    //EXCLUDE   ########

                    //SCOPE     ######
                    //EXCLUDE   ########

                    unset($scopes[$key]);
                    continue;
                }
                else if ($from <= $ex_from && $to <= $ex_to)
                {
                    //SCOPE     ##########
                    //EXCLUDE         ######
                    //NEW       ######
                    //          0123456

                    $new_from = $from;
                    $new_to = $ex_from - 1;

                    $scope = new Annotation_scope();
                    $scope->set_index($new_from, $new_to);

                    $text = $s->get_text();
                    if (NULL !== $text)
                    {
                        $len = $ex_from - $from - 1;
                        $text = substr($text, 0, $len);
                        $scope->set_anchor_text($text);
                    }

                    $scopes[$key] = $scope;
                }
                else if ($from >= $ex_from && $to >= $ex_to)
                {
                    //SCOPE         ##########
                    //EXCLUDE   ######
                    //NEW             ########
                    //          12345678901234

                    $new_from = $ex_to + 1;
                    $new_to = $to;

                    $scope = new Annotation_scope();
                    $scope->set_index($new_from, $new_to);

                    $text = $s->get_text();
                    if (NULL !== $text)
                    {
                        $len = $ex_to - $from + 1;
                        $text = substr($text, $len);

                        $scope->set_anchor_text($text);
                    }

                    $scopes[$key] = $scope;
                }
                else if ($from < $ex_from
                    && $to > $ex_to)
                {
                    //SCOPE     ##########
                    //EXCLUDE     ######
                    //NEW       ##      ##
                    //          0123456789

                    $text = $s->get_text();

                    $new_from1 = $from;
                    $new_to1 = $ex_from - 1;

                    $scope1 = new Annotation_scope();
                    $scope1->set_index($new_from1, $new_to1);

                    if (NULL !== $text)
                    {
                        $len = $ex_from - $from;
                        $text1 = substr($text, 0, $len);
                        $scope1->set_anchor_text($text1);
                    }

                    $scopes[$key] = $scope1;

                    //第二部分

                    $new_from2 = $ex_to + 1;
                    $new_to2 = $to;

                    $scope2 = new Annotation_scope();
                    $scope2->set_index($new_from2, $new_to2);

                    if (NULL !== $text)
                    {
                        $len = $ex_to - $from;
                        $text2 = substr($text, $len);
                        $scope2->set_anchor_text($text2);
                    }

                    $scopes[] = $scope2;
                }
            }
        }

        //$scopes = self::sort_scopes($scopes);
        return $scopes;
    }

    public function get_anchor_text()
    {
        $scopes = $this->get_scopes();

        $text = '';

        foreach ($scopes AS $scope)
        {
            if ($text != '')
                $text .= ' ';

            $text .= $scope->get_text();
        }

        return $text;
    }

    public function get_anchor_speech()
    {
        $scopes = $this->get_scopes();

        $coll_speechs = array();
        foreach ($scopes AS $scope)
        {
            $speechs = $scope->get_speechs();
            foreach ($speechs AS $sp)
            {
                if (FALSE === in_array($sp, $coll_speechs))
                {
                    $coll_speechs[] = $sp;
                }
            }
        }

        return $coll_speechs;
    }
}


/* End of file Annotation_scope_collection.php */
/* Location: ./system/application/libraries/annotation/Annotation_scope_collection.php */