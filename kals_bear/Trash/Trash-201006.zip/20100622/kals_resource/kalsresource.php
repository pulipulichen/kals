<?php
/**
 * kalsresource
 *
 * kalsresource full description.
 * 
 * @package		KALS
 * @category		Models
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/6/19 下午 12:03:05
 */
require_once './core/logger.php';
class KALSResource extends Model {

    var $logger;
    var $resource_id;
    var $resource_type_id;

    function KALSResource()
    {
        parent::Model();
        //$this->load->model("core/Logger", 'logger2');
        //echo gettype($this->logger2);
        $this->logger = new Logger();
        $this->logger->set_class($this);
    }

    function get_id()
    {
        if ($this->resource_id == NULL)
        {
            // @todo 當沒有的時候，去讀取資料庫吧
        }
        return $this->resource_id;
    }

    function get_type_id()
    {
        if ($this->resource_type_id == NULL)
        {
            // @todo 當沒有的時候，去讀取資料庫吧
        }
        return $this->resource_type_id;
    }

    function find($id, $type_id)
    {
        if ($type_id == 1)
            $this->load->model('kals_resource/Domain', 'Resource');
        else if ($type_id == 2)
            $this->load->model('kals_resource/Webpage', 'Resource');
        else if ($type_id == 3)
            $this->load->model('kals_resource/Annotation', 'Resource');
        else
            return NULL;
        $resource = $this->Resource->find($id);
        return $resource;
    }
}

/* End of file kalsresource.php */
/* Location: ./system/application/models/kalsresource.php */