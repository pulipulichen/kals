<?php
/**
 * domain
 *
 * domain full description.
 * 
 * @package		KALS
 * @category		Models
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/6/19 下午 12:11:24
 */
require_once 'kalsresource.php';

class Domain extends KALSResource {

    var $modle_path = 'kals_resource';
    var $table_name = 'domain';
    
    var $logger;
    var $resource_id;
    var $resource_type_id = 1;
    var $host;
    var $title;

    /**
     * 用來find並回傳結果的內部屬性
     * @var Domain
     */
    var $domain;

    function Domain()
    {
        parent::KALSResource();
        $this->load->model("core/Logger", 'logger');
        $this->logger->set_class($this);
        $this->load->helper('kals');
    }

    function create($url = NULL)
    {
        $d = $this->find($url);

        if ($d != NULL)
            return $d;

        $this->load->model($this->modle_path, 'domain');
        $domain = $this->domain;
        $host = parse_host($url);
        $domain->set_host($host);
        $domain->update();
        return $domain;
    }

    function find($key = NULL)
    {
        $id = NULL;
        $url = NULL;
        if (is_int($key))
        {
            $this->db->where('doamin_id', $id);
        }
        else if (is_string($key))
        {
            $this->db->where('url', $url);
        }
        else
            return NULL;

        $this->db->from($this->table_name);
        $this->db->limit(1);
        $count = $this->db->count_all_results();

        if ($count == 0)
            return NULL;

        $db->select('domain_id, host, title');
        $query = $db->get();
        $row = $query->result();

        $this->load->model($this->modle_path, 'domain');
        $this->domain->setup($row);
        return $this->domain;
    }

    function find_all()
    {
        $this->db->from($this->table_name);
        $this->db->order('host');
        $query = $this->db->get();

        $domains = array();
        foreach ($query->result() AS $row)
        {
            $this->load->modle($this->model_path, 'domain');
            $this->domain->setup($row);
            array_push($domains, $this->domain);
        }
        return $domains;
    }

    function setup($row)
    {
        if (isset($row->domain_id))
            $this->resource_id = $row->domain_id;
        if (isset($row->host))
            $this->host = $row->host;
        if (isset($row->title))
            $this->title = $row->title;
    }

    function update()
    {
        $data = array(
            'host' => $this->get_host(),
            'title' => $this->get_title()
        );

        $this->db->where('domain_id', $this->resource_id);
        $this->db->update($this->table_name, $date);
    }

    function delete()
    {
        $this->db->where('domain_id', $this->resource_id);
        $this->db->delete($this->table_name);
    }

    function set_host($host = NULL)
    {
        $host = parse_host($host);
        $this->host = $host;
    }

    function get_host()
    {
        return $this->host;
    }

    function set_title($title = NULL)
    {
        $this->title = $title;
    }

    function get_title()
    {
        if ($this->title == NULL && $this->host != NULL)
        {
            $this->title = $this->_retrieve_title();
        }
        return $this->title;
    }

    function get_webpages()
    {
        $webpages = array();
        if ($this->resource_id == NULL)
            return $webpages;

        $this->db->from('domain2webpage');
        $this->db->join('webpage','domain2webpage.webpage_id = webpage.webpage_id');
        $this->db->where('domain_id', $this->resource_id);

        $query = $this->db->get();
        foreach ($query->result() AS $row)
        {
            $this->load->model('kals_resource/Webpage', 'webpage');
            $this->webpage->setup($row);
            array_push($webpages, $this->webpage);
        }
        return $webpages;
    }

    function _retrieve_title()
    {
        $host = $this->host;
        if ($host == NULL)
            return NULL;

        return retrieve_title($host);
    }
}

/* End of file domain.php */
/* Location: ./system/application/models/domain.php */