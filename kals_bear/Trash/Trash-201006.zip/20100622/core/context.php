<?php
/**
 * context
 *
 * context full description. A part of KALS
 * @author Pudding Chen <puddingchen.35@gmail.com>
 * @version 1.0 2010/6/18 上午 11:47:26
 * @copyright Copyright (c) 2010, Pudding Chen
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 *
 */
class Context extends Model {

    var $Logger;

    var $webpage = NULL;
    var $domain = NULL;
    var $user = NULL;

    var $ignore_auth = FALSE;

    function Context()
    {
        parent::Model();
        $this->load->model("core/Logger");
        $this->Logger->set_class($this);
        $this->load->library('session');
    }

    function get_current_user()
    {
        if ($this->user == NULL)
        {
            //先讀取session，取得user_id
            $user_id = $this->session->userdata('user_id');
            if ($user_id !== FALSE)
            {
                $this->load->model('kals_actor/User', 'user');
                $this->user->find($user_id);
            }
        }
        return $this->user;
    }

    function set_current_user($user_in = NULL)
    {
        $this->user = $user_in;
    }

    function get_current_webpage()
    {
        if ($this->webpage == NULL)
        {
            $url = getenv("HTTP_REFERER");
            if ($url)
            {


            }
        }

    }


}

/* End of file context.php */
/* Location: ./system/application/model/core/context.php */