<?php
//require_once '';
/**
 * Policy
 *
 * 權限
 *
 * @package		KALS
 * @category		Library
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/6/25 下午 08:05:32
 * @property CI_DB_active_record $db
 * @property CI_Base $CI
 * @property CI_Language $lang
 * @property KALSResource $resource
 * @property Action $action
 */
class Policy {

    var $policy_id;
    var $resource;
    var $action;
    var $throw_exception = FALSE;

    var $actors;


    function Policy($resource = NULL, $action = NULL)
    {
        setup_kals_object($this);
        $this->CI->load->library('policy/Action_factory');

        if (is_int($resource))
        {
            $this->policy_id = $resource;
        }
        else if (is_object($resource))
        {
            $this->set_resource($resource);
            $this->set_action($action);
        }
    }

    function create($resource, $action, $actors)
    {
        $policy = new Policy();
        return $policy;
    }

    function find($cond, $value = NULL)
    {
        if (isset($cond['action_id']))
        {
            $cond['action'] = $this->_check_action($cond['action_id']);
        }
        if (($cond == 'id' || $cond == 'policy_id')
            && $value != NULL)
        {
            $cond = array('policy_id' => $value);
            $key = 'policy_id';
        }
        if (isset($cond['resource']) && isset($cond['action']))
        {
            $key = $cond['resource']->get_id();
            $value = $cond['action']->get_id();
        }

        // @todo find還沒做完喔！


        

    }

    function _check_action($action_id)
    {
        return $this->CI->action_factory->create($action_id);
    }

    function update()
    {
        //如果他有ID
        //或是指定了Resource跟Action
        //就update看看

        //如果沒有受到影響
        //則insert

        return TRUE;
    }

    function delete()
    {
        //刪掉policy2actor
        //刪掉policy
        return TRUE;
    }

    function set_id($id)
    {
        $this->policy_id = $id;
    }

    function get_id()
    {
        return $this->policy_id;
    }

    function set_resource($resource)
    {
        $this->resource = $resource;
    }

    function get_resource()
    {
        return $this->resource;
    }

    function set_action($action)
    {
        $this->action = $this->_check_action($action);
    }

    function get_action()
    {
        return $this->action;
    }

    function set_throw_exception($throw)
    {
        $this->throw_exception = $throw;
    }

    function set_actors($actors)
    {
        $this->actors = $actors;
    }

    function get_actors()
    {
        if ($this->actors == NULL)
        {
            $actors = array();
            //從資料庫中取得actors

            $this->actors = $actors;
        }
        return $this->actors;
    }

    function in_actors($actor)
    {
        $in = FALSE;
        return $in;
    }

    function allow($actor)
    {
        $allow = FALSE;

        $groups = $actor->get_parent_groups();

        return $allow;
    }

    function add_actor($actor)
    {
        if ($this->in_actors($actor))
        {
            return TRUE;
        }
        //加入

        return TRUE;
    }

    function remove_actor($actor)
    {
        
    }

    function has_actos()
    {
        $actors = $this->get_actors();
        return (count($actors) > 0);
    }
}


/* End of file Policy.php */
/* Location: ./system/application/libraries/.../Policy.php */