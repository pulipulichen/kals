<?php
require_once 'KALSResource.php';
/**
 * Domain
 *
 * Domain full description.
 *
 * @package		KALS
 * @category		Library
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/6/27 下午 09:14:42
 */
class Domain extends KALSResource {

    static public $resourc_type_id = 1;

    public $table_name = 'domain';
    public $table_fields = array('domain_id', 'host', 'title');
    public $primary_key = 'domain_id';
    public $not_null_field = array('host');
    public $unique_restriction = array('host');
    public $default_field = 'url';

    public function  __construct($id = NULL) {
        if (is_string($id) && url_is_link($id, FALSE))
        {
            $host = parse_host($id);
            return $this->create($host);
        }
        else
        {
            return parent::__construct($id);
        }
    }

//    public function create($cond, $value = NULL)
//    {
//        if (is_string($cond) && $value == NULL)
//        {
//            $cond = array(
//                'url' => $cond
//            );
//        }
//        $cond = convert_cond($cond, $value);
//
//        if (isset($cond['url']))
//            $cond['host'] = parse_host($cond['url']);
//
//        return parent::create($cond);
//    }
//
//    public function find($cond, $value = NULL)
//    {
//        if (is_string($cond) && $value == NULL)
//        {
//            $cond = array(
//                'url' => $cond
//            );
//        }
//        $cond = convert_cond($cond, $value);
//
//        if (isset($cond['url']))
//            $cond['host'] = parse_host($cond['url']);
//
//        return parent::find($cond);
//    }

    public function _field_filter($cond)
    {
        if (is_array($cond) && array_key_exists('url', $cond))
            $cond['host'] = parse_host($cond['url']);
        else if (is_string($cond) && $cond == 'url')
            $cond = 'host';

        return $cond;
    }


//    public function  set_field($field, $value) {
//        if ($field == 'url')
//        {
//            $field = 'host';
//            $value = parse_host($value);
//        }
//
//        parent::set_field($field, $value);
//    }

//    public function  get_field($field) {
//        if ($field == 'url')
//            $field = 'host';
//        return parent::get_field($field);
//    }


//    public function  update() {
//        parent::update();
//        if ($this->get_field('title') == NULL)
//        {
//            $title = retrieve_title($this->get_field('host'));
//            if (NULL != $title)
//            {
//                $this->set_field('title', $title);
//                parent::update();
//            }
//        }
//        return $this;
//    }

//    public function _post_insert()
//    {
//        if ($this->get_field('title') == NULL)
//        {
//            $title = retrieve_title($this->get_field('host'));
//            if (NULL != $title)
//            {
//                $this->set_field('title', $title);
//                parent::update();
//            }
//        }
//    }

    public function _pre_insert($data)
    {
        if (FALSE === isset($data['title'])
            OR is_null($data['title']))
        {
            $title = retrieve_title($this->get_field('host'));
            if (NULL != $title)
                $data['title'] = $title;
        }
        return $data;
    }

}


/* End of file Domain.php */
/* Location: ./system/application/libraries/.../Domain.php */