<?php
/**
 * MY_user_agent
 *
 * MY_user_agent full description.
 *
 * @package		KALS
 * @category		Library
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/6/23 下午 03:35:51
 */
class Generic_object extends KALSObject{
	
    # Member Variables
    private $id;
    private $table_name;

    private $database_fields = array();
    private $database_asso = array();
    private $loaded = FALSE;
    private $modified_fields = array();
    private $modified_asso = array();
    private $modified = FALSE;

    private $unique_restriction = array();
    private $not_null_field = array();
    private $table_field = array();
    
    # Methods
    
    public function set_unique(String $field)
    {
    	array_push($this->unique_restriction, $field);
    	return $this;
    }
    
	public function reset_unique()
    {
    	$this->unique_restriction = array();
    	return $this;
    }
    
    public function reload()
    {
        $pk = $this->_get_pk();
    	$id = $this->id;
    	$table_name = $this->table_name;
    	
    	$query = $this->db->from($table_name)
    		->where($pk, $id)
    		->get();
    	$result_fields = $query->first_row('array');
    	
    	$this->database_fields = $result_fields;
    	
    	$this->loaded = TRUE;

    	if (sizeof($this->modified_fields) > 0) 
    	{
    		foreach($this->modified_fields as $key => $value)
    		{
    			$this->modified_fields[$key] = FALSE;
    		}
    	}
    	return $this;
    }
    
    private function _load()
    {
    	$this->reload();
    	$this->loaded = TRUE;
    	return $this;
    }
    
    public function force_loaded()
    {
    	$thid->loaded = TRUE;
    	return $this;
    }
    
    public function get_field(String $field)
    {
    	if (TRUE === isset($this->id)
    		&& FALSE === $this->loaded)
    	{
    		$this->reload();
    	}

        if (FALSE === $this->_in_asso($field))
            return $this->database_fields[$field];
        else
            return $this->database_asso[$field];
    }
    
    public function get_all_fields()
    {
    	if (FALSE === $this->loaded)
    		$this->reload();
    	return $this->database_fields;
    }

    public function get_all_asso()
    {
    	if (FALSE === $this->loaded)
    		$this->reload();
    	return $this->database_asso;
    }
    
    public function get_id() 
    {
    	return $this->id;
    }
    
    public function initialize(String $table_name, int $tuple_id = NULL)
    {
        if ($table_name != NULL)
            $this->table_name = $table_name;
    	if ($tuple_id != NULL)
    		$this->id = $tuple_id;
    	return $this;
    }
    
    public function set_field(String $field, $value)
    {
    	if (FALSE === $this->loaded)
    	{
    		if (TRUE === isset($this->id))
    			$this->reload();
    	}
    	
        $this->modified = TRUE;

        if (FALSE === $this->_in_asso($field))
        {
            $this->database_fields[$field] = $value;
            $this->modified_fields[$field] = TRUE;
        }
        else
        {
            $this->database_asso[$field] = $value;
            $this->modified_asso[$field] = TRUE;
        }
    	return $this;
    }
    
    public function save_field($field, $value = NULL)
    {
    	if (is_array($field))
    	{
    		foreach ($field as $key => $value)
    			$this->set_field($key, $value);
    		$this->save();
    	}
    	else
    	{
    		$this->set_field($field, $value)
    			->save();
    	}
    	return $this;
    }

    public function destroy()
    {
    	if (TRUE === isset($this->id)
            && TRUE === isset($this->table_name))
    	{
            $pk = $this->_get_pk();

            $id = $this->id;
            $table_name = $this->table;

            //先檢查是否有這個id吧
            $result_num = $this->db->where($pk, $id)
                    ->from($table_name)
                    ->count_all_results();

            if ($result_num > 0)
            {
                $asso_tables = $this->_get_asso_tables();
                $this->db->where($pk, $id)
                    ->delete($asso_tables);
                
                $this->db->where($pk, $id)
                                ->delete($table_name);
                        return TRUE;
            }
    	}
    	
    	return FALSE;
    }
    
    public function save()
    {
        $pk = $this->_get_pk();
        $asso = $this->_get_asso();
        
    	$id = $this->id;
    	$table_name = $this->table_name;
    	
    	if (FALSE === isset($this->id))
    		$this->loaded = FALSE;
    	
    	$data = $this->_get_table_data();
    	$data = $this->_where_filter($data);
    	if (FALSE === $this->loaded)
    	{
            //確認關聯物件都已經配好
            foreach ($asso AS $field => $a)
            {
                if (FALSE === isset($this->database_asso[$field]))
                {
                    handle_error($this->lang->line('generic_object.save.no_asso.exception'));
                    return $this;
                }
            }

    		#假設這是一個新項目
    		if (TRUE === $this->_check_unique())
    		{
	    		if (TRUE === $this->_check_not_null())
	    		{
	    			$this->db->set($data);
	    			$this->db->insert($table_name);
	    		}
    		}

	    	//然後取得新增的ID
	    	$query = $this->db->select_max($pk)
		   		->where($data)    			
		   		->get($table_name);
		    		
                $result = $query->row(); //$query->first_row('array', 0);
                $proposed_id = $result->id;
                if ($proposed_id > 0)
                {
                        $this->loaded = TRUE;
                        $this->id = $proposed_id;
                }

                // @todo 新增asso
                foreach ($asso AS $key => $a)
                {
                    $table_name = $a['table_name'];
                    $data = array(
                        $a['asso_key'] => $this->get_field($key)->get_id(),
                        $pk => $this->id
                    );

                    $this->db->insert($a['table_name'], $data);
                }
    	}
    	else
    	{
            #更新原有項目
            $this->db->set($data);
            $this->db->where($pk, $this->id);
            $this->db->update($table_name);

            foreach ($this->modified_asso AS $field => $boolean)
            {
                
            }
    	}
    	
    	return $this;
    }
    
    private function _get_result_num($where)
    {
    	$result_num = $this->db->where($where)
    		->from($this->table_name)
    		->count_all_results();   		
    	return $result_num;
    }

    function _has_unique_restriction()
    {
        return (count($this->unique_restriction) > 0);
    }
    
    private function _check_unique()
    {
    	$pass = TRUE;
    	
    	foreach($this->unique_restriction as $restriction)
    	{
    		if (TRUE === is_array($restriction))
    		{
    			$full_data = TRUE;
    			
    			foreach($restriction as $field)
    			{
    				$where[$field] = $this->get_field($field);
    				if (FALSE === isset($where[$field]))
    				{
    					$full_data = FALSE;
    					break;
    				}
    			}
    			
    			if (TRUE === $full_data)
    			{
    				$result_num = $this->_get_result_num($where);
    				if ($result_num > 0)
    				{
    					$pass = FALSE;
    					break;
    				}
    			}
    			else
    			{
    				//如果只是一個約束條件沒過，那就直接略過沒關係。
    			}
    		}
    		else
    		{
    			$where[$restriction] = $this->get_field($restriction);
    			$result_num = $this->_get_result_num($where);
    			if ($result_num > 0)
    			{
    				$pass = FALSE;
    				break;
    			}
    		}
    	}
    	
    	return $pass;
    }
    
    public function set_not_null(String $field)
    {
    	if (FALSE === is_array($field))
    		array_push($this->not_null_field, $field);
    	else
    	 	array_merge($this->not_null_field, $field);
    	return $this;
    }
    
    public function reset_not_null()
    {
    	$this->not_null_field = array();
    	return $this;
    }
    
    private function _check_not_null()
    {
    	$pass = TRUE;
    	
    	$not_null_field = $this->not_null_field;
    	foreach ($not_null_field as $field)
    	{
    		if (FALSE === isset($this->database_fields[$field]))
    		{
    			$pass = FALSE;
    			break;
    		}
    	}
    	return $pass;
    }
    
    public function set_table_field(String $field)
    {
    	if (FALSE === is_array($field))
    		array_push($this->table_field, $field);
    	else
    	 	$this->table_field = array_merge($this->table_field, $field);
    	return $this;
    }
    
	public function reset_table_field()
    {
    	$this->table_field = array();
    	return $this;
    }
    
    //private function _get_table_data()
    public function _get_table_data()
    {
    	if (sizeof($this->table_field) == 0)
    		return $this->database_fields;
    	else
    	{
    		$data = array();
    		foreach($this->table_field as $field)
    		{
    			if (TRUE === isset($this->database_fields[$field]))
    			{
    				$data[$field] = $this->database_fields[$field];
    			}
    		}
    		return $data;
    	}
    }
    private function _where_filter($data)
    {
    	$output = array();
    	foreach($data as $k => $d)
    	{
    		if (is_null($d))
    			continue;
    		$output[$k] = $d;
    	}
    	return $output;
    }

    private function _get_pk()
    {
        if ($this->table_name != NULL)
            return $this->table_name.'_id';
        else
            return 'id';
    }

    private function _get_asso()
    {
        return array();
    }

    private function _get_asso_tables()
    {
        $asso = $this->_get_asso();
        
        $asso_tables = array();
        foreach($asso AS $a)
        {
            $asso_tables[] = $a['table_name'];
        }
        return $asso_tables;
    }

    private function _in_asso($field)
    {
        $asso = $this->_get_asso();

        return isset($asso[$field]);
    }

    private function _create_asso($class_name)
    {
        if (is_string($class_name))
        {
            $class_name = array($class_name);

            return 
        }
        else if (is_array($class_name))
        {
            $asso = array();
            forearch ($calss_name AS $c)
            {
                $key = strtolower($class_name);
                $a = array(
                    'table_name' => $key.'2'.$this->table_name,
                    'asso_key' => $key.'_id',
                    'class_name' => $calss_name
                );

                $asso[$key] = $a;
            }
            return $asso;
        }
    }
}
?>