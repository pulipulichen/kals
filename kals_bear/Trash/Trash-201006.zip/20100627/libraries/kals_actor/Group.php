<?php
include_once 'KALSActor.php';
/**
 * Group
 *
 * KALS的群組！
 *
 * @package		KALS
 * @category		Library
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/6/24 上午 12:51:56
 */
class Group extends KALSActor {

    var $actor_type_id = 2;

    /**
     * @var Array|NULL $users 如果是NULL，表示尚未讀取，讀取完應該是Array()
     */
    var $users = NULL;
    /**
     * @var Array|NULL $groups 如果是NULL，表示尚未讀取，讀取完應該是Array()
     */
    var $groups = NULL;

    function Group()
    {
        parent::KALSActor();
        $this->CI->load->library('kals_actor/User');
    }

    /**
     * 搜尋吧！
     * @param array|string $key 可以是搜尋條件$cond，也可以是'id'。name因為要搭配Domain，所以不行
     * @param int|NULL $value 只有$key == 'id'的時候才能有$value
     * @return Group
     */
    function find($key, $value = NULL)
    {
        if (is_array($key) === FALSE)
            $cond = array($key => $value);
        else
            $cond = $key;

        if (array_key_exists('id', $cond))
        {
            $cond['group_id'] = $cond['id'];
            $key = 'group_id';
        }

        if (array_key_exists('name', $cond))
            $key = 'name';
        else
            $key = 'group_id';

        if (array_key_exists('url', $cond))
        {
            $cond['domain'] = $this->_filter_domain($cond['url']);
        }

        if (has_cond_key($cond, $key))
        {
            $value = $cond[$key];
            $group = get_cache($this, $key, $value);
            if ($group != NULL)
                return $group;
        }

        if ($key == 'group_id')
        {
            $group = new Group;
            $group->set_id($value);
            set_cache($group, $key, $value);
            return $group;
        }

        //一切手段都無用，那就只能搜尋了！
        if (has_cond_key($cond, 'domain') === FALSE
            OR has_cond_key($cond, 'name') === FALSE)
        {
            return NULL;
        }

        $db = $this->db;
        $db->from('group');
        $db->join('domain2group', 'domain2group.group_id = group.group_id');
        $db->select('group.group_id, group.name');
        $db->where('name', $cond['name']);
        $db->where('domain2group.domain_id', $cond['domain']->get_id());
        $query = $db->get();
        if ($query->num_rows() == 0)
        {
            return NULL;
        }

        $row = $query->row();
        $group = new Group;
        $group->setup($row);
        set_cache($group, $key, $value);
        return $group;
    }

    /**
     * @param Domain|NULL $domain
     * @return array
     */
    function find_all($domain = NULL)
    {
        $db = $this->db;
        $db->from('group');
        $db->select('group.group_id, group.name');
        if ($domain != NULL)
        {
            $domain_id = $domain->get_id();
            $db->join('domain2group', 'domain2group.group_id = group.group_id');
            $db->where('domain_id', $domain_id);
        }
        $query = $db->get();
        $groups = array();
        $key = 'group_id';
        foreach ($query->result() AS $row)
        {
            $value = $row->group_id;

            $group = get_cache($this, $key, $value);
            if ($group == NULL)
            {
                $group = new Group();
                $group->setup($row);
                set_cache($group, $key, $value);
            }
            array_push($groups, $group);
        }
        return $groups;
    }

    function create($domain, $name)
    {
        $domain = $this->_filter_domain($domain);

        $group = $this->find(array(
            'domain'=>$domain,
            'name' => $name
        ));

        if ($group != NULL)
            return $group;

        $group = new Group();
        $group->set_name($name);
        $group->set_domain($domain);
        $group->update();
        set_cache($group, 'name', $name);
        return $group;
    }

    function setup($row = NULL)
    {
        if ($row == NULL)
        {
            $id = $this->get_id();
            //讀取$row
            if ($id == NULL)
                return NULL;
            else
            {
                $this->db->where(array('group_id'=>$id));
                $query = $this->db->get('group');
                if ($query->num_rows() == 0)
                    return NULL;
                else
                    $row = $query->row();
            }
        }

        if (isset($row->group_id))
                $this->set_id($row->group_id);
        if (isset($row->name))
                $this->set_name ($row->name);

        $this->loaded = TRUE;
        return $this;
    }

    function update()
    {
        $db = $this->db;
        $data = array(
            'name' => $this->name
        );

        if ($this->get_id() != NULL)
        {
            $data['group_id'] = $this->get_id();
            $db->where('group_id', $this->get_id());
            $db->update('group', $data);
            
            if ($db->affected_rows() > 0)
                return TRUE;
        }

        $domain = $this->get_domain();
        if ($domain == NULL)
            return FALSE;

        $db->insert('group', $data);
        $this->set_id($db->insert_id());

        $db->insert('domain2group', array(
            'domain_id' => $domain->get_id(),
            'group_id' => $this->get_id()
        ));

        return TRUE;
    }

    function delete()
    {
        // @todo 檢查policy2actor
        //檢查 domain2group group2group group2user
        $domain = $this->get_domain();
        $domain_id = $domain->get_id();

        $db = $this->db;
        $db->delete('domain2group', array('group_id' => $this->get_id()));
        $db->delete('group2group', array('parent_id' => $this->get_id()));
        $db->delete('group2group', array('child_id' => $this->get_id()));
        $db->delete('group2user', array('group_id'=> $this->get_id()));
        $db->delete('group', array('group_id' => $this->get_id()));

        $this->actor_id = NULL;
        $this->name = NULL;
        unset_cache($this);

        return TRUE;
    }

    function load()
    {
        if ($this->loaded === FALSE
            && $this->get_id() != NULL)
        {
            if ($this->setup() != NULL)
                return TRUE;
            else
                return FALSE;
        }
        return TRUE;
    }

    function get_domain()
    {
        if ($this->domain == NULL
            && $this->get_id() != NULL)
        {
            $db = $this->db;
            $db->from('domain2group');
            $db->where('group_id', $this->get_id());
            $db->select('domain_id');
            $query = $db->get();

            if ($query->num_rows() > 0)
            {
                $row = $query->row();
                $domain_id = $row->domain_id;
                $this->CI->load->library('kals_resource/Domain');
                $this->domain = $this->CI->domain->find('domain_id', $domain_id);
            }
        }
        return $this->domain;
    }

    function get_parent_groups($groups = NULL)
    {
        if ($groups == NULL)
            $groups = array();

        $db = $this->db;
        $db->from('group2group');
        $db->where('child_id', $this->get_id());
        $db->select('parent_id');
        $query = $db->get();

        foreach ($query->result() AS $row)
        {
            $parent_id = $row->parent_id;

            //檢查是否已經在$groups裡面
            $existed = FALSE;
            foreach ($groups AS $group)
            {
                if ($group->get_id() == $parent_id)
                {
                    $existed = TRUE;
                    break;
                }
            }

            //沒有的話，則加入，並且把它的get_parent_groups也一起加入
            if ($existed === FALSE)
            {
                $group = $this->find('group_id', $parent_id);
                array_push($groups, $group);

                $groups = $group->get_parent_groups($groups);
            }
        }

        return $groups;
    }

    function add_actor($actor)
    {
        if ($actor == NULL)
            return TRUE;
        else
        {
            $db = $this->db;
            if ($actor->get_type_id() == 1)
            {
                //先檢查是否有actor了
                $users = $this->get_users();
                foreach ($users AS $user)
                {
                    if ($user->equals($actor))
                        return TRUE;
                }

                //再來新增
                $db->insert('group2user', array(
                    'group_id' => $this->get_id(),
                    'user_id' => $actor->get_id()
                ));
                array_push($this->users, $actor);
                set_cache($actor, 'user_id', $actor->get_id());
                return TRUE;
            }
            else if ($actor->get_type_id() == 2)
            {
                //先檢查是否有actor了
                $groups = $this->get_groups();
                foreach ($groups AS $group)
                {
                    if ($group->equals($actor))
                        return TRUE;
                }

                //再來新增
                $db->insert('group2group', array(
                    'parent_id' => $this->get_id(),
                    'child_id' => $actor->get_id()
                ));
                array_push($this->groups, $actor);
                set_cache($actor, 'group_id', $actor->get_id());
                return TRUE;
            }
            else
                return FALSE;
        }
        return TRUE;
    }

    function remove_actor($actor)
    {
        if ($actor == NULL)
            return TRUE;
        else
        {
            $db = $this->db;
            if ($actor->get_type_id() == 1)
            {
                //先檢查是否有actor了
                $users = $this->get_users();
                foreach ($users AS $key => $user)
                {
                    if ($user->equals($actor))
                    {
                        //再來刪除
                        $db->delete('group2user', array(
                            'group_id' => $this->get_id(),
                            'user_id' => $actor->get_id()
                        ));
                        unset($this->users[$key]);
                        unset_cache($actor);
                    }
                }
                return TRUE;
            }
            else if ($actor->get_type_id() == 2)
            {
                //先檢查是否有actor了
                $groups = $this->get_groups();
                foreach ($groups AS $key => $group)
                {
                    if ($group->equals($actor))
                    {
                        //再來刪除
                        $db->delete('group2group', array(
                            'parent_id' => $this->get_id(),
                            'child_id' => $actor->get_id()
                        ));
                        unset($this->groups[$key]);
                        unset_cache($actor);
                    }
                }
                return TRUE;
            }
            else
                return FALSE;
        }
        return TRUE;
    }

    function in_group($actor)
    {
        if ($actor == NULL)
            return FALSE;
        else
        {
            $db = $this->db;
            if ($actor->get_type_id() == 1)
            {
                //先檢查是否有actor了
                $users = $this->get_users();
                foreach ($users AS $user)
                {
                    if ($user->equals($actor))
                            return TRUE;
                }
            }
            else if ($actor->get_type_id() == 2)
            {
                //先檢查是否有actor了
                $groups = $this->get_groups();
                foreach ($groups AS $group)
                {
                    if ($group->equals($actor))
                            return TRUE;
                }
            }
            else
                return FALSE;
        }
        return FALSE;
    }
    function get_users()
    {
        if ($this->users == NULL)
        {
            $db = $this->db;
            $db->from('group2user');
            $db->join('user', 'group2user.user_id = user.user_id');
            $db->where('user.deleted', 'FALSE');
            $db->select('group2user.user_id');
            $db->where('group_id', $this->get_id());
            $query = $db->get();

            $users = array();
            foreach($query->result() AS $row)
            {
                $user = $this->CI->user->find('user_id', $row->user_id);
                array_push($users, $user);
            }
            $this->users = $users;
        }
        return $this->users;
    }

    function get_groups()
    {
        if ($this->groups == NULL)
        {
            $db = $this->db;
            $db->from('group2group');
            $db->select('child_id');
            $db->where('parent_id', $this->get_id());
            $query = $db->get();

            $groups = array();
            foreach($query->result() AS $row)
            {
                $group = $this->find('group_id', $row->child_id);
                array_push($groups, $group);
            }
            $this->groups = $groups;
        }
        return $this->groups;
    }

    function get_actors()
    {
        $groups = $this->get_groups();
        $users = $this->get_users();

        $actors = $groups;
        foreach ($users AS $user)
            $actors[] = $user;

        return $actors;
    }
}


/* End of file Group.php */
/* Location: ./system/application/libraries/kals_actor/Group.php */