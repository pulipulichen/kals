<?php
/**
 * User
 *
 * KALS的使用者
 *
 * @package		KALS
 * @category		Library
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/6/22 下午 08:40:37
 */
include_once 'KALSActor.php';

class User extends KALSActor {

    var $actor_type_id = 1;

    var $password;
    var $email;
    var $sex = 0;
    var $photo = FALSE;
    var $locale;
    var $style;
    var $domain;

    //var $setup_fields = 'user.user_id, user.name, user.password, user.email, user.sex, user.photo, user.locale, user.style';
    var $setup_fields = 'user.user_id';

    function User()
    {
        parent::KALSActor();
    }

    /**
     * @return User|NULL
     */
    function find($key, $value = NULL)
    {
        $id = NULL;

        //參數前處理
        if (($key == 'id' OR $key == 'user_id')
                && $value != NULL)
        {
            $value = (int) $value;
            $cond = array('user_id' => $value);
        }
        else if (is_array($key))
        {
            $cond = $key;
            if (array_key_exists('id', $cond))
            {
                $cond['user_id'] = $cond['id'];
                $key = 'user_id';
            }
            if (array_key_exists('url', $cond)
                    && !array_key_exists('domain', $cond))
            {
                $cond['domain'] = $this->_filter_domain ($cond['url']);
                if (array_key_exists('name', $cond))
                    $key = 'name';
                else if (array_key_exists('email', $cond))
                    $key = 'email';
            }
            else
                $key = 'user_id';
        }
        else
            return NULL;

        //從cache中取得資料
        if (isset($cond[$key]))
        {
            $value = $cond[$key];
            $user = get_cache($this, $key, $value);
            if ($user != NULL)
                return $user;
        }

        //如果是選擇ID的話，則直接回傳ID給他
        if (array_key_exists('user_id', $cond))
        {
            $user = new User();
            $user->actor_id = $cond['user_id'];
            set_cache($user, 'user_id', $cond['user_id']);
            return $user;
        }

        $db = $this->db;
        
        $db->from('user');
        $db->where('user.deleted', 'FALSE');

        if (array_key_exists('user_id', $cond))
        {
            $db->where('user_id', $cond['user_id']);
        }
        else
        {
            $domain = get_array_index($cond, 'domain');
            $domain_id = $domain->get_id();

            if ($domain_id == NULL)
                return NULL;

            $db->join('domain2user', 'domain2user.user_id = user.user_id');
            $db->where('domain2user.domain_id', $domain_id);

            if (array_key_exists('name', $cond) != NULL)
                    $db->where('user.name', $cond['name']);
            if (array_key_exists('email', $cond) != NULL)
                    $db->where('user.email', $cond['email']);
            if (array_key_exists('password', $cond) != NULL)
                    $db->where('user.password', $this->_crypt_password($cond['password']));
        }   //else

        $db->limit(1);
        $db->select($this->setup_fields);
        $query = $db->get();

        if ($query->num_rows() == 0)
                return NULL;

        $this->CI->load->library('kals_actor/User');
        $row = $query->row();
        $user = new User();
        $user->set_id($row->user_id);

        //加入快取
        set_cache($user, $key, $value);

        return $user;
    }

    /**
     * @param Domain $domain
     * @return array
     */
    function find_all($domain = NULL)
    {
        $users = array();
        $db = $this->db;
        $db->from('user');
        $db->select($this->setup_fields);

        if ($domain != NULL)
        {
            $domain_id = $domain->get_id();
            $db->join('domain2user', 'domain2user.user_id = user.user_id');
            $db->where('domain_id', $domain_id);
        }

        $query = $db->get();
        $key = 'user_id';
        foreach ($query->result() AS $row)
        {
            $value = $row->user_id;

            $user = get_cache($this, $key, $value);
            if ($user == NULL)
            {
                $user = new User();
                $user->setup($row);
                set_cache($user, $key, $value);
            }
            array_push($users, $user);
        }
        return $users;
    }

    function _crypt_password($password)
    {
        if ($password == NULL)
            return NULL;
        $this->CI->config->load('kals');
        $salt = $this->CI->config->item('crypt_salt');
        $crypted_password = crypt($password, $salt);
        return $crypted_password;
    }
    /**
     * @return User
     */
    function setup($row = NULL)
    {
        if ($row == NULL)
        {
            $id = $this->get_id();
            if ($id != NULL)
            {
                $db = $this->db;
                $db->where(array('user_id' => $id));
                $query = $db->get('user');
                if ($query->num_rows() > 0)
                    $row = $query->row();
                else
                    return NULL;
            }
            else
                return NULL;
        }

        //'user.user_id, user.password, user.email, user.sex, user.photo, user.locale, user.style';
        if (isset($row->user_id))
                $this->actor_id = $row->user_id;
        else
            return NULL;
        if (isset($row->password))
                $this->set_password($row->password);
        if (isset($row->name))
                $this->set_name ($row->name);
        if (isset($row->email))
                $this->set_email($row->email);
        if (isset($row->sex))
                $this->set_sex($row->sex);
        if (isset($row->photo))
                $this->set_photo($row->photo);
        if (isset ($row->locale))
                $this->set_locale($row->locale);
        if (isset($row->style))
                $this->set_style($row->style);
        $this->loaded = TRUE;
        return $this;
    }

    function load()
    {
        if ($this->loaded === FALSE && $this->get_id() != NULL)
        {
            if ($this->setup() != NULL)
                return TRUE;
        }
        return FALSE;
    }

    /**
     * @return mixed
     */
    function search($domain, $keyword)
    {
        $domain = $this->_filter_domain($domain);
        $domain_id = $domain->get_id();

        $db = $this->db;
        $db->from('user');
        $db->like('name', $keyword);
        $db->like('email', $keyword);
        $db->select($this->setup_fields);
        $query = $db->get();

        $users = array();
        foreach ($query->result() AS $row)
        {
            $this->CI->load->library('kals_actor/User');
            $user = new User();
            $user->setup($row);
            array_push($users, $user);
        }
        return $users;
    }

    /**
     * @return User|NULL
     */
    function create($domain, $key, $value = NULL)
    {
        if (is_array($key) && $value == NULL)
        {
            $cond = $key;
            $key = get_cond_key($cond);
            $value = get_cond_value($cond);
        }

        $domain = $this->_filter_domain($domain);
        
        if (($key != 'name' && $key != 'email')
                || $domain == NULL)
        {
            return NULL;
        }

        $user = $this->find(array(
            'domain' => $domain,
            $key => $value));
        if ($user != NULL)
        {
            return $user;
        }
        
        //來建立User吧
        $this->CI->load->library('kals_actor/User');
        $user = new User();

        if ($key == 'name')
            $user->set_name($value);
        else if ($key == 'email')
            $user->set_email($value);
        else
            return NULL;
        $user->set_domain($domain);
        $user->update();
        set_cache($user, $key, $value);
        return $user;
    }

    function update()
    {
        $db = $this->db;
        $existed = check_row_exist($db, 'user', array('user_id'=>$this->get_id()));

        $data = array(
                'name' => $this->name,
                'email' => $this->email,
                'sex' => $this->sex,
                'photo' => $this->has_photo(TRUE),
                'locale' => $this->locale,
                'style' => $this->style,
                'password' => $this->password,
            );
        if ($existed === TRUE)
        {
            //做Update
            $data['user_id'] = $this->get_id();

            $db->where('user_id', $this->get_id());
            $db->update('user', $data);
            log_info('User update: ('.$this->get_id().') '.$this->get_name().' : '.$this->get_email());
        }
        else
        {
            //做insert
            $domain = $this->get_domain();
            if ($domain == NULL)
            {
                handle_error($this->lang->line('user_create_failed_by_no_domain'));
                return FALSE;
            }

            $db->insert('user', $data);

            $this->actor_id = $db->insert_id();
            $this->loaded = TRUE;

            //插入跟domain2user的關係
            $asso_data = array(
                'domain_id' => $domain->get_id(),
                'user_id' => $this->get_id()
            );
            $db->insert('domain2user', $asso_data);
        }
        return TRUE;
    }

    function delete()
    {
        // @todo 檢查policy2actor

        if ($this->get_id() == NULL)
                return FALSE;

        $db = $this->db;
        $db->where('user_id', $this->get_id());
        $db->update('user', array('deleted'=>'TRUE'));

        //清空本身的資料
        $this->actor_id = NULL;
        $this->name = NULL;
        $this->domain = NULL;
        $this->email = NULL;
        $this->photo = FALSE;
        $this->locale = NULL;
        $this->password = NULL;
        $this->style = NULL;
        $this->sex = 0;
        unset_cache($this);
        return TRUE;
    }

    function get_domain()
    {
        if ($this->domain == NULL
            && $this->get_id() != NULL)
        {
            $db = $this->db;
            $db->from('domain2user');
            $db->where('user_id', $this->get_id());
            $db->limit(1);
            $db->select('domain2user.domain_id');
            $query = $db->get();
            $row = $query->row();
            $domain_id = (int) $row->domain_id;

            $this->set_domain($domain_id);
        }
        return $this->domain;
    }

    function set_password($password)
    {
        $this->password = $this->_crypt_password($password);
    }

    function set_email($email)
    {
        $this->CI->load->helper('email');
        if (valid_email($email))
        {
            $this->email = $email;
            if ($this->name == NULL)
            {
                $name = get_email_name($email);
                $this->set_name($name);
                return;
            }
        }
    }
    
    function get_email()
    {
        $this->load();
        return $this->email;
    }
    
    function set_sex($sex)
    {
        if ($sex == 'man' || $sex == 'male')
            $sex = 1;
        else if ($sex == 'woman' || $sex == 'female')
            $sex = 2;
        else if (is_string($sex))
            $sex = 0;
        $this->sex = $sex;
    }

    function get_sex()
    {
        $this->load();
        return $this->sex;
    }

    function set_photo($photo)
    {
        $this->photo = $photo;
    }

    function has_photo($for_db = FALSE)
    {
        if ($for_db === FALSE)
        {
            $this->load();
            return $this->photo;
        }
        else
        {
            if ($this->photo === TRUE)
                return 'TRUE';
            else
                return 'FALSE';
        }
    }

    function set_locale($locale)
    {
        $this->CI->load->library('user_agent');
        if ($this->CI->agent->in_acceptable_langage($locale) === FALSE)
                $locale = $this->CI->agent->get_default_language();
        $this->locale = $locale;
    }

    function get_locale()
    {
        $this->load();
        if ($this->locale === NULL)
        {
            $this->CI->load->library('user_agent');
            return $this->CI->agent->detect_language();
        }
        else
            return $this->locale;
    }

    function set_style($style)
    {
        $this->style = $style;
    }

    function get_style()
    {
        $this->load();
        return $this->style;
    }

    function get_parent_groups() {
        $groups = array();

        $db = $this->db;
        $db->from('group2user');
        $db->where('user_id', $this->get_id());
        $db->select('group_id');
        $query = $db->get();

        $this->CI->load->library('kals_actor/Group');

        foreach ($query->result() AS $row)
        {
            $group_id = $row->group_id;

            $group = $this->CI->group->find('group_id', $group_id);
            array_push($groups, $group);

            $groups = $group->get_parent_groups($groups);
        }

        return $groups;
    }

    function add_friend($friend)
    {
        // @todo User::add_friend()
    }

    function get_friends()
    {
        // @todo User::get_friends()
    }


}


/* End of file User.php */
/* Location: ./system/application/libraries/kals_actor/User.php */