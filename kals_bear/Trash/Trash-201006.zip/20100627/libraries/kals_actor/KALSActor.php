<?php
/**
 * KALSActor
 *
 * User跟Group的原形
 *
 * @package		KALS
 * @category		Library
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/6/22 下午 07:23:22
 * @property CI_DB_active_record $db
 * @property CI_Language $lang
 */

class KALSActor {

    var $loaded = FALSE;

    var $actor_id;
    var $actor_type_id;
    var $domain;
    var $domain_id;
    var $name;
    var $lang;

    function KALSActor()
    {
        setup_kals_object($this);
        log_set_class($this);

        $this->CI->lang->load('kals');
        $this->lang = $this->CI->lang;
    }

    /**
     * @return KALSActor
     */
    function find($id, $type_id = 1)
    {
        $actor = NULL;
        if ($type_id == 1)
        {
            $this->CI->load->library('kals_actor/User');
            $actor = $this->CI->user->find('id', $id);
        }
        else if ($type_id == 2)
        {
            $this->CI->load->library('kals_actor/Group');
            $actor = $this->CI->group->find('id', $id);
        }
        return $actor;
    }

    function load()
    {
        return FALSE;
    }

    function get_id()
    {
        return $this->actor_id;
    }
    function set_id($id)
    {
        $this->actor_id = $id;
    }

    function get_type_id()
    {
        return $this->actor_type_id;
    }

    function set_domain($domain)
    {
        if (!(is_object($domain) && get_class($domain) == 'Domain'))
        {
                return;
        }
        $this->domain = $domain;
    }

    /**
     * @return Domain
     */
    function get_domain()
    {
        return $this->domain;
    }

    function set_name($name)
    {
        $this->name = $name;
    }

    function get_name()
    {
        $this->load();
        return $this->name;
    }

    function get_parent_groups()
    {
        $groups = array();
        return $groups;
    }

    function equals($actor = NULL)
    {
        if ($actor == NULL
            OR is_object($actor) === FALSE
            OR !(get_class($actor) == 'User' || get_class($actor) == 'Group'))
            return FALSE;

        return ($this->get_id() == $actor->get_id()
                && $this->get_type_id() == $actor->get_type_id());
    }
    
    function _filter_domain($domain)
    {
        if (is_object($domain))
        {
            if (get_class ($domain) == 'Domain')
                return $domain;
            else
                return NULL;
        }
        else
        {
            $this->CI->load->library('kals_resource/Domain');
            if (is_int($domain))
            {
                $domain_id = $domain;
                $domain = $this->CI->domain->find('id', $domain_id);
            }
            else if (is_string($domain))
            {
                $url = $domain;
                $domain = $this->CI->domain->find('url', $url);
            }
            else if (is_array($domain))
            {
                $cond = $domain;
                $domain = $this->CI->domain->find($cond);
            }
            else
                $domain = NULL;
            return $domain;
        }
    }

    function  __toString() {
        if ($this->get_type_id() == 1)
        {
            return 'User['.$this->get_id().']['.$this->get_name().']';
        }
        else if ($this->get_type_id() == 2)
        {
            return 'Group['.$this->get_id().']['.$this->get_name().']';
        }

    }
}


/* End of file KALSActor.php */
/* Location: ./system/application/libraries/kals_actor/KALSActor.php */