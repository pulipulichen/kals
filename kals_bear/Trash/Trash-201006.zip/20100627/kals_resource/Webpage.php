<?php
/**
 * Webpage
 *
 * Webpage是Domain以下的分支！
 *
 * @package		KALS
 * @category		Library
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/6/21 下午 10:27:58
 */
include_once 'KALSResource.php';

class Webpage extends KALSResource {

    var $lib_path = 'kals_resource/Webpage';
    var $table_name = 'webpage';

    var $resource_id;
    var $resource_type_id = 2;
    var $uri;
    var $title;

    var $parent_domain;

    function Webpage()
    {
        parent::KALSResource();
        log_set_class($this);
    }

    /**
     * 找尋Domain
     * @param mixed|int|string $key
     * @param string|null $value
     * @return Webpage
     */
    function find($key, $value = NULL)
    {
        if (is_array($key) && $value == NULL)
        {
            $cond = $key;
            $key = get_cond_key($cond);
            $value = get_cond_value($cond);
        }

        if ($key == NULL && $value == NULL)
            return NULL;

        if (($key == 'id' || $key == 'webpage_id')
                && $value != NULL)
            $value = (int) $value;

        if ($value != NULL)
        {
            $webpage = get_cache($this, $key, $value);
            if ($webpage != NULL)
            {
                return $webpage;
            }
        }

        $db = $this->db;
        $db->from($this->table_name);

        if ($key == 'id' OR $key == 'webpage_id')
        {
            $where = array('webpage.webpage_id' => $value);
            $db->where($where);
        }
        else if ($key == 'url')
        {
            $host = parse_host($value);
            $uri = parse_uri($value);

            if ($host != NULL && $uri != NULL)
            {
                $db->join('domain2webpage', 'domain2webpage.webpage_id = webpage.webpage_id');
                $db->join('domain', 'domain2webpage.domain_id = domain.domain_id');
                $where = array(
                    'webpage.uri' => $uri,
                    'domain.host' => $host
                );
                $db->where($where);
            }
            else if ($uri != NULL)
            {
                $db->where('uri', $value);
            }
        }
        else if ($key == 'uri')
        {
            $db->where('uri', $value);
        }
        else
            return NULL;

        $db->select('webpage.webpage_id, webpage.uri, webpage.title');
        $db->limit(1);
        $query = $db->get();

        if ($query->num_rows() == 0)
            return NULL;

        $row = $query->row();

        $this->CI->load->library($this->lib_path);
        $webpage = new Webpage();
        $webpage->setup($row);

        set_cache($webpage, $key, $value);

        return $webpage;
    }

    /**
     * 找尋該Domain底下的所有Webpage
     * @param Domain|NULL $domain
     * @return array
     */
    function find_all($domain = NULL)
    {
        $db = $this->db;

        if ($domain != NULL && get_class($domain) == 'Domain')
        {
            $db->from($this->table_name);
            $db->join('domain2webpage', 'domain2webpage.webpage_id = webpage.webpage_id');

            $db->where('domain2webpage.domain_id', $domain.get_id());
            $db->select('webpage.webpage_id, webpage.uri, webpage.title');
            $db->order('webpage.uri');
        }
        else
        {
            $db->from($this->table_name);
            $db->order_by('uri');
            $db->select('webpage_id, uri, title');
        }

        $query = $db->get();

        $webpages = array();
        foreach($query->result() AS $row)
        {
            $resource_id = $row->webpage_id;
            $webpage = get_cache($this, 'webpage_id', $resource_id);
            if ($webpage == NULL)
            {
                $this->CI->load->library($this->lib_path);
                $webpage = new Webpage();
                $webpage->setup($row, $domain);

                set_cache($webpage, 'webpage_id', $webpage->get_id());
            }
            array_push($webpages, $webpage);
        }
        return $webpages;
    }

    /**
     * @param mixed $row
     * @param Domain|NULL $domain
     * @return Webpage
     */
    function setup($row, $domain = NULL)
    {
        if (isset($row->webpage_id))
                $this->resource_id = $row->webpage_id;
        if (isset($row->uri))
                $this->set_uri($row->uri);
        if (isset($row->title))
                $this->set_title($row->title);
        
        if ($domain != NULL)
            $this->set_domain($domain);
        return $this;
    }

    /**
     * 建立Webpage，如果find不到的話
     * @param String|NULL $url
     * @return Webpage
     */
    function create($url = NULL)
    {
        if ($url == NULL)
            return NULL;

        $webpage = $this->find('url', $url);
        if ($webpage != NULL)
            return $webpage;

        $this->CI->load->library('kals_resource/Webpage');
        $webpage = new Webpage();
        $webpage->set_url($url);
        $webpage->update();
        set_cache($webpage, 'url', $url);
        return $webpage;
    }

    function update()
    {
        $db = $this->db;
        $existed = FALSE;

        if ($this->get_id() != NULL)
        {
            $db->where('webpage_id', $this->get_id());
            if ($db->count_all_results($this->table_name) > 0)
                    $existed = TRUE;
        }

        if ($existed === TRUE)
        {
            $data = array(
                'webpage_id' => $this->get_id(),
                'uri' => $this->get_uri(),
                'title' => $this->get_title()
            );
            $db->where('webpage_id', $this->get_id());
            $db->update($this->table_name, $data);
            log_info('Webpage update: ('.$this->get_id().') '.$this->get_uri().' '.$this->get_title());
        }
        else
        {
            $domain = $this->get_domain();
            if ($domain == NULL)
            {
                handle_error($this->lang->line('webpage_create_failed_by_no_domain'));
                return FALSE;
            }

            $data = array(
                'uri' => $this->get_uri(),
                'title' => $this->get_title()
            );
            $db->insert($this->table_name, $data);

            //取得resource_id吧
            $this->resource_id = $this->db->insert_id();

            $data = array(
                'webpage_id' => $this->get_id(),
                'domain_id' => $domain->get_id()
            );
            $db->where($data);
            if ($db->count_all_results('domain2webpage') == 0)
            {
                $db->insert('domain2webpage', $data);
            }
            log_info('Webpage Create: ('.$this->get_id().') '.$this->get_uri().' '.$this->get_title());
        }
        return TRUE;
    }

    function delete()
    {
        parent::delete();

        $db = $this->db;
        $where = array('webpage_id' => $this->get_id());

        $allow_delete = TRUE;
        $db->where($where);
        if ($db->count_all_results('webpage2langvar') > 0)
                $allow_delete = FALSE;
        else
        {
            $db->where($where);
            if ($db->count_all_results('webpage2annotation') > 0)
            {
                $allow_delete = FALSE;
            }
        }

        if ($allow_delete === TRUE)
        {
            $db->delete('domain2webpage', $where);
            $db->delete('webpage2langvar', $where);

            $db->delete($this->table_name, $where);

            $this->resource_id = NULL;
            $this->uri = NULL;
            $this->title = NULL;
            $this->parent_domain = NULL;
            unset_cache($this);
            return TRUE;
        }
        else
        {
            handle_error($this->lang->line('webpage_delete_failed'));
            return FALSE;
        }
    }

    function set_uri($uri)
    {
        $this->uri = $uri;
    }

    function get_uri()
    {
        return $this->uri;
    }

    function set_url($url)
    {
        $this->CI->load->library('kals_resource/Domain');
        $domain = $this->CI->domain->create($url);
        $this->set_domain($domain);

        $uri = parse_uri($url);
        $this->set_uri($uri);
    }

    function get_url()
    {
        $domain = $this->get_domain();
        if ($domain == NULL)
            return NULL;
        $host = $domain->get_host();

        $uri = $this->get_uri();
        $url = combine_url($host, $uri);
        return $url;
    }

    function set_title($title)
    {
        $this->title = $title;
    }

    function get_title($force_update = FALSE)
    {
        if ($force_update === TRUE
            OR $this->title == NULL)
        {
            $this->update_title();
        }
        return $this->title;
    }

    function update_title()
    {
        $title = $this->_retrieve_title();
        if ($title != NULL)
            $this->title = $title;
    }

    function _retrieve_title()
    {
        return retrieve_title($this->get_url());
    }

    function set_domain($domain)
    {
        $this->parent_domain = $domain;
    }

    function get_domain()
    {
        if ($this->parent_domain == NULL)
        {
            $db = $this->db;

            $db->from('domain2webpage');
            $db->where('webpage_id', $this->get_id());
            $db->select('domain_id');
            $query = $db->get();

            if ($query->num_rows() > 0)
            {
                $row = $query->row();
                $domain_id = (int) $row->domain_id;

                $this->CI->load->library('kals_resource/Domain');
                $this->parent_domain = $this->CI->domain->find('domain_id', $domain_id);
            }
        }
        return $this->parent_domain;
    }

    // @todo 下面才是處理Annotation的部份
}


/* End of file Webpage.php */
/* Location: ./system/application/libraries/.../Webpage.php */