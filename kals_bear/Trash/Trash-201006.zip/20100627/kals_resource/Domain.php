<?php
/**
 * domain
 *
 * domain full description.
 * 
 * @package		KALS
 * @category		Models
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/6/19 下午 12:11:24
 */
include_once 'KALSResource.php';

class Domain extends KALSResource {

    var $lib_path = 'kals_resource/Domain';
    var $table_name = 'domain';

    var $resource_id;
    var $resource_type_id = 1;
    var $host;
    var $title;

    /**
     * 用來find並回傳結果的內部屬性
     * @var Domain
     */
    var $domain;

    function Domain()
    {
        parent::KALSResource();
    }

    function create($url = NULL)
    {
        if ($url == NULL)
            return NULL;

        $d = $this->find('url', $url);

        if ($d != NULL)
            return $d;

        $this->CI->load->library($this->lib_path);
        $domain = new Domain();
        $host = parse_host($url);
        $domain->set_host($host);
        $domain->update();
        set_cache($domain, 'host', $domain->get_host());
        return $domain;
    }

    /**
     * @return Domain
     */
    function find($key, $value = NULL)
    {
        if (is_array($key) && $value == NULL)
        {
            $cond = $key;
            $key = get_cond_key($cond);
            $value = get_cond_value($cond);
        }

        if (($key == 'id' || $key == 'domain_id')
                && $value != NULL)
            $value = (int) $value;

        if ($key == NULL && $value == NULL)
            return NULL;

        if ($value != NULL)
        {
            $domain = get_cache($this, $key, $value);
            if ($domain != NULL)
                return $domain;
        }

        $db = $this->db;
        $db->from($this->table_name);

        if ($key == 'id' OR $key == 'domain_id')
        {
            $where = array('domain_id' => $value);
        }
        else if ($key == 'host' OR $key == 'url')
        {
            $value = parse_host($value);
            $where = array('host' => $value);
        }
        else
            return NULL;

        $db->where($where);
        $db->limit(1);
        $count = $db->count_all_results();
        if ($count == 0)
            return NULL;

        $db->select('domain_id, host, title');
        $db->from($this->table_name);
        $db->where($where);
        $db->limit(1);
        $query = $db->get();
        $row = $query->row();

        $this->CI->load->library($this->lib_path);
        $domain = new Domain();
        $domain->setup($row);

        set_cache($domain, $key, $value);
        return $domain;
    }

    function find_all()
    {
        $this->db->from($this->table_name);
        $this->db->order('host');
        $query = $this->db->get();

        $domains = array();
        foreach ($query->result() AS $row)
        {
            $resource_id = $row->domain_id;
            $domain = get_cache($this, 'domain_id', $resource_id);
            if ($domain == NULL)
            {
                $this->CI->load->library($this->lib_path);
                $domain = new Domain();
                $domain->setup($row);

                set_cache($domain, 'domain_id', $domain->get_id());
            }
            array_push($domains, $domain);
        }
        return $domains;
    }

    /**
     * 設定Domain資料
     * @param <type> $row是Active Record中$query的結果
     * @return Domain 
     */
    function setup($row)
    {
        if (isset($row->domain_id))
            $this->resource_id = $row->domain_id;
        if (isset($row->host))
            $this->set_host($row->host);
        if (isset($row->title))
            $this->set_title($row->title);
        return $this;
    }

    function update()
    {
        //如果存在資料了
        $existed = FALSE;
        if ($this->resource_id != NULL)
        {
            $this->db->where('domain_id', $this->resource_id);
            $this->db->from($this->table_name);
            if ($this->db->count_all_results() > 0)
                $existed = TRUE;
        }

        if ($existed === TRUE)
        {
            $data = array(
                'domain_id' => $this->resource_id,
                'host' => $this->get_host(),
                'title' => $this->get_title()
            );
            $this->db->where('domain_id', $this->resource_id);
            $this->db->from($this->table_name);
            $this->db->update($this->table_name, $data);
        }
        else
        {
            $data = array(
                'host' => $this->get_host(),
                'title' => $this->get_title()
            );
            $this->db->from($this->table_name);
            $this->db->insert($this->table_name, $data);

            //取得resource_id吧
            $this->resource_id = $this->db->insert_id();
        }
        return TRUE;
    }

    function delete()
    {
        parent::delete();

        $db = $this->db;

        $db->where('domain_id', $this->get_id());
        if ($db->count_all_results('domain2webpage') > 0)
        {
            handle_error($this->lang->line('domain_delete_failed'));
            return FALSE;
        }

        // @todo 檢查domain2user domain2group

        $this->db->where('domain_id', $this->get_id());
        //$this->db->limit(1);
        $this->db->delete($this->table_name);

        $this->resource_id = NULL;
        $this->host = NULL;
        $this->title = NULL;
        unset_cache($this);
        return TRUE;
    }

    function set_host($host)
    {
        $host = parse_host($host);
        $this->host = $host;
    }

    function get_host()
    {
        return $this->host;
    }

    function set_title($title)
    {
        $this->title = $title;
    }

    /**
     * @param boolean $force_update 預設會將title存入資料庫中，如果要強迫更新，則可用get_title(true)的方式來強迫置換title
     */
    function get_title($force_update = FALSE)
    {
        if ($force_update === TRUE OR
            ($this->title == NULL && $this->host != NULL))
        {
            $this->update_title();
        }
        return $this->title;
    }

    function update_title()
    {
        $title = $this->_retrieve_title();
        if ($title != NULL)
            $this->title = $title;
    }

    function _retrieve_title()
    {
        $host = $this->get_host();
        if ($host == NULL)
            return NULL;

        return retrieve_title($host);
    }

    function get_webpages()
    {
        $webpages = array();
        if ($this->resource_id == NULL)
            return $webpages;

        $this->db->from('domain2webpage');
        $this->db->join('webpage','domain2webpage.webpage_id = webpage.webpage_id');
        $this->db->where('domain_id', $this->resource_id);

        $query = $this->db->get();
        foreach ($query->result() AS $row)
        {
            $this->CI->load->library('kals_resource/Webpage', 'webpage');
            $this->CI->webpage->setup($row);
            array_push($webpages, $this->CI->webpage);
        }
        return $webpages;
    }

    static public function convert_field(String &$field, &$value)
    {
        if ($field == 'url' || $field == 'host')
        {
            $field = 'domain';
            $value = $this->find('url', $value);
        }
    }

    static public function convert_cond(Array $cond)
    {
        if (TRUE === isset($cond['url']))
        {
            $url = $cond['url'];
        }
        else if (TRUE === isset($cond['host']))
        {
            $url = $cond['host'];
        }
        else
        {
            return $cond;
        }

        $cond['domain'] = $this->find('url', $url);
        return $cond;
    }
}

/* End of file domain.php */
/* Location: ./system/application/models/domain.php */