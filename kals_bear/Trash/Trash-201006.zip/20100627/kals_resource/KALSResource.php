<?php
/**
 * kalsresource
 *
 * kalsresource full description.
 * 
 * @package		KALS
 * @category		Library
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/6/19 下午 12:03:05
 */

class KALSResource {

    var $lib_path = 'kals_resource/KALSResource';
    var $lang;

    var $resource_id;
    var $resource_type_id;

    function KALSResource()
    {
        setup_kals_object(&$this);
        log_set_class($this);
       
        $this->CI->lang->load('kals');
        $this->lang = $this->CI->lang;
    }

    function get_id()
    {
        $id = $this->resource_id;
        if ($id != NULL)
            $id = (int) $id;
        return $id;
    }

    function get_type_id()
    {
        return (int) $this->resource_type_id;
    }

    /**
     * @return KALSResource
     */
    function find($id, $type_id)
    {
        $class = NULL;
        if ($type_id == 1)
        {
            $this->CI->load->library('kals_resource/Domain');
            $class = new Domain();
        }
        else if ($type_id == 2)
        {
            $this->CI->load->library('kals_resource/Webpage');
            $class = new Webpage();
        }
        else if ($type_id == 3)
        {
            $this->CI->load->library('kals_resource/Annotation');
            $class = new Annotation();
        }
        else
            return NULL;
        $resource = $class->find(array('id'=>$id));
        return $resource;
    }

    function delete()
    {
        // @todo 檢查policy
    }
}

/* End of file kalsresource.php */
/* Location: ./system/application/library/kals_resource/KALSResource.php */