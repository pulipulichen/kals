<?php
/**
 * object_helper
 *
 * object_helper full description.
 *
 * @package		KALS
 * @category		Helpers
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/6/21 下午 10:08:12
 */

if ( ! function_exists('setup_kals_object'))
{
    function setup_kals_object(&$object, $setup_db = TRUE)
    {
        if (isset($object->CI) === FALSE)
        {
            $object->CI =& get_instance();
            
            $object->CI->load->helper('kals');
            $object->CI->load->helper('context');    
        }
        if (isset($object->CI->db) === FALSE
               && $setup_db === TRUE)
        {
            //echo '讀取database'.get_class($object);
            $object->CI->load->database();
        }
        if (isset($object->db) === FALSE
               && $setup_db === TRUE)
        {
            $object->db = $object->CI->db;
        }
    }
}

if ( ! function_exists('check_row_exist'))
{
    function check_row_exist($db, $table_name, $cond)
    {
        $value = get_cond_value($cond);
        if ($value == NULL)
            return FALSE;

        $db->where($cond);
        if ($db->count_all_results($table_name) > 0)
            return TRUE;
        else
            return FALSE;
    }
}



/* End of file object_helper.php */
/* Location: ./system/application/helpers/object_helper.php */