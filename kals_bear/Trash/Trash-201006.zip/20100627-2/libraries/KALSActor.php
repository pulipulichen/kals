<?php
/**
 * KALSActor
 *
 * KALSActor full description.
 *
 * @package		KALS
 * @category		Library
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/6/27 下午 03:16:29
 * @property Domain $domain
 */
abstract class KALSActor extends Generic_object {

    private $domain;

    private $types = array(
        1 => 'User',
        2 => 'Group'
    );

    public function __constructor($id = NULL)
    {
        parent::__construct($id);
        $this->CI->load->library('kals_resource/Domain');
    }

    abstract public function get_type_id();

    private function _get_asso()
    {
        return $this->_create_asso(array('Domain'));
    }

    /**
     * @return KALSActor 
     */
    public function find(int $id, $type_id = 1)
    {
        $this->CI->load('kals_actor/'.$this->types[$type_id], $id, 'actor');
        return $this->CI->actor;
    }

    public function set_field(String $field, $value)
    {
        Domain::convert_field($field, $value);

        if ($field == 'domain')
        {
            $this->domain = $value;
        }
        else
        {
            parent::set_field ($field, $value);
        }
    }

    public function get_field(String $field)
    {
        if ($field != 'domain')
        {
            return parent::get_field($field);
        }
        else
        {
            
        }
    }

    public function  save() {
        if ($this->domain == NULL)
        {
            handle_error($this->lang->line('actor.save.miss_domain.exception'));
        }

        parent::save();
        
        $data = array(
            'domain_id' => $this->domain->get_id(),
            $this->table_name.'_id' => $this->get_id()
        );
        $this->db->update('domain2'.$this->table_name, $data);
    }

    public function destroy()
    {
        parent::destory(array('domain2'.$this->table_name));
    }
}


/* End of file KALSActor.php */
/* Location: ./system/application/libraries/.../KALSActor.php */