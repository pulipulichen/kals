/**
 * Selection_manager
 *
 * @package		KALS
 * @category		Webpage Application Libraries
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/8/5 下午 01:45:46
 * @constructor Selection_manager()
 * @requires jQuery
 * @requires Other_class
 */

/**
 * @class Selection_manager
 * @constructor Selection_manager
 * @extends {Multi_event_dispatcher}
 * @requires {Modal_factory}
 */
function Selection_manager(_config) {
    this.selectable_element = null;
    this.selectable_selector = null;
    this.selected_scope = [];
    //this.on_initialize_complete = [];
    //this.on_cancel_select = [];
    //this.event_name = 'onselect';
    
    this.paragraph_count = 0;
    this.word_count = 0;
    this.selected_start = null;
    this.select_tooltip = null;
    this.locks = [];
    
    // ---------
    // 初始化
    // ---------
    var _callback = $.get_parameter(_config, 'on_initialize_complete');
    //this.add_initialize_complete(_callback);
    this.add_listener('initialize_complete', _callback);
    
    var _selector = $.get_parameter(_config, 'selector');
    if ($.isset(_selector))
    {
        this.set_selectable_element(_selector);
    }
    
    var _init = $.get_parameter(_config, 'initialize', false);
    if (_init == true)
    {
        this.initialize();
    }
    
    return this;
}

/**
 * 繼承
 * @memberOf {Selection_manager}
 */
Selection_manager.prototype = new Multi_event_dispatcher();
//Selection_manager.prototype.event_name = 'onselect';

/**
 * Selection_manager管理的範圍
 * @type {jQuery}
 */
Selection_manager.prototype.selectable_element = null;

/**
 * 設定可選取範圍
 * @param {String|jQuery} _selector
 */
Selection_manager.prototype.set_selectable_element = function(_selector) {  
    var _element = null;
    if ($.is_string(_selector)) {
        _element = $(_selector);
    }
    else if ($.is_jquery(_selector)) {
        _element = _selector;           
    }
    else {
        //如果_selector不是字串也不是jQuery物件，則丟出例外錯誤
        var _message = 'selector error:' + _selector; 
        throw KALS_exception(this, _message);
    }
    
    if (_element.exists() == false)
    {
        throw KALS_exception(this, 'no element:' + _selector);
    }
    else
    {
        _element.css('word-break', 'break-all');
        
        this.selectable_element = _element;
        return this;
    }
};

/*
Selection_manager.prototype.add_select_listener = function (_type, _obj, _function, _trigger)
{
    if (_type == 'select')
    {
        this.add_listener(_obj, _function, _trigger);
    }
    else 
    {
        if ($.is_function(_obj) == false)
            return this;
        else if (_type == 'initialize_complete')
            this.on_initialize_complete.push(_obj);
        else if (_type == 'cancel_select')
            this.on_cancel_select.push(_obj);
    }
};
*/

/**
 * 將可選取範圍初始化
 * @memberOf {Selection_manager}
 * @param {Object} _selector
 */
Selection_manager.prototype.initialize = function () {
    
    var _element = this.selectable_element;
    if ($.is_null(_element))
    {
        throw KALS_exception(this, 'No selectable element');
    }
    
    // ---------
    // 建立按鈕
    // ---------
    
    //var _select_trigger = $.create_once('<button class="kals-select-trigger" id="kals_select_trigger">SELECT</button>');
    this.create_select_tooltip();
    
    // ---------
    // 開始作初始化
    // ---------
    var _this = this;
    this.setup_selectable_element(_element, function () 
    {
        // ---------
        // 完成後的動作
        // ---------
        /*
        for (var _i in _this.on_initialize_complete)
        {
            var _event = _this.on_initialize_complete[_i];
            if ($.is_function(_event))
            {   
                _event(_this);
            }
        }
        */
        _this.notify_listeners('initialize_complete');    
    });    //this.setup_selectable_element(_element, function ()    
    
    return this; 
};

Selection_manager.prototype.paragraph_count = 0;
Selection_manager.prototype.word_count = 0;

Selection_manager.prototype.setup_selectable_element = function (_element, _callback) {
    /**
     * @type {Array}
     */
    var _child_nodes = _element.attr('childNodes');
    if (typeof(_child_nodes) == 'undefined')
    {
        if ($.is_function(_callback))
            _callback();
        return this;
    }
    
    var _para_class_name = KALS_CONFIG.selection_manager.paragraph_class_name;
    var _para_tag_names = KALS_CONFIG.selection_manager.paragraph_tag_names;
    var _this = this;
    
    var _loop = function (_i, _child_nodes, _cb)
	{
        //停止迴圈的判定
        if (_i == _child_nodes.length || _i > _child_nodes.length)
        {
            if ($.is_function(_cb))
                _cb();
            return;
        }
        
        /**
         * @type {jQuery}
         */
		var _child_obj = _child_nodes.item(_i);
        if (_this.element_has_class(_child_obj, _para_class_name)) 
        {
            _i++;
            _loop(_i, _child_nodes, _cb);
            return;
        }
		
		if (_child_obj.nodeName != '#text' &&
            _this.element_has_class(_child_obj, _para_class_name) == false)
        {
            _this.setup_selectable_element($(_child_obj), function () 
            {
                var _node_name = _child_obj.nodeName;
                if (typeof(_node_name) == 'string' &&
                $.inArray(_node_name.toLowerCase(), _para_tag_names) != -1) 
                    _this.paragraph_count++;
                    
                setTimeout(function () 
                {
                    _i++;
                    _loop(_i, _child_nodes, _cb);
                    return;
                }, 100);
            });
            return;
        }
        else
        {
            var _text = _this.get_element_content(_child_obj);
            
            if (_text == "")
            {
                _i++;
                _loop(_i, _child_nodes, _cb);
                return;
            }
    		
    		var _next_element = null;
            
            _next_element = _this.create_selectable_paragraph(_this.paragraph_count);
            _child_obj.parentNode.insertBefore(_next_element, _child_obj);
            $(_child_obj).remove();
            
    		for (var _s = 0; _s < _text.length; _s++)
    		{
    			var _t = _text.substr(_s, 1);
                
    			if ($.match_english(_t) == true)
    			{
    				var _t_next = _text.substr(parseInt(_s)+1, 1);
    				while ($.match_english(_t_next) == true)
    				{
    					_t = _t + _t_next;
    					_s++;
    					_t_next = _text.substr(parseInt(_s)+1, 1);
    				}
    			}
    			else if ($.match_number(_t) == true)
    			{
    				var _t_next = _text.substr(parseInt(_s)+1, 1);
    				while ($.match_number(_t_next) == true)
    				{
    					_t = _t + _t_next;
    					_s++;
    					_t_next = _text.substr(parseInt(_s)+1, 1);
    				}
    			}
                
                var _t_element = null;
                
    			if ($.match_space(_t) == false) {
                    _t_element = _this.create_selectable_word(_this.paragraph_count, _this.word_count, _t);
                    if ($.match_punctuation(_t))
                        $(_t_element).addClass(KALS_CONFIG.selection_manager.paragraph_class_name);
                    _this.word_count++;
                }
                else 
                {
                    _t_element = _this.create_span_word(_t);
                }
    			_next_element.appendChild(_t_element);
    		}    //for (var _s = 0; _s < _text.length; _s++)
    		
            setTimeout(function () 
            {
                _i++;
                _loop(_i, _child_nodes, _cb);
                return;
            }, 100);
        }    //else if (_child_obj.nodeName != '#text' &&
	}    //var _loop = function (_i, _child_nodes, _callback)
	
    setTimeout(function () 
    {
        _loop(0, _child_nodes, _callback);
    }, 100);
    return this;
};

/**
 * 建立一個可以選取Word的容器
 * @param {number} _id
 */
Selection_manager.prototype.create_selectable_paragraph = function (_id) {
    var _ele = document.createElement('span');
	_ele.className = KALS_CONFIG.selection_manager.paragraph_class_name 
        + ' ' + KALS_CONFIG.selection_manager.paragraph_id_prefix + _id;
    return _ele;
};

Selection_manager.prototype.selected_from = null;
Selection_manager.prototype.listen_select = function (_word) 
{
    if (this.selected_from == null)
    {
        this.cancel_select();
        this.selected_from = _word;
        _word.addClass('selected');
    }
    else
    {
        //在做add_select的時候，就會進行通知
        this.add_select({
            from: this.selected_from,
            to: _word
        });
        this.selected_from = null;
        var _scope = this.get_scope();
    }
    return this;
};

Selection_manager.prototype.get_word_id = function (_word)

{
    if ($.is_object(_word))
    {
        if ($.is_jquery(_word))
            _word = _word.attr('id');
        else
            _word = _word.id;
    }
       
    var _id_prefix = KALS_CONFIG.selection_manager.word_id_prefix;
    if ($.starts_with(_word, _id_prefix))
    {
        _word = _word.substring(_id_prefix.length, _word.length);
    }
    return parseInt(_word);
};

Selection_manager.prototype.tooltip_config = null
Selection_manager.prototype.get_tooltip_config = function () {
    if (this.tooltip_config == null)
    {
        var _config = {
            tip: '#' + KALS_CONFIG.selection_manager.select_tooltip.id,
            onBeforeShow: function (_this)
            {
                if ($.is_null(_this))
                    _this = this;
                
                var _tip = _this.getTip();
                var _trigger = _this.getTrigger();
                //設定調整            
                var _id = $.get_prefixed_id(_trigger);
                _tip.attr('word_id', _id);
            }
        };
        this.tooltip_config = Modal_factory.get_tooltip_config(_config);
    }
    return this.tooltip_config;
};

/**
 * 建立一個可選取的文字
 * @param {number} _para_id
 * @param {number} _point_id
 * @param {string} _text
 * @type {jQuery}
 */
Selection_manager.prototype.create_selectable_word = function(_para_id, _point_id, _text)
{
	var _word = document.createElement("span");

	_word.className = KALS_CONFIG.selection_manager.word_class_name
        + ' ' + KALS_CONFIG.tooltip.trigger_class_name;
	var _word_id = KALS_CONFIG.selection_manager.word_id_prefix + _point_id; 
	_word.id = _word_id;
    
	var _t_text = document.createTextNode(_text);
	_word.appendChild(_t_text);
    
    var _this = this;
    var _tooltip_config = this.get_tooltip_config();
    
    $(_word).tooltip(_tooltip_config);
    
    if (typeof(this.locks['word_click']) == 'undefined')
    {
        if ($.is_mobile_mode() == false)
        {
            //$(_word).click(function () {
            $('.'+ KALS_CONFIG.selection_manager.word_class_name).live('click', function() {
                var _word = $(this);
                setTimeout(function () {
                    _word.tooltip().hide();
                }, 100);
                _this.listen_select(_word);
            });
        }
        this.locks['word_click'] = true;
    }
    
	return _word;
};

Selection_manager.prototype.locks = [];

Selection_manager.prototype.select_tooltip = null;
Selection_manager.prototype.create_select_tooltip = function () 
{    
    if (this.select_tooltip == null)
    {
        var _tooltip_id = KALS_CONFIG.selection_manager.select_tooltip.id;
        var _container_class_name = KALS_CONFIG.selection_manager.select_tooltip.container_class_name;
        var _button_class_name = KALS_CONFIG.selection_manager.select_tooltip.button_class_name;
        
        var _button = $('<button class="' + _button_class_name + '">SELECT</button>');
        var _select_tooltip = Modal_factory.get_tooltip({
            id: _tooltip_id,
            content: _button
        });
        
        if ($.object_isset('KALS_context.add_listener'))
        {
            KALS_context.add_listener('language', _button, 'selection_manager.select_tooltip');
        }
        
        _select_tooltip.addClass(_container_class_name);
        
        var _this = this;
        var _word_id_prefix = KALS_CONFIG.selection_manager.word_id_prefix;
        
        var _select_event = function (_event)
        {
            _event.preventDefault();
            
            var _word_id = $(this).attr('word_id');
            var _word = $('#' + _word_id_prefix + _word_id );
            _word.tooltip().hide();
            _this.listen_select(_word);
        };
        _select_tooltip.click(_select_event);
        this.select_tooltip = _select_tooltip;
    }
    return this.select_tooltip;
};

/**
 * 建立一個不可選取的文字
 * @param {String} _text
 * @type {jQuery}
 */
Selection_manager.prototype.create_span_word = function(_text)
{
	var _word = document.createElement("span");
	
	var _t_text = document.createTextNode(_text);
	_word.appendChild(_t_text);

	return _word;
};

/**
 * 檢查HTML元素是否有_class_name
 * @param {Object} _element
 * @param {String} _class_name
 * @type {boolean}
 */
Selection_manager.prototype.element_has_class = function (_element, _class_name)
{
    if ($.is_object(_element) == false
        || typeof(_element.className) == 'undefined')
        return false;
    else
    {
        var _class_names = _element.className.split(' ');
        return ($.inArray(_class_name, _class_names) > -1);
    }
};

Selection_manager.prototype.get_element_content = function (_element) {
    if ($.is_object(_element) == false)
        return '';
    //else if (typeof(_element.textContent) != 'undefined'
    //    && $.trim(_element.textContent) != '')
    //    return $.trim(_element.textContent);
    else if (typeof(_element.nodeValue) != 'undefined'
        && $.trim(_element.nodeValue) != '')
        return $.trim(_element.nodeValue);
    else
        return '';
};

/**
 * 目前已經被選取的範圍，注意，資料型態不是JSON，而是被選取的jQuery元素
 * @type {jQuery}
 */
Selection_manager.prototype.selected_scope = [];

/**
 * 將目前選取的範圍轉換成scope陣列回傳
 */
Selection_manager.prototype.get_scope = function () {
    var _scope = [];
    
    for (var _key in this.selected_scope)
    {
        var _s = this.selected_scope[_key];
        
        var _from = _s[0];
        var _to = _s[(_s.length-1)];
        
        var _from_id = $.get_prefixed_id(_from);
        var _to_id = $.get_prefixed_id(_to);
        
        _scope.push([_from_id, _to_id]);
    }
    
    return _scope;
};

/**
 * 完成初始化之後的回呼函數
 * @type {Function}
 */
//Selection_manager.prototype.on_initialize_complete = [];


/**
 * 設定初始化完成之後的回呼函數
 * @param {Object} _callback
 */
/*
Selection_manager.prototype.add_initialize_complete = function (_callback)
{
    if ($.is_function(_callback))
        this.on_initialize_complete.push(_callback);
    return this;
};
*/
/*
Selection_manager.prototype.notify_select_listensr = function () {
    
    return this;
};
*/

/**
 * 忘記這個是幹嘛用的了
 */
Selection_manager.prototype.expand_selection = function () {
    return this;
};

/**
 * 選擇指定範圍
 * @param {Object} _scope 範圍
 */
Selection_manager.prototype.select = function (_scope) {
    this.cancel_select();
    this.add_select(_scope);
    return this;
};

/**
 * 增加選擇範圍
 * @param {Object} _scope 範圍。example: {
 *     from: 0,
 *     to: 12
 * }
 */
Selection_manager.prototype.add_select = function (_scope)
{
    var _from, _to, _from_id, _to_id;
    if ($.is_array(_scope) && _scope.length > 0)
    {
        _from = _scope[0];
        if (_scope.length > 1)
            _to = _scope[1];
        else
            _to = _from;
    }
    else if ($.is_object(_scope))
    {
        _from = $.get_parameter(_scope, 'from');
        _to = $.get_parameter(_scope, 'to');
    }
    
    var _id_prefix = KALS_CONFIG.selection_manager.word_id_prefix;
    
    if ($.is_object(_from))
        _from_id = $.get_prefixed_id(_from);
    else
    {
        _from_id = parseInt(_from);
        _from = $('#' + _id_prefix + _from_id );
    }
    
    if ($.is_object(_to))
        _to_id = $.get_prefixed_id(_to);
    else
    {
        _to_id = parseInt(_to);
        _to = $('#' + _id_prefix + _to_id );
    }
    
    if (_to_id < _from_id)
    {
        var _temp = _from;
        var _temp_id = _from_id;
        _from = _to;
        _from_id = _to_id;
        _to = _temp;
        _to_id = _temp_id;
    }
    
    _from.addClass('from').addClass('selected');
    _to.addClass('to').addClass('selected');
    
    var _scope = [];
    _scope.push(_from);
    for (var _i = _from_id+1; _i < _to_id; _i++)
    {
        var _middle = $('#' + _id_prefix + _i).addClass('selected').addClass('middle');
        _scope.push(_middle);
    }
    if (_to_id != _from_id)
        _scope.push(_to);
    
    this.selected_scope.push(_scope);
    
    //this.notify_listeners();
    this.notify_listeners('select');
    
    return this;
}

/**
 * 看看是否有選取範圍
 * @type {boolean} 
 */
Selection_manager.prototype.has_selected = function () {
    return (this.selected_scope.length > 0);
};

/**
 * 設定該選取範圍為此標註類型
 * @param {number} _type 標註類型ID
 */
Selection_manager.prototype.set_annotation_type = function (_type)
{
    //有哪些標註的class_name，尚未訂定
    var _anno_class_name = _type;
    this.add_class(_anno_class_name);
    
    return this;
};

Selection_manager.prototype.unset_annotation_type = function (_type)
{
    //有哪些標註的class_name，尚未訂定
    var _anno_class_name = _type;
    this.remove_class(_anno_class_name);
    
    return this;
};

/**
 * 設定該選取範圍為推薦
 */
Selection_manager.prototype.set_recommend = function () {
    
    //有哪些推薦標註的class_name，尚未訂定
    var _recommend_class_name = 'recommend';
    this.add_class(_recommend_class_name);
    
    return this;
};

Selection_manager.prototype.unset_recommend = function () {
    
    //有哪些推薦標註的class_name，尚未訂定
    var _recommend_class_name = 'recommend';
    this.remove_class(_recommend_class_name);
        
    return this;
};

/**
 * 增加_class_name
 * @param {String} _class_name
 */
Selection_manager.prototype.add_class = function (_class_name) 
{
    
    for (var _i in this.selected_scope)
    {
        var _scope = this.selected_scope[_i];
        if ($.is_array(_scope))
        {
            for (var _j in _scope)
            {
                var _word = _scope[_j];
                if ($.is_jquery(_word))
                {
                    _word.addClass(_class_name);
                }
            }
        }
        else if ($.is_jquery(_scope))
        {
            _scope.addClass(_class_name);
        }
    }
    return this;
};

/**
 * 移除_class_name
 * @param {String} _class_name
 */
Selection_manager.prototype.remove_class = function (_class_name) 
{
    
    for (var _i in this.selected_scope)
    {
        var _scope = this.selected_scope[_i];
        if ($.is_array(_scope))
        {
            for (var _j in _scope)
            {
                var _word = _scope[_j];
                if ($.is_jquery(_word))
                {
                    _word.removeClass(_class_name);
                }
            }
        }
        else if ($.is_jquery(_scope))
        {
            _scope.removeClass(_class_name);
        }
    }
    return this;
};

Selection_manager.prototype.on_cancel_select = [];

/**
 * 取消選取
 */
Selection_manager.prototype.cancel_select = function () {
    
    /*
    for (var _i in this.on_cancel_select)
    {
        var _event = this.on_cancel_select[_i];
        if ($.is_function(_event))
            _event(this);
    }
    */
    this.notify_listeners('cancel_select');
    
    //還要清理Selectable_element的樣式
    $('.selected.from').removeClass('from');
    $('.selected.to').removeClass('to');
    $('.selected.middle').removeClass('middle');
    $('.selected').removeClass('selected');
    this.selected_scope = [];
    return this;
};

/**
 * 清理標註範圍標示
 */
Selection_manager.prototype.clear_annotation = function () {
    
    //有哪些標註的class_name，尚未訂定
    var _anno_class_names = [];
    
    for (var _i in _anno_class_names)
    {
        var _class_name = _anno_class_names[_i];
        $('.' + _class_name).removeClass(_class_name);
    }
    return this;
    
};

/**
 * 清理推薦範圍標示
 */
Selection_manager.prototype.clear_recommend = function () {
    
    //有哪些推薦標註的class_name，尚未訂定
    var _recommend_class_names = [];
    
    for (var _i in _recommend_class_names)
    {
        var _class_name = _recommend_class_names[_i];
        $('.' + _class_name).removeClass(_class_name);
    }
    return this;
    
};

/* End of file Selection_manager */
/* Location: ./system/application/views/web_apps/kals_text/Selection_manager.js */