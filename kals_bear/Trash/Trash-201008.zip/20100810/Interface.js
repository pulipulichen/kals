/**
 * 
 * Interface
 *
 * @package		KALS
 * @category		Webpage Application Libraries
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/7/28 下午 03:55:07
 */

INTERFACES = {
};

/* End of file Interface */
/* Location: ./system/application/views/web_apps/Interface.js */