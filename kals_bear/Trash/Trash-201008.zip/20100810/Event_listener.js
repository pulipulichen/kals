/**
 * Event_listener
 *
 * 觀察者模式當中的傾聽者 Interface
 *
 * @package		KALS
 * @category		Webpage Application Libraries
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/7/28 下午 03:55:07
 */

if (typeof(INTERFACES) == 'undefined')
    INTERFACES = {};
INTERFACES.Event_listener = {
    update: function (_event_dispatcher, _arg) {}
};

/* End of file Observer */
/* Location: ./system/application/views/web_apps/Event_listener.js */