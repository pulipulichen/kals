<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-07-10 04:32:15 --> Unable to load the requested class: generic_attribute_collection
ERROR - 2010-07-10 05:11:29 --> Severity: Warning  --> include_once(Annotation_feature) [<a href='function.include-once'>function.include-once</a>]: failed to open stream: No such file or directory D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Annotation_feature_location.php 2
ERROR - 2010-07-10 05:11:29 --> Severity: Warning  --> include_once() [<a href='function.include'>function.include</a>]: Failed opening 'Annotation_feature' for inclusion (include_path='.;D:\xampp\php\pear\') D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Annotation_feature_location.php 2
ERROR - 2010-07-10 05:13:24 --> Severity: 4096  --> Argument 1 passed to Annotation_feature_collection::add_item() must be an instance of Generic_attribute_object, null given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Annotation_feature_collection.php on line 89 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Annotation_feature_collection.php 76
ERROR - 2010-07-10 05:38:23 --> Severity: 4096  --> Argument 1 passed to Annotation_feature_collection::add_item() must be an instance of Generic_attribute_object, null given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Annotation_feature_collection.php on line 89 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Annotation_feature_collection.php 76
ERROR - 2010-07-10 05:39:16 --> Severity: 4096  --> Argument 1 passed to Annotation_feature_collection::add_item() must be an instance of Generic_attribute_object, null given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Annotation_feature_collection.php on line 90 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Annotation_feature_collection.php 77
ERROR - 2010-07-10 05:40:24 --> Severity: 4096  --> Argument 1 passed to Annotation_feature_collection::add_item() must be an instance of Generic_attribute_object, null given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Annotation_feature_collection.php on line 91 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Annotation_feature_collection.php 77
ERROR - 2010-07-10 05:51:23 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  operator does not exist: text = integer
LINE 5: AND &quot;value&quot; = 2
                    ^
HINT:  No operator matches the given name and argument type(s). You might need to add explicit type casts. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 05:51:23 --> Query error: ERROR:  operator does not exist: text = integer
LINE 5: AND "value" = 2
                    ^
HINT:  No operator matches the given name and argument type(s). You might need to add explicit type casts.
ERROR - 2010-07-10 05:51:23 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:386) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-10 05:57:07 --> Severity: Notice  --> Undefined variable: data D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Annotation_feature_collection.php 50
ERROR - 2010-07-10 06:21:40 --> Severity: Warning  --> include_once(Annotation_feature_location.php) [<a href='function.include-once'>function.include-once</a>]: failed to open stream: No such file or directory D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_attribute_collection.php 95
ERROR - 2010-07-10 06:21:40 --> Severity: Warning  --> include_once() [<a href='function.include'>function.include</a>]: Failed opening 'Annotation_feature_location.php' for inclusion (include_path='.;D:\xampp\php\pear\') D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_attribute_collection.php 95
ERROR - 2010-07-10 06:37:21 --> Severity: Notice  --> Undefined variable: new_id_array D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_association_collection.php 160
ERROR - 2010-07-10 06:37:21 --> Severity: Warning  --> array_unique() [<a href='function.array-unique'>function.array-unique</a>]: The argument should be an array D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_association_collection.php 160
ERROR - 2010-07-10 06:37:21 --> Severity: Notice  --> Undefined variable: new_id_array D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_association_collection.php 175
ERROR - 2010-07-10 06:37:21 --> Severity: Notice  --> Undefined variable: new_id_array D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_association_collection.php 183
ERROR - 2010-07-10 06:37:21 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 433
ERROR - 2010-07-10 06:37:21 --> Severity: Notice  --> Undefined variable: new_id_array D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_association_collection.php 160
ERROR - 2010-07-10 06:37:21 --> Severity: Warning  --> array_unique() [<a href='function.array-unique'>function.array-unique</a>]: The argument should be an array D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_association_collection.php 160
ERROR - 2010-07-10 06:37:21 --> Severity: Notice  --> Undefined variable: new_id_array D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_association_collection.php 175
ERROR - 2010-07-10 06:37:21 --> Severity: Notice  --> Undefined variable: new_id_array D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_association_collection.php 183
ERROR - 2010-07-10 06:37:21 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 433
ERROR - 2010-07-10 06:37:21 --> Severity: Notice  --> Undefined variable: new_id_array D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_association_collection.php 160
ERROR - 2010-07-10 06:37:21 --> Severity: Warning  --> array_unique() [<a href='function.array-unique'>function.array-unique</a>]: The argument should be an array D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_association_collection.php 160
ERROR - 2010-07-10 06:37:21 --> Severity: Notice  --> Undefined variable: new_id_array D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_association_collection.php 175
ERROR - 2010-07-10 06:37:21 --> Severity: Notice  --> Undefined variable: new_id_array D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_association_collection.php 183
ERROR - 2010-07-10 06:37:21 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 433
ERROR - 2010-07-10 06:37:21 --> Severity: Notice  --> Undefined variable: new_id_array D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_association_collection.php 160
ERROR - 2010-07-10 06:37:21 --> Severity: Warning  --> array_unique() [<a href='function.array-unique'>function.array-unique</a>]: The argument should be an array D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_association_collection.php 160
ERROR - 2010-07-10 06:37:21 --> Severity: Notice  --> Undefined variable: new_id_array D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_association_collection.php 175
ERROR - 2010-07-10 06:37:21 --> Severity: Notice  --> Undefined variable: new_id_array D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_association_collection.php 183
ERROR - 2010-07-10 06:37:21 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 433
ERROR - 2010-07-10 06:37:21 --> Severity: Notice  --> Undefined variable: db D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_association_collection.php 80
ERROR - 2010-07-10 06:39:37 --> Severity: Notice  --> Undefined variable: db D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_association_collection.php 80
ERROR - 2010-07-10 06:40:59 --> Severity: Notice  --> Undefined variable: db D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_association_collection.php 81
ERROR - 2010-07-10 06:42:50 --> Severity: Notice  --> Undefined property: Annotation_scope_collection::$association_class_name D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_collection.php 199
ERROR - 2010-07-10 06:42:50 --> Severity: Notice  --> Undefined property: Annotation_scope_collection::$association_class_name D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_collection.php 199
ERROR - 2010-07-10 06:45:40 --> Unable to load the requested class: collection_iterator
ERROR - 2010-07-10 06:46:24 --> Severity: Warning  --> include_once(annotation/Annotation_feature_location.php) [<a href='function.include-once'>function.include-once</a>]: failed to open stream: No such file or directory D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_attribute_collection.php 100
ERROR - 2010-07-10 06:46:24 --> Severity: Warning  --> include_once() [<a href='function.include'>function.include</a>]: Failed opening 'annotation/Annotation_feature_location.php' for inclusion (include_path='.;D:\xampp\php\pear\') D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_attribute_collection.php 100
ERROR - 2010-07-10 07:58:00 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 114
ERROR - 2010-07-10 07:58:00 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at end of input
LINE 3: WHERE &quot;text&quot; = Array
                            ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 07:58:00 --> Query error: ERROR:  syntax error at end of input
LINE 3: WHERE "text" = Array
                            ^
ERROR - 2010-07-10 07:58:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:386) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-10 07:58:07 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 114
ERROR - 2010-07-10 07:58:07 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at end of input
LINE 3: WHERE &quot;text&quot; = Array
                            ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 07:58:07 --> Query error: ERROR:  syntax error at end of input
LINE 3: WHERE "text" = Array
                            ^
ERROR - 2010-07-10 07:58:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:386) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-10 08:04:47 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  unterminated quoted identifier at or near &quot;&quot;) VALUES ('s', 's', 's', 1.36978, 'annotation.score.integrated')&quot;
LINE 1: ...e_id&quot;, &quot;annotation_id&quot;, &quot;score_type_id&quot;, &quot;score&quot;, &quot;) VALUES ...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 08:04:47 --> Query error: ERROR:  unterminated quoted identifier at or near "") VALUES ('s', 's', 's', 1.36978, 'annotation.score.integrated')"
LINE 1: ...e_id", "annotation_id", "score_type_id", "score", ") VALUES ...
                                                             ^
ERROR - 2010-07-10 08:04:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:386) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-10 08:05:56 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  unterminated quoted identifier at or near &quot;&quot;) VALUES ('s', 's', 's', 1.36978, 'annotation.score.integrated')&quot;
LINE 1: ...e_id&quot;, &quot;annotation_id&quot;, &quot;score_type_id&quot;, &quot;score&quot;, &quot;) VALUES ...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 08:05:56 --> Query error: ERROR:  unterminated quoted identifier at or near "") VALUES ('s', 's', 's', 1.36978, 'annotation.score.integrated')"
LINE 1: ...e_id", "annotation_id", "score_type_id", "score", ") VALUES ...
                                                             ^
ERROR - 2010-07-10 08:05:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:386) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-10 08:10:29 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  unterminated quoted identifier at or near &quot;&quot;) VALUES ('s', 's', 's', 1.36978, 'annotation.score.integrated')&quot;
LINE 1: ...e_id&quot;, &quot;annotation_id&quot;, &quot;score_type_id&quot;, &quot;score&quot;, &quot;) VALUES ...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 08:10:29 --> Query error: ERROR:  unterminated quoted identifier at or near "") VALUES ('s', 's', 's', 1.36978, 'annotation.score.integrated')"
LINE 1: ...e_id", "annotation_id", "score_type_id", "score", ") VALUES ...
                                                             ^
ERROR - 2010-07-10 08:10:29 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:386) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-10 08:10:35 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  unterminated quoted identifier at or near &quot;&quot;) VALUES ('s', 's', 's', 1.36978, 'annotation.score.integrated')&quot;
LINE 1: ...e_id&quot;, &quot;annotation_id&quot;, &quot;score_type_id&quot;, &quot;score&quot;, &quot;) VALUES ...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 08:10:35 --> Query error: ERROR:  unterminated quoted identifier at or near "") VALUES ('s', 's', 's', 1.36978, 'annotation.score.integrated')"
LINE 1: ...e_id", "annotation_id", "score_type_id", "score", ") VALUES ...
                                                             ^
ERROR - 2010-07-10 08:10:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:386) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-10 08:12:52 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  unterminated quoted identifier at or near &quot;&quot;) VALUES ('s', 's', 's', 1.36978, 'annotation.score.integrated')&quot;
LINE 1: ...e_id&quot;, &quot;annotation_id&quot;, &quot;score_type_id&quot;, &quot;score&quot;, &quot;) VALUES ...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 08:12:52 --> Query error: ERROR:  unterminated quoted identifier at or near "") VALUES ('s', 's', 's', 1.36978, 'annotation.score.integrated')"
LINE 1: ...e_id", "annotation_id", "score_type_id", "score", ") VALUES ...
                                                             ^
ERROR - 2010-07-10 08:12:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:386) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-10 08:13:18 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  unterminated quoted identifier at or near &quot;&quot;) VALUES ('s', 's', 's', 1.36978, 'annotation.score.integrated')&quot;
LINE 1: ...e_id&quot;, &quot;annotation_id&quot;, &quot;score_type_id&quot;, &quot;score&quot;, &quot;) VALUES ...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 08:13:18 --> Query error: ERROR:  unterminated quoted identifier at or near "") VALUES ('s', 's', 's', 1.36978, 'annotation.score.integrated')"
LINE 1: ...e_id", "annotation_id", "score_type_id", "score", ") VALUES ...
                                                             ^
ERROR - 2010-07-10 08:13:18 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:386) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-10 08:13:56 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  unterminated quoted identifier at or near &quot;&quot;) VALUES ('s', 's', 's', 1.36978, 'annotation.score.integrated')&quot;
LINE 1: ...e_id&quot;, &quot;annotation_id&quot;, &quot;score_type_id&quot;, &quot;score&quot;, &quot;) VALUES ...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 08:13:56 --> Query error: ERROR:  unterminated quoted identifier at or near "") VALUES ('s', 's', 's', 1.36978, 'annotation.score.integrated')"
LINE 1: ...e_id", "annotation_id", "score_type_id", "score", ") VALUES ...
                                                             ^
ERROR - 2010-07-10 08:13:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:386) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-10 08:14:14 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  unterminated quoted identifier at or near &quot;&quot;) VALUES ('s', 's', 's', 1.36978, 'annotation.score.integrated')&quot;
LINE 1: ...e_id&quot;, &quot;annotation_id&quot;, &quot;score_type_id&quot;, &quot;score&quot;, &quot;) VALUES ...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 08:14:14 --> Query error: ERROR:  unterminated quoted identifier at or near "") VALUES ('s', 's', 's', 1.36978, 'annotation.score.integrated')"
LINE 1: ...e_id", "annotation_id", "score_type_id", "score", ") VALUES ...
                                                             ^
ERROR - 2010-07-10 08:14:14 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:386) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-10 08:14:50 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  unterminated quoted identifier at or near &quot;&quot;) VALUES ('s', 's', 's', 1.36978, 'annotation.score.integrated')&quot;
LINE 1: ...e_id&quot;, &quot;annotation_id&quot;, &quot;score_type_id&quot;, &quot;score&quot;, &quot;) VALUES ...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 08:14:50 --> Query error: ERROR:  unterminated quoted identifier at or near "") VALUES ('s', 's', 's', 1.36978, 'annotation.score.integrated')"
LINE 1: ...e_id", "annotation_id", "score_type_id", "score", ") VALUES ...
                                                             ^
ERROR - 2010-07-10 08:14:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:386) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-10 08:16:07 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  unterminated quoted identifier at or near &quot;&quot;) VALUES ('s', 's', 's', 1.36978, 'annotation.score.integrated')&quot;
LINE 1: ...e_id&quot;, &quot;annotation_id&quot;, &quot;score_type_id&quot;, &quot;score&quot;, &quot;) VALUES ...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 08:16:07 --> Query error: ERROR:  unterminated quoted identifier at or near "") VALUES ('s', 's', 's', 1.36978, 'annotation.score.integrated')"
LINE 1: ...e_id", "annotation_id", "score_type_id", "score", ") VALUES ...
                                                             ^
ERROR - 2010-07-10 08:16:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:386) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-10 08:16:13 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid input syntax for integer: &quot;s&quot;
LINE 1: ...annotation_id&quot;, &quot;score_type_id&quot;, &quot;score&quot;) VALUES ('s', 's', ...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 08:16:13 --> Query error: ERROR:  invalid input syntax for integer: "s"
LINE 1: ...annotation_id", "score_type_id", "score") VALUES ('s', 's', ...
                                                             ^
ERROR - 2010-07-10 08:16:13 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:386) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-10 08:16:48 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid input syntax for integer: &quot;s&quot;
LINE 1: ...annotation_id&quot;, &quot;score_type_id&quot;, &quot;score&quot;) VALUES ('s', 's', ...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 08:16:48 --> Query error: ERROR:  invalid input syntax for integer: "s"
LINE 1: ...annotation_id", "score_type_id", "score") VALUES ('s', 's', ...
                                                             ^
ERROR - 2010-07-10 08:16:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:386) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-10 08:19:08 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid input syntax for integer: &quot;s&quot;
LINE 1: ...annotation_id&quot;, &quot;score_type_id&quot;, &quot;score&quot;) VALUES ('s', 's', ...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 08:19:08 --> Query error: ERROR:  invalid input syntax for integer: "s"
LINE 1: ...annotation_id", "score_type_id", "score") VALUES ('s', 's', ...
                                                             ^
ERROR - 2010-07-10 08:19:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:386) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-10 08:19:25 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid input syntax for integer: &quot;s&quot;
LINE 1: ...annotation_id&quot;, &quot;score_type_id&quot;, &quot;score&quot;) VALUES ('s', 's', ...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 08:19:25 --> Query error: ERROR:  invalid input syntax for integer: "s"
LINE 1: ...annotation_id", "score_type_id", "score") VALUES ('s', 's', ...
                                                             ^
ERROR - 2010-07-10 08:19:25 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:386) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-10 08:19:28 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid input syntax for integer: &quot;s&quot;
LINE 1: ...annotation_id&quot;, &quot;score_type_id&quot;, &quot;score&quot;) VALUES ('s', 's', ...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 08:19:28 --> Query error: ERROR:  invalid input syntax for integer: "s"
LINE 1: ...annotation_id", "score_type_id", "score") VALUES ('s', 's', ...
                                                             ^
ERROR - 2010-07-10 08:19:28 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:386) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-10 08:22:52 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid input syntax for integer: &quot;s&quot;
LINE 1: ...annotation_id&quot;, &quot;score_type_id&quot;, &quot;score&quot;) VALUES ('s', 's', ...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 08:22:52 --> Query error: ERROR:  invalid input syntax for integer: "s"
LINE 1: ...annotation_id", "score_type_id", "score") VALUES ('s', 's', ...
                                                             ^
ERROR - 2010-07-10 08:22:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:386) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-10 08:26:17 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid input syntax for integer: &quot;s&quot;
LINE 1: ...annotation_id&quot;, &quot;score_type_id&quot;, &quot;score&quot;) VALUES ('s', 's', ...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 08:26:17 --> Query error: ERROR:  invalid input syntax for integer: "s"
LINE 1: ...annotation_id", "score_type_id", "score") VALUES ('s', 's', ...
                                                             ^
ERROR - 2010-07-10 08:26:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:386) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-10 08:27:38 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid input syntax for integer: &quot;s&quot;
LINE 1: ...annotation_id&quot;, &quot;score_type_id&quot;, &quot;score&quot;) VALUES ('s', 's', ...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 08:27:38 --> Query error: ERROR:  invalid input syntax for integer: "s"
LINE 1: ...annotation_id", "score_type_id", "score") VALUES ('s', 's', ...
                                                             ^
ERROR - 2010-07-10 08:27:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:386) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-10 08:27:46 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid input syntax for integer: &quot;s&quot;
LINE 1: ...annotation_id&quot;, &quot;score_type_id&quot;, &quot;score&quot;) VALUES ('s', 's', ...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 08:27:46 --> Query error: ERROR:  invalid input syntax for integer: "s"
LINE 1: ...annotation_id", "score_type_id", "score") VALUES ('s', 's', ...
                                                             ^
ERROR - 2010-07-10 08:27:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:386) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-10 08:28:10 --> Severity: Notice  --> Undefined variable: data D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 394
ERROR - 2010-07-10 08:28:10 --> Severity: Notice  --> Undefined variable: data D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 394
ERROR - 2010-07-10 08:28:10 --> Severity: Notice  --> Undefined variable: data D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 394
ERROR - 2010-07-10 08:28:10 --> Severity: Notice  --> Undefined variable: data D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 394
ERROR - 2010-07-10 08:28:10 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid input syntax for integer: &quot;s&quot;
LINE 1: ...annotation_id&quot;, &quot;score_type_id&quot;, &quot;score&quot;) VALUES ('s', 's', ...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 08:28:10 --> Query error: ERROR:  invalid input syntax for integer: "s"
LINE 1: ...annotation_id", "score_type_id", "score") VALUES ('s', 's', ...
                                                             ^
ERROR - 2010-07-10 08:28:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:386) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-10 08:28:17 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid input syntax for integer: &quot;s&quot;
LINE 1: ...annotation_id&quot;, &quot;score_type_id&quot;, &quot;score&quot;) VALUES ('s', 's', ...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 08:28:17 --> Query error: ERROR:  invalid input syntax for integer: "s"
LINE 1: ...annotation_id", "score_type_id", "score") VALUES ('s', 's', ...
                                                             ^
ERROR - 2010-07-10 08:28:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:386) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-10 08:28:34 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid input syntax for integer: &quot;s&quot;
LINE 1: ...annotation_id&quot;, &quot;score_type_id&quot;, &quot;score&quot;) VALUES ('s', 's', ...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 08:28:34 --> Query error: ERROR:  invalid input syntax for integer: "s"
LINE 1: ...annotation_id", "score_type_id", "score") VALUES ('s', 's', ...
                                                             ^
ERROR - 2010-07-10 08:28:34 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:386) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-10 08:28:43 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid input syntax for integer: &quot;s&quot;
LINE 1: ...annotation_id&quot;, &quot;score_type_id&quot;, &quot;score&quot;) VALUES ('s', 's', ...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 08:28:43 --> Query error: ERROR:  invalid input syntax for integer: "s"
LINE 1: ...annotation_id", "score_type_id", "score") VALUES ('s', 's', ...
                                                             ^
ERROR - 2010-07-10 08:28:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:386) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-10 08:31:32 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:32 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:32 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:32 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:32 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:32 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:32 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:32 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:32 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:32 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:32 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:32 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:32 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:32 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:32 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:32 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:32 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:32 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:32 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:32 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:32 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:32 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:32 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:32 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:32 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:32 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Notice  --> Undefined variable: this D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 851
ERROR - 2010-07-10 08:31:33 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid input syntax for integer: &quot;s&quot;
LINE 1: ...annotation_id&quot;, &quot;score_type_id&quot;, &quot;score&quot;) VALUES ('s', 's', ...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 08:31:33 --> Query error: ERROR:  invalid input syntax for integer: "s"
LINE 1: ...annotation_id", "score_type_id", "score") VALUES ('s', 's', ...
                                                             ^
ERROR - 2010-07-10 08:31:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-10 08:32:42 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid input syntax for integer: &quot;s&quot;
LINE 1: ...annotation_id&quot;, &quot;score_type_id&quot;, &quot;score&quot;) VALUES ('s', 's', ...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 08:32:42 --> Query error: ERROR:  invalid input syntax for integer: "s"
LINE 1: ...annotation_id", "score_type_id", "score") VALUES ('s', 's', ...
                                                             ^
ERROR - 2010-07-10 08:32:42 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:386) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-10 08:34:38 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid input syntax for integer: &quot;s&quot;
LINE 1: ...annotation_id&quot;, &quot;score_type_id&quot;, &quot;score&quot;) VALUES ('s', 's', ...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 08:34:38 --> Query error: ERROR:  invalid input syntax for integer: "s"
LINE 1: ...annotation_id", "score_type_id", "score") VALUES ('s', 's', ...
                                                             ^
ERROR - 2010-07-10 08:34:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:386) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-10 09:24:36 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;update_timestamp&quot; is of type timestamp with time zone but expression is of type integer
LINE 1: ...tation_type_id, update_timestamp) VALUES (225, 1, 1278753876...
                                                             ^
HINT:  You will need to rewrite or cast the expression. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 09:24:36 --> Query error: ERROR:  column "update_timestamp" is of type timestamp with time zone but expression is of type integer
LINE 1: ...tation_type_id, update_timestamp) VALUES (225, 1, 1278753876...
                                                             ^
HINT:  You will need to rewrite or cast the expression.
ERROR - 2010-07-10 09:29:07 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;update_timestamp&quot; is of type timestamp with time zone but expression is of type integer
LINE 1: ...tation_type_id, update_timestamp) VALUES (225, 1, 1278754147...
                                                             ^
HINT:  You will need to rewrite or cast the expression. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 09:29:07 --> Query error: ERROR:  column "update_timestamp" is of type timestamp with time zone but expression is of type integer
LINE 1: ...tation_type_id, update_timestamp) VALUES (225, 1, 1278754147...
                                                             ^
HINT:  You will need to rewrite or cast the expression.
ERROR - 2010-07-10 09:36:51 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid input syntax for type timestamp with time zone: &quot;2010-07-10 09:36:51 . 000000 UTC&quot;
LINE 1: ...tation_type_id, update_timestamp) VALUES (225, 1, '2010-07-1...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 09:36:51 --> Query error: ERROR:  invalid input syntax for type timestamp with time zone: "2010-07-10 09:36:51 . 000000 UTC"
LINE 1: ...tation_type_id, update_timestamp) VALUES (225, 1, '2010-07-1...
                                                             ^
ERROR - 2010-07-10 11:15:40 --> annotation_like_collection.deny_annotation_author.exception
ERROR - 2010-07-10 11:16:39 --> annotation_like_collection.deny_annotation_author.exception
ERROR - 2010-07-10 11:16:39 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:386) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-10 11:17:23 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/6ea9ab1baa0efb9e19094440c317e21b) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-10 11:17:23 --> annotation_like_collection.deny_annotation_author.exception
ERROR - 2010-07-10 11:17:23 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:386) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-10 11:21:16 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/4e732ced3463d06de0ca9a15b6153677) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-10 11:29:22 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid byte sequence for encoding &quot;UTF8&quot;: 0xb8
HINT:  This error can also happen if the byte sequence does not match the encoding expected by the server, which is controlled by &quot;client_encoding&quot;. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 11:29:22 --> Query error: ERROR:  invalid byte sequence for encoding "UTF8": 0xb8
HINT:  This error can also happen if the byte sequence does not match the encoding expected by the server, which is controlled by "client_encoding".
ERROR - 2010-07-10 11:29:36 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid byte sequence for encoding &quot;UTF8&quot;: 0xb8
HINT:  This error can also happen if the byte sequence does not match the encoding expected by the server, which is controlled by &quot;client_encoding&quot;. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 11:29:36 --> Query error: ERROR:  invalid byte sequence for encoding "UTF8": 0xb8
HINT:  This error can also happen if the byte sequence does not match the encoding expected by the server, which is controlled by "client_encoding".
ERROR - 2010-07-10 11:30:50 --> 404 Page Not Found --> ut_annotation
ERROR - 2010-07-10 11:34:58 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid byte sequence for encoding &quot;UTF8&quot;: 0xb8
HINT:  This error can also happen if the byte sequence does not match the encoding expected by the server, which is controlled by &quot;client_encoding&quot;. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-10 11:34:58 --> Query error: ERROR:  invalid byte sequence for encoding "UTF8": 0xb8
HINT:  This error can also happen if the byte sequence does not match the encoding expected by the server, which is controlled by "client_encoding".
ERROR - 2010-07-10 11:56:07 --> annotation_like_collection.deny_annotation_author.exception
ERROR - 2010-07-10 11:56:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:387) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-10 11:56:13 --> annotation_like_collection.deny_annotation_author.exception
ERROR - 2010-07-10 11:56:13 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:387) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-10 11:56:15 --> annotation_like_collection.deny_annotation_author.exception
ERROR - 2010-07-10 11:56:15 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:387) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-10 11:57:48 --> annotation_like_collection.deny_annotation_author.exception
ERROR - 2010-07-10 11:57:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:387) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
