<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-07-13 04:50:38 --> Severity: Notice  --> Undefined property: Ut_user::$scope_anchor_text D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Annotation_scope.php 129
ERROR - 2010-07-13 05:00:51 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/7f39f8317fbdb1988ef4c628eba02591) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-13 05:21:06 --> Severity: Notice  --> Undefined property: User::$get_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Annotation_respond_collection.php 60
ERROR - 2010-07-13 05:21:06 --> Severity: Notice  --> Undefined property: User::$get_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Annotation_respond_collection.php 60
ERROR - 2010-07-13 10:10:18 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  relation &quot;annotation2likc_count&quot; does not exist
LINE 2: FROM &quot;annotation2likc_count&quot;
             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-13 10:10:18 --> Query error: ERROR:  relation "annotation2likc_count" does not exist
LINE 2: FROM "annotation2likc_count"
             ^
