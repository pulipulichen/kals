<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2010-06-30 05:34:49 --> Config Class Initialized
DEBUG - 2010-06-30 05:34:49 --> Hooks Class Initialized
DEBUG - 2010-06-30 05:34:49 --> URI Class Initialized
DEBUG - 2010-06-30 05:34:49 --> Router Class Initialized
DEBUG - 2010-06-30 05:34:49 --> Output Class Initialized
DEBUG - 2010-06-30 05:34:49 --> Input Class Initialized
DEBUG - 2010-06-30 05:34:49 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-30 05:34:49 --> Language Class Initialized
DEBUG - 2010-06-30 05:34:49 --> Loader Class Initialized
DEBUG - 2010-06-30 05:34:49 --> Helper loaded: context_helper
DEBUG - 2010-06-30 05:34:49 --> Helper loaded: kals_helper
DEBUG - 2010-06-30 05:34:49 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-30 05:34:49 --> Database Driver Class Initialized
DEBUG - 2010-06-30 05:34:49 --> Controller Class Initialized
DEBUG - 2010-06-30 05:34:49 --> Unit Testing Class Initialized
DEBUG - 2010-06-30 05:34:49 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-30 05:34:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:34:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:34:49 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:34:49 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:34:49 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:34:50 --> Helper loaded: email_helper
DEBUG - 2010-06-30 05:34:50 --> User Agent Class Initialized
DEBUG - 2010-06-30 05:34:50 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:41:29 --> Config Class Initialized
DEBUG - 2010-06-30 05:41:29 --> Hooks Class Initialized
DEBUG - 2010-06-30 05:41:29 --> URI Class Initialized
DEBUG - 2010-06-30 05:41:29 --> Router Class Initialized
DEBUG - 2010-06-30 05:41:29 --> Output Class Initialized
DEBUG - 2010-06-30 05:41:29 --> Input Class Initialized
DEBUG - 2010-06-30 05:41:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-30 05:41:29 --> Language Class Initialized
DEBUG - 2010-06-30 05:41:29 --> Loader Class Initialized
DEBUG - 2010-06-30 05:41:29 --> Helper loaded: context_helper
DEBUG - 2010-06-30 05:41:29 --> Helper loaded: kals_helper
DEBUG - 2010-06-30 05:41:29 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-30 05:41:29 --> Database Driver Class Initialized
DEBUG - 2010-06-30 05:41:29 --> Controller Class Initialized
DEBUG - 2010-06-30 05:41:29 --> Unit Testing Class Initialized
DEBUG - 2010-06-30 05:41:29 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-30 05:41:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:41:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:41:29 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:41:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:41:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:41:29 --> Helper loaded: email_helper
DEBUG - 2010-06-30 05:41:29 --> User Agent Class Initialized
DEBUG - 2010-06-30 05:41:29 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:41:29 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:41:29 --> Session Class Initialized
DEBUG - 2010-06-30 05:41:29 --> Helper loaded: string_helper
DEBUG - 2010-06-30 05:41:29 --> A session cookie was not found.
DEBUG - 2010-06-30 05:41:29 --> Session routines successfully run
DEBUG - 2010-06-30 05:41:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:41:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:41:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:41:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:41:30 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:41:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:41:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:41:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:41:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:41:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:41:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:41:31 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-30 05:41:31 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:41:31 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:41:31 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:41:31 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:41:31 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:41:31 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:41:31 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:41:31 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:42:05 --> Config Class Initialized
DEBUG - 2010-06-30 05:42:05 --> Hooks Class Initialized
DEBUG - 2010-06-30 05:42:05 --> URI Class Initialized
DEBUG - 2010-06-30 05:42:05 --> Router Class Initialized
DEBUG - 2010-06-30 05:42:05 --> Output Class Initialized
DEBUG - 2010-06-30 05:42:05 --> Input Class Initialized
DEBUG - 2010-06-30 05:42:05 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-30 05:42:05 --> Language Class Initialized
DEBUG - 2010-06-30 05:42:05 --> Loader Class Initialized
DEBUG - 2010-06-30 05:42:05 --> Helper loaded: context_helper
DEBUG - 2010-06-30 05:42:05 --> Helper loaded: kals_helper
DEBUG - 2010-06-30 05:42:05 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-30 05:42:05 --> Database Driver Class Initialized
DEBUG - 2010-06-30 05:42:05 --> Controller Class Initialized
DEBUG - 2010-06-30 05:42:05 --> Unit Testing Class Initialized
DEBUG - 2010-06-30 05:42:05 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-30 05:42:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:42:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:42:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:42:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:42:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:42:05 --> Helper loaded: email_helper
DEBUG - 2010-06-30 05:42:05 --> User Agent Class Initialized
DEBUG - 2010-06-30 05:42:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:42:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:42:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:42:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:42:05 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:42:05 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:42:05 --> Session Class Initialized
DEBUG - 2010-06-30 05:42:05 --> Helper loaded: string_helper
DEBUG - 2010-06-30 05:42:05 --> Session routines successfully run
DEBUG - 2010-06-30 05:42:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:42:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:42:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:42:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:42:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:42:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:42:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:42:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:42:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:42:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:42:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:42:07 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-30 05:42:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:42:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:42:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:42:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:42:07 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:42:07 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:42:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:42:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:42:07 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:42:07 --> KALS_actor class already loaded. Second attempt ignored.
ERROR - 2010-06-30 05:42:07 --> Severity: Notice  --> Object of class Action_webpage_administration could not be converted to int D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 288
ERROR - 2010-06-30 05:42:07 --> Severity: Notice  --> Object of class Action_webpage_administration could not be converted to int D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 288
ERROR - 2010-06-30 05:42:07 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;actor_Id&quot; does not exist
LINE 5: AND &quot;actor_Id&quot; = 60
            ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-06-30 05:42:07 --> DB Transaction Failure
ERROR - 2010-06-30 05:42:07 --> Query error: ERROR:  column "actor_Id" does not exist
LINE 5: AND "actor_Id" = 60
            ^
DEBUG - 2010-06-30 05:42:07 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-06-30 05:42:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-30 05:44:56 --> Config Class Initialized
DEBUG - 2010-06-30 05:44:56 --> Hooks Class Initialized
DEBUG - 2010-06-30 05:44:56 --> URI Class Initialized
DEBUG - 2010-06-30 05:44:56 --> Router Class Initialized
DEBUG - 2010-06-30 05:44:56 --> Output Class Initialized
DEBUG - 2010-06-30 05:44:56 --> Input Class Initialized
DEBUG - 2010-06-30 05:44:56 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-30 05:44:56 --> Language Class Initialized
DEBUG - 2010-06-30 05:44:56 --> Loader Class Initialized
DEBUG - 2010-06-30 05:44:56 --> Helper loaded: context_helper
DEBUG - 2010-06-30 05:44:56 --> Helper loaded: kals_helper
DEBUG - 2010-06-30 05:44:56 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-30 05:44:56 --> Database Driver Class Initialized
DEBUG - 2010-06-30 05:44:56 --> Controller Class Initialized
DEBUG - 2010-06-30 05:44:56 --> Unit Testing Class Initialized
DEBUG - 2010-06-30 05:44:56 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-30 05:44:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:44:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:44:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:44:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:44:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:44:56 --> Helper loaded: email_helper
DEBUG - 2010-06-30 05:44:56 --> User Agent Class Initialized
DEBUG - 2010-06-30 05:44:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:44:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:44:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:44:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:44:56 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:44:56 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:44:56 --> Session Class Initialized
DEBUG - 2010-06-30 05:44:56 --> Helper loaded: string_helper
DEBUG - 2010-06-30 05:44:56 --> Session routines successfully run
DEBUG - 2010-06-30 05:45:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:45:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:45:02 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:45:02 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:45:02 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:45:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:45:02 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:45:02 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:45:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:45:02 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:45:02 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:45:02 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-30 05:45:02 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:45:02 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:45:02 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:45:02 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:45:02 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:45:02 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:45:02 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:45:02 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:45:02 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:45:02 --> KALS_actor class already loaded. Second attempt ignored.
ERROR - 2010-06-30 05:45:02 --> Severity: Notice  --> Object of class Action_webpage_administration could not be converted to int D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 288
ERROR - 2010-06-30 05:45:02 --> Severity: Notice  --> Object of class Action_webpage_administration could not be converted to int D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 288
ERROR - 2010-06-30 05:45:02 --> Severity: Notice  --> Object of class Action_webpage_administration could not be converted to int D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 288
ERROR - 2010-06-30 05:45:02 --> Severity: Notice  --> Object of class Action_webpage_administration could not be converted to int D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 288
ERROR - 2010-06-30 05:45:02 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  insert or update on table &quot;policy2actor&quot; violates foreign key constraint &quot;policy2actor_policy_id_fkey&quot;
DETAIL:  Key (policy_id)=(1) is not present in table &quot;policy&quot;. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-06-30 05:45:02 --> DB Transaction Failure
ERROR - 2010-06-30 05:45:02 --> Query error: ERROR:  insert or update on table "policy2actor" violates foreign key constraint "policy2actor_policy_id_fkey"
DETAIL:  Key (policy_id)=(1) is not present in table "policy".
DEBUG - 2010-06-30 05:45:02 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-06-30 05:45:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Authorize_manager.php:289) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-30 05:46:05 --> Config Class Initialized
DEBUG - 2010-06-30 05:46:05 --> Hooks Class Initialized
DEBUG - 2010-06-30 05:46:05 --> URI Class Initialized
DEBUG - 2010-06-30 05:46:05 --> Router Class Initialized
DEBUG - 2010-06-30 05:46:05 --> Output Class Initialized
DEBUG - 2010-06-30 05:46:05 --> Input Class Initialized
DEBUG - 2010-06-30 05:46:05 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-30 05:46:05 --> Language Class Initialized
DEBUG - 2010-06-30 05:46:05 --> Loader Class Initialized
DEBUG - 2010-06-30 05:46:05 --> Helper loaded: context_helper
DEBUG - 2010-06-30 05:46:05 --> Helper loaded: kals_helper
DEBUG - 2010-06-30 05:46:05 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-30 05:46:05 --> Database Driver Class Initialized
DEBUG - 2010-06-30 05:46:05 --> Controller Class Initialized
DEBUG - 2010-06-30 05:46:05 --> Unit Testing Class Initialized
DEBUG - 2010-06-30 05:46:05 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-30 05:46:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:46:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:46:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:46:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:46:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:46:05 --> Helper loaded: email_helper
DEBUG - 2010-06-30 05:46:05 --> User Agent Class Initialized
DEBUG - 2010-06-30 05:46:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:46:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:46:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:46:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:46:05 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:46:05 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:46:06 --> Session Class Initialized
DEBUG - 2010-06-30 05:46:06 --> Helper loaded: string_helper
DEBUG - 2010-06-30 05:46:06 --> Session routines successfully run
DEBUG - 2010-06-30 05:46:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:46:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:46:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:46:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:46:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:46:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:46:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:46:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:46:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:46:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:46:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:46:07 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-30 05:46:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:46:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:46:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:46:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:46:07 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:46:07 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:46:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:46:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:46:07 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 05:46:07 --> KALS_actor class already loaded. Second attempt ignored.
ERROR - 2010-06-30 05:46:07 --> Severity: Notice  --> Object of class Action_webpage_administration could not be converted to int D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 288
ERROR - 2010-06-30 05:46:07 --> Severity: Notice  --> Object of class Action_webpage_administration could not be converted to int D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 288
ERROR - 2010-06-30 05:46:07 --> Severity: Notice  --> Object of class Action_webpage_administration could not be converted to int D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 288
ERROR - 2010-06-30 05:46:07 --> Severity: Notice  --> Object of class Action_webpage_administration could not be converted to int D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 288
ERROR - 2010-06-30 05:46:07 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  insert or update on table &quot;policy2actor&quot; violates foreign key constraint &quot;policy2actor_policy_id_fkey&quot;
DETAIL:  Key (policy_id)=(1) is not present in table &quot;policy&quot;. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-06-30 05:46:07 --> DB Transaction Failure
ERROR - 2010-06-30 05:46:07 --> Query error: ERROR:  insert or update on table "policy2actor" violates foreign key constraint "policy2actor_policy_id_fkey"
DETAIL:  Key (policy_id)=(1) is not present in table "policy".
DEBUG - 2010-06-30 05:46:07 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-06-30 05:46:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:377) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-30 13:49:36 --> Config Class Initialized
DEBUG - 2010-06-30 13:49:36 --> Hooks Class Initialized
DEBUG - 2010-06-30 13:49:36 --> URI Class Initialized
DEBUG - 2010-06-30 13:49:37 --> Router Class Initialized
DEBUG - 2010-06-30 13:49:37 --> Output Class Initialized
DEBUG - 2010-06-30 13:49:37 --> Input Class Initialized
DEBUG - 2010-06-30 13:49:37 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-30 13:49:37 --> Language Class Initialized
DEBUG - 2010-06-30 13:49:37 --> Loader Class Initialized
DEBUG - 2010-06-30 13:49:37 --> Helper loaded: context_helper
DEBUG - 2010-06-30 13:49:37 --> Helper loaded: kals_helper
DEBUG - 2010-06-30 13:49:37 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-30 13:49:37 --> Database Driver Class Initialized
DEBUG - 2010-06-30 13:49:37 --> Controller Class Initialized
DEBUG - 2010-06-30 13:49:37 --> Unit Testing Class Initialized
DEBUG - 2010-06-30 13:49:37 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-30 13:49:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:37 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:37 --> Helper loaded: email_helper
DEBUG - 2010-06-30 13:49:37 --> User Agent Class Initialized
DEBUG - 2010-06-30 13:49:37 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:38 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:38 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:38 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:38 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:38 --> Session Class Initialized
DEBUG - 2010-06-30 13:49:38 --> Helper loaded: string_helper
DEBUG - 2010-06-30 13:49:38 --> A session cookie was not found.
DEBUG - 2010-06-30 13:49:38 --> Session routines successfully run
DEBUG - 2010-06-30 13:49:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-30 13:49:39 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> Action_webpage_administration class already loaded. Second attempt ignored.
ERROR - 2010-06-30 13:49:39 --> Severity: Warning  --> Missing argument 3 for Policy::create_policy(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Authorize_manager.php on line 216 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Policy.php 54
DEBUG - 2010-06-30 13:49:39 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> Action_webpage_administration class already loaded. Second attempt ignored.
ERROR - 2010-06-30 13:49:39 --> Severity: Warning  --> Missing argument 3 for Policy::create_policy(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Authorize_manager.php on line 216 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Policy.php 54
DEBUG - 2010-06-30 13:49:39 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> Action_webpage_administration class already loaded. Second attempt ignored.
ERROR - 2010-06-30 13:49:39 --> Severity: Warning  --> Missing argument 3 for Policy::create_policy(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Authorize_manager.php on line 216 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Policy.php 54
DEBUG - 2010-06-30 13:49:39 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> Action_webpage_administration class already loaded. Second attempt ignored.
ERROR - 2010-06-30 13:49:39 --> Severity: Warning  --> Missing argument 3 for Policy::create_policy(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Authorize_manager.php on line 216 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Policy.php 54
DEBUG - 2010-06-30 13:49:39 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> Action_webpage_administration class already loaded. Second attempt ignored.
ERROR - 2010-06-30 13:49:39 --> Severity: Warning  --> Missing argument 3 for Policy::create_policy(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Authorize_manager.php on line 216 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Policy.php 54
DEBUG - 2010-06-30 13:49:39 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:39 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:40 --> Action_webpage_administration class already loaded. Second attempt ignored.
ERROR - 2010-06-30 13:49:40 --> Severity: Warning  --> Missing argument 3 for Policy::create_policy(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Authorize_manager.php on line 216 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Policy.php 54
DEBUG - 2010-06-30 13:49:40 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:40 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:40 --> Action_webpage_administration class already loaded. Second attempt ignored.
ERROR - 2010-06-30 13:49:40 --> Severity: Warning  --> Missing argument 3 for Policy::create_policy(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Authorize_manager.php on line 216 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Policy.php 54
DEBUG - 2010-06-30 13:49:40 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:40 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:40 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:40 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:40 --> User class already loaded. Second attempt ignored.
ERROR - 2010-06-30 13:49:40 --> Severity: Warning  --> Missing argument 3 for Policy::create_policy(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Authorize_manager.php on line 216 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Policy.php 54
DEBUG - 2010-06-30 13:49:40 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:40 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:40 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:40 --> Action_webpage_read class already loaded. Second attempt ignored.
ERROR - 2010-06-30 13:49:40 --> Severity: Warning  --> Missing argument 3 for Policy::create_policy(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Authorize_manager.php on line 216 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Policy.php 54
DEBUG - 2010-06-30 13:49:40 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:40 --> KALS_actor class already loaded. Second attempt ignored.
ERROR - 2010-06-30 13:49:40 --> Severity: Warning  --> Missing argument 3 for Policy::create_policy(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Authorize_manager.php on line 216 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Policy.php 54
DEBUG - 2010-06-30 13:49:40 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:49:40 --> KALS_actor class already loaded. Second attempt ignored.
ERROR - 2010-06-30 13:49:40 --> Severity: Notice  --> Undefined variable: action D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Authorize_manager.php 107
ERROR - 2010-06-30 13:49:40 --> Severity: Notice  --> Undefined variable: action D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Authorize_manager.php 107
ERROR - 2010-06-30 13:49:40 --> Severity: Notice  --> Undefined variable: action D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Authorize_manager.php 107
DEBUG - 2010-06-30 13:55:05 --> Config Class Initialized
DEBUG - 2010-06-30 13:55:05 --> Hooks Class Initialized
DEBUG - 2010-06-30 13:55:05 --> URI Class Initialized
DEBUG - 2010-06-30 13:55:05 --> Router Class Initialized
DEBUG - 2010-06-30 13:55:05 --> Output Class Initialized
DEBUG - 2010-06-30 13:55:05 --> Input Class Initialized
DEBUG - 2010-06-30 13:55:05 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-30 13:55:05 --> Language Class Initialized
DEBUG - 2010-06-30 13:55:05 --> Loader Class Initialized
DEBUG - 2010-06-30 13:55:05 --> Helper loaded: context_helper
DEBUG - 2010-06-30 13:55:05 --> Helper loaded: kals_helper
DEBUG - 2010-06-30 13:55:05 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-30 13:55:05 --> Database Driver Class Initialized
DEBUG - 2010-06-30 13:55:05 --> Controller Class Initialized
DEBUG - 2010-06-30 13:55:05 --> Unit Testing Class Initialized
DEBUG - 2010-06-30 13:55:05 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-30 13:55:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:05 --> Helper loaded: email_helper
DEBUG - 2010-06-30 13:55:05 --> User Agent Class Initialized
DEBUG - 2010-06-30 13:55:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:05 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:05 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:06 --> Session Class Initialized
DEBUG - 2010-06-30 13:55:06 --> Helper loaded: string_helper
DEBUG - 2010-06-30 13:55:06 --> Session routines successfully run
DEBUG - 2010-06-30 13:55:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:06 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:06 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-30 13:55:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:08 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:08 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:08 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:08 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:08 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:08 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:08 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:55:08 --> KALS_actor class already loaded. Second attempt ignored.
ERROR - 2010-06-30 13:55:08 --> Severity: Notice  --> Undefined variable: action D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Authorize_manager.php 107
ERROR - 2010-06-30 13:55:08 --> Severity: Notice  --> Undefined variable: action D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Authorize_manager.php 107
ERROR - 2010-06-30 13:55:08 --> Severity: Notice  --> Undefined variable: action D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Authorize_manager.php 107
DEBUG - 2010-06-30 13:56:28 --> Config Class Initialized
DEBUG - 2010-06-30 13:56:28 --> Hooks Class Initialized
DEBUG - 2010-06-30 13:56:28 --> URI Class Initialized
DEBUG - 2010-06-30 13:56:28 --> Router Class Initialized
DEBUG - 2010-06-30 13:56:28 --> Output Class Initialized
DEBUG - 2010-06-30 13:56:28 --> Input Class Initialized
DEBUG - 2010-06-30 13:56:28 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-30 13:56:28 --> Language Class Initialized
DEBUG - 2010-06-30 13:56:28 --> Loader Class Initialized
DEBUG - 2010-06-30 13:56:28 --> Helper loaded: context_helper
DEBUG - 2010-06-30 13:56:28 --> Helper loaded: kals_helper
DEBUG - 2010-06-30 13:56:28 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-30 13:56:28 --> Database Driver Class Initialized
DEBUG - 2010-06-30 13:56:28 --> Controller Class Initialized
DEBUG - 2010-06-30 13:56:28 --> Unit Testing Class Initialized
DEBUG - 2010-06-30 13:56:28 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-30 13:56:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:28 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:28 --> Helper loaded: email_helper
DEBUG - 2010-06-30 13:56:28 --> User Agent Class Initialized
DEBUG - 2010-06-30 13:56:29 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:29 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:29 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:29 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:29 --> Session Class Initialized
DEBUG - 2010-06-30 13:56:29 --> Helper loaded: string_helper
DEBUG - 2010-06-30 13:56:29 --> Session routines successfully run
DEBUG - 2010-06-30 13:56:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-30 13:56:30 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:30 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> KALS_actor class already loaded. Second attempt ignored.
ERROR - 2010-06-30 13:56:31 --> Severity: Notice  --> Undefined variable: action D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Authorize_manager.php 107
ERROR - 2010-06-30 13:56:31 --> Severity: Notice  --> Undefined variable: action D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Authorize_manager.php 107
ERROR - 2010-06-30 13:56:31 --> Severity: Notice  --> Undefined variable: action D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Authorize_manager.php 107
DEBUG - 2010-06-30 13:56:31 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:56:31 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
ERROR - 2010-06-30 13:56:31 --> Severity: Notice  --> Undefined variable: group D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_policy\ut_auth.php 242
DEBUG - 2010-06-30 13:57:09 --> Config Class Initialized
DEBUG - 2010-06-30 13:57:09 --> Hooks Class Initialized
DEBUG - 2010-06-30 13:57:09 --> URI Class Initialized
DEBUG - 2010-06-30 13:57:09 --> Router Class Initialized
DEBUG - 2010-06-30 13:57:09 --> Output Class Initialized
DEBUG - 2010-06-30 13:57:09 --> Input Class Initialized
DEBUG - 2010-06-30 13:57:09 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-30 13:57:09 --> Language Class Initialized
DEBUG - 2010-06-30 13:57:09 --> Loader Class Initialized
DEBUG - 2010-06-30 13:57:09 --> Helper loaded: context_helper
DEBUG - 2010-06-30 13:57:09 --> Helper loaded: kals_helper
DEBUG - 2010-06-30 13:57:09 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-30 13:57:09 --> Database Driver Class Initialized
DEBUG - 2010-06-30 13:57:09 --> Controller Class Initialized
DEBUG - 2010-06-30 13:57:09 --> Unit Testing Class Initialized
DEBUG - 2010-06-30 13:57:09 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-30 13:57:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:09 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:09 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:09 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:09 --> Helper loaded: email_helper
DEBUG - 2010-06-30 13:57:09 --> User Agent Class Initialized
DEBUG - 2010-06-30 13:57:09 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:09 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:09 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:09 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:09 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:09 --> Session Class Initialized
DEBUG - 2010-06-30 13:57:09 --> Helper loaded: string_helper
DEBUG - 2010-06-30 13:57:09 --> Session routines successfully run
DEBUG - 2010-06-30 13:57:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:10 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:10 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:10 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:10 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:10 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:10 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-30 13:57:11 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:11 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:12 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:12 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:12 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:12 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:12 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:12 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:12 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:12 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:12 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:12 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:12 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:12 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:12 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:12 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:12 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:12 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:12 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:12 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:12 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 13:57:12 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:06 --> Config Class Initialized
DEBUG - 2010-06-30 14:01:06 --> Hooks Class Initialized
DEBUG - 2010-06-30 14:01:06 --> URI Class Initialized
DEBUG - 2010-06-30 14:01:07 --> Router Class Initialized
DEBUG - 2010-06-30 14:01:07 --> Output Class Initialized
DEBUG - 2010-06-30 14:01:07 --> Input Class Initialized
DEBUG - 2010-06-30 14:01:07 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-30 14:01:07 --> Language Class Initialized
DEBUG - 2010-06-30 14:01:07 --> Loader Class Initialized
DEBUG - 2010-06-30 14:01:07 --> Helper loaded: context_helper
DEBUG - 2010-06-30 14:01:07 --> Helper loaded: kals_helper
DEBUG - 2010-06-30 14:01:07 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-30 14:01:07 --> Database Driver Class Initialized
DEBUG - 2010-06-30 14:01:07 --> Controller Class Initialized
DEBUG - 2010-06-30 14:01:07 --> Unit Testing Class Initialized
DEBUG - 2010-06-30 14:01:07 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-30 14:01:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:07 --> Helper loaded: email_helper
DEBUG - 2010-06-30 14:01:07 --> User Agent Class Initialized
DEBUG - 2010-06-30 14:01:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:07 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:07 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:07 --> Session Class Initialized
DEBUG - 2010-06-30 14:01:07 --> Helper loaded: string_helper
DEBUG - 2010-06-30 14:01:07 --> Session routines successfully run
DEBUG - 2010-06-30 14:01:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:08 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:08 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-30 14:01:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:09 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:09 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:09 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:09 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:09 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:09 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:09 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:09 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:09 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:09 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:09 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:09 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:09 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:09 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:10 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:10 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:10 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:10 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:10 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:10 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:10 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:10 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:10 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:10 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:10 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:10 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:10 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:10 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:10 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:10 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:10 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:10 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:10 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:10 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:10 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:10 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:01:10 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:31 --> Config Class Initialized
DEBUG - 2010-06-30 14:02:31 --> Hooks Class Initialized
DEBUG - 2010-06-30 14:02:31 --> URI Class Initialized
DEBUG - 2010-06-30 14:02:31 --> Router Class Initialized
DEBUG - 2010-06-30 14:02:32 --> Output Class Initialized
DEBUG - 2010-06-30 14:02:32 --> Input Class Initialized
DEBUG - 2010-06-30 14:02:32 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-30 14:02:32 --> Language Class Initialized
DEBUG - 2010-06-30 14:02:32 --> Loader Class Initialized
DEBUG - 2010-06-30 14:02:32 --> Helper loaded: context_helper
DEBUG - 2010-06-30 14:02:32 --> Helper loaded: kals_helper
DEBUG - 2010-06-30 14:02:32 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-30 14:02:32 --> Database Driver Class Initialized
DEBUG - 2010-06-30 14:02:32 --> Controller Class Initialized
DEBUG - 2010-06-30 14:02:32 --> Unit Testing Class Initialized
DEBUG - 2010-06-30 14:02:32 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-30 14:02:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:32 --> Helper loaded: email_helper
DEBUG - 2010-06-30 14:02:32 --> User Agent Class Initialized
DEBUG - 2010-06-30 14:02:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:32 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:32 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:32 --> Session Class Initialized
DEBUG - 2010-06-30 14:02:32 --> Helper loaded: string_helper
DEBUG - 2010-06-30 14:02:32 --> Session routines successfully run
DEBUG - 2010-06-30 14:02:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:33 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:33 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:33 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:33 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:33 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:33 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:33 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:33 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-30 14:02:33 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:33 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:34 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:35 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:36 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:36 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:36 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:36 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:36 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:36 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:36 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:36 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:36 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:36 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:36 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:36 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:36 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:36 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:36 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:36 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:36 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:02:36 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-30 14:02:36 --> Final output sent to browser
DEBUG - 2010-06-30 14:02:36 --> Total execution time: 4.7118
DEBUG - 2010-06-30 14:09:26 --> Config Class Initialized
DEBUG - 2010-06-30 14:09:26 --> Hooks Class Initialized
DEBUG - 2010-06-30 14:09:26 --> URI Class Initialized
DEBUG - 2010-06-30 14:09:26 --> Router Class Initialized
DEBUG - 2010-06-30 14:09:26 --> Output Class Initialized
DEBUG - 2010-06-30 14:09:26 --> Input Class Initialized
DEBUG - 2010-06-30 14:09:26 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-30 14:09:26 --> Language Class Initialized
DEBUG - 2010-06-30 14:09:26 --> Loader Class Initialized
DEBUG - 2010-06-30 14:09:26 --> Helper loaded: context_helper
DEBUG - 2010-06-30 14:09:26 --> Helper loaded: kals_helper
DEBUG - 2010-06-30 14:09:26 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-30 14:09:26 --> Database Driver Class Initialized
DEBUG - 2010-06-30 14:09:26 --> Controller Class Initialized
DEBUG - 2010-06-30 14:09:26 --> Unit Testing Class Initialized
DEBUG - 2010-06-30 14:09:26 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-30 14:09:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:26 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:26 --> Helper loaded: email_helper
DEBUG - 2010-06-30 14:09:26 --> User Agent Class Initialized
DEBUG - 2010-06-30 14:09:26 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:26 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:26 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:26 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:26 --> Session Class Initialized
DEBUG - 2010-06-30 14:09:26 --> Helper loaded: string_helper
DEBUG - 2010-06-30 14:09:27 --> Session routines successfully run
DEBUG - 2010-06-30 14:09:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:27 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:28 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:28 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:28 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:28 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-30 14:09:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:28 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:28 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:28 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:28 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:28 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:28 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:29 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:29 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:29 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:29 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:29 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:29 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:29 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:29 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:29 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:29 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:29 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:29 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:29 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:29 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:29 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:29 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:29 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:29 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:29 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:29 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:29 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:29 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:29 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:30 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:30 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:30 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:30 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:30 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:30 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:30 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:30 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:30 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:30 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:30 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:30 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:30 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:30 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:30 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:30 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:30 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:30 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:30 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:30 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:31 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:31 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:31 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:31 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:31 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:31 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:31 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:31 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:31 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:31 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:31 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:09:31 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-30 14:09:31 --> Final output sent to browser
DEBUG - 2010-06-30 14:09:31 --> Total execution time: 5.4091
DEBUG - 2010-06-30 14:10:07 --> Config Class Initialized
DEBUG - 2010-06-30 14:10:07 --> Hooks Class Initialized
DEBUG - 2010-06-30 14:10:07 --> URI Class Initialized
DEBUG - 2010-06-30 14:10:07 --> Router Class Initialized
DEBUG - 2010-06-30 14:10:07 --> Output Class Initialized
DEBUG - 2010-06-30 14:10:07 --> Input Class Initialized
DEBUG - 2010-06-30 14:10:08 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-30 14:10:08 --> Language Class Initialized
DEBUG - 2010-06-30 14:10:08 --> Loader Class Initialized
DEBUG - 2010-06-30 14:10:08 --> Helper loaded: context_helper
DEBUG - 2010-06-30 14:10:08 --> Helper loaded: kals_helper
DEBUG - 2010-06-30 14:10:08 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-30 14:10:08 --> Database Driver Class Initialized
DEBUG - 2010-06-30 14:10:08 --> Controller Class Initialized
DEBUG - 2010-06-30 14:10:08 --> Unit Testing Class Initialized
DEBUG - 2010-06-30 14:10:08 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-30 14:10:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:08 --> Helper loaded: email_helper
DEBUG - 2010-06-30 14:10:08 --> User Agent Class Initialized
DEBUG - 2010-06-30 14:10:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:08 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:08 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:08 --> Session Class Initialized
DEBUG - 2010-06-30 14:10:08 --> Helper loaded: string_helper
DEBUG - 2010-06-30 14:10:08 --> Session routines successfully run
DEBUG - 2010-06-30 14:10:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:13 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:13 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:13 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:13 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:13 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:13 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:13 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:13 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-30 14:10:13 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:13 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:14 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:14 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:14 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:14 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:14 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:14 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:14 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:14 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:14 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:14 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:14 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:14 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:14 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:14 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:14 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:14 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:14 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:14 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:14 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:14 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:14 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:14 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:14 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:14 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:14 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:14 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:14 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:14 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:15 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:15 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:15 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:15 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:15 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:15 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:15 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:15 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:15 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:15 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:15 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:15 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:15 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:15 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:15 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:15 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:15 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:15 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:15 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:15 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:16 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:16 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:16 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:16 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:16 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:16 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:16 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:16 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:16 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:16 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:16 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:16 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:16 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:16 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:16 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:16 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:16 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:16 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:16 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:16 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:16 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:16 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:16 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:17 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:17 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:17 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:17 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:17 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:17 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:17 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:17 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:17 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:17 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:10:17 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-30 14:10:17 --> Final output sent to browser
DEBUG - 2010-06-30 14:10:17 --> Total execution time: 9.6401
DEBUG - 2010-06-30 14:11:02 --> Config Class Initialized
DEBUG - 2010-06-30 14:11:03 --> Hooks Class Initialized
DEBUG - 2010-06-30 14:11:03 --> URI Class Initialized
DEBUG - 2010-06-30 14:11:03 --> Router Class Initialized
DEBUG - 2010-06-30 14:11:03 --> Output Class Initialized
DEBUG - 2010-06-30 14:11:03 --> Input Class Initialized
DEBUG - 2010-06-30 14:11:03 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-30 14:11:03 --> Language Class Initialized
DEBUG - 2010-06-30 14:11:03 --> Loader Class Initialized
DEBUG - 2010-06-30 14:11:03 --> Helper loaded: context_helper
DEBUG - 2010-06-30 14:11:03 --> Helper loaded: kals_helper
DEBUG - 2010-06-30 14:11:03 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-30 14:11:03 --> Database Driver Class Initialized
DEBUG - 2010-06-30 14:11:03 --> Controller Class Initialized
DEBUG - 2010-06-30 14:11:03 --> Unit Testing Class Initialized
DEBUG - 2010-06-30 14:11:03 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-30 14:11:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:03 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:03 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:03 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:03 --> Helper loaded: email_helper
DEBUG - 2010-06-30 14:11:03 --> User Agent Class Initialized
DEBUG - 2010-06-30 14:11:03 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:03 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:04 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:04 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:04 --> Session Class Initialized
DEBUG - 2010-06-30 14:11:04 --> Helper loaded: string_helper
DEBUG - 2010-06-30 14:11:04 --> Session routines successfully run
DEBUG - 2010-06-30 14:11:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:05 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-30 14:11:05 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:05 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:05 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:05 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:05 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:05 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:05 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:05 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:05 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:05 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:05 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:06 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:06 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:06 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:06 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:06 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:06 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:06 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:06 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:06 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:06 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:06 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:06 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:06 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:06 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:06 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:06 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:06 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:06 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:07 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:07 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:07 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:07 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:07 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:07 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:08 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:08 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:08 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:08 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:08 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:08 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:08 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:08 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:08 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:08 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:08 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:09 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:09 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:09 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:09 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:10 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:10 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:10 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:10 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:10 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:10 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:10 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:10 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:10 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:10 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:10 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:10 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:10 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:10 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:10 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-30 14:11:10 --> Final output sent to browser
DEBUG - 2010-06-30 14:11:10 --> Total execution time: 7.6896
DEBUG - 2010-06-30 14:11:28 --> Config Class Initialized
DEBUG - 2010-06-30 14:11:28 --> Hooks Class Initialized
DEBUG - 2010-06-30 14:11:28 --> URI Class Initialized
DEBUG - 2010-06-30 14:11:28 --> Router Class Initialized
DEBUG - 2010-06-30 14:11:28 --> Output Class Initialized
DEBUG - 2010-06-30 14:11:28 --> Input Class Initialized
DEBUG - 2010-06-30 14:11:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-30 14:11:29 --> Language Class Initialized
DEBUG - 2010-06-30 14:11:29 --> Loader Class Initialized
DEBUG - 2010-06-30 14:11:29 --> Helper loaded: context_helper
DEBUG - 2010-06-30 14:11:29 --> Helper loaded: kals_helper
DEBUG - 2010-06-30 14:11:29 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-30 14:11:29 --> Database Driver Class Initialized
DEBUG - 2010-06-30 14:11:29 --> Controller Class Initialized
DEBUG - 2010-06-30 14:11:29 --> Unit Testing Class Initialized
DEBUG - 2010-06-30 14:11:29 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-30 14:11:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:29 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:29 --> Helper loaded: email_helper
DEBUG - 2010-06-30 14:11:29 --> User Agent Class Initialized
DEBUG - 2010-06-30 14:11:29 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:29 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:29 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:29 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:29 --> Session Class Initialized
DEBUG - 2010-06-30 14:11:30 --> Helper loaded: string_helper
DEBUG - 2010-06-30 14:11:30 --> Session routines successfully run
DEBUG - 2010-06-30 14:11:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:34 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:34 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:34 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:34 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:34 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-30 14:11:34 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:34 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:34 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:34 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:34 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:35 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:35 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:35 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:35 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:35 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:35 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:35 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:35 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:35 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:35 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:35 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:35 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:35 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:35 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:35 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:35 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:35 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:35 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:35 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:35 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:35 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:35 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:36 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:36 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:36 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:36 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:36 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:36 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:36 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:36 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:36 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:36 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:36 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:36 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:36 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:36 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:36 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:36 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:36 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:36 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:36 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:37 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:37 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:37 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:37 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:37 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:37 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:37 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:37 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:37 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:37 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:37 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:37 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:37 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:37 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:37 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:38 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:38 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:38 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:38 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:38 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:38 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:38 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:38 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:38 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:38 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:38 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:38 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:38 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:38 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:38 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:38 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:38 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:38 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:38 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:11:38 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-30 14:11:38 --> Final output sent to browser
DEBUG - 2010-06-30 14:11:38 --> Total execution time: 10.1696
DEBUG - 2010-06-30 14:12:34 --> Config Class Initialized
DEBUG - 2010-06-30 14:12:34 --> Hooks Class Initialized
DEBUG - 2010-06-30 14:12:34 --> URI Class Initialized
DEBUG - 2010-06-30 14:12:34 --> Router Class Initialized
DEBUG - 2010-06-30 14:12:34 --> Output Class Initialized
DEBUG - 2010-06-30 14:12:34 --> Input Class Initialized
DEBUG - 2010-06-30 14:12:34 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-30 14:12:34 --> Language Class Initialized
DEBUG - 2010-06-30 14:12:34 --> Loader Class Initialized
DEBUG - 2010-06-30 14:12:34 --> Helper loaded: context_helper
DEBUG - 2010-06-30 14:12:34 --> Helper loaded: kals_helper
DEBUG - 2010-06-30 14:12:34 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-30 14:12:34 --> Database Driver Class Initialized
DEBUG - 2010-06-30 14:12:34 --> Controller Class Initialized
DEBUG - 2010-06-30 14:12:34 --> Unit Testing Class Initialized
DEBUG - 2010-06-30 14:12:35 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-30 14:12:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:35 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:35 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:35 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:35 --> Helper loaded: email_helper
DEBUG - 2010-06-30 14:12:35 --> User Agent Class Initialized
DEBUG - 2010-06-30 14:12:35 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:35 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:35 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:35 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:35 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:35 --> Session Class Initialized
DEBUG - 2010-06-30 14:12:35 --> Helper loaded: string_helper
DEBUG - 2010-06-30 14:12:35 --> Session routines successfully run
DEBUG - 2010-06-30 14:12:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:36 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:36 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:36 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:36 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:36 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:37 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:37 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-30 14:12:37 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:37 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:37 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:37 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:37 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:37 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:37 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:37 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:37 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:37 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:37 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:37 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:37 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:37 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:37 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:37 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:37 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:38 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:38 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:38 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:38 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:38 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:38 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:38 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:38 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:38 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:38 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:38 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:38 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:38 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:38 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:38 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:38 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:38 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:38 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:38 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:38 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:39 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:39 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:39 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:39 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:39 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:39 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:39 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:39 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:39 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:39 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:39 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:39 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:39 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:39 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:39 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:39 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:39 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:40 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:40 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:40 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:40 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:40 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:40 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:40 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:40 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:40 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:40 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:40 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:40 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:40 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:40 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:40 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:40 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:40 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:41 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:41 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:41 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:41 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:41 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:41 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:41 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:41 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:12:41 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-30 14:12:41 --> Final output sent to browser
DEBUG - 2010-06-30 14:12:41 --> Total execution time: 7.1600
DEBUG - 2010-06-30 14:14:11 --> Config Class Initialized
DEBUG - 2010-06-30 14:14:11 --> Hooks Class Initialized
DEBUG - 2010-06-30 14:14:11 --> URI Class Initialized
DEBUG - 2010-06-30 14:14:11 --> Router Class Initialized
DEBUG - 2010-06-30 14:14:11 --> Output Class Initialized
DEBUG - 2010-06-30 14:14:11 --> Input Class Initialized
DEBUG - 2010-06-30 14:14:11 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-30 14:14:11 --> Language Class Initialized
DEBUG - 2010-06-30 14:14:11 --> Loader Class Initialized
DEBUG - 2010-06-30 14:14:11 --> Helper loaded: context_helper
DEBUG - 2010-06-30 14:14:11 --> Helper loaded: kals_helper
DEBUG - 2010-06-30 14:14:11 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-30 14:14:11 --> Database Driver Class Initialized
DEBUG - 2010-06-30 14:14:12 --> Controller Class Initialized
DEBUG - 2010-06-30 14:14:12 --> Unit Testing Class Initialized
DEBUG - 2010-06-30 14:14:12 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-30 14:14:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:12 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:12 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:12 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:12 --> Helper loaded: email_helper
DEBUG - 2010-06-30 14:14:12 --> User Agent Class Initialized
DEBUG - 2010-06-30 14:14:12 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:12 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:12 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:12 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:12 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:12 --> Session Class Initialized
DEBUG - 2010-06-30 14:14:12 --> Helper loaded: string_helper
DEBUG - 2010-06-30 14:14:12 --> Session routines successfully run
DEBUG - 2010-06-30 14:14:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:13 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:13 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:14 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:14 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:14 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:14 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:14 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:14 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-30 14:14:14 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:14 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:14 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:14 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:14 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:14 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:14 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:14 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:14 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:14 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:14 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:15 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:15 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:15 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:15 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:15 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:15 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:15 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:15 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:15 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:15 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:15 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:15 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:15 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:15 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:16 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:16 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:16 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:16 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:16 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:16 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:16 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:16 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:16 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:16 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:16 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:16 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:17 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:17 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:17 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:17 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:17 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:17 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:17 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:17 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:17 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:18 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:18 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:18 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:18 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:18 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:18 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:18 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:18 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:18 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:18 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:18 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:19 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:19 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:19 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:20 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:20 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:20 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:20 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:20 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:20 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:20 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:20 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:21 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:21 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:21 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:21 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:21 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:21 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:21 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:21 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:21 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:14:21 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-30 14:14:21 --> Final output sent to browser
DEBUG - 2010-06-30 14:14:21 --> Total execution time: 10.2626
DEBUG - 2010-06-30 14:15:21 --> Config Class Initialized
DEBUG - 2010-06-30 14:15:21 --> Hooks Class Initialized
DEBUG - 2010-06-30 14:15:21 --> URI Class Initialized
DEBUG - 2010-06-30 14:15:21 --> Router Class Initialized
DEBUG - 2010-06-30 14:15:21 --> Output Class Initialized
DEBUG - 2010-06-30 14:15:21 --> Input Class Initialized
DEBUG - 2010-06-30 14:15:21 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-30 14:15:21 --> Language Class Initialized
DEBUG - 2010-06-30 14:15:21 --> Loader Class Initialized
DEBUG - 2010-06-30 14:15:21 --> Helper loaded: context_helper
DEBUG - 2010-06-30 14:15:21 --> Helper loaded: kals_helper
DEBUG - 2010-06-30 14:15:21 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-30 14:15:21 --> Database Driver Class Initialized
DEBUG - 2010-06-30 14:15:21 --> Controller Class Initialized
DEBUG - 2010-06-30 14:15:21 --> Unit Testing Class Initialized
DEBUG - 2010-06-30 14:15:21 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-30 14:15:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:22 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:22 --> Helper loaded: email_helper
DEBUG - 2010-06-30 14:15:22 --> User Agent Class Initialized
DEBUG - 2010-06-30 14:15:22 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:22 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:22 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:22 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:22 --> Session Class Initialized
DEBUG - 2010-06-30 14:15:22 --> Helper loaded: string_helper
DEBUG - 2010-06-30 14:15:22 --> Session routines successfully run
DEBUG - 2010-06-30 14:15:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:23 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:23 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:23 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:23 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:24 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:24 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:24 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:24 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-30 14:15:24 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:24 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:24 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:24 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:24 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:24 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:24 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:24 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:24 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:24 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:24 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:24 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:24 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:25 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:25 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:25 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:25 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:25 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:25 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:25 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:25 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:25 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:25 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:25 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:25 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:25 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:25 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:25 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:26 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:26 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:26 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:26 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:26 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:26 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:26 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:26 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:26 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:26 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:26 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:26 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:26 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:27 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:27 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:27 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:27 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:27 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:27 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:27 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:27 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:27 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:27 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:27 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:27 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:27 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:27 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:27 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:27 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:28 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:28 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:28 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:28 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:28 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:28 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:28 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:28 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:28 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:28 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:28 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:28 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:29 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:29 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:29 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:15:29 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-30 14:15:29 --> Final output sent to browser
DEBUG - 2010-06-30 14:15:29 --> Total execution time: 8.1441
DEBUG - 2010-06-30 14:18:29 --> Config Class Initialized
DEBUG - 2010-06-30 14:18:29 --> Hooks Class Initialized
DEBUG - 2010-06-30 14:18:29 --> URI Class Initialized
DEBUG - 2010-06-30 14:18:29 --> Router Class Initialized
DEBUG - 2010-06-30 14:18:29 --> Output Class Initialized
DEBUG - 2010-06-30 14:18:29 --> Input Class Initialized
DEBUG - 2010-06-30 14:18:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-30 14:18:29 --> Language Class Initialized
DEBUG - 2010-06-30 14:18:29 --> Loader Class Initialized
DEBUG - 2010-06-30 14:18:29 --> Helper loaded: context_helper
DEBUG - 2010-06-30 14:18:30 --> Helper loaded: kals_helper
DEBUG - 2010-06-30 14:18:30 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-30 14:18:30 --> Database Driver Class Initialized
DEBUG - 2010-06-30 14:18:30 --> Controller Class Initialized
DEBUG - 2010-06-30 14:18:30 --> Unit Testing Class Initialized
DEBUG - 2010-06-30 14:18:30 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-30 14:18:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:30 --> Helper loaded: email_helper
DEBUG - 2010-06-30 14:18:30 --> User Agent Class Initialized
DEBUG - 2010-06-30 14:18:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:31 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:31 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:31 --> Session Class Initialized
DEBUG - 2010-06-30 14:18:31 --> Helper loaded: string_helper
ERROR - 2010-06-30 14:18:31 --> Severity: Warning  --> fopen(D:\xampp\htdocs\CodeIgniter_1.7.2/system/logs/log-2010-06-30.php) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Log.php 97
DEBUG - 2010-06-30 14:18:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:32 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:32 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-30 14:18:32 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:32 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:33 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:33 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:33 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:33 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:33 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:33 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:33 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:33 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:33 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:33 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:33 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:33 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:33 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:33 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:33 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:33 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:34 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:34 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:34 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:34 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:34 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:34 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:34 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:34 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:34 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:34 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:34 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:34 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:34 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:34 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:35 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:35 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:35 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:35 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:35 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:35 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:35 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:35 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:35 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:35 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:35 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:35 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:35 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:35 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:35 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:35 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:35 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:36 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:36 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:36 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:36 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:36 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:36 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:36 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:36 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:36 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:36 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:36 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:36 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:36 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:36 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:37 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:37 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:37 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:37 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:37 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:37 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:37 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:37 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:37 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:37 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:37 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:37 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:37 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:37 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:37 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:37 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:38 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:38 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:38 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:38 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:38 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:38 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:18:38 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-30 14:18:38 --> Final output sent to browser
DEBUG - 2010-06-30 14:18:38 --> Total execution time: 9.0767
DEBUG - 2010-06-30 14:33:57 --> Config Class Initialized
DEBUG - 2010-06-30 14:33:57 --> Hooks Class Initialized
DEBUG - 2010-06-30 14:33:57 --> URI Class Initialized
DEBUG - 2010-06-30 14:33:57 --> Router Class Initialized
DEBUG - 2010-06-30 14:33:58 --> Output Class Initialized
DEBUG - 2010-06-30 14:33:58 --> Input Class Initialized
DEBUG - 2010-06-30 14:33:58 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-30 14:33:58 --> Language Class Initialized
DEBUG - 2010-06-30 14:33:58 --> Loader Class Initialized
DEBUG - 2010-06-30 14:33:58 --> Helper loaded: context_helper
DEBUG - 2010-06-30 14:33:58 --> Helper loaded: kals_helper
DEBUG - 2010-06-30 14:33:58 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-30 14:33:58 --> Database Driver Class Initialized
DEBUG - 2010-06-30 14:33:58 --> Controller Class Initialized
DEBUG - 2010-06-30 14:33:58 --> Unit Testing Class Initialized
DEBUG - 2010-06-30 14:33:58 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-30 14:33:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:33:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:33:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:33:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:33:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:33:59 --> Helper loaded: email_helper
DEBUG - 2010-06-30 14:33:59 --> User Agent Class Initialized
DEBUG - 2010-06-30 14:33:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:33:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:33:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:33:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:33:59 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:33:59 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:33:59 --> Session Class Initialized
DEBUG - 2010-06-30 14:33:59 --> Helper loaded: string_helper
DEBUG - 2010-06-30 14:33:59 --> Session routines successfully run
DEBUG - 2010-06-30 14:34:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:03 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:03 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:04 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:04 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:04 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:04 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-30 14:34:04 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:04 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:04 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:04 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:04 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:04 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:04 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:04 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:05 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:05 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:05 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:05 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:05 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:05 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:05 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:05 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:05 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:05 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:05 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:05 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:05 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:05 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:06 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:06 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:06 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:06 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:06 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:06 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:06 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:06 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:06 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:06 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:06 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:06 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:07 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:07 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:07 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:07 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:07 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:07 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:07 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:08 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:08 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:08 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:08 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:08 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:08 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:08 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:08 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:08 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:08 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:09 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:09 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:09 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:09 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:09 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:09 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:09 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:09 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:09 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:09 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:09 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:10 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:10 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:10 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:10 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:10 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:10 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-30 14:34:10 --> Final output sent to browser
DEBUG - 2010-06-30 14:34:10 --> Total execution time: 12.6545
DEBUG - 2010-06-30 14:34:57 --> Config Class Initialized
DEBUG - 2010-06-30 14:34:58 --> Hooks Class Initialized
DEBUG - 2010-06-30 14:34:58 --> URI Class Initialized
DEBUG - 2010-06-30 14:34:58 --> Router Class Initialized
DEBUG - 2010-06-30 14:34:58 --> Output Class Initialized
DEBUG - 2010-06-30 14:34:58 --> Input Class Initialized
DEBUG - 2010-06-30 14:34:58 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-30 14:34:58 --> Language Class Initialized
DEBUG - 2010-06-30 14:34:59 --> Loader Class Initialized
DEBUG - 2010-06-30 14:34:59 --> Helper loaded: context_helper
DEBUG - 2010-06-30 14:34:59 --> Helper loaded: kals_helper
DEBUG - 2010-06-30 14:34:59 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-30 14:34:59 --> Database Driver Class Initialized
DEBUG - 2010-06-30 14:34:59 --> Controller Class Initialized
DEBUG - 2010-06-30 14:34:59 --> Unit Testing Class Initialized
DEBUG - 2010-06-30 14:34:59 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-30 14:34:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:34:59 --> Helper loaded: email_helper
DEBUG - 2010-06-30 14:35:00 --> User Agent Class Initialized
DEBUG - 2010-06-30 14:35:00 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:00 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:00 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:00 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:00 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:00 --> Session Class Initialized
DEBUG - 2010-06-30 14:35:00 --> Helper loaded: string_helper
DEBUG - 2010-06-30 14:35:01 --> Session routines successfully run
DEBUG - 2010-06-30 14:35:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:02 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:02 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:02 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:03 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:03 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:03 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:03 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:03 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-30 14:35:03 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:03 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:03 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:03 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:03 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:03 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:03 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:04 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:04 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:04 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:04 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:04 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:04 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:04 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:04 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:04 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:04 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:04 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:04 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:04 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:05 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:05 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:05 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:05 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:05 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:05 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:05 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:05 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:05 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:05 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:06 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:06 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:06 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:06 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:06 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:06 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:06 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:06 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:06 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:06 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:06 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:06 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:06 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:07 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:07 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:07 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:07 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:07 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:07 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:07 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:07 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:08 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:08 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:08 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:08 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:08 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:35:08 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:04 --> Config Class Initialized
DEBUG - 2010-06-30 14:36:04 --> Hooks Class Initialized
DEBUG - 2010-06-30 14:36:04 --> URI Class Initialized
DEBUG - 2010-06-30 14:36:04 --> Router Class Initialized
DEBUG - 2010-06-30 14:36:04 --> Output Class Initialized
DEBUG - 2010-06-30 14:36:04 --> Input Class Initialized
DEBUG - 2010-06-30 14:36:04 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-30 14:36:05 --> Language Class Initialized
DEBUG - 2010-06-30 14:36:05 --> Loader Class Initialized
DEBUG - 2010-06-30 14:36:05 --> Helper loaded: context_helper
DEBUG - 2010-06-30 14:36:05 --> Helper loaded: kals_helper
DEBUG - 2010-06-30 14:36:05 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-30 14:36:05 --> Database Driver Class Initialized
DEBUG - 2010-06-30 14:36:05 --> Controller Class Initialized
DEBUG - 2010-06-30 14:36:05 --> Unit Testing Class Initialized
DEBUG - 2010-06-30 14:36:05 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-30 14:36:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:05 --> Helper loaded: email_helper
DEBUG - 2010-06-30 14:36:06 --> User Agent Class Initialized
DEBUG - 2010-06-30 14:36:06 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:06 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:06 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:06 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:06 --> Session Class Initialized
DEBUG - 2010-06-30 14:36:06 --> Helper loaded: string_helper
DEBUG - 2010-06-30 14:36:06 --> Session routines successfully run
DEBUG - 2010-06-30 14:36:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:08 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-30 14:36:08 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:08 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:08 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:08 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:08 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:08 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:08 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:08 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:08 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:09 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:09 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:09 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:09 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:09 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:09 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:10 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:10 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:10 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:10 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:10 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:10 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:10 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:10 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:10 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:10 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:10 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:10 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:10 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:11 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:11 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:11 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:11 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:11 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:11 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:11 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:11 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:11 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:11 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:11 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:11 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:11 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:12 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:12 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:12 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:12 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:12 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:12 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:12 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:12 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:12 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:12 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:12 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:12 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:12 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:13 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:13 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:13 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:13 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:13 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:13 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:13 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:13 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:13 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:13 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:13 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:13 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:13 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:13 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:14 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:14 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:14 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:14 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:14 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:14 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:14 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:14 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:14 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:14 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:36:14 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-30 14:36:14 --> Final output sent to browser
DEBUG - 2010-06-30 14:36:14 --> Total execution time: 10.3601
DEBUG - 2010-06-30 14:38:43 --> Config Class Initialized
DEBUG - 2010-06-30 14:38:43 --> Hooks Class Initialized
DEBUG - 2010-06-30 14:38:43 --> URI Class Initialized
DEBUG - 2010-06-30 14:38:43 --> Router Class Initialized
DEBUG - 2010-06-30 14:38:43 --> Output Class Initialized
DEBUG - 2010-06-30 14:38:43 --> Input Class Initialized
DEBUG - 2010-06-30 14:38:43 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-30 14:38:43 --> Language Class Initialized
DEBUG - 2010-06-30 14:38:43 --> Loader Class Initialized
DEBUG - 2010-06-30 14:38:43 --> Helper loaded: context_helper
DEBUG - 2010-06-30 14:38:43 --> Helper loaded: kals_helper
DEBUG - 2010-06-30 14:38:43 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-30 14:38:44 --> Database Driver Class Initialized
DEBUG - 2010-06-30 14:38:44 --> Controller Class Initialized
DEBUG - 2010-06-30 14:38:44 --> Unit Testing Class Initialized
DEBUG - 2010-06-30 14:38:44 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-30 14:38:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:44 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:44 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:44 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:44 --> Helper loaded: email_helper
DEBUG - 2010-06-30 14:38:44 --> User Agent Class Initialized
DEBUG - 2010-06-30 14:38:44 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:45 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:45 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:45 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:45 --> Session Class Initialized
DEBUG - 2010-06-30 14:38:45 --> Helper loaded: string_helper
DEBUG - 2010-06-30 14:38:45 --> Session routines successfully run
DEBUG - 2010-06-30 14:38:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:46 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:46 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:46 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:46 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:47 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:47 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:47 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:47 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-30 14:38:47 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:47 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:47 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:47 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:47 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:47 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:47 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:47 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:47 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:48 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:48 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:48 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:48 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:48 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:48 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:48 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:48 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:48 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:48 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:48 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:49 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:49 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:49 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:49 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:49 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:49 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:49 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:49 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:49 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:49 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:49 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:49 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:50 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:50 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:50 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:50 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:50 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:50 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:50 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:50 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:50 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:50 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:50 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:51 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:51 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:51 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:51 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:51 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:51 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:51 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:51 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:51 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:51 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:51 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:51 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:51 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:52 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:52 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:52 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:52 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:52 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:52 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:52 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:52 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:52 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:52 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:52 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:53 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:53 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:53 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:53 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:53 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:53 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:53 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:53 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:53 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:53 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:53 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:53 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:53 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:54 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:54 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:54 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:38:54 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-30 14:38:54 --> Final output sent to browser
DEBUG - 2010-06-30 14:38:54 --> Total execution time: 11.2686
DEBUG - 2010-06-30 14:41:11 --> Config Class Initialized
DEBUG - 2010-06-30 14:41:11 --> Hooks Class Initialized
DEBUG - 2010-06-30 14:41:11 --> URI Class Initialized
DEBUG - 2010-06-30 14:41:11 --> Router Class Initialized
DEBUG - 2010-06-30 14:41:11 --> Output Class Initialized
DEBUG - 2010-06-30 14:41:11 --> Input Class Initialized
DEBUG - 2010-06-30 14:41:12 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-30 14:41:12 --> Language Class Initialized
DEBUG - 2010-06-30 14:41:12 --> Loader Class Initialized
DEBUG - 2010-06-30 14:41:12 --> Helper loaded: context_helper
DEBUG - 2010-06-30 14:41:12 --> Helper loaded: kals_helper
DEBUG - 2010-06-30 14:41:12 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-30 14:41:12 --> Database Driver Class Initialized
DEBUG - 2010-06-30 14:41:12 --> Controller Class Initialized
DEBUG - 2010-06-30 14:41:12 --> Unit Testing Class Initialized
DEBUG - 2010-06-30 14:41:12 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-30 14:41:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:13 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:13 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:13 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:13 --> Helper loaded: email_helper
DEBUG - 2010-06-30 14:41:13 --> User Agent Class Initialized
DEBUG - 2010-06-30 14:41:13 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:13 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:13 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:13 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:13 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:13 --> Session Class Initialized
DEBUG - 2010-06-30 14:41:13 --> Helper loaded: string_helper
DEBUG - 2010-06-30 14:41:13 --> Session routines successfully run
DEBUG - 2010-06-30 14:41:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:15 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:15 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:15 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:15 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:15 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-30 14:41:15 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:15 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:15 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:16 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:16 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:16 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:16 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:16 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:16 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:16 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:16 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:16 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:16 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:16 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:16 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:16 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:17 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:17 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:17 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:17 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:17 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:17 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:17 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:17 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:17 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:17 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:17 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:17 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:18 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:18 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:18 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:18 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:18 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:18 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:18 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:18 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:18 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:19 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:19 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:19 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:19 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:19 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:19 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:19 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:19 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:19 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:19 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:19 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:19 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:20 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:20 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:20 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:20 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:20 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:20 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:20 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:20 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:20 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:20 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:20 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:21 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:21 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:21 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:21 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:21 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:21 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:21 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:21 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:21 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:21 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:21 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:21 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:22 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:22 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:22 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:22 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:22 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:22 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:22 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:22 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:22 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:22 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:22 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:41:22 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-30 14:41:22 --> Final output sent to browser
DEBUG - 2010-06-30 14:41:23 --> Total execution time: 11.4475
DEBUG - 2010-06-30 14:42:35 --> Config Class Initialized
DEBUG - 2010-06-30 14:42:35 --> Hooks Class Initialized
DEBUG - 2010-06-30 14:42:35 --> URI Class Initialized
DEBUG - 2010-06-30 14:42:35 --> Router Class Initialized
DEBUG - 2010-06-30 14:42:35 --> Output Class Initialized
DEBUG - 2010-06-30 14:42:35 --> Input Class Initialized
DEBUG - 2010-06-30 14:42:35 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-30 14:42:35 --> Language Class Initialized
DEBUG - 2010-06-30 14:42:35 --> Loader Class Initialized
DEBUG - 2010-06-30 14:42:36 --> Helper loaded: context_helper
DEBUG - 2010-06-30 14:42:36 --> Helper loaded: kals_helper
DEBUG - 2010-06-30 14:42:36 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-30 14:42:36 --> Database Driver Class Initialized
DEBUG - 2010-06-30 14:42:36 --> Controller Class Initialized
DEBUG - 2010-06-30 14:42:36 --> Unit Testing Class Initialized
DEBUG - 2010-06-30 14:42:36 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-30 14:42:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:36 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:36 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:36 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:37 --> Helper loaded: email_helper
DEBUG - 2010-06-30 14:42:37 --> User Agent Class Initialized
DEBUG - 2010-06-30 14:42:37 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:37 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:37 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:37 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:37 --> Session Class Initialized
DEBUG - 2010-06-30 14:42:37 --> Helper loaded: string_helper
DEBUG - 2010-06-30 14:42:37 --> Session routines successfully run
DEBUG - 2010-06-30 14:42:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:39 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:39 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:39 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:39 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-30 14:42:39 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:39 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:40 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:40 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:40 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:40 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:40 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:40 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:40 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:40 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:40 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:40 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:40 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:40 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:40 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:41 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:41 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:41 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:41 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:41 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:41 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:41 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:41 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:41 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:41 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:41 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:41 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:42 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:42 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:42 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:42 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:42 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:42 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:42 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:42 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:42 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:42 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:42 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:43 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:43 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:43 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:43 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:43 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:43 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:43 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:43 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:43 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:43 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:43 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:43 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:43 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:44 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:44 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:44 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:44 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:44 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:44 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:44 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:44 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:44 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:44 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:44 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:45 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:45 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:45 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:45 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:45 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:45 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:45 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:45 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:45 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:45 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:46 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:46 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:46 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:46 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:46 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:46 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:46 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:46 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:46 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:46 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:46 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:46 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:47 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:47 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:42:47 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-30 14:42:47 --> Final output sent to browser
DEBUG - 2010-06-30 14:42:47 --> Total execution time: 12.0656
DEBUG - 2010-06-30 14:45:03 --> Config Class Initialized
DEBUG - 2010-06-30 14:45:03 --> Hooks Class Initialized
DEBUG - 2010-06-30 14:45:03 --> URI Class Initialized
DEBUG - 2010-06-30 14:45:03 --> Router Class Initialized
DEBUG - 2010-06-30 14:45:03 --> Output Class Initialized
DEBUG - 2010-06-30 14:45:03 --> Input Class Initialized
DEBUG - 2010-06-30 14:45:03 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-30 14:45:03 --> Language Class Initialized
DEBUG - 2010-06-30 14:45:03 --> Loader Class Initialized
DEBUG - 2010-06-30 14:45:03 --> Helper loaded: context_helper
DEBUG - 2010-06-30 14:45:03 --> Helper loaded: kals_helper
DEBUG - 2010-06-30 14:45:04 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-30 14:45:04 --> Database Driver Class Initialized
DEBUG - 2010-06-30 14:45:04 --> Controller Class Initialized
DEBUG - 2010-06-30 14:45:04 --> Unit Testing Class Initialized
DEBUG - 2010-06-30 14:45:04 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-30 14:45:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:04 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:04 --> Helper loaded: email_helper
DEBUG - 2010-06-30 14:45:04 --> User Agent Class Initialized
DEBUG - 2010-06-30 14:45:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:05 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:05 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:05 --> Session Class Initialized
DEBUG - 2010-06-30 14:45:05 --> Helper loaded: string_helper
DEBUG - 2010-06-30 14:45:05 --> Session routines successfully run
DEBUG - 2010-06-30 14:45:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:06 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:07 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-30 14:45:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:07 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:07 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:08 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:08 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:08 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:08 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:08 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:08 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:08 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:08 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:08 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:08 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:08 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:08 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:09 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:09 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:09 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:09 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:10 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:10 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:10 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:10 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:10 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:10 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:10 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:10 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:10 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:10 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:10 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:11 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:11 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:11 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:11 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:11 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:11 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:11 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:11 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:11 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:12 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:12 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:12 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:12 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:12 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:12 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:12 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:12 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:12 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:12 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:12 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:13 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:13 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:13 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:13 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:13 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:13 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:13 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:13 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:13 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:13 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:13 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:14 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:14 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:14 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:14 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:14 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:14 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:14 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:14 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:14 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:14 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:14 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:15 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:15 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:15 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:15 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:15 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:45:15 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-30 14:45:15 --> Final output sent to browser
DEBUG - 2010-06-30 14:45:15 --> Total execution time: 12.3960
DEBUG - 2010-06-30 14:52:35 --> Config Class Initialized
DEBUG - 2010-06-30 14:52:35 --> Hooks Class Initialized
DEBUG - 2010-06-30 14:52:35 --> URI Class Initialized
DEBUG - 2010-06-30 14:52:35 --> Router Class Initialized
DEBUG - 2010-06-30 14:52:35 --> Output Class Initialized
DEBUG - 2010-06-30 14:52:35 --> Input Class Initialized
DEBUG - 2010-06-30 14:52:35 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-30 14:52:36 --> Language Class Initialized
DEBUG - 2010-06-30 14:52:36 --> Loader Class Initialized
DEBUG - 2010-06-30 14:52:36 --> Helper loaded: context_helper
DEBUG - 2010-06-30 14:52:36 --> Helper loaded: kals_helper
DEBUG - 2010-06-30 14:52:36 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-30 14:52:36 --> Database Driver Class Initialized
DEBUG - 2010-06-30 14:52:36 --> Controller Class Initialized
DEBUG - 2010-06-30 14:52:36 --> Unit Testing Class Initialized
DEBUG - 2010-06-30 14:52:36 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-30 14:52:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:37 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:37 --> Helper loaded: email_helper
DEBUG - 2010-06-30 14:52:37 --> User Agent Class Initialized
DEBUG - 2010-06-30 14:52:37 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:37 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:37 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:37 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:38 --> Session Class Initialized
DEBUG - 2010-06-30 14:52:38 --> Helper loaded: string_helper
DEBUG - 2010-06-30 14:52:38 --> Session routines successfully run
DEBUG - 2010-06-30 14:52:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:39 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:39 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:39 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:40 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-30 14:52:40 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:40 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:40 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:40 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:40 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:40 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:40 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:40 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:40 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:40 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:41 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:41 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:41 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:41 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:41 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:41 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:41 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:41 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:41 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:41 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:41 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:42 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:42 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:42 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:42 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:42 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:42 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:42 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:42 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:42 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:43 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:43 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:43 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:43 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:43 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:43 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:43 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:43 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:43 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:43 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:43 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:43 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:44 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:44 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:44 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:44 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:44 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:44 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:44 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:44 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:44 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:45 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:45 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:45 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:45 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:45 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:45 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:45 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:45 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:45 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:46 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:46 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:46 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:46 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:46 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:46 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:46 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:46 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:46 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:46 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:46 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:47 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:47 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:47 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:47 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:47 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:47 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:47 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:47 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:47 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:47 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:47 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:47 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:48 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:48 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:52:48 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-30 14:52:48 --> Final output sent to browser
DEBUG - 2010-06-30 14:52:48 --> Total execution time: 12.9058
DEBUG - 2010-06-30 14:57:13 --> Config Class Initialized
DEBUG - 2010-06-30 14:57:13 --> Hooks Class Initialized
DEBUG - 2010-06-30 14:57:13 --> URI Class Initialized
DEBUG - 2010-06-30 14:57:13 --> Router Class Initialized
DEBUG - 2010-06-30 14:57:13 --> Output Class Initialized
DEBUG - 2010-06-30 14:57:13 --> Input Class Initialized
DEBUG - 2010-06-30 14:57:13 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-30 14:57:13 --> Language Class Initialized
DEBUG - 2010-06-30 14:57:13 --> Loader Class Initialized
DEBUG - 2010-06-30 14:57:13 --> Helper loaded: context_helper
DEBUG - 2010-06-30 14:57:13 --> Helper loaded: kals_helper
DEBUG - 2010-06-30 14:57:14 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-30 14:57:14 --> Database Driver Class Initialized
DEBUG - 2010-06-30 14:57:14 --> Controller Class Initialized
DEBUG - 2010-06-30 14:57:14 --> Unit Testing Class Initialized
DEBUG - 2010-06-30 14:57:14 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-30 14:57:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:14 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:14 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:14 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:14 --> Helper loaded: email_helper
DEBUG - 2010-06-30 14:57:15 --> User Agent Class Initialized
DEBUG - 2010-06-30 14:57:15 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:15 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:15 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:15 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:15 --> Session Class Initialized
DEBUG - 2010-06-30 14:57:15 --> Helper loaded: string_helper
DEBUG - 2010-06-30 14:57:15 --> Session routines successfully run
DEBUG - 2010-06-30 14:57:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:20 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:20 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:20 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:20 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:20 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:20 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:20 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:20 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-30 14:57:21 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:21 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:21 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:21 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:21 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:21 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:21 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:21 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:21 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:21 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:21 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:22 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:22 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:22 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:22 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:22 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:22 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:22 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:22 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:22 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:22 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:22 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:23 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:23 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:23 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:23 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:23 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:23 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:23 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:23 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:23 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:23 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:24 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:24 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:24 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:24 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:24 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:24 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:24 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:24 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:24 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:24 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:24 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:25 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:25 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:25 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:25 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:25 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:26 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:26 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:26 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:26 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:26 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:26 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:26 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:26 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:27 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:27 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:27 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:27 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:27 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:27 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:27 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:27 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:27 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:28 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:28 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:28 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:28 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:28 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:28 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:28 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:28 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:28 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:29 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:29 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:29 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:29 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:29 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:29 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:29 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:29 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:29 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:29 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:30 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:30 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:30 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:30 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:30 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:30 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-30 14:57:30 --> Final output sent to browser
DEBUG - 2010-06-30 14:57:30 --> Total execution time: 17.5729
DEBUG - 2010-06-30 14:57:48 --> Config Class Initialized
DEBUG - 2010-06-30 14:57:48 --> Hooks Class Initialized
DEBUG - 2010-06-30 14:57:48 --> URI Class Initialized
DEBUG - 2010-06-30 14:57:48 --> Router Class Initialized
DEBUG - 2010-06-30 14:57:48 --> Output Class Initialized
DEBUG - 2010-06-30 14:57:48 --> Input Class Initialized
DEBUG - 2010-06-30 14:57:48 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-30 14:57:49 --> Language Class Initialized
DEBUG - 2010-06-30 14:57:49 --> Loader Class Initialized
DEBUG - 2010-06-30 14:57:49 --> Helper loaded: context_helper
DEBUG - 2010-06-30 14:57:49 --> Helper loaded: kals_helper
DEBUG - 2010-06-30 14:57:49 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-30 14:57:49 --> Database Driver Class Initialized
DEBUG - 2010-06-30 14:57:49 --> Controller Class Initialized
DEBUG - 2010-06-30 14:57:49 --> Unit Testing Class Initialized
DEBUG - 2010-06-30 14:57:49 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-30 14:57:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:50 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:50 --> Helper loaded: email_helper
DEBUG - 2010-06-30 14:57:50 --> User Agent Class Initialized
DEBUG - 2010-06-30 14:57:50 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:50 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:50 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:51 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:51 --> Session Class Initialized
DEBUG - 2010-06-30 14:57:51 --> Helper loaded: string_helper
DEBUG - 2010-06-30 14:57:51 --> Session routines successfully run
DEBUG - 2010-06-30 14:57:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:52 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:52 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:52 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:52 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:52 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:53 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:53 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:53 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-30 14:57:53 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:53 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:53 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:53 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:53 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:53 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:53 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:54 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:54 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:54 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:54 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:54 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:54 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:54 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:54 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:54 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:54 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:54 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:55 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:55 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:55 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:55 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:55 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:55 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:55 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:55 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:55 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:55 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:56 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:56 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:56 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:56 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:56 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:56 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:57 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:57 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:57 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:57 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:57 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:57 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:58 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:58 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:58 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:58 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:58 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:58 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:58 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:58 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:58 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:59 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:59 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:59 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:59 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:57:59 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:58:00 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:58:00 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:58:00 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:58:00 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:58:00 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:58:00 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:58:00 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:58:00 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:58:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:58:00 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:58:01 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:58:01 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:58:01 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:58:01 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:58:01 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:58:01 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:58:01 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:58:01 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:58:01 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:58:01 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:58:02 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:58:02 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:58:02 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:58:02 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:58:02 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:58:02 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:58:02 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:58:02 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:58:02 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:58:02 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-30 14:58:02 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-30 14:58:03 --> Final output sent to browser
DEBUG - 2010-06-30 14:58:03 --> Total execution time: 14.6943
