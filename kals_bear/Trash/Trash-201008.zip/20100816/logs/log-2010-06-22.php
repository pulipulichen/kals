<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2010-06-22 06:16:52 --> Config Class Initialized
DEBUG - 2010-06-22 06:16:52 --> Hooks Class Initialized
DEBUG - 2010-06-22 06:16:52 --> URI Class Initialized
DEBUG - 2010-06-22 06:16:52 --> Router Class Initialized
DEBUG - 2010-06-22 06:16:52 --> Output Class Initialized
DEBUG - 2010-06-22 06:16:52 --> Input Class Initialized
DEBUG - 2010-06-22 06:16:52 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 06:16:52 --> Language Class Initialized
DEBUG - 2010-06-22 06:16:52 --> Loader Class Initialized
DEBUG - 2010-06-22 06:16:52 --> Helper loaded: object_helper
DEBUG - 2010-06-22 06:16:52 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 06:16:52 --> Helper loaded: context_helper
DEBUG - 2010-06-22 06:16:52 --> Session Class Initialized
DEBUG - 2010-06-22 06:16:52 --> Helper loaded: string_helper
DEBUG - 2010-06-22 06:16:52 --> A session cookie was not found.
DEBUG - 2010-06-22 06:16:52 --> Session routines successfully run
DEBUG - 2010-06-22 06:16:52 --> Helper loaded: context_helper
DEBUG - 2010-06-22 06:16:52 --> Controller Class Initialized
DEBUG - 2010-06-22 06:16:52 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 06:16:52 --> Database Driver Class Initialized
DEBUG - 2010-06-22 06:16:52 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 06:16:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 06:16:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 06:16:52 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
DEBUG - 2010-06-22 06:16:52 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-22 06:16:52 --> Final output sent to browser
DEBUG - 2010-06-22 06:16:52 --> Total execution time: 0.3648
DEBUG - 2010-06-22 06:19:36 --> Config Class Initialized
DEBUG - 2010-06-22 06:19:36 --> Hooks Class Initialized
DEBUG - 2010-06-22 06:19:36 --> URI Class Initialized
DEBUG - 2010-06-22 06:19:36 --> Router Class Initialized
DEBUG - 2010-06-22 06:19:36 --> Output Class Initialized
DEBUG - 2010-06-22 06:19:36 --> Input Class Initialized
DEBUG - 2010-06-22 06:19:36 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 06:19:36 --> Language Class Initialized
DEBUG - 2010-06-22 06:19:36 --> Loader Class Initialized
DEBUG - 2010-06-22 06:19:36 --> Helper loaded: object_helper
DEBUG - 2010-06-22 06:19:36 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 06:19:36 --> Helper loaded: context_helper
DEBUG - 2010-06-22 06:19:36 --> Session Class Initialized
DEBUG - 2010-06-22 06:19:36 --> Helper loaded: string_helper
DEBUG - 2010-06-22 06:19:36 --> Session routines successfully run
DEBUG - 2010-06-22 06:19:36 --> Helper loaded: context_helper
DEBUG - 2010-06-22 06:19:36 --> Controller Class Initialized
DEBUG - 2010-06-22 06:19:36 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 06:19:36 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 06:19:36 --> Database Driver Class Initialized
DEBUG - 2010-06-22 06:19:36 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 06:19:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 06:19:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 06:19:36 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
DEBUG - 2010-06-22 06:19:36 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-22 06:19:36 --> Final output sent to browser
DEBUG - 2010-06-22 06:19:36 --> Total execution time: 0.1609
DEBUG - 2010-06-22 06:23:18 --> Config Class Initialized
DEBUG - 2010-06-22 06:23:18 --> Hooks Class Initialized
DEBUG - 2010-06-22 06:23:18 --> URI Class Initialized
DEBUG - 2010-06-22 06:23:18 --> Router Class Initialized
DEBUG - 2010-06-22 06:23:18 --> Output Class Initialized
DEBUG - 2010-06-22 06:23:18 --> Input Class Initialized
DEBUG - 2010-06-22 06:23:18 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 06:23:18 --> Language Class Initialized
DEBUG - 2010-06-22 06:23:18 --> Loader Class Initialized
DEBUG - 2010-06-22 06:23:18 --> Helper loaded: object_helper
DEBUG - 2010-06-22 06:23:18 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 06:23:18 --> Helper loaded: context_helper
DEBUG - 2010-06-22 06:23:18 --> Session Class Initialized
DEBUG - 2010-06-22 06:23:18 --> Helper loaded: string_helper
DEBUG - 2010-06-22 06:23:18 --> Session routines successfully run
DEBUG - 2010-06-22 06:23:18 --> Helper loaded: context_helper
DEBUG - 2010-06-22 06:23:18 --> Controller Class Initialized
DEBUG - 2010-06-22 06:23:18 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 06:23:18 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 06:23:18 --> Database Driver Class Initialized
DEBUG - 2010-06-22 06:23:18 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 06:23:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 06:23:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 06:23:18 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
DEBUG - 2010-06-22 06:23:34 --> Config Class Initialized
DEBUG - 2010-06-22 06:23:34 --> Hooks Class Initialized
DEBUG - 2010-06-22 06:23:34 --> URI Class Initialized
DEBUG - 2010-06-22 06:23:34 --> Router Class Initialized
DEBUG - 2010-06-22 06:23:34 --> Output Class Initialized
DEBUG - 2010-06-22 06:23:34 --> Input Class Initialized
DEBUG - 2010-06-22 06:23:34 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 06:23:34 --> Language Class Initialized
DEBUG - 2010-06-22 06:23:34 --> Loader Class Initialized
DEBUG - 2010-06-22 06:23:34 --> Helper loaded: object_helper
DEBUG - 2010-06-22 06:23:34 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 06:23:34 --> Helper loaded: context_helper
DEBUG - 2010-06-22 06:23:34 --> Session Class Initialized
DEBUG - 2010-06-22 06:23:34 --> Helper loaded: string_helper
DEBUG - 2010-06-22 06:23:34 --> Session routines successfully run
DEBUG - 2010-06-22 06:23:34 --> Helper loaded: context_helper
DEBUG - 2010-06-22 06:23:34 --> Controller Class Initialized
DEBUG - 2010-06-22 06:23:34 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 06:23:34 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 06:23:35 --> Database Driver Class Initialized
DEBUG - 2010-06-22 06:23:35 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 06:23:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 06:23:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 06:23:35 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
ERROR - 2010-06-22 06:23:35 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;LIMIT&quot;
LINE 2: WHERE &quot;domain_id&quot; = 1 LIMIT 1
                              ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-22 06:23:35 --> DB Transaction Failure
ERROR - 2010-06-22 06:23:35 --> Query error: ERROR:  syntax error at or near "LIMIT"
LINE 2: WHERE "domain_id" = 1 LIMIT 1
                              ^
DEBUG - 2010-06-22 06:23:35 --> Language file loaded: language/traditional_chinese/db_lang.php
DEBUG - 2010-06-22 06:23:57 --> Config Class Initialized
DEBUG - 2010-06-22 06:23:57 --> Hooks Class Initialized
DEBUG - 2010-06-22 06:23:57 --> URI Class Initialized
DEBUG - 2010-06-22 06:23:57 --> Router Class Initialized
DEBUG - 2010-06-22 06:23:57 --> Output Class Initialized
DEBUG - 2010-06-22 06:23:57 --> Input Class Initialized
DEBUG - 2010-06-22 06:23:57 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 06:23:57 --> Language Class Initialized
DEBUG - 2010-06-22 06:23:57 --> Loader Class Initialized
DEBUG - 2010-06-22 06:23:57 --> Helper loaded: object_helper
DEBUG - 2010-06-22 06:23:57 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 06:23:58 --> Helper loaded: context_helper
DEBUG - 2010-06-22 06:23:58 --> Session Class Initialized
DEBUG - 2010-06-22 06:23:58 --> Helper loaded: string_helper
DEBUG - 2010-06-22 06:23:58 --> Session routines successfully run
DEBUG - 2010-06-22 06:23:58 --> Helper loaded: context_helper
DEBUG - 2010-06-22 06:23:58 --> Controller Class Initialized
DEBUG - 2010-06-22 06:23:58 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 06:23:58 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 06:23:58 --> Database Driver Class Initialized
DEBUG - 2010-06-22 06:23:58 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 06:23:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 06:23:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 06:23:58 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
DEBUG - 2010-06-22 06:23:58 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-22 06:23:58 --> Final output sent to browser
DEBUG - 2010-06-22 06:23:58 --> Total execution time: 0.2276
DEBUG - 2010-06-22 06:24:38 --> Config Class Initialized
DEBUG - 2010-06-22 06:24:38 --> Hooks Class Initialized
DEBUG - 2010-06-22 06:24:38 --> URI Class Initialized
DEBUG - 2010-06-22 06:24:38 --> Router Class Initialized
DEBUG - 2010-06-22 06:24:38 --> Output Class Initialized
DEBUG - 2010-06-22 06:24:38 --> Input Class Initialized
DEBUG - 2010-06-22 06:24:38 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 06:24:38 --> Language Class Initialized
DEBUG - 2010-06-22 06:24:38 --> Loader Class Initialized
DEBUG - 2010-06-22 06:24:38 --> Helper loaded: object_helper
DEBUG - 2010-06-22 06:24:38 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 06:24:38 --> Helper loaded: context_helper
DEBUG - 2010-06-22 06:24:38 --> Session Class Initialized
DEBUG - 2010-06-22 06:24:38 --> Helper loaded: string_helper
DEBUG - 2010-06-22 06:24:38 --> Session routines successfully run
DEBUG - 2010-06-22 06:24:38 --> Helper loaded: context_helper
DEBUG - 2010-06-22 06:24:38 --> Controller Class Initialized
DEBUG - 2010-06-22 06:24:38 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 06:24:38 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 06:24:38 --> Database Driver Class Initialized
DEBUG - 2010-06-22 06:24:38 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 06:24:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 06:24:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 06:24:38 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
DEBUG - 2010-06-22 06:24:38 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-22 06:24:38 --> Final output sent to browser
DEBUG - 2010-06-22 06:24:38 --> Total execution time: 0.7767
DEBUG - 2010-06-22 06:24:40 --> Config Class Initialized
DEBUG - 2010-06-22 06:24:40 --> Hooks Class Initialized
DEBUG - 2010-06-22 06:24:40 --> URI Class Initialized
DEBUG - 2010-06-22 06:24:40 --> Router Class Initialized
DEBUG - 2010-06-22 06:24:40 --> Output Class Initialized
DEBUG - 2010-06-22 06:24:40 --> Input Class Initialized
DEBUG - 2010-06-22 06:24:40 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 06:24:40 --> Language Class Initialized
DEBUG - 2010-06-22 06:24:40 --> Loader Class Initialized
DEBUG - 2010-06-22 06:24:40 --> Helper loaded: object_helper
DEBUG - 2010-06-22 06:24:40 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 06:24:40 --> Helper loaded: context_helper
DEBUG - 2010-06-22 06:24:40 --> Session Class Initialized
DEBUG - 2010-06-22 06:24:40 --> Helper loaded: string_helper
DEBUG - 2010-06-22 06:24:40 --> Session routines successfully run
DEBUG - 2010-06-22 06:24:41 --> Helper loaded: context_helper
DEBUG - 2010-06-22 06:24:41 --> Controller Class Initialized
DEBUG - 2010-06-22 06:24:41 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 06:24:41 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 06:24:41 --> Database Driver Class Initialized
DEBUG - 2010-06-22 06:24:41 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 06:24:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 06:24:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 06:24:41 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
DEBUG - 2010-06-22 06:24:41 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-22 06:24:41 --> Final output sent to browser
DEBUG - 2010-06-22 06:24:41 --> Total execution time: 1.0960
DEBUG - 2010-06-22 06:24:55 --> Config Class Initialized
DEBUG - 2010-06-22 06:24:55 --> Hooks Class Initialized
DEBUG - 2010-06-22 06:24:55 --> URI Class Initialized
DEBUG - 2010-06-22 06:24:55 --> Router Class Initialized
DEBUG - 2010-06-22 06:24:55 --> Output Class Initialized
DEBUG - 2010-06-22 06:24:55 --> Input Class Initialized
DEBUG - 2010-06-22 06:24:55 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 06:24:55 --> Language Class Initialized
DEBUG - 2010-06-22 06:24:55 --> Loader Class Initialized
DEBUG - 2010-06-22 06:24:55 --> Helper loaded: object_helper
DEBUG - 2010-06-22 06:24:55 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 06:24:55 --> Helper loaded: context_helper
DEBUG - 2010-06-22 06:24:55 --> Session Class Initialized
DEBUG - 2010-06-22 06:24:55 --> Helper loaded: string_helper
DEBUG - 2010-06-22 06:24:55 --> Session routines successfully run
DEBUG - 2010-06-22 06:24:55 --> Helper loaded: context_helper
DEBUG - 2010-06-22 06:24:55 --> Controller Class Initialized
DEBUG - 2010-06-22 06:24:55 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 06:24:55 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 06:24:55 --> Database Driver Class Initialized
DEBUG - 2010-06-22 06:24:55 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 06:24:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 06:24:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 06:24:56 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
DEBUG - 2010-06-22 06:24:56 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-22 06:24:56 --> Final output sent to browser
DEBUG - 2010-06-22 06:24:56 --> Total execution time: 0.6748
DEBUG - 2010-06-22 06:25:29 --> Config Class Initialized
DEBUG - 2010-06-22 06:25:29 --> Hooks Class Initialized
DEBUG - 2010-06-22 06:25:29 --> URI Class Initialized
DEBUG - 2010-06-22 06:25:29 --> Router Class Initialized
DEBUG - 2010-06-22 06:25:29 --> Output Class Initialized
DEBUG - 2010-06-22 06:25:29 --> Input Class Initialized
DEBUG - 2010-06-22 06:25:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 06:25:29 --> Language Class Initialized
DEBUG - 2010-06-22 06:25:29 --> Loader Class Initialized
DEBUG - 2010-06-22 06:25:29 --> Helper loaded: object_helper
DEBUG - 2010-06-22 06:25:29 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 06:25:29 --> Helper loaded: context_helper
DEBUG - 2010-06-22 06:25:29 --> Session Class Initialized
DEBUG - 2010-06-22 06:25:29 --> Helper loaded: string_helper
DEBUG - 2010-06-22 06:25:29 --> Session routines successfully run
DEBUG - 2010-06-22 06:25:29 --> Helper loaded: context_helper
DEBUG - 2010-06-22 06:25:29 --> Controller Class Initialized
DEBUG - 2010-06-22 06:25:29 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 06:25:29 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 06:25:29 --> Database Driver Class Initialized
DEBUG - 2010-06-22 06:25:29 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 06:25:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 06:25:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 06:25:29 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
DEBUG - 2010-06-22 06:25:29 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-22 06:25:29 --> Final output sent to browser
DEBUG - 2010-06-22 06:25:29 --> Total execution time: 0.2583
DEBUG - 2010-06-22 06:43:04 --> Config Class Initialized
DEBUG - 2010-06-22 06:43:04 --> Hooks Class Initialized
DEBUG - 2010-06-22 06:43:04 --> URI Class Initialized
DEBUG - 2010-06-22 06:43:04 --> Router Class Initialized
DEBUG - 2010-06-22 06:43:04 --> Output Class Initialized
DEBUG - 2010-06-22 06:43:04 --> Input Class Initialized
DEBUG - 2010-06-22 06:43:04 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 06:43:04 --> Language Class Initialized
DEBUG - 2010-06-22 06:43:04 --> Loader Class Initialized
DEBUG - 2010-06-22 06:43:04 --> Helper loaded: object_helper
DEBUG - 2010-06-22 06:43:04 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 06:43:04 --> Helper loaded: context_helper
DEBUG - 2010-06-22 06:43:04 --> Session Class Initialized
DEBUG - 2010-06-22 06:43:04 --> Helper loaded: string_helper
DEBUG - 2010-06-22 06:43:04 --> Session routines successfully run
DEBUG - 2010-06-22 06:43:04 --> Helper loaded: context_helper
DEBUG - 2010-06-22 06:43:04 --> Controller Class Initialized
DEBUG - 2010-06-22 06:43:04 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 06:43:04 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 06:43:04 --> Database Driver Class Initialized
DEBUG - 2010-06-22 06:43:04 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 06:43:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 06:43:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 06:43:05 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
ERROR - 2010-06-22 06:43:05 --> Severity: Notice  --> Undefined index:  Result D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\views\misc\unit_test.php 25
ERROR - 2010-06-22 06:43:05 --> Severity: Notice  --> Undefined index:  Result D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\views\misc\unit_test.php 25
DEBUG - 2010-06-22 06:43:05 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-22 06:43:05 --> Final output sent to browser
DEBUG - 2010-06-22 06:43:05 --> Total execution time: 1.1468
DEBUG - 2010-06-22 06:45:21 --> Config Class Initialized
DEBUG - 2010-06-22 06:45:21 --> Hooks Class Initialized
DEBUG - 2010-06-22 06:45:21 --> URI Class Initialized
DEBUG - 2010-06-22 06:45:21 --> Router Class Initialized
DEBUG - 2010-06-22 06:45:21 --> Output Class Initialized
DEBUG - 2010-06-22 06:45:21 --> Input Class Initialized
DEBUG - 2010-06-22 06:45:21 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 06:45:21 --> Language Class Initialized
DEBUG - 2010-06-22 06:45:21 --> Loader Class Initialized
DEBUG - 2010-06-22 06:45:21 --> Helper loaded: object_helper
DEBUG - 2010-06-22 06:45:21 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 06:45:21 --> Helper loaded: context_helper
DEBUG - 2010-06-22 06:45:21 --> Session Class Initialized
DEBUG - 2010-06-22 06:45:21 --> Helper loaded: string_helper
DEBUG - 2010-06-22 06:45:21 --> Session routines successfully run
DEBUG - 2010-06-22 06:45:21 --> Helper loaded: context_helper
DEBUG - 2010-06-22 06:45:21 --> Controller Class Initialized
DEBUG - 2010-06-22 06:45:21 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 06:45:21 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 06:45:21 --> Database Driver Class Initialized
DEBUG - 2010-06-22 06:45:22 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 06:45:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 06:45:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 06:45:22 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
ERROR - 2010-06-22 06:45:22 --> Severity: Notice  --> Undefined index:  Result D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\views\misc\unit_test.php 26
ERROR - 2010-06-22 06:45:22 --> Severity: Notice  --> Undefined index:  Result D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\views\misc\unit_test.php 26
DEBUG - 2010-06-22 06:45:22 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-22 06:45:22 --> Final output sent to browser
DEBUG - 2010-06-22 06:45:22 --> Total execution time: 0.7059
DEBUG - 2010-06-22 06:45:34 --> Config Class Initialized
DEBUG - 2010-06-22 06:45:34 --> Hooks Class Initialized
DEBUG - 2010-06-22 06:45:34 --> URI Class Initialized
DEBUG - 2010-06-22 06:45:34 --> Router Class Initialized
DEBUG - 2010-06-22 06:45:34 --> Output Class Initialized
DEBUG - 2010-06-22 06:45:34 --> Input Class Initialized
DEBUG - 2010-06-22 06:45:34 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 06:45:34 --> Language Class Initialized
DEBUG - 2010-06-22 06:45:34 --> Loader Class Initialized
DEBUG - 2010-06-22 06:45:34 --> Helper loaded: object_helper
DEBUG - 2010-06-22 06:45:34 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 06:45:34 --> Helper loaded: context_helper
DEBUG - 2010-06-22 06:45:34 --> Session Class Initialized
DEBUG - 2010-06-22 06:45:34 --> Helper loaded: string_helper
DEBUG - 2010-06-22 06:45:34 --> Session routines successfully run
DEBUG - 2010-06-22 06:45:34 --> Helper loaded: context_helper
DEBUG - 2010-06-22 06:45:34 --> Controller Class Initialized
DEBUG - 2010-06-22 06:45:34 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 06:45:34 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 06:45:34 --> Database Driver Class Initialized
DEBUG - 2010-06-22 06:45:34 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 06:45:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 06:45:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 06:45:35 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
ERROR - 2010-06-22 06:45:35 --> Severity: Notice  --> Undefined index:  Result D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\views\misc\unit_test.php 26
ERROR - 2010-06-22 06:45:35 --> Severity: Notice  --> Undefined index:  Result D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\views\misc\unit_test.php 26
DEBUG - 2010-06-22 06:45:35 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-22 06:45:35 --> Final output sent to browser
DEBUG - 2010-06-22 06:45:35 --> Total execution time: 1.0952
DEBUG - 2010-06-22 06:45:59 --> Config Class Initialized
DEBUG - 2010-06-22 06:45:59 --> Hooks Class Initialized
DEBUG - 2010-06-22 06:45:59 --> URI Class Initialized
DEBUG - 2010-06-22 06:45:59 --> Router Class Initialized
DEBUG - 2010-06-22 06:45:59 --> Output Class Initialized
DEBUG - 2010-06-22 06:45:59 --> Input Class Initialized
DEBUG - 2010-06-22 06:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 06:45:59 --> Language Class Initialized
DEBUG - 2010-06-22 06:45:59 --> Loader Class Initialized
DEBUG - 2010-06-22 06:45:59 --> Helper loaded: object_helper
DEBUG - 2010-06-22 06:45:59 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 06:45:59 --> Helper loaded: context_helper
DEBUG - 2010-06-22 06:45:59 --> Session Class Initialized
DEBUG - 2010-06-22 06:45:59 --> Helper loaded: string_helper
DEBUG - 2010-06-22 06:45:59 --> Session routines successfully run
DEBUG - 2010-06-22 06:45:59 --> Helper loaded: context_helper
DEBUG - 2010-06-22 06:45:59 --> Controller Class Initialized
DEBUG - 2010-06-22 06:45:59 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 06:45:59 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 06:45:59 --> Database Driver Class Initialized
DEBUG - 2010-06-22 06:45:59 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 06:45:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 06:46:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 06:46:00 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
DEBUG - 2010-06-22 06:46:00 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-22 06:46:00 --> Final output sent to browser
DEBUG - 2010-06-22 06:46:00 --> Total execution time: 1.1036
DEBUG - 2010-06-22 07:09:52 --> Config Class Initialized
DEBUG - 2010-06-22 07:09:52 --> Hooks Class Initialized
DEBUG - 2010-06-22 07:09:52 --> URI Class Initialized
DEBUG - 2010-06-22 07:09:52 --> Router Class Initialized
DEBUG - 2010-06-22 07:09:52 --> Output Class Initialized
DEBUG - 2010-06-22 07:09:52 --> Input Class Initialized
DEBUG - 2010-06-22 07:09:52 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 07:09:52 --> Language Class Initialized
DEBUG - 2010-06-22 07:09:52 --> Loader Class Initialized
DEBUG - 2010-06-22 07:09:52 --> Helper loaded: object_helper
DEBUG - 2010-06-22 07:09:52 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 07:09:52 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:09:52 --> Session Class Initialized
DEBUG - 2010-06-22 07:09:52 --> Helper loaded: string_helper
DEBUG - 2010-06-22 07:09:52 --> Session routines successfully run
DEBUG - 2010-06-22 07:09:52 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:09:52 --> Controller Class Initialized
DEBUG - 2010-06-22 07:09:52 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 07:09:52 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 07:09:52 --> Database Driver Class Initialized
DEBUG - 2010-06-22 07:09:52 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 07:10:18 --> Config Class Initialized
DEBUG - 2010-06-22 07:10:18 --> Hooks Class Initialized
DEBUG - 2010-06-22 07:10:18 --> URI Class Initialized
DEBUG - 2010-06-22 07:10:18 --> Router Class Initialized
DEBUG - 2010-06-22 07:10:18 --> Output Class Initialized
DEBUG - 2010-06-22 07:10:18 --> Input Class Initialized
DEBUG - 2010-06-22 07:10:18 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 07:10:18 --> Language Class Initialized
DEBUG - 2010-06-22 07:10:18 --> Loader Class Initialized
DEBUG - 2010-06-22 07:10:18 --> Helper loaded: object_helper
DEBUG - 2010-06-22 07:10:18 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 07:10:18 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:10:18 --> Session Class Initialized
DEBUG - 2010-06-22 07:10:18 --> Helper loaded: string_helper
DEBUG - 2010-06-22 07:10:18 --> Session routines successfully run
DEBUG - 2010-06-22 07:10:18 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:10:18 --> Controller Class Initialized
DEBUG - 2010-06-22 07:10:18 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 07:10:18 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 07:10:18 --> Database Driver Class Initialized
DEBUG - 2010-06-22 07:10:18 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
ERROR - 2010-06-22 07:10:18 --> Severity: Notice  --> Undefined property: Domain::$db D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 67
DEBUG - 2010-06-22 07:13:10 --> Config Class Initialized
DEBUG - 2010-06-22 07:13:10 --> Hooks Class Initialized
DEBUG - 2010-06-22 07:13:10 --> URI Class Initialized
DEBUG - 2010-06-22 07:13:10 --> Router Class Initialized
DEBUG - 2010-06-22 07:13:10 --> Output Class Initialized
DEBUG - 2010-06-22 07:13:10 --> Input Class Initialized
DEBUG - 2010-06-22 07:13:10 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 07:13:10 --> Language Class Initialized
DEBUG - 2010-06-22 07:13:10 --> Loader Class Initialized
DEBUG - 2010-06-22 07:13:10 --> Helper loaded: object_helper
DEBUG - 2010-06-22 07:13:10 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 07:13:10 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:13:10 --> Session Class Initialized
DEBUG - 2010-06-22 07:13:10 --> Helper loaded: string_helper
DEBUG - 2010-06-22 07:13:10 --> Session routines successfully run
DEBUG - 2010-06-22 07:13:10 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:13:10 --> Controller Class Initialized
DEBUG - 2010-06-22 07:13:10 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 07:13:10 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 07:13:10 --> Database Driver Class Initialized
DEBUG - 2010-06-22 07:13:10 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
ERROR - 2010-06-22 07:13:10 --> Severity: Notice  --> Undefined property: Domain::$db D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 67
DEBUG - 2010-06-22 07:13:34 --> Config Class Initialized
DEBUG - 2010-06-22 07:13:34 --> Hooks Class Initialized
DEBUG - 2010-06-22 07:13:34 --> URI Class Initialized
DEBUG - 2010-06-22 07:13:34 --> Router Class Initialized
DEBUG - 2010-06-22 07:13:34 --> Output Class Initialized
DEBUG - 2010-06-22 07:13:34 --> Input Class Initialized
DEBUG - 2010-06-22 07:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 07:13:34 --> Language Class Initialized
DEBUG - 2010-06-22 07:13:34 --> Loader Class Initialized
DEBUG - 2010-06-22 07:13:34 --> Helper loaded: object_helper
DEBUG - 2010-06-22 07:13:34 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 07:13:34 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:13:34 --> Session Class Initialized
DEBUG - 2010-06-22 07:13:34 --> Helper loaded: string_helper
DEBUG - 2010-06-22 07:13:34 --> Session routines successfully run
DEBUG - 2010-06-22 07:13:34 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:13:34 --> Controller Class Initialized
DEBUG - 2010-06-22 07:13:34 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 07:13:34 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 07:13:34 --> Database Driver Class Initialized
DEBUG - 2010-06-22 07:13:34 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
ERROR - 2010-06-22 07:13:34 --> Severity: Notice  --> Undefined property: Domain::$db D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 68
DEBUG - 2010-06-22 07:13:50 --> Config Class Initialized
DEBUG - 2010-06-22 07:13:50 --> Hooks Class Initialized
DEBUG - 2010-06-22 07:13:50 --> URI Class Initialized
DEBUG - 2010-06-22 07:13:50 --> Router Class Initialized
DEBUG - 2010-06-22 07:13:50 --> Output Class Initialized
DEBUG - 2010-06-22 07:13:50 --> Input Class Initialized
DEBUG - 2010-06-22 07:13:50 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 07:13:50 --> Language Class Initialized
DEBUG - 2010-06-22 07:13:50 --> Loader Class Initialized
DEBUG - 2010-06-22 07:13:50 --> Helper loaded: object_helper
DEBUG - 2010-06-22 07:13:50 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 07:13:50 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:13:50 --> Session Class Initialized
DEBUG - 2010-06-22 07:13:50 --> Helper loaded: string_helper
DEBUG - 2010-06-22 07:13:50 --> Session routines successfully run
DEBUG - 2010-06-22 07:13:50 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:13:50 --> Controller Class Initialized
DEBUG - 2010-06-22 07:13:50 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 07:13:50 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 07:13:51 --> Database Driver Class Initialized
DEBUG - 2010-06-22 07:13:51 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 07:14:03 --> Config Class Initialized
DEBUG - 2010-06-22 07:14:03 --> Hooks Class Initialized
DEBUG - 2010-06-22 07:14:03 --> URI Class Initialized
DEBUG - 2010-06-22 07:14:03 --> Router Class Initialized
DEBUG - 2010-06-22 07:14:03 --> Output Class Initialized
DEBUG - 2010-06-22 07:14:03 --> Input Class Initialized
DEBUG - 2010-06-22 07:14:03 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 07:14:03 --> Language Class Initialized
DEBUG - 2010-06-22 07:14:03 --> Loader Class Initialized
DEBUG - 2010-06-22 07:14:03 --> Helper loaded: object_helper
DEBUG - 2010-06-22 07:14:03 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 07:14:03 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:14:03 --> Session Class Initialized
DEBUG - 2010-06-22 07:14:03 --> Helper loaded: string_helper
DEBUG - 2010-06-22 07:14:03 --> Session routines successfully run
DEBUG - 2010-06-22 07:14:03 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:14:03 --> Controller Class Initialized
DEBUG - 2010-06-22 07:14:03 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 07:14:03 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 07:14:03 --> Database Driver Class Initialized
DEBUG - 2010-06-22 07:14:03 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 07:14:53 --> Config Class Initialized
DEBUG - 2010-06-22 07:14:53 --> Hooks Class Initialized
DEBUG - 2010-06-22 07:14:53 --> URI Class Initialized
DEBUG - 2010-06-22 07:14:53 --> Router Class Initialized
DEBUG - 2010-06-22 07:14:53 --> Output Class Initialized
DEBUG - 2010-06-22 07:14:53 --> Input Class Initialized
DEBUG - 2010-06-22 07:14:53 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 07:14:53 --> Language Class Initialized
DEBUG - 2010-06-22 07:14:53 --> Loader Class Initialized
DEBUG - 2010-06-22 07:14:53 --> Helper loaded: object_helper
DEBUG - 2010-06-22 07:14:53 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 07:14:53 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:14:53 --> Session Class Initialized
DEBUG - 2010-06-22 07:14:53 --> Helper loaded: string_helper
DEBUG - 2010-06-22 07:14:53 --> Session routines successfully run
DEBUG - 2010-06-22 07:14:53 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:14:53 --> Controller Class Initialized
DEBUG - 2010-06-22 07:14:53 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 07:14:53 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 07:14:53 --> Database Driver Class Initialized
DEBUG - 2010-06-22 07:14:53 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 07:15:06 --> Config Class Initialized
DEBUG - 2010-06-22 07:15:06 --> Hooks Class Initialized
DEBUG - 2010-06-22 07:15:06 --> URI Class Initialized
DEBUG - 2010-06-22 07:15:07 --> Router Class Initialized
DEBUG - 2010-06-22 07:15:07 --> Output Class Initialized
DEBUG - 2010-06-22 07:15:07 --> Input Class Initialized
DEBUG - 2010-06-22 07:15:07 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 07:15:07 --> Language Class Initialized
DEBUG - 2010-06-22 07:15:07 --> Loader Class Initialized
DEBUG - 2010-06-22 07:15:07 --> Helper loaded: object_helper
DEBUG - 2010-06-22 07:15:07 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 07:15:07 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:15:07 --> Session Class Initialized
DEBUG - 2010-06-22 07:15:07 --> Helper loaded: string_helper
DEBUG - 2010-06-22 07:15:07 --> Session routines successfully run
DEBUG - 2010-06-22 07:15:07 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:15:07 --> Controller Class Initialized
DEBUG - 2010-06-22 07:15:07 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 07:15:07 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 07:15:07 --> Database Driver Class Initialized
DEBUG - 2010-06-22 07:15:07 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 07:15:25 --> Config Class Initialized
DEBUG - 2010-06-22 07:15:25 --> Hooks Class Initialized
DEBUG - 2010-06-22 07:15:25 --> URI Class Initialized
DEBUG - 2010-06-22 07:15:25 --> Router Class Initialized
DEBUG - 2010-06-22 07:15:25 --> Output Class Initialized
DEBUG - 2010-06-22 07:15:25 --> Input Class Initialized
DEBUG - 2010-06-22 07:15:25 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 07:15:25 --> Language Class Initialized
DEBUG - 2010-06-22 07:15:25 --> Loader Class Initialized
DEBUG - 2010-06-22 07:15:25 --> Helper loaded: object_helper
DEBUG - 2010-06-22 07:15:25 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 07:15:25 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:15:25 --> Session Class Initialized
DEBUG - 2010-06-22 07:15:25 --> Helper loaded: string_helper
DEBUG - 2010-06-22 07:15:25 --> Session routines successfully run
DEBUG - 2010-06-22 07:15:25 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:15:25 --> Controller Class Initialized
DEBUG - 2010-06-22 07:15:25 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 07:15:25 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 07:15:25 --> Database Driver Class Initialized
DEBUG - 2010-06-22 07:15:25 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 07:15:40 --> Config Class Initialized
DEBUG - 2010-06-22 07:15:40 --> Hooks Class Initialized
DEBUG - 2010-06-22 07:15:40 --> URI Class Initialized
DEBUG - 2010-06-22 07:15:40 --> Router Class Initialized
DEBUG - 2010-06-22 07:15:40 --> Output Class Initialized
DEBUG - 2010-06-22 07:15:40 --> Input Class Initialized
DEBUG - 2010-06-22 07:15:40 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 07:15:40 --> Language Class Initialized
DEBUG - 2010-06-22 07:15:40 --> Loader Class Initialized
DEBUG - 2010-06-22 07:15:40 --> Helper loaded: object_helper
DEBUG - 2010-06-22 07:15:40 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 07:15:40 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:15:40 --> Session Class Initialized
DEBUG - 2010-06-22 07:15:40 --> Helper loaded: string_helper
DEBUG - 2010-06-22 07:15:40 --> Session routines successfully run
DEBUG - 2010-06-22 07:15:40 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:15:40 --> Controller Class Initialized
DEBUG - 2010-06-22 07:15:40 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 07:15:40 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 07:15:40 --> Database Driver Class Initialized
DEBUG - 2010-06-22 07:15:40 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 07:23:27 --> Config Class Initialized
DEBUG - 2010-06-22 07:23:27 --> Hooks Class Initialized
DEBUG - 2010-06-22 07:23:27 --> URI Class Initialized
DEBUG - 2010-06-22 07:23:27 --> Router Class Initialized
DEBUG - 2010-06-22 07:23:27 --> Output Class Initialized
DEBUG - 2010-06-22 07:23:27 --> Input Class Initialized
DEBUG - 2010-06-22 07:23:27 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 07:23:27 --> Language Class Initialized
DEBUG - 2010-06-22 07:23:27 --> Loader Class Initialized
DEBUG - 2010-06-22 07:23:27 --> Helper loaded: object_helper
DEBUG - 2010-06-22 07:23:27 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 07:23:27 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:23:27 --> Session Class Initialized
DEBUG - 2010-06-22 07:23:27 --> Helper loaded: string_helper
DEBUG - 2010-06-22 07:23:27 --> Session routines successfully run
DEBUG - 2010-06-22 07:23:27 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:23:27 --> Controller Class Initialized
DEBUG - 2010-06-22 07:23:27 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 07:23:28 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 07:23:28 --> Database Driver Class Initialized
DEBUG - 2010-06-22 07:23:28 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 07:25:34 --> Config Class Initialized
DEBUG - 2010-06-22 07:25:34 --> Hooks Class Initialized
DEBUG - 2010-06-22 07:25:34 --> URI Class Initialized
DEBUG - 2010-06-22 07:25:34 --> Router Class Initialized
DEBUG - 2010-06-22 07:25:34 --> Output Class Initialized
DEBUG - 2010-06-22 07:25:34 --> Input Class Initialized
DEBUG - 2010-06-22 07:25:34 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 07:25:34 --> Language Class Initialized
DEBUG - 2010-06-22 07:25:34 --> Loader Class Initialized
DEBUG - 2010-06-22 07:25:34 --> Helper loaded: object_helper
DEBUG - 2010-06-22 07:25:34 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 07:25:34 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:25:34 --> Session Class Initialized
DEBUG - 2010-06-22 07:25:34 --> Helper loaded: string_helper
DEBUG - 2010-06-22 07:25:34 --> Session routines successfully run
DEBUG - 2010-06-22 07:25:34 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:25:34 --> Controller Class Initialized
DEBUG - 2010-06-22 07:25:34 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 07:25:34 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 07:25:42 --> Config Class Initialized
DEBUG - 2010-06-22 07:25:42 --> Hooks Class Initialized
DEBUG - 2010-06-22 07:25:42 --> URI Class Initialized
DEBUG - 2010-06-22 07:25:42 --> Router Class Initialized
DEBUG - 2010-06-22 07:25:42 --> Output Class Initialized
DEBUG - 2010-06-22 07:25:42 --> Input Class Initialized
DEBUG - 2010-06-22 07:25:42 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 07:25:42 --> Language Class Initialized
DEBUG - 2010-06-22 07:25:42 --> Loader Class Initialized
DEBUG - 2010-06-22 07:25:42 --> Helper loaded: object_helper
DEBUG - 2010-06-22 07:25:42 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 07:25:42 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:25:42 --> Session Class Initialized
DEBUG - 2010-06-22 07:25:42 --> Helper loaded: string_helper
DEBUG - 2010-06-22 07:25:42 --> Session routines successfully run
DEBUG - 2010-06-22 07:25:42 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:25:42 --> Controller Class Initialized
DEBUG - 2010-06-22 07:25:42 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 07:25:42 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 07:25:42 --> Database Driver Class Initialized
DEBUG - 2010-06-22 07:25:42 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 07:26:40 --> Config Class Initialized
DEBUG - 2010-06-22 07:26:40 --> Hooks Class Initialized
DEBUG - 2010-06-22 07:26:40 --> URI Class Initialized
DEBUG - 2010-06-22 07:26:40 --> Router Class Initialized
DEBUG - 2010-06-22 07:26:40 --> Output Class Initialized
DEBUG - 2010-06-22 07:26:40 --> Input Class Initialized
DEBUG - 2010-06-22 07:26:40 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 07:26:40 --> Language Class Initialized
DEBUG - 2010-06-22 07:26:40 --> Loader Class Initialized
DEBUG - 2010-06-22 07:26:40 --> Helper loaded: object_helper
DEBUG - 2010-06-22 07:26:40 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 07:26:40 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:26:40 --> Session Class Initialized
DEBUG - 2010-06-22 07:26:40 --> Helper loaded: string_helper
DEBUG - 2010-06-22 07:26:40 --> Session routines successfully run
DEBUG - 2010-06-22 07:26:40 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:26:40 --> Controller Class Initialized
DEBUG - 2010-06-22 07:26:40 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 07:26:40 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 07:26:40 --> Database Driver Class Initialized
DEBUG - 2010-06-22 07:26:40 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 07:27:29 --> Config Class Initialized
DEBUG - 2010-06-22 07:27:29 --> Hooks Class Initialized
DEBUG - 2010-06-22 07:27:29 --> URI Class Initialized
DEBUG - 2010-06-22 07:27:29 --> Router Class Initialized
DEBUG - 2010-06-22 07:27:29 --> Output Class Initialized
DEBUG - 2010-06-22 07:27:29 --> Input Class Initialized
DEBUG - 2010-06-22 07:27:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 07:27:29 --> Language Class Initialized
DEBUG - 2010-06-22 07:27:29 --> Loader Class Initialized
DEBUG - 2010-06-22 07:27:29 --> Helper loaded: object_helper
DEBUG - 2010-06-22 07:27:29 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 07:27:30 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:27:30 --> Session Class Initialized
DEBUG - 2010-06-22 07:27:30 --> Helper loaded: string_helper
DEBUG - 2010-06-22 07:27:30 --> Session routines successfully run
DEBUG - 2010-06-22 07:27:30 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:27:30 --> Controller Class Initialized
DEBUG - 2010-06-22 07:27:30 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 07:27:30 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 07:27:30 --> Database Driver Class Initialized
DEBUG - 2010-06-22 07:27:30 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 07:27:34 --> Config Class Initialized
DEBUG - 2010-06-22 07:27:34 --> Hooks Class Initialized
DEBUG - 2010-06-22 07:27:34 --> URI Class Initialized
DEBUG - 2010-06-22 07:27:34 --> Router Class Initialized
DEBUG - 2010-06-22 07:27:34 --> Output Class Initialized
DEBUG - 2010-06-22 07:27:34 --> Input Class Initialized
DEBUG - 2010-06-22 07:27:34 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 07:27:34 --> Language Class Initialized
DEBUG - 2010-06-22 07:27:34 --> Loader Class Initialized
DEBUG - 2010-06-22 07:27:34 --> Helper loaded: object_helper
DEBUG - 2010-06-22 07:27:34 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 07:27:34 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:27:34 --> Session Class Initialized
DEBUG - 2010-06-22 07:27:34 --> Helper loaded: string_helper
DEBUG - 2010-06-22 07:27:34 --> Session routines successfully run
DEBUG - 2010-06-22 07:27:34 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:27:34 --> Controller Class Initialized
DEBUG - 2010-06-22 07:27:34 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 07:27:34 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 07:27:34 --> Database Driver Class Initialized
DEBUG - 2010-06-22 07:27:34 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 07:27:55 --> Config Class Initialized
DEBUG - 2010-06-22 07:27:55 --> Hooks Class Initialized
DEBUG - 2010-06-22 07:27:55 --> URI Class Initialized
DEBUG - 2010-06-22 07:27:55 --> Router Class Initialized
DEBUG - 2010-06-22 07:27:55 --> Output Class Initialized
DEBUG - 2010-06-22 07:27:55 --> Input Class Initialized
DEBUG - 2010-06-22 07:27:55 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 07:27:55 --> Language Class Initialized
DEBUG - 2010-06-22 07:27:55 --> Loader Class Initialized
DEBUG - 2010-06-22 07:27:55 --> Helper loaded: object_helper
DEBUG - 2010-06-22 07:27:55 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 07:27:55 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:27:55 --> Session Class Initialized
DEBUG - 2010-06-22 07:27:55 --> Helper loaded: string_helper
DEBUG - 2010-06-22 07:27:55 --> Session routines successfully run
DEBUG - 2010-06-22 07:27:55 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:27:55 --> Controller Class Initialized
DEBUG - 2010-06-22 07:27:55 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 07:27:55 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 07:27:55 --> Database Driver Class Initialized
DEBUG - 2010-06-22 07:27:55 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 07:29:14 --> Config Class Initialized
DEBUG - 2010-06-22 07:29:14 --> Hooks Class Initialized
DEBUG - 2010-06-22 07:29:14 --> URI Class Initialized
DEBUG - 2010-06-22 07:29:15 --> Router Class Initialized
DEBUG - 2010-06-22 07:29:15 --> Output Class Initialized
DEBUG - 2010-06-22 07:29:15 --> Input Class Initialized
DEBUG - 2010-06-22 07:29:15 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 07:29:15 --> Language Class Initialized
DEBUG - 2010-06-22 07:29:15 --> Loader Class Initialized
DEBUG - 2010-06-22 07:29:15 --> Helper loaded: object_helper
DEBUG - 2010-06-22 07:29:15 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 07:29:15 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:29:15 --> Session Class Initialized
DEBUG - 2010-06-22 07:29:15 --> Helper loaded: string_helper
DEBUG - 2010-06-22 07:29:15 --> Session routines successfully run
DEBUG - 2010-06-22 07:29:15 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:29:15 --> Controller Class Initialized
DEBUG - 2010-06-22 07:29:15 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 07:29:15 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 07:29:15 --> Database Driver Class Initialized
DEBUG - 2010-06-22 07:29:15 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
ERROR - 2010-06-22 07:29:15 --> Severity: Notice  --> Undefined property: Domain::$db D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 69
DEBUG - 2010-06-22 07:29:37 --> Config Class Initialized
DEBUG - 2010-06-22 07:29:37 --> Hooks Class Initialized
DEBUG - 2010-06-22 07:29:37 --> URI Class Initialized
DEBUG - 2010-06-22 07:29:37 --> Router Class Initialized
DEBUG - 2010-06-22 07:29:37 --> Output Class Initialized
DEBUG - 2010-06-22 07:29:38 --> Input Class Initialized
DEBUG - 2010-06-22 07:29:38 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 07:29:38 --> Language Class Initialized
DEBUG - 2010-06-22 07:29:38 --> Loader Class Initialized
DEBUG - 2010-06-22 07:29:38 --> Helper loaded: object_helper
DEBUG - 2010-06-22 07:29:38 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 07:29:38 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:29:38 --> Session Class Initialized
DEBUG - 2010-06-22 07:29:38 --> Helper loaded: string_helper
DEBUG - 2010-06-22 07:29:38 --> Session routines successfully run
DEBUG - 2010-06-22 07:29:38 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:29:38 --> Controller Class Initialized
DEBUG - 2010-06-22 07:29:38 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 07:29:38 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 07:29:38 --> Database Driver Class Initialized
DEBUG - 2010-06-22 07:29:38 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
ERROR - 2010-06-22 07:29:38 --> Severity: Notice  --> Undefined property: Domain::$db D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 67
DEBUG - 2010-06-22 07:30:10 --> Config Class Initialized
DEBUG - 2010-06-22 07:30:10 --> Hooks Class Initialized
DEBUG - 2010-06-22 07:30:10 --> URI Class Initialized
DEBUG - 2010-06-22 07:30:10 --> Router Class Initialized
DEBUG - 2010-06-22 07:30:10 --> Output Class Initialized
DEBUG - 2010-06-22 07:30:10 --> Input Class Initialized
DEBUG - 2010-06-22 07:30:10 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 07:30:10 --> Language Class Initialized
DEBUG - 2010-06-22 07:30:10 --> Loader Class Initialized
DEBUG - 2010-06-22 07:30:10 --> Helper loaded: object_helper
DEBUG - 2010-06-22 07:30:10 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 07:30:10 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:30:10 --> Session Class Initialized
DEBUG - 2010-06-22 07:30:10 --> Helper loaded: string_helper
DEBUG - 2010-06-22 07:30:10 --> Session routines successfully run
DEBUG - 2010-06-22 07:30:10 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:30:10 --> Controller Class Initialized
DEBUG - 2010-06-22 07:30:10 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 07:30:10 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 07:30:10 --> Database Driver Class Initialized
DEBUG - 2010-06-22 07:30:10 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
ERROR - 2010-06-22 07:30:10 --> Severity: Notice  --> Undefined property: Domain::$db D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 67
DEBUG - 2010-06-22 07:30:19 --> Config Class Initialized
DEBUG - 2010-06-22 07:30:19 --> Hooks Class Initialized
DEBUG - 2010-06-22 07:30:19 --> URI Class Initialized
DEBUG - 2010-06-22 07:30:19 --> Router Class Initialized
DEBUG - 2010-06-22 07:30:20 --> Output Class Initialized
DEBUG - 2010-06-22 07:30:20 --> Input Class Initialized
DEBUG - 2010-06-22 07:30:20 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 07:30:20 --> Language Class Initialized
DEBUG - 2010-06-22 07:30:20 --> Loader Class Initialized
DEBUG - 2010-06-22 07:30:20 --> Helper loaded: object_helper
DEBUG - 2010-06-22 07:30:20 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 07:30:20 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:30:20 --> Session Class Initialized
DEBUG - 2010-06-22 07:30:20 --> Helper loaded: string_helper
DEBUG - 2010-06-22 07:30:20 --> Session routines successfully run
DEBUG - 2010-06-22 07:30:20 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:30:20 --> Controller Class Initialized
DEBUG - 2010-06-22 07:30:20 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 07:30:20 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 07:30:20 --> Database Driver Class Initialized
DEBUG - 2010-06-22 07:30:20 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
ERROR - 2010-06-22 07:30:20 --> Severity: Notice  --> Undefined property: Domain::$db D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 67
DEBUG - 2010-06-22 07:31:27 --> Config Class Initialized
DEBUG - 2010-06-22 07:31:27 --> Hooks Class Initialized
DEBUG - 2010-06-22 07:31:27 --> URI Class Initialized
DEBUG - 2010-06-22 07:31:27 --> Router Class Initialized
DEBUG - 2010-06-22 07:31:27 --> Output Class Initialized
DEBUG - 2010-06-22 07:31:27 --> Input Class Initialized
DEBUG - 2010-06-22 07:31:27 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 07:31:27 --> Language Class Initialized
DEBUG - 2010-06-22 07:31:27 --> Loader Class Initialized
DEBUG - 2010-06-22 07:31:27 --> Helper loaded: object_helper
DEBUG - 2010-06-22 07:31:27 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 07:31:27 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:31:28 --> Session Class Initialized
DEBUG - 2010-06-22 07:31:28 --> Helper loaded: string_helper
DEBUG - 2010-06-22 07:31:28 --> Session routines successfully run
DEBUG - 2010-06-22 07:31:28 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:31:28 --> Controller Class Initialized
DEBUG - 2010-06-22 07:31:28 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 07:31:28 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 07:31:28 --> Database Driver Class Initialized
DEBUG - 2010-06-22 07:31:28 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
ERROR - 2010-06-22 07:31:28 --> Severity: Notice  --> Undefined property: Domain::$db D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 67
DEBUG - 2010-06-22 07:31:52 --> Config Class Initialized
DEBUG - 2010-06-22 07:31:52 --> Hooks Class Initialized
DEBUG - 2010-06-22 07:31:52 --> URI Class Initialized
DEBUG - 2010-06-22 07:31:52 --> Router Class Initialized
DEBUG - 2010-06-22 07:31:52 --> Output Class Initialized
DEBUG - 2010-06-22 07:31:52 --> Input Class Initialized
DEBUG - 2010-06-22 07:31:52 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 07:31:52 --> Language Class Initialized
DEBUG - 2010-06-22 07:31:52 --> Loader Class Initialized
DEBUG - 2010-06-22 07:31:52 --> Helper loaded: object_helper
DEBUG - 2010-06-22 07:31:52 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 07:31:52 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:31:52 --> Session Class Initialized
DEBUG - 2010-06-22 07:31:52 --> Helper loaded: string_helper
DEBUG - 2010-06-22 07:31:52 --> Session routines successfully run
DEBUG - 2010-06-22 07:31:52 --> Helper loaded: context_helper
DEBUG - 2010-06-22 07:31:52 --> Controller Class Initialized
DEBUG - 2010-06-22 07:31:52 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 07:31:52 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 07:31:52 --> Database Driver Class Initialized
DEBUG - 2010-06-22 07:31:52 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
ERROR - 2010-06-22 07:31:52 --> Severity: Notice  --> Undefined property: Domain::$db D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 67
DEBUG - 2010-06-22 08:47:15 --> Config Class Initialized
DEBUG - 2010-06-22 08:47:15 --> Hooks Class Initialized
DEBUG - 2010-06-22 08:47:15 --> URI Class Initialized
DEBUG - 2010-06-22 08:47:16 --> Router Class Initialized
DEBUG - 2010-06-22 08:47:16 --> Output Class Initialized
DEBUG - 2010-06-22 08:47:16 --> Input Class Initialized
DEBUG - 2010-06-22 08:47:16 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 08:47:16 --> Language Class Initialized
DEBUG - 2010-06-22 08:47:16 --> Loader Class Initialized
DEBUG - 2010-06-22 08:47:16 --> Helper loaded: object_helper
DEBUG - 2010-06-22 08:47:16 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 08:47:16 --> Helper loaded: context_helper
DEBUG - 2010-06-22 08:47:16 --> Session Class Initialized
DEBUG - 2010-06-22 08:47:16 --> Helper loaded: string_helper
ERROR - 2010-06-22 08:47:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\object_helper.php:37) D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Session.php 662
DEBUG - 2010-06-22 08:47:16 --> Session routines successfully run
DEBUG - 2010-06-22 08:47:16 --> Helper loaded: context_helper
DEBUG - 2010-06-22 08:47:16 --> Controller Class Initialized
DEBUG - 2010-06-22 08:47:16 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 08:47:16 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 08:47:16 --> Database Driver Class Initialized
DEBUG - 2010-06-22 08:47:16 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
ERROR - 2010-06-22 08:47:16 --> Severity: Notice  --> Undefined property: Domain::$db D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 66
DEBUG - 2010-06-22 08:48:08 --> Config Class Initialized
DEBUG - 2010-06-22 08:48:08 --> Hooks Class Initialized
DEBUG - 2010-06-22 08:48:08 --> URI Class Initialized
DEBUG - 2010-06-22 08:48:08 --> Router Class Initialized
DEBUG - 2010-06-22 08:48:08 --> Output Class Initialized
DEBUG - 2010-06-22 08:48:08 --> Input Class Initialized
DEBUG - 2010-06-22 08:48:08 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 08:48:08 --> Language Class Initialized
DEBUG - 2010-06-22 08:48:08 --> Loader Class Initialized
DEBUG - 2010-06-22 08:48:08 --> Helper loaded: object_helper
DEBUG - 2010-06-22 08:48:08 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 08:48:08 --> Helper loaded: context_helper
DEBUG - 2010-06-22 08:48:08 --> Session Class Initialized
DEBUG - 2010-06-22 08:48:08 --> Helper loaded: string_helper
ERROR - 2010-06-22 08:48:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\object_helper.php:37) D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Session.php 662
DEBUG - 2010-06-22 08:48:08 --> Session routines successfully run
DEBUG - 2010-06-22 08:48:08 --> Helper loaded: context_helper
DEBUG - 2010-06-22 08:48:08 --> Controller Class Initialized
DEBUG - 2010-06-22 08:48:08 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 08:48:08 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 08:48:08 --> Database Driver Class Initialized
DEBUG - 2010-06-22 08:48:08 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 08:48:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 08:48:09 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 08:48:39 --> Config Class Initialized
DEBUG - 2010-06-22 08:48:39 --> Hooks Class Initialized
DEBUG - 2010-06-22 08:48:39 --> URI Class Initialized
DEBUG - 2010-06-22 08:48:39 --> Router Class Initialized
DEBUG - 2010-06-22 08:48:39 --> Output Class Initialized
DEBUG - 2010-06-22 08:48:39 --> Input Class Initialized
DEBUG - 2010-06-22 08:48:39 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 08:48:39 --> Language Class Initialized
DEBUG - 2010-06-22 08:48:39 --> Loader Class Initialized
DEBUG - 2010-06-22 08:48:40 --> Helper loaded: object_helper
DEBUG - 2010-06-22 08:48:40 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 08:48:40 --> Helper loaded: context_helper
DEBUG - 2010-06-22 08:48:40 --> Session Class Initialized
DEBUG - 2010-06-22 08:48:40 --> Helper loaded: string_helper
ERROR - 2010-06-22 08:48:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\object_helper.php:41) D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Session.php 662
DEBUG - 2010-06-22 08:48:40 --> Session routines successfully run
DEBUG - 2010-06-22 08:48:40 --> Helper loaded: context_helper
DEBUG - 2010-06-22 08:48:40 --> Controller Class Initialized
DEBUG - 2010-06-22 08:48:40 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 08:48:40 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 08:48:40 --> Database Driver Class Initialized
DEBUG - 2010-06-22 08:48:40 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
ERROR - 2010-06-22 08:48:40 --> Severity: Notice  --> Undefined property: Webpage::$db D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Webpage.php 44
DEBUG - 2010-06-22 08:48:47 --> Config Class Initialized
DEBUG - 2010-06-22 08:48:47 --> Hooks Class Initialized
DEBUG - 2010-06-22 08:48:47 --> URI Class Initialized
DEBUG - 2010-06-22 08:48:47 --> Router Class Initialized
DEBUG - 2010-06-22 08:48:47 --> Output Class Initialized
DEBUG - 2010-06-22 08:48:47 --> Input Class Initialized
DEBUG - 2010-06-22 08:48:47 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 08:48:47 --> Language Class Initialized
DEBUG - 2010-06-22 08:48:47 --> Loader Class Initialized
DEBUG - 2010-06-22 08:48:47 --> Helper loaded: object_helper
DEBUG - 2010-06-22 08:48:47 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 08:48:47 --> Helper loaded: context_helper
DEBUG - 2010-06-22 08:48:47 --> Session Class Initialized
DEBUG - 2010-06-22 08:48:47 --> Helper loaded: string_helper
ERROR - 2010-06-22 08:48:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\object_helper.php:41) D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Session.php 662
DEBUG - 2010-06-22 08:48:47 --> Session routines successfully run
DEBUG - 2010-06-22 08:48:47 --> Helper loaded: context_helper
DEBUG - 2010-06-22 08:48:48 --> Controller Class Initialized
DEBUG - 2010-06-22 08:48:48 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 08:48:48 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 08:48:48 --> Database Driver Class Initialized
DEBUG - 2010-06-22 08:48:48 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 08:48:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 08:48:48 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 08:48:55 --> Config Class Initialized
DEBUG - 2010-06-22 08:48:55 --> Hooks Class Initialized
DEBUG - 2010-06-22 08:48:55 --> URI Class Initialized
DEBUG - 2010-06-22 08:48:55 --> Router Class Initialized
DEBUG - 2010-06-22 08:48:55 --> Output Class Initialized
DEBUG - 2010-06-22 08:48:55 --> Input Class Initialized
DEBUG - 2010-06-22 08:48:55 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 08:48:55 --> Language Class Initialized
DEBUG - 2010-06-22 08:48:55 --> Loader Class Initialized
DEBUG - 2010-06-22 08:48:55 --> Helper loaded: object_helper
DEBUG - 2010-06-22 08:48:55 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 08:48:55 --> Helper loaded: context_helper
DEBUG - 2010-06-22 08:48:55 --> Session Class Initialized
DEBUG - 2010-06-22 08:48:55 --> Helper loaded: string_helper
DEBUG - 2010-06-22 08:48:55 --> Session routines successfully run
DEBUG - 2010-06-22 08:48:55 --> Helper loaded: context_helper
DEBUG - 2010-06-22 08:48:55 --> Controller Class Initialized
DEBUG - 2010-06-22 08:48:55 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 08:48:55 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 08:48:55 --> Database Driver Class Initialized
DEBUG - 2010-06-22 08:48:55 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 08:48:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 08:48:56 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 08:49:32 --> Config Class Initialized
DEBUG - 2010-06-22 08:49:32 --> Hooks Class Initialized
DEBUG - 2010-06-22 08:49:32 --> URI Class Initialized
DEBUG - 2010-06-22 08:49:32 --> Router Class Initialized
DEBUG - 2010-06-22 08:49:32 --> Output Class Initialized
DEBUG - 2010-06-22 08:49:32 --> Input Class Initialized
DEBUG - 2010-06-22 08:49:32 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 08:49:32 --> Language Class Initialized
DEBUG - 2010-06-22 08:49:32 --> Loader Class Initialized
DEBUG - 2010-06-22 08:49:33 --> Helper loaded: object_helper
DEBUG - 2010-06-22 08:49:33 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 08:49:33 --> Helper loaded: context_helper
DEBUG - 2010-06-22 08:49:33 --> Session Class Initialized
DEBUG - 2010-06-22 08:49:33 --> Helper loaded: string_helper
DEBUG - 2010-06-22 08:49:33 --> Session routines successfully run
DEBUG - 2010-06-22 08:49:33 --> Helper loaded: context_helper
DEBUG - 2010-06-22 08:49:33 --> Controller Class Initialized
DEBUG - 2010-06-22 08:49:33 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 08:49:33 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 08:49:33 --> Database Driver Class Initialized
DEBUG - 2010-06-22 08:49:33 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 08:49:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 08:49:33 --> Webpage class already loaded. Second attempt ignored.
ERROR - 2010-06-22 08:49:33 --> Severity: Notice  --> Undefined variable: db D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Webpage.php 178
DEBUG - 2010-06-22 08:50:01 --> Config Class Initialized
DEBUG - 2010-06-22 08:50:01 --> Hooks Class Initialized
DEBUG - 2010-06-22 08:50:01 --> URI Class Initialized
DEBUG - 2010-06-22 08:50:01 --> Router Class Initialized
DEBUG - 2010-06-22 08:50:02 --> Output Class Initialized
DEBUG - 2010-06-22 08:50:02 --> Input Class Initialized
DEBUG - 2010-06-22 08:50:02 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 08:50:02 --> Language Class Initialized
DEBUG - 2010-06-22 08:50:02 --> Loader Class Initialized
DEBUG - 2010-06-22 08:50:02 --> Helper loaded: object_helper
DEBUG - 2010-06-22 08:50:02 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 08:50:02 --> Helper loaded: context_helper
DEBUG - 2010-06-22 08:50:02 --> Session Class Initialized
DEBUG - 2010-06-22 08:50:02 --> Helper loaded: string_helper
DEBUG - 2010-06-22 08:50:02 --> Session routines successfully run
DEBUG - 2010-06-22 08:50:02 --> Helper loaded: context_helper
DEBUG - 2010-06-22 08:50:02 --> Controller Class Initialized
DEBUG - 2010-06-22 08:50:02 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 08:50:02 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 08:50:02 --> Database Driver Class Initialized
DEBUG - 2010-06-22 08:50:02 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 08:50:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 08:50:02 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 08:50:02 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
DEBUG - 2010-06-22 08:55:39 --> Config Class Initialized
DEBUG - 2010-06-22 08:55:39 --> Hooks Class Initialized
DEBUG - 2010-06-22 08:55:39 --> URI Class Initialized
DEBUG - 2010-06-22 08:55:39 --> Router Class Initialized
DEBUG - 2010-06-22 08:55:39 --> Output Class Initialized
DEBUG - 2010-06-22 08:55:39 --> Input Class Initialized
DEBUG - 2010-06-22 08:55:39 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 08:55:39 --> Language Class Initialized
DEBUG - 2010-06-22 08:55:39 --> Loader Class Initialized
DEBUG - 2010-06-22 08:55:39 --> Helper loaded: object_helper
DEBUG - 2010-06-22 08:55:39 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 08:55:39 --> Helper loaded: context_helper
DEBUG - 2010-06-22 08:55:39 --> Session Class Initialized
DEBUG - 2010-06-22 08:55:39 --> Helper loaded: string_helper
DEBUG - 2010-06-22 08:55:40 --> Session routines successfully run
DEBUG - 2010-06-22 08:55:40 --> Helper loaded: context_helper
DEBUG - 2010-06-22 08:55:40 --> Controller Class Initialized
DEBUG - 2010-06-22 08:55:40 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 08:55:40 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 08:55:40 --> Database Driver Class Initialized
DEBUG - 2010-06-22 08:55:40 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 08:55:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 08:55:40 --> Webpage class already loaded. Second attempt ignored.
ERROR - 2010-06-22 08:55:40 --> Severity: Notice  --> Undefined property: Webpage::$get_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Webpage.php 182
ERROR - 2010-06-22 08:55:40 --> Severity: Notice  --> Undefined property: Webpage::$get_uri D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Webpage.php 182
ERROR - 2010-06-22 08:55:40 --> Severity: Notice  --> Undefined property: Webpage::$get_title D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Webpage.php 182
INFO  - 2010-06-22 08:55:40 --> Webpage update: (()) () ()
DEBUG - 2010-06-22 08:55:40 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
DEBUG - 2010-06-22 09:06:12 --> Config Class Initialized
DEBUG - 2010-06-22 09:06:12 --> Hooks Class Initialized
DEBUG - 2010-06-22 09:06:12 --> URI Class Initialized
DEBUG - 2010-06-22 09:06:12 --> Router Class Initialized
DEBUG - 2010-06-22 09:06:12 --> Output Class Initialized
DEBUG - 2010-06-22 09:06:12 --> Input Class Initialized
DEBUG - 2010-06-22 09:06:12 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 09:06:12 --> Language Class Initialized
DEBUG - 2010-06-22 09:06:12 --> Loader Class Initialized
DEBUG - 2010-06-22 09:06:12 --> Helper loaded: object_helper
DEBUG - 2010-06-22 09:06:12 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 09:06:12 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:06:12 --> Session Class Initialized
DEBUG - 2010-06-22 09:06:12 --> Helper loaded: string_helper
DEBUG - 2010-06-22 09:06:12 --> Session routines successfully run
DEBUG - 2010-06-22 09:06:12 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:06:12 --> Controller Class Initialized
DEBUG - 2010-06-22 09:06:13 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 09:06:13 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 09:06:54 --> Config Class Initialized
DEBUG - 2010-06-22 09:06:54 --> Hooks Class Initialized
DEBUG - 2010-06-22 09:06:54 --> URI Class Initialized
DEBUG - 2010-06-22 09:06:54 --> Router Class Initialized
DEBUG - 2010-06-22 09:06:54 --> Output Class Initialized
DEBUG - 2010-06-22 09:06:54 --> Input Class Initialized
DEBUG - 2010-06-22 09:06:54 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 09:06:54 --> Language Class Initialized
DEBUG - 2010-06-22 09:06:54 --> Loader Class Initialized
DEBUG - 2010-06-22 09:06:54 --> Helper loaded: object_helper
DEBUG - 2010-06-22 09:06:54 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 09:06:54 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:06:54 --> Session Class Initialized
DEBUG - 2010-06-22 09:06:54 --> Helper loaded: string_helper
DEBUG - 2010-06-22 09:06:54 --> Session routines successfully run
DEBUG - 2010-06-22 09:06:54 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:06:54 --> Controller Class Initialized
DEBUG - 2010-06-22 09:06:54 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 09:06:54 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 09:07:15 --> Config Class Initialized
DEBUG - 2010-06-22 09:07:15 --> Hooks Class Initialized
DEBUG - 2010-06-22 09:07:15 --> URI Class Initialized
DEBUG - 2010-06-22 09:07:15 --> Router Class Initialized
DEBUG - 2010-06-22 09:07:15 --> Output Class Initialized
DEBUG - 2010-06-22 09:07:15 --> Input Class Initialized
DEBUG - 2010-06-22 09:07:15 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 09:07:15 --> Language Class Initialized
DEBUG - 2010-06-22 09:07:15 --> Loader Class Initialized
DEBUG - 2010-06-22 09:07:15 --> Helper loaded: object_helper
DEBUG - 2010-06-22 09:07:15 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 09:07:15 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:07:15 --> Session Class Initialized
DEBUG - 2010-06-22 09:07:15 --> Helper loaded: string_helper
DEBUG - 2010-06-22 09:07:16 --> Session routines successfully run
DEBUG - 2010-06-22 09:07:16 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:07:16 --> Controller Class Initialized
DEBUG - 2010-06-22 09:07:16 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 09:07:16 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 09:07:16 --> Database Driver Class Initialized
DEBUG - 2010-06-22 09:07:16 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 09:07:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:07:16 --> Webpage class already loaded. Second attempt ignored.
ERROR - 2010-06-22 09:07:16 --> 無法建立Webpage，由於沒有設定關連的Domain
DEBUG - 2010-06-22 09:08:25 --> Config Class Initialized
DEBUG - 2010-06-22 09:08:25 --> Hooks Class Initialized
DEBUG - 2010-06-22 09:08:25 --> URI Class Initialized
DEBUG - 2010-06-22 09:08:26 --> Router Class Initialized
DEBUG - 2010-06-22 09:08:26 --> Output Class Initialized
DEBUG - 2010-06-22 09:08:26 --> Input Class Initialized
DEBUG - 2010-06-22 09:08:26 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 09:08:26 --> Language Class Initialized
DEBUG - 2010-06-22 09:08:26 --> Loader Class Initialized
DEBUG - 2010-06-22 09:08:26 --> Helper loaded: object_helper
DEBUG - 2010-06-22 09:08:26 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 09:08:26 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:08:26 --> Session Class Initialized
DEBUG - 2010-06-22 09:08:26 --> Helper loaded: string_helper
DEBUG - 2010-06-22 09:08:26 --> Session routines successfully run
DEBUG - 2010-06-22 09:08:26 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:08:26 --> Controller Class Initialized
DEBUG - 2010-06-22 09:08:26 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 09:08:26 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 09:08:26 --> Database Driver Class Initialized
DEBUG - 2010-06-22 09:08:26 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 09:08:26 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:08:26 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-22 09:08:27 --> Severity: Notice  --> Undefined property: Webpage::$get_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Webpage.php 207
ERROR - 2010-06-22 09:08:27 --> Severity: Notice  --> Undefined property: Webpage::$get_uri D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Webpage.php 207
ERROR - 2010-06-22 09:08:27 --> Severity: Notice  --> Undefined property: Webpage::$get_title D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Webpage.php 207
INFO  - 2010-06-22 09:08:27 --> Webpage Create: (()) () ()
DEBUG - 2010-06-22 09:08:27 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
DEBUG - 2010-06-22 09:12:07 --> Config Class Initialized
DEBUG - 2010-06-22 09:12:07 --> Hooks Class Initialized
DEBUG - 2010-06-22 09:12:07 --> URI Class Initialized
DEBUG - 2010-06-22 09:12:08 --> Router Class Initialized
DEBUG - 2010-06-22 09:12:08 --> Output Class Initialized
DEBUG - 2010-06-22 09:12:08 --> Input Class Initialized
DEBUG - 2010-06-22 09:12:08 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 09:12:08 --> Language Class Initialized
DEBUG - 2010-06-22 09:12:08 --> Loader Class Initialized
DEBUG - 2010-06-22 09:12:08 --> Helper loaded: object_helper
DEBUG - 2010-06-22 09:12:08 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 09:12:08 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:12:08 --> Session Class Initialized
DEBUG - 2010-06-22 09:12:08 --> Helper loaded: string_helper
DEBUG - 2010-06-22 09:12:08 --> Session routines successfully run
DEBUG - 2010-06-22 09:12:08 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:12:08 --> Controller Class Initialized
DEBUG - 2010-06-22 09:12:08 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 09:12:08 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 09:12:08 --> Database Driver Class Initialized
DEBUG - 2010-06-22 09:12:08 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
ERROR - 2010-06-22 09:12:08 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column reference &quot;webpage_id&quot; is ambiguous
LINE 1: SELECT &quot;webpage_id&quot;, &quot;uri&quot;, &quot;title&quot;
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-22 09:12:08 --> DB Transaction Failure
ERROR - 2010-06-22 09:12:08 --> Query error: ERROR:  column reference "webpage_id" is ambiguous
LINE 1: SELECT "webpage_id", "uri", "title"
               ^
DEBUG - 2010-06-22 09:12:08 --> Language file loaded: language/traditional_chinese/db_lang.php
DEBUG - 2010-06-22 09:12:46 --> Config Class Initialized
DEBUG - 2010-06-22 09:12:46 --> Hooks Class Initialized
DEBUG - 2010-06-22 09:12:46 --> URI Class Initialized
DEBUG - 2010-06-22 09:12:46 --> Router Class Initialized
DEBUG - 2010-06-22 09:12:46 --> Output Class Initialized
DEBUG - 2010-06-22 09:12:46 --> Input Class Initialized
DEBUG - 2010-06-22 09:12:46 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 09:12:46 --> Language Class Initialized
DEBUG - 2010-06-22 09:12:46 --> Loader Class Initialized
DEBUG - 2010-06-22 09:12:46 --> Helper loaded: object_helper
DEBUG - 2010-06-22 09:12:46 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 09:12:46 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:12:46 --> Session Class Initialized
DEBUG - 2010-06-22 09:12:46 --> Helper loaded: string_helper
DEBUG - 2010-06-22 09:12:46 --> Session routines successfully run
DEBUG - 2010-06-22 09:12:46 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:12:46 --> Controller Class Initialized
DEBUG - 2010-06-22 09:12:46 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 09:12:47 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 09:12:47 --> Database Driver Class Initialized
DEBUG - 2010-06-22 09:12:47 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 09:12:47 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:12:47 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
DEBUG - 2010-06-22 09:12:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:12:47 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:12:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:12:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:12:59 --> Config Class Initialized
DEBUG - 2010-06-22 09:12:59 --> Hooks Class Initialized
DEBUG - 2010-06-22 09:12:59 --> URI Class Initialized
DEBUG - 2010-06-22 09:12:59 --> Router Class Initialized
DEBUG - 2010-06-22 09:12:59 --> Output Class Initialized
DEBUG - 2010-06-22 09:12:59 --> Input Class Initialized
DEBUG - 2010-06-22 09:12:59 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 09:12:59 --> Language Class Initialized
DEBUG - 2010-06-22 09:12:59 --> Loader Class Initialized
DEBUG - 2010-06-22 09:12:59 --> Helper loaded: object_helper
DEBUG - 2010-06-22 09:12:59 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 09:12:59 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:12:59 --> Session Class Initialized
DEBUG - 2010-06-22 09:12:59 --> Helper loaded: string_helper
DEBUG - 2010-06-22 09:12:59 --> Session routines successfully run
DEBUG - 2010-06-22 09:12:59 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:12:59 --> Controller Class Initialized
DEBUG - 2010-06-22 09:13:00 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 09:13:00 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 09:13:00 --> Database Driver Class Initialized
DEBUG - 2010-06-22 09:13:00 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 09:13:00 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:13:00 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
DEBUG - 2010-06-22 09:13:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:13:00 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:13:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:13:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:13:00 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-22 09:13:00 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_webpage.php 54
DEBUG - 2010-06-22 09:13:22 --> Config Class Initialized
DEBUG - 2010-06-22 09:13:22 --> Hooks Class Initialized
DEBUG - 2010-06-22 09:13:22 --> URI Class Initialized
DEBUG - 2010-06-22 09:13:22 --> Router Class Initialized
DEBUG - 2010-06-22 09:13:22 --> Output Class Initialized
DEBUG - 2010-06-22 09:13:23 --> Input Class Initialized
DEBUG - 2010-06-22 09:13:23 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 09:13:23 --> Language Class Initialized
DEBUG - 2010-06-22 09:13:23 --> Loader Class Initialized
DEBUG - 2010-06-22 09:13:23 --> Helper loaded: object_helper
DEBUG - 2010-06-22 09:13:23 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 09:13:23 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:13:23 --> Session Class Initialized
DEBUG - 2010-06-22 09:13:23 --> Helper loaded: string_helper
DEBUG - 2010-06-22 09:13:23 --> Session routines successfully run
DEBUG - 2010-06-22 09:13:23 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:13:23 --> Controller Class Initialized
DEBUG - 2010-06-22 09:13:23 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 09:13:23 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 09:13:23 --> Database Driver Class Initialized
DEBUG - 2010-06-22 09:13:23 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 09:13:23 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:13:23 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
DEBUG - 2010-06-22 09:13:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:13:23 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:13:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:13:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:13:23 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-22 09:13:23 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_webpage.php 54
DEBUG - 2010-06-22 09:13:35 --> Config Class Initialized
DEBUG - 2010-06-22 09:13:35 --> Hooks Class Initialized
DEBUG - 2010-06-22 09:13:35 --> URI Class Initialized
DEBUG - 2010-06-22 09:13:35 --> Router Class Initialized
DEBUG - 2010-06-22 09:13:35 --> Output Class Initialized
DEBUG - 2010-06-22 09:13:35 --> Input Class Initialized
DEBUG - 2010-06-22 09:13:35 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 09:13:35 --> Language Class Initialized
DEBUG - 2010-06-22 09:13:35 --> Loader Class Initialized
DEBUG - 2010-06-22 09:13:35 --> Helper loaded: object_helper
DEBUG - 2010-06-22 09:13:35 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 09:13:35 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:13:35 --> Session Class Initialized
DEBUG - 2010-06-22 09:13:35 --> Helper loaded: string_helper
DEBUG - 2010-06-22 09:13:35 --> Session routines successfully run
DEBUG - 2010-06-22 09:13:35 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:13:35 --> Controller Class Initialized
DEBUG - 2010-06-22 09:13:35 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 09:13:35 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 09:13:35 --> Database Driver Class Initialized
DEBUG - 2010-06-22 09:13:35 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 09:13:35 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:13:35 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
DEBUG - 2010-06-22 09:13:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:13:35 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:13:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:13:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:13:36 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-22 09:13:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_webpage.php 54
DEBUG - 2010-06-22 09:13:36 --> Webpage class already loaded. Second attempt ignored.
ERROR - 2010-06-22 09:13:36 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  relation &quot;webpage2langvar&quot; does not exist
LINE 2: FROM &quot;webpage2langvar&quot;
             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-22 09:13:36 --> DB Transaction Failure
ERROR - 2010-06-22 09:13:36 --> Query error: ERROR:  relation "webpage2langvar" does not exist
LINE 2: FROM "webpage2langvar"
             ^
DEBUG - 2010-06-22 09:13:36 --> Language file loaded: language/traditional_chinese/db_lang.php
ERROR - 2010-06-22 09:13:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-22 09:18:59 --> Config Class Initialized
DEBUG - 2010-06-22 09:18:59 --> Hooks Class Initialized
DEBUG - 2010-06-22 09:18:59 --> URI Class Initialized
DEBUG - 2010-06-22 09:18:59 --> Router Class Initialized
DEBUG - 2010-06-22 09:18:59 --> Output Class Initialized
DEBUG - 2010-06-22 09:18:59 --> Input Class Initialized
DEBUG - 2010-06-22 09:18:59 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 09:18:59 --> Language Class Initialized
DEBUG - 2010-06-22 09:18:59 --> Loader Class Initialized
DEBUG - 2010-06-22 09:18:59 --> Helper loaded: object_helper
DEBUG - 2010-06-22 09:18:59 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 09:18:59 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:18:59 --> Session Class Initialized
DEBUG - 2010-06-22 09:18:59 --> Helper loaded: string_helper
DEBUG - 2010-06-22 09:19:00 --> Session routines successfully run
DEBUG - 2010-06-22 09:19:00 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:19:00 --> Controller Class Initialized
DEBUG - 2010-06-22 09:19:00 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 09:19:00 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 09:19:00 --> Database Driver Class Initialized
DEBUG - 2010-06-22 09:19:00 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 09:19:00 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:19:00 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
DEBUG - 2010-06-22 09:19:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:19:00 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:19:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:19:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:19:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:22:49 --> Config Class Initialized
DEBUG - 2010-06-22 09:22:49 --> Hooks Class Initialized
DEBUG - 2010-06-22 09:22:49 --> URI Class Initialized
DEBUG - 2010-06-22 09:22:49 --> Router Class Initialized
DEBUG - 2010-06-22 09:22:49 --> Output Class Initialized
DEBUG - 2010-06-22 09:22:49 --> Input Class Initialized
DEBUG - 2010-06-22 09:22:49 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 09:22:49 --> Language Class Initialized
DEBUG - 2010-06-22 09:22:49 --> Loader Class Initialized
DEBUG - 2010-06-22 09:22:49 --> Helper loaded: object_helper
DEBUG - 2010-06-22 09:22:49 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 09:22:49 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:22:49 --> Session Class Initialized
DEBUG - 2010-06-22 09:22:49 --> Helper loaded: string_helper
DEBUG - 2010-06-22 09:22:49 --> Session routines successfully run
DEBUG - 2010-06-22 09:22:49 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:22:49 --> Controller Class Initialized
DEBUG - 2010-06-22 09:22:49 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 09:22:49 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 09:22:49 --> Database Driver Class Initialized
DEBUG - 2010-06-22 09:22:49 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 09:22:49 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:22:50 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
ERROR - 2010-06-22 09:22:50 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-22 09:22:50 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
DEBUG - 2010-06-22 09:22:50 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-22 09:22:50 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-22 09:22:50 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
DEBUG - 2010-06-22 09:22:50 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:22:50 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-22 09:22:50 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-22 09:22:50 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
DEBUG - 2010-06-22 09:22:50 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-22 09:22:50 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-22 09:22:50 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
DEBUG - 2010-06-22 09:22:50 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-22 09:22:50 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-22 09:22:50 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
DEBUG - 2010-06-22 09:23:49 --> Config Class Initialized
DEBUG - 2010-06-22 09:23:49 --> Hooks Class Initialized
DEBUG - 2010-06-22 09:23:49 --> URI Class Initialized
DEBUG - 2010-06-22 09:23:49 --> Router Class Initialized
DEBUG - 2010-06-22 09:23:49 --> Output Class Initialized
DEBUG - 2010-06-22 09:23:49 --> Input Class Initialized
DEBUG - 2010-06-22 09:23:49 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 09:23:49 --> Language Class Initialized
DEBUG - 2010-06-22 09:23:49 --> Loader Class Initialized
DEBUG - 2010-06-22 09:23:49 --> Helper loaded: object_helper
DEBUG - 2010-06-22 09:23:50 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 09:23:50 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:23:50 --> Session Class Initialized
DEBUG - 2010-06-22 09:23:50 --> Helper loaded: string_helper
DEBUG - 2010-06-22 09:23:50 --> Session routines successfully run
DEBUG - 2010-06-22 09:23:50 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:23:50 --> Controller Class Initialized
DEBUG - 2010-06-22 09:23:50 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 09:23:50 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 09:23:50 --> Database Driver Class Initialized
DEBUG - 2010-06-22 09:23:50 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 09:23:50 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:23:50 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
ERROR - 2010-06-22 09:23:50 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 41
ERROR - 2010-06-22 09:23:50 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 41
DEBUG - 2010-06-22 09:23:50 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-22 09:23:50 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 41
ERROR - 2010-06-22 09:23:50 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 41
DEBUG - 2010-06-22 09:23:50 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:23:50 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-22 09:23:50 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 41
ERROR - 2010-06-22 09:23:50 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 41
DEBUG - 2010-06-22 09:23:50 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-22 09:23:50 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 41
ERROR - 2010-06-22 09:23:50 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 41
DEBUG - 2010-06-22 09:23:50 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-22 09:23:50 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 41
ERROR - 2010-06-22 09:23:51 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 41
DEBUG - 2010-06-22 09:25:08 --> Config Class Initialized
DEBUG - 2010-06-22 09:25:08 --> Hooks Class Initialized
DEBUG - 2010-06-22 09:25:08 --> URI Class Initialized
DEBUG - 2010-06-22 09:25:08 --> Router Class Initialized
DEBUG - 2010-06-22 09:25:08 --> Output Class Initialized
DEBUG - 2010-06-22 09:25:08 --> Input Class Initialized
DEBUG - 2010-06-22 09:25:08 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 09:25:08 --> Language Class Initialized
DEBUG - 2010-06-22 09:25:08 --> Loader Class Initialized
DEBUG - 2010-06-22 09:25:08 --> Helper loaded: object_helper
DEBUG - 2010-06-22 09:25:08 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 09:25:08 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:25:08 --> Session Class Initialized
DEBUG - 2010-06-22 09:25:08 --> Helper loaded: string_helper
DEBUG - 2010-06-22 09:25:08 --> Session routines successfully run
DEBUG - 2010-06-22 09:25:08 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:25:08 --> Controller Class Initialized
DEBUG - 2010-06-22 09:25:08 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 09:25:08 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 09:25:08 --> Database Driver Class Initialized
DEBUG - 2010-06-22 09:25:09 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 09:25:09 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:25:09 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
ERROR - 2010-06-22 09:25:09 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 42
ERROR - 2010-06-22 09:25:09 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 42
DEBUG - 2010-06-22 09:25:09 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-22 09:25:09 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 42
ERROR - 2010-06-22 09:25:09 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 42
DEBUG - 2010-06-22 09:25:09 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:25:09 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-22 09:25:09 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 42
ERROR - 2010-06-22 09:25:09 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 42
DEBUG - 2010-06-22 09:25:09 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-22 09:25:09 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 42
ERROR - 2010-06-22 09:25:09 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 42
DEBUG - 2010-06-22 09:25:09 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-22 09:25:09 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 42
ERROR - 2010-06-22 09:25:09 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 42
DEBUG - 2010-06-22 09:25:39 --> Config Class Initialized
DEBUG - 2010-06-22 09:25:39 --> Hooks Class Initialized
DEBUG - 2010-06-22 09:25:39 --> URI Class Initialized
DEBUG - 2010-06-22 09:25:39 --> Router Class Initialized
DEBUG - 2010-06-22 09:25:39 --> Output Class Initialized
DEBUG - 2010-06-22 09:25:39 --> Input Class Initialized
DEBUG - 2010-06-22 09:25:39 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 09:25:39 --> Language Class Initialized
DEBUG - 2010-06-22 09:25:39 --> Loader Class Initialized
DEBUG - 2010-06-22 09:25:39 --> Helper loaded: object_helper
DEBUG - 2010-06-22 09:25:40 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 09:25:40 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:25:40 --> Session Class Initialized
DEBUG - 2010-06-22 09:25:40 --> Helper loaded: string_helper
DEBUG - 2010-06-22 09:25:40 --> Session routines successfully run
DEBUG - 2010-06-22 09:25:40 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:25:40 --> Controller Class Initialized
DEBUG - 2010-06-22 09:25:40 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 09:25:40 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 09:25:40 --> Database Driver Class Initialized
DEBUG - 2010-06-22 09:25:40 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 09:25:40 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:25:40 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
ERROR - 2010-06-22 09:25:40 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 42
ERROR - 2010-06-22 09:25:40 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 42
DEBUG - 2010-06-22 09:25:40 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-22 09:25:40 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 42
ERROR - 2010-06-22 09:25:40 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 42
DEBUG - 2010-06-22 09:25:40 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:25:40 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-22 09:25:40 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 42
ERROR - 2010-06-22 09:25:40 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 42
DEBUG - 2010-06-22 09:25:40 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-22 09:25:40 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 42
ERROR - 2010-06-22 09:25:40 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 42
DEBUG - 2010-06-22 09:25:40 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-22 09:25:41 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 42
ERROR - 2010-06-22 09:25:41 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 42
DEBUG - 2010-06-22 09:25:56 --> Config Class Initialized
DEBUG - 2010-06-22 09:25:56 --> Hooks Class Initialized
DEBUG - 2010-06-22 09:25:56 --> URI Class Initialized
DEBUG - 2010-06-22 09:25:56 --> Router Class Initialized
DEBUG - 2010-06-22 09:25:56 --> Output Class Initialized
DEBUG - 2010-06-22 09:25:56 --> Input Class Initialized
DEBUG - 2010-06-22 09:25:56 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 09:25:56 --> Language Class Initialized
DEBUG - 2010-06-22 09:25:56 --> Loader Class Initialized
DEBUG - 2010-06-22 09:25:56 --> Helper loaded: object_helper
DEBUG - 2010-06-22 09:25:56 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 09:25:56 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:25:56 --> Session Class Initialized
DEBUG - 2010-06-22 09:25:56 --> Helper loaded: string_helper
DEBUG - 2010-06-22 09:25:56 --> Session routines successfully run
DEBUG - 2010-06-22 09:25:56 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:25:56 --> Controller Class Initialized
DEBUG - 2010-06-22 09:25:56 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 09:25:56 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 09:25:56 --> Database Driver Class Initialized
DEBUG - 2010-06-22 09:25:56 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 09:25:57 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:25:57 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
DEBUG - 2010-06-22 09:25:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:25:57 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:25:57 --> Webpage class already loaded. Second attempt ignored.
ERROR - 2010-06-22 09:25:57 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;webpage&quot; does not exist
LINE 3: WHERE &quot;webpage&quot; = 1
              ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-22 09:25:57 --> DB Transaction Failure
ERROR - 2010-06-22 09:25:57 --> Query error: ERROR:  column "webpage" does not exist
LINE 3: WHERE "webpage" = 1
              ^
DEBUG - 2010-06-22 09:25:57 --> Language file loaded: language/traditional_chinese/db_lang.php
ERROR - 2010-06-22 09:25:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:40) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-22 09:26:25 --> Config Class Initialized
DEBUG - 2010-06-22 09:26:25 --> Hooks Class Initialized
DEBUG - 2010-06-22 09:26:26 --> URI Class Initialized
DEBUG - 2010-06-22 09:26:26 --> Router Class Initialized
DEBUG - 2010-06-22 09:26:26 --> Output Class Initialized
DEBUG - 2010-06-22 09:26:26 --> Input Class Initialized
DEBUG - 2010-06-22 09:26:26 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 09:26:26 --> Language Class Initialized
DEBUG - 2010-06-22 09:26:26 --> Loader Class Initialized
DEBUG - 2010-06-22 09:26:26 --> Helper loaded: object_helper
DEBUG - 2010-06-22 09:26:26 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 09:26:26 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:26:26 --> Session Class Initialized
DEBUG - 2010-06-22 09:26:26 --> Helper loaded: string_helper
DEBUG - 2010-06-22 09:26:26 --> Session routines successfully run
DEBUG - 2010-06-22 09:26:26 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:26:26 --> Controller Class Initialized
DEBUG - 2010-06-22 09:26:26 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 09:26:26 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 09:26:26 --> Database Driver Class Initialized
DEBUG - 2010-06-22 09:26:26 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 09:26:26 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:26:26 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
DEBUG - 2010-06-22 09:26:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:26:27 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:26:27 --> Webpage class already loaded. Second attempt ignored.
ERROR - 2010-06-22 09:26:27 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;webpage&quot; does not exist
LINE 3: WHERE &quot;webpage&quot; = 1
              ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-22 09:26:27 --> DB Transaction Failure
ERROR - 2010-06-22 09:26:27 --> Query error: ERROR:  column "webpage" does not exist
LINE 3: WHERE "webpage" = 1
              ^
DEBUG - 2010-06-22 09:26:27 --> Language file loaded: language/traditional_chinese/db_lang.php
DEBUG - 2010-06-22 09:27:52 --> Config Class Initialized
DEBUG - 2010-06-22 09:27:52 --> Hooks Class Initialized
DEBUG - 2010-06-22 09:27:52 --> URI Class Initialized
DEBUG - 2010-06-22 09:27:52 --> Router Class Initialized
DEBUG - 2010-06-22 09:27:52 --> Output Class Initialized
DEBUG - 2010-06-22 09:27:52 --> Input Class Initialized
DEBUG - 2010-06-22 09:27:52 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 09:27:52 --> Language Class Initialized
DEBUG - 2010-06-22 09:27:52 --> Loader Class Initialized
DEBUG - 2010-06-22 09:27:52 --> Helper loaded: object_helper
DEBUG - 2010-06-22 09:27:52 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 09:27:52 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:27:53 --> Session Class Initialized
DEBUG - 2010-06-22 09:27:53 --> Helper loaded: string_helper
DEBUG - 2010-06-22 09:27:53 --> Session routines successfully run
DEBUG - 2010-06-22 09:27:53 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:27:53 --> Controller Class Initialized
DEBUG - 2010-06-22 09:27:53 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 09:27:53 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 09:28:24 --> Config Class Initialized
DEBUG - 2010-06-22 09:28:24 --> Hooks Class Initialized
DEBUG - 2010-06-22 09:28:24 --> URI Class Initialized
DEBUG - 2010-06-22 09:28:24 --> Router Class Initialized
DEBUG - 2010-06-22 09:28:24 --> Output Class Initialized
DEBUG - 2010-06-22 09:28:24 --> Input Class Initialized
DEBUG - 2010-06-22 09:28:24 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 09:28:24 --> Language Class Initialized
DEBUG - 2010-06-22 09:28:24 --> Loader Class Initialized
DEBUG - 2010-06-22 09:28:24 --> Helper loaded: object_helper
DEBUG - 2010-06-22 09:28:24 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 09:28:24 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:28:25 --> Session Class Initialized
DEBUG - 2010-06-22 09:28:25 --> Helper loaded: string_helper
DEBUG - 2010-06-22 09:28:25 --> Session routines successfully run
DEBUG - 2010-06-22 09:28:25 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:28:25 --> Controller Class Initialized
DEBUG - 2010-06-22 09:28:25 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 09:28:25 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 09:28:25 --> Database Driver Class Initialized
DEBUG - 2010-06-22 09:28:25 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 09:28:25 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:28:25 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
DEBUG - 2010-06-22 09:28:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:28:26 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:28:26 --> Webpage class already loaded. Second attempt ignored.
ERROR - 2010-06-22 09:28:26 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;webpage&quot; does not exist
LINE 3: WHERE &quot;webpage&quot; = 1
              ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-22 09:28:26 --> DB Transaction Failure
ERROR - 2010-06-22 09:28:26 --> Query error: ERROR:  column "webpage" does not exist
LINE 3: WHERE "webpage" = 1
              ^
DEBUG - 2010-06-22 09:28:26 --> Language file loaded: language/traditional_chinese/db_lang.php
DEBUG - 2010-06-22 09:28:54 --> Config Class Initialized
DEBUG - 2010-06-22 09:28:54 --> Hooks Class Initialized
DEBUG - 2010-06-22 09:28:55 --> URI Class Initialized
DEBUG - 2010-06-22 09:28:55 --> Router Class Initialized
DEBUG - 2010-06-22 09:28:55 --> Output Class Initialized
DEBUG - 2010-06-22 09:28:55 --> Input Class Initialized
DEBUG - 2010-06-22 09:28:55 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 09:28:55 --> Language Class Initialized
DEBUG - 2010-06-22 09:28:55 --> Loader Class Initialized
DEBUG - 2010-06-22 09:28:55 --> Helper loaded: object_helper
DEBUG - 2010-06-22 09:28:55 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 09:28:55 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:28:55 --> Session Class Initialized
DEBUG - 2010-06-22 09:28:55 --> Helper loaded: string_helper
DEBUG - 2010-06-22 09:28:55 --> Session routines successfully run
DEBUG - 2010-06-22 09:28:55 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:28:55 --> Controller Class Initialized
DEBUG - 2010-06-22 09:28:55 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 09:28:55 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 09:28:55 --> Database Driver Class Initialized
DEBUG - 2010-06-22 09:28:55 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 09:28:55 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:28:55 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
DEBUG - 2010-06-22 09:28:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:28:56 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:28:56 --> Webpage class already loaded. Second attempt ignored.
ERROR - 2010-06-22 09:28:56 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  relation &quot;webpage2annotation&quot; does not exist
LINE 2: FROM &quot;webpage2annotation&quot;
             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-22 09:28:56 --> DB Transaction Failure
ERROR - 2010-06-22 09:28:56 --> Query error: ERROR:  relation "webpage2annotation" does not exist
LINE 2: FROM "webpage2annotation"
             ^
DEBUG - 2010-06-22 09:28:56 --> Language file loaded: language/traditional_chinese/db_lang.php
DEBUG - 2010-06-22 09:31:42 --> Config Class Initialized
DEBUG - 2010-06-22 09:31:42 --> Hooks Class Initialized
DEBUG - 2010-06-22 09:31:42 --> URI Class Initialized
DEBUG - 2010-06-22 09:31:42 --> Router Class Initialized
DEBUG - 2010-06-22 09:31:42 --> Output Class Initialized
DEBUG - 2010-06-22 09:31:42 --> Input Class Initialized
DEBUG - 2010-06-22 09:31:42 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 09:31:42 --> Language Class Initialized
DEBUG - 2010-06-22 09:31:42 --> Loader Class Initialized
DEBUG - 2010-06-22 09:31:42 --> Helper loaded: object_helper
DEBUG - 2010-06-22 09:31:42 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 09:31:42 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:31:42 --> Session Class Initialized
DEBUG - 2010-06-22 09:31:42 --> Helper loaded: string_helper
DEBUG - 2010-06-22 09:31:42 --> Session routines successfully run
DEBUG - 2010-06-22 09:31:43 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:31:43 --> Controller Class Initialized
DEBUG - 2010-06-22 09:31:43 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 09:31:43 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 09:31:43 --> Database Driver Class Initialized
DEBUG - 2010-06-22 09:31:43 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 09:31:43 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:31:43 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
DEBUG - 2010-06-22 09:31:43 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:31:43 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:31:43 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:31:54 --> Config Class Initialized
DEBUG - 2010-06-22 09:31:54 --> Hooks Class Initialized
DEBUG - 2010-06-22 09:31:54 --> URI Class Initialized
DEBUG - 2010-06-22 09:31:54 --> Router Class Initialized
DEBUG - 2010-06-22 09:31:54 --> Output Class Initialized
DEBUG - 2010-06-22 09:31:54 --> Input Class Initialized
DEBUG - 2010-06-22 09:31:55 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 09:31:55 --> Language Class Initialized
DEBUG - 2010-06-22 09:31:55 --> Loader Class Initialized
DEBUG - 2010-06-22 09:31:55 --> Helper loaded: object_helper
DEBUG - 2010-06-22 09:31:55 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 09:31:55 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:31:55 --> Session Class Initialized
DEBUG - 2010-06-22 09:31:55 --> Helper loaded: string_helper
DEBUG - 2010-06-22 09:31:55 --> Session routines successfully run
DEBUG - 2010-06-22 09:31:55 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:31:55 --> Controller Class Initialized
DEBUG - 2010-06-22 09:31:55 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 09:31:55 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 09:31:55 --> Database Driver Class Initialized
DEBUG - 2010-06-22 09:31:55 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 09:31:55 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:31:55 --> Domain class already loaded. Second attempt ignored.
INFO  - 2010-06-22 09:31:56 --> Webpage Create: (2) /p/5x1uan#response-1650638188 
DEBUG - 2010-06-22 09:31:56 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
DEBUG - 2010-06-22 09:31:56 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:31:57 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-22 09:31:57 --> Final output sent to browser
DEBUG - 2010-06-22 09:31:57 --> Total execution time: 2.2953
DEBUG - 2010-06-22 09:33:32 --> Config Class Initialized
DEBUG - 2010-06-22 09:33:32 --> Hooks Class Initialized
DEBUG - 2010-06-22 09:33:32 --> URI Class Initialized
DEBUG - 2010-06-22 09:33:32 --> Router Class Initialized
DEBUG - 2010-06-22 09:33:32 --> Output Class Initialized
DEBUG - 2010-06-22 09:33:32 --> Input Class Initialized
DEBUG - 2010-06-22 09:33:32 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 09:33:32 --> Language Class Initialized
DEBUG - 2010-06-22 09:33:33 --> Loader Class Initialized
DEBUG - 2010-06-22 09:33:33 --> Helper loaded: object_helper
DEBUG - 2010-06-22 09:33:33 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 09:33:33 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:33:33 --> Session Class Initialized
DEBUG - 2010-06-22 09:33:33 --> Helper loaded: string_helper
DEBUG - 2010-06-22 09:33:33 --> Session routines successfully run
DEBUG - 2010-06-22 09:33:33 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:33:33 --> Controller Class Initialized
DEBUG - 2010-06-22 09:33:33 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 09:33:33 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 09:33:33 --> Database Driver Class Initialized
DEBUG - 2010-06-22 09:33:33 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 09:33:33 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:33:33 --> Domain class already loaded. Second attempt ignored.
INFO  - 2010-06-22 09:33:34 --> Webpage Create: (3) /p/5x1uan#response-1650638188 
DEBUG - 2010-06-22 09:33:34 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
DEBUG - 2010-06-22 09:33:34 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:33:34 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-22 09:33:34 --> Final output sent to browser
DEBUG - 2010-06-22 09:33:34 --> Total execution time: 1.6969
DEBUG - 2010-06-22 09:34:10 --> Config Class Initialized
DEBUG - 2010-06-22 09:34:10 --> Hooks Class Initialized
DEBUG - 2010-06-22 09:34:10 --> URI Class Initialized
DEBUG - 2010-06-22 09:34:10 --> Router Class Initialized
DEBUG - 2010-06-22 09:34:10 --> Output Class Initialized
DEBUG - 2010-06-22 09:34:10 --> Input Class Initialized
DEBUG - 2010-06-22 09:34:10 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 09:34:10 --> Language Class Initialized
DEBUG - 2010-06-22 09:34:10 --> Loader Class Initialized
DEBUG - 2010-06-22 09:34:11 --> Helper loaded: object_helper
DEBUG - 2010-06-22 09:34:11 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 09:34:11 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:34:11 --> Session Class Initialized
DEBUG - 2010-06-22 09:34:11 --> Helper loaded: string_helper
DEBUG - 2010-06-22 09:34:11 --> Session routines successfully run
DEBUG - 2010-06-22 09:34:11 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:34:11 --> Controller Class Initialized
DEBUG - 2010-06-22 09:34:11 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 09:34:11 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 09:34:11 --> Database Driver Class Initialized
DEBUG - 2010-06-22 09:34:11 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 09:34:11 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:34:11 --> Domain class already loaded. Second attempt ignored.
INFO  - 2010-06-22 09:34:12 --> Webpage Create: (4) /p/5x1uan#response-1650638188 
DEBUG - 2010-06-22 09:34:12 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
DEBUG - 2010-06-22 09:34:12 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:34:12 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-22 09:34:12 --> Final output sent to browser
DEBUG - 2010-06-22 09:34:12 --> Total execution time: 1.7011
DEBUG - 2010-06-22 09:34:42 --> Config Class Initialized
DEBUG - 2010-06-22 09:34:42 --> Hooks Class Initialized
DEBUG - 2010-06-22 09:34:42 --> URI Class Initialized
DEBUG - 2010-06-22 09:34:42 --> Router Class Initialized
DEBUG - 2010-06-22 09:34:42 --> Output Class Initialized
DEBUG - 2010-06-22 09:34:42 --> Input Class Initialized
DEBUG - 2010-06-22 09:34:42 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 09:34:42 --> Language Class Initialized
DEBUG - 2010-06-22 09:34:42 --> Loader Class Initialized
DEBUG - 2010-06-22 09:34:42 --> Helper loaded: object_helper
DEBUG - 2010-06-22 09:34:42 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 09:34:42 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:34:42 --> Session Class Initialized
DEBUG - 2010-06-22 09:34:43 --> Helper loaded: string_helper
DEBUG - 2010-06-22 09:34:43 --> Session routines successfully run
DEBUG - 2010-06-22 09:34:43 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:34:43 --> Controller Class Initialized
DEBUG - 2010-06-22 09:34:43 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 09:34:43 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 09:34:43 --> Database Driver Class Initialized
DEBUG - 2010-06-22 09:34:43 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 09:34:43 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:34:43 --> Domain class already loaded. Second attempt ignored.
INFO  - 2010-06-22 09:34:44 --> Webpage Create: (5) /p/5x1uan#response-1650638188 PHP布丁 說 [CODING D4] 目前進度5/182。希望今天能夠打起精神好好地來做！ - #5x1uan
DEBUG - 2010-06-22 09:34:44 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
DEBUG - 2010-06-22 09:34:44 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:34:44 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-22 09:34:44 --> Final output sent to browser
DEBUG - 2010-06-22 09:34:44 --> Total execution time: 2.2194
DEBUG - 2010-06-22 09:39:44 --> Config Class Initialized
DEBUG - 2010-06-22 09:39:44 --> Hooks Class Initialized
DEBUG - 2010-06-22 09:39:44 --> URI Class Initialized
DEBUG - 2010-06-22 09:39:45 --> Router Class Initialized
DEBUG - 2010-06-22 09:39:45 --> Output Class Initialized
DEBUG - 2010-06-22 09:39:45 --> Input Class Initialized
DEBUG - 2010-06-22 09:39:45 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 09:39:45 --> Language Class Initialized
DEBUG - 2010-06-22 09:39:59 --> Config Class Initialized
DEBUG - 2010-06-22 09:40:00 --> Hooks Class Initialized
DEBUG - 2010-06-22 09:40:00 --> URI Class Initialized
DEBUG - 2010-06-22 09:40:00 --> Router Class Initialized
DEBUG - 2010-06-22 09:40:00 --> Output Class Initialized
DEBUG - 2010-06-22 09:40:00 --> Input Class Initialized
DEBUG - 2010-06-22 09:40:00 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 09:40:00 --> Language Class Initialized
DEBUG - 2010-06-22 09:40:00 --> Loader Class Initialized
DEBUG - 2010-06-22 09:40:00 --> Helper loaded: object_helper
DEBUG - 2010-06-22 09:40:00 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 09:40:00 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:40:00 --> Session Class Initialized
DEBUG - 2010-06-22 09:40:00 --> Helper loaded: string_helper
DEBUG - 2010-06-22 09:40:00 --> Session routines successfully run
DEBUG - 2010-06-22 09:40:00 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:40:00 --> Controller Class Initialized
DEBUG - 2010-06-22 09:40:00 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 09:40:00 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 09:40:00 --> Database Driver Class Initialized
DEBUG - 2010-06-22 09:40:00 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 09:40:10 --> Config Class Initialized
DEBUG - 2010-06-22 09:40:10 --> Hooks Class Initialized
DEBUG - 2010-06-22 09:40:10 --> URI Class Initialized
DEBUG - 2010-06-22 09:40:10 --> Router Class Initialized
DEBUG - 2010-06-22 09:40:10 --> Output Class Initialized
DEBUG - 2010-06-22 09:40:10 --> Input Class Initialized
DEBUG - 2010-06-22 09:40:10 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 09:40:10 --> Language Class Initialized
DEBUG - 2010-06-22 09:40:10 --> Loader Class Initialized
DEBUG - 2010-06-22 09:40:10 --> Helper loaded: object_helper
DEBUG - 2010-06-22 09:40:10 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 09:40:10 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:40:11 --> Session Class Initialized
DEBUG - 2010-06-22 09:40:11 --> Helper loaded: string_helper
DEBUG - 2010-06-22 09:40:11 --> Session routines successfully run
DEBUG - 2010-06-22 09:40:11 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:40:11 --> Controller Class Initialized
DEBUG - 2010-06-22 09:40:11 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 09:40:11 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 09:40:11 --> Database Driver Class Initialized
DEBUG - 2010-06-22 09:40:11 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 09:40:11 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:40:11 --> Domain class already loaded. Second attempt ignored.
INFO  - 2010-06-22 09:40:12 --> Webpage Create: (6) /p/5x1uan#response-1650638188 PHP布丁 說 [CODING D4] 目前進度5/182。希望今天能夠打起精神好好地來做！ - #5x1uan
DEBUG - 2010-06-22 09:40:12 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
DEBUG - 2010-06-22 09:40:12 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:40:12 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-22 09:40:12 --> Final output sent to browser
DEBUG - 2010-06-22 09:40:12 --> Total execution time: 1.7515
DEBUG - 2010-06-22 09:40:34 --> Config Class Initialized
DEBUG - 2010-06-22 09:40:34 --> Hooks Class Initialized
DEBUG - 2010-06-22 09:40:34 --> URI Class Initialized
DEBUG - 2010-06-22 09:40:34 --> Router Class Initialized
DEBUG - 2010-06-22 09:40:34 --> Output Class Initialized
DEBUG - 2010-06-22 09:40:34 --> Input Class Initialized
DEBUG - 2010-06-22 09:40:34 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 09:40:34 --> Language Class Initialized
DEBUG - 2010-06-22 09:40:34 --> Loader Class Initialized
DEBUG - 2010-06-22 09:40:34 --> Helper loaded: object_helper
DEBUG - 2010-06-22 09:40:34 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 09:40:34 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:40:34 --> Session Class Initialized
DEBUG - 2010-06-22 09:40:34 --> Helper loaded: string_helper
DEBUG - 2010-06-22 09:40:34 --> Session routines successfully run
DEBUG - 2010-06-22 09:40:34 --> Helper loaded: context_helper
DEBUG - 2010-06-22 09:40:34 --> Controller Class Initialized
DEBUG - 2010-06-22 09:40:34 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 09:40:35 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 09:40:35 --> Database Driver Class Initialized
DEBUG - 2010-06-22 09:40:35 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 09:40:35 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 09:40:35 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
DEBUG - 2010-06-22 09:40:35 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-22 09:40:35 --> Final output sent to browser
DEBUG - 2010-06-22 09:40:35 --> Total execution time: 1.1713
DEBUG - 2010-06-22 13:36:31 --> Config Class Initialized
DEBUG - 2010-06-22 13:36:32 --> Hooks Class Initialized
DEBUG - 2010-06-22 13:36:32 --> URI Class Initialized
DEBUG - 2010-06-22 13:36:32 --> Router Class Initialized
DEBUG - 2010-06-22 13:36:32 --> Output Class Initialized
DEBUG - 2010-06-22 13:36:32 --> Input Class Initialized
DEBUG - 2010-06-22 13:36:32 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 13:36:32 --> Language Class Initialized
DEBUG - 2010-06-22 13:36:32 --> Loader Class Initialized
DEBUG - 2010-06-22 13:36:32 --> Helper loaded: object_helper
DEBUG - 2010-06-22 13:36:49 --> Config Class Initialized
DEBUG - 2010-06-22 13:36:50 --> Hooks Class Initialized
DEBUG - 2010-06-22 13:36:50 --> URI Class Initialized
DEBUG - 2010-06-22 13:36:50 --> Router Class Initialized
DEBUG - 2010-06-22 13:36:50 --> Output Class Initialized
DEBUG - 2010-06-22 13:36:50 --> Input Class Initialized
DEBUG - 2010-06-22 13:36:50 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 13:36:50 --> Language Class Initialized
DEBUG - 2010-06-22 13:36:50 --> Loader Class Initialized
DEBUG - 2010-06-22 13:36:50 --> Helper loaded: object_helper
DEBUG - 2010-06-22 13:36:50 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 13:36:50 --> Helper loaded: context_helper
DEBUG - 2010-06-22 13:36:50 --> Session Class Initialized
DEBUG - 2010-06-22 13:36:50 --> Helper loaded: string_helper
DEBUG - 2010-06-22 13:36:50 --> A session cookie was not found.
DEBUG - 2010-06-22 13:36:50 --> Session routines successfully run
DEBUG - 2010-06-22 13:36:50 --> Helper loaded: context_helper
DEBUG - 2010-06-22 13:36:50 --> Controller Class Initialized
DEBUG - 2010-06-22 13:36:50 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 13:36:50 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 13:36:51 --> Database Driver Class Initialized
DEBUG - 2010-06-22 13:36:51 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 13:36:51 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 13:36:51 --> Domain class already loaded. Second attempt ignored.
INFO  - 2010-06-22 13:36:52 --> Webpage Create: (7) /p/5x1uan#response-1650638188 PHP布丁 說 [CODING D4] 目前進度5/182。希望今天能夠打起精神好好地來做！ - #5x1uan
DEBUG - 2010-06-22 13:36:52 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
DEBUG - 2010-06-22 13:43:03 --> Config Class Initialized
DEBUG - 2010-06-22 13:43:03 --> Hooks Class Initialized
DEBUG - 2010-06-22 13:43:03 --> URI Class Initialized
DEBUG - 2010-06-22 13:43:03 --> Router Class Initialized
DEBUG - 2010-06-22 13:43:03 --> Output Class Initialized
DEBUG - 2010-06-22 13:43:03 --> Input Class Initialized
DEBUG - 2010-06-22 13:43:03 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-22 13:43:03 --> Language Class Initialized
DEBUG - 2010-06-22 13:43:03 --> Loader Class Initialized
DEBUG - 2010-06-22 13:43:03 --> Helper loaded: object_helper
DEBUG - 2010-06-22 13:43:03 --> Helper loaded: kals_helper
DEBUG - 2010-06-22 13:43:03 --> Helper loaded: context_helper
DEBUG - 2010-06-22 13:43:03 --> Session Class Initialized
DEBUG - 2010-06-22 13:43:03 --> Helper loaded: string_helper
DEBUG - 2010-06-22 13:43:03 --> Session routines successfully run
DEBUG - 2010-06-22 13:43:03 --> Helper loaded: context_helper
DEBUG - 2010-06-22 13:43:03 --> Controller Class Initialized
DEBUG - 2010-06-22 13:43:03 --> Unit Testing Class Initialized
DEBUG - 2010-06-22 13:43:04 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-22 13:43:04 --> Database Driver Class Initialized
DEBUG - 2010-06-22 13:43:04 --> Language file loaded: language/traditional_chinese/kals_resource_lang.php
DEBUG - 2010-06-22 13:43:04 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 13:43:04 --> Language file loaded: language/traditional_chinese/unit_test_lang.php
DEBUG - 2010-06-22 13:43:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 13:43:04 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-22 13:43:04 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-22 13:43:04 --> Final output sent to browser
DEBUG - 2010-06-22 13:43:04 --> Total execution time: 1.4415
