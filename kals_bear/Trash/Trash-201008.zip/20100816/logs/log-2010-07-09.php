<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2010-07-09 01:56:17 --> Config Class Initialized
DEBUG - 2010-07-09 01:56:17 --> Hooks Class Initialized
DEBUG - 2010-07-09 01:56:17 --> URI Class Initialized
DEBUG - 2010-07-09 01:56:17 --> Router Class Initialized
DEBUG - 2010-07-09 01:56:17 --> Output Class Initialized
DEBUG - 2010-07-09 01:56:17 --> Input Class Initialized
DEBUG - 2010-07-09 01:56:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 01:56:17 --> Language Class Initialized
DEBUG - 2010-07-09 01:56:17 --> Loader Class Initialized
DEBUG - 2010-07-09 01:56:17 --> Helper loaded: context_helper
DEBUG - 2010-07-09 01:56:17 --> Helper loaded: kals_helper
DEBUG - 2010-07-09 01:56:17 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-09 01:56:17 --> Database Driver Class Initialized
DEBUG - 2010-07-09 01:56:17 --> Controller Class Initialized
DEBUG - 2010-07-09 01:56:17 --> Unit Testing Class Initialized
DEBUG - 2010-07-09 01:56:17 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-09 01:56:17 --> Session Class Initialized
DEBUG - 2010-07-09 01:56:17 --> Helper loaded: string_helper
DEBUG - 2010-07-09 01:56:17 --> A session cookie was not found.
DEBUG - 2010-07-09 01:56:17 --> Session routines successfully run
DEBUG - 2010-07-09 01:56:17 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-09 01:56:17 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-09 01:56:17 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-09 01:56:17 --> Helper loaded: text_helper
DEBUG - 2010-07-09 01:56:17 --> Final output sent to browser
DEBUG - 2010-07-09 01:56:17 --> Total execution time: 0.4895
DEBUG - 2010-07-09 02:01:21 --> Config Class Initialized
DEBUG - 2010-07-09 02:01:21 --> Hooks Class Initialized
DEBUG - 2010-07-09 02:01:21 --> URI Class Initialized
DEBUG - 2010-07-09 02:01:21 --> Router Class Initialized
DEBUG - 2010-07-09 02:01:21 --> Output Class Initialized
DEBUG - 2010-07-09 02:01:21 --> Input Class Initialized
DEBUG - 2010-07-09 02:01:21 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 02:01:21 --> Language Class Initialized
DEBUG - 2010-07-09 02:01:21 --> Loader Class Initialized
DEBUG - 2010-07-09 02:01:21 --> Helper loaded: context_helper
DEBUG - 2010-07-09 02:01:21 --> Helper loaded: kals_helper
DEBUG - 2010-07-09 02:01:21 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-09 02:01:21 --> Database Driver Class Initialized
DEBUG - 2010-07-09 02:01:21 --> Controller Class Initialized
DEBUG - 2010-07-09 02:01:21 --> Unit Testing Class Initialized
DEBUG - 2010-07-09 02:01:21 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-09 02:01:21 --> Session Class Initialized
DEBUG - 2010-07-09 02:01:21 --> Helper loaded: string_helper
DEBUG - 2010-07-09 02:01:21 --> Session routines successfully run
DEBUG - 2010-07-09 02:01:21 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-09 02:01:21 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-09 02:01:21 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-09 02:01:21 --> Helper loaded: text_helper
DEBUG - 2010-07-09 02:01:21 --> Final output sent to browser
DEBUG - 2010-07-09 02:01:21 --> Total execution time: 0.2225
DEBUG - 2010-07-09 02:05:56 --> Config Class Initialized
DEBUG - 2010-07-09 02:05:56 --> Hooks Class Initialized
DEBUG - 2010-07-09 02:05:56 --> URI Class Initialized
DEBUG - 2010-07-09 02:05:56 --> Router Class Initialized
DEBUG - 2010-07-09 02:05:56 --> Output Class Initialized
DEBUG - 2010-07-09 02:05:56 --> Input Class Initialized
DEBUG - 2010-07-09 02:05:56 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 02:05:56 --> Language Class Initialized
DEBUG - 2010-07-09 02:05:56 --> Loader Class Initialized
DEBUG - 2010-07-09 02:05:56 --> Helper loaded: context_helper
DEBUG - 2010-07-09 02:05:56 --> Helper loaded: kals_helper
DEBUG - 2010-07-09 02:05:56 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-09 02:05:56 --> Database Driver Class Initialized
DEBUG - 2010-07-09 02:05:56 --> Controller Class Initialized
DEBUG - 2010-07-09 02:05:56 --> Unit Testing Class Initialized
DEBUG - 2010-07-09 02:05:56 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-09 02:05:56 --> Session Class Initialized
DEBUG - 2010-07-09 02:05:56 --> Helper loaded: string_helper
DEBUG - 2010-07-09 02:05:56 --> Session routines successfully run
DEBUG - 2010-07-09 02:05:56 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-09 02:05:56 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-09 02:05:56 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-09 02:05:56 --> Helper loaded: text_helper
DEBUG - 2010-07-09 02:05:56 --> Final output sent to browser
DEBUG - 2010-07-09 02:05:56 --> Total execution time: 0.3112
DEBUG - 2010-07-09 02:06:49 --> Config Class Initialized
DEBUG - 2010-07-09 02:06:49 --> Hooks Class Initialized
DEBUG - 2010-07-09 02:06:49 --> URI Class Initialized
DEBUG - 2010-07-09 02:06:49 --> Router Class Initialized
DEBUG - 2010-07-09 02:06:49 --> Output Class Initialized
DEBUG - 2010-07-09 02:06:49 --> Input Class Initialized
DEBUG - 2010-07-09 02:06:49 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 02:06:49 --> Language Class Initialized
DEBUG - 2010-07-09 02:06:49 --> Loader Class Initialized
DEBUG - 2010-07-09 02:06:49 --> Helper loaded: context_helper
DEBUG - 2010-07-09 02:06:49 --> Helper loaded: kals_helper
DEBUG - 2010-07-09 02:06:49 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-09 02:06:49 --> Database Driver Class Initialized
DEBUG - 2010-07-09 02:06:49 --> Controller Class Initialized
DEBUG - 2010-07-09 02:06:49 --> Unit Testing Class Initialized
DEBUG - 2010-07-09 02:06:49 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-09 02:06:49 --> Session Class Initialized
DEBUG - 2010-07-09 02:06:49 --> Helper loaded: string_helper
DEBUG - 2010-07-09 02:06:49 --> Session routines successfully run
DEBUG - 2010-07-09 02:06:49 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-09 02:06:49 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-09 02:06:49 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-09 02:06:49 --> Helper loaded: text_helper
DEBUG - 2010-07-09 02:06:49 --> Final output sent to browser
DEBUG - 2010-07-09 02:06:49 --> Total execution time: 0.2615
DEBUG - 2010-07-09 02:07:18 --> Config Class Initialized
DEBUG - 2010-07-09 02:07:18 --> Hooks Class Initialized
DEBUG - 2010-07-09 02:07:18 --> URI Class Initialized
DEBUG - 2010-07-09 02:07:18 --> Router Class Initialized
DEBUG - 2010-07-09 02:07:18 --> Output Class Initialized
DEBUG - 2010-07-09 02:07:18 --> Input Class Initialized
DEBUG - 2010-07-09 02:07:18 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 02:07:18 --> Language Class Initialized
DEBUG - 2010-07-09 02:07:18 --> Loader Class Initialized
DEBUG - 2010-07-09 02:07:18 --> Helper loaded: context_helper
DEBUG - 2010-07-09 02:07:18 --> Helper loaded: kals_helper
DEBUG - 2010-07-09 02:07:18 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-09 02:07:18 --> Database Driver Class Initialized
DEBUG - 2010-07-09 02:07:18 --> Controller Class Initialized
DEBUG - 2010-07-09 02:07:18 --> Unit Testing Class Initialized
DEBUG - 2010-07-09 02:07:18 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-09 02:07:18 --> Session Class Initialized
DEBUG - 2010-07-09 02:07:18 --> Helper loaded: string_helper
DEBUG - 2010-07-09 02:07:18 --> Session routines successfully run
DEBUG - 2010-07-09 02:07:19 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-09 02:07:19 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-09 02:07:19 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-09 02:07:19 --> Helper loaded: text_helper
DEBUG - 2010-07-09 02:07:19 --> Final output sent to browser
DEBUG - 2010-07-09 02:07:19 --> Total execution time: 0.2334
DEBUG - 2010-07-09 02:07:46 --> Config Class Initialized
DEBUG - 2010-07-09 02:07:46 --> Hooks Class Initialized
DEBUG - 2010-07-09 02:07:46 --> URI Class Initialized
DEBUG - 2010-07-09 02:07:46 --> Router Class Initialized
DEBUG - 2010-07-09 02:07:46 --> Output Class Initialized
DEBUG - 2010-07-09 02:07:46 --> Input Class Initialized
DEBUG - 2010-07-09 02:07:46 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 02:07:46 --> Language Class Initialized
DEBUG - 2010-07-09 02:07:46 --> Loader Class Initialized
DEBUG - 2010-07-09 02:07:46 --> Helper loaded: context_helper
DEBUG - 2010-07-09 02:07:46 --> Helper loaded: kals_helper
DEBUG - 2010-07-09 02:07:46 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-09 02:07:46 --> Database Driver Class Initialized
DEBUG - 2010-07-09 02:07:46 --> Controller Class Initialized
DEBUG - 2010-07-09 02:07:46 --> Unit Testing Class Initialized
DEBUG - 2010-07-09 02:07:46 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-09 02:07:46 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-09 02:07:46 --> Severity: Notice  --> Undefined property: ut_annotation::$authorize_manager D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 36
DEBUG - 2010-07-09 02:09:43 --> Config Class Initialized
DEBUG - 2010-07-09 02:09:43 --> Hooks Class Initialized
DEBUG - 2010-07-09 02:09:43 --> URI Class Initialized
DEBUG - 2010-07-09 02:09:43 --> Router Class Initialized
DEBUG - 2010-07-09 02:09:43 --> Output Class Initialized
DEBUG - 2010-07-09 02:09:43 --> Input Class Initialized
DEBUG - 2010-07-09 02:09:43 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 02:09:43 --> Language Class Initialized
DEBUG - 2010-07-09 02:09:43 --> Loader Class Initialized
DEBUG - 2010-07-09 02:09:43 --> Helper loaded: context_helper
DEBUG - 2010-07-09 02:09:43 --> Helper loaded: kals_helper
DEBUG - 2010-07-09 02:09:43 --> Language file loaded: language/zh_tw/kals_lang.php
ERROR - 2010-07-09 02:09:43 --> Severity: Notice  --> Undefined property: ut_annotation::$db D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\KALS_object.php 33
DEBUG - 2010-07-09 02:09:43 --> Database Driver Class Initialized
DEBUG - 2010-07-09 02:09:43 --> Controller Class Initialized
DEBUG - 2010-07-09 02:09:43 --> Unit Testing Class Initialized
DEBUG - 2010-07-09 02:09:43 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-09 02:09:43 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-09 02:09:43 --> Severity: Notice  --> Undefined property: ut_annotation::$authorize_manager D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 37
DEBUG - 2010-07-09 02:10:17 --> Config Class Initialized
DEBUG - 2010-07-09 02:10:17 --> Hooks Class Initialized
DEBUG - 2010-07-09 02:10:17 --> URI Class Initialized
DEBUG - 2010-07-09 02:10:17 --> Router Class Initialized
DEBUG - 2010-07-09 02:10:17 --> Output Class Initialized
DEBUG - 2010-07-09 02:10:17 --> Input Class Initialized
DEBUG - 2010-07-09 02:10:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 02:10:17 --> Language Class Initialized
DEBUG - 2010-07-09 02:10:17 --> Loader Class Initialized
DEBUG - 2010-07-09 02:10:17 --> Helper loaded: context_helper
DEBUG - 2010-07-09 02:10:21 --> Config Class Initialized
DEBUG - 2010-07-09 02:10:21 --> Hooks Class Initialized
DEBUG - 2010-07-09 02:10:21 --> URI Class Initialized
DEBUG - 2010-07-09 02:10:21 --> Router Class Initialized
DEBUG - 2010-07-09 02:10:21 --> Output Class Initialized
DEBUG - 2010-07-09 02:10:21 --> Input Class Initialized
DEBUG - 2010-07-09 02:10:21 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 02:10:21 --> Language Class Initialized
DEBUG - 2010-07-09 02:10:21 --> Loader Class Initialized
DEBUG - 2010-07-09 02:10:21 --> Helper loaded: context_helper
DEBUG - 2010-07-09 02:10:21 --> Helper loaded: kals_helper
DEBUG - 2010-07-09 02:10:21 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-09 02:10:21 --> Database Driver Class Initialized
DEBUG - 2010-07-09 02:10:21 --> Controller Class Initialized
DEBUG - 2010-07-09 02:10:21 --> Unit Testing Class Initialized
DEBUG - 2010-07-09 02:10:21 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-09 02:10:21 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-09 02:10:21 --> Severity: Notice  --> Undefined property: ut_annotation::$authorize_manager D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 37
DEBUG - 2010-07-09 02:11:56 --> Config Class Initialized
DEBUG - 2010-07-09 02:11:56 --> Hooks Class Initialized
DEBUG - 2010-07-09 02:11:56 --> URI Class Initialized
DEBUG - 2010-07-09 02:11:56 --> Router Class Initialized
DEBUG - 2010-07-09 02:11:56 --> Output Class Initialized
DEBUG - 2010-07-09 02:11:56 --> Input Class Initialized
DEBUG - 2010-07-09 02:11:56 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 02:11:56 --> Language Class Initialized
DEBUG - 2010-07-09 02:11:56 --> Loader Class Initialized
DEBUG - 2010-07-09 02:11:56 --> Helper loaded: context_helper
DEBUG - 2010-07-09 02:11:56 --> Helper loaded: kals_helper
DEBUG - 2010-07-09 02:11:56 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-09 02:11:56 --> Database Driver Class Initialized
DEBUG - 2010-07-09 02:11:56 --> Controller Class Initialized
DEBUG - 2010-07-09 02:11:56 --> Unit Testing Class Initialized
DEBUG - 2010-07-09 02:11:56 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-09 02:11:56 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-09 02:11:56 --> Severity: Notice  --> Undefined property: ut_annotation::$authorize_manager D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 37
DEBUG - 2010-07-09 02:12:21 --> Config Class Initialized
DEBUG - 2010-07-09 02:12:21 --> Hooks Class Initialized
DEBUG - 2010-07-09 02:12:21 --> URI Class Initialized
DEBUG - 2010-07-09 02:12:21 --> Router Class Initialized
DEBUG - 2010-07-09 02:12:21 --> Output Class Initialized
DEBUG - 2010-07-09 02:12:21 --> Input Class Initialized
DEBUG - 2010-07-09 02:12:21 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 02:12:21 --> Language Class Initialized
DEBUG - 2010-07-09 02:12:21 --> Loader Class Initialized
DEBUG - 2010-07-09 02:12:21 --> Helper loaded: context_helper
DEBUG - 2010-07-09 02:12:21 --> Helper loaded: kals_helper
DEBUG - 2010-07-09 02:12:21 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-09 02:12:21 --> Database Driver Class Initialized
DEBUG - 2010-07-09 02:12:21 --> Controller Class Initialized
DEBUG - 2010-07-09 02:12:21 --> Unit Testing Class Initialized
DEBUG - 2010-07-09 02:12:21 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-09 02:12:21 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-09 02:12:21 --> Severity: Notice  --> Undefined property: ut_annotation::$authorize_manager D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 37
DEBUG - 2010-07-09 02:12:56 --> Config Class Initialized
DEBUG - 2010-07-09 02:12:56 --> Hooks Class Initialized
DEBUG - 2010-07-09 02:12:56 --> URI Class Initialized
DEBUG - 2010-07-09 02:12:56 --> Router Class Initialized
DEBUG - 2010-07-09 02:12:56 --> Output Class Initialized
DEBUG - 2010-07-09 02:12:56 --> Input Class Initialized
DEBUG - 2010-07-09 02:12:56 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 02:12:56 --> Language Class Initialized
DEBUG - 2010-07-09 02:12:56 --> Loader Class Initialized
DEBUG - 2010-07-09 02:12:56 --> Helper loaded: context_helper
DEBUG - 2010-07-09 02:12:56 --> Helper loaded: kals_helper
DEBUG - 2010-07-09 02:12:56 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-09 02:12:56 --> Database Driver Class Initialized
DEBUG - 2010-07-09 02:12:56 --> Controller Class Initialized
DEBUG - 2010-07-09 02:12:56 --> Unit Testing Class Initialized
DEBUG - 2010-07-09 02:12:56 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-09 02:12:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:12:56 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-09 02:12:56 --> Severity: Notice  --> Undefined property: ut_annotation::$authorize_manager D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 37
DEBUG - 2010-07-09 02:13:23 --> Config Class Initialized
DEBUG - 2010-07-09 02:13:23 --> Hooks Class Initialized
DEBUG - 2010-07-09 02:13:23 --> URI Class Initialized
DEBUG - 2010-07-09 02:13:23 --> Router Class Initialized
DEBUG - 2010-07-09 02:13:23 --> Output Class Initialized
DEBUG - 2010-07-09 02:13:23 --> Input Class Initialized
DEBUG - 2010-07-09 02:13:23 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 02:13:23 --> Language Class Initialized
DEBUG - 2010-07-09 02:13:23 --> Loader Class Initialized
DEBUG - 2010-07-09 02:13:23 --> Helper loaded: context_helper
DEBUG - 2010-07-09 02:13:24 --> Helper loaded: kals_helper
DEBUG - 2010-07-09 02:13:24 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-09 02:13:24 --> Database Driver Class Initialized
DEBUG - 2010-07-09 02:13:24 --> Controller Class Initialized
DEBUG - 2010-07-09 02:13:24 --> Unit Testing Class Initialized
DEBUG - 2010-07-09 02:13:24 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-09 02:13:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:13:24 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:13:24 --> Action_factory class already loaded. Second attempt ignored.
ERROR - 2010-07-09 02:13:24 --> Severity: Notice  --> Undefined property: ut_annotation::$authorize_manager D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 37
DEBUG - 2010-07-09 02:13:32 --> Config Class Initialized
DEBUG - 2010-07-09 02:13:32 --> Hooks Class Initialized
DEBUG - 2010-07-09 02:13:32 --> URI Class Initialized
DEBUG - 2010-07-09 02:13:32 --> Router Class Initialized
DEBUG - 2010-07-09 02:13:32 --> Output Class Initialized
DEBUG - 2010-07-09 02:13:32 --> Input Class Initialized
DEBUG - 2010-07-09 02:13:32 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 02:13:32 --> Language Class Initialized
DEBUG - 2010-07-09 02:13:32 --> Loader Class Initialized
DEBUG - 2010-07-09 02:13:32 --> Helper loaded: context_helper
DEBUG - 2010-07-09 02:13:32 --> Helper loaded: kals_helper
DEBUG - 2010-07-09 02:13:32 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-09 02:13:32 --> Database Driver Class Initialized
DEBUG - 2010-07-09 02:13:32 --> Controller Class Initialized
DEBUG - 2010-07-09 02:13:32 --> Unit Testing Class Initialized
DEBUG - 2010-07-09 02:13:32 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-09 02:13:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:13:32 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:13:32 --> Action_factory class already loaded. Second attempt ignored.
ERROR - 2010-07-09 02:13:32 --> Severity: Notice  --> Undefined property: ut_annotation::$authorize_manager D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 37
DEBUG - 2010-07-09 02:51:19 --> Config Class Initialized
DEBUG - 2010-07-09 02:51:19 --> Hooks Class Initialized
DEBUG - 2010-07-09 02:51:19 --> URI Class Initialized
DEBUG - 2010-07-09 02:51:19 --> Router Class Initialized
DEBUG - 2010-07-09 02:51:19 --> Output Class Initialized
DEBUG - 2010-07-09 02:51:19 --> Input Class Initialized
DEBUG - 2010-07-09 02:51:19 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 02:51:19 --> Language Class Initialized
DEBUG - 2010-07-09 02:51:19 --> Loader Class Initialized
DEBUG - 2010-07-09 02:51:19 --> Helper loaded: context_helper
DEBUG - 2010-07-09 02:51:19 --> Helper loaded: kals_helper
DEBUG - 2010-07-09 02:51:19 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-09 02:51:19 --> Database Driver Class Initialized
DEBUG - 2010-07-09 02:51:19 --> Controller Class Initialized
DEBUG - 2010-07-09 02:51:19 --> Unit Testing Class Initialized
DEBUG - 2010-07-09 02:51:19 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-09 02:51:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:51:19 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:51:19 --> Action_factory class already loaded. Second attempt ignored.
ERROR - 2010-07-09 02:51:19 --> Severity: Notice  --> Undefined property: ut_annotation::$authorize_manager D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 37
DEBUG - 2010-07-09 02:51:55 --> Config Class Initialized
DEBUG - 2010-07-09 02:51:55 --> Hooks Class Initialized
DEBUG - 2010-07-09 02:51:55 --> URI Class Initialized
DEBUG - 2010-07-09 02:51:55 --> Router Class Initialized
DEBUG - 2010-07-09 02:51:55 --> Output Class Initialized
DEBUG - 2010-07-09 02:51:55 --> Input Class Initialized
DEBUG - 2010-07-09 02:51:55 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 02:51:55 --> Language Class Initialized
DEBUG - 2010-07-09 02:51:55 --> Loader Class Initialized
DEBUG - 2010-07-09 02:51:55 --> Helper loaded: context_helper
DEBUG - 2010-07-09 02:51:55 --> Helper loaded: kals_helper
DEBUG - 2010-07-09 02:51:55 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-09 02:51:55 --> Database Driver Class Initialized
DEBUG - 2010-07-09 02:51:55 --> Controller Class Initialized
DEBUG - 2010-07-09 02:51:55 --> Unit Testing Class Initialized
DEBUG - 2010-07-09 02:51:55 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-09 02:51:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:51:55 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:51:55 --> Action_factory class already loaded. Second attempt ignored.
ERROR - 2010-07-09 02:51:55 --> Severity: Notice  --> Undefined property: ut_annotation::$authorize_manager D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 37
DEBUG - 2010-07-09 02:52:16 --> Config Class Initialized
DEBUG - 2010-07-09 02:52:16 --> Hooks Class Initialized
DEBUG - 2010-07-09 02:52:16 --> URI Class Initialized
DEBUG - 2010-07-09 02:52:16 --> Router Class Initialized
DEBUG - 2010-07-09 02:52:16 --> Output Class Initialized
DEBUG - 2010-07-09 02:52:16 --> Input Class Initialized
DEBUG - 2010-07-09 02:52:16 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 02:52:16 --> Language Class Initialized
DEBUG - 2010-07-09 02:52:16 --> Loader Class Initialized
DEBUG - 2010-07-09 02:52:16 --> Helper loaded: context_helper
DEBUG - 2010-07-09 02:52:16 --> Helper loaded: kals_helper
DEBUG - 2010-07-09 02:52:16 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-09 02:52:16 --> Database Driver Class Initialized
DEBUG - 2010-07-09 02:52:16 --> Controller Class Initialized
DEBUG - 2010-07-09 02:52:16 --> Unit Testing Class Initialized
DEBUG - 2010-07-09 02:52:16 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-09 02:52:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:52:17 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:52:17 --> Action_factory class already loaded. Second attempt ignored.
ERROR - 2010-07-09 02:52:17 --> Severity: Notice  --> Undefined property: ut_annotation::$authorize_manager D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 37
DEBUG - 2010-07-09 02:52:46 --> Config Class Initialized
DEBUG - 2010-07-09 02:52:46 --> Hooks Class Initialized
DEBUG - 2010-07-09 02:52:47 --> URI Class Initialized
DEBUG - 2010-07-09 02:52:47 --> Router Class Initialized
DEBUG - 2010-07-09 02:52:47 --> Output Class Initialized
DEBUG - 2010-07-09 02:52:47 --> Input Class Initialized
DEBUG - 2010-07-09 02:52:47 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 02:52:47 --> Language Class Initialized
DEBUG - 2010-07-09 02:52:47 --> Loader Class Initialized
DEBUG - 2010-07-09 02:52:47 --> Helper loaded: context_helper
DEBUG - 2010-07-09 02:52:47 --> Helper loaded: kals_helper
DEBUG - 2010-07-09 02:52:47 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-09 02:52:47 --> Database Driver Class Initialized
DEBUG - 2010-07-09 02:52:47 --> Controller Class Initialized
DEBUG - 2010-07-09 02:52:47 --> Unit Testing Class Initialized
DEBUG - 2010-07-09 02:52:47 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-09 02:52:47 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:52:47 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:52:47 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:52:47 --> Action_factory class already loaded. Second attempt ignored.
ERROR - 2010-07-09 02:52:47 --> Severity: Notice  --> Undefined property: ut_annotation::$authorize_manager D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 37
DEBUG - 2010-07-09 02:53:02 --> Config Class Initialized
DEBUG - 2010-07-09 02:53:02 --> Hooks Class Initialized
DEBUG - 2010-07-09 02:53:02 --> URI Class Initialized
DEBUG - 2010-07-09 02:53:02 --> Router Class Initialized
DEBUG - 2010-07-09 02:53:02 --> Output Class Initialized
DEBUG - 2010-07-09 02:53:02 --> Input Class Initialized
DEBUG - 2010-07-09 02:53:02 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 02:53:02 --> Language Class Initialized
DEBUG - 2010-07-09 02:53:02 --> Loader Class Initialized
DEBUG - 2010-07-09 02:53:02 --> Helper loaded: context_helper
DEBUG - 2010-07-09 02:53:02 --> Helper loaded: kals_helper
DEBUG - 2010-07-09 02:53:02 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-09 02:53:02 --> Database Driver Class Initialized
DEBUG - 2010-07-09 02:53:02 --> Controller Class Initialized
DEBUG - 2010-07-09 02:53:02 --> Unit Testing Class Initialized
DEBUG - 2010-07-09 02:53:02 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-09 02:53:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:53:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:53:02 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:53:02 --> Action_factory class already loaded. Second attempt ignored.
ERROR - 2010-07-09 02:53:03 --> Severity: Notice  --> Undefined property: ut_annotation::$authorize_manager D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 37
DEBUG - 2010-07-09 02:53:55 --> Config Class Initialized
DEBUG - 2010-07-09 02:53:55 --> Hooks Class Initialized
DEBUG - 2010-07-09 02:53:55 --> URI Class Initialized
DEBUG - 2010-07-09 02:53:55 --> Router Class Initialized
DEBUG - 2010-07-09 02:53:55 --> Output Class Initialized
DEBUG - 2010-07-09 02:53:55 --> Input Class Initialized
DEBUG - 2010-07-09 02:53:55 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 02:53:55 --> Language Class Initialized
DEBUG - 2010-07-09 02:53:55 --> Loader Class Initialized
DEBUG - 2010-07-09 02:53:55 --> Helper loaded: context_helper
DEBUG - 2010-07-09 02:53:55 --> Helper loaded: kals_helper
DEBUG - 2010-07-09 02:53:55 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-09 02:53:55 --> Database Driver Class Initialized
DEBUG - 2010-07-09 02:53:55 --> Controller Class Initialized
DEBUG - 2010-07-09 02:53:55 --> Unit Testing Class Initialized
DEBUG - 2010-07-09 02:53:55 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-09 02:53:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:53:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:53:55 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:53:55 --> Action_factory class already loaded. Second attempt ignored.
ERROR - 2010-07-09 02:53:55 --> Severity: Notice  --> Undefined property: ut_annotation::$authorize_manager D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 37
DEBUG - 2010-07-09 02:54:17 --> Config Class Initialized
DEBUG - 2010-07-09 02:54:17 --> Hooks Class Initialized
DEBUG - 2010-07-09 02:54:17 --> URI Class Initialized
DEBUG - 2010-07-09 02:54:17 --> Router Class Initialized
DEBUG - 2010-07-09 02:54:17 --> Output Class Initialized
DEBUG - 2010-07-09 02:54:17 --> Input Class Initialized
DEBUG - 2010-07-09 02:54:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 02:54:17 --> Language Class Initialized
DEBUG - 2010-07-09 02:54:17 --> Loader Class Initialized
DEBUG - 2010-07-09 02:54:17 --> Helper loaded: context_helper
DEBUG - 2010-07-09 02:54:17 --> Helper loaded: kals_helper
DEBUG - 2010-07-09 02:54:17 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-09 02:54:17 --> Database Driver Class Initialized
DEBUG - 2010-07-09 02:54:17 --> Controller Class Initialized
DEBUG - 2010-07-09 02:54:17 --> Unit Testing Class Initialized
DEBUG - 2010-07-09 02:54:17 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-09 02:54:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:54:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:54:17 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:54:17 --> Action_factory class already loaded. Second attempt ignored.
ERROR - 2010-07-09 02:54:17 --> Severity: Notice  --> Undefined property: ut_annotation::$authorize_manager D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 37
DEBUG - 2010-07-09 02:54:52 --> Config Class Initialized
DEBUG - 2010-07-09 02:54:52 --> Hooks Class Initialized
DEBUG - 2010-07-09 02:54:52 --> URI Class Initialized
DEBUG - 2010-07-09 02:54:52 --> Router Class Initialized
DEBUG - 2010-07-09 02:54:52 --> Output Class Initialized
DEBUG - 2010-07-09 02:54:52 --> Input Class Initialized
DEBUG - 2010-07-09 02:54:52 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 02:54:52 --> Language Class Initialized
DEBUG - 2010-07-09 02:54:52 --> Loader Class Initialized
DEBUG - 2010-07-09 02:54:52 --> Helper loaded: context_helper
DEBUG - 2010-07-09 02:54:52 --> Helper loaded: kals_helper
DEBUG - 2010-07-09 02:54:52 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-09 02:54:52 --> Database Driver Class Initialized
DEBUG - 2010-07-09 02:54:52 --> Controller Class Initialized
DEBUG - 2010-07-09 02:54:52 --> Unit Testing Class Initialized
DEBUG - 2010-07-09 02:54:52 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-09 02:54:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:54:53 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:54:53 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:54:53 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:54:53 --> Helper loaded: email_helper
DEBUG - 2010-07-09 02:54:53 --> User Agent Class Initialized
DEBUG - 2010-07-09 02:54:53 --> Session Class Initialized
DEBUG - 2010-07-09 02:54:53 --> Helper loaded: string_helper
DEBUG - 2010-07-09 02:54:53 --> Session routines successfully run
DEBUG - 2010-07-09 02:54:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:54:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:54:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:54:53 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-09 02:54:53 --> Severity: Notice  --> Undefined property: ut_annotation::$scope_anchor_text D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Annotation_scope.php 156
DEBUG - 2010-07-09 02:55:37 --> Config Class Initialized
DEBUG - 2010-07-09 02:55:37 --> Hooks Class Initialized
DEBUG - 2010-07-09 02:55:37 --> URI Class Initialized
DEBUG - 2010-07-09 02:55:37 --> Router Class Initialized
DEBUG - 2010-07-09 02:55:37 --> Output Class Initialized
DEBUG - 2010-07-09 02:55:37 --> Input Class Initialized
DEBUG - 2010-07-09 02:55:37 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 02:55:37 --> Language Class Initialized
DEBUG - 2010-07-09 02:55:37 --> Loader Class Initialized
DEBUG - 2010-07-09 02:55:37 --> Helper loaded: context_helper
DEBUG - 2010-07-09 02:55:37 --> Helper loaded: kals_helper
DEBUG - 2010-07-09 02:55:37 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-09 02:55:37 --> Database Driver Class Initialized
DEBUG - 2010-07-09 02:55:37 --> Controller Class Initialized
DEBUG - 2010-07-09 02:55:37 --> Unit Testing Class Initialized
DEBUG - 2010-07-09 02:55:37 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-09 02:55:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:55:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:55:37 --> Policy class already loaded. Second attempt ignored.
ERROR - 2010-07-09 02:55:37 --> Severity: Notice  --> Undefined property: ut_annotation::$authorize_manager D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 37
DEBUG - 2010-07-09 02:56:02 --> Config Class Initialized
DEBUG - 2010-07-09 02:56:02 --> Hooks Class Initialized
DEBUG - 2010-07-09 02:56:02 --> URI Class Initialized
DEBUG - 2010-07-09 02:56:02 --> Router Class Initialized
DEBUG - 2010-07-09 02:56:02 --> Output Class Initialized
DEBUG - 2010-07-09 02:56:02 --> Input Class Initialized
DEBUG - 2010-07-09 02:56:02 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 02:56:02 --> Language Class Initialized
DEBUG - 2010-07-09 02:56:02 --> Loader Class Initialized
DEBUG - 2010-07-09 02:56:02 --> Helper loaded: context_helper
DEBUG - 2010-07-09 02:56:02 --> Helper loaded: kals_helper
DEBUG - 2010-07-09 02:56:02 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-09 02:56:02 --> Database Driver Class Initialized
DEBUG - 2010-07-09 02:56:02 --> Controller Class Initialized
DEBUG - 2010-07-09 02:56:02 --> Unit Testing Class Initialized
DEBUG - 2010-07-09 02:56:02 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-09 02:56:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:56:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:56:02 --> Policy class already loaded. Second attempt ignored.
ERROR - 2010-07-09 02:56:02 --> Severity: Notice  --> Undefined property: ut_annotation::$authorize_manager D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 37
DEBUG - 2010-07-09 02:56:16 --> Config Class Initialized
DEBUG - 2010-07-09 02:56:16 --> Hooks Class Initialized
DEBUG - 2010-07-09 02:56:16 --> URI Class Initialized
DEBUG - 2010-07-09 02:56:16 --> Router Class Initialized
DEBUG - 2010-07-09 02:56:16 --> Output Class Initialized
DEBUG - 2010-07-09 02:56:16 --> Input Class Initialized
DEBUG - 2010-07-09 02:56:16 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 02:56:16 --> Language Class Initialized
DEBUG - 2010-07-09 02:56:16 --> Loader Class Initialized
DEBUG - 2010-07-09 02:56:16 --> Helper loaded: context_helper
DEBUG - 2010-07-09 02:56:16 --> Helper loaded: kals_helper
DEBUG - 2010-07-09 02:56:16 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-09 02:56:16 --> Database Driver Class Initialized
DEBUG - 2010-07-09 02:56:16 --> Controller Class Initialized
DEBUG - 2010-07-09 02:56:16 --> Unit Testing Class Initialized
DEBUG - 2010-07-09 02:56:16 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-09 02:56:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:56:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:56:16 --> Policy class already loaded. Second attempt ignored.
ERROR - 2010-07-09 02:56:16 --> Severity: Notice  --> Undefined property: ut_annotation::$authorize_manager D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 37
DEBUG - 2010-07-09 02:56:24 --> Config Class Initialized
DEBUG - 2010-07-09 02:56:24 --> Hooks Class Initialized
DEBUG - 2010-07-09 02:56:24 --> URI Class Initialized
DEBUG - 2010-07-09 02:56:24 --> Router Class Initialized
DEBUG - 2010-07-09 02:56:24 --> Output Class Initialized
DEBUG - 2010-07-09 02:56:24 --> Input Class Initialized
DEBUG - 2010-07-09 02:56:24 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 02:56:24 --> Language Class Initialized
DEBUG - 2010-07-09 02:56:24 --> Loader Class Initialized
DEBUG - 2010-07-09 02:56:24 --> Helper loaded: context_helper
DEBUG - 2010-07-09 02:56:24 --> Helper loaded: kals_helper
DEBUG - 2010-07-09 02:56:24 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-09 02:56:24 --> Database Driver Class Initialized
DEBUG - 2010-07-09 02:56:24 --> Controller Class Initialized
DEBUG - 2010-07-09 02:56:24 --> Unit Testing Class Initialized
DEBUG - 2010-07-09 02:56:24 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-09 02:56:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:56:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:56:24 --> Policy class already loaded. Second attempt ignored.
ERROR - 2010-07-09 02:56:24 --> Severity: Notice  --> Undefined property: ut_annotation::$authorize_manager D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 37
DEBUG - 2010-07-09 02:56:31 --> Config Class Initialized
DEBUG - 2010-07-09 02:56:31 --> Hooks Class Initialized
DEBUG - 2010-07-09 02:56:31 --> URI Class Initialized
DEBUG - 2010-07-09 02:56:31 --> Router Class Initialized
DEBUG - 2010-07-09 02:56:31 --> Output Class Initialized
DEBUG - 2010-07-09 02:56:31 --> Input Class Initialized
DEBUG - 2010-07-09 02:56:31 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 02:56:31 --> Language Class Initialized
DEBUG - 2010-07-09 02:56:31 --> Loader Class Initialized
DEBUG - 2010-07-09 02:56:31 --> Helper loaded: context_helper
DEBUG - 2010-07-09 02:56:31 --> Helper loaded: kals_helper
DEBUG - 2010-07-09 02:56:31 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-09 02:56:31 --> Database Driver Class Initialized
DEBUG - 2010-07-09 02:56:31 --> Controller Class Initialized
DEBUG - 2010-07-09 02:56:31 --> Unit Testing Class Initialized
DEBUG - 2010-07-09 02:56:31 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-09 02:56:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:56:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:56:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:56:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:56:32 --> Helper loaded: email_helper
DEBUG - 2010-07-09 02:56:32 --> User Agent Class Initialized
DEBUG - 2010-07-09 02:56:32 --> Session Class Initialized
DEBUG - 2010-07-09 02:56:32 --> Helper loaded: string_helper
DEBUG - 2010-07-09 02:56:32 --> Session routines successfully run
DEBUG - 2010-07-09 02:56:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:56:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:56:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:56:32 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-09 02:56:32 --> Severity: Notice  --> Undefined property: ut_annotation::$scope_anchor_text D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Annotation_scope.php 156
DEBUG - 2010-07-09 02:56:59 --> Config Class Initialized
DEBUG - 2010-07-09 02:56:59 --> Hooks Class Initialized
DEBUG - 2010-07-09 02:56:59 --> URI Class Initialized
DEBUG - 2010-07-09 02:56:59 --> Router Class Initialized
DEBUG - 2010-07-09 02:56:59 --> Output Class Initialized
DEBUG - 2010-07-09 02:56:59 --> Input Class Initialized
DEBUG - 2010-07-09 02:56:59 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 02:56:59 --> Language Class Initialized
DEBUG - 2010-07-09 02:56:59 --> Loader Class Initialized
DEBUG - 2010-07-09 02:56:59 --> Helper loaded: context_helper
DEBUG - 2010-07-09 02:56:59 --> Helper loaded: kals_helper
DEBUG - 2010-07-09 02:56:59 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-09 02:56:59 --> Database Driver Class Initialized
DEBUG - 2010-07-09 02:56:59 --> Controller Class Initialized
DEBUG - 2010-07-09 02:56:59 --> Unit Testing Class Initialized
DEBUG - 2010-07-09 02:56:59 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-09 02:57:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:01 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:03 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:05 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:07 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:08 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:08 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:08 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:08 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:08 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:08 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:08 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:08 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:08 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:08 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:08 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:08 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:08 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:08 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:08 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:08 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:08 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:09 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:09 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:09 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:09 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:09 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:09 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:09 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:09 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:09 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:09 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:09 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:09 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:09 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:09 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:09 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:09 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:10 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:10 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:10 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:10 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:10 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:10 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:10 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:10 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:10 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:10 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:10 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:10 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:10 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:11 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:11 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:11 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:11 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:11 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:11 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:11 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:11 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:11 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:11 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:11 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:11 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:11 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:11 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:12 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:12 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:12 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:12 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:12 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:12 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:12 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:12 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:12 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:12 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:12 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:12 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:12 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:13 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:13 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:13 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:13 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:13 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:13 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:13 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:13 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:13 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:13 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:13 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:13 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:13 --> Policy class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:57:13 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:58:17 --> Config Class Initialized
DEBUG - 2010-07-09 02:58:17 --> Hooks Class Initialized
DEBUG - 2010-07-09 02:58:17 --> URI Class Initialized
DEBUG - 2010-07-09 02:58:17 --> Router Class Initialized
DEBUG - 2010-07-09 02:58:17 --> Output Class Initialized
DEBUG - 2010-07-09 02:58:17 --> Input Class Initialized
DEBUG - 2010-07-09 02:58:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 02:58:17 --> Language Class Initialized
DEBUG - 2010-07-09 02:58:17 --> Loader Class Initialized
DEBUG - 2010-07-09 02:58:17 --> Helper loaded: context_helper
DEBUG - 2010-07-09 02:58:17 --> Helper loaded: kals_helper
DEBUG - 2010-07-09 02:58:17 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-09 02:58:17 --> Database Driver Class Initialized
DEBUG - 2010-07-09 02:58:17 --> Controller Class Initialized
DEBUG - 2010-07-09 02:58:17 --> Unit Testing Class Initialized
DEBUG - 2010-07-09 02:58:17 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-09 02:58:18 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-09 02:58:18 --> Severity: Notice  --> Undefined property: ut_annotation::$authorize_manager D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 37
DEBUG - 2010-07-09 02:59:05 --> Config Class Initialized
DEBUG - 2010-07-09 02:59:05 --> Hooks Class Initialized
DEBUG - 2010-07-09 02:59:05 --> URI Class Initialized
DEBUG - 2010-07-09 02:59:05 --> Router Class Initialized
DEBUG - 2010-07-09 02:59:05 --> Output Class Initialized
DEBUG - 2010-07-09 02:59:05 --> Input Class Initialized
DEBUG - 2010-07-09 02:59:05 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 02:59:05 --> Language Class Initialized
DEBUG - 2010-07-09 02:59:05 --> Loader Class Initialized
DEBUG - 2010-07-09 02:59:05 --> Helper loaded: context_helper
DEBUG - 2010-07-09 02:59:10 --> Config Class Initialized
DEBUG - 2010-07-09 02:59:10 --> Hooks Class Initialized
DEBUG - 2010-07-09 02:59:10 --> URI Class Initialized
DEBUG - 2010-07-09 02:59:10 --> Router Class Initialized
DEBUG - 2010-07-09 02:59:10 --> Output Class Initialized
DEBUG - 2010-07-09 02:59:10 --> Input Class Initialized
DEBUG - 2010-07-09 02:59:10 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 02:59:10 --> Language Class Initialized
DEBUG - 2010-07-09 02:59:10 --> Loader Class Initialized
DEBUG - 2010-07-09 02:59:10 --> Helper loaded: context_helper
DEBUG - 2010-07-09 02:59:18 --> Config Class Initialized
DEBUG - 2010-07-09 02:59:18 --> Hooks Class Initialized
DEBUG - 2010-07-09 02:59:18 --> URI Class Initialized
DEBUG - 2010-07-09 02:59:18 --> Router Class Initialized
DEBUG - 2010-07-09 02:59:18 --> Output Class Initialized
DEBUG - 2010-07-09 02:59:18 --> Input Class Initialized
DEBUG - 2010-07-09 02:59:18 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 02:59:18 --> Language Class Initialized
DEBUG - 2010-07-09 02:59:18 --> Loader Class Initialized
DEBUG - 2010-07-09 02:59:18 --> Helper loaded: context_helper
DEBUG - 2010-07-09 02:59:18 --> Helper loaded: kals_helper
DEBUG - 2010-07-09 02:59:18 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-09 02:59:18 --> Database Driver Class Initialized
DEBUG - 2010-07-09 02:59:18 --> Controller Class Initialized
DEBUG - 2010-07-09 02:59:18 --> Unit Testing Class Initialized
DEBUG - 2010-07-09 02:59:18 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-09 02:59:18 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-09 02:59:18 --> Severity: Notice  --> Undefined property: ut_annotation::$authorize_manager D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 37
DEBUG - 2010-07-09 02:59:41 --> Config Class Initialized
DEBUG - 2010-07-09 02:59:41 --> Hooks Class Initialized
DEBUG - 2010-07-09 02:59:41 --> URI Class Initialized
DEBUG - 2010-07-09 02:59:41 --> Router Class Initialized
DEBUG - 2010-07-09 02:59:41 --> Output Class Initialized
DEBUG - 2010-07-09 02:59:41 --> Input Class Initialized
DEBUG - 2010-07-09 02:59:41 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 02:59:41 --> Language Class Initialized
DEBUG - 2010-07-09 02:59:41 --> Loader Class Initialized
DEBUG - 2010-07-09 02:59:41 --> Helper loaded: context_helper
DEBUG - 2010-07-09 02:59:41 --> Helper loaded: kals_helper
DEBUG - 2010-07-09 02:59:41 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-09 02:59:41 --> Database Driver Class Initialized
DEBUG - 2010-07-09 02:59:42 --> Controller Class Initialized
DEBUG - 2010-07-09 02:59:42 --> Unit Testing Class Initialized
DEBUG - 2010-07-09 02:59:42 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-09 02:59:42 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:59:42 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:59:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:59:42 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:59:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:59:42 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:59:42 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:59:42 --> Helper loaded: email_helper
DEBUG - 2010-07-09 02:59:42 --> User Agent Class Initialized
DEBUG - 2010-07-09 02:59:42 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:59:42 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:59:42 --> Session Class Initialized
DEBUG - 2010-07-09 02:59:42 --> Helper loaded: string_helper
DEBUG - 2010-07-09 02:59:42 --> Session routines successfully run
DEBUG - 2010-07-09 02:59:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:59:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:59:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 02:59:42 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-09 02:59:42 --> Severity: Notice  --> Undefined property: ut_annotation::$scope_anchor_text D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Annotation_scope.php 156
DEBUG - 2010-07-09 03:00:55 --> Config Class Initialized
DEBUG - 2010-07-09 03:00:55 --> Hooks Class Initialized
DEBUG - 2010-07-09 03:00:55 --> URI Class Initialized
DEBUG - 2010-07-09 03:00:55 --> Router Class Initialized
DEBUG - 2010-07-09 03:00:55 --> Output Class Initialized
DEBUG - 2010-07-09 03:00:55 --> Input Class Initialized
DEBUG - 2010-07-09 03:00:55 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 03:00:55 --> Language Class Initialized
DEBUG - 2010-07-09 03:00:55 --> Loader Class Initialized
DEBUG - 2010-07-09 03:00:55 --> Helper loaded: context_helper
DEBUG - 2010-07-09 03:00:55 --> Helper loaded: kals_helper
DEBUG - 2010-07-09 03:00:55 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-09 03:00:55 --> Database Driver Class Initialized
DEBUG - 2010-07-09 03:00:55 --> Controller Class Initialized
DEBUG - 2010-07-09 03:00:55 --> Unit Testing Class Initialized
DEBUG - 2010-07-09 03:00:55 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-09 03:00:55 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:55 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:56 --> Helper loaded: email_helper
DEBUG - 2010-07-09 03:00:56 --> User Agent Class Initialized
DEBUG - 2010-07-09 03:00:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:56 --> Session Class Initialized
DEBUG - 2010-07-09 03:00:56 --> Helper loaded: string_helper
ERROR - 2010-07-09 03:00:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:383) D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Session.php 662
DEBUG - 2010-07-09 03:00:56 --> Session routines successfully run
DEBUG - 2010-07-09 03:00:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:56 --> Config file loaded: config/kals.php
DEBUG - 2010-07-09 03:00:56 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:56 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:56 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:56 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:56 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:56 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:57 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:57 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-09 03:00:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:57 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:57 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:57 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:57 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:57 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:57 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:57 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:57 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:57 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:57 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:58 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:58 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:58 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:58 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:58 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:58 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:58 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:58 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:58 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:58 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:58 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:58 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:00:58 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-09 03:00:58 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-09 03:00:58 --> Helper loaded: text_helper
DEBUG - 2010-07-09 03:00:58 --> Final output sent to browser
DEBUG - 2010-07-09 03:00:58 --> Total execution time: 3.6246
DEBUG - 2010-07-09 03:01:15 --> Config Class Initialized
DEBUG - 2010-07-09 03:01:15 --> Hooks Class Initialized
DEBUG - 2010-07-09 03:01:15 --> URI Class Initialized
DEBUG - 2010-07-09 03:01:15 --> Router Class Initialized
DEBUG - 2010-07-09 03:01:15 --> Output Class Initialized
DEBUG - 2010-07-09 03:01:15 --> Input Class Initialized
DEBUG - 2010-07-09 03:01:15 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-09 03:01:15 --> Language Class Initialized
DEBUG - 2010-07-09 03:01:15 --> Loader Class Initialized
DEBUG - 2010-07-09 03:01:15 --> Helper loaded: context_helper
DEBUG - 2010-07-09 03:01:15 --> Helper loaded: kals_helper
DEBUG - 2010-07-09 03:01:15 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-09 03:01:15 --> Database Driver Class Initialized
DEBUG - 2010-07-09 03:01:15 --> Controller Class Initialized
DEBUG - 2010-07-09 03:01:15 --> Unit Testing Class Initialized
DEBUG - 2010-07-09 03:01:15 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-09 03:01:16 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:16 --> KALS_actor class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:16 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:16 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:16 --> Helper loaded: email_helper
DEBUG - 2010-07-09 03:01:16 --> User Agent Class Initialized
DEBUG - 2010-07-09 03:01:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:16 --> Session Class Initialized
DEBUG - 2010-07-09 03:01:16 --> Helper loaded: string_helper
DEBUG - 2010-07-09 03:01:16 --> Session routines successfully run
DEBUG - 2010-07-09 03:01:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:16 --> Config file loaded: config/kals.php
DEBUG - 2010-07-09 03:01:16 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:16 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:16 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:16 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:16 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:16 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:17 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:17 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:17 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-09 03:01:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:17 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:17 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:17 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:17 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:17 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:17 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:17 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:17 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:18 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:18 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:18 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:18 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:18 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:18 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:18 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:18 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:18 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:18 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:18 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:18 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:18 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:18 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:18 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:18 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-09 03:01:18 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-09 03:01:19 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-09 03:01:19 --> Helper loaded: text_helper
DEBUG - 2010-07-09 03:01:19 --> Final output sent to browser
DEBUG - 2010-07-09 03:01:19 --> Total execution time: 3.6939
ERROR - 2010-07-09 03:19:44 --> Severity: Notice  --> Undefined property: ut_annotation::$authorize_manager D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 36
ERROR - 2010-07-09 03:29:25 --> 管理Domain錯誤
ERROR - 2010-07-09 03:32:16 --> Severity: 4096  --> Method Domain::__toString() must return a string value D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 328
ERROR - 2010-07-09 03:32:17 --> Severity: 4096  --> Method Domain::__toString() must return a string value D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 244
ERROR - 2010-07-09 03:32:17 --> Severity: 4096  --> Method Domain::__toString() must return a string value D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 319
ERROR - 2010-07-09 03:32:17 --> Severity: 4096  --> Method Domain::__toString() must return a string value D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 244
ERROR - 2010-07-09 03:32:17 --> Severity: 4096  --> Method Domain::__toString() must return a string value D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 319
ERROR - 2010-07-09 13:51:07 --> Severity: Warning  --> include_once(Annotation_collection) [<a href='function.include-once'>function.include-once</a>]: failed to open stream: No such file or directory D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Annotation_respond_collection.php 2
ERROR - 2010-07-09 13:51:07 --> Severity: Warning  --> include_once() [<a href='function.include'>function.include</a>]: Failed opening 'Annotation_collection' for inclusion (include_path='.;D:\xampp\php\pear\') D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Annotation_respond_collection.php 2
ERROR - 2010-07-09 13:51:30 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;ON&quot;
LINE 2: JOIN &quot; ON &quot;.&quot; = &quot;.&quot;
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-09 13:51:30 --> Query error: ERROR:  syntax error at or near "ON"
LINE 2: JOIN " ON "." = "."
               ^
ERROR - 2010-07-09 13:55:12 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;ON&quot;
LINE 2: JOIN &quot; ON &quot;.&quot; = &quot;.&quot;
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-09 13:55:12 --> Query error: ERROR:  syntax error at or near "ON"
LINE 2: JOIN " ON "." = "."
               ^
ERROR - 2010-07-09 13:55:53 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;ON&quot;
LINE 2: JOIN &quot; ON &quot;.&quot; = &quot;.&quot;
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-09 13:55:53 --> Query error: ERROR:  syntax error at or near "ON"
LINE 2: JOIN " ON "." = "."
               ^
ERROR - 2010-07-09 13:56:38 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;ON&quot;
LINE 2: JOIN &quot; ON &quot;.&quot; = &quot;.&quot;
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-09 13:56:38 --> Query error: ERROR:  syntax error at or near "ON"
LINE 2: JOIN " ON "." = "."
               ^
ERROR - 2010-07-09 13:56:39 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:383) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-09 13:57:16 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;scope_id&quot; does not exist
LINE 1: SELECT DISTINCT &quot;scope_id&quot;
                        ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-09 13:57:16 --> Query error: ERROR:  column "scope_id" does not exist
LINE 1: SELECT DISTINCT "scope_id"
                        ^
ERROR - 2010-07-09 14:00:08 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;ON&quot;
LINE 2: JOIN &quot; ON &quot;.&quot; = &quot;.&quot;
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-09 14:00:08 --> Query error: ERROR:  syntax error at or near "ON"
LINE 2: JOIN " ON "." = "."
               ^
ERROR - 2010-07-09 14:00:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:383) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-09 14:03:41 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;ON&quot;
LINE 2: JOIN &quot; ON &quot;.&quot; = &quot;.&quot;
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-09 14:03:41 --> Query error: ERROR:  syntax error at or near "ON"
LINE 2: JOIN " ON "." = "."
               ^
ERROR - 2010-07-09 14:03:42 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:383) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-09 14:37:58 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;ON&quot;
LINE 2: JOIN &quot; ON &quot;.&quot; = &quot;.&quot;
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-09 14:37:58 --> Query error: ERROR:  syntax error at or near "ON"
LINE 2: JOIN " ON "." = "."
               ^
ERROR - 2010-07-09 14:37:58 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:383) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-09 14:38:53 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;ON&quot;
LINE 2: JOIN &quot; ON &quot;.&quot; = &quot;.&quot;
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-09 14:38:53 --> Query error: ERROR:  syntax error at or near "ON"
LINE 2: JOIN " ON "." = "."
               ^
ERROR - 2010-07-09 14:38:53 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:383) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-09 14:39:57 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;ON&quot;
LINE 2: JOIN &quot; ON &quot;.&quot; = &quot;.&quot;
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-09 14:39:57 --> Query error: ERROR:  syntax error at or near "ON"
LINE 2: JOIN " ON "." = "."
               ^
ERROR - 2010-07-09 14:39:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:383) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-09 14:40:27 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;ON&quot;
LINE 2: JOIN &quot; ON &quot;.&quot; = &quot;.&quot;
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-09 14:40:27 --> Query error: ERROR:  syntax error at or near "ON"
LINE 2: JOIN " ON "." = "."
               ^
ERROR - 2010-07-09 14:40:27 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:383) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-09 14:41:36 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;ON&quot;
LINE 2: JOIN &quot; ON &quot;.&quot; = &quot;.&quot;
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-09 14:41:36 --> Query error: ERROR:  syntax error at or near "ON"
LINE 2: JOIN " ON "." = "."
               ^
ERROR - 2010-07-09 14:41:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:383) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-09 14:42:08 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;ON&quot;
LINE 2: JOIN &quot; ON &quot;.&quot; = &quot;.&quot;
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-09 14:42:08 --> Query error: ERROR:  syntax error at or near "ON"
LINE 2: JOIN " ON "." = "."
               ^
ERROR - 2010-07-09 14:42:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:383) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-09 14:42:31 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;ON&quot;
LINE 2: JOIN &quot; ON &quot;.&quot; = &quot;.&quot;
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-09 14:42:31 --> Query error: ERROR:  syntax error at or near "ON"
LINE 2: JOIN " ON "." = "."
               ^
ERROR - 2010-07-09 14:42:31 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:383) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-09 14:44:22 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;$&quot;
LINE 5: AND &quot;annotation_id&quot; = Annotation::$id=339
                                          ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-09 14:44:22 --> Query error: ERROR:  syntax error at or near "$"
LINE 5: AND "annotation_id" = Annotation::$id=339
                                          ^
ERROR - 2010-07-09 14:44:22 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:383) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-09 14:45:37 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;$&quot;
LINE 5: AND &quot;annotation_id&quot; = Annotation::$id=342
                                          ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-09 14:45:38 --> Query error: ERROR:  syntax error at or near "$"
LINE 5: AND "annotation_id" = Annotation::$id=342
                                          ^
ERROR - 2010-07-09 14:46:04 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column reference &quot;annotation_id&quot; is ambiguous
LINE 5: AND &quot;annotation_id&quot; = 345
            ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-09 14:46:04 --> Query error: ERROR:  column reference "annotation_id" is ambiguous
LINE 5: AND "annotation_id" = 345
            ^
ERROR - 2010-07-09 15:01:29 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/d1fe173d08e959397adf34b1d77e88d7) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-09 15:52:00 --> Severity: Notice  --> Undefined index:  topic_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 306
ERROR - 2010-07-09 15:54:14 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/d67d8ab4f4c10bf22aa353e27879133c) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-09 16:09:06 --> Unable to load the requested class: annotation_topic_respond_collection
ERROR - 2010-07-09 16:31:48 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:48 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:48 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:48 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:48 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:48 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:48 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:48 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:48 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:48 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:48 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:49 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:49 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:49 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:49 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:49 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:49 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:49 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:49 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:49 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:49 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:49 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:49 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:49 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:49 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:49 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:49 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:49 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:49 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:49 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:49 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:49 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:50 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:50 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:50 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:50 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:50 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:50 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:50 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:50 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:50 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:50 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:50 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:50 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:50 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:50 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:50 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:50 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:50 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:50 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:50 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:51 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:51 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:51 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:51 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:51 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:51 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:51 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:51 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:51 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:51 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:51 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:51 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:51 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:51 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:51 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:51 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:51 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:51 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:51 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 16:31:51 --> Severity: Notice  --> Undefined variable: this_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 324
ERROR - 2010-07-09 17:44:41 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\DB_active_rec.php 86
ERROR - 2010-07-09 17:44:41 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  unterminated quoted identifier at or near &quot;&quot; = 478&quot;
LINE 3: WHERE &quot; = 478
              ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-09 17:44:41 --> Query error: ERROR:  unterminated quoted identifier at or near "" = 478"
LINE 3: WHERE " = 478
              ^
ERROR - 2010-07-09 17:44:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
