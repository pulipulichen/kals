<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-07-21 01:31:18 --> Severity: Notice  --> Undefined variable: js_files D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\views\qunit\qunit_template.php 31
ERROR - 2010-07-21 01:31:18 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\views\qunit\qunit_template.php 31
ERROR - 2010-07-21 01:32:58 --> Severity: Notice  --> Undefined variable: js_files D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\views\qunit\qunit_template.php 31
ERROR - 2010-07-21 01:32:58 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\views\qunit\qunit_template.php 31
ERROR - 2010-07-21 01:33:00 --> 404 Page Not Found --> libraries
ERROR - 2010-07-21 01:33:35 --> 404 Page Not Found --> libraries
ERROR - 2010-07-21 01:33:49 --> 404 Page Not Found --> libraries
ERROR - 2010-07-21 01:34:15 --> 404 Page Not Found --> libraries
ERROR - 2010-07-21 03:33:41 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/b6d767d2f8ed5d21a44b0e5886680cb9) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-21 03:55:58 --> 404 Page Not Found --> KALS_units
ERROR - 2010-07-21 03:55:58 --> 404 Page Not Found --> KALS_units
ERROR - 2010-07-21 06:52:22 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 06:55:34 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 06:58:40 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 06:58:46 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 06:58:55 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 06:59:34 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 06:59:34 --> Severity: Notice  --> Undefined variable: callback D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\errors\error_404.php 46
ERROR - 2010-07-21 06:59:55 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:00:18 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:00:18 --> Severity: Notice  --> Undefined variable: callback D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\errors\error_404.php 48
ERROR - 2010-07-21 07:00:57 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:01:07 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:01:07 --> Severity: Notice  --> Undefined variable: callback D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\errors\error_404.php 48
ERROR - 2010-07-21 07:01:49 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:01:58 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:02:34 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:02:41 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:02:55 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:03:04 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:03:04 --> Severity: Notice  --> Undefined variable: callback D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\errors\error_404.php 49
ERROR - 2010-07-21 07:03:17 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:03:23 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:03:46 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:03:59 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:04:16 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:04:27 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:05:05 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:05:14 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:05:32 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:05:40 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:05:51 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:06:14 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:06:41 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:06:49 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:06:57 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:07:06 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:07:49 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:07:50 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:07:52 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:07:53 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:07:53 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:08:13 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:13:39 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:14:25 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:14:32 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:14:36 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:17:12 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:17:16 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/f7177163c833dff4b38fc8d2872f1ec6) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-21 07:17:18 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:17:36 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:17:59 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:18:01 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:20:06 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:20:17 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:20:56 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:21:06 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:21:13 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:21:40 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:22:33 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:22:44 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 07:23:03 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 08:16:02 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 08:16:06 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 08:16:14 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 08:18:25 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 08:18:41 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 08:19:07 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 08:19:16 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 08:19:26 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 08:19:43 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 08:19:56 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 08:20:09 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 08:20:57 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 08:26:51 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 08:37:28 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 08:37:30 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 08:37:32 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 08:46:55 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 08:47:06 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 08:47:12 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 08:52:14 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 08:52:47 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 08:52:52 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 08:54:01 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 08:54:25 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 08:55:32 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 08:56:57 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 08:57:33 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 09:00:14 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 09:01:37 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 09:05:29 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 09:06:18 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 09:06:53 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 09:07:13 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 09:08:26 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 09:08:38 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 09:08:52 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 09:09:15 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 09:10:37 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 09:10:48 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 09:12:27 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 09:12:37 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 15:52:10 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-21 15:52:39 --> 404 Page Not Found --> qunit_feeds
