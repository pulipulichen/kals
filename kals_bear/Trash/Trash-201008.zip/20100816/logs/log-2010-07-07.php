<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2010-07-07 03:27:50 --> Config Class Initialized
DEBUG - 2010-07-07 03:27:50 --> Hooks Class Initialized
DEBUG - 2010-07-07 03:27:50 --> URI Class Initialized
DEBUG - 2010-07-07 03:27:50 --> Router Class Initialized
DEBUG - 2010-07-07 03:27:50 --> Output Class Initialized
DEBUG - 2010-07-07 03:27:50 --> Input Class Initialized
DEBUG - 2010-07-07 03:27:50 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 03:27:50 --> Language Class Initialized
DEBUG - 2010-07-07 03:27:50 --> Loader Class Initialized
DEBUG - 2010-07-07 03:27:50 --> Helper loaded: context_helper
DEBUG - 2010-07-07 03:27:50 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 03:27:50 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 03:27:50 --> Database Driver Class Initialized
DEBUG - 2010-07-07 03:27:50 --> Controller Class Initialized
DEBUG - 2010-07-07 03:27:50 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 03:27:50 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 03:27:50 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 03:27:50 --> Session Class Initialized
DEBUG - 2010-07-07 03:27:50 --> Helper loaded: string_helper
DEBUG - 2010-07-07 03:27:50 --> A session cookie was not found.
DEBUG - 2010-07-07 03:27:50 --> Session routines successfully run
DEBUG - 2010-07-07 03:27:50 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:27:50 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:27:50 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:27:50 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 03:27:50 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:27:50 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:27:50 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:27:50 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:27:50 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:27:50 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:27:50 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 03:27:50 --> Final output sent to browser
DEBUG - 2010-07-07 03:27:50 --> Total execution time: 0.5906
DEBUG - 2010-07-07 03:29:23 --> Config Class Initialized
DEBUG - 2010-07-07 03:29:23 --> Hooks Class Initialized
DEBUG - 2010-07-07 03:29:23 --> URI Class Initialized
DEBUG - 2010-07-07 03:29:23 --> Router Class Initialized
DEBUG - 2010-07-07 03:29:23 --> Output Class Initialized
DEBUG - 2010-07-07 03:29:23 --> Input Class Initialized
DEBUG - 2010-07-07 03:29:23 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 03:29:23 --> Language Class Initialized
DEBUG - 2010-07-07 03:29:23 --> Loader Class Initialized
DEBUG - 2010-07-07 03:29:23 --> Helper loaded: context_helper
DEBUG - 2010-07-07 03:29:23 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 03:29:23 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 03:29:23 --> Database Driver Class Initialized
DEBUG - 2010-07-07 03:29:23 --> Controller Class Initialized
DEBUG - 2010-07-07 03:29:23 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 03:29:23 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 03:29:23 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 03:29:23 --> Session Class Initialized
DEBUG - 2010-07-07 03:29:23 --> Helper loaded: string_helper
DEBUG - 2010-07-07 03:29:23 --> Session routines successfully run
DEBUG - 2010-07-07 03:29:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:29:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:29:23 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:29:23 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 03:29:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:29:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:29:23 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:29:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:29:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:29:23 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:29:23 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 03:29:23 --> Final output sent to browser
DEBUG - 2010-07-07 03:29:23 --> Total execution time: 0.2917
DEBUG - 2010-07-07 03:32:28 --> Config Class Initialized
DEBUG - 2010-07-07 03:32:28 --> Hooks Class Initialized
DEBUG - 2010-07-07 03:32:28 --> URI Class Initialized
DEBUG - 2010-07-07 03:32:28 --> Router Class Initialized
DEBUG - 2010-07-07 03:32:28 --> Output Class Initialized
DEBUG - 2010-07-07 03:32:28 --> Input Class Initialized
DEBUG - 2010-07-07 03:32:28 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 03:32:28 --> Language Class Initialized
DEBUG - 2010-07-07 03:32:28 --> Loader Class Initialized
DEBUG - 2010-07-07 03:32:28 --> Helper loaded: context_helper
DEBUG - 2010-07-07 03:32:28 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 03:32:28 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 03:32:28 --> Database Driver Class Initialized
DEBUG - 2010-07-07 03:32:28 --> Controller Class Initialized
DEBUG - 2010-07-07 03:32:28 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 03:32:28 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 03:32:28 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 03:32:28 --> Session Class Initialized
DEBUG - 2010-07-07 03:32:28 --> Helper loaded: string_helper
DEBUG - 2010-07-07 03:32:28 --> Session routines successfully run
DEBUG - 2010-07-07 03:32:28 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:32:28 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:32:28 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:32:28 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 03:32:28 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:32:28 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:32:28 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:32:28 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:32:28 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:32:28 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:32:28 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 03:32:28 --> Final output sent to browser
DEBUG - 2010-07-07 03:32:28 --> Total execution time: 0.3615
DEBUG - 2010-07-07 03:34:57 --> Config Class Initialized
DEBUG - 2010-07-07 03:34:57 --> Hooks Class Initialized
DEBUG - 2010-07-07 03:34:57 --> URI Class Initialized
DEBUG - 2010-07-07 03:34:57 --> Router Class Initialized
DEBUG - 2010-07-07 03:34:57 --> Output Class Initialized
DEBUG - 2010-07-07 03:34:57 --> Input Class Initialized
DEBUG - 2010-07-07 03:34:57 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 03:34:57 --> Language Class Initialized
DEBUG - 2010-07-07 03:34:57 --> Loader Class Initialized
DEBUG - 2010-07-07 03:34:57 --> Helper loaded: context_helper
DEBUG - 2010-07-07 03:34:57 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 03:34:57 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 03:34:57 --> Database Driver Class Initialized
DEBUG - 2010-07-07 03:34:57 --> Controller Class Initialized
DEBUG - 2010-07-07 03:34:57 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 03:34:57 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 03:34:57 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 03:34:57 --> Session Class Initialized
DEBUG - 2010-07-07 03:34:57 --> Helper loaded: string_helper
DEBUG - 2010-07-07 03:34:57 --> Session routines successfully run
DEBUG - 2010-07-07 03:34:57 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:34:57 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:34:57 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:34:58 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 03:34:58 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:34:58 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:34:58 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:34:58 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:34:58 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:34:58 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:34:58 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 03:34:58 --> Final output sent to browser
DEBUG - 2010-07-07 03:34:58 --> Total execution time: 0.3573
DEBUG - 2010-07-07 03:39:43 --> Config Class Initialized
DEBUG - 2010-07-07 03:39:43 --> Hooks Class Initialized
DEBUG - 2010-07-07 03:39:43 --> URI Class Initialized
DEBUG - 2010-07-07 03:39:43 --> Router Class Initialized
DEBUG - 2010-07-07 03:39:43 --> Output Class Initialized
DEBUG - 2010-07-07 03:39:43 --> Input Class Initialized
DEBUG - 2010-07-07 03:39:43 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 03:39:43 --> Language Class Initialized
DEBUG - 2010-07-07 03:39:43 --> Loader Class Initialized
DEBUG - 2010-07-07 03:39:43 --> Helper loaded: context_helper
DEBUG - 2010-07-07 03:39:43 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 03:39:43 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 03:39:43 --> Database Driver Class Initialized
DEBUG - 2010-07-07 03:39:43 --> Controller Class Initialized
DEBUG - 2010-07-07 03:39:43 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 03:39:43 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 03:39:43 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 03:39:43 --> Session Class Initialized
DEBUG - 2010-07-07 03:39:43 --> Helper loaded: string_helper
DEBUG - 2010-07-07 03:39:43 --> Session routines successfully run
DEBUG - 2010-07-07 03:39:43 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:39:43 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:39:43 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:39:43 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-07-07 03:39:43 --> Severity: Notice  --> Undefined variable: ouptut D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 411
ERROR - 2010-07-07 03:39:43 --> Severity: Notice  --> Undefined variable: ouptut D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 411
DEBUG - 2010-07-07 03:39:43 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:39:43 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:39:43 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:39:43 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:39:43 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:39:43 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:39:43 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 03:39:43 --> Final output sent to browser
DEBUG - 2010-07-07 03:39:43 --> Total execution time: 0.4456
DEBUG - 2010-07-07 03:39:58 --> Config Class Initialized
DEBUG - 2010-07-07 03:39:58 --> Hooks Class Initialized
DEBUG - 2010-07-07 03:39:58 --> URI Class Initialized
DEBUG - 2010-07-07 03:39:58 --> Router Class Initialized
DEBUG - 2010-07-07 03:39:58 --> Output Class Initialized
DEBUG - 2010-07-07 03:39:58 --> Input Class Initialized
DEBUG - 2010-07-07 03:39:58 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 03:39:58 --> Language Class Initialized
DEBUG - 2010-07-07 03:39:58 --> Loader Class Initialized
DEBUG - 2010-07-07 03:39:58 --> Helper loaded: context_helper
DEBUG - 2010-07-07 03:39:58 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 03:39:58 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 03:39:58 --> Database Driver Class Initialized
DEBUG - 2010-07-07 03:39:58 --> Controller Class Initialized
DEBUG - 2010-07-07 03:39:58 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 03:39:58 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 03:39:58 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 03:39:58 --> Session Class Initialized
DEBUG - 2010-07-07 03:39:58 --> Helper loaded: string_helper
DEBUG - 2010-07-07 03:39:58 --> Session routines successfully run
DEBUG - 2010-07-07 03:39:58 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:39:58 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:39:58 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:39:58 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 03:39:58 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:39:58 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:39:58 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:39:58 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:39:58 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:39:58 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:39:58 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 03:39:58 --> Final output sent to browser
DEBUG - 2010-07-07 03:39:58 --> Total execution time: 0.3855
DEBUG - 2010-07-07 03:40:36 --> Config Class Initialized
DEBUG - 2010-07-07 03:40:36 --> Hooks Class Initialized
DEBUG - 2010-07-07 03:40:36 --> URI Class Initialized
DEBUG - 2010-07-07 03:40:36 --> Router Class Initialized
DEBUG - 2010-07-07 03:40:36 --> Output Class Initialized
DEBUG - 2010-07-07 03:40:36 --> Input Class Initialized
DEBUG - 2010-07-07 03:40:36 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 03:40:36 --> Language Class Initialized
DEBUG - 2010-07-07 03:40:36 --> Loader Class Initialized
DEBUG - 2010-07-07 03:40:36 --> Helper loaded: context_helper
DEBUG - 2010-07-07 03:40:36 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 03:40:36 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 03:40:36 --> Database Driver Class Initialized
DEBUG - 2010-07-07 03:40:36 --> Controller Class Initialized
DEBUG - 2010-07-07 03:40:36 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 03:40:36 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 03:40:36 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 03:40:36 --> Session Class Initialized
DEBUG - 2010-07-07 03:40:36 --> Helper loaded: string_helper
DEBUG - 2010-07-07 03:40:36 --> Session routines successfully run
DEBUG - 2010-07-07 03:40:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:40:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:40:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:40:36 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 03:40:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:40:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:40:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:40:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:40:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:40:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:40:36 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 03:40:36 --> Final output sent to browser
DEBUG - 2010-07-07 03:40:36 --> Total execution time: 0.4451
DEBUG - 2010-07-07 03:41:14 --> Config Class Initialized
DEBUG - 2010-07-07 03:41:14 --> Hooks Class Initialized
DEBUG - 2010-07-07 03:41:14 --> URI Class Initialized
DEBUG - 2010-07-07 03:41:14 --> Router Class Initialized
DEBUG - 2010-07-07 03:41:14 --> Output Class Initialized
DEBUG - 2010-07-07 03:41:14 --> Input Class Initialized
DEBUG - 2010-07-07 03:41:14 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 03:41:14 --> Language Class Initialized
DEBUG - 2010-07-07 03:41:14 --> Loader Class Initialized
DEBUG - 2010-07-07 03:41:14 --> Helper loaded: context_helper
DEBUG - 2010-07-07 03:41:14 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 03:41:14 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 03:41:14 --> Database Driver Class Initialized
DEBUG - 2010-07-07 03:41:14 --> Controller Class Initialized
DEBUG - 2010-07-07 03:41:14 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 03:41:14 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 03:41:14 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 03:41:14 --> Session Class Initialized
DEBUG - 2010-07-07 03:41:14 --> Helper loaded: string_helper
DEBUG - 2010-07-07 03:41:14 --> Session routines successfully run
DEBUG - 2010-07-07 03:41:14 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:41:14 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:41:14 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:41:14 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 03:41:14 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:41:14 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:41:14 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:41:14 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:41:14 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:41:14 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:41:14 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 03:41:14 --> Final output sent to browser
DEBUG - 2010-07-07 03:41:14 --> Total execution time: 0.4533
DEBUG - 2010-07-07 03:41:15 --> Config Class Initialized
DEBUG - 2010-07-07 03:41:15 --> Hooks Class Initialized
DEBUG - 2010-07-07 03:41:15 --> URI Class Initialized
DEBUG - 2010-07-07 03:41:15 --> Router Class Initialized
DEBUG - 2010-07-07 03:41:15 --> Output Class Initialized
DEBUG - 2010-07-07 03:41:15 --> Input Class Initialized
DEBUG - 2010-07-07 03:41:15 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 03:41:15 --> Language Class Initialized
DEBUG - 2010-07-07 03:41:15 --> Loader Class Initialized
DEBUG - 2010-07-07 03:41:15 --> Helper loaded: context_helper
DEBUG - 2010-07-07 03:41:15 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 03:41:15 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 03:41:15 --> Database Driver Class Initialized
DEBUG - 2010-07-07 03:41:15 --> Controller Class Initialized
DEBUG - 2010-07-07 03:41:15 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 03:41:15 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 03:41:15 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 03:41:15 --> Session Class Initialized
DEBUG - 2010-07-07 03:41:15 --> Helper loaded: string_helper
DEBUG - 2010-07-07 03:41:15 --> Session routines successfully run
DEBUG - 2010-07-07 03:41:15 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:41:15 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:41:15 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:41:15 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 03:41:15 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:41:15 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:41:15 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:41:15 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:41:15 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:41:15 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:41:15 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 03:41:16 --> Final output sent to browser
DEBUG - 2010-07-07 03:41:16 --> Total execution time: 0.4812
DEBUG - 2010-07-07 03:59:22 --> Config Class Initialized
DEBUG - 2010-07-07 03:59:22 --> Hooks Class Initialized
DEBUG - 2010-07-07 03:59:22 --> URI Class Initialized
DEBUG - 2010-07-07 03:59:22 --> Router Class Initialized
DEBUG - 2010-07-07 03:59:22 --> Output Class Initialized
DEBUG - 2010-07-07 03:59:23 --> Input Class Initialized
DEBUG - 2010-07-07 03:59:23 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 03:59:23 --> Language Class Initialized
DEBUG - 2010-07-07 03:59:23 --> Loader Class Initialized
DEBUG - 2010-07-07 03:59:23 --> Helper loaded: context_helper
DEBUG - 2010-07-07 03:59:23 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 03:59:23 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 03:59:23 --> Database Driver Class Initialized
DEBUG - 2010-07-07 03:59:23 --> Controller Class Initialized
DEBUG - 2010-07-07 03:59:23 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 03:59:23 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 03:59:23 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 03:59:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:59:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 03:59:23 --> Segmentor class already loaded. Second attempt ignored.
ERROR - 2010-07-07 03:59:23 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;Text來寫PHP真是有夠痛苦的。&quot;
LINE 1: ...ented) VALUES (而且NetBeans寫習慣之後，回頭用這RJ Text來寫PH...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-07 03:59:23 --> DB Transaction Failure
ERROR - 2010-07-07 03:59:23 --> Query error: ERROR:  syntax error at or near "Text來寫PHP真是有夠痛苦的。"
LINE 1: ...ented) VALUES (而且NetBeans寫習慣之後，回頭用這RJ Text來寫PH...
                                                             ^
DEBUG - 2010-07-07 03:59:23 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-07-07 04:00:11 --> Config Class Initialized
DEBUG - 2010-07-07 04:00:11 --> Hooks Class Initialized
DEBUG - 2010-07-07 04:00:11 --> URI Class Initialized
DEBUG - 2010-07-07 04:00:11 --> Router Class Initialized
DEBUG - 2010-07-07 04:00:11 --> Output Class Initialized
DEBUG - 2010-07-07 04:00:11 --> Input Class Initialized
DEBUG - 2010-07-07 04:00:11 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 04:00:11 --> Language Class Initialized
DEBUG - 2010-07-07 04:00:11 --> Loader Class Initialized
DEBUG - 2010-07-07 04:00:11 --> Helper loaded: context_helper
DEBUG - 2010-07-07 04:00:11 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 04:00:11 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 04:00:11 --> Database Driver Class Initialized
DEBUG - 2010-07-07 04:00:11 --> Controller Class Initialized
DEBUG - 2010-07-07 04:00:11 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 04:00:11 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 04:00:11 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 04:00:11 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:00:11 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:00:11 --> Segmentor class already loaded. Second attempt ignored.
ERROR - 2010-07-07 04:00:11 --> Severity: Warning  --> Wrong parameter count for in_array() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 520
ERROR - 2010-07-07 04:00:11 --> Severity: Warning  --> Wrong parameter count for in_array() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 520
ERROR - 2010-07-07 04:00:11 --> Severity: Warning  --> Wrong parameter count for in_array() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 520
DEBUG - 2010-07-07 04:00:11 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 04:00:11 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:00:11 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:00:11 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:00:11 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:00:11 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:00:11 --> Segmentor class already loaded. Second attempt ignored.
ERROR - 2010-07-07 04:00:11 --> Severity: Warning  --> Wrong parameter count for in_array() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 520
ERROR - 2010-07-07 04:00:11 --> Severity: Warning  --> Wrong parameter count for in_array() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 520
ERROR - 2010-07-07 04:00:11 --> Severity: Warning  --> Wrong parameter count for in_array() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 520
DEBUG - 2010-07-07 04:00:11 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 04:00:11 --> Final output sent to browser
DEBUG - 2010-07-07 04:00:11 --> Total execution time: 0.5493
DEBUG - 2010-07-07 04:02:01 --> Config Class Initialized
DEBUG - 2010-07-07 04:02:01 --> Hooks Class Initialized
DEBUG - 2010-07-07 04:02:01 --> URI Class Initialized
DEBUG - 2010-07-07 04:02:01 --> Router Class Initialized
DEBUG - 2010-07-07 04:02:01 --> Output Class Initialized
DEBUG - 2010-07-07 04:02:01 --> Input Class Initialized
DEBUG - 2010-07-07 04:02:01 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 04:02:01 --> Language Class Initialized
DEBUG - 2010-07-07 04:02:01 --> Loader Class Initialized
DEBUG - 2010-07-07 04:02:01 --> Helper loaded: context_helper
DEBUG - 2010-07-07 04:02:01 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 04:02:01 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 04:02:01 --> Database Driver Class Initialized
DEBUG - 2010-07-07 04:02:01 --> Controller Class Initialized
DEBUG - 2010-07-07 04:02:01 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 04:02:01 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 04:02:01 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 04:02:01 --> Session Class Initialized
DEBUG - 2010-07-07 04:02:01 --> Helper loaded: string_helper
DEBUG - 2010-07-07 04:02:01 --> Session routines successfully run
DEBUG - 2010-07-07 04:02:01 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:02:02 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:02:02 --> Segmentor class already loaded. Second attempt ignored.
ERROR - 2010-07-07 04:02:02 --> Severity: Warning  --> Wrong parameter count for in_array() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 520
ERROR - 2010-07-07 04:02:02 --> Severity: Warning  --> Wrong parameter count for in_array() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 520
ERROR - 2010-07-07 04:02:02 --> Severity: Warning  --> Wrong parameter count for in_array() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 520
DEBUG - 2010-07-07 04:02:02 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 04:02:02 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:02:02 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:02:02 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:02:02 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:02:02 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:02:02 --> Segmentor class already loaded. Second attempt ignored.
ERROR - 2010-07-07 04:02:02 --> Severity: Warning  --> Wrong parameter count for in_array() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 520
ERROR - 2010-07-07 04:02:02 --> Severity: Warning  --> Wrong parameter count for in_array() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 520
ERROR - 2010-07-07 04:02:02 --> Severity: Warning  --> Wrong parameter count for in_array() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 520
DEBUG - 2010-07-07 04:02:02 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 04:02:02 --> Final output sent to browser
DEBUG - 2010-07-07 04:02:02 --> Total execution time: 1.2187
DEBUG - 2010-07-07 04:02:31 --> Config Class Initialized
DEBUG - 2010-07-07 04:02:31 --> Hooks Class Initialized
DEBUG - 2010-07-07 04:02:31 --> URI Class Initialized
DEBUG - 2010-07-07 04:02:31 --> Router Class Initialized
DEBUG - 2010-07-07 04:02:31 --> Output Class Initialized
DEBUG - 2010-07-07 04:02:31 --> Input Class Initialized
DEBUG - 2010-07-07 04:02:31 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 04:02:31 --> Language Class Initialized
DEBUG - 2010-07-07 04:02:31 --> Loader Class Initialized
DEBUG - 2010-07-07 04:02:31 --> Helper loaded: context_helper
DEBUG - 2010-07-07 04:02:31 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 04:02:31 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 04:02:31 --> Database Driver Class Initialized
DEBUG - 2010-07-07 04:02:31 --> Controller Class Initialized
DEBUG - 2010-07-07 04:02:31 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 04:02:31 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 04:02:31 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 04:02:31 --> Session Class Initialized
DEBUG - 2010-07-07 04:02:31 --> Helper loaded: string_helper
DEBUG - 2010-07-07 04:02:31 --> Session routines successfully run
DEBUG - 2010-07-07 04:02:31 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:02:31 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:02:31 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:02:31 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 04:02:31 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:02:31 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:02:31 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:02:31 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:02:31 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:02:31 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:02:31 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 04:02:31 --> Final output sent to browser
DEBUG - 2010-07-07 04:02:31 --> Total execution time: 0.6211
DEBUG - 2010-07-07 04:05:46 --> Config Class Initialized
DEBUG - 2010-07-07 04:05:46 --> Hooks Class Initialized
DEBUG - 2010-07-07 04:05:46 --> URI Class Initialized
DEBUG - 2010-07-07 04:05:46 --> Router Class Initialized
DEBUG - 2010-07-07 04:05:46 --> Output Class Initialized
DEBUG - 2010-07-07 04:05:46 --> Input Class Initialized
DEBUG - 2010-07-07 04:05:46 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 04:05:46 --> Language Class Initialized
DEBUG - 2010-07-07 04:05:46 --> Loader Class Initialized
DEBUG - 2010-07-07 04:05:46 --> Helper loaded: context_helper
DEBUG - 2010-07-07 04:05:46 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 04:05:46 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 04:05:46 --> Database Driver Class Initialized
DEBUG - 2010-07-07 04:05:46 --> Controller Class Initialized
DEBUG - 2010-07-07 04:05:46 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 04:05:46 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 04:05:46 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 04:05:46 --> Session Class Initialized
DEBUG - 2010-07-07 04:05:46 --> Helper loaded: string_helper
DEBUG - 2010-07-07 04:05:46 --> Session routines successfully run
DEBUG - 2010-07-07 04:05:46 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:05:46 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:05:46 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:05:47 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 04:05:47 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:05:47 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:05:47 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:05:47 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:05:47 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:05:47 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:05:47 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 04:05:47 --> Final output sent to browser
DEBUG - 2010-07-07 04:05:47 --> Total execution time: 1.0836
DEBUG - 2010-07-07 04:06:22 --> Config Class Initialized
DEBUG - 2010-07-07 04:06:22 --> Hooks Class Initialized
DEBUG - 2010-07-07 04:06:22 --> URI Class Initialized
DEBUG - 2010-07-07 04:06:22 --> Router Class Initialized
DEBUG - 2010-07-07 04:06:22 --> Output Class Initialized
DEBUG - 2010-07-07 04:06:22 --> Input Class Initialized
DEBUG - 2010-07-07 04:06:22 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 04:06:23 --> Language Class Initialized
DEBUG - 2010-07-07 04:06:23 --> Loader Class Initialized
DEBUG - 2010-07-07 04:06:23 --> Helper loaded: context_helper
DEBUG - 2010-07-07 04:06:23 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 04:06:23 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 04:06:23 --> Database Driver Class Initialized
DEBUG - 2010-07-07 04:06:23 --> Controller Class Initialized
DEBUG - 2010-07-07 04:06:23 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 04:06:23 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 04:06:23 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 04:06:23 --> Session Class Initialized
DEBUG - 2010-07-07 04:06:23 --> Helper loaded: string_helper
DEBUG - 2010-07-07 04:06:23 --> Session routines successfully run
DEBUG - 2010-07-07 04:06:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:06:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:06:23 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:06:23 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 04:06:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:06:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:06:23 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:06:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:06:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:06:23 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:06:23 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 04:06:23 --> Final output sent to browser
DEBUG - 2010-07-07 04:06:23 --> Total execution time: 0.7782
DEBUG - 2010-07-07 04:06:45 --> Config Class Initialized
DEBUG - 2010-07-07 04:06:45 --> Hooks Class Initialized
DEBUG - 2010-07-07 04:06:45 --> URI Class Initialized
DEBUG - 2010-07-07 04:06:45 --> Router Class Initialized
DEBUG - 2010-07-07 04:06:45 --> Output Class Initialized
DEBUG - 2010-07-07 04:06:45 --> Input Class Initialized
DEBUG - 2010-07-07 04:06:45 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 04:06:45 --> Language Class Initialized
DEBUG - 2010-07-07 04:06:45 --> Loader Class Initialized
DEBUG - 2010-07-07 04:06:45 --> Helper loaded: context_helper
DEBUG - 2010-07-07 04:06:45 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 04:06:45 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 04:06:45 --> Database Driver Class Initialized
DEBUG - 2010-07-07 04:06:45 --> Controller Class Initialized
DEBUG - 2010-07-07 04:06:45 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 04:06:45 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 04:06:45 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 04:06:45 --> Session Class Initialized
DEBUG - 2010-07-07 04:06:45 --> Helper loaded: string_helper
DEBUG - 2010-07-07 04:06:45 --> Session routines successfully run
DEBUG - 2010-07-07 04:06:45 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:06:45 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:06:45 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:06:45 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 04:06:45 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:06:45 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:06:45 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:06:45 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:06:45 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:06:45 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:06:46 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 04:06:46 --> Final output sent to browser
DEBUG - 2010-07-07 04:06:46 --> Total execution time: 0.7255
DEBUG - 2010-07-07 04:07:26 --> Config Class Initialized
DEBUG - 2010-07-07 04:07:26 --> Hooks Class Initialized
DEBUG - 2010-07-07 04:07:26 --> URI Class Initialized
DEBUG - 2010-07-07 04:07:26 --> Router Class Initialized
DEBUG - 2010-07-07 04:07:26 --> Output Class Initialized
DEBUG - 2010-07-07 04:07:26 --> Input Class Initialized
DEBUG - 2010-07-07 04:07:26 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 04:07:26 --> Language Class Initialized
DEBUG - 2010-07-07 04:07:26 --> Loader Class Initialized
DEBUG - 2010-07-07 04:07:26 --> Helper loaded: context_helper
DEBUG - 2010-07-07 04:07:26 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 04:07:26 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 04:07:26 --> Database Driver Class Initialized
DEBUG - 2010-07-07 04:07:26 --> Controller Class Initialized
DEBUG - 2010-07-07 04:07:26 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 04:07:26 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 04:07:26 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 04:07:26 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:07:26 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:07:26 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:07:26 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 04:07:26 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:07:26 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:07:26 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:07:26 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:07:26 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:07:27 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:07:27 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 04:07:27 --> Final output sent to browser
DEBUG - 2010-07-07 04:07:27 --> Total execution time: 0.7769
DEBUG - 2010-07-07 04:08:28 --> Config Class Initialized
DEBUG - 2010-07-07 04:08:28 --> Hooks Class Initialized
DEBUG - 2010-07-07 04:08:28 --> URI Class Initialized
DEBUG - 2010-07-07 04:08:28 --> Router Class Initialized
DEBUG - 2010-07-07 04:08:28 --> Output Class Initialized
DEBUG - 2010-07-07 04:08:28 --> Input Class Initialized
DEBUG - 2010-07-07 04:08:28 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 04:08:28 --> Language Class Initialized
DEBUG - 2010-07-07 04:08:28 --> Loader Class Initialized
DEBUG - 2010-07-07 04:08:28 --> Helper loaded: context_helper
DEBUG - 2010-07-07 04:08:28 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 04:08:28 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 04:08:28 --> Database Driver Class Initialized
DEBUG - 2010-07-07 04:08:28 --> Controller Class Initialized
DEBUG - 2010-07-07 04:08:28 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 04:08:28 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 04:08:28 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 04:08:28 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:08:28 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:08:28 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:08:28 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 04:08:28 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:08:28 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:08:28 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:08:29 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:08:29 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:08:29 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:08:29 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 04:08:29 --> Final output sent to browser
DEBUG - 2010-07-07 04:08:29 --> Total execution time: 0.6352
DEBUG - 2010-07-07 04:08:42 --> Config Class Initialized
DEBUG - 2010-07-07 04:08:42 --> Hooks Class Initialized
DEBUG - 2010-07-07 04:08:42 --> URI Class Initialized
DEBUG - 2010-07-07 04:08:42 --> Router Class Initialized
DEBUG - 2010-07-07 04:08:42 --> Output Class Initialized
ERROR - 2010-07-07 04:08:42 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/72b32a1f754ba1c09b3695e0cb6cde7f) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
DEBUG - 2010-07-07 04:08:42 --> Input Class Initialized
DEBUG - 2010-07-07 04:08:42 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 04:08:42 --> Language Class Initialized
DEBUG - 2010-07-07 04:08:42 --> Loader Class Initialized
DEBUG - 2010-07-07 04:08:42 --> Helper loaded: context_helper
DEBUG - 2010-07-07 04:08:42 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 04:08:42 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 04:08:42 --> Database Driver Class Initialized
DEBUG - 2010-07-07 04:08:42 --> Controller Class Initialized
DEBUG - 2010-07-07 04:08:42 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 04:08:43 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 04:08:43 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 04:08:43 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:08:43 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:08:43 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:08:43 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 04:08:43 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:08:43 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:08:43 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:08:43 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:08:43 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:08:43 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:08:43 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 04:08:43 --> Final output sent to browser
DEBUG - 2010-07-07 04:08:43 --> Total execution time: 0.7141
DEBUG - 2010-07-07 04:12:31 --> Config Class Initialized
DEBUG - 2010-07-07 04:12:31 --> Hooks Class Initialized
DEBUG - 2010-07-07 04:12:32 --> URI Class Initialized
DEBUG - 2010-07-07 04:12:32 --> Router Class Initialized
DEBUG - 2010-07-07 04:12:32 --> Output Class Initialized
DEBUG - 2010-07-07 04:12:32 --> Input Class Initialized
DEBUG - 2010-07-07 04:12:32 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 04:12:32 --> Language Class Initialized
DEBUG - 2010-07-07 04:12:32 --> Loader Class Initialized
DEBUG - 2010-07-07 04:12:32 --> Helper loaded: context_helper
DEBUG - 2010-07-07 04:12:32 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 04:12:32 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 04:12:32 --> Database Driver Class Initialized
DEBUG - 2010-07-07 04:12:32 --> Controller Class Initialized
DEBUG - 2010-07-07 04:12:32 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 04:12:32 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 04:12:32 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 04:12:32 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:12:32 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:12:32 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:12:32 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 04:12:32 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:12:32 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:12:32 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:12:32 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:12:32 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:12:32 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:12:32 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 04:12:32 --> Final output sent to browser
DEBUG - 2010-07-07 04:12:32 --> Total execution time: 0.6747
DEBUG - 2010-07-07 04:12:50 --> Config Class Initialized
DEBUG - 2010-07-07 04:12:50 --> Hooks Class Initialized
DEBUG - 2010-07-07 04:12:50 --> URI Class Initialized
DEBUG - 2010-07-07 04:12:50 --> Router Class Initialized
DEBUG - 2010-07-07 04:12:50 --> Output Class Initialized
DEBUG - 2010-07-07 04:12:50 --> Input Class Initialized
DEBUG - 2010-07-07 04:12:50 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 04:12:50 --> Language Class Initialized
DEBUG - 2010-07-07 04:12:50 --> Loader Class Initialized
DEBUG - 2010-07-07 04:12:50 --> Helper loaded: context_helper
DEBUG - 2010-07-07 04:12:50 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 04:12:50 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 04:12:50 --> Database Driver Class Initialized
DEBUG - 2010-07-07 04:12:50 --> Controller Class Initialized
DEBUG - 2010-07-07 04:12:50 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 04:12:50 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 04:12:51 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 04:12:51 --> Session Class Initialized
DEBUG - 2010-07-07 04:12:51 --> Helper loaded: string_helper
DEBUG - 2010-07-07 04:12:51 --> Session routines successfully run
DEBUG - 2010-07-07 04:12:51 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:12:51 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:12:51 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:12:51 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 04:12:51 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:12:51 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:12:51 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:12:51 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:12:51 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:12:51 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:12:51 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 04:12:51 --> Final output sent to browser
DEBUG - 2010-07-07 04:12:51 --> Total execution time: 0.9509
DEBUG - 2010-07-07 04:13:16 --> Config Class Initialized
DEBUG - 2010-07-07 04:13:16 --> Hooks Class Initialized
DEBUG - 2010-07-07 04:13:16 --> URI Class Initialized
DEBUG - 2010-07-07 04:13:16 --> Router Class Initialized
DEBUG - 2010-07-07 04:13:16 --> Output Class Initialized
DEBUG - 2010-07-07 04:13:16 --> Input Class Initialized
DEBUG - 2010-07-07 04:13:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 04:13:17 --> Language Class Initialized
DEBUG - 2010-07-07 04:13:17 --> Loader Class Initialized
DEBUG - 2010-07-07 04:13:17 --> Helper loaded: context_helper
DEBUG - 2010-07-07 04:13:17 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 04:13:17 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 04:13:17 --> Database Driver Class Initialized
DEBUG - 2010-07-07 04:13:17 --> Controller Class Initialized
DEBUG - 2010-07-07 04:13:17 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 04:13:17 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 04:13:17 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 04:13:17 --> Session Class Initialized
DEBUG - 2010-07-07 04:13:17 --> Helper loaded: string_helper
DEBUG - 2010-07-07 04:13:17 --> Session routines successfully run
DEBUG - 2010-07-07 04:13:17 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:13:17 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:13:17 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:13:17 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 04:13:17 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:13:17 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:13:17 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:13:17 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:13:17 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:13:17 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:13:17 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 04:13:17 --> Final output sent to browser
DEBUG - 2010-07-07 04:13:17 --> Total execution time: 0.8584
DEBUG - 2010-07-07 04:13:37 --> Config Class Initialized
DEBUG - 2010-07-07 04:13:37 --> Hooks Class Initialized
DEBUG - 2010-07-07 04:13:37 --> URI Class Initialized
DEBUG - 2010-07-07 04:13:37 --> Router Class Initialized
DEBUG - 2010-07-07 04:13:37 --> Output Class Initialized
DEBUG - 2010-07-07 04:13:37 --> Input Class Initialized
DEBUG - 2010-07-07 04:13:37 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 04:13:37 --> Language Class Initialized
DEBUG - 2010-07-07 04:13:37 --> Loader Class Initialized
DEBUG - 2010-07-07 04:13:37 --> Helper loaded: context_helper
DEBUG - 2010-07-07 04:13:37 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 04:13:37 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 04:13:37 --> Database Driver Class Initialized
DEBUG - 2010-07-07 04:13:37 --> Controller Class Initialized
DEBUG - 2010-07-07 04:13:37 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 04:13:37 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 04:13:37 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 04:13:37 --> Session Class Initialized
DEBUG - 2010-07-07 04:13:37 --> Helper loaded: string_helper
DEBUG - 2010-07-07 04:13:37 --> Session routines successfully run
DEBUG - 2010-07-07 04:13:37 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:13:37 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:13:37 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:13:37 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 04:13:37 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:13:37 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:13:37 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:13:37 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:13:37 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:13:37 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:13:37 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 04:13:38 --> Final output sent to browser
DEBUG - 2010-07-07 04:13:38 --> Total execution time: 0.9390
DEBUG - 2010-07-07 04:20:26 --> Config Class Initialized
DEBUG - 2010-07-07 04:20:26 --> Hooks Class Initialized
DEBUG - 2010-07-07 04:20:26 --> URI Class Initialized
DEBUG - 2010-07-07 04:20:26 --> Router Class Initialized
DEBUG - 2010-07-07 04:20:26 --> Output Class Initialized
DEBUG - 2010-07-07 04:20:26 --> Input Class Initialized
DEBUG - 2010-07-07 04:20:26 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 04:20:26 --> Language Class Initialized
DEBUG - 2010-07-07 04:20:26 --> Loader Class Initialized
DEBUG - 2010-07-07 04:20:26 --> Helper loaded: context_helper
DEBUG - 2010-07-07 04:20:26 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 04:20:26 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 04:20:26 --> Database Driver Class Initialized
DEBUG - 2010-07-07 04:20:26 --> Controller Class Initialized
DEBUG - 2010-07-07 04:20:26 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 04:20:26 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 04:20:26 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 04:20:26 --> Session Class Initialized
DEBUG - 2010-07-07 04:20:26 --> Helper loaded: string_helper
DEBUG - 2010-07-07 04:20:26 --> Session routines successfully run
DEBUG - 2010-07-07 04:20:26 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:20:26 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:20:26 --> Segmentor class already loaded. Second attempt ignored.
ERROR - 2010-07-07 04:20:27 --> Severity: Warning  --> in_array() [<a href='function.in-array'>function.in-array</a>]: Wrong datatype for second argument D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 541
ERROR - 2010-07-07 04:20:27 --> Severity: Warning  --> in_array() [<a href='function.in-array'>function.in-array</a>]: Wrong datatype for second argument D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 541
ERROR - 2010-07-07 04:20:27 --> Severity: Warning  --> in_array() [<a href='function.in-array'>function.in-array</a>]: Wrong datatype for second argument D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 541
ERROR - 2010-07-07 04:20:27 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;Array&quot;
LINE 1: INSERT INTO Array (text, indexed, segmented) VALUES ('而且Ne...
                    ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-07 04:20:27 --> DB Transaction Failure
ERROR - 2010-07-07 04:20:27 --> Query error: ERROR:  syntax error at or near "Array"
LINE 1: INSERT INTO Array (text, indexed, segmented) VALUES ('而且Ne...
                    ^
DEBUG - 2010-07-07 04:20:27 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-07 04:20:27 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-07 04:21:17 --> Config Class Initialized
DEBUG - 2010-07-07 04:21:17 --> Hooks Class Initialized
DEBUG - 2010-07-07 04:21:17 --> URI Class Initialized
DEBUG - 2010-07-07 04:21:17 --> Router Class Initialized
DEBUG - 2010-07-07 04:21:17 --> Output Class Initialized
DEBUG - 2010-07-07 04:21:17 --> Input Class Initialized
DEBUG - 2010-07-07 04:21:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 04:21:17 --> Language Class Initialized
DEBUG - 2010-07-07 04:21:17 --> Loader Class Initialized
DEBUG - 2010-07-07 04:21:17 --> Helper loaded: context_helper
DEBUG - 2010-07-07 04:21:17 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 04:21:17 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 04:21:17 --> Database Driver Class Initialized
DEBUG - 2010-07-07 04:21:17 --> Controller Class Initialized
DEBUG - 2010-07-07 04:21:17 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 04:21:17 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 04:21:17 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 04:21:17 --> Session Class Initialized
DEBUG - 2010-07-07 04:21:18 --> Helper loaded: string_helper
DEBUG - 2010-07-07 04:21:18 --> Session routines successfully run
DEBUG - 2010-07-07 04:21:18 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:21:18 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:21:18 --> Segmentor class already loaded. Second attempt ignored.
ERROR - 2010-07-07 04:21:18 --> Severity: Warning  --> in_array() [<a href='function.in-array'>function.in-array</a>]: Wrong datatype for second argument D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 541
ERROR - 2010-07-07 04:21:18 --> Severity: Warning  --> in_array() [<a href='function.in-array'>function.in-array</a>]: Wrong datatype for second argument D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 541
ERROR - 2010-07-07 04:21:18 --> Severity: Warning  --> in_array() [<a href='function.in-array'>function.in-array</a>]: Wrong datatype for second argument D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 541
ERROR - 2010-07-07 04:21:18 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;Array&quot;
LINE 1: INSERT INTO Array (text, indexed, segmented) VALUES ('而且Ne...
                    ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-07 04:21:18 --> DB Transaction Failure
ERROR - 2010-07-07 04:21:18 --> Query error: ERROR:  syntax error at or near "Array"
LINE 1: INSERT INTO Array (text, indexed, segmented) VALUES ('而且Ne...
                    ^
DEBUG - 2010-07-07 04:21:18 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-07 04:21:18 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-07 04:22:04 --> Config Class Initialized
DEBUG - 2010-07-07 04:22:04 --> Hooks Class Initialized
DEBUG - 2010-07-07 04:22:04 --> URI Class Initialized
DEBUG - 2010-07-07 04:22:04 --> Router Class Initialized
DEBUG - 2010-07-07 04:22:04 --> Output Class Initialized
DEBUG - 2010-07-07 04:22:04 --> Input Class Initialized
DEBUG - 2010-07-07 04:22:04 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 04:22:04 --> Language Class Initialized
DEBUG - 2010-07-07 04:22:04 --> Loader Class Initialized
DEBUG - 2010-07-07 04:22:04 --> Helper loaded: context_helper
DEBUG - 2010-07-07 04:22:04 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 04:22:04 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 04:22:04 --> Database Driver Class Initialized
DEBUG - 2010-07-07 04:22:04 --> Controller Class Initialized
DEBUG - 2010-07-07 04:22:04 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 04:22:04 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 04:22:05 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 04:22:05 --> Session Class Initialized
DEBUG - 2010-07-07 04:22:05 --> Helper loaded: string_helper
DEBUG - 2010-07-07 04:22:05 --> Session routines successfully run
DEBUG - 2010-07-07 04:22:05 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:22:05 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:22:05 --> Segmentor class already loaded. Second attempt ignored.
ERROR - 2010-07-07 04:22:05 --> Severity: Notice  --> Undefined variable: except_bind_fields D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 509
DEBUG - 2010-07-07 04:22:05 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 04:22:05 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:22:05 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:22:05 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:22:05 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:22:05 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:22:05 --> Segmentor class already loaded. Second attempt ignored.
ERROR - 2010-07-07 04:22:05 --> Severity: Notice  --> Undefined variable: except_bind_fields D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 509
DEBUG - 2010-07-07 04:22:05 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 04:22:05 --> Final output sent to browser
DEBUG - 2010-07-07 04:22:05 --> Total execution time: 1.1451
DEBUG - 2010-07-07 04:22:47 --> Config Class Initialized
DEBUG - 2010-07-07 04:22:47 --> Hooks Class Initialized
DEBUG - 2010-07-07 04:22:47 --> URI Class Initialized
DEBUG - 2010-07-07 04:22:47 --> Router Class Initialized
DEBUG - 2010-07-07 04:22:47 --> Output Class Initialized
DEBUG - 2010-07-07 04:22:47 --> Input Class Initialized
DEBUG - 2010-07-07 04:22:47 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 04:22:47 --> Language Class Initialized
DEBUG - 2010-07-07 04:22:47 --> Loader Class Initialized
DEBUG - 2010-07-07 04:22:47 --> Helper loaded: context_helper
DEBUG - 2010-07-07 04:22:47 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 04:22:47 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 04:22:47 --> Database Driver Class Initialized
DEBUG - 2010-07-07 04:22:47 --> Controller Class Initialized
DEBUG - 2010-07-07 04:22:47 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 04:22:47 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 04:22:47 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 04:22:47 --> Session Class Initialized
DEBUG - 2010-07-07 04:22:48 --> Helper loaded: string_helper
DEBUG - 2010-07-07 04:22:48 --> Session routines successfully run
DEBUG - 2010-07-07 04:22:48 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:22:48 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:22:48 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:22:48 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 04:22:48 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:22:48 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:22:48 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:22:48 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:22:48 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:22:48 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 04:22:48 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 04:22:48 --> Final output sent to browser
DEBUG - 2010-07-07 04:22:48 --> Total execution time: 1.0801
DEBUG - 2010-07-07 06:07:03 --> Config Class Initialized
DEBUG - 2010-07-07 06:07:03 --> Hooks Class Initialized
DEBUG - 2010-07-07 06:07:03 --> URI Class Initialized
DEBUG - 2010-07-07 06:07:03 --> Router Class Initialized
DEBUG - 2010-07-07 06:07:03 --> Output Class Initialized
DEBUG - 2010-07-07 06:07:03 --> Input Class Initialized
DEBUG - 2010-07-07 06:07:03 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 06:07:03 --> Language Class Initialized
DEBUG - 2010-07-07 06:07:03 --> Loader Class Initialized
DEBUG - 2010-07-07 06:07:03 --> Helper loaded: context_helper
DEBUG - 2010-07-07 06:07:03 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 06:07:03 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 06:07:04 --> Database Driver Class Initialized
DEBUG - 2010-07-07 06:07:04 --> Controller Class Initialized
DEBUG - 2010-07-07 06:07:04 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 06:07:04 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 06:07:04 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 06:07:04 --> Session Class Initialized
DEBUG - 2010-07-07 06:07:04 --> Helper loaded: string_helper
DEBUG - 2010-07-07 06:07:04 --> Session routines successfully run
DEBUG - 2010-07-07 06:07:04 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:07:04 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:07:04 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:07:04 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 06:07:04 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:07:04 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:07:04 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:07:04 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:07:04 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:07:04 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:07:04 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 06:07:04 --> Final output sent to browser
DEBUG - 2010-07-07 06:07:04 --> Total execution time: 1.2995
DEBUG - 2010-07-07 06:07:24 --> Config Class Initialized
DEBUG - 2010-07-07 06:07:24 --> Hooks Class Initialized
DEBUG - 2010-07-07 06:07:24 --> URI Class Initialized
DEBUG - 2010-07-07 06:07:24 --> Router Class Initialized
DEBUG - 2010-07-07 06:07:24 --> Output Class Initialized
DEBUG - 2010-07-07 06:07:24 --> Input Class Initialized
DEBUG - 2010-07-07 06:07:24 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 06:07:24 --> Language Class Initialized
DEBUG - 2010-07-07 06:07:24 --> Loader Class Initialized
DEBUG - 2010-07-07 06:07:24 --> Helper loaded: context_helper
DEBUG - 2010-07-07 06:07:24 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 06:07:24 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 06:07:24 --> Database Driver Class Initialized
DEBUG - 2010-07-07 06:07:24 --> Controller Class Initialized
DEBUG - 2010-07-07 06:07:24 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 06:07:24 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 06:07:24 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 06:07:24 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:07:24 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:07:24 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:07:24 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 06:07:24 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:07:24 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:07:24 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:07:24 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:07:25 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:07:25 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:07:25 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 06:07:25 --> Final output sent to browser
DEBUG - 2010-07-07 06:07:25 --> Total execution time: 0.9651
DEBUG - 2010-07-07 06:41:58 --> Config Class Initialized
DEBUG - 2010-07-07 06:41:58 --> Hooks Class Initialized
DEBUG - 2010-07-07 06:41:58 --> URI Class Initialized
DEBUG - 2010-07-07 06:41:58 --> No URI present. Default controller set.
DEBUG - 2010-07-07 06:41:58 --> Router Class Initialized
DEBUG - 2010-07-07 06:41:58 --> Output Class Initialized
DEBUG - 2010-07-07 06:41:58 --> Input Class Initialized
DEBUG - 2010-07-07 06:41:58 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 06:41:58 --> Language Class Initialized
DEBUG - 2010-07-07 06:41:58 --> Loader Class Initialized
DEBUG - 2010-07-07 06:41:58 --> Helper loaded: context_helper
DEBUG - 2010-07-07 06:41:58 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 06:41:58 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 06:41:58 --> Database Driver Class Initialized
DEBUG - 2010-07-07 06:41:58 --> Controller Class Initialized
DEBUG - 2010-07-07 06:41:58 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-07-07 06:41:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:41:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:41:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:41:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:41:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:41:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:41:59 --> Helper loaded: email_helper
DEBUG - 2010-07-07 06:41:59 --> User Agent Class Initialized
DEBUG - 2010-07-07 06:41:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:41:59 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:41:59 --> Final output sent to browser
DEBUG - 2010-07-07 06:41:59 --> Total execution time: 1.1370
DEBUG - 2010-07-07 06:42:06 --> Config Class Initialized
DEBUG - 2010-07-07 06:42:06 --> Hooks Class Initialized
DEBUG - 2010-07-07 06:42:06 --> URI Class Initialized
DEBUG - 2010-07-07 06:42:06 --> No URI present. Default controller set.
DEBUG - 2010-07-07 06:42:06 --> Router Class Initialized
DEBUG - 2010-07-07 06:42:06 --> Output Class Initialized
DEBUG - 2010-07-07 06:42:06 --> Input Class Initialized
DEBUG - 2010-07-07 06:42:06 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 06:42:07 --> Language Class Initialized
DEBUG - 2010-07-07 06:42:07 --> Loader Class Initialized
DEBUG - 2010-07-07 06:42:07 --> Helper loaded: context_helper
DEBUG - 2010-07-07 06:42:07 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 06:42:07 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 06:42:07 --> Database Driver Class Initialized
DEBUG - 2010-07-07 06:42:07 --> Controller Class Initialized
DEBUG - 2010-07-07 06:42:07 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-07-07 06:42:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:42:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:42:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:42:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:42:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:42:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:42:07 --> Helper loaded: email_helper
DEBUG - 2010-07-07 06:42:07 --> User Agent Class Initialized
DEBUG - 2010-07-07 06:42:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:42:07 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:42:07 --> Final output sent to browser
DEBUG - 2010-07-07 06:42:07 --> Total execution time: 0.8482
DEBUG - 2010-07-07 06:42:16 --> Config Class Initialized
DEBUG - 2010-07-07 06:42:16 --> Hooks Class Initialized
DEBUG - 2010-07-07 06:42:16 --> URI Class Initialized
DEBUG - 2010-07-07 06:42:16 --> No URI present. Default controller set.
DEBUG - 2010-07-07 06:42:16 --> Router Class Initialized
DEBUG - 2010-07-07 06:42:16 --> Output Class Initialized
DEBUG - 2010-07-07 06:42:16 --> Input Class Initialized
DEBUG - 2010-07-07 06:42:16 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 06:42:16 --> Language Class Initialized
DEBUG - 2010-07-07 06:42:16 --> Loader Class Initialized
DEBUG - 2010-07-07 06:42:16 --> Helper loaded: context_helper
DEBUG - 2010-07-07 06:42:16 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 06:42:16 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 06:42:16 --> Database Driver Class Initialized
DEBUG - 2010-07-07 06:42:16 --> Controller Class Initialized
DEBUG - 2010-07-07 06:42:16 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-07-07 06:42:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:42:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:42:17 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:42:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:42:17 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:42:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:42:17 --> Helper loaded: email_helper
DEBUG - 2010-07-07 06:42:17 --> User Agent Class Initialized
DEBUG - 2010-07-07 06:42:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:42:17 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 06:42:17 --> Final output sent to browser
DEBUG - 2010-07-07 06:42:17 --> Total execution time: 0.8700
DEBUG - 2010-07-07 07:45:09 --> Config Class Initialized
DEBUG - 2010-07-07 07:45:09 --> Hooks Class Initialized
DEBUG - 2010-07-07 07:45:09 --> URI Class Initialized
DEBUG - 2010-07-07 07:45:09 --> No URI present. Default controller set.
DEBUG - 2010-07-07 07:45:09 --> Router Class Initialized
DEBUG - 2010-07-07 07:45:09 --> Output Class Initialized
DEBUG - 2010-07-07 07:45:09 --> Input Class Initialized
DEBUG - 2010-07-07 07:45:09 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 07:45:09 --> Language Class Initialized
DEBUG - 2010-07-07 07:45:18 --> Config Class Initialized
DEBUG - 2010-07-07 07:45:18 --> Hooks Class Initialized
DEBUG - 2010-07-07 07:45:18 --> URI Class Initialized
DEBUG - 2010-07-07 07:45:18 --> No URI present. Default controller set.
DEBUG - 2010-07-07 07:45:18 --> Router Class Initialized
DEBUG - 2010-07-07 07:45:18 --> Output Class Initialized
DEBUG - 2010-07-07 07:45:18 --> Input Class Initialized
DEBUG - 2010-07-07 07:45:18 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 07:45:18 --> Language Class Initialized
DEBUG - 2010-07-07 07:45:18 --> Loader Class Initialized
DEBUG - 2010-07-07 07:45:18 --> Helper loaded: context_helper
DEBUG - 2010-07-07 07:45:18 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 07:45:18 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 07:45:18 --> Database Driver Class Initialized
DEBUG - 2010-07-07 07:45:50 --> Config Class Initialized
DEBUG - 2010-07-07 07:45:50 --> Hooks Class Initialized
DEBUG - 2010-07-07 07:45:50 --> URI Class Initialized
DEBUG - 2010-07-07 07:45:50 --> No URI present. Default controller set.
DEBUG - 2010-07-07 07:45:50 --> Router Class Initialized
DEBUG - 2010-07-07 07:45:50 --> Output Class Initialized
DEBUG - 2010-07-07 07:45:50 --> Input Class Initialized
DEBUG - 2010-07-07 07:45:50 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 07:45:51 --> Language Class Initialized
DEBUG - 2010-07-07 07:45:51 --> Loader Class Initialized
DEBUG - 2010-07-07 07:45:51 --> Helper loaded: context_helper
DEBUG - 2010-07-07 07:45:51 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 07:45:51 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 07:45:51 --> Database Driver Class Initialized
DEBUG - 2010-07-07 07:47:48 --> Config Class Initialized
DEBUG - 2010-07-07 07:47:48 --> Hooks Class Initialized
DEBUG - 2010-07-07 07:47:48 --> URI Class Initialized
DEBUG - 2010-07-07 07:47:48 --> No URI present. Default controller set.
DEBUG - 2010-07-07 07:47:48 --> Router Class Initialized
DEBUG - 2010-07-07 07:47:48 --> Output Class Initialized
DEBUG - 2010-07-07 07:47:48 --> Input Class Initialized
DEBUG - 2010-07-07 07:47:48 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 07:47:48 --> Language Class Initialized
DEBUG - 2010-07-07 07:47:48 --> Loader Class Initialized
DEBUG - 2010-07-07 07:47:48 --> Helper loaded: context_helper
DEBUG - 2010-07-07 07:47:48 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 07:47:48 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 07:47:48 --> Database Driver Class Initialized
DEBUG - 2010-07-07 07:48:27 --> Config Class Initialized
DEBUG - 2010-07-07 07:48:27 --> Hooks Class Initialized
DEBUG - 2010-07-07 07:48:27 --> URI Class Initialized
DEBUG - 2010-07-07 07:48:27 --> No URI present. Default controller set.
DEBUG - 2010-07-07 07:48:27 --> Router Class Initialized
DEBUG - 2010-07-07 07:48:27 --> Output Class Initialized
DEBUG - 2010-07-07 07:48:27 --> Input Class Initialized
DEBUG - 2010-07-07 07:48:27 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 07:48:27 --> Language Class Initialized
DEBUG - 2010-07-07 07:48:27 --> Loader Class Initialized
DEBUG - 2010-07-07 07:48:27 --> Helper loaded: context_helper
DEBUG - 2010-07-07 07:48:27 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 07:48:27 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 07:48:28 --> Database Driver Class Initialized
DEBUG - 2010-07-07 07:48:48 --> Config Class Initialized
DEBUG - 2010-07-07 07:48:48 --> Hooks Class Initialized
DEBUG - 2010-07-07 07:48:48 --> URI Class Initialized
DEBUG - 2010-07-07 07:48:48 --> No URI present. Default controller set.
DEBUG - 2010-07-07 07:48:48 --> Router Class Initialized
DEBUG - 2010-07-07 07:48:48 --> Output Class Initialized
DEBUG - 2010-07-07 07:48:48 --> Input Class Initialized
DEBUG - 2010-07-07 07:48:48 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 07:48:48 --> Language Class Initialized
DEBUG - 2010-07-07 07:48:48 --> Loader Class Initialized
DEBUG - 2010-07-07 07:48:48 --> Helper loaded: context_helper
DEBUG - 2010-07-07 07:48:48 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 07:48:48 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 07:48:48 --> Database Driver Class Initialized
DEBUG - 2010-07-07 07:48:59 --> Config Class Initialized
DEBUG - 2010-07-07 07:48:59 --> Hooks Class Initialized
DEBUG - 2010-07-07 07:48:59 --> URI Class Initialized
DEBUG - 2010-07-07 07:48:59 --> No URI present. Default controller set.
DEBUG - 2010-07-07 07:48:59 --> Router Class Initialized
DEBUG - 2010-07-07 07:48:59 --> Output Class Initialized
DEBUG - 2010-07-07 07:48:59 --> Input Class Initialized
DEBUG - 2010-07-07 07:48:59 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 07:48:59 --> Language Class Initialized
DEBUG - 2010-07-07 07:48:59 --> Loader Class Initialized
DEBUG - 2010-07-07 07:48:59 --> Helper loaded: context_helper
DEBUG - 2010-07-07 07:48:59 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 07:48:59 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 07:48:59 --> Database Driver Class Initialized
DEBUG - 2010-07-07 07:48:59 --> Controller Class Initialized
DEBUG - 2010-07-07 07:48:59 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-07-07 07:48:59 --> Final output sent to browser
DEBUG - 2010-07-07 07:48:59 --> Total execution time: 0.6454
DEBUG - 2010-07-07 12:47:44 --> Config Class Initialized
DEBUG - 2010-07-07 12:47:44 --> Hooks Class Initialized
DEBUG - 2010-07-07 12:47:44 --> URI Class Initialized
DEBUG - 2010-07-07 12:47:44 --> Router Class Initialized
DEBUG - 2010-07-07 12:47:44 --> Output Class Initialized
DEBUG - 2010-07-07 12:47:44 --> Input Class Initialized
DEBUG - 2010-07-07 12:47:44 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 12:47:44 --> Language Class Initialized
DEBUG - 2010-07-07 12:47:44 --> Loader Class Initialized
DEBUG - 2010-07-07 12:47:44 --> Helper loaded: context_helper
DEBUG - 2010-07-07 12:47:44 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 12:47:44 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 12:47:44 --> Database Driver Class Initialized
DEBUG - 2010-07-07 12:47:44 --> Controller Class Initialized
DEBUG - 2010-07-07 12:47:44 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 12:47:44 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 12:47:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:45 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:45 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:45 --> Helper loaded: email_helper
DEBUG - 2010-07-07 12:47:45 --> User Agent Class Initialized
DEBUG - 2010-07-07 12:47:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:45 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:45 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:45 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 12:47:45 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:45 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:45 --> Session Class Initialized
DEBUG - 2010-07-07 12:47:45 --> Helper loaded: string_helper
DEBUG - 2010-07-07 12:47:45 --> A session cookie was not found.
DEBUG - 2010-07-07 12:47:45 --> Session routines successfully run
DEBUG - 2010-07-07 12:47:45 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:45 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:46 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:46 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:46 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:46 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:46 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:46 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:47 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:47 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:47 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:47 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:47 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:47 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:47 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:47 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:47 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:47 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:47 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:47:47 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-07-07 12:47:47 --> Severity: Notice  --> Undefined index:  type_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 305
DEBUG - 2010-07-07 12:49:33 --> Config Class Initialized
DEBUG - 2010-07-07 12:49:33 --> Hooks Class Initialized
DEBUG - 2010-07-07 12:49:33 --> URI Class Initialized
DEBUG - 2010-07-07 12:49:33 --> Router Class Initialized
DEBUG - 2010-07-07 12:49:33 --> Output Class Initialized
DEBUG - 2010-07-07 12:49:33 --> Input Class Initialized
DEBUG - 2010-07-07 12:49:33 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 12:49:33 --> Language Class Initialized
DEBUG - 2010-07-07 12:49:33 --> Loader Class Initialized
DEBUG - 2010-07-07 12:49:34 --> Helper loaded: context_helper
DEBUG - 2010-07-07 12:49:34 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 12:49:34 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 12:49:34 --> Database Driver Class Initialized
DEBUG - 2010-07-07 12:49:34 --> Controller Class Initialized
DEBUG - 2010-07-07 12:49:34 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 12:49:34 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 12:49:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:34 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:34 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:34 --> Helper loaded: email_helper
DEBUG - 2010-07-07 12:49:34 --> User Agent Class Initialized
DEBUG - 2010-07-07 12:49:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:34 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:34 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 12:49:34 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:35 --> Session Class Initialized
DEBUG - 2010-07-07 12:49:35 --> Helper loaded: string_helper
DEBUG - 2010-07-07 12:49:35 --> Session routines successfully run
DEBUG - 2010-07-07 12:49:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:36 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:36 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:36 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:36 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:36 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:37 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:37 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:37 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:49:37 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-07-07 12:49:37 --> Severity: Notice  --> Undefined index:  type_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 305
DEBUG - 2010-07-07 12:51:08 --> Config Class Initialized
DEBUG - 2010-07-07 12:51:08 --> Hooks Class Initialized
DEBUG - 2010-07-07 12:51:08 --> URI Class Initialized
DEBUG - 2010-07-07 12:51:08 --> Router Class Initialized
DEBUG - 2010-07-07 12:51:08 --> Output Class Initialized
DEBUG - 2010-07-07 12:51:08 --> Input Class Initialized
DEBUG - 2010-07-07 12:51:08 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 12:51:08 --> Language Class Initialized
DEBUG - 2010-07-07 12:51:08 --> Loader Class Initialized
DEBUG - 2010-07-07 12:51:08 --> Helper loaded: context_helper
DEBUG - 2010-07-07 12:51:08 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 12:51:08 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 12:51:08 --> Database Driver Class Initialized
DEBUG - 2010-07-07 12:51:08 --> Controller Class Initialized
DEBUG - 2010-07-07 12:51:08 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 12:51:08 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 12:51:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:09 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:09 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:09 --> Helper loaded: email_helper
DEBUG - 2010-07-07 12:51:09 --> User Agent Class Initialized
DEBUG - 2010-07-07 12:51:09 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:09 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:09 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 12:51:09 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:09 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:09 --> Session Class Initialized
DEBUG - 2010-07-07 12:51:09 --> Helper loaded: string_helper
DEBUG - 2010-07-07 12:51:09 --> Session routines successfully run
DEBUG - 2010-07-07 12:51:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:10 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:10 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:10 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:10 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:10 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:10 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:10 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:10 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:10 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:10 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:10 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:10 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:10 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:10 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:10 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:51:11 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-07-07 12:51:11 --> Severity: Notice  --> Undefined index:  type_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 305
DEBUG - 2010-07-07 12:52:56 --> Config Class Initialized
DEBUG - 2010-07-07 12:52:56 --> Hooks Class Initialized
DEBUG - 2010-07-07 12:52:56 --> URI Class Initialized
DEBUG - 2010-07-07 12:52:56 --> Router Class Initialized
DEBUG - 2010-07-07 12:52:56 --> Output Class Initialized
DEBUG - 2010-07-07 12:52:56 --> Input Class Initialized
DEBUG - 2010-07-07 12:52:56 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 12:52:56 --> Language Class Initialized
DEBUG - 2010-07-07 12:52:56 --> Loader Class Initialized
DEBUG - 2010-07-07 12:52:56 --> Helper loaded: context_helper
DEBUG - 2010-07-07 12:52:56 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 12:52:56 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 12:52:56 --> Database Driver Class Initialized
DEBUG - 2010-07-07 12:52:56 --> Controller Class Initialized
DEBUG - 2010-07-07 12:52:57 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 12:52:57 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 12:52:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:57 --> Helper loaded: email_helper
DEBUG - 2010-07-07 12:52:57 --> User Agent Class Initialized
DEBUG - 2010-07-07 12:52:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:57 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:57 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 12:52:57 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:57 --> Session Class Initialized
DEBUG - 2010-07-07 12:52:57 --> Helper loaded: string_helper
DEBUG - 2010-07-07 12:52:57 --> Session routines successfully run
DEBUG - 2010-07-07 12:52:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:58 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:58 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:58 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:58 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:58 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:58 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:58 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:58 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:58 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:59 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:59 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:59 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:59 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:59 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 12:52:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:52:59 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:53:57 --> Config Class Initialized
DEBUG - 2010-07-07 12:53:57 --> Hooks Class Initialized
DEBUG - 2010-07-07 12:53:57 --> URI Class Initialized
DEBUG - 2010-07-07 12:53:57 --> Router Class Initialized
DEBUG - 2010-07-07 12:53:57 --> Output Class Initialized
DEBUG - 2010-07-07 12:53:57 --> Input Class Initialized
DEBUG - 2010-07-07 12:53:57 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 12:53:57 --> Language Class Initialized
DEBUG - 2010-07-07 12:53:57 --> Loader Class Initialized
DEBUG - 2010-07-07 12:53:57 --> Helper loaded: context_helper
DEBUG - 2010-07-07 12:53:57 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 12:53:57 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 12:53:57 --> Database Driver Class Initialized
DEBUG - 2010-07-07 12:53:58 --> Controller Class Initialized
DEBUG - 2010-07-07 12:53:58 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 12:53:58 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 12:53:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:53:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:53:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:53:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:53:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:53:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:53:58 --> Helper loaded: email_helper
DEBUG - 2010-07-07 12:53:58 --> User Agent Class Initialized
DEBUG - 2010-07-07 12:53:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:53:58 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:53:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:53:58 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 12:53:58 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:53:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:53:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:53:58 --> Session Class Initialized
DEBUG - 2010-07-07 12:53:58 --> Helper loaded: string_helper
DEBUG - 2010-07-07 12:53:58 --> Session routines successfully run
DEBUG - 2010-07-07 12:53:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:53:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:53:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:53:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:53:59 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:53:59 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:53:59 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:53:59 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:53:59 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:53:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:53:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:53:59 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:54:00 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:54:00 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:54:00 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:54:00 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:54:00 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:54:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:54:00 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:54:00 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:54:00 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:54:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:54:00 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:54:00 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 12:54:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:54:00 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:54:00 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:54:00 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:54:00 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:54:00 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:54:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:54:01 --> Annotation_scope_collection class already loaded. Second attempt ignored.
ERROR - 2010-07-07 12:54:01 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  relation &quot;annotation2scope&quot; does not exist
LINE 2: FROM &quot;annotation2scope&quot;, &quot;annotation2scope&quot;
             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-07 12:54:01 --> DB Transaction Failure
ERROR - 2010-07-07 12:54:01 --> Query error: ERROR:  relation "annotation2scope" does not exist
LINE 2: FROM "annotation2scope", "annotation2scope"
             ^
DEBUG - 2010-07-07 12:54:01 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-07-07 12:55:05 --> Config Class Initialized
DEBUG - 2010-07-07 12:55:05 --> Hooks Class Initialized
DEBUG - 2010-07-07 12:55:05 --> URI Class Initialized
DEBUG - 2010-07-07 12:55:06 --> Router Class Initialized
DEBUG - 2010-07-07 12:55:06 --> Output Class Initialized
DEBUG - 2010-07-07 12:55:06 --> Input Class Initialized
DEBUG - 2010-07-07 12:55:06 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 12:55:06 --> Language Class Initialized
DEBUG - 2010-07-07 12:55:06 --> Loader Class Initialized
DEBUG - 2010-07-07 12:55:06 --> Helper loaded: context_helper
DEBUG - 2010-07-07 12:55:06 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 12:55:06 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 12:55:06 --> Database Driver Class Initialized
DEBUG - 2010-07-07 12:55:06 --> Controller Class Initialized
DEBUG - 2010-07-07 12:55:06 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 12:55:06 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 12:55:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:06 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:06 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:06 --> Helper loaded: email_helper
DEBUG - 2010-07-07 12:55:06 --> User Agent Class Initialized
DEBUG - 2010-07-07 12:55:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:07 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:07 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 12:55:07 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:07 --> Session Class Initialized
DEBUG - 2010-07-07 12:55:07 --> Helper loaded: string_helper
DEBUG - 2010-07-07 12:55:07 --> Session routines successfully run
DEBUG - 2010-07-07 12:55:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:08 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:08 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:08 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:08 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:08 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:08 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:08 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:08 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:08 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:08 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:08 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:08 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:08 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:08 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 12:55:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:09 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:09 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:09 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:09 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:09 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 12:55:09 --> Annotation_scope_collection class already loaded. Second attempt ignored.
ERROR - 2010-07-07 12:55:09 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  relation &quot;annotation2scope&quot; does not exist
LINE 2: FROM &quot;annotation2scope&quot;
             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-07 12:55:09 --> DB Transaction Failure
ERROR - 2010-07-07 12:55:09 --> Query error: ERROR:  relation "annotation2scope" does not exist
LINE 2: FROM "annotation2scope"
             ^
DEBUG - 2010-07-07 12:55:09 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-07-07 13:01:03 --> Config Class Initialized
DEBUG - 2010-07-07 13:01:03 --> Hooks Class Initialized
DEBUG - 2010-07-07 13:01:03 --> URI Class Initialized
DEBUG - 2010-07-07 13:01:03 --> Router Class Initialized
DEBUG - 2010-07-07 13:01:03 --> Output Class Initialized
DEBUG - 2010-07-07 13:01:03 --> Input Class Initialized
DEBUG - 2010-07-07 13:01:04 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 13:01:04 --> Language Class Initialized
DEBUG - 2010-07-07 13:01:04 --> Loader Class Initialized
DEBUG - 2010-07-07 13:01:04 --> Helper loaded: context_helper
DEBUG - 2010-07-07 13:01:04 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 13:01:04 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 13:01:04 --> Database Driver Class Initialized
DEBUG - 2010-07-07 13:01:04 --> Controller Class Initialized
DEBUG - 2010-07-07 13:01:04 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 13:01:04 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 13:01:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:04 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:04 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:04 --> Helper loaded: email_helper
DEBUG - 2010-07-07 13:01:04 --> User Agent Class Initialized
DEBUG - 2010-07-07 13:01:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:04 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:05 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 13:01:05 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:05 --> Session Class Initialized
DEBUG - 2010-07-07 13:01:05 --> Helper loaded: string_helper
DEBUG - 2010-07-07 13:01:05 --> Session routines successfully run
DEBUG - 2010-07-07 13:01:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:06 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:06 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:06 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:06 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:06 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:06 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:06 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:06 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:06 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:06 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:06 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:06 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:06 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:06 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:07 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 13:01:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:07 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:07 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:01:07 --> Annotation_scope_collection class already loaded. Second attempt ignored.
ERROR - 2010-07-07 13:01:07 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;3&quot; does not exist
LINE 4: WHERE &quot;3&quot; IS NULL
              ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-07 13:01:07 --> DB Transaction Failure
ERROR - 2010-07-07 13:01:07 --> Query error: ERROR:  column "3" does not exist
LINE 4: WHERE "3" IS NULL
              ^
DEBUG - 2010-07-07 13:01:07 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-07-07 13:02:15 --> Config Class Initialized
DEBUG - 2010-07-07 13:02:15 --> Hooks Class Initialized
DEBUG - 2010-07-07 13:02:15 --> URI Class Initialized
DEBUG - 2010-07-07 13:02:15 --> Router Class Initialized
DEBUG - 2010-07-07 13:02:15 --> Output Class Initialized
DEBUG - 2010-07-07 13:02:15 --> Input Class Initialized
DEBUG - 2010-07-07 13:02:15 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 13:02:15 --> Language Class Initialized
DEBUG - 2010-07-07 13:02:16 --> Loader Class Initialized
DEBUG - 2010-07-07 13:02:16 --> Helper loaded: context_helper
DEBUG - 2010-07-07 13:02:16 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 13:02:16 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 13:02:16 --> Database Driver Class Initialized
DEBUG - 2010-07-07 13:02:16 --> Controller Class Initialized
DEBUG - 2010-07-07 13:02:16 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 13:02:16 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 13:02:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:16 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:16 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:16 --> Helper loaded: email_helper
DEBUG - 2010-07-07 13:02:16 --> User Agent Class Initialized
DEBUG - 2010-07-07 13:02:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:16 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:16 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 13:02:17 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:17 --> Session Class Initialized
DEBUG - 2010-07-07 13:02:17 --> Helper loaded: string_helper
DEBUG - 2010-07-07 13:02:17 --> Session routines successfully run
DEBUG - 2010-07-07 13:02:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:17 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:17 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:18 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:18 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:18 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:18 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:18 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:18 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:18 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:18 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:18 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:18 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:18 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:18 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:19 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 13:02:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:19 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:19 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:19 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:19 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:19 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:19 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:19 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:02:19 --> Annotation_scope class already loaded. Second attempt ignored.
ERROR - 2010-07-07 13:02:19 --> Severity: Notice  --> Undefined variable: text D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Annotation_scope_collection.php 463
DEBUG - 2010-07-07 13:05:59 --> Config Class Initialized
DEBUG - 2010-07-07 13:05:59 --> Hooks Class Initialized
DEBUG - 2010-07-07 13:05:59 --> URI Class Initialized
DEBUG - 2010-07-07 13:05:59 --> Router Class Initialized
DEBUG - 2010-07-07 13:05:59 --> Output Class Initialized
DEBUG - 2010-07-07 13:06:00 --> Input Class Initialized
DEBUG - 2010-07-07 13:06:00 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 13:06:00 --> Language Class Initialized
DEBUG - 2010-07-07 13:06:00 --> Loader Class Initialized
DEBUG - 2010-07-07 13:06:00 --> Helper loaded: context_helper
DEBUG - 2010-07-07 13:06:00 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 13:06:00 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 13:06:00 --> Database Driver Class Initialized
DEBUG - 2010-07-07 13:06:00 --> Controller Class Initialized
DEBUG - 2010-07-07 13:06:00 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 13:06:00 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 13:06:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:00 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:00 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:00 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:00 --> Helper loaded: email_helper
DEBUG - 2010-07-07 13:06:01 --> User Agent Class Initialized
DEBUG - 2010-07-07 13:06:01 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:01 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:01 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 13:06:01 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:01 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:01 --> Session Class Initialized
DEBUG - 2010-07-07 13:06:01 --> Helper loaded: string_helper
DEBUG - 2010-07-07 13:06:01 --> Session routines successfully run
DEBUG - 2010-07-07 13:06:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:02 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:02 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:02 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:02 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:02 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:02 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:02 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:02 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:03 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:03 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:03 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:03 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:03 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:03 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:03 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:03 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 13:06:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:03 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:03 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:03 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:03 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:03 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:03 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:04 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:04 --> Annotation_scope class already loaded. Second attempt ignored.
ERROR - 2010-07-07 13:06:04 --> Severity: Notice  --> Undefined variable: text D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Annotation_scope_collection.php 463
DEBUG - 2010-07-07 13:06:04 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:04 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:04 --> Segmentor class already loaded. Second attempt ignored.
ERROR - 2010-07-07 13:06:04 --> Severity: Notice  --> Undefined variable: text D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Annotation_scope_collection.php 463
DEBUG - 2010-07-07 13:06:04 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:04 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:04 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:04 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:22 --> Config Class Initialized
DEBUG - 2010-07-07 13:06:22 --> Hooks Class Initialized
DEBUG - 2010-07-07 13:06:22 --> URI Class Initialized
DEBUG - 2010-07-07 13:06:22 --> Router Class Initialized
DEBUG - 2010-07-07 13:06:22 --> Output Class Initialized
DEBUG - 2010-07-07 13:06:22 --> Input Class Initialized
DEBUG - 2010-07-07 13:06:22 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 13:06:22 --> Language Class Initialized
DEBUG - 2010-07-07 13:06:22 --> Loader Class Initialized
DEBUG - 2010-07-07 13:06:22 --> Helper loaded: context_helper
DEBUG - 2010-07-07 13:06:22 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 13:06:22 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 13:06:22 --> Database Driver Class Initialized
DEBUG - 2010-07-07 13:06:23 --> Controller Class Initialized
DEBUG - 2010-07-07 13:06:23 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 13:06:23 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 13:06:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:23 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:23 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:23 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:23 --> Helper loaded: email_helper
DEBUG - 2010-07-07 13:06:23 --> User Agent Class Initialized
DEBUG - 2010-07-07 13:06:23 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:23 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:23 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 13:06:23 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:23 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:23 --> Session Class Initialized
DEBUG - 2010-07-07 13:06:24 --> Helper loaded: string_helper
DEBUG - 2010-07-07 13:06:24 --> Session routines successfully run
DEBUG - 2010-07-07 13:06:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:24 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:24 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:24 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:25 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:25 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:25 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:25 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:25 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:25 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:25 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:25 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:25 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:25 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:25 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 13:06:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:26 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:26 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:26 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:26 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:26 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:26 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:26 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:26 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:26 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:26 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:26 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:26 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:26 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:06:26 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:06 --> Config Class Initialized
DEBUG - 2010-07-07 13:08:06 --> Hooks Class Initialized
DEBUG - 2010-07-07 13:08:07 --> URI Class Initialized
DEBUG - 2010-07-07 13:08:07 --> Router Class Initialized
DEBUG - 2010-07-07 13:08:07 --> Output Class Initialized
DEBUG - 2010-07-07 13:08:07 --> Input Class Initialized
DEBUG - 2010-07-07 13:08:07 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 13:08:07 --> Language Class Initialized
DEBUG - 2010-07-07 13:08:07 --> Loader Class Initialized
DEBUG - 2010-07-07 13:08:07 --> Helper loaded: context_helper
DEBUG - 2010-07-07 13:08:07 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 13:08:07 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 13:08:07 --> Database Driver Class Initialized
DEBUG - 2010-07-07 13:08:07 --> Controller Class Initialized
DEBUG - 2010-07-07 13:08:07 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 13:08:07 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 13:08:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:08 --> Helper loaded: email_helper
DEBUG - 2010-07-07 13:08:08 --> User Agent Class Initialized
DEBUG - 2010-07-07 13:08:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:08 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:08 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 13:08:08 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:08 --> Session Class Initialized
DEBUG - 2010-07-07 13:08:08 --> Helper loaded: string_helper
DEBUG - 2010-07-07 13:08:08 --> Session routines successfully run
DEBUG - 2010-07-07 13:08:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:09 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:09 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:09 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:09 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:09 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:09 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:09 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:10 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:10 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:10 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:10 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:10 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:10 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:10 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:10 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:10 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 13:08:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:10 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:10 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:10 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:10 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:11 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:11 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 13:08:11 --> Final output sent to browser
DEBUG - 2010-07-07 13:08:11 --> Total execution time: 4.3295
DEBUG - 2010-07-07 13:08:50 --> Config Class Initialized
DEBUG - 2010-07-07 13:08:50 --> Hooks Class Initialized
DEBUG - 2010-07-07 13:08:50 --> URI Class Initialized
DEBUG - 2010-07-07 13:08:50 --> Router Class Initialized
DEBUG - 2010-07-07 13:08:50 --> Output Class Initialized
DEBUG - 2010-07-07 13:08:50 --> Input Class Initialized
DEBUG - 2010-07-07 13:08:50 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 13:08:50 --> Language Class Initialized
DEBUG - 2010-07-07 13:08:50 --> Loader Class Initialized
DEBUG - 2010-07-07 13:08:50 --> Helper loaded: context_helper
DEBUG - 2010-07-07 13:08:50 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 13:08:50 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 13:08:50 --> Database Driver Class Initialized
DEBUG - 2010-07-07 13:08:50 --> Controller Class Initialized
DEBUG - 2010-07-07 13:08:50 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 13:08:50 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 13:08:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:51 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:51 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:51 --> Helper loaded: email_helper
DEBUG - 2010-07-07 13:08:51 --> User Agent Class Initialized
DEBUG - 2010-07-07 13:08:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:51 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:51 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 13:08:51 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:51 --> Session Class Initialized
DEBUG - 2010-07-07 13:08:51 --> Helper loaded: string_helper
DEBUG - 2010-07-07 13:08:52 --> Session routines successfully run
DEBUG - 2010-07-07 13:08:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:52 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:52 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:52 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:52 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:53 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:53 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:53 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:53 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:53 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:53 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:53 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:53 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:53 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:53 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:53 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:53 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 13:08:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:54 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:54 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:54 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:54 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:54 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:54 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:54 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:54 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:54 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:54 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:54 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:54 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:54 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:54 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:08:54 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 13:08:54 --> Final output sent to browser
DEBUG - 2010-07-07 13:08:55 --> Total execution time: 4.8711
DEBUG - 2010-07-07 13:10:30 --> Config Class Initialized
DEBUG - 2010-07-07 13:10:30 --> Hooks Class Initialized
DEBUG - 2010-07-07 13:10:30 --> URI Class Initialized
DEBUG - 2010-07-07 13:10:30 --> Router Class Initialized
DEBUG - 2010-07-07 13:10:30 --> Output Class Initialized
DEBUG - 2010-07-07 13:10:30 --> Input Class Initialized
DEBUG - 2010-07-07 13:10:30 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 13:10:30 --> Language Class Initialized
DEBUG - 2010-07-07 13:10:31 --> Loader Class Initialized
DEBUG - 2010-07-07 13:10:31 --> Helper loaded: context_helper
DEBUG - 2010-07-07 13:10:31 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 13:10:31 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 13:10:31 --> Database Driver Class Initialized
DEBUG - 2010-07-07 13:10:31 --> Controller Class Initialized
DEBUG - 2010-07-07 13:10:31 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 13:10:31 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 13:10:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:31 --> Helper loaded: email_helper
DEBUG - 2010-07-07 13:10:31 --> User Agent Class Initialized
DEBUG - 2010-07-07 13:10:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:32 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:32 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 13:10:32 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:32 --> Session Class Initialized
DEBUG - 2010-07-07 13:10:32 --> Helper loaded: string_helper
DEBUG - 2010-07-07 13:10:32 --> Session routines successfully run
DEBUG - 2010-07-07 13:10:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:33 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:33 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:33 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:33 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:33 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:33 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:33 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:33 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:33 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:34 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:34 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:34 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:34 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:34 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:34 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 13:10:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:34 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:34 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:34 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:34 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:35 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:35 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:35 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:35 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:35 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:35 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:35 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:35 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:35 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:10:35 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 13:10:35 --> Final output sent to browser
DEBUG - 2010-07-07 13:10:35 --> Total execution time: 5.0634
DEBUG - 2010-07-07 13:11:33 --> Config Class Initialized
DEBUG - 2010-07-07 13:11:33 --> Hooks Class Initialized
DEBUG - 2010-07-07 13:11:33 --> URI Class Initialized
DEBUG - 2010-07-07 13:11:33 --> Router Class Initialized
DEBUG - 2010-07-07 13:11:33 --> Output Class Initialized
DEBUG - 2010-07-07 13:11:33 --> Input Class Initialized
DEBUG - 2010-07-07 13:11:33 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 13:11:33 --> Language Class Initialized
DEBUG - 2010-07-07 13:11:33 --> Loader Class Initialized
DEBUG - 2010-07-07 13:11:34 --> Helper loaded: context_helper
DEBUG - 2010-07-07 13:11:34 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 13:11:34 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 13:11:34 --> Database Driver Class Initialized
DEBUG - 2010-07-07 13:11:34 --> Controller Class Initialized
DEBUG - 2010-07-07 13:11:34 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 13:11:34 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 13:11:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:34 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:34 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:34 --> Helper loaded: email_helper
DEBUG - 2010-07-07 13:11:34 --> User Agent Class Initialized
DEBUG - 2010-07-07 13:11:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:35 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:35 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 13:11:35 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:35 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:36 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:36 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:37 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:37 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:37 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:37 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:37 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:37 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:37 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:11:37 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:02 --> Config Class Initialized
DEBUG - 2010-07-07 13:13:02 --> Hooks Class Initialized
DEBUG - 2010-07-07 13:13:02 --> URI Class Initialized
DEBUG - 2010-07-07 13:13:02 --> Router Class Initialized
DEBUG - 2010-07-07 13:13:02 --> Output Class Initialized
DEBUG - 2010-07-07 13:13:02 --> Input Class Initialized
DEBUG - 2010-07-07 13:13:02 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 13:13:03 --> Language Class Initialized
DEBUG - 2010-07-07 13:13:03 --> Loader Class Initialized
DEBUG - 2010-07-07 13:13:03 --> Helper loaded: context_helper
DEBUG - 2010-07-07 13:13:03 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 13:13:03 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 13:13:03 --> Database Driver Class Initialized
DEBUG - 2010-07-07 13:13:03 --> Controller Class Initialized
DEBUG - 2010-07-07 13:13:03 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 13:13:03 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 13:13:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:03 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:03 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:03 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:03 --> Helper loaded: email_helper
DEBUG - 2010-07-07 13:13:04 --> User Agent Class Initialized
DEBUG - 2010-07-07 13:13:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:04 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:04 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 13:13:04 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:04 --> Session Class Initialized
DEBUG - 2010-07-07 13:13:04 --> Helper loaded: string_helper
DEBUG - 2010-07-07 13:13:04 --> Session routines successfully run
DEBUG - 2010-07-07 13:13:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:04 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:04 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:05 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:05 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:05 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:05 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:05 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:05 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:05 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:05 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:05 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:05 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:05 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 13:13:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:06 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:06 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:06 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:06 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:06 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:06 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:06 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:06 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:06 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:06 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:06 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:06 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:06 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:13:07 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 13:13:07 --> Final output sent to browser
DEBUG - 2010-07-07 13:13:07 --> Total execution time: 4.5515
DEBUG - 2010-07-07 13:14:59 --> Config Class Initialized
DEBUG - 2010-07-07 13:14:59 --> Hooks Class Initialized
DEBUG - 2010-07-07 13:14:59 --> URI Class Initialized
DEBUG - 2010-07-07 13:14:59 --> Router Class Initialized
DEBUG - 2010-07-07 13:14:59 --> Output Class Initialized
DEBUG - 2010-07-07 13:14:59 --> Input Class Initialized
DEBUG - 2010-07-07 13:14:59 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 13:15:00 --> Language Class Initialized
DEBUG - 2010-07-07 13:15:00 --> Loader Class Initialized
DEBUG - 2010-07-07 13:15:00 --> Helper loaded: context_helper
DEBUG - 2010-07-07 13:15:00 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 13:15:00 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 13:15:00 --> Database Driver Class Initialized
DEBUG - 2010-07-07 13:15:00 --> Controller Class Initialized
DEBUG - 2010-07-07 13:15:00 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 13:15:00 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 13:15:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:00 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:00 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:00 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:00 --> Helper loaded: email_helper
DEBUG - 2010-07-07 13:15:01 --> User Agent Class Initialized
DEBUG - 2010-07-07 13:15:01 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:01 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:01 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 13:15:01 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:01 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:01 --> Session Class Initialized
DEBUG - 2010-07-07 13:15:01 --> Helper loaded: string_helper
DEBUG - 2010-07-07 13:15:01 --> Session routines successfully run
DEBUG - 2010-07-07 13:15:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:01 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:02 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:02 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:02 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:02 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:02 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:02 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:02 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:02 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:02 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:02 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:02 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:02 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:02 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:02 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:03 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 13:15:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:03 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:03 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:03 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:03 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:03 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:03 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:03 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:03 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:03 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:03 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:04 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:04 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:04 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:04 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:15:04 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 13:15:04 --> Final output sent to browser
DEBUG - 2010-07-07 13:15:04 --> Total execution time: 4.7972
DEBUG - 2010-07-07 13:16:21 --> Config Class Initialized
DEBUG - 2010-07-07 13:16:21 --> Hooks Class Initialized
DEBUG - 2010-07-07 13:16:21 --> URI Class Initialized
DEBUG - 2010-07-07 13:16:21 --> Router Class Initialized
DEBUG - 2010-07-07 13:16:21 --> Output Class Initialized
DEBUG - 2010-07-07 13:16:21 --> Input Class Initialized
DEBUG - 2010-07-07 13:16:21 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 13:16:21 --> Language Class Initialized
DEBUG - 2010-07-07 13:16:21 --> Loader Class Initialized
DEBUG - 2010-07-07 13:16:21 --> Helper loaded: context_helper
DEBUG - 2010-07-07 13:16:21 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 13:16:21 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 13:16:22 --> Database Driver Class Initialized
DEBUG - 2010-07-07 13:16:22 --> Controller Class Initialized
DEBUG - 2010-07-07 13:16:22 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 13:16:22 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 13:16:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:22 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:22 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:22 --> Helper loaded: email_helper
DEBUG - 2010-07-07 13:16:22 --> User Agent Class Initialized
DEBUG - 2010-07-07 13:16:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:22 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:23 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 13:16:23 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:23 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:23 --> Session Class Initialized
DEBUG - 2010-07-07 13:16:23 --> Helper loaded: string_helper
DEBUG - 2010-07-07 13:16:23 --> Session routines successfully run
DEBUG - 2010-07-07 13:16:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:23 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:23 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:23 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:24 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:24 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:24 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:24 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:24 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:24 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:24 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:24 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:24 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:24 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:24 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 13:16:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:24 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:25 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:25 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:25 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:25 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:25 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:25 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:25 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:25 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:25 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:25 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:25 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:25 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:25 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 13:16:26 --> Final output sent to browser
DEBUG - 2010-07-07 13:16:26 --> Total execution time: 4.8387
DEBUG - 2010-07-07 13:16:35 --> Config Class Initialized
DEBUG - 2010-07-07 13:16:35 --> Hooks Class Initialized
DEBUG - 2010-07-07 13:16:35 --> URI Class Initialized
DEBUG - 2010-07-07 13:16:35 --> Router Class Initialized
DEBUG - 2010-07-07 13:16:35 --> Output Class Initialized
DEBUG - 2010-07-07 13:16:35 --> Input Class Initialized
DEBUG - 2010-07-07 13:16:35 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 13:16:35 --> Language Class Initialized
DEBUG - 2010-07-07 13:16:36 --> Loader Class Initialized
DEBUG - 2010-07-07 13:16:36 --> Helper loaded: context_helper
DEBUG - 2010-07-07 13:16:36 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 13:16:36 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 13:16:36 --> Database Driver Class Initialized
DEBUG - 2010-07-07 13:16:36 --> Controller Class Initialized
DEBUG - 2010-07-07 13:16:36 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 13:16:36 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 13:16:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:36 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:36 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:36 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:37 --> Helper loaded: email_helper
DEBUG - 2010-07-07 13:16:37 --> User Agent Class Initialized
DEBUG - 2010-07-07 13:16:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:37 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:37 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 13:16:37 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:37 --> Session Class Initialized
DEBUG - 2010-07-07 13:16:37 --> Helper loaded: string_helper
DEBUG - 2010-07-07 13:16:37 --> Session routines successfully run
DEBUG - 2010-07-07 13:16:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:38 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:38 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:38 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:38 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:38 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:38 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:38 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:38 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:38 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:38 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:38 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:38 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:38 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:38 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:39 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:39 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 13:16:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:39 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:39 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:39 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:39 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:39 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:39 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:40 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:40 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:40 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:40 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:40 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:40 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:16:40 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 13:16:40 --> Final output sent to browser
DEBUG - 2010-07-07 13:16:40 --> Total execution time: 4.9702
DEBUG - 2010-07-07 13:17:19 --> Config Class Initialized
DEBUG - 2010-07-07 13:17:19 --> Hooks Class Initialized
DEBUG - 2010-07-07 13:17:20 --> URI Class Initialized
DEBUG - 2010-07-07 13:17:20 --> Router Class Initialized
DEBUG - 2010-07-07 13:17:20 --> Output Class Initialized
DEBUG - 2010-07-07 13:17:20 --> Input Class Initialized
DEBUG - 2010-07-07 13:17:20 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 13:17:20 --> Language Class Initialized
DEBUG - 2010-07-07 13:17:20 --> Loader Class Initialized
DEBUG - 2010-07-07 13:17:20 --> Helper loaded: context_helper
DEBUG - 2010-07-07 13:17:20 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 13:17:20 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 13:17:20 --> Database Driver Class Initialized
DEBUG - 2010-07-07 13:17:20 --> Controller Class Initialized
DEBUG - 2010-07-07 13:17:20 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 13:17:20 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 13:17:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:21 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:21 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:21 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:21 --> Helper loaded: email_helper
DEBUG - 2010-07-07 13:17:21 --> User Agent Class Initialized
DEBUG - 2010-07-07 13:17:21 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:21 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:21 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 13:17:21 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:22 --> Session Class Initialized
DEBUG - 2010-07-07 13:17:22 --> Helper loaded: string_helper
DEBUG - 2010-07-07 13:17:22 --> Session routines successfully run
DEBUG - 2010-07-07 13:17:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:22 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:22 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:22 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:22 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:22 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:22 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:22 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:22 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:23 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:23 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:23 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:23 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:23 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:23 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:23 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:23 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:23 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:23 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 13:17:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:23 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:24 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:24 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:24 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:24 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:24 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:24 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:24 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:24 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:24 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:24 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:24 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:24 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:25 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:25 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:25 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:25 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:25 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:25 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:25 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:25 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:25 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:25 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:25 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:17:25 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 13:17:25 --> Final output sent to browser
DEBUG - 2010-07-07 13:17:25 --> Total execution time: 5.9498
DEBUG - 2010-07-07 13:18:02 --> Config Class Initialized
DEBUG - 2010-07-07 13:18:02 --> Hooks Class Initialized
DEBUG - 2010-07-07 13:18:02 --> URI Class Initialized
DEBUG - 2010-07-07 13:18:02 --> Router Class Initialized
DEBUG - 2010-07-07 13:18:02 --> Output Class Initialized
DEBUG - 2010-07-07 13:18:02 --> Input Class Initialized
DEBUG - 2010-07-07 13:18:02 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 13:18:02 --> Language Class Initialized
DEBUG - 2010-07-07 13:18:02 --> Loader Class Initialized
DEBUG - 2010-07-07 13:18:03 --> Helper loaded: context_helper
DEBUG - 2010-07-07 13:18:03 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 13:18:03 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 13:18:03 --> Database Driver Class Initialized
DEBUG - 2010-07-07 13:18:03 --> Controller Class Initialized
DEBUG - 2010-07-07 13:18:03 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 13:18:03 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 13:18:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:03 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:03 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:03 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:03 --> Helper loaded: email_helper
DEBUG - 2010-07-07 13:18:04 --> User Agent Class Initialized
DEBUG - 2010-07-07 13:18:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:04 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:04 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 13:18:04 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:04 --> Session Class Initialized
DEBUG - 2010-07-07 13:18:04 --> Helper loaded: string_helper
DEBUG - 2010-07-07 13:18:04 --> Session routines successfully run
DEBUG - 2010-07-07 13:18:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:05 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:05 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:05 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:05 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:05 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:05 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:05 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:05 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:05 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:05 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:05 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:06 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:06 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:06 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:06 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:06 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 13:18:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:06 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:06 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:06 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:06 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:07 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:07 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:07 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:07 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:07 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:07 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:07 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:07 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:07 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:07 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:07 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:07 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:07 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:07 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:08 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:08 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:08 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:08 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:08 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:08 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:27 --> Config Class Initialized
DEBUG - 2010-07-07 13:18:27 --> Hooks Class Initialized
DEBUG - 2010-07-07 13:18:27 --> URI Class Initialized
DEBUG - 2010-07-07 13:18:27 --> Router Class Initialized
DEBUG - 2010-07-07 13:18:27 --> Output Class Initialized
DEBUG - 2010-07-07 13:18:27 --> Input Class Initialized
DEBUG - 2010-07-07 13:18:27 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 13:18:27 --> Language Class Initialized
DEBUG - 2010-07-07 13:18:27 --> Loader Class Initialized
DEBUG - 2010-07-07 13:18:27 --> Helper loaded: context_helper
DEBUG - 2010-07-07 13:18:27 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 13:18:28 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 13:18:28 --> Database Driver Class Initialized
DEBUG - 2010-07-07 13:18:28 --> Controller Class Initialized
DEBUG - 2010-07-07 13:18:28 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 13:18:28 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 13:18:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:28 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:28 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:28 --> Helper loaded: email_helper
DEBUG - 2010-07-07 13:18:28 --> User Agent Class Initialized
DEBUG - 2010-07-07 13:18:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:29 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:29 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 13:18:29 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:29 --> Session Class Initialized
DEBUG - 2010-07-07 13:18:29 --> Helper loaded: string_helper
DEBUG - 2010-07-07 13:18:29 --> Session routines successfully run
DEBUG - 2010-07-07 13:18:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:29 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:30 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:30 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:30 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:30 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:30 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:30 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:30 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:30 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:30 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:30 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:31 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:31 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:31 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:31 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:31 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 13:18:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:31 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:31 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:31 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:32 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:32 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:32 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:32 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:32 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:32 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:32 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:32 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:32 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:32 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:32 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:32 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:32 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:33 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:33 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:33 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:33 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:33 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:33 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:18:33 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:29 --> Config Class Initialized
DEBUG - 2010-07-07 13:20:29 --> Hooks Class Initialized
DEBUG - 2010-07-07 13:20:29 --> URI Class Initialized
DEBUG - 2010-07-07 13:20:29 --> Router Class Initialized
DEBUG - 2010-07-07 13:20:29 --> Output Class Initialized
DEBUG - 2010-07-07 13:20:29 --> Input Class Initialized
DEBUG - 2010-07-07 13:20:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 13:20:30 --> Language Class Initialized
DEBUG - 2010-07-07 13:20:30 --> Loader Class Initialized
DEBUG - 2010-07-07 13:20:30 --> Helper loaded: context_helper
DEBUG - 2010-07-07 13:20:30 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 13:20:30 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 13:20:30 --> Database Driver Class Initialized
DEBUG - 2010-07-07 13:20:30 --> Controller Class Initialized
DEBUG - 2010-07-07 13:20:30 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 13:20:30 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 13:20:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:31 --> Helper loaded: email_helper
DEBUG - 2010-07-07 13:20:31 --> User Agent Class Initialized
DEBUG - 2010-07-07 13:20:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:31 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:31 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 13:20:31 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:32 --> Session Class Initialized
DEBUG - 2010-07-07 13:20:32 --> Helper loaded: string_helper
DEBUG - 2010-07-07 13:20:32 --> Session routines successfully run
DEBUG - 2010-07-07 13:20:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:32 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:32 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:32 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:32 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:32 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:32 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:33 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:33 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:33 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:33 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:33 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:33 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:33 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:33 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:33 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:33 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:33 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:34 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 13:20:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:34 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:34 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:34 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:34 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:34 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:34 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:34 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:34 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:35 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:35 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:35 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:35 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:35 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:35 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:35 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:35 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:35 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:35 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:35 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:35 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:35 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:20:36 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:21 --> Config Class Initialized
DEBUG - 2010-07-07 13:21:21 --> Hooks Class Initialized
DEBUG - 2010-07-07 13:21:21 --> URI Class Initialized
DEBUG - 2010-07-07 13:21:21 --> Router Class Initialized
DEBUG - 2010-07-07 13:21:21 --> Output Class Initialized
DEBUG - 2010-07-07 13:21:21 --> Input Class Initialized
DEBUG - 2010-07-07 13:21:21 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 13:21:21 --> Language Class Initialized
DEBUG - 2010-07-07 13:21:21 --> Loader Class Initialized
DEBUG - 2010-07-07 13:21:22 --> Helper loaded: context_helper
DEBUG - 2010-07-07 13:21:22 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 13:21:22 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 13:21:22 --> Database Driver Class Initialized
DEBUG - 2010-07-07 13:21:22 --> Controller Class Initialized
DEBUG - 2010-07-07 13:21:22 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 13:21:22 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 13:21:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:22 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:22 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:23 --> Helper loaded: email_helper
DEBUG - 2010-07-07 13:21:23 --> User Agent Class Initialized
DEBUG - 2010-07-07 13:21:23 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:23 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:23 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 13:21:23 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:23 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:23 --> Session Class Initialized
DEBUG - 2010-07-07 13:21:23 --> Helper loaded: string_helper
DEBUG - 2010-07-07 13:21:23 --> Session routines successfully run
DEBUG - 2010-07-07 13:21:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:24 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:24 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:24 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:24 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:24 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:24 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:24 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:24 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:24 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:24 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:25 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:25 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:25 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:25 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:25 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:25 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 13:21:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:26 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:26 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:26 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:26 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:26 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:26 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:26 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:26 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:26 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:26 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:26 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:27 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:27 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:27 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:27 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:27 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:27 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:27 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:27 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:27 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:27 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:27 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:27 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:55 --> Config Class Initialized
DEBUG - 2010-07-07 13:21:55 --> Hooks Class Initialized
DEBUG - 2010-07-07 13:21:55 --> URI Class Initialized
DEBUG - 2010-07-07 13:21:55 --> Router Class Initialized
DEBUG - 2010-07-07 13:21:55 --> Output Class Initialized
DEBUG - 2010-07-07 13:21:55 --> Input Class Initialized
DEBUG - 2010-07-07 13:21:55 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 13:21:55 --> Language Class Initialized
DEBUG - 2010-07-07 13:21:55 --> Loader Class Initialized
DEBUG - 2010-07-07 13:21:55 --> Helper loaded: context_helper
DEBUG - 2010-07-07 13:21:55 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 13:21:56 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 13:21:56 --> Database Driver Class Initialized
DEBUG - 2010-07-07 13:21:56 --> Controller Class Initialized
DEBUG - 2010-07-07 13:21:56 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 13:21:56 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 13:21:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:57 --> Helper loaded: email_helper
DEBUG - 2010-07-07 13:21:57 --> User Agent Class Initialized
DEBUG - 2010-07-07 13:21:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:57 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:57 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 13:21:57 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:57 --> Session Class Initialized
DEBUG - 2010-07-07 13:21:57 --> Helper loaded: string_helper
DEBUG - 2010-07-07 13:21:58 --> Session routines successfully run
DEBUG - 2010-07-07 13:21:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:58 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:58 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:58 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:58 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:58 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:58 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:58 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:58 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:59 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:59 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:59 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:59 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:59 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:59 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:59 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:21:59 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 13:21:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:22:00 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:22:00 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:22:00 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:22:00 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:22:00 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:22:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:22:00 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:22:00 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:22:00 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:22:00 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:22:00 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:22:01 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:22:01 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:22:01 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:22:01 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:22:01 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:22:01 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:22:01 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:22:01 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:22:01 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:22:01 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:22:01 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:22:01 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:22:01 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:22:02 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:22:02 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:22:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:22:02 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:22:02 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:22:02 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:22:02 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 13:22:02 --> Final output sent to browser
DEBUG - 2010-07-07 13:22:02 --> Total execution time: 7.5448
DEBUG - 2010-07-07 13:25:49 --> Config Class Initialized
DEBUG - 2010-07-07 13:25:49 --> Hooks Class Initialized
DEBUG - 2010-07-07 13:25:49 --> URI Class Initialized
DEBUG - 2010-07-07 13:25:49 --> Router Class Initialized
DEBUG - 2010-07-07 13:25:49 --> Output Class Initialized
DEBUG - 2010-07-07 13:25:49 --> Input Class Initialized
DEBUG - 2010-07-07 13:25:49 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 13:25:49 --> Language Class Initialized
DEBUG - 2010-07-07 13:25:49 --> Loader Class Initialized
DEBUG - 2010-07-07 13:25:49 --> Helper loaded: context_helper
DEBUG - 2010-07-07 13:25:50 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 13:25:50 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 13:25:50 --> Database Driver Class Initialized
DEBUG - 2010-07-07 13:25:50 --> Controller Class Initialized
DEBUG - 2010-07-07 13:25:50 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 13:25:50 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 13:25:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:50 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:50 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:51 --> Helper loaded: email_helper
DEBUG - 2010-07-07 13:25:51 --> User Agent Class Initialized
DEBUG - 2010-07-07 13:25:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:51 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:51 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 13:25:51 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:51 --> Session Class Initialized
DEBUG - 2010-07-07 13:25:51 --> Helper loaded: string_helper
DEBUG - 2010-07-07 13:25:52 --> Session routines successfully run
DEBUG - 2010-07-07 13:25:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:52 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:52 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:52 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:52 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:52 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:52 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:52 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:52 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:53 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:53 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:53 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:53 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:53 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:53 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:53 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:53 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:53 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:53 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 13:25:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:54 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:54 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:54 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:54 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:54 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:54 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:54 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:54 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:54 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:55 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:55 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:55 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:55 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:55 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:55 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:55 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:55 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:55 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:55 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:55 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:55 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:56 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:56 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:56 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:56 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:56 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:56 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:56 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:25:57 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 13:25:57 --> Final output sent to browser
DEBUG - 2010-07-07 13:25:57 --> Total execution time: 8.0014
DEBUG - 2010-07-07 13:26:11 --> Config Class Initialized
DEBUG - 2010-07-07 13:26:11 --> Hooks Class Initialized
DEBUG - 2010-07-07 13:26:11 --> URI Class Initialized
DEBUG - 2010-07-07 13:26:11 --> Router Class Initialized
DEBUG - 2010-07-07 13:26:12 --> Output Class Initialized
DEBUG - 2010-07-07 13:26:12 --> Input Class Initialized
DEBUG - 2010-07-07 13:26:12 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 13:26:12 --> Language Class Initialized
DEBUG - 2010-07-07 13:26:12 --> Loader Class Initialized
DEBUG - 2010-07-07 13:26:12 --> Helper loaded: context_helper
DEBUG - 2010-07-07 13:26:12 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 13:26:12 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 13:26:12 --> Database Driver Class Initialized
DEBUG - 2010-07-07 13:26:12 --> Controller Class Initialized
DEBUG - 2010-07-07 13:26:12 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 13:26:12 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 13:26:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:13 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:13 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:13 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:13 --> Helper loaded: email_helper
DEBUG - 2010-07-07 13:26:13 --> User Agent Class Initialized
DEBUG - 2010-07-07 13:26:13 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:13 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:14 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 13:26:14 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:14 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:14 --> Session Class Initialized
DEBUG - 2010-07-07 13:26:14 --> Helper loaded: string_helper
DEBUG - 2010-07-07 13:26:14 --> Session routines successfully run
DEBUG - 2010-07-07 13:26:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:15 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:15 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:15 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:15 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:15 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:15 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:15 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:15 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:15 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:16 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:16 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:16 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:16 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:16 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:16 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:16 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:16 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 13:26:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:17 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:17 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:17 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:17 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:17 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:17 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:17 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:18 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:18 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:18 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:18 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:18 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:18 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:18 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:18 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:18 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:18 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:18 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:19 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:19 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:19 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:19 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:19 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:19 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:19 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:19 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:19 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:19 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:20 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:26:20 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 13:26:20 --> Final output sent to browser
DEBUG - 2010-07-07 13:26:20 --> Total execution time: 8.6850
DEBUG - 2010-07-07 13:28:28 --> Config Class Initialized
DEBUG - 2010-07-07 13:28:29 --> Hooks Class Initialized
DEBUG - 2010-07-07 13:28:29 --> URI Class Initialized
DEBUG - 2010-07-07 13:28:29 --> Router Class Initialized
DEBUG - 2010-07-07 13:28:29 --> Output Class Initialized
DEBUG - 2010-07-07 13:28:29 --> Input Class Initialized
DEBUG - 2010-07-07 13:28:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 13:28:29 --> Language Class Initialized
DEBUG - 2010-07-07 13:28:29 --> Loader Class Initialized
DEBUG - 2010-07-07 13:28:29 --> Helper loaded: context_helper
DEBUG - 2010-07-07 13:28:29 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 13:28:29 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 13:28:30 --> Database Driver Class Initialized
DEBUG - 2010-07-07 13:28:30 --> Controller Class Initialized
DEBUG - 2010-07-07 13:28:30 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 13:28:30 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 13:28:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:30 --> Helper loaded: email_helper
DEBUG - 2010-07-07 13:28:31 --> User Agent Class Initialized
DEBUG - 2010-07-07 13:28:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:31 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:31 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 13:28:31 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:31 --> Session Class Initialized
DEBUG - 2010-07-07 13:28:31 --> Helper loaded: string_helper
DEBUG - 2010-07-07 13:28:31 --> Session routines successfully run
DEBUG - 2010-07-07 13:28:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:32 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:32 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:32 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:32 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:32 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:32 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:32 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:32 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:33 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:33 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:33 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:33 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:33 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:33 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:33 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:33 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:33 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:34 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 13:28:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:34 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:34 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:34 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:34 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:34 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:35 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:35 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:35 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:35 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:35 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:35 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:35 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:35 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:35 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:35 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:35 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:35 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:36 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:36 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:36 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:36 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:37 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:37 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 13:28:37 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 13:28:37 --> Final output sent to browser
DEBUG - 2010-07-07 13:28:37 --> Total execution time: 8.4865
DEBUG - 2010-07-07 14:02:02 --> Config Class Initialized
DEBUG - 2010-07-07 14:02:02 --> Hooks Class Initialized
DEBUG - 2010-07-07 14:02:03 --> URI Class Initialized
DEBUG - 2010-07-07 14:02:03 --> Router Class Initialized
DEBUG - 2010-07-07 14:02:03 --> Output Class Initialized
DEBUG - 2010-07-07 14:02:03 --> Input Class Initialized
DEBUG - 2010-07-07 14:02:03 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 14:02:03 --> Language Class Initialized
DEBUG - 2010-07-07 14:02:03 --> Loader Class Initialized
DEBUG - 2010-07-07 14:02:03 --> Helper loaded: context_helper
DEBUG - 2010-07-07 14:02:03 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 14:02:03 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 14:02:04 --> Database Driver Class Initialized
DEBUG - 2010-07-07 14:02:04 --> Controller Class Initialized
DEBUG - 2010-07-07 14:02:04 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 14:02:04 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 14:02:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:04 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:04 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:05 --> Helper loaded: email_helper
DEBUG - 2010-07-07 14:02:05 --> User Agent Class Initialized
DEBUG - 2010-07-07 14:02:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:05 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:05 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 14:02:05 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:05 --> Session Class Initialized
DEBUG - 2010-07-07 14:02:06 --> Helper loaded: string_helper
DEBUG - 2010-07-07 14:02:06 --> Session routines successfully run
DEBUG - 2010-07-07 14:02:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:06 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:06 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:06 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:06 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:06 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:07 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:07 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:07 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:07 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:07 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:07 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:08 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:08 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:08 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:08 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 14:02:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:08 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:08 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:09 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:09 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:09 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:09 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:09 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:09 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:09 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:09 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:09 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:10 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:10 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:10 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:10 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:10 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:10 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:10 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:10 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:10 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:11 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:11 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:11 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:11 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:11 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:11 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:11 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:11 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:11 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:12 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:12 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:12 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:12 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:12 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:12 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:12 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:12 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:12 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:12 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:12 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:13 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:26 --> Config Class Initialized
DEBUG - 2010-07-07 14:02:26 --> Hooks Class Initialized
DEBUG - 2010-07-07 14:02:26 --> URI Class Initialized
DEBUG - 2010-07-07 14:02:26 --> Router Class Initialized
DEBUG - 2010-07-07 14:02:26 --> Output Class Initialized
DEBUG - 2010-07-07 14:02:26 --> Input Class Initialized
DEBUG - 2010-07-07 14:02:26 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 14:02:27 --> Language Class Initialized
DEBUG - 2010-07-07 14:02:27 --> Loader Class Initialized
DEBUG - 2010-07-07 14:02:27 --> Helper loaded: context_helper
DEBUG - 2010-07-07 14:02:27 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 14:02:27 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 14:02:27 --> Database Driver Class Initialized
DEBUG - 2010-07-07 14:02:27 --> Controller Class Initialized
DEBUG - 2010-07-07 14:02:27 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 14:02:27 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 14:02:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:28 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:28 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:28 --> Helper loaded: email_helper
DEBUG - 2010-07-07 14:02:28 --> User Agent Class Initialized
DEBUG - 2010-07-07 14:02:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:28 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:28 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 14:02:29 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:29 --> Session Class Initialized
DEBUG - 2010-07-07 14:02:29 --> Helper loaded: string_helper
DEBUG - 2010-07-07 14:02:29 --> Session routines successfully run
DEBUG - 2010-07-07 14:02:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:29 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:30 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:30 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:30 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:30 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:30 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:30 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:30 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:30 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:30 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:31 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:31 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:31 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:31 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:31 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:31 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 14:02:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:32 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:32 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:32 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:32 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:32 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:32 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:33 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:33 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:33 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:33 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:33 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:33 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:33 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:33 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:33 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:33 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:34 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:34 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:34 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:34 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:34 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:34 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:34 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:34 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:35 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:35 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:35 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:35 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:35 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:35 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:35 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:35 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:35 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:36 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:36 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:36 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:02:36 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 14:02:36 --> Final output sent to browser
DEBUG - 2010-07-07 14:02:37 --> Total execution time: 10.5820
DEBUG - 2010-07-07 14:08:27 --> Config Class Initialized
DEBUG - 2010-07-07 14:08:27 --> Hooks Class Initialized
DEBUG - 2010-07-07 14:08:27 --> URI Class Initialized
DEBUG - 2010-07-07 14:08:28 --> Router Class Initialized
DEBUG - 2010-07-07 14:08:28 --> Output Class Initialized
DEBUG - 2010-07-07 14:08:28 --> Input Class Initialized
DEBUG - 2010-07-07 14:08:28 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 14:08:28 --> Language Class Initialized
DEBUG - 2010-07-07 14:08:28 --> Loader Class Initialized
DEBUG - 2010-07-07 14:08:28 --> Helper loaded: context_helper
DEBUG - 2010-07-07 14:08:28 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 14:08:29 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 14:08:29 --> Database Driver Class Initialized
DEBUG - 2010-07-07 14:08:29 --> Controller Class Initialized
DEBUG - 2010-07-07 14:08:29 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 14:08:29 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 14:08:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:29 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:30 --> Helper loaded: email_helper
DEBUG - 2010-07-07 14:08:30 --> User Agent Class Initialized
DEBUG - 2010-07-07 14:08:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:30 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:30 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 14:08:31 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:31 --> Session Class Initialized
DEBUG - 2010-07-07 14:08:31 --> Helper loaded: string_helper
DEBUG - 2010-07-07 14:08:31 --> Session routines successfully run
DEBUG - 2010-07-07 14:08:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:31 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:32 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:32 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:32 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:32 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:32 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:32 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:32 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:32 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:33 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:33 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:33 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:33 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:33 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:33 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:33 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:33 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:33 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 14:08:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:34 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:34 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:34 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:34 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:34 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:34 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:35 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:35 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:35 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:35 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:35 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:35 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:35 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:35 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:35 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:35 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:36 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:36 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:36 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:37 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:37 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:37 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:37 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:37 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:37 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:37 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:37 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:38 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:38 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:38 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:38 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:38 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:38 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:38 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:38 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:08:38 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 14:08:38 --> Final output sent to browser
DEBUG - 2010-07-07 14:08:39 --> Total execution time: 11.2330
DEBUG - 2010-07-07 14:09:26 --> Config Class Initialized
DEBUG - 2010-07-07 14:09:26 --> Hooks Class Initialized
DEBUG - 2010-07-07 14:09:26 --> URI Class Initialized
DEBUG - 2010-07-07 14:09:26 --> Router Class Initialized
DEBUG - 2010-07-07 14:09:26 --> Output Class Initialized
DEBUG - 2010-07-07 14:09:26 --> Input Class Initialized
DEBUG - 2010-07-07 14:09:26 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 14:09:26 --> Language Class Initialized
DEBUG - 2010-07-07 14:09:26 --> Loader Class Initialized
DEBUG - 2010-07-07 14:09:26 --> Helper loaded: context_helper
DEBUG - 2010-07-07 14:09:27 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 14:09:27 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 14:09:27 --> Database Driver Class Initialized
DEBUG - 2010-07-07 14:09:27 --> Controller Class Initialized
DEBUG - 2010-07-07 14:09:27 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 14:09:27 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 14:09:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:27 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:28 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:28 --> Helper loaded: email_helper
DEBUG - 2010-07-07 14:09:28 --> User Agent Class Initialized
DEBUG - 2010-07-07 14:09:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:28 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:28 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 14:09:28 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:29 --> Session Class Initialized
DEBUG - 2010-07-07 14:09:29 --> Helper loaded: string_helper
DEBUG - 2010-07-07 14:09:29 --> Session routines successfully run
DEBUG - 2010-07-07 14:09:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:29 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:29 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:30 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:30 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:30 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:30 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:30 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:30 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:30 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:30 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:31 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:31 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:31 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:31 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:31 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:31 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 14:09:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:32 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:32 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:32 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:32 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:33 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:33 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:33 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:33 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:33 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:33 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:33 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:33 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:33 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:33 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:34 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:34 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:34 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:34 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:34 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:34 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:34 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:34 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:34 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:35 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:35 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:35 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:35 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:35 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:35 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:35 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:35 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:35 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:36 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:36 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:36 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:09:37 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 14:09:37 --> Final output sent to browser
DEBUG - 2010-07-07 14:09:37 --> Total execution time: 11.0903
DEBUG - 2010-07-07 14:10:56 --> Config Class Initialized
DEBUG - 2010-07-07 14:10:57 --> Hooks Class Initialized
DEBUG - 2010-07-07 14:10:57 --> URI Class Initialized
DEBUG - 2010-07-07 14:10:57 --> Router Class Initialized
DEBUG - 2010-07-07 14:10:57 --> Output Class Initialized
DEBUG - 2010-07-07 14:10:57 --> Input Class Initialized
DEBUG - 2010-07-07 14:10:57 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 14:10:57 --> Language Class Initialized
DEBUG - 2010-07-07 14:10:57 --> Loader Class Initialized
DEBUG - 2010-07-07 14:10:57 --> Helper loaded: context_helper
DEBUG - 2010-07-07 14:10:58 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 14:10:58 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 14:10:58 --> Database Driver Class Initialized
DEBUG - 2010-07-07 14:10:58 --> Controller Class Initialized
DEBUG - 2010-07-07 14:10:58 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 14:10:58 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 14:10:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:10:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:10:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:10:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:10:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:10:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:10:59 --> Helper loaded: email_helper
DEBUG - 2010-07-07 14:10:59 --> User Agent Class Initialized
DEBUG - 2010-07-07 14:10:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:10:59 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:10:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:10:59 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 14:10:59 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:00 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:00 --> Session Class Initialized
DEBUG - 2010-07-07 14:11:00 --> Helper loaded: string_helper
DEBUG - 2010-07-07 14:11:00 --> Session routines successfully run
DEBUG - 2010-07-07 14:11:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:00 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:01 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:01 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:01 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:01 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:01 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:01 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:01 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:01 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:02 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:02 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:02 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:02 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:02 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:02 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:02 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:02 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:03 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 14:11:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:03 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:03 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:03 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:03 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:03 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:04 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:04 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:04 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:04 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:04 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:04 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:04 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:04 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:04 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:04 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:05 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:05 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:05 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:05 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:05 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:05 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:05 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:05 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:06 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:06 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:06 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:06 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:06 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:06 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:07 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:07 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:07 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:07 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:07 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:07 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:07 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:07 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:08 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:08 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:08 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:08 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:08 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:08 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:08 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:09 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 14:11:09 --> Final output sent to browser
DEBUG - 2010-07-07 14:11:09 --> Total execution time: 12.3075
DEBUG - 2010-07-07 14:11:18 --> Config Class Initialized
DEBUG - 2010-07-07 14:11:19 --> Hooks Class Initialized
DEBUG - 2010-07-07 14:11:19 --> URI Class Initialized
DEBUG - 2010-07-07 14:11:19 --> Router Class Initialized
DEBUG - 2010-07-07 14:11:19 --> Output Class Initialized
DEBUG - 2010-07-07 14:11:19 --> Input Class Initialized
DEBUG - 2010-07-07 14:11:19 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 14:11:19 --> Language Class Initialized
DEBUG - 2010-07-07 14:11:19 --> Loader Class Initialized
DEBUG - 2010-07-07 14:11:19 --> Helper loaded: context_helper
DEBUG - 2010-07-07 14:11:20 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 14:11:20 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 14:11:20 --> Database Driver Class Initialized
DEBUG - 2010-07-07 14:11:20 --> Controller Class Initialized
DEBUG - 2010-07-07 14:11:20 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 14:11:20 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 14:11:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:20 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:21 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:21 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:21 --> Helper loaded: email_helper
DEBUG - 2010-07-07 14:11:21 --> User Agent Class Initialized
DEBUG - 2010-07-07 14:11:21 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:21 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:21 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 14:11:22 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:22 --> Session Class Initialized
DEBUG - 2010-07-07 14:11:22 --> Helper loaded: string_helper
DEBUG - 2010-07-07 14:11:22 --> Session routines successfully run
DEBUG - 2010-07-07 14:11:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:23 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:23 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:23 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:23 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:24 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:24 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:24 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:24 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:24 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:24 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:25 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:25 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:25 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:25 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 14:11:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:25 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:25 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:26 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:26 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:26 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:26 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:26 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:26 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:26 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:27 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:27 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:27 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:27 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:27 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:27 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:27 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:27 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:27 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:28 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:28 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:28 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:28 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:28 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:28 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:28 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:28 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:29 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:29 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:29 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:29 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:29 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:29 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:29 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:29 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:30 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:30 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:30 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:30 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:30 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:30 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:30 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:30 --> Annotation class already loaded. Second attempt ignored.
ERROR - 2010-07-07 14:11:30 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column reference &quot;webpage_id&quot; is ambiguous
LINE 6: GROUP BY &quot;webpage_id&quot;
                 ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-07 14:11:31 --> DB Transaction Failure
ERROR - 2010-07-07 14:11:31 --> Query error: ERROR:  column reference "webpage_id" is ambiguous
LINE 6: GROUP BY "webpage_id"
                 ^
DEBUG - 2010-07-07 14:11:31 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-07 14:11:31 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:383) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-07 14:11:47 --> Config Class Initialized
DEBUG - 2010-07-07 14:11:47 --> Hooks Class Initialized
DEBUG - 2010-07-07 14:11:47 --> URI Class Initialized
DEBUG - 2010-07-07 14:11:47 --> Router Class Initialized
DEBUG - 2010-07-07 14:11:47 --> Output Class Initialized
DEBUG - 2010-07-07 14:11:47 --> Input Class Initialized
DEBUG - 2010-07-07 14:11:47 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 14:11:47 --> Language Class Initialized
DEBUG - 2010-07-07 14:11:48 --> Loader Class Initialized
DEBUG - 2010-07-07 14:11:48 --> Helper loaded: context_helper
DEBUG - 2010-07-07 14:11:48 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 14:11:48 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 14:11:48 --> Database Driver Class Initialized
DEBUG - 2010-07-07 14:11:48 --> Controller Class Initialized
DEBUG - 2010-07-07 14:11:48 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 14:11:48 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 14:11:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:49 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:49 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:49 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:49 --> Helper loaded: email_helper
DEBUG - 2010-07-07 14:11:49 --> User Agent Class Initialized
DEBUG - 2010-07-07 14:11:49 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:50 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:50 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:50 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 14:11:50 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:50 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:50 --> Session Class Initialized
DEBUG - 2010-07-07 14:11:51 --> Helper loaded: string_helper
DEBUG - 2010-07-07 14:11:51 --> Session routines successfully run
DEBUG - 2010-07-07 14:11:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:51 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:51 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:51 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:52 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:52 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:52 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:52 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:52 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:52 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:52 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:52 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:53 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:53 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:53 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:53 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:53 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:53 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:53 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 14:11:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:54 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:54 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:54 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:54 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:54 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:54 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:54 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:54 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:55 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:55 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:55 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:55 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:55 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:55 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:55 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:55 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:55 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:56 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:56 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:56 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:56 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:56 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:56 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:56 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:56 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:57 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:57 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:57 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:57 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:57 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:58 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:58 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:58 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:58 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:58 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:58 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:58 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:58 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:58 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:59 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:59 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:59 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:11:59 --> Annotation class already loaded. Second attempt ignored.
ERROR - 2010-07-07 14:11:59 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;webpage.uri&quot; must appear in the GROUP BY clause or be used in an aggregate function
LINE 1: SELECT &quot;webpage&quot;.*
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-07 14:11:59 --> DB Transaction Failure
ERROR - 2010-07-07 14:11:59 --> Query error: ERROR:  column "webpage.uri" must appear in the GROUP BY clause or be used in an aggregate function
LINE 1: SELECT "webpage".*
               ^
DEBUG - 2010-07-07 14:11:59 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-07 14:11:59 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:383) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-07 14:12:13 --> Config Class Initialized
DEBUG - 2010-07-07 14:12:13 --> Hooks Class Initialized
DEBUG - 2010-07-07 14:12:13 --> URI Class Initialized
DEBUG - 2010-07-07 14:12:13 --> Router Class Initialized
DEBUG - 2010-07-07 14:12:13 --> Output Class Initialized
DEBUG - 2010-07-07 14:12:13 --> Input Class Initialized
DEBUG - 2010-07-07 14:12:14 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 14:12:14 --> Language Class Initialized
DEBUG - 2010-07-07 14:12:14 --> Loader Class Initialized
DEBUG - 2010-07-07 14:12:14 --> Helper loaded: context_helper
DEBUG - 2010-07-07 14:12:14 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 14:12:14 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 14:12:14 --> Database Driver Class Initialized
DEBUG - 2010-07-07 14:12:14 --> Controller Class Initialized
DEBUG - 2010-07-07 14:12:15 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 14:12:15 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 14:12:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:15 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:15 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:16 --> Helper loaded: email_helper
DEBUG - 2010-07-07 14:12:16 --> User Agent Class Initialized
DEBUG - 2010-07-07 14:12:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:16 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:16 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 14:12:16 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:17 --> Session Class Initialized
DEBUG - 2010-07-07 14:12:17 --> Helper loaded: string_helper
DEBUG - 2010-07-07 14:12:17 --> Session routines successfully run
DEBUG - 2010-07-07 14:12:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:17 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:18 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:18 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:18 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:18 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:18 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:18 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:18 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:18 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:19 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:19 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:19 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:19 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:19 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:19 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:19 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:20 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:20 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 14:12:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:20 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:20 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:20 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:20 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:20 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:21 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:21 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:21 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:21 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:21 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:21 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:21 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:22 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:22 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:22 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:22 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:22 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:22 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:22 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:22 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:22 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:23 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:23 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:23 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:23 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:23 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:24 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:24 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:24 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:24 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:24 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:24 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:24 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:25 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:25 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:25 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:25 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:25 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:25 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:25 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:25 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:26 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:12:26 --> Annotation class already loaded. Second attempt ignored.
ERROR - 2010-07-07 14:12:26 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;webpage.webpage_id&quot; must appear in the GROUP BY clause or be used in an aggregate function
LINE 1: SELECT &quot;webpage&quot;.*
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-07 14:12:26 --> DB Transaction Failure
ERROR - 2010-07-07 14:12:26 --> Query error: ERROR:  column "webpage.webpage_id" must appear in the GROUP BY clause or be used in an aggregate function
LINE 1: SELECT "webpage".*
               ^
DEBUG - 2010-07-07 14:12:26 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-07 14:12:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:383) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-07 14:14:15 --> Config Class Initialized
DEBUG - 2010-07-07 14:14:15 --> Hooks Class Initialized
DEBUG - 2010-07-07 14:14:15 --> URI Class Initialized
DEBUG - 2010-07-07 14:14:15 --> Router Class Initialized
DEBUG - 2010-07-07 14:14:15 --> Output Class Initialized
DEBUG - 2010-07-07 14:14:16 --> Input Class Initialized
DEBUG - 2010-07-07 14:14:16 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 14:14:16 --> Language Class Initialized
DEBUG - 2010-07-07 14:14:16 --> Loader Class Initialized
DEBUG - 2010-07-07 14:14:16 --> Helper loaded: context_helper
DEBUG - 2010-07-07 14:14:16 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 14:14:16 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 14:14:16 --> Database Driver Class Initialized
DEBUG - 2010-07-07 14:14:17 --> Controller Class Initialized
DEBUG - 2010-07-07 14:14:17 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 14:14:17 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 14:14:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:17 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:17 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:18 --> Helper loaded: email_helper
DEBUG - 2010-07-07 14:14:18 --> User Agent Class Initialized
DEBUG - 2010-07-07 14:14:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:18 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:18 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 14:14:18 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:19 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:19 --> Session Class Initialized
DEBUG - 2010-07-07 14:14:19 --> Helper loaded: string_helper
DEBUG - 2010-07-07 14:14:19 --> Session routines successfully run
DEBUG - 2010-07-07 14:14:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:19 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:20 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:20 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:20 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:20 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:20 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:20 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:20 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:20 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:21 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:21 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:21 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:21 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:21 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:21 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:22 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:22 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:22 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 14:14:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:22 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:22 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:22 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:23 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:23 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:23 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:23 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:24 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:24 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:24 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:24 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:24 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:24 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:24 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:24 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:25 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:25 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:25 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:25 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:25 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:25 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:25 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:26 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:26 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:26 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:26 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:26 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:26 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:26 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:27 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:27 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:27 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:27 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:27 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:27 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:27 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:27 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:28 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:28 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:28 --> Annotation class already loaded. Second attempt ignored.
ERROR - 2010-07-07 14:14:28 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column webpage.domaind_id does not exist
LINE 6: ...&quot;webpage_id&quot;, &quot;webpage&quot;.&quot;uri&quot;, &quot;webpage&quot;.&quot;title&quot;, &quot;webpage&quot;....
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-07 14:14:28 --> DB Transaction Failure
ERROR - 2010-07-07 14:14:28 --> Query error: ERROR:  column webpage.domaind_id does not exist
LINE 6: ..."webpage_id", "webpage"."uri", "webpage"."title", "webpage"....
                                                             ^
DEBUG - 2010-07-07 14:14:28 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-07 14:14:28 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:383) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-07 14:14:55 --> Config Class Initialized
DEBUG - 2010-07-07 14:14:55 --> Hooks Class Initialized
DEBUG - 2010-07-07 14:14:55 --> URI Class Initialized
DEBUG - 2010-07-07 14:14:56 --> Router Class Initialized
DEBUG - 2010-07-07 14:14:56 --> Output Class Initialized
DEBUG - 2010-07-07 14:14:56 --> Input Class Initialized
DEBUG - 2010-07-07 14:14:56 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 14:14:56 --> Language Class Initialized
DEBUG - 2010-07-07 14:14:56 --> Loader Class Initialized
DEBUG - 2010-07-07 14:14:56 --> Helper loaded: context_helper
DEBUG - 2010-07-07 14:14:56 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 14:14:57 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 14:14:57 --> Database Driver Class Initialized
DEBUG - 2010-07-07 14:14:57 --> Controller Class Initialized
DEBUG - 2010-07-07 14:14:57 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 14:14:57 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 14:14:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:58 --> Helper loaded: email_helper
DEBUG - 2010-07-07 14:14:58 --> User Agent Class Initialized
DEBUG - 2010-07-07 14:14:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:58 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:59 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 14:14:59 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:14:59 --> Session Class Initialized
DEBUG - 2010-07-07 14:15:00 --> Helper loaded: string_helper
DEBUG - 2010-07-07 14:15:00 --> Session routines successfully run
DEBUG - 2010-07-07 14:15:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:00 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:00 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:01 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:01 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:01 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:01 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:01 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:01 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:01 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:02 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:02 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:02 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:02 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:02 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:02 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:03 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:03 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:03 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 14:15:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:03 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:03 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:03 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:03 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:03 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:04 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:04 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:04 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:04 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:04 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:04 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:05 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:05 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:05 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:05 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:05 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:05 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:05 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:05 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:06 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:06 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:06 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:06 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:06 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:06 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:06 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:07 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:07 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:07 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:07 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:08 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:08 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:08 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:08 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:08 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:08 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:08 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:09 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:09 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:09 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:09 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:09 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:15:09 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 14:15:10 --> Final output sent to browser
DEBUG - 2010-07-07 14:15:10 --> Total execution time: 14.4602
DEBUG - 2010-07-07 14:16:57 --> Config Class Initialized
DEBUG - 2010-07-07 14:16:57 --> Hooks Class Initialized
DEBUG - 2010-07-07 14:16:57 --> URI Class Initialized
DEBUG - 2010-07-07 14:16:58 --> Router Class Initialized
DEBUG - 2010-07-07 14:16:58 --> Output Class Initialized
DEBUG - 2010-07-07 14:16:58 --> Input Class Initialized
DEBUG - 2010-07-07 14:16:58 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 14:16:58 --> Language Class Initialized
DEBUG - 2010-07-07 14:16:58 --> Loader Class Initialized
DEBUG - 2010-07-07 14:16:58 --> Helper loaded: context_helper
DEBUG - 2010-07-07 14:16:58 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 14:16:59 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 14:16:59 --> Database Driver Class Initialized
DEBUG - 2010-07-07 14:16:59 --> Controller Class Initialized
DEBUG - 2010-07-07 14:16:59 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 14:16:59 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 14:16:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:16:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:00 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:00 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:00 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:00 --> Helper loaded: email_helper
DEBUG - 2010-07-07 14:17:00 --> User Agent Class Initialized
DEBUG - 2010-07-07 14:17:00 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:00 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:01 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 14:17:01 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:01 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:01 --> Session Class Initialized
DEBUG - 2010-07-07 14:17:01 --> Helper loaded: string_helper
DEBUG - 2010-07-07 14:17:01 --> Session routines successfully run
DEBUG - 2010-07-07 14:17:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:02 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:02 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:02 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:02 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:02 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:03 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:03 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:03 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:03 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:03 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:03 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:03 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:04 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:04 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:04 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:04 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:04 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 14:17:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:05 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:05 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:05 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:06 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:06 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:06 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:06 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:06 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:06 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:06 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:06 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:07 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:07 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:07 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:07 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:07 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:07 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:07 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:07 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:08 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:08 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:08 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:08 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:08 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:08 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:09 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:09 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:09 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:09 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:09 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:09 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:10 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:10 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:10 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:10 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:10 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:10 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:10 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:10 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:10 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:11 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 14:17:11 --> Final output sent to browser
DEBUG - 2010-07-07 14:17:11 --> Total execution time: 13.8190
DEBUG - 2010-07-07 14:17:21 --> Config Class Initialized
DEBUG - 2010-07-07 14:17:21 --> Hooks Class Initialized
DEBUG - 2010-07-07 14:17:22 --> URI Class Initialized
DEBUG - 2010-07-07 14:17:22 --> Router Class Initialized
DEBUG - 2010-07-07 14:17:22 --> Output Class Initialized
DEBUG - 2010-07-07 14:17:22 --> Input Class Initialized
DEBUG - 2010-07-07 14:17:22 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 14:17:22 --> Language Class Initialized
DEBUG - 2010-07-07 14:17:22 --> Loader Class Initialized
DEBUG - 2010-07-07 14:17:22 --> Helper loaded: context_helper
DEBUG - 2010-07-07 14:17:23 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 14:17:23 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 14:17:23 --> Database Driver Class Initialized
DEBUG - 2010-07-07 14:17:23 --> Controller Class Initialized
DEBUG - 2010-07-07 14:17:23 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 14:17:23 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 14:17:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:24 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:24 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:24 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:24 --> Helper loaded: email_helper
DEBUG - 2010-07-07 14:17:24 --> User Agent Class Initialized
DEBUG - 2010-07-07 14:17:24 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:25 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:25 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 14:17:25 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:25 --> Session Class Initialized
DEBUG - 2010-07-07 14:17:25 --> Helper loaded: string_helper
DEBUG - 2010-07-07 14:17:26 --> Session routines successfully run
DEBUG - 2010-07-07 14:17:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:26 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:26 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:26 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:27 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:27 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:27 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:27 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:27 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:27 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:27 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:27 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:28 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:28 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:28 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:28 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:29 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:29 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 14:17:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:29 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:29 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:29 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:29 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:30 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:30 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:30 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:30 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:30 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:30 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:31 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:31 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:31 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:31 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:31 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:31 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:31 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:32 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:32 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:32 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:32 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:32 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:32 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:32 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:32 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:33 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:33 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:33 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:33 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:33 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:33 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:34 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:34 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:34 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:34 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:34 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:34 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:34 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:34 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:35 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:35 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:35 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:35 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:35 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 14:17:35 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 14:17:36 --> Final output sent to browser
DEBUG - 2010-07-07 14:17:36 --> Total execution time: 14.3338
DEBUG - 2010-07-07 17:03:13 --> Config Class Initialized
DEBUG - 2010-07-07 17:03:14 --> Hooks Class Initialized
DEBUG - 2010-07-07 17:03:14 --> URI Class Initialized
DEBUG - 2010-07-07 17:03:14 --> Router Class Initialized
DEBUG - 2010-07-07 17:03:14 --> Output Class Initialized
DEBUG - 2010-07-07 17:03:14 --> Input Class Initialized
DEBUG - 2010-07-07 17:03:15 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 17:03:15 --> Language Class Initialized
DEBUG - 2010-07-07 17:03:15 --> Loader Class Initialized
DEBUG - 2010-07-07 17:03:15 --> Helper loaded: context_helper
DEBUG - 2010-07-07 17:03:15 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 17:03:15 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 17:03:16 --> Database Driver Class Initialized
DEBUG - 2010-07-07 17:03:16 --> Controller Class Initialized
DEBUG - 2010-07-07 17:03:16 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 17:03:16 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 17:03:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:17 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:17 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:17 --> Helper loaded: email_helper
DEBUG - 2010-07-07 17:03:17 --> User Agent Class Initialized
DEBUG - 2010-07-07 17:03:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:18 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:18 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 17:03:18 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:19 --> Session Class Initialized
DEBUG - 2010-07-07 17:03:19 --> Helper loaded: string_helper
DEBUG - 2010-07-07 17:03:19 --> A session cookie was not found.
DEBUG - 2010-07-07 17:03:19 --> Session routines successfully run
DEBUG - 2010-07-07 17:03:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:19 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:20 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:20 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:20 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:20 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:20 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:20 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:20 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:21 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:21 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:21 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:21 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:21 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:21 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:22 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:22 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:22 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:22 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 17:03:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:22 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:23 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:23 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:23 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:23 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:23 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:03:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
ERROR - 2010-07-07 17:03:24 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  null value in column &quot;topic_id&quot; violates not-null constraint D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-07 17:03:24 --> DB Transaction Failure
ERROR - 2010-07-07 17:03:24 --> Query error: ERROR:  null value in column "topic_id" violates not-null constraint
DEBUG - 2010-07-07 17:03:24 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-07-07 17:04:14 --> Config Class Initialized
DEBUG - 2010-07-07 17:04:14 --> Hooks Class Initialized
DEBUG - 2010-07-07 17:04:14 --> URI Class Initialized
DEBUG - 2010-07-07 17:04:14 --> Router Class Initialized
DEBUG - 2010-07-07 17:04:14 --> Output Class Initialized
DEBUG - 2010-07-07 17:04:14 --> Input Class Initialized
DEBUG - 2010-07-07 17:04:15 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 17:04:15 --> Language Class Initialized
DEBUG - 2010-07-07 17:04:15 --> Loader Class Initialized
DEBUG - 2010-07-07 17:04:15 --> Helper loaded: context_helper
DEBUG - 2010-07-07 17:04:15 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 17:04:15 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 17:04:15 --> Database Driver Class Initialized
DEBUG - 2010-07-07 17:04:16 --> Controller Class Initialized
DEBUG - 2010-07-07 17:04:16 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 17:04:16 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 17:04:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:16 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:16 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:17 --> Helper loaded: email_helper
DEBUG - 2010-07-07 17:04:17 --> User Agent Class Initialized
DEBUG - 2010-07-07 17:04:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:17 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:17 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 17:04:18 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:18 --> Session Class Initialized
DEBUG - 2010-07-07 17:04:18 --> Helper loaded: string_helper
DEBUG - 2010-07-07 17:04:18 --> Session routines successfully run
DEBUG - 2010-07-07 17:04:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:19 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:19 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:19 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:19 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:19 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:19 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:20 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:20 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:20 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:20 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:20 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:20 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:21 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:21 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:21 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:21 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:21 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:21 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 17:04:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:22 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:22 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:22 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:22 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:22 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:23 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:04:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
ERROR - 2010-07-07 17:04:23 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  null value in column &quot;topic_id&quot; violates not-null constraint D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-07 17:04:23 --> DB Transaction Failure
ERROR - 2010-07-07 17:04:23 --> Query error: ERROR:  null value in column "topic_id" violates not-null constraint
DEBUG - 2010-07-07 17:04:24 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-07-07 17:06:15 --> Config Class Initialized
DEBUG - 2010-07-07 17:06:15 --> Hooks Class Initialized
DEBUG - 2010-07-07 17:06:15 --> URI Class Initialized
DEBUG - 2010-07-07 17:06:15 --> Router Class Initialized
DEBUG - 2010-07-07 17:06:16 --> Output Class Initialized
DEBUG - 2010-07-07 17:06:16 --> Input Class Initialized
DEBUG - 2010-07-07 17:06:16 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 17:06:16 --> Language Class Initialized
DEBUG - 2010-07-07 17:06:16 --> Loader Class Initialized
DEBUG - 2010-07-07 17:06:16 --> Helper loaded: context_helper
DEBUG - 2010-07-07 17:06:16 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 17:06:16 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 17:06:17 --> Database Driver Class Initialized
DEBUG - 2010-07-07 17:06:17 --> Controller Class Initialized
DEBUG - 2010-07-07 17:06:17 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 17:06:17 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 17:06:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:17 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:18 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:18 --> Helper loaded: email_helper
DEBUG - 2010-07-07 17:06:18 --> User Agent Class Initialized
DEBUG - 2010-07-07 17:06:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:18 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:19 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 17:06:19 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:19 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:19 --> Session Class Initialized
DEBUG - 2010-07-07 17:06:19 --> Helper loaded: string_helper
DEBUG - 2010-07-07 17:06:19 --> Session routines successfully run
DEBUG - 2010-07-07 17:06:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:20 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:20 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:20 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:20 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:21 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:21 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:21 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:21 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:21 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:21 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:21 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:22 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:22 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:22 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:22 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:22 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:23 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 17:06:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:23 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:23 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:23 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:23 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:23 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:24 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:24 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:24 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:06:24 --> Segmentor_CKIP class already loaded. Second attempt ignored.
ERROR - 2010-07-07 17:06:24 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  insert or update on table &quot;annotation2topic&quot; violates foreign key constraint &quot;annotation2topic_respond_id_fkey&quot;
DETAIL:  Key (respond_id)=(39) is not present in table &quot;anchor_text&quot;. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-07 17:06:24 --> DB Transaction Failure
ERROR - 2010-07-07 17:06:25 --> Query error: ERROR:  insert or update on table "annotation2topic" violates foreign key constraint "annotation2topic_respond_id_fkey"
DETAIL:  Key (respond_id)=(39) is not present in table "anchor_text".
DEBUG - 2010-07-07 17:06:25 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-07-07 17:08:01 --> Config Class Initialized
DEBUG - 2010-07-07 17:08:01 --> Hooks Class Initialized
DEBUG - 2010-07-07 17:08:01 --> URI Class Initialized
DEBUG - 2010-07-07 17:08:02 --> Router Class Initialized
DEBUG - 2010-07-07 17:08:02 --> Output Class Initialized
DEBUG - 2010-07-07 17:08:02 --> Input Class Initialized
DEBUG - 2010-07-07 17:08:02 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 17:08:02 --> Language Class Initialized
DEBUG - 2010-07-07 17:08:02 --> Loader Class Initialized
DEBUG - 2010-07-07 17:08:02 --> Helper loaded: context_helper
DEBUG - 2010-07-07 17:08:03 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 17:08:03 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 17:08:03 --> Database Driver Class Initialized
DEBUG - 2010-07-07 17:08:03 --> Controller Class Initialized
DEBUG - 2010-07-07 17:08:03 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 17:08:03 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 17:08:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:04 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:04 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:04 --> Helper loaded: email_helper
DEBUG - 2010-07-07 17:08:04 --> User Agent Class Initialized
DEBUG - 2010-07-07 17:08:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:05 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:05 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 17:08:05 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:06 --> Session Class Initialized
DEBUG - 2010-07-07 17:08:06 --> Helper loaded: string_helper
DEBUG - 2010-07-07 17:08:06 --> Session routines successfully run
DEBUG - 2010-07-07 17:08:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:06 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:07 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:07 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:07 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:07 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:07 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:07 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:07 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:08 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:08 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:08 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:08 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:09 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:09 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:09 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:09 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 17:08:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:09 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:10 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:10 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:10 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:10 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:10 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:10 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:11 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:11 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:11 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:11 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:11 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:11 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:12 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:12 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:12 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:12 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:12 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:12 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:12 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:13 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:13 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:13 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:13 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:13 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:13 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:14 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:14 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:14 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:14 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:14 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:14 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:15 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:15 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:15 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:15 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:15 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:15 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:16 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:16 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:16 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:16 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:16 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:16 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:16 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:17 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:17 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:17 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:17 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:32 --> Config Class Initialized
DEBUG - 2010-07-07 17:08:33 --> Hooks Class Initialized
DEBUG - 2010-07-07 17:08:33 --> URI Class Initialized
DEBUG - 2010-07-07 17:08:33 --> Router Class Initialized
DEBUG - 2010-07-07 17:08:33 --> Output Class Initialized
DEBUG - 2010-07-07 17:08:33 --> Input Class Initialized
DEBUG - 2010-07-07 17:08:33 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 17:08:33 --> Language Class Initialized
DEBUG - 2010-07-07 17:08:34 --> Loader Class Initialized
DEBUG - 2010-07-07 17:08:34 --> Helper loaded: context_helper
DEBUG - 2010-07-07 17:08:34 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 17:08:34 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 17:08:34 --> Database Driver Class Initialized
DEBUG - 2010-07-07 17:08:34 --> Controller Class Initialized
DEBUG - 2010-07-07 17:08:34 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 17:08:35 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 17:08:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:35 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:35 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:36 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:36 --> Helper loaded: email_helper
DEBUG - 2010-07-07 17:08:36 --> User Agent Class Initialized
DEBUG - 2010-07-07 17:08:36 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:36 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:36 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 17:08:37 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:37 --> Session Class Initialized
DEBUG - 2010-07-07 17:08:37 --> Helper loaded: string_helper
DEBUG - 2010-07-07 17:08:37 --> Session routines successfully run
DEBUG - 2010-07-07 17:08:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:38 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:38 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:38 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:39 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:39 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:39 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:39 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:39 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:39 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:39 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:40 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:40 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:40 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:40 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:40 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:41 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:41 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 17:08:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:41 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:41 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:41 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:42 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:42 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:42 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:42 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:42 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:42 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:43 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:43 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:43 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:43 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:43 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:43 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:43 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:44 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:44 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:44 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:44 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:44 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:44 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:44 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:44 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:45 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:45 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:45 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:45 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:45 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:45 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:45 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:46 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:46 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:46 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:46 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:46 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:47 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:47 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:47 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:47 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:47 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:47 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:47 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:48 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:48 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:48 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:48 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:48 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:48 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:48 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:49 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:08:49 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-07 17:08:49 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  unterminated quoted identifier at or near &quot;&quot; = 'FALSE'
LIMIT 1&quot;
LINE 5: AND &quot;annotation&quot;.&quot; = 'FALSE'
                         ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-07 17:08:49 --> DB Transaction Failure
ERROR - 2010-07-07 17:08:49 --> Query error: ERROR:  unterminated quoted identifier at or near "" = 'FALSE'
LIMIT 1"
LINE 5: AND "annotation"." = 'FALSE'
                         ^
DEBUG - 2010-07-07 17:08:49 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-07-07 17:09:47 --> Config Class Initialized
DEBUG - 2010-07-07 17:09:47 --> Hooks Class Initialized
DEBUG - 2010-07-07 17:09:48 --> URI Class Initialized
DEBUG - 2010-07-07 17:09:48 --> Router Class Initialized
DEBUG - 2010-07-07 17:09:48 --> Output Class Initialized
DEBUG - 2010-07-07 17:09:48 --> Input Class Initialized
DEBUG - 2010-07-07 17:09:48 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 17:09:48 --> Language Class Initialized
DEBUG - 2010-07-07 17:09:48 --> Loader Class Initialized
DEBUG - 2010-07-07 17:09:49 --> Helper loaded: context_helper
DEBUG - 2010-07-07 17:09:49 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 17:09:49 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 17:09:49 --> Database Driver Class Initialized
DEBUG - 2010-07-07 17:09:49 --> Controller Class Initialized
DEBUG - 2010-07-07 17:09:49 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 17:09:49 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 17:09:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:50 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:50 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:50 --> Helper loaded: email_helper
DEBUG - 2010-07-07 17:09:51 --> User Agent Class Initialized
DEBUG - 2010-07-07 17:09:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:51 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:51 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 17:09:51 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:52 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:52 --> Session Class Initialized
DEBUG - 2010-07-07 17:09:52 --> Helper loaded: string_helper
DEBUG - 2010-07-07 17:09:52 --> Session routines successfully run
DEBUG - 2010-07-07 17:09:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:53 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:53 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:53 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:53 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:53 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:53 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:54 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:54 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:54 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:54 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:54 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:55 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:55 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:55 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:55 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:55 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:55 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:56 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 17:09:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:56 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:56 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:57 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:57 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:57 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:57 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:57 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:58 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:58 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:58 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:58 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:58 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:58 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:58 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:58 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:59 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:59 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:59 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:59 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:59 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:09:59 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:00 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:00 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:00 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:00 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:00 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:00 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:00 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:01 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:01 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:01 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:01 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:01 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:02 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:02 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:02 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:02 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:02 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:02 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:02 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:03 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:03 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:03 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:03 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:03 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:03 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:03 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:47 --> Config Class Initialized
DEBUG - 2010-07-07 17:10:48 --> Hooks Class Initialized
DEBUG - 2010-07-07 17:10:48 --> URI Class Initialized
DEBUG - 2010-07-07 17:10:48 --> Router Class Initialized
DEBUG - 2010-07-07 17:10:48 --> Output Class Initialized
DEBUG - 2010-07-07 17:10:48 --> Input Class Initialized
DEBUG - 2010-07-07 17:10:48 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 17:10:49 --> Language Class Initialized
DEBUG - 2010-07-07 17:10:49 --> Loader Class Initialized
DEBUG - 2010-07-07 17:10:49 --> Helper loaded: context_helper
DEBUG - 2010-07-07 17:10:49 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 17:10:49 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 17:10:49 --> Database Driver Class Initialized
DEBUG - 2010-07-07 17:10:49 --> Controller Class Initialized
DEBUG - 2010-07-07 17:10:50 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 17:10:50 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 17:10:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:50 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:51 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:51 --> Helper loaded: email_helper
DEBUG - 2010-07-07 17:10:51 --> User Agent Class Initialized
DEBUG - 2010-07-07 17:10:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:51 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:52 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 17:10:52 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:52 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:52 --> Session Class Initialized
DEBUG - 2010-07-07 17:10:52 --> Helper loaded: string_helper
DEBUG - 2010-07-07 17:10:52 --> Session routines successfully run
DEBUG - 2010-07-07 17:10:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:53 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:53 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:53 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:54 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:54 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:54 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:54 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:54 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:54 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:54 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:55 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:55 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:55 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:55 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:56 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:56 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:56 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:56 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 17:10:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:57 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:57 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:57 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:57 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:57 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:58 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:58 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:58 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:58 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:58 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:59 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:59 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:59 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:59 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:59 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:59 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:10:59 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:00 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:00 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:00 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:00 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:00 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:00 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:00 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:01 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:01 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:01 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:01 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:01 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:01 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:02 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:02 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:02 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:02 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:02 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:02 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:03 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:03 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:03 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:03 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:03 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:03 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:04 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:04 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:04 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:04 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:04 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:11:05 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 17:11:05 --> Final output sent to browser
DEBUG - 2010-07-07 17:11:05 --> Total execution time: 17.2080
DEBUG - 2010-07-07 17:12:34 --> Config Class Initialized
DEBUG - 2010-07-07 17:12:34 --> Hooks Class Initialized
DEBUG - 2010-07-07 17:12:34 --> URI Class Initialized
DEBUG - 2010-07-07 17:12:35 --> Router Class Initialized
DEBUG - 2010-07-07 17:12:35 --> Output Class Initialized
DEBUG - 2010-07-07 17:12:35 --> Input Class Initialized
DEBUG - 2010-07-07 17:12:35 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 17:12:35 --> Language Class Initialized
DEBUG - 2010-07-07 17:12:35 --> Loader Class Initialized
DEBUG - 2010-07-07 17:12:35 --> Helper loaded: context_helper
DEBUG - 2010-07-07 17:12:36 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 17:12:36 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 17:12:36 --> Database Driver Class Initialized
DEBUG - 2010-07-07 17:12:36 --> Controller Class Initialized
DEBUG - 2010-07-07 17:12:36 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 17:12:36 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 17:12:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:37 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:37 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:38 --> Helper loaded: email_helper
DEBUG - 2010-07-07 17:12:38 --> User Agent Class Initialized
DEBUG - 2010-07-07 17:12:38 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:38 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:38 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 17:12:38 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:48 --> Config Class Initialized
DEBUG - 2010-07-07 17:12:48 --> Hooks Class Initialized
DEBUG - 2010-07-07 17:12:48 --> URI Class Initialized
DEBUG - 2010-07-07 17:12:48 --> Router Class Initialized
DEBUG - 2010-07-07 17:12:48 --> Output Class Initialized
DEBUG - 2010-07-07 17:12:49 --> Input Class Initialized
DEBUG - 2010-07-07 17:12:49 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 17:12:49 --> Language Class Initialized
DEBUG - 2010-07-07 17:12:49 --> Loader Class Initialized
DEBUG - 2010-07-07 17:12:49 --> Helper loaded: context_helper
DEBUG - 2010-07-07 17:12:49 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 17:12:49 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 17:12:50 --> Database Driver Class Initialized
DEBUG - 2010-07-07 17:12:50 --> Controller Class Initialized
DEBUG - 2010-07-07 17:12:50 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 17:12:50 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 17:12:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:51 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:51 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:51 --> Helper loaded: email_helper
DEBUG - 2010-07-07 17:12:51 --> User Agent Class Initialized
DEBUG - 2010-07-07 17:12:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:52 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:52 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 17:12:52 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:52 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:52 --> Session Class Initialized
DEBUG - 2010-07-07 17:12:53 --> Helper loaded: string_helper
DEBUG - 2010-07-07 17:12:53 --> Session routines successfully run
DEBUG - 2010-07-07 17:12:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:53 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:54 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:54 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:54 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:54 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:54 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:54 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:54 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:55 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:55 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:55 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:55 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:55 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:56 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:56 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:56 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:56 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:56 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 17:12:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:57 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:57 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:57 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:58 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:58 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:58 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:58 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:58 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:59 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:59 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:59 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:59 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:59 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:12:59 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:00 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:00 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:00 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:00 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:00 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:00 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:01 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:01 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:01 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:01 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:01 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:01 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:01 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:02 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:02 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:02 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:02 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:02 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:02 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:03 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:03 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:03 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:03 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:04 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:04 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:04 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:04 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:04 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:04 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:04 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:05 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:05 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:05 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:30 --> Config Class Initialized
DEBUG - 2010-07-07 17:13:30 --> Hooks Class Initialized
DEBUG - 2010-07-07 17:13:30 --> URI Class Initialized
DEBUG - 2010-07-07 17:13:30 --> Router Class Initialized
DEBUG - 2010-07-07 17:13:30 --> Output Class Initialized
DEBUG - 2010-07-07 17:13:30 --> Input Class Initialized
DEBUG - 2010-07-07 17:13:31 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 17:13:31 --> Language Class Initialized
DEBUG - 2010-07-07 17:13:31 --> Loader Class Initialized
DEBUG - 2010-07-07 17:13:31 --> Helper loaded: context_helper
DEBUG - 2010-07-07 17:13:31 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 17:13:31 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 17:13:31 --> Database Driver Class Initialized
DEBUG - 2010-07-07 17:13:32 --> Controller Class Initialized
DEBUG - 2010-07-07 17:13:32 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 17:13:32 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 17:13:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:33 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:33 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:33 --> Helper loaded: email_helper
DEBUG - 2010-07-07 17:13:33 --> User Agent Class Initialized
DEBUG - 2010-07-07 17:13:33 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:33 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:34 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 17:13:34 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:35 --> Session Class Initialized
DEBUG - 2010-07-07 17:13:35 --> Helper loaded: string_helper
DEBUG - 2010-07-07 17:13:35 --> Session routines successfully run
DEBUG - 2010-07-07 17:13:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:35 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:36 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:36 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:37 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:37 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:37 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:37 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:37 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:38 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:38 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:38 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:38 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:38 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:39 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 17:13:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:39 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:40 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:40 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:40 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:40 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:40 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:40 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:41 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:41 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:41 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:41 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:41 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:42 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:42 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:42 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:42 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:42 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:42 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:42 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:43 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:43 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:43 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:43 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:43 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:43 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:44 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:44 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:44 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:44 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:44 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:44 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:45 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:45 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:45 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:45 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:45 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:46 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:46 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:46 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:46 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:46 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:47 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:47 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:47 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:47 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:47 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:13:48 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:14:56 --> Config Class Initialized
DEBUG - 2010-07-07 17:14:56 --> Hooks Class Initialized
DEBUG - 2010-07-07 17:14:56 --> URI Class Initialized
DEBUG - 2010-07-07 17:14:57 --> Router Class Initialized
DEBUG - 2010-07-07 17:14:57 --> Output Class Initialized
DEBUG - 2010-07-07 17:14:57 --> Input Class Initialized
DEBUG - 2010-07-07 17:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 17:14:57 --> Language Class Initialized
DEBUG - 2010-07-07 17:14:57 --> Loader Class Initialized
DEBUG - 2010-07-07 17:14:58 --> Helper loaded: context_helper
DEBUG - 2010-07-07 17:14:58 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 17:14:58 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 17:14:58 --> Database Driver Class Initialized
DEBUG - 2010-07-07 17:14:58 --> Controller Class Initialized
DEBUG - 2010-07-07 17:14:58 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 17:14:59 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 17:14:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:14:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:14:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:14:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:14:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:14:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:00 --> Helper loaded: email_helper
DEBUG - 2010-07-07 17:15:00 --> User Agent Class Initialized
DEBUG - 2010-07-07 17:15:00 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:00 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:00 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 17:15:01 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:01 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:01 --> Session Class Initialized
DEBUG - 2010-07-07 17:15:01 --> Helper loaded: string_helper
DEBUG - 2010-07-07 17:15:01 --> Session routines successfully run
DEBUG - 2010-07-07 17:15:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:02 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:02 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:02 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:03 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:03 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:03 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:03 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:03 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:03 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:04 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:04 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:04 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:04 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:05 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:05 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:05 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:05 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 17:15:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:06 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:06 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:06 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:06 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:06 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:07 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:07 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:07 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:07 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:07 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:08 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:08 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:08 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:08 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:08 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:09 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:09 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:09 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:09 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:09 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:09 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:09 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:10 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:10 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:10 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:10 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:10 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:10 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:11 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:11 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:11 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:11 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:11 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:12 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:12 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:12 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:12 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:12 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:12 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:13 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:13 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:13 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:13 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:13 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:13 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:14 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:14 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:15:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:16:50 --> Config Class Initialized
DEBUG - 2010-07-07 17:16:50 --> Hooks Class Initialized
DEBUG - 2010-07-07 17:16:50 --> URI Class Initialized
DEBUG - 2010-07-07 17:16:51 --> Router Class Initialized
DEBUG - 2010-07-07 17:16:51 --> Output Class Initialized
DEBUG - 2010-07-07 17:16:51 --> Input Class Initialized
DEBUG - 2010-07-07 17:16:51 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 17:16:51 --> Language Class Initialized
DEBUG - 2010-07-07 17:16:51 --> Loader Class Initialized
DEBUG - 2010-07-07 17:16:52 --> Helper loaded: context_helper
DEBUG - 2010-07-07 17:16:52 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 17:16:52 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 17:16:52 --> Database Driver Class Initialized
DEBUG - 2010-07-07 17:16:52 --> Controller Class Initialized
DEBUG - 2010-07-07 17:16:52 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 17:16:53 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 17:16:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:16:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:16:53 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:16:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:16:53 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:16:53 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:16:54 --> Helper loaded: email_helper
DEBUG - 2010-07-07 17:16:54 --> User Agent Class Initialized
DEBUG - 2010-07-07 17:16:54 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:16:54 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:16:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:16:55 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 17:16:55 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:16:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:16:55 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:16:55 --> Session Class Initialized
DEBUG - 2010-07-07 17:16:55 --> Helper loaded: string_helper
DEBUG - 2010-07-07 17:16:56 --> Session routines successfully run
DEBUG - 2010-07-07 17:16:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:16:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:16:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:16:56 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:16:56 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:16:57 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:16:57 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:16:57 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:16:57 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:16:57 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:16:57 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:16:58 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:16:58 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:16:58 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:16:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:16:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:16:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:16:59 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:16:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:16:59 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:16:59 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:16:59 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:17:00 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 17:17:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:17:00 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:17:00 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:17:00 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:17:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:17:01 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:17:01 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:17:01 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:17:01 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:17:01 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:17:01 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:17:02 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 17:17:02 --> Final output sent to browser
DEBUG - 2010-07-07 17:17:02 --> Total execution time: 11.6621
DEBUG - 2010-07-07 17:20:49 --> Config Class Initialized
DEBUG - 2010-07-07 17:20:49 --> Hooks Class Initialized
DEBUG - 2010-07-07 17:20:49 --> URI Class Initialized
DEBUG - 2010-07-07 17:20:49 --> Router Class Initialized
DEBUG - 2010-07-07 17:20:49 --> Output Class Initialized
DEBUG - 2010-07-07 17:20:50 --> Input Class Initialized
DEBUG - 2010-07-07 17:20:50 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-07 17:20:50 --> Language Class Initialized
DEBUG - 2010-07-07 17:20:50 --> Loader Class Initialized
DEBUG - 2010-07-07 17:20:50 --> Helper loaded: context_helper
DEBUG - 2010-07-07 17:20:51 --> Helper loaded: kals_helper
DEBUG - 2010-07-07 17:20:51 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-07 17:20:51 --> Database Driver Class Initialized
DEBUG - 2010-07-07 17:20:51 --> Controller Class Initialized
DEBUG - 2010-07-07 17:20:51 --> Unit Testing Class Initialized
DEBUG - 2010-07-07 17:20:51 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-07 17:20:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:52 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:52 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:52 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:53 --> Helper loaded: email_helper
DEBUG - 2010-07-07 17:20:53 --> User Agent Class Initialized
DEBUG - 2010-07-07 17:20:53 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:53 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:54 --> Config file loaded: config/kals.php
DEBUG - 2010-07-07 17:20:54 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:54 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:54 --> Session Class Initialized
DEBUG - 2010-07-07 17:20:54 --> Helper loaded: string_helper
DEBUG - 2010-07-07 17:20:55 --> Session routines successfully run
DEBUG - 2010-07-07 17:20:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:55 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:55 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:56 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:56 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:56 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:56 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:56 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:56 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:57 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:57 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:57 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:58 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:58 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:58 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:58 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:58 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-07 17:20:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:59 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:20:59 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:00 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:00 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:00 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:00 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:00 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:01 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:01 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:01 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:01 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:01 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:01 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:02 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:02 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:02 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:02 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:02 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:02 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:02 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:03 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:03 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:03 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:03 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:03 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:03 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:04 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:04 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:04 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:05 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:05 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:05 --> Annotation_scope_collection class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:05 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:06 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:06 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:06 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:06 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:06 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:06 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:06 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:07 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:07 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:07 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:07 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:07 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-07 17:21:08 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-07 17:21:08 --> Final output sent to browser
DEBUG - 2010-07-07 17:21:09 --> Total execution time: 19.6456
