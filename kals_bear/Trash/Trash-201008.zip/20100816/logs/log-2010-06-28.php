<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2010-06-28 02:32:12 --> Config Class Initialized
DEBUG - 2010-06-28 02:32:12 --> Hooks Class Initialized
DEBUG - 2010-06-28 02:32:12 --> URI Class Initialized
DEBUG - 2010-06-28 02:32:12 --> Router Class Initialized
DEBUG - 2010-06-28 02:32:12 --> Output Class Initialized
DEBUG - 2010-06-28 02:32:12 --> Input Class Initialized
DEBUG - 2010-06-28 02:32:12 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 02:32:12 --> Language Class Initialized
DEBUG - 2010-06-28 02:32:12 --> Loader Class Initialized
DEBUG - 2010-06-28 02:32:12 --> Helper loaded: context_helper
DEBUG - 2010-06-28 02:32:12 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 02:32:12 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 02:32:12 --> Database Driver Class Initialized
DEBUG - 2010-06-28 02:32:12 --> Controller Class Initialized
DEBUG - 2010-06-28 02:32:12 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 02:32:12 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 02:32:12 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-06-28 02:33:27 --> Config Class Initialized
DEBUG - 2010-06-28 02:33:27 --> Hooks Class Initialized
DEBUG - 2010-06-28 02:33:27 --> URI Class Initialized
DEBUG - 2010-06-28 02:33:27 --> Router Class Initialized
DEBUG - 2010-06-28 02:33:27 --> Output Class Initialized
DEBUG - 2010-06-28 02:33:27 --> Input Class Initialized
DEBUG - 2010-06-28 02:33:27 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 02:33:27 --> Language Class Initialized
DEBUG - 2010-06-28 02:33:27 --> Loader Class Initialized
DEBUG - 2010-06-28 02:33:27 --> Helper loaded: context_helper
DEBUG - 2010-06-28 02:33:27 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 02:33:27 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 02:33:27 --> Database Driver Class Initialized
DEBUG - 2010-06-28 02:33:27 --> Controller Class Initialized
DEBUG - 2010-06-28 02:33:27 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 02:33:27 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 02:33:27 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-06-28 02:33:27 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php:443) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-28 02:33:54 --> Config Class Initialized
DEBUG - 2010-06-28 02:33:54 --> Hooks Class Initialized
DEBUG - 2010-06-28 02:33:54 --> URI Class Initialized
DEBUG - 2010-06-28 02:33:54 --> Router Class Initialized
DEBUG - 2010-06-28 02:33:54 --> Output Class Initialized
DEBUG - 2010-06-28 02:33:54 --> Input Class Initialized
DEBUG - 2010-06-28 02:33:54 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 02:33:54 --> Language Class Initialized
DEBUG - 2010-06-28 02:33:54 --> Loader Class Initialized
DEBUG - 2010-06-28 02:33:54 --> Helper loaded: context_helper
DEBUG - 2010-06-28 02:33:54 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 02:33:54 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 02:33:54 --> Database Driver Class Initialized
DEBUG - 2010-06-28 02:33:54 --> Controller Class Initialized
DEBUG - 2010-06-28 02:33:54 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 02:33:54 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 02:33:54 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-06-28 02:34:12 --> Config Class Initialized
DEBUG - 2010-06-28 02:34:12 --> Hooks Class Initialized
DEBUG - 2010-06-28 02:34:12 --> URI Class Initialized
DEBUG - 2010-06-28 02:34:12 --> Router Class Initialized
DEBUG - 2010-06-28 02:34:12 --> Output Class Initialized
DEBUG - 2010-06-28 02:34:13 --> Input Class Initialized
DEBUG - 2010-06-28 02:34:13 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 02:34:13 --> Language Class Initialized
DEBUG - 2010-06-28 02:34:13 --> Loader Class Initialized
DEBUG - 2010-06-28 02:34:13 --> Helper loaded: context_helper
DEBUG - 2010-06-28 02:34:13 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 02:34:13 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 02:34:13 --> Database Driver Class Initialized
DEBUG - 2010-06-28 02:34:13 --> Controller Class Initialized
DEBUG - 2010-06-28 02:34:13 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 02:34:13 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 02:34:13 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-06-28 02:34:13 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php:452) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-28 02:34:21 --> Config Class Initialized
DEBUG - 2010-06-28 02:34:21 --> Hooks Class Initialized
DEBUG - 2010-06-28 02:34:21 --> URI Class Initialized
DEBUG - 2010-06-28 02:34:21 --> Router Class Initialized
DEBUG - 2010-06-28 02:34:21 --> Output Class Initialized
DEBUG - 2010-06-28 02:34:21 --> Input Class Initialized
DEBUG - 2010-06-28 02:34:21 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 02:34:21 --> Language Class Initialized
DEBUG - 2010-06-28 02:34:21 --> Loader Class Initialized
DEBUG - 2010-06-28 02:34:21 --> Helper loaded: context_helper
DEBUG - 2010-06-28 02:34:21 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 02:34:21 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 02:34:21 --> Database Driver Class Initialized
DEBUG - 2010-06-28 02:34:21 --> Controller Class Initialized
DEBUG - 2010-06-28 02:34:21 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 02:34:21 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 02:34:21 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 02:34:21 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 02:34:21 --> Final output sent to browser
DEBUG - 2010-06-28 02:34:21 --> Total execution time: 0.1527
DEBUG - 2010-06-28 02:34:43 --> Config Class Initialized
DEBUG - 2010-06-28 02:34:43 --> Hooks Class Initialized
DEBUG - 2010-06-28 02:34:43 --> URI Class Initialized
DEBUG - 2010-06-28 02:34:43 --> Router Class Initialized
DEBUG - 2010-06-28 02:34:43 --> Output Class Initialized
DEBUG - 2010-06-28 02:34:43 --> Input Class Initialized
DEBUG - 2010-06-28 02:34:43 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 02:34:43 --> Language Class Initialized
DEBUG - 2010-06-28 02:34:43 --> Loader Class Initialized
DEBUG - 2010-06-28 02:34:43 --> Helper loaded: context_helper
DEBUG - 2010-06-28 02:34:43 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 02:34:43 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 02:34:43 --> Database Driver Class Initialized
DEBUG - 2010-06-28 02:34:43 --> Controller Class Initialized
DEBUG - 2010-06-28 02:34:44 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 02:34:44 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 02:34:44 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-06-28 02:34:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php:188) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-28 02:35:22 --> Config Class Initialized
DEBUG - 2010-06-28 02:35:22 --> Hooks Class Initialized
DEBUG - 2010-06-28 02:35:22 --> URI Class Initialized
DEBUG - 2010-06-28 02:35:22 --> Router Class Initialized
DEBUG - 2010-06-28 02:35:22 --> Output Class Initialized
DEBUG - 2010-06-28 02:35:22 --> Input Class Initialized
DEBUG - 2010-06-28 02:35:22 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 02:35:22 --> Language Class Initialized
DEBUG - 2010-06-28 02:35:22 --> Loader Class Initialized
DEBUG - 2010-06-28 02:35:22 --> Helper loaded: context_helper
DEBUG - 2010-06-28 02:35:22 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 02:35:22 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 02:35:22 --> Database Driver Class Initialized
DEBUG - 2010-06-28 02:35:22 --> Controller Class Initialized
DEBUG - 2010-06-28 02:35:22 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 02:35:22 --> Helper loaded: unit_test_helper
ERROR - 2010-06-28 02:35:22 --> Severity: Notice  --> Undefined property: stdClass::$id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 211
DEBUG - 2010-06-28 02:35:22 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 02:35:22 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 02:35:22 --> Final output sent to browser
DEBUG - 2010-06-28 02:35:22 --> Total execution time: 0.2481
DEBUG - 2010-06-28 02:36:11 --> Config Class Initialized
DEBUG - 2010-06-28 02:36:11 --> Hooks Class Initialized
DEBUG - 2010-06-28 02:36:11 --> URI Class Initialized
DEBUG - 2010-06-28 02:36:11 --> Router Class Initialized
DEBUG - 2010-06-28 02:36:11 --> Output Class Initialized
DEBUG - 2010-06-28 02:36:11 --> Input Class Initialized
DEBUG - 2010-06-28 02:36:11 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 02:36:11 --> Language Class Initialized
DEBUG - 2010-06-28 02:36:11 --> Loader Class Initialized
DEBUG - 2010-06-28 02:36:11 --> Helper loaded: context_helper
DEBUG - 2010-06-28 02:36:11 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 02:36:11 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 02:36:12 --> Database Driver Class Initialized
DEBUG - 2010-06-28 02:36:12 --> Controller Class Initialized
DEBUG - 2010-06-28 02:36:12 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 02:36:12 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 02:36:12 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 02:36:12 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 02:36:12 --> Final output sent to browser
DEBUG - 2010-06-28 02:36:12 --> Total execution time: 0.3253
DEBUG - 2010-06-28 02:36:36 --> Config Class Initialized
DEBUG - 2010-06-28 02:36:36 --> Hooks Class Initialized
DEBUG - 2010-06-28 02:36:36 --> URI Class Initialized
DEBUG - 2010-06-28 02:36:36 --> Router Class Initialized
DEBUG - 2010-06-28 02:36:36 --> Output Class Initialized
DEBUG - 2010-06-28 02:36:36 --> Input Class Initialized
DEBUG - 2010-06-28 02:36:36 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 02:36:36 --> Language Class Initialized
DEBUG - 2010-06-28 02:36:36 --> Loader Class Initialized
DEBUG - 2010-06-28 02:36:36 --> Helper loaded: context_helper
DEBUG - 2010-06-28 02:36:36 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 02:36:36 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 02:36:36 --> Database Driver Class Initialized
DEBUG - 2010-06-28 02:36:36 --> Controller Class Initialized
DEBUG - 2010-06-28 02:36:36 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 02:36:36 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 02:36:36 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 02:36:36 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 02:36:36 --> Final output sent to browser
DEBUG - 2010-06-28 02:36:36 --> Total execution time: 0.1862
DEBUG - 2010-06-28 02:38:28 --> Config Class Initialized
DEBUG - 2010-06-28 02:38:28 --> Hooks Class Initialized
DEBUG - 2010-06-28 02:38:28 --> URI Class Initialized
DEBUG - 2010-06-28 02:38:28 --> Router Class Initialized
DEBUG - 2010-06-28 02:38:28 --> Output Class Initialized
DEBUG - 2010-06-28 02:38:28 --> Input Class Initialized
DEBUG - 2010-06-28 02:38:28 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 02:38:28 --> Language Class Initialized
DEBUG - 2010-06-28 02:38:28 --> Loader Class Initialized
DEBUG - 2010-06-28 02:38:28 --> Helper loaded: context_helper
DEBUG - 2010-06-28 02:38:28 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 02:38:28 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 02:38:28 --> Database Driver Class Initialized
DEBUG - 2010-06-28 02:38:28 --> Controller Class Initialized
DEBUG - 2010-06-28 02:38:28 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 02:38:28 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 02:38:28 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 02:38:28 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 02:38:28 --> Final output sent to browser
DEBUG - 2010-06-28 02:38:28 --> Total execution time: 0.2484
DEBUG - 2010-06-28 02:39:00 --> Config Class Initialized
DEBUG - 2010-06-28 02:39:00 --> Hooks Class Initialized
DEBUG - 2010-06-28 02:39:00 --> URI Class Initialized
DEBUG - 2010-06-28 02:39:00 --> Router Class Initialized
DEBUG - 2010-06-28 02:39:00 --> Output Class Initialized
DEBUG - 2010-06-28 02:39:00 --> Input Class Initialized
DEBUG - 2010-06-28 02:39:00 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 02:39:00 --> Language Class Initialized
DEBUG - 2010-06-28 02:39:00 --> Loader Class Initialized
DEBUG - 2010-06-28 02:39:00 --> Helper loaded: context_helper
DEBUG - 2010-06-28 02:39:00 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 02:39:00 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 02:39:00 --> Database Driver Class Initialized
DEBUG - 2010-06-28 02:39:00 --> Controller Class Initialized
DEBUG - 2010-06-28 02:39:00 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 02:39:00 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 02:39:00 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 02:39:00 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 02:39:00 --> Final output sent to browser
DEBUG - 2010-06-28 02:39:00 --> Total execution time: 0.2120
DEBUG - 2010-06-28 02:39:16 --> Config Class Initialized
DEBUG - 2010-06-28 02:39:16 --> Hooks Class Initialized
DEBUG - 2010-06-28 02:39:16 --> URI Class Initialized
DEBUG - 2010-06-28 02:39:16 --> Router Class Initialized
DEBUG - 2010-06-28 02:39:16 --> Output Class Initialized
DEBUG - 2010-06-28 02:39:16 --> Input Class Initialized
DEBUG - 2010-06-28 02:39:16 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 02:39:16 --> Language Class Initialized
DEBUG - 2010-06-28 02:39:16 --> Loader Class Initialized
DEBUG - 2010-06-28 02:39:16 --> Helper loaded: context_helper
DEBUG - 2010-06-28 02:39:16 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 02:39:16 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 02:39:16 --> Database Driver Class Initialized
DEBUG - 2010-06-28 02:39:16 --> Controller Class Initialized
DEBUG - 2010-06-28 02:39:16 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 02:39:16 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 02:39:16 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 02:39:16 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 02:39:16 --> Final output sent to browser
DEBUG - 2010-06-28 02:39:16 --> Total execution time: 0.1957
DEBUG - 2010-06-28 02:39:29 --> Config Class Initialized
DEBUG - 2010-06-28 02:39:29 --> Hooks Class Initialized
DEBUG - 2010-06-28 02:39:29 --> URI Class Initialized
DEBUG - 2010-06-28 02:39:29 --> Router Class Initialized
DEBUG - 2010-06-28 02:39:29 --> Output Class Initialized
DEBUG - 2010-06-28 02:39:29 --> Input Class Initialized
DEBUG - 2010-06-28 02:39:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 02:39:29 --> Language Class Initialized
DEBUG - 2010-06-28 02:39:29 --> Loader Class Initialized
DEBUG - 2010-06-28 02:39:29 --> Helper loaded: context_helper
DEBUG - 2010-06-28 02:39:29 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 02:39:29 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 02:39:29 --> Database Driver Class Initialized
DEBUG - 2010-06-28 02:39:34 --> Config Class Initialized
DEBUG - 2010-06-28 02:39:34 --> Hooks Class Initialized
DEBUG - 2010-06-28 02:39:34 --> URI Class Initialized
DEBUG - 2010-06-28 02:39:34 --> Router Class Initialized
DEBUG - 2010-06-28 02:39:34 --> Output Class Initialized
DEBUG - 2010-06-28 02:39:34 --> Input Class Initialized
DEBUG - 2010-06-28 02:39:34 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 02:39:34 --> Language Class Initialized
DEBUG - 2010-06-28 02:39:34 --> Loader Class Initialized
DEBUG - 2010-06-28 02:39:34 --> Helper loaded: context_helper
DEBUG - 2010-06-28 02:39:34 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 02:39:34 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 02:39:34 --> Database Driver Class Initialized
DEBUG - 2010-06-28 02:39:34 --> Controller Class Initialized
DEBUG - 2010-06-28 02:39:34 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 02:39:34 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 02:39:34 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 02:39:34 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 02:39:34 --> Final output sent to browser
DEBUG - 2010-06-28 02:39:34 --> Total execution time: 0.2488
DEBUG - 2010-06-28 02:41:26 --> Config Class Initialized
DEBUG - 2010-06-28 02:41:26 --> Hooks Class Initialized
DEBUG - 2010-06-28 02:41:26 --> URI Class Initialized
DEBUG - 2010-06-28 02:41:26 --> Router Class Initialized
DEBUG - 2010-06-28 02:41:26 --> Output Class Initialized
DEBUG - 2010-06-28 02:41:26 --> Input Class Initialized
DEBUG - 2010-06-28 02:41:26 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 02:41:26 --> Language Class Initialized
DEBUG - 2010-06-28 02:41:26 --> Loader Class Initialized
DEBUG - 2010-06-28 02:41:26 --> Helper loaded: context_helper
DEBUG - 2010-06-28 02:41:26 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 02:41:26 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 02:41:26 --> Database Driver Class Initialized
DEBUG - 2010-06-28 02:41:26 --> Controller Class Initialized
DEBUG - 2010-06-28 02:41:26 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 02:41:26 --> Helper loaded: unit_test_helper
ERROR - 2010-06-28 02:41:26 --> Severity: Notice  --> Undefined variable: url D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 52
DEBUG - 2010-06-28 02:41:26 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 02:41:26 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 02:41:26 --> Final output sent to browser
DEBUG - 2010-06-28 02:41:26 --> Total execution time: 0.2628
DEBUG - 2010-06-28 02:48:07 --> Config Class Initialized
DEBUG - 2010-06-28 02:48:07 --> Hooks Class Initialized
DEBUG - 2010-06-28 02:48:08 --> URI Class Initialized
DEBUG - 2010-06-28 02:48:08 --> Router Class Initialized
DEBUG - 2010-06-28 02:48:08 --> Output Class Initialized
DEBUG - 2010-06-28 02:48:08 --> Input Class Initialized
DEBUG - 2010-06-28 02:48:08 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 02:48:08 --> Language Class Initialized
DEBUG - 2010-06-28 02:48:08 --> Loader Class Initialized
DEBUG - 2010-06-28 02:48:08 --> Helper loaded: context_helper
DEBUG - 2010-06-28 02:48:08 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 02:48:08 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 02:48:08 --> Database Driver Class Initialized
DEBUG - 2010-06-28 02:48:08 --> Controller Class Initialized
DEBUG - 2010-06-28 02:48:08 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 02:48:08 --> Helper loaded: unit_test_helper
ERROR - 2010-06-28 02:48:08 --> Severity: Notice  --> Undefined variable: host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 55
DEBUG - 2010-06-28 02:48:08 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 02:48:08 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 02:48:08 --> Final output sent to browser
DEBUG - 2010-06-28 02:48:08 --> Total execution time: 0.2992
DEBUG - 2010-06-28 02:48:20 --> Config Class Initialized
DEBUG - 2010-06-28 02:48:20 --> Hooks Class Initialized
DEBUG - 2010-06-28 02:48:20 --> URI Class Initialized
DEBUG - 2010-06-28 02:48:20 --> Router Class Initialized
DEBUG - 2010-06-28 02:48:20 --> Output Class Initialized
DEBUG - 2010-06-28 02:48:20 --> Input Class Initialized
DEBUG - 2010-06-28 02:48:20 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 02:48:20 --> Language Class Initialized
DEBUG - 2010-06-28 02:48:20 --> Loader Class Initialized
DEBUG - 2010-06-28 02:48:20 --> Helper loaded: context_helper
DEBUG - 2010-06-28 02:48:20 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 02:48:20 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 02:48:20 --> Database Driver Class Initialized
DEBUG - 2010-06-28 02:48:20 --> Controller Class Initialized
DEBUG - 2010-06-28 02:48:20 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 02:48:20 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 02:48:20 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 02:48:20 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 02:48:20 --> Final output sent to browser
DEBUG - 2010-06-28 02:48:20 --> Total execution time: 0.2415
DEBUG - 2010-06-28 02:48:32 --> Config Class Initialized
DEBUG - 2010-06-28 02:48:32 --> Hooks Class Initialized
DEBUG - 2010-06-28 02:48:32 --> URI Class Initialized
DEBUG - 2010-06-28 02:48:32 --> Router Class Initialized
DEBUG - 2010-06-28 02:48:32 --> Output Class Initialized
DEBUG - 2010-06-28 02:48:32 --> Input Class Initialized
DEBUG - 2010-06-28 02:48:32 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 02:48:32 --> Language Class Initialized
DEBUG - 2010-06-28 02:48:32 --> Loader Class Initialized
DEBUG - 2010-06-28 02:48:32 --> Helper loaded: context_helper
DEBUG - 2010-06-28 02:48:32 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 02:48:32 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 02:48:32 --> Database Driver Class Initialized
DEBUG - 2010-06-28 02:48:32 --> Controller Class Initialized
DEBUG - 2010-06-28 02:48:32 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 02:48:32 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 02:48:32 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 02:48:32 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 02:48:32 --> Final output sent to browser
DEBUG - 2010-06-28 02:48:32 --> Total execution time: 0.2551
DEBUG - 2010-06-28 02:48:35 --> Config Class Initialized
DEBUG - 2010-06-28 02:48:35 --> Hooks Class Initialized
DEBUG - 2010-06-28 02:48:35 --> URI Class Initialized
DEBUG - 2010-06-28 02:48:35 --> Router Class Initialized
DEBUG - 2010-06-28 02:48:35 --> Output Class Initialized
DEBUG - 2010-06-28 02:48:35 --> Input Class Initialized
DEBUG - 2010-06-28 02:48:35 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 02:48:35 --> Language Class Initialized
DEBUG - 2010-06-28 02:48:35 --> Loader Class Initialized
DEBUG - 2010-06-28 02:48:35 --> Helper loaded: context_helper
DEBUG - 2010-06-28 02:48:35 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 02:48:35 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 02:48:35 --> Database Driver Class Initialized
DEBUG - 2010-06-28 02:48:35 --> Controller Class Initialized
DEBUG - 2010-06-28 02:48:35 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 02:48:35 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 02:48:35 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 02:48:35 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 02:48:35 --> Final output sent to browser
DEBUG - 2010-06-28 02:48:35 --> Total execution time: 0.2654
DEBUG - 2010-06-28 02:48:42 --> Config Class Initialized
DEBUG - 2010-06-28 02:48:42 --> Hooks Class Initialized
DEBUG - 2010-06-28 02:48:42 --> URI Class Initialized
DEBUG - 2010-06-28 02:48:42 --> Router Class Initialized
DEBUG - 2010-06-28 02:48:43 --> Output Class Initialized
DEBUG - 2010-06-28 02:48:43 --> Input Class Initialized
DEBUG - 2010-06-28 02:48:43 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 02:48:43 --> Language Class Initialized
DEBUG - 2010-06-28 02:48:43 --> Loader Class Initialized
DEBUG - 2010-06-28 02:48:43 --> Helper loaded: context_helper
DEBUG - 2010-06-28 02:48:43 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 02:48:43 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 02:48:43 --> Database Driver Class Initialized
DEBUG - 2010-06-28 02:48:43 --> Controller Class Initialized
DEBUG - 2010-06-28 02:48:43 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 02:48:43 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 02:48:43 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 02:48:43 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 02:48:43 --> Final output sent to browser
DEBUG - 2010-06-28 02:48:43 --> Total execution time: 0.2649
DEBUG - 2010-06-28 02:48:47 --> Config Class Initialized
DEBUG - 2010-06-28 02:48:47 --> Hooks Class Initialized
DEBUG - 2010-06-28 02:48:47 --> URI Class Initialized
DEBUG - 2010-06-28 02:48:47 --> Router Class Initialized
DEBUG - 2010-06-28 02:48:47 --> Output Class Initialized
DEBUG - 2010-06-28 02:48:47 --> Input Class Initialized
DEBUG - 2010-06-28 02:48:47 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 02:48:47 --> Language Class Initialized
DEBUG - 2010-06-28 02:48:47 --> Loader Class Initialized
DEBUG - 2010-06-28 02:48:47 --> Helper loaded: context_helper
DEBUG - 2010-06-28 02:48:47 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 02:48:47 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 02:48:47 --> Database Driver Class Initialized
DEBUG - 2010-06-28 02:48:47 --> Controller Class Initialized
DEBUG - 2010-06-28 02:48:47 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 02:48:47 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 02:48:47 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 02:48:47 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 02:48:47 --> Final output sent to browser
DEBUG - 2010-06-28 02:48:47 --> Total execution time: 0.2823
DEBUG - 2010-06-28 02:55:53 --> Config Class Initialized
DEBUG - 2010-06-28 02:55:53 --> Hooks Class Initialized
DEBUG - 2010-06-28 02:55:53 --> URI Class Initialized
DEBUG - 2010-06-28 02:55:53 --> Router Class Initialized
DEBUG - 2010-06-28 02:55:53 --> Output Class Initialized
DEBUG - 2010-06-28 02:55:53 --> Input Class Initialized
DEBUG - 2010-06-28 02:55:53 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 02:55:53 --> Language Class Initialized
DEBUG - 2010-06-28 02:55:53 --> Loader Class Initialized
DEBUG - 2010-06-28 02:55:53 --> Helper loaded: context_helper
DEBUG - 2010-06-28 02:55:53 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 02:55:53 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 02:55:53 --> Database Driver Class Initialized
DEBUG - 2010-06-28 02:56:19 --> Config Class Initialized
DEBUG - 2010-06-28 02:56:19 --> Hooks Class Initialized
DEBUG - 2010-06-28 02:56:19 --> URI Class Initialized
DEBUG - 2010-06-28 02:56:19 --> Router Class Initialized
DEBUG - 2010-06-28 02:56:19 --> Output Class Initialized
DEBUG - 2010-06-28 02:56:19 --> Input Class Initialized
DEBUG - 2010-06-28 02:56:19 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 02:56:19 --> Language Class Initialized
DEBUG - 2010-06-28 02:56:19 --> Loader Class Initialized
DEBUG - 2010-06-28 02:56:19 --> Helper loaded: context_helper
DEBUG - 2010-06-28 02:56:19 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 02:56:19 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 02:56:19 --> Database Driver Class Initialized
DEBUG - 2010-06-28 02:56:19 --> Controller Class Initialized
DEBUG - 2010-06-28 02:56:19 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 02:56:19 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 02:56:19 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 02:56:19 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 02:56:19 --> Final output sent to browser
DEBUG - 2010-06-28 02:56:19 --> Total execution time: 0.3067
DEBUG - 2010-06-28 02:56:34 --> Config Class Initialized
DEBUG - 2010-06-28 02:56:34 --> Hooks Class Initialized
DEBUG - 2010-06-28 02:56:34 --> URI Class Initialized
DEBUG - 2010-06-28 02:56:34 --> Router Class Initialized
DEBUG - 2010-06-28 02:56:34 --> Output Class Initialized
DEBUG - 2010-06-28 02:56:34 --> Input Class Initialized
DEBUG - 2010-06-28 02:56:34 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 02:56:34 --> Language Class Initialized
DEBUG - 2010-06-28 02:56:34 --> Loader Class Initialized
DEBUG - 2010-06-28 02:56:34 --> Helper loaded: context_helper
DEBUG - 2010-06-28 02:56:34 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 02:56:34 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 02:56:34 --> Database Driver Class Initialized
DEBUG - 2010-06-28 02:56:34 --> Controller Class Initialized
DEBUG - 2010-06-28 02:56:34 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 02:56:34 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 02:57:02 --> Config Class Initialized
DEBUG - 2010-06-28 02:57:02 --> Hooks Class Initialized
DEBUG - 2010-06-28 02:57:02 --> URI Class Initialized
DEBUG - 2010-06-28 02:57:02 --> Router Class Initialized
DEBUG - 2010-06-28 02:57:02 --> Output Class Initialized
DEBUG - 2010-06-28 02:57:02 --> Input Class Initialized
DEBUG - 2010-06-28 02:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 02:57:02 --> Language Class Initialized
DEBUG - 2010-06-28 02:57:02 --> Loader Class Initialized
DEBUG - 2010-06-28 02:57:02 --> Helper loaded: context_helper
DEBUG - 2010-06-28 02:57:02 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 02:57:02 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 02:57:02 --> Database Driver Class Initialized
DEBUG - 2010-06-28 02:57:02 --> Controller Class Initialized
DEBUG - 2010-06-28 02:57:02 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 02:57:02 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 02:57:02 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 02:57:02 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 02:57:02 --> Final output sent to browser
DEBUG - 2010-06-28 02:57:02 --> Total execution time: 0.3130
DEBUG - 2010-06-28 02:58:40 --> Config Class Initialized
DEBUG - 2010-06-28 02:58:40 --> Hooks Class Initialized
DEBUG - 2010-06-28 02:58:40 --> URI Class Initialized
DEBUG - 2010-06-28 02:58:40 --> Router Class Initialized
DEBUG - 2010-06-28 02:58:40 --> Output Class Initialized
DEBUG - 2010-06-28 02:58:40 --> Input Class Initialized
DEBUG - 2010-06-28 02:58:40 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 02:58:40 --> Language Class Initialized
DEBUG - 2010-06-28 02:58:40 --> Loader Class Initialized
DEBUG - 2010-06-28 02:58:40 --> Helper loaded: context_helper
DEBUG - 2010-06-28 02:58:41 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 02:58:41 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 02:58:41 --> Database Driver Class Initialized
DEBUG - 2010-06-28 02:58:41 --> Controller Class Initialized
DEBUG - 2010-06-28 02:58:41 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 02:58:41 --> Helper loaded: unit_test_helper
ERROR - 2010-06-28 02:58:41 --> Severity: Warning  --> fopen(政治大學圖書館網站) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: Invalid argument D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 203
ERROR - 2010-06-28 02:58:41 --> Severity: Warning  --> fread(): supplied argument is not a valid stream resource D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 204
ERROR - 2010-06-28 02:58:41 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 205
DEBUG - 2010-06-28 02:58:41 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 02:58:41 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 02:58:41 --> Final output sent to browser
DEBUG - 2010-06-28 02:58:41 --> Total execution time: 1.0532
DEBUG - 2010-06-28 02:59:05 --> Config Class Initialized
DEBUG - 2010-06-28 02:59:05 --> Hooks Class Initialized
DEBUG - 2010-06-28 02:59:05 --> URI Class Initialized
DEBUG - 2010-06-28 02:59:05 --> Router Class Initialized
DEBUG - 2010-06-28 02:59:05 --> Output Class Initialized
DEBUG - 2010-06-28 02:59:05 --> Input Class Initialized
DEBUG - 2010-06-28 02:59:05 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 02:59:05 --> Language Class Initialized
DEBUG - 2010-06-28 02:59:05 --> Loader Class Initialized
DEBUG - 2010-06-28 02:59:05 --> Helper loaded: context_helper
DEBUG - 2010-06-28 02:59:05 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 02:59:05 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 02:59:05 --> Database Driver Class Initialized
DEBUG - 2010-06-28 02:59:05 --> Controller Class Initialized
DEBUG - 2010-06-28 02:59:05 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 02:59:06 --> Helper loaded: unit_test_helper
ERROR - 2010-06-28 02:59:06 --> Severity: Warning  --> fopen(政治大學圖書館網站) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: Invalid argument D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 203
ERROR - 2010-06-28 02:59:06 --> Severity: Warning  --> fread(): supplied argument is not a valid stream resource D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 204
ERROR - 2010-06-28 02:59:06 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 205
DEBUG - 2010-06-28 02:59:06 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 02:59:06 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 02:59:06 --> Final output sent to browser
DEBUG - 2010-06-28 02:59:06 --> Total execution time: 0.7451
DEBUG - 2010-06-28 02:59:28 --> Config Class Initialized
DEBUG - 2010-06-28 02:59:28 --> Hooks Class Initialized
DEBUG - 2010-06-28 02:59:28 --> URI Class Initialized
DEBUG - 2010-06-28 02:59:28 --> Router Class Initialized
DEBUG - 2010-06-28 02:59:28 --> Output Class Initialized
DEBUG - 2010-06-28 02:59:28 --> Input Class Initialized
DEBUG - 2010-06-28 02:59:28 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 02:59:28 --> Language Class Initialized
DEBUG - 2010-06-28 02:59:28 --> Loader Class Initialized
DEBUG - 2010-06-28 02:59:28 --> Helper loaded: context_helper
DEBUG - 2010-06-28 02:59:28 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 02:59:28 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 02:59:28 --> Database Driver Class Initialized
DEBUG - 2010-06-28 02:59:28 --> Controller Class Initialized
DEBUG - 2010-06-28 02:59:28 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 02:59:28 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 03:00:15 --> Config Class Initialized
DEBUG - 2010-06-28 03:00:15 --> Hooks Class Initialized
DEBUG - 2010-06-28 03:00:15 --> URI Class Initialized
DEBUG - 2010-06-28 03:00:15 --> Router Class Initialized
DEBUG - 2010-06-28 03:00:15 --> Output Class Initialized
DEBUG - 2010-06-28 03:00:15 --> Input Class Initialized
DEBUG - 2010-06-28 03:00:15 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 03:00:15 --> Language Class Initialized
DEBUG - 2010-06-28 03:00:15 --> Loader Class Initialized
DEBUG - 2010-06-28 03:00:15 --> Helper loaded: context_helper
DEBUG - 2010-06-28 03:00:15 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 03:00:15 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 03:00:15 --> Database Driver Class Initialized
DEBUG - 2010-06-28 03:00:15 --> Controller Class Initialized
DEBUG - 2010-06-28 03:00:16 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 03:00:16 --> Helper loaded: unit_test_helper
ERROR - 2010-06-28 03:00:16 --> Severity: 4096  --> Argument 2 passed to Generic_object::initialize() must be an instance of int, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php on line 37 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 102
DEBUG - 2010-06-28 03:00:16 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 03:00:16 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 03:00:16 --> Final output sent to browser
DEBUG - 2010-06-28 03:00:16 --> Total execution time: 0.3777
DEBUG - 2010-06-28 03:01:36 --> Config Class Initialized
DEBUG - 2010-06-28 03:01:36 --> Hooks Class Initialized
DEBUG - 2010-06-28 03:01:36 --> URI Class Initialized
DEBUG - 2010-06-28 03:01:36 --> Router Class Initialized
DEBUG - 2010-06-28 03:01:36 --> Output Class Initialized
DEBUG - 2010-06-28 03:01:36 --> Input Class Initialized
DEBUG - 2010-06-28 03:01:36 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 03:01:36 --> Language Class Initialized
DEBUG - 2010-06-28 03:01:36 --> Loader Class Initialized
DEBUG - 2010-06-28 03:01:36 --> Helper loaded: context_helper
DEBUG - 2010-06-28 03:01:36 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 03:01:36 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 03:01:36 --> Database Driver Class Initialized
DEBUG - 2010-06-28 03:01:36 --> Controller Class Initialized
DEBUG - 2010-06-28 03:01:36 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 03:01:36 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 03:01:36 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 03:01:36 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 03:01:36 --> Final output sent to browser
DEBUG - 2010-06-28 03:01:36 --> Total execution time: 0.4213
DEBUG - 2010-06-28 03:01:44 --> Config Class Initialized
DEBUG - 2010-06-28 03:01:44 --> Hooks Class Initialized
DEBUG - 2010-06-28 03:01:44 --> URI Class Initialized
DEBUG - 2010-06-28 03:01:45 --> Router Class Initialized
DEBUG - 2010-06-28 03:01:45 --> Output Class Initialized
DEBUG - 2010-06-28 03:01:45 --> Input Class Initialized
DEBUG - 2010-06-28 03:01:45 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 03:01:45 --> Language Class Initialized
DEBUG - 2010-06-28 03:01:45 --> Loader Class Initialized
DEBUG - 2010-06-28 03:01:45 --> Helper loaded: context_helper
DEBUG - 2010-06-28 03:01:45 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 03:01:45 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 03:01:45 --> Database Driver Class Initialized
DEBUG - 2010-06-28 03:01:45 --> Controller Class Initialized
DEBUG - 2010-06-28 03:01:45 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 03:01:45 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 03:03:03 --> Config Class Initialized
DEBUG - 2010-06-28 03:03:03 --> Hooks Class Initialized
DEBUG - 2010-06-28 03:03:03 --> URI Class Initialized
DEBUG - 2010-06-28 03:03:03 --> Router Class Initialized
DEBUG - 2010-06-28 03:03:03 --> Output Class Initialized
DEBUG - 2010-06-28 03:03:03 --> Input Class Initialized
DEBUG - 2010-06-28 03:03:03 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 03:03:03 --> Language Class Initialized
DEBUG - 2010-06-28 03:03:03 --> Loader Class Initialized
DEBUG - 2010-06-28 03:03:03 --> Helper loaded: context_helper
DEBUG - 2010-06-28 03:03:03 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 03:03:03 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 03:03:03 --> Database Driver Class Initialized
DEBUG - 2010-06-28 03:03:03 --> Controller Class Initialized
DEBUG - 2010-06-28 03:03:03 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 03:03:03 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 03:04:06 --> Config Class Initialized
DEBUG - 2010-06-28 03:04:06 --> Hooks Class Initialized
DEBUG - 2010-06-28 03:04:06 --> URI Class Initialized
DEBUG - 2010-06-28 03:04:06 --> Router Class Initialized
DEBUG - 2010-06-28 03:04:06 --> Output Class Initialized
DEBUG - 2010-06-28 03:04:06 --> Input Class Initialized
DEBUG - 2010-06-28 03:04:06 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 03:04:06 --> Language Class Initialized
DEBUG - 2010-06-28 03:04:06 --> Loader Class Initialized
DEBUG - 2010-06-28 03:04:06 --> Helper loaded: context_helper
DEBUG - 2010-06-28 03:04:06 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 03:04:06 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 03:04:06 --> Database Driver Class Initialized
DEBUG - 2010-06-28 03:04:06 --> Controller Class Initialized
DEBUG - 2010-06-28 03:04:06 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 03:04:06 --> Helper loaded: unit_test_helper
ERROR - 2010-06-28 03:04:07 --> Severity: Notice  --> Undefined index:  title D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 87
DEBUG - 2010-06-28 03:04:07 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 03:04:07 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 03:04:07 --> Final output sent to browser
DEBUG - 2010-06-28 03:04:07 --> Total execution time: 0.8476
DEBUG - 2010-06-28 03:05:58 --> Config Class Initialized
DEBUG - 2010-06-28 03:05:58 --> Hooks Class Initialized
DEBUG - 2010-06-28 03:05:58 --> URI Class Initialized
DEBUG - 2010-06-28 03:05:58 --> Router Class Initialized
DEBUG - 2010-06-28 03:05:58 --> Output Class Initialized
DEBUG - 2010-06-28 03:05:58 --> Input Class Initialized
DEBUG - 2010-06-28 03:05:58 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 03:05:58 --> Language Class Initialized
DEBUG - 2010-06-28 03:05:58 --> Loader Class Initialized
DEBUG - 2010-06-28 03:05:58 --> Helper loaded: context_helper
DEBUG - 2010-06-28 03:05:58 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 03:05:59 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 03:05:59 --> Database Driver Class Initialized
DEBUG - 2010-06-28 03:05:59 --> Controller Class Initialized
DEBUG - 2010-06-28 03:05:59 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 03:05:59 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 03:05:59 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 03:05:59 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 03:05:59 --> Final output sent to browser
DEBUG - 2010-06-28 03:05:59 --> Total execution time: 0.7491
DEBUG - 2010-06-28 03:06:07 --> Config Class Initialized
DEBUG - 2010-06-28 03:06:07 --> Hooks Class Initialized
DEBUG - 2010-06-28 03:06:07 --> URI Class Initialized
DEBUG - 2010-06-28 03:06:07 --> Router Class Initialized
DEBUG - 2010-06-28 03:06:07 --> Output Class Initialized
DEBUG - 2010-06-28 03:06:07 --> Input Class Initialized
DEBUG - 2010-06-28 03:06:07 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 03:06:07 --> Language Class Initialized
DEBUG - 2010-06-28 03:06:07 --> Loader Class Initialized
DEBUG - 2010-06-28 03:06:07 --> Helper loaded: context_helper
DEBUG - 2010-06-28 03:06:07 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 03:06:07 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 03:06:07 --> Database Driver Class Initialized
DEBUG - 2010-06-28 03:06:07 --> Controller Class Initialized
DEBUG - 2010-06-28 03:06:07 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 03:06:07 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 03:06:08 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 03:06:08 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 03:06:08 --> Final output sent to browser
DEBUG - 2010-06-28 03:06:08 --> Total execution time: 0.7934
DEBUG - 2010-06-28 03:10:59 --> Config Class Initialized
DEBUG - 2010-06-28 03:10:59 --> Hooks Class Initialized
DEBUG - 2010-06-28 03:10:59 --> URI Class Initialized
DEBUG - 2010-06-28 03:10:59 --> Router Class Initialized
DEBUG - 2010-06-28 03:10:59 --> Output Class Initialized
DEBUG - 2010-06-28 03:10:59 --> Input Class Initialized
DEBUG - 2010-06-28 03:10:59 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 03:10:59 --> Language Class Initialized
DEBUG - 2010-06-28 03:10:59 --> Loader Class Initialized
DEBUG - 2010-06-28 03:10:59 --> Helper loaded: context_helper
DEBUG - 2010-06-28 03:10:59 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 03:10:59 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 03:10:59 --> Database Driver Class Initialized
DEBUG - 2010-06-28 03:10:59 --> Controller Class Initialized
DEBUG - 2010-06-28 03:10:59 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 03:10:59 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 03:10:59 --> Session Class Initialized
DEBUG - 2010-06-28 03:10:59 --> Helper loaded: string_helper
DEBUG - 2010-06-28 03:10:59 --> A session cookie was not found.
DEBUG - 2010-06-28 03:10:59 --> Session routines successfully run
DEBUG - 2010-06-28 03:11:00 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-28 03:11:00 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  unterminated quoted identifier at or near &quot;&quot;&quot;
LINE 3: WHERE &quot;
              ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-28 03:11:00 --> DB Transaction Failure
ERROR - 2010-06-28 03:11:00 --> Query error: ERROR:  unterminated quoted identifier at or near """
LINE 3: WHERE "
              ^
DEBUG - 2010-06-28 03:11:00 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-06-28 03:12:59 --> Config Class Initialized
DEBUG - 2010-06-28 03:12:59 --> Hooks Class Initialized
DEBUG - 2010-06-28 03:12:59 --> URI Class Initialized
DEBUG - 2010-06-28 03:12:59 --> Router Class Initialized
DEBUG - 2010-06-28 03:12:59 --> Output Class Initialized
DEBUG - 2010-06-28 03:12:59 --> Input Class Initialized
DEBUG - 2010-06-28 03:12:59 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 03:12:59 --> Language Class Initialized
DEBUG - 2010-06-28 03:12:59 --> Loader Class Initialized
DEBUG - 2010-06-28 03:12:59 --> Helper loaded: context_helper
DEBUG - 2010-06-28 03:12:59 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 03:12:59 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 03:12:59 --> Database Driver Class Initialized
DEBUG - 2010-06-28 03:12:59 --> Controller Class Initialized
DEBUG - 2010-06-28 03:12:59 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 03:12:59 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 03:12:59 --> Session Class Initialized
DEBUG - 2010-06-28 03:12:59 --> Helper loaded: string_helper
DEBUG - 2010-06-28 03:12:59 --> Session routines successfully run
DEBUG - 2010-06-28 03:13:00 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-28 03:13:00 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;url&quot; does not exist
LINE 3: WHERE &quot;url&quot; = 'http://www.lib.nccu.edu.tw/?m=1109&amp;sn=54&amp;id=9...
              ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-28 03:13:00 --> DB Transaction Failure
ERROR - 2010-06-28 03:13:00 --> Query error: ERROR:  column "url" does not exist
LINE 3: WHERE "url" = 'http://www.lib.nccu.edu.tw/?m=1109&sn=54&id=9...
              ^
DEBUG - 2010-06-28 03:13:00 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-06-28 03:13:27 --> Config Class Initialized
DEBUG - 2010-06-28 03:13:27 --> Hooks Class Initialized
DEBUG - 2010-06-28 03:13:27 --> URI Class Initialized
DEBUG - 2010-06-28 03:13:27 --> Router Class Initialized
DEBUG - 2010-06-28 03:13:27 --> Output Class Initialized
DEBUG - 2010-06-28 03:13:27 --> Input Class Initialized
DEBUG - 2010-06-28 03:13:27 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 03:13:27 --> Language Class Initialized
DEBUG - 2010-06-28 03:13:27 --> Loader Class Initialized
DEBUG - 2010-06-28 03:13:27 --> Helper loaded: context_helper
DEBUG - 2010-06-28 03:13:27 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 03:13:27 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 03:13:27 --> Database Driver Class Initialized
DEBUG - 2010-06-28 03:13:27 --> Controller Class Initialized
DEBUG - 2010-06-28 03:13:27 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 03:13:27 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 03:13:27 --> Session Class Initialized
DEBUG - 2010-06-28 03:13:27 --> Helper loaded: string_helper
DEBUG - 2010-06-28 03:13:27 --> Session routines successfully run
DEBUG - 2010-06-28 03:13:28 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-28 03:13:28 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;url&quot; does not exist
LINE 3: WHERE &quot;url&quot; = 'http://www.lib.nccu.edu.tw/?m=1109&amp;sn=54&amp;id=9...
              ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-28 03:13:28 --> DB Transaction Failure
ERROR - 2010-06-28 03:13:28 --> Query error: ERROR:  column "url" does not exist
LINE 3: WHERE "url" = 'http://www.lib.nccu.edu.tw/?m=1109&sn=54&id=9...
              ^
DEBUG - 2010-06-28 03:13:28 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-06-28 03:13:28 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php:61) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-28 03:15:36 --> Config Class Initialized
DEBUG - 2010-06-28 03:15:37 --> Hooks Class Initialized
DEBUG - 2010-06-28 03:15:37 --> URI Class Initialized
DEBUG - 2010-06-28 03:15:37 --> Router Class Initialized
DEBUG - 2010-06-28 03:15:37 --> Output Class Initialized
DEBUG - 2010-06-28 03:15:37 --> Input Class Initialized
DEBUG - 2010-06-28 03:15:37 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 03:15:37 --> Language Class Initialized
DEBUG - 2010-06-28 03:15:37 --> Loader Class Initialized
DEBUG - 2010-06-28 03:15:37 --> Helper loaded: context_helper
DEBUG - 2010-06-28 03:15:37 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 03:15:37 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 03:15:37 --> Database Driver Class Initialized
DEBUG - 2010-06-28 03:15:37 --> Controller Class Initialized
DEBUG - 2010-06-28 03:15:37 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 03:15:37 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 03:15:37 --> Session Class Initialized
DEBUG - 2010-06-28 03:15:37 --> Helper loaded: string_helper
DEBUG - 2010-06-28 03:15:37 --> Session routines successfully run
DEBUG - 2010-06-28 03:15:37 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-06-28 05:03:26 --> Config Class Initialized
DEBUG - 2010-06-28 05:03:26 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:03:26 --> URI Class Initialized
DEBUG - 2010-06-28 05:03:26 --> Router Class Initialized
DEBUG - 2010-06-28 05:03:26 --> Output Class Initialized
DEBUG - 2010-06-28 05:03:26 --> Input Class Initialized
DEBUG - 2010-06-28 05:03:26 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:03:26 --> Language Class Initialized
DEBUG - 2010-06-28 05:03:26 --> Loader Class Initialized
DEBUG - 2010-06-28 05:03:26 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:03:26 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:03:26 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:03:27 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:03:27 --> Controller Class Initialized
DEBUG - 2010-06-28 05:03:27 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:03:27 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:03:27 --> Session Class Initialized
DEBUG - 2010-06-28 05:03:27 --> Helper loaded: string_helper
DEBUG - 2010-06-28 05:03:27 --> Session routines successfully run
DEBUG - 2010-06-28 05:03:27 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-06-28 05:09:43 --> Config Class Initialized
DEBUG - 2010-06-28 05:09:43 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:09:43 --> URI Class Initialized
DEBUG - 2010-06-28 05:09:43 --> Router Class Initialized
DEBUG - 2010-06-28 05:09:43 --> Output Class Initialized
DEBUG - 2010-06-28 05:09:43 --> Input Class Initialized
DEBUG - 2010-06-28 05:09:43 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:09:43 --> Language Class Initialized
DEBUG - 2010-06-28 05:09:43 --> Loader Class Initialized
DEBUG - 2010-06-28 05:09:43 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:09:43 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:09:43 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:09:43 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:09:43 --> Controller Class Initialized
DEBUG - 2010-06-28 05:09:43 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:09:44 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:09:44 --> Session Class Initialized
DEBUG - 2010-06-28 05:09:44 --> Helper loaded: string_helper
DEBUG - 2010-06-28 05:09:44 --> Session routines successfully run
DEBUG - 2010-06-28 05:09:44 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-06-28 05:10:10 --> Config Class Initialized
DEBUG - 2010-06-28 05:10:11 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:10:11 --> URI Class Initialized
DEBUG - 2010-06-28 05:10:11 --> Router Class Initialized
DEBUG - 2010-06-28 05:10:11 --> Output Class Initialized
DEBUG - 2010-06-28 05:10:11 --> Input Class Initialized
DEBUG - 2010-06-28 05:10:11 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:10:11 --> Language Class Initialized
DEBUG - 2010-06-28 05:10:11 --> Loader Class Initialized
DEBUG - 2010-06-28 05:10:11 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:10:11 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:10:11 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:10:11 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:10:11 --> Controller Class Initialized
DEBUG - 2010-06-28 05:10:11 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:10:11 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:10:11 --> Session Class Initialized
DEBUG - 2010-06-28 05:10:11 --> Helper loaded: string_helper
DEBUG - 2010-06-28 05:10:11 --> Session routines successfully run
DEBUG - 2010-06-28 05:10:11 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-06-28 05:10:47 --> Config Class Initialized
DEBUG - 2010-06-28 05:10:47 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:10:47 --> URI Class Initialized
DEBUG - 2010-06-28 05:10:47 --> Router Class Initialized
DEBUG - 2010-06-28 05:10:47 --> Output Class Initialized
DEBUG - 2010-06-28 05:10:47 --> Input Class Initialized
DEBUG - 2010-06-28 05:10:47 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:10:47 --> Language Class Initialized
DEBUG - 2010-06-28 05:10:47 --> Loader Class Initialized
DEBUG - 2010-06-28 05:10:47 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:10:47 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:10:47 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:10:47 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:10:47 --> Controller Class Initialized
DEBUG - 2010-06-28 05:10:47 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:10:47 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:10:47 --> Session Class Initialized
DEBUG - 2010-06-28 05:10:47 --> Helper loaded: string_helper
DEBUG - 2010-06-28 05:10:47 --> Session routines successfully run
DEBUG - 2010-06-28 05:10:48 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 05:10:48 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 05:10:48 --> Final output sent to browser
DEBUG - 2010-06-28 05:10:48 --> Total execution time: 1.4247
DEBUG - 2010-06-28 05:12:07 --> Config Class Initialized
DEBUG - 2010-06-28 05:12:07 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:12:07 --> URI Class Initialized
DEBUG - 2010-06-28 05:12:07 --> Router Class Initialized
DEBUG - 2010-06-28 05:12:07 --> Output Class Initialized
DEBUG - 2010-06-28 05:12:07 --> Input Class Initialized
DEBUG - 2010-06-28 05:12:07 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:12:07 --> Language Class Initialized
DEBUG - 2010-06-28 05:12:07 --> Loader Class Initialized
DEBUG - 2010-06-28 05:12:07 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:12:07 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:12:07 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:12:07 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:12:07 --> Controller Class Initialized
DEBUG - 2010-06-28 05:12:08 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:12:08 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:12:08 --> Session Class Initialized
DEBUG - 2010-06-28 05:12:08 --> Helper loaded: string_helper
DEBUG - 2010-06-28 05:12:08 --> Session routines successfully run
DEBUG - 2010-06-28 05:12:08 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 05:12:08 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 05:12:09 --> Final output sent to browser
DEBUG - 2010-06-28 05:12:09 --> Total execution time: 1.4349
DEBUG - 2010-06-28 05:12:27 --> Config Class Initialized
DEBUG - 2010-06-28 05:12:28 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:12:28 --> URI Class Initialized
DEBUG - 2010-06-28 05:12:28 --> Router Class Initialized
DEBUG - 2010-06-28 05:12:28 --> Output Class Initialized
DEBUG - 2010-06-28 05:12:28 --> Input Class Initialized
DEBUG - 2010-06-28 05:12:28 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:12:28 --> Language Class Initialized
DEBUG - 2010-06-28 05:12:28 --> Loader Class Initialized
DEBUG - 2010-06-28 05:12:28 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:12:28 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:12:28 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:12:28 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:12:28 --> Controller Class Initialized
DEBUG - 2010-06-28 05:12:28 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:12:28 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:12:28 --> Session Class Initialized
DEBUG - 2010-06-28 05:12:28 --> Helper loaded: string_helper
DEBUG - 2010-06-28 05:12:28 --> Session routines successfully run
DEBUG - 2010-06-28 05:12:29 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 05:12:29 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 05:12:29 --> Final output sent to browser
DEBUG - 2010-06-28 05:12:29 --> Total execution time: 1.3735
DEBUG - 2010-06-28 05:12:53 --> Config Class Initialized
DEBUG - 2010-06-28 05:12:53 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:12:53 --> URI Class Initialized
DEBUG - 2010-06-28 05:12:53 --> Router Class Initialized
DEBUG - 2010-06-28 05:12:53 --> Output Class Initialized
DEBUG - 2010-06-28 05:12:53 --> Input Class Initialized
DEBUG - 2010-06-28 05:12:53 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:12:53 --> Language Class Initialized
DEBUG - 2010-06-28 05:12:54 --> Loader Class Initialized
DEBUG - 2010-06-28 05:12:54 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:12:54 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:12:54 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:12:54 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:12:54 --> Controller Class Initialized
DEBUG - 2010-06-28 05:12:54 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:12:54 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:12:54 --> Session Class Initialized
DEBUG - 2010-06-28 05:12:54 --> Helper loaded: string_helper
DEBUG - 2010-06-28 05:12:54 --> Session routines successfully run
DEBUG - 2010-06-28 05:12:55 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 05:12:55 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 05:12:55 --> Final output sent to browser
DEBUG - 2010-06-28 05:12:55 --> Total execution time: 1.7164
DEBUG - 2010-06-28 05:15:11 --> Config Class Initialized
DEBUG - 2010-06-28 05:15:11 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:15:11 --> URI Class Initialized
DEBUG - 2010-06-28 05:15:11 --> Router Class Initialized
DEBUG - 2010-06-28 05:15:11 --> Output Class Initialized
DEBUG - 2010-06-28 05:15:11 --> Input Class Initialized
DEBUG - 2010-06-28 05:15:11 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:15:11 --> Language Class Initialized
DEBUG - 2010-06-28 05:15:11 --> Loader Class Initialized
DEBUG - 2010-06-28 05:15:11 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:15:11 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:15:11 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:15:11 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:15:11 --> Controller Class Initialized
DEBUG - 2010-06-28 05:15:11 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:15:11 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:15:11 --> Session Class Initialized
DEBUG - 2010-06-28 05:15:11 --> Helper loaded: string_helper
DEBUG - 2010-06-28 05:15:11 --> Session routines successfully run
DEBUG - 2010-06-28 05:15:12 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 05:15:12 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 05:15:12 --> Final output sent to browser
DEBUG - 2010-06-28 05:15:12 --> Total execution time: 1.5625
DEBUG - 2010-06-28 05:16:07 --> Config Class Initialized
DEBUG - 2010-06-28 05:16:07 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:16:07 --> URI Class Initialized
DEBUG - 2010-06-28 05:16:07 --> Router Class Initialized
DEBUG - 2010-06-28 05:16:07 --> Output Class Initialized
DEBUG - 2010-06-28 05:16:07 --> Input Class Initialized
DEBUG - 2010-06-28 05:16:07 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:16:07 --> Language Class Initialized
DEBUG - 2010-06-28 05:16:07 --> Loader Class Initialized
DEBUG - 2010-06-28 05:16:07 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:16:07 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:16:07 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:16:07 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:16:07 --> Controller Class Initialized
DEBUG - 2010-06-28 05:16:07 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:16:07 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:16:07 --> Session Class Initialized
DEBUG - 2010-06-28 05:16:07 --> Helper loaded: string_helper
DEBUG - 2010-06-28 05:16:07 --> Session routines successfully run
DEBUG - 2010-06-28 05:16:08 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 05:16:08 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 05:16:08 --> Final output sent to browser
DEBUG - 2010-06-28 05:16:08 --> Total execution time: 0.9980
DEBUG - 2010-06-28 05:18:13 --> Config Class Initialized
DEBUG - 2010-06-28 05:18:13 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:18:13 --> URI Class Initialized
DEBUG - 2010-06-28 05:18:13 --> Router Class Initialized
DEBUG - 2010-06-28 05:18:13 --> Output Class Initialized
DEBUG - 2010-06-28 05:18:13 --> Input Class Initialized
DEBUG - 2010-06-28 05:18:13 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:18:13 --> Language Class Initialized
DEBUG - 2010-06-28 05:18:13 --> Loader Class Initialized
DEBUG - 2010-06-28 05:18:13 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:18:13 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:18:13 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:18:13 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:18:13 --> Controller Class Initialized
DEBUG - 2010-06-28 05:18:13 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:18:13 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:18:13 --> Session Class Initialized
DEBUG - 2010-06-28 05:18:13 --> Helper loaded: string_helper
DEBUG - 2010-06-28 05:18:14 --> Session routines successfully run
DEBUG - 2010-06-28 05:18:14 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 05:18:14 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 05:18:14 --> Final output sent to browser
DEBUG - 2010-06-28 05:18:14 --> Total execution time: 1.3079
DEBUG - 2010-06-28 05:18:44 --> Config Class Initialized
DEBUG - 2010-06-28 05:18:44 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:18:44 --> URI Class Initialized
DEBUG - 2010-06-28 05:18:44 --> Router Class Initialized
DEBUG - 2010-06-28 05:18:44 --> Output Class Initialized
DEBUG - 2010-06-28 05:18:44 --> Input Class Initialized
DEBUG - 2010-06-28 05:18:44 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:18:44 --> Language Class Initialized
DEBUG - 2010-06-28 05:18:44 --> Loader Class Initialized
DEBUG - 2010-06-28 05:18:44 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:18:44 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:18:44 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:18:45 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:18:45 --> Controller Class Initialized
DEBUG - 2010-06-28 05:18:45 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:18:45 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:18:45 --> Session Class Initialized
DEBUG - 2010-06-28 05:18:45 --> Helper loaded: string_helper
DEBUG - 2010-06-28 05:18:45 --> Session routines successfully run
DEBUG - 2010-06-28 05:18:45 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 05:18:45 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 05:18:45 --> Final output sent to browser
DEBUG - 2010-06-28 05:18:45 --> Total execution time: 1.3156
DEBUG - 2010-06-28 05:21:35 --> Config Class Initialized
DEBUG - 2010-06-28 05:21:36 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:21:36 --> URI Class Initialized
DEBUG - 2010-06-28 05:21:36 --> Router Class Initialized
DEBUG - 2010-06-28 05:21:36 --> Output Class Initialized
DEBUG - 2010-06-28 05:21:36 --> Input Class Initialized
DEBUG - 2010-06-28 05:21:36 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:21:36 --> Language Class Initialized
DEBUG - 2010-06-28 05:21:36 --> Loader Class Initialized
DEBUG - 2010-06-28 05:21:36 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:21:36 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:21:36 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:21:36 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:21:36 --> Controller Class Initialized
DEBUG - 2010-06-28 05:21:36 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:21:36 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:21:36 --> Session Class Initialized
DEBUG - 2010-06-28 05:21:36 --> Helper loaded: string_helper
DEBUG - 2010-06-28 05:21:36 --> Session routines successfully run
ERROR - 2010-06-28 05:21:36 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 408
ERROR - 2010-06-28 05:21:36 --> Severity: Notice  --> Undefined index:  title D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 92
ERROR - 2010-06-28 05:21:37 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 408
ERROR - 2010-06-28 05:21:37 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 408
ERROR - 2010-06-28 05:21:37 --> Severity: Notice  --> Undefined index:  title D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 92
ERROR - 2010-06-28 05:21:37 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 408
DEBUG - 2010-06-28 05:21:37 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 05:21:37 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 05:21:37 --> Final output sent to browser
DEBUG - 2010-06-28 05:21:37 --> Total execution time: 1.6088
DEBUG - 2010-06-28 05:25:09 --> Config Class Initialized
DEBUG - 2010-06-28 05:25:09 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:25:09 --> URI Class Initialized
DEBUG - 2010-06-28 05:25:10 --> Router Class Initialized
DEBUG - 2010-06-28 05:25:10 --> Output Class Initialized
DEBUG - 2010-06-28 05:25:10 --> Input Class Initialized
DEBUG - 2010-06-28 05:25:10 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:25:10 --> Language Class Initialized
DEBUG - 2010-06-28 05:25:10 --> Loader Class Initialized
DEBUG - 2010-06-28 05:25:10 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:25:10 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:25:10 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:25:10 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:25:10 --> Controller Class Initialized
DEBUG - 2010-06-28 05:25:10 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:25:10 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:25:10 --> Session Class Initialized
DEBUG - 2010-06-28 05:25:10 --> Helper loaded: string_helper
DEBUG - 2010-06-28 05:25:10 --> Session routines successfully run
ERROR - 2010-06-28 05:25:10 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 408
ERROR - 2010-06-28 05:25:10 --> Severity: Notice  --> Undefined index:  title D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 92
ERROR - 2010-06-28 05:25:10 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 408
ERROR - 2010-06-28 05:25:10 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 408
ERROR - 2010-06-28 05:25:11 --> Severity: Notice  --> Undefined index:  title D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 92
ERROR - 2010-06-28 05:25:11 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 408
DEBUG - 2010-06-28 05:25:11 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 05:25:11 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 05:25:11 --> Final output sent to browser
DEBUG - 2010-06-28 05:25:11 --> Total execution time: 1.6352
DEBUG - 2010-06-28 05:26:17 --> Config Class Initialized
DEBUG - 2010-06-28 05:26:17 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:26:17 --> URI Class Initialized
DEBUG - 2010-06-28 05:26:17 --> Router Class Initialized
DEBUG - 2010-06-28 05:26:17 --> Output Class Initialized
DEBUG - 2010-06-28 05:26:17 --> Input Class Initialized
DEBUG - 2010-06-28 05:26:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:26:18 --> Language Class Initialized
DEBUG - 2010-06-28 05:26:18 --> Loader Class Initialized
DEBUG - 2010-06-28 05:26:18 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:26:18 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:26:18 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:26:18 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:26:18 --> Controller Class Initialized
DEBUG - 2010-06-28 05:26:18 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:26:18 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:26:18 --> Session Class Initialized
DEBUG - 2010-06-28 05:26:18 --> Helper loaded: string_helper
DEBUG - 2010-06-28 05:26:18 --> Session routines successfully run
ERROR - 2010-06-28 05:26:18 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 408
ERROR - 2010-06-28 05:26:18 --> Severity: Notice  --> Undefined index:  title D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 92
ERROR - 2010-06-28 05:26:18 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 408
ERROR - 2010-06-28 05:26:18 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 408
ERROR - 2010-06-28 05:26:18 --> Severity: Notice  --> Undefined index:  title D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 92
ERROR - 2010-06-28 05:26:19 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 408
DEBUG - 2010-06-28 05:26:19 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 05:26:19 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 05:26:19 --> Final output sent to browser
DEBUG - 2010-06-28 05:26:19 --> Total execution time: 1.6669
DEBUG - 2010-06-28 05:26:39 --> Config Class Initialized
DEBUG - 2010-06-28 05:26:39 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:26:39 --> URI Class Initialized
DEBUG - 2010-06-28 05:26:39 --> Router Class Initialized
DEBUG - 2010-06-28 05:26:39 --> Output Class Initialized
DEBUG - 2010-06-28 05:26:39 --> Input Class Initialized
DEBUG - 2010-06-28 05:26:39 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:26:39 --> Language Class Initialized
DEBUG - 2010-06-28 05:26:39 --> Loader Class Initialized
DEBUG - 2010-06-28 05:26:39 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:26:39 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:26:39 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:26:39 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:26:39 --> Controller Class Initialized
DEBUG - 2010-06-28 05:26:39 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:26:39 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:26:39 --> Session Class Initialized
DEBUG - 2010-06-28 05:26:39 --> Helper loaded: string_helper
DEBUG - 2010-06-28 05:26:39 --> Session routines successfully run
ERROR - 2010-06-28 05:26:39 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 407
ERROR - 2010-06-28 05:26:39 --> Severity: Notice  --> Undefined index:  title D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 91
ERROR - 2010-06-28 05:26:40 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 407
ERROR - 2010-06-28 05:26:40 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 407
ERROR - 2010-06-28 05:26:40 --> Severity: Notice  --> Undefined index:  title D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 91
ERROR - 2010-06-28 05:26:40 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 407
DEBUG - 2010-06-28 05:26:40 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 05:26:40 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 05:26:40 --> Final output sent to browser
DEBUG - 2010-06-28 05:26:40 --> Total execution time: 1.5639
DEBUG - 2010-06-28 05:26:54 --> Config Class Initialized
DEBUG - 2010-06-28 05:26:54 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:26:54 --> URI Class Initialized
DEBUG - 2010-06-28 05:26:54 --> Router Class Initialized
DEBUG - 2010-06-28 05:26:55 --> Output Class Initialized
DEBUG - 2010-06-28 05:26:55 --> Input Class Initialized
DEBUG - 2010-06-28 05:26:55 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:26:55 --> Language Class Initialized
DEBUG - 2010-06-28 05:26:55 --> Loader Class Initialized
DEBUG - 2010-06-28 05:26:55 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:26:55 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:26:55 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:26:55 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:26:55 --> Controller Class Initialized
DEBUG - 2010-06-28 05:26:55 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:26:55 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:26:55 --> Session Class Initialized
DEBUG - 2010-06-28 05:26:55 --> Helper loaded: string_helper
DEBUG - 2010-06-28 05:26:55 --> Session routines successfully run
ERROR - 2010-06-28 05:26:55 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 408
ERROR - 2010-06-28 05:26:55 --> Severity: Notice  --> Undefined index:  title D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 92
ERROR - 2010-06-28 05:26:55 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 408
ERROR - 2010-06-28 05:26:55 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 408
ERROR - 2010-06-28 05:26:55 --> Severity: Notice  --> Undefined index:  title D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 92
ERROR - 2010-06-28 05:26:56 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 408
DEBUG - 2010-06-28 05:26:56 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 05:26:56 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 05:26:56 --> Final output sent to browser
DEBUG - 2010-06-28 05:26:56 --> Total execution time: 1.5944
DEBUG - 2010-06-28 05:28:04 --> Config Class Initialized
DEBUG - 2010-06-28 05:28:04 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:28:04 --> URI Class Initialized
DEBUG - 2010-06-28 05:28:04 --> Router Class Initialized
DEBUG - 2010-06-28 05:28:04 --> Output Class Initialized
DEBUG - 2010-06-28 05:28:04 --> Input Class Initialized
DEBUG - 2010-06-28 05:28:04 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:28:04 --> Language Class Initialized
DEBUG - 2010-06-28 05:28:04 --> Loader Class Initialized
DEBUG - 2010-06-28 05:28:04 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:28:04 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:28:04 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:28:04 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:28:05 --> Controller Class Initialized
DEBUG - 2010-06-28 05:28:05 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:28:05 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:28:05 --> Session Class Initialized
DEBUG - 2010-06-28 05:28:05 --> Helper loaded: string_helper
DEBUG - 2010-06-28 05:28:05 --> Session routines successfully run
DEBUG - 2010-06-28 05:29:02 --> Config Class Initialized
DEBUG - 2010-06-28 05:29:02 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:29:02 --> URI Class Initialized
DEBUG - 2010-06-28 05:29:03 --> Router Class Initialized
DEBUG - 2010-06-28 05:29:03 --> Output Class Initialized
DEBUG - 2010-06-28 05:29:03 --> Input Class Initialized
DEBUG - 2010-06-28 05:29:03 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:29:03 --> Language Class Initialized
DEBUG - 2010-06-28 05:29:03 --> Loader Class Initialized
DEBUG - 2010-06-28 05:29:03 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:29:03 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:29:03 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:29:03 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:29:03 --> Controller Class Initialized
DEBUG - 2010-06-28 05:29:03 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:29:03 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:29:03 --> Session Class Initialized
DEBUG - 2010-06-28 05:29:03 --> Helper loaded: string_helper
DEBUG - 2010-06-28 05:29:03 --> Session routines successfully run
DEBUG - 2010-06-28 05:29:04 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 05:29:04 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 05:29:04 --> Final output sent to browser
DEBUG - 2010-06-28 05:29:04 --> Total execution time: 1.4473
DEBUG - 2010-06-28 05:29:52 --> Config Class Initialized
DEBUG - 2010-06-28 05:29:52 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:29:52 --> URI Class Initialized
DEBUG - 2010-06-28 05:29:52 --> Router Class Initialized
DEBUG - 2010-06-28 05:29:52 --> Output Class Initialized
DEBUG - 2010-06-28 05:29:52 --> Input Class Initialized
DEBUG - 2010-06-28 05:29:52 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:29:52 --> Language Class Initialized
DEBUG - 2010-06-28 05:29:52 --> Loader Class Initialized
DEBUG - 2010-06-28 05:29:52 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:29:52 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:29:52 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:29:52 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:29:52 --> Controller Class Initialized
DEBUG - 2010-06-28 05:29:52 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:29:52 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:29:52 --> Session Class Initialized
DEBUG - 2010-06-28 05:29:52 --> Helper loaded: string_helper
DEBUG - 2010-06-28 05:29:52 --> Session routines successfully run
DEBUG - 2010-06-28 05:29:53 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 05:29:53 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 05:29:53 --> Final output sent to browser
DEBUG - 2010-06-28 05:29:53 --> Total execution time: 1.4834
DEBUG - 2010-06-28 05:31:16 --> Config Class Initialized
DEBUG - 2010-06-28 05:31:16 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:31:16 --> URI Class Initialized
DEBUG - 2010-06-28 05:31:16 --> Router Class Initialized
DEBUG - 2010-06-28 05:31:16 --> Output Class Initialized
DEBUG - 2010-06-28 05:31:16 --> Input Class Initialized
DEBUG - 2010-06-28 05:31:16 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:31:16 --> Language Class Initialized
DEBUG - 2010-06-28 05:31:16 --> Loader Class Initialized
DEBUG - 2010-06-28 05:31:16 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:31:16 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:31:16 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:31:16 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:31:29 --> Config Class Initialized
DEBUG - 2010-06-28 05:31:29 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:31:29 --> URI Class Initialized
DEBUG - 2010-06-28 05:31:29 --> Router Class Initialized
DEBUG - 2010-06-28 05:31:29 --> Output Class Initialized
DEBUG - 2010-06-28 05:31:30 --> Input Class Initialized
DEBUG - 2010-06-28 05:31:30 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:31:30 --> Language Class Initialized
DEBUG - 2010-06-28 05:31:30 --> Loader Class Initialized
DEBUG - 2010-06-28 05:31:30 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:31:30 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:31:30 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:31:30 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:31:30 --> Controller Class Initialized
DEBUG - 2010-06-28 05:31:30 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:31:30 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:31:30 --> Session Class Initialized
DEBUG - 2010-06-28 05:31:30 --> Helper loaded: string_helper
DEBUG - 2010-06-28 05:31:30 --> Session routines successfully run
DEBUG - 2010-06-28 05:31:54 --> Config Class Initialized
DEBUG - 2010-06-28 05:31:54 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:31:54 --> URI Class Initialized
DEBUG - 2010-06-28 05:31:54 --> Router Class Initialized
DEBUG - 2010-06-28 05:31:54 --> Output Class Initialized
DEBUG - 2010-06-28 05:31:54 --> Input Class Initialized
DEBUG - 2010-06-28 05:31:55 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:31:55 --> Language Class Initialized
DEBUG - 2010-06-28 05:31:55 --> Loader Class Initialized
DEBUG - 2010-06-28 05:31:55 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:31:55 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:31:55 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:31:55 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:31:55 --> Controller Class Initialized
DEBUG - 2010-06-28 05:31:55 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:31:55 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:31:55 --> Session Class Initialized
DEBUG - 2010-06-28 05:31:55 --> Helper loaded: string_helper
DEBUG - 2010-06-28 05:31:55 --> Session routines successfully run
DEBUG - 2010-06-28 05:31:56 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 05:31:56 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 05:31:56 --> Final output sent to browser
DEBUG - 2010-06-28 05:31:56 --> Total execution time: 1.8181
DEBUG - 2010-06-28 05:35:52 --> Config Class Initialized
DEBUG - 2010-06-28 05:35:52 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:35:52 --> URI Class Initialized
DEBUG - 2010-06-28 05:35:52 --> Router Class Initialized
DEBUG - 2010-06-28 05:35:52 --> Output Class Initialized
DEBUG - 2010-06-28 05:35:52 --> Input Class Initialized
DEBUG - 2010-06-28 05:35:52 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:35:52 --> Language Class Initialized
DEBUG - 2010-06-28 05:35:53 --> Loader Class Initialized
DEBUG - 2010-06-28 05:35:53 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:35:53 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:35:53 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:35:53 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:35:53 --> Controller Class Initialized
DEBUG - 2010-06-28 05:35:53 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:35:53 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:35:54 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 05:35:54 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 05:35:54 --> Final output sent to browser
DEBUG - 2010-06-28 05:35:54 --> Total execution time: 1.3840
DEBUG - 2010-06-28 05:36:49 --> Config Class Initialized
DEBUG - 2010-06-28 05:36:49 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:36:49 --> URI Class Initialized
DEBUG - 2010-06-28 05:36:49 --> Router Class Initialized
DEBUG - 2010-06-28 05:36:49 --> Output Class Initialized
DEBUG - 2010-06-28 05:36:49 --> Input Class Initialized
DEBUG - 2010-06-28 05:36:49 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:36:49 --> Language Class Initialized
DEBUG - 2010-06-28 05:36:49 --> Loader Class Initialized
DEBUG - 2010-06-28 05:36:49 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:36:49 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:36:49 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:36:49 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:36:49 --> Controller Class Initialized
DEBUG - 2010-06-28 05:36:49 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:36:49 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:36:50 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 05:36:50 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 05:36:50 --> Final output sent to browser
DEBUG - 2010-06-28 05:36:50 --> Total execution time: 1.3714
DEBUG - 2010-06-28 05:38:02 --> Config Class Initialized
DEBUG - 2010-06-28 05:38:02 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:38:02 --> URI Class Initialized
DEBUG - 2010-06-28 05:38:02 --> Router Class Initialized
DEBUG - 2010-06-28 05:38:02 --> Output Class Initialized
DEBUG - 2010-06-28 05:38:02 --> Input Class Initialized
DEBUG - 2010-06-28 05:38:02 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:38:02 --> Language Class Initialized
DEBUG - 2010-06-28 05:38:02 --> Loader Class Initialized
DEBUG - 2010-06-28 05:38:02 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:38:02 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:38:02 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:38:02 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:38:02 --> Controller Class Initialized
DEBUG - 2010-06-28 05:38:02 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:38:03 --> Helper loaded: unit_test_helper
ERROR - 2010-06-28 05:38:03 --> Severity: Notice  --> Undefined variable: host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 49
ERROR - 2010-06-28 05:38:03 --> Severity: Notice  --> Undefined variable: host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 49
DEBUG - 2010-06-28 05:38:03 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 05:38:03 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 05:38:03 --> Final output sent to browser
DEBUG - 2010-06-28 05:38:03 --> Total execution time: 0.7857
DEBUG - 2010-06-28 05:38:31 --> Config Class Initialized
DEBUG - 2010-06-28 05:38:32 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:38:32 --> URI Class Initialized
DEBUG - 2010-06-28 05:38:32 --> Router Class Initialized
DEBUG - 2010-06-28 05:38:32 --> Output Class Initialized
DEBUG - 2010-06-28 05:38:32 --> Input Class Initialized
DEBUG - 2010-06-28 05:38:32 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:38:32 --> Language Class Initialized
DEBUG - 2010-06-28 05:38:32 --> Loader Class Initialized
DEBUG - 2010-06-28 05:38:32 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:38:32 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:38:32 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:38:32 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:38:32 --> Controller Class Initialized
DEBUG - 2010-06-28 05:38:32 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:38:32 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:38:33 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 05:38:33 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 05:38:33 --> Final output sent to browser
DEBUG - 2010-06-28 05:38:33 --> Total execution time: 1.7007
DEBUG - 2010-06-28 05:39:33 --> Config Class Initialized
DEBUG - 2010-06-28 05:39:33 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:39:33 --> URI Class Initialized
DEBUG - 2010-06-28 05:39:33 --> Router Class Initialized
DEBUG - 2010-06-28 05:39:33 --> Output Class Initialized
DEBUG - 2010-06-28 05:39:33 --> Input Class Initialized
DEBUG - 2010-06-28 05:39:33 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:39:33 --> Language Class Initialized
DEBUG - 2010-06-28 05:39:33 --> Loader Class Initialized
DEBUG - 2010-06-28 05:39:33 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:39:34 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:39:34 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:39:34 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:39:34 --> Controller Class Initialized
DEBUG - 2010-06-28 05:39:34 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:39:34 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:39:34 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 05:39:34 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 05:39:34 --> Final output sent to browser
DEBUG - 2010-06-28 05:39:35 --> Total execution time: 1.3875
DEBUG - 2010-06-28 05:40:20 --> Config Class Initialized
DEBUG - 2010-06-28 05:40:20 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:40:20 --> URI Class Initialized
DEBUG - 2010-06-28 05:40:20 --> Router Class Initialized
DEBUG - 2010-06-28 05:40:20 --> Output Class Initialized
DEBUG - 2010-06-28 05:40:20 --> Input Class Initialized
DEBUG - 2010-06-28 05:40:20 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:40:20 --> Language Class Initialized
DEBUG - 2010-06-28 05:40:20 --> Loader Class Initialized
DEBUG - 2010-06-28 05:40:20 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:40:20 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:40:20 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:40:20 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:40:20 --> Controller Class Initialized
DEBUG - 2010-06-28 05:40:20 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:40:20 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:40:21 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-28 05:40:21 --> Severity: 4096  --> Argument 1 passed to Generic_object::_match_unique() must be an array, null given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php on line 467 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 485
ERROR - 2010-06-28 05:40:21 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 477
DEBUG - 2010-06-28 05:40:21 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 05:40:21 --> Final output sent to browser
DEBUG - 2010-06-28 05:40:21 --> Total execution time: 1.5175
DEBUG - 2010-06-28 05:40:47 --> Config Class Initialized
DEBUG - 2010-06-28 05:40:47 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:40:47 --> URI Class Initialized
DEBUG - 2010-06-28 05:40:47 --> Router Class Initialized
DEBUG - 2010-06-28 05:40:47 --> Output Class Initialized
DEBUG - 2010-06-28 05:40:47 --> Input Class Initialized
DEBUG - 2010-06-28 05:40:47 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:40:47 --> Language Class Initialized
DEBUG - 2010-06-28 05:40:48 --> Loader Class Initialized
DEBUG - 2010-06-28 05:40:48 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:40:48 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:40:48 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:40:48 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:40:48 --> Controller Class Initialized
DEBUG - 2010-06-28 05:40:48 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:40:48 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:40:49 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-28 05:40:49 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 477
DEBUG - 2010-06-28 05:40:49 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 05:40:49 --> Final output sent to browser
DEBUG - 2010-06-28 05:40:49 --> Total execution time: 1.4590
DEBUG - 2010-06-28 05:41:41 --> Config Class Initialized
DEBUG - 2010-06-28 05:41:41 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:41:41 --> URI Class Initialized
DEBUG - 2010-06-28 05:41:41 --> Router Class Initialized
DEBUG - 2010-06-28 05:41:41 --> Output Class Initialized
DEBUG - 2010-06-28 05:41:41 --> Input Class Initialized
DEBUG - 2010-06-28 05:41:41 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:41:41 --> Language Class Initialized
DEBUG - 2010-06-28 05:41:41 --> Loader Class Initialized
DEBUG - 2010-06-28 05:41:41 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:41:41 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:41:41 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:41:42 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:41:42 --> Controller Class Initialized
DEBUG - 2010-06-28 05:41:42 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:41:42 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:41:42 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-28 05:41:42 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 477
DEBUG - 2010-06-28 05:41:42 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 05:41:43 --> Final output sent to browser
DEBUG - 2010-06-28 05:41:43 --> Total execution time: 1.5204
DEBUG - 2010-06-28 05:48:19 --> Config Class Initialized
DEBUG - 2010-06-28 05:48:19 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:48:19 --> URI Class Initialized
DEBUG - 2010-06-28 05:48:19 --> Router Class Initialized
DEBUG - 2010-06-28 05:48:19 --> Output Class Initialized
DEBUG - 2010-06-28 05:48:19 --> Input Class Initialized
DEBUG - 2010-06-28 05:48:19 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:48:19 --> Language Class Initialized
DEBUG - 2010-06-28 05:48:19 --> Loader Class Initialized
DEBUG - 2010-06-28 05:48:19 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:48:19 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:48:19 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:48:20 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:48:20 --> Controller Class Initialized
DEBUG - 2010-06-28 05:48:20 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:48:20 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:48:20 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 05:48:20 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 05:48:21 --> Final output sent to browser
DEBUG - 2010-06-28 05:48:21 --> Total execution time: 1.4873
DEBUG - 2010-06-28 05:50:03 --> Config Class Initialized
DEBUG - 2010-06-28 05:50:03 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:50:03 --> URI Class Initialized
DEBUG - 2010-06-28 05:50:03 --> Router Class Initialized
DEBUG - 2010-06-28 05:50:03 --> Output Class Initialized
DEBUG - 2010-06-28 05:50:03 --> Input Class Initialized
DEBUG - 2010-06-28 05:50:03 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:50:03 --> Language Class Initialized
DEBUG - 2010-06-28 05:50:03 --> Loader Class Initialized
DEBUG - 2010-06-28 05:50:03 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:50:03 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:50:03 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:50:03 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:50:03 --> Controller Class Initialized
DEBUG - 2010-06-28 05:50:03 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:50:03 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:50:04 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 05:50:04 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 05:50:04 --> Final output sent to browser
DEBUG - 2010-06-28 05:50:04 --> Total execution time: 1.4949
DEBUG - 2010-06-28 05:50:19 --> Config Class Initialized
DEBUG - 2010-06-28 05:50:19 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:50:19 --> URI Class Initialized
DEBUG - 2010-06-28 05:50:19 --> Router Class Initialized
DEBUG - 2010-06-28 05:50:19 --> Output Class Initialized
DEBUG - 2010-06-28 05:50:19 --> Input Class Initialized
DEBUG - 2010-06-28 05:50:19 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:50:19 --> Language Class Initialized
DEBUG - 2010-06-28 05:50:19 --> Loader Class Initialized
DEBUG - 2010-06-28 05:50:19 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:50:19 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:50:19 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:50:19 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:53:21 --> Config Class Initialized
DEBUG - 2010-06-28 05:53:21 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:53:21 --> URI Class Initialized
DEBUG - 2010-06-28 05:53:21 --> Router Class Initialized
DEBUG - 2010-06-28 05:53:22 --> Output Class Initialized
DEBUG - 2010-06-28 05:53:22 --> Input Class Initialized
DEBUG - 2010-06-28 05:53:22 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:53:22 --> Language Class Initialized
DEBUG - 2010-06-28 05:53:22 --> Loader Class Initialized
DEBUG - 2010-06-28 05:53:22 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:53:22 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:53:22 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:53:22 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:53:39 --> Config Class Initialized
DEBUG - 2010-06-28 05:53:39 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:53:39 --> URI Class Initialized
DEBUG - 2010-06-28 05:53:40 --> Router Class Initialized
DEBUG - 2010-06-28 05:53:40 --> Output Class Initialized
DEBUG - 2010-06-28 05:53:40 --> Input Class Initialized
DEBUG - 2010-06-28 05:53:40 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:53:40 --> Language Class Initialized
DEBUG - 2010-06-28 05:53:40 --> Loader Class Initialized
DEBUG - 2010-06-28 05:53:40 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:53:40 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:53:40 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:53:40 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:53:40 --> Controller Class Initialized
DEBUG - 2010-06-28 05:53:40 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:53:40 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:53:41 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 05:53:41 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 05:53:41 --> Final output sent to browser
DEBUG - 2010-06-28 05:53:41 --> Total execution time: 1.4770
DEBUG - 2010-06-28 05:56:30 --> Config Class Initialized
DEBUG - 2010-06-28 05:56:30 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:56:30 --> URI Class Initialized
DEBUG - 2010-06-28 05:56:30 --> Router Class Initialized
DEBUG - 2010-06-28 05:56:30 --> Output Class Initialized
DEBUG - 2010-06-28 05:56:30 --> Input Class Initialized
DEBUG - 2010-06-28 05:56:30 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:56:30 --> Language Class Initialized
DEBUG - 2010-06-28 05:56:30 --> Loader Class Initialized
DEBUG - 2010-06-28 05:56:30 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:56:30 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:56:30 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:56:30 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:56:30 --> Controller Class Initialized
DEBUG - 2010-06-28 05:56:30 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:56:30 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:56:31 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 05:56:32 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 05:56:32 --> Final output sent to browser
DEBUG - 2010-06-28 05:56:32 --> Total execution time: 1.8022
DEBUG - 2010-06-28 05:56:57 --> Config Class Initialized
DEBUG - 2010-06-28 05:56:57 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:56:57 --> URI Class Initialized
DEBUG - 2010-06-28 05:56:57 --> Router Class Initialized
DEBUG - 2010-06-28 05:56:58 --> Output Class Initialized
DEBUG - 2010-06-28 05:56:58 --> Input Class Initialized
DEBUG - 2010-06-28 05:56:58 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:56:58 --> Language Class Initialized
DEBUG - 2010-06-28 05:56:58 --> Loader Class Initialized
DEBUG - 2010-06-28 05:56:58 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:56:58 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:56:58 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:56:58 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:56:58 --> Controller Class Initialized
DEBUG - 2010-06-28 05:56:58 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:56:58 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:56:59 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 05:56:59 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 05:56:59 --> Final output sent to browser
DEBUG - 2010-06-28 05:56:59 --> Total execution time: 1.9064
DEBUG - 2010-06-28 05:57:21 --> Config Class Initialized
DEBUG - 2010-06-28 05:57:21 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:57:21 --> URI Class Initialized
DEBUG - 2010-06-28 05:57:21 --> Router Class Initialized
DEBUG - 2010-06-28 05:57:21 --> Output Class Initialized
DEBUG - 2010-06-28 05:57:21 --> Input Class Initialized
DEBUG - 2010-06-28 05:57:21 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:57:21 --> Language Class Initialized
DEBUG - 2010-06-28 05:57:21 --> Loader Class Initialized
DEBUG - 2010-06-28 05:57:21 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:57:21 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:57:21 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:57:21 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:57:22 --> Controller Class Initialized
DEBUG - 2010-06-28 05:57:22 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:57:22 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:57:22 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 05:57:22 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 05:57:22 --> Final output sent to browser
DEBUG - 2010-06-28 05:57:22 --> Total execution time: 1.5235
DEBUG - 2010-06-28 05:59:26 --> Config Class Initialized
DEBUG - 2010-06-28 05:59:26 --> Hooks Class Initialized
DEBUG - 2010-06-28 05:59:26 --> URI Class Initialized
DEBUG - 2010-06-28 05:59:26 --> Router Class Initialized
DEBUG - 2010-06-28 05:59:26 --> Output Class Initialized
DEBUG - 2010-06-28 05:59:26 --> Input Class Initialized
DEBUG - 2010-06-28 05:59:26 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 05:59:26 --> Language Class Initialized
DEBUG - 2010-06-28 05:59:27 --> Loader Class Initialized
DEBUG - 2010-06-28 05:59:27 --> Helper loaded: context_helper
DEBUG - 2010-06-28 05:59:27 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 05:59:27 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 05:59:27 --> Database Driver Class Initialized
DEBUG - 2010-06-28 05:59:27 --> Controller Class Initialized
DEBUG - 2010-06-28 05:59:27 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 05:59:27 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 05:59:28 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 05:59:28 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 05:59:28 --> Final output sent to browser
DEBUG - 2010-06-28 05:59:28 --> Total execution time: 1.5323
DEBUG - 2010-06-28 06:00:20 --> Config Class Initialized
DEBUG - 2010-06-28 06:00:20 --> Hooks Class Initialized
DEBUG - 2010-06-28 06:00:20 --> URI Class Initialized
DEBUG - 2010-06-28 06:00:20 --> Router Class Initialized
DEBUG - 2010-06-28 06:00:20 --> Output Class Initialized
DEBUG - 2010-06-28 06:00:20 --> Input Class Initialized
DEBUG - 2010-06-28 06:00:20 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 06:00:20 --> Language Class Initialized
DEBUG - 2010-06-28 06:00:20 --> Loader Class Initialized
DEBUG - 2010-06-28 06:00:20 --> Helper loaded: context_helper
DEBUG - 2010-06-28 06:00:20 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 06:00:20 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 06:00:20 --> Database Driver Class Initialized
DEBUG - 2010-06-28 06:00:20 --> Controller Class Initialized
DEBUG - 2010-06-28 06:00:20 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 06:00:20 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 06:00:21 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 06:00:21 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 06:00:21 --> Final output sent to browser
DEBUG - 2010-06-28 06:00:21 --> Total execution time: 1.5860
DEBUG - 2010-06-28 06:00:45 --> Config Class Initialized
DEBUG - 2010-06-28 06:00:45 --> Hooks Class Initialized
DEBUG - 2010-06-28 06:00:45 --> URI Class Initialized
DEBUG - 2010-06-28 06:00:45 --> Router Class Initialized
DEBUG - 2010-06-28 06:00:45 --> Output Class Initialized
DEBUG - 2010-06-28 06:00:45 --> Input Class Initialized
DEBUG - 2010-06-28 06:00:45 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 06:00:45 --> Language Class Initialized
DEBUG - 2010-06-28 06:00:45 --> Loader Class Initialized
DEBUG - 2010-06-28 06:00:45 --> Helper loaded: context_helper
DEBUG - 2010-06-28 06:00:45 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 06:00:45 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 06:00:45 --> Database Driver Class Initialized
DEBUG - 2010-06-28 06:00:45 --> Controller Class Initialized
DEBUG - 2010-06-28 06:00:45 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 06:00:45 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 06:00:45 --> Session Class Initialized
DEBUG - 2010-06-28 06:00:46 --> Helper loaded: string_helper
DEBUG - 2010-06-28 06:00:46 --> Session routines successfully run
DEBUG - 2010-06-28 06:00:46 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 06:00:46 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 06:00:46 --> Final output sent to browser
DEBUG - 2010-06-28 06:00:46 --> Total execution time: 1.7234
DEBUG - 2010-06-28 06:01:02 --> Config Class Initialized
DEBUG - 2010-06-28 06:01:02 --> Hooks Class Initialized
DEBUG - 2010-06-28 06:01:02 --> URI Class Initialized
DEBUG - 2010-06-28 06:01:02 --> Router Class Initialized
DEBUG - 2010-06-28 06:01:02 --> Output Class Initialized
DEBUG - 2010-06-28 06:01:02 --> Input Class Initialized
DEBUG - 2010-06-28 06:01:02 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 06:01:02 --> Language Class Initialized
DEBUG - 2010-06-28 06:01:02 --> Loader Class Initialized
DEBUG - 2010-06-28 06:01:02 --> Helper loaded: context_helper
DEBUG - 2010-06-28 06:01:02 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 06:01:02 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 06:01:02 --> Database Driver Class Initialized
DEBUG - 2010-06-28 06:01:02 --> Controller Class Initialized
DEBUG - 2010-06-28 06:01:03 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 06:01:03 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 06:01:03 --> Session Class Initialized
DEBUG - 2010-06-28 06:01:03 --> Helper loaded: string_helper
DEBUG - 2010-06-28 06:01:03 --> Session routines successfully run
DEBUG - 2010-06-28 06:01:03 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 06:01:04 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 06:01:04 --> Final output sent to browser
DEBUG - 2010-06-28 06:01:04 --> Total execution time: 1.7328
DEBUG - 2010-06-28 06:01:17 --> Config Class Initialized
DEBUG - 2010-06-28 06:01:17 --> Hooks Class Initialized
DEBUG - 2010-06-28 06:01:18 --> URI Class Initialized
DEBUG - 2010-06-28 06:01:18 --> Router Class Initialized
DEBUG - 2010-06-28 06:01:18 --> Output Class Initialized
DEBUG - 2010-06-28 06:01:18 --> Input Class Initialized
DEBUG - 2010-06-28 06:01:18 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 06:01:18 --> Language Class Initialized
DEBUG - 2010-06-28 06:01:18 --> Loader Class Initialized
DEBUG - 2010-06-28 06:01:18 --> Helper loaded: context_helper
DEBUG - 2010-06-28 06:01:18 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 06:01:18 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 06:01:18 --> Database Driver Class Initialized
DEBUG - 2010-06-28 06:01:18 --> Controller Class Initialized
DEBUG - 2010-06-28 06:01:18 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 06:01:18 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 06:01:18 --> Session Class Initialized
DEBUG - 2010-06-28 06:01:18 --> Helper loaded: string_helper
DEBUG - 2010-06-28 06:01:18 --> Session routines successfully run
DEBUG - 2010-06-28 06:01:19 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 06:01:19 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 06:01:19 --> Final output sent to browser
DEBUG - 2010-06-28 06:01:19 --> Total execution time: 1.7739
DEBUG - 2010-06-28 06:01:28 --> Config Class Initialized
DEBUG - 2010-06-28 06:01:29 --> Hooks Class Initialized
DEBUG - 2010-06-28 06:01:29 --> URI Class Initialized
DEBUG - 2010-06-28 06:01:29 --> Router Class Initialized
DEBUG - 2010-06-28 06:01:29 --> Output Class Initialized
DEBUG - 2010-06-28 06:01:29 --> Input Class Initialized
DEBUG - 2010-06-28 06:01:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 06:01:29 --> Language Class Initialized
DEBUG - 2010-06-28 06:01:29 --> Loader Class Initialized
DEBUG - 2010-06-28 06:01:29 --> Helper loaded: context_helper
DEBUG - 2010-06-28 06:01:29 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 06:01:29 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 06:01:29 --> Database Driver Class Initialized
DEBUG - 2010-06-28 06:01:29 --> Controller Class Initialized
DEBUG - 2010-06-28 06:01:29 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 06:01:29 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 06:01:29 --> Session Class Initialized
DEBUG - 2010-06-28 06:01:29 --> Helper loaded: string_helper
DEBUG - 2010-06-28 06:01:29 --> Session routines successfully run
DEBUG - 2010-06-28 06:01:30 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 06:01:30 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 06:01:30 --> Final output sent to browser
DEBUG - 2010-06-28 06:01:30 --> Total execution time: 1.8320
DEBUG - 2010-06-28 06:02:03 --> Config Class Initialized
DEBUG - 2010-06-28 06:02:03 --> Hooks Class Initialized
DEBUG - 2010-06-28 06:02:03 --> URI Class Initialized
DEBUG - 2010-06-28 06:02:03 --> Router Class Initialized
DEBUG - 2010-06-28 06:02:03 --> Output Class Initialized
DEBUG - 2010-06-28 06:02:03 --> Input Class Initialized
DEBUG - 2010-06-28 06:02:04 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 06:02:04 --> Language Class Initialized
DEBUG - 2010-06-28 06:02:04 --> Loader Class Initialized
DEBUG - 2010-06-28 06:02:04 --> Helper loaded: context_helper
DEBUG - 2010-06-28 06:02:04 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 06:02:04 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 06:02:04 --> Database Driver Class Initialized
DEBUG - 2010-06-28 06:02:04 --> Controller Class Initialized
DEBUG - 2010-06-28 06:02:04 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 06:02:04 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 06:02:04 --> Session Class Initialized
DEBUG - 2010-06-28 06:02:04 --> Helper loaded: string_helper
DEBUG - 2010-06-28 06:02:04 --> Session routines successfully run
DEBUG - 2010-06-28 06:02:05 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 06:02:05 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 06:02:06 --> Final output sent to browser
DEBUG - 2010-06-28 06:02:06 --> Total execution time: 2.3214
DEBUG - 2010-06-28 06:02:18 --> Config Class Initialized
DEBUG - 2010-06-28 06:02:18 --> Hooks Class Initialized
DEBUG - 2010-06-28 06:02:18 --> URI Class Initialized
DEBUG - 2010-06-28 06:02:18 --> Router Class Initialized
DEBUG - 2010-06-28 06:02:18 --> Output Class Initialized
DEBUG - 2010-06-28 06:02:18 --> Input Class Initialized
DEBUG - 2010-06-28 06:02:18 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 06:02:18 --> Language Class Initialized
DEBUG - 2010-06-28 06:02:19 --> Loader Class Initialized
DEBUG - 2010-06-28 06:02:19 --> Helper loaded: context_helper
DEBUG - 2010-06-28 06:02:19 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 06:02:19 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 06:02:19 --> Database Driver Class Initialized
DEBUG - 2010-06-28 06:02:19 --> Controller Class Initialized
DEBUG - 2010-06-28 06:02:20 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 06:02:20 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 06:02:20 --> Session Class Initialized
DEBUG - 2010-06-28 06:02:20 --> Helper loaded: string_helper
DEBUG - 2010-06-28 06:02:20 --> Session routines successfully run
DEBUG - 2010-06-28 06:02:20 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 06:02:20 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 06:02:21 --> Final output sent to browser
DEBUG - 2010-06-28 06:02:21 --> Total execution time: 2.7607
DEBUG - 2010-06-28 06:05:40 --> Config Class Initialized
DEBUG - 2010-06-28 06:05:40 --> Hooks Class Initialized
DEBUG - 2010-06-28 06:05:40 --> URI Class Initialized
DEBUG - 2010-06-28 06:05:40 --> Router Class Initialized
DEBUG - 2010-06-28 06:05:41 --> Output Class Initialized
DEBUG - 2010-06-28 06:05:41 --> Input Class Initialized
DEBUG - 2010-06-28 06:05:41 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 06:05:41 --> Language Class Initialized
DEBUG - 2010-06-28 06:05:41 --> Loader Class Initialized
DEBUG - 2010-06-28 06:05:41 --> Helper loaded: context_helper
DEBUG - 2010-06-28 06:05:41 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 06:05:41 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 06:05:41 --> Database Driver Class Initialized
DEBUG - 2010-06-28 06:05:41 --> Controller Class Initialized
DEBUG - 2010-06-28 06:05:41 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 06:05:41 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 06:05:41 --> Session Class Initialized
DEBUG - 2010-06-28 06:05:41 --> Helper loaded: string_helper
DEBUG - 2010-06-28 06:05:41 --> Session routines successfully run
DEBUG - 2010-06-28 06:05:42 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 06:05:42 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 06:05:42 --> Final output sent to browser
DEBUG - 2010-06-28 06:05:42 --> Total execution time: 1.8714
DEBUG - 2010-06-28 06:08:34 --> Config Class Initialized
DEBUG - 2010-06-28 06:08:34 --> Hooks Class Initialized
DEBUG - 2010-06-28 06:08:34 --> URI Class Initialized
DEBUG - 2010-06-28 06:08:34 --> Router Class Initialized
DEBUG - 2010-06-28 06:08:34 --> Output Class Initialized
DEBUG - 2010-06-28 06:08:34 --> Input Class Initialized
DEBUG - 2010-06-28 06:08:34 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 06:08:34 --> Language Class Initialized
DEBUG - 2010-06-28 06:08:34 --> Loader Class Initialized
DEBUG - 2010-06-28 06:08:34 --> Helper loaded: context_helper
DEBUG - 2010-06-28 06:08:34 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 06:08:34 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 06:08:35 --> Database Driver Class Initialized
DEBUG - 2010-06-28 06:08:35 --> Controller Class Initialized
DEBUG - 2010-06-28 06:08:35 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 06:08:35 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 06:08:35 --> Session Class Initialized
DEBUG - 2010-06-28 06:08:35 --> Helper loaded: string_helper
DEBUG - 2010-06-28 06:08:35 --> Session routines successfully run
DEBUG - 2010-06-28 06:08:36 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 06:08:36 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 06:08:36 --> Final output sent to browser
DEBUG - 2010-06-28 06:08:36 --> Total execution time: 2.3849
DEBUG - 2010-06-28 09:53:09 --> Config Class Initialized
DEBUG - 2010-06-28 09:53:09 --> Hooks Class Initialized
DEBUG - 2010-06-28 09:53:09 --> URI Class Initialized
DEBUG - 2010-06-28 09:53:10 --> Router Class Initialized
DEBUG - 2010-06-28 09:53:10 --> Output Class Initialized
DEBUG - 2010-06-28 09:53:10 --> Input Class Initialized
DEBUG - 2010-06-28 09:53:10 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 09:53:10 --> Language Class Initialized
DEBUG - 2010-06-28 09:53:10 --> Loader Class Initialized
DEBUG - 2010-06-28 09:53:10 --> Helper loaded: context_helper
DEBUG - 2010-06-28 09:53:10 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 09:53:10 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 09:53:10 --> Database Driver Class Initialized
DEBUG - 2010-06-28 09:53:10 --> Controller Class Initialized
DEBUG - 2010-06-28 09:53:10 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 09:53:10 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 09:53:10 --> Session Class Initialized
DEBUG - 2010-06-28 09:53:10 --> Helper loaded: string_helper
DEBUG - 2010-06-28 09:53:11 --> A session cookie was not found.
DEBUG - 2010-06-28 09:53:11 --> Session routines successfully run
ERROR - 2010-06-28 09:53:11 --> Severity: Notice  --> Undefined variable: cond D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 481
ERROR - 2010-06-28 09:53:11 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 494
ERROR - 2010-06-28 09:53:11 --> Severity: Notice  --> Undefined variable: cond D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 481
ERROR - 2010-06-28 09:53:11 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 494
DEBUG - 2010-06-28 09:53:11 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 09:53:11 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 09:53:11 --> Final output sent to browser
DEBUG - 2010-06-28 09:53:11 --> Total execution time: 1.5859
DEBUG - 2010-06-28 09:53:21 --> Config Class Initialized
DEBUG - 2010-06-28 09:53:21 --> Hooks Class Initialized
DEBUG - 2010-06-28 09:53:21 --> URI Class Initialized
DEBUG - 2010-06-28 09:53:21 --> Router Class Initialized
DEBUG - 2010-06-28 09:53:21 --> Output Class Initialized
DEBUG - 2010-06-28 09:53:22 --> Input Class Initialized
DEBUG - 2010-06-28 09:53:22 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 09:53:22 --> Language Class Initialized
DEBUG - 2010-06-28 09:53:22 --> Loader Class Initialized
DEBUG - 2010-06-28 09:53:22 --> Helper loaded: context_helper
DEBUG - 2010-06-28 09:53:22 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 09:53:22 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 09:53:22 --> Database Driver Class Initialized
DEBUG - 2010-06-28 09:53:22 --> Controller Class Initialized
DEBUG - 2010-06-28 09:53:22 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 09:53:22 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 09:53:22 --> Session Class Initialized
DEBUG - 2010-06-28 09:53:22 --> Helper loaded: string_helper
DEBUG - 2010-06-28 09:53:22 --> Session routines successfully run
DEBUG - 2010-06-28 09:53:23 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 09:53:23 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 09:53:23 --> Final output sent to browser
DEBUG - 2010-06-28 09:53:23 --> Total execution time: 1.8127
DEBUG - 2010-06-28 09:54:26 --> Config Class Initialized
DEBUG - 2010-06-28 09:54:26 --> Hooks Class Initialized
DEBUG - 2010-06-28 09:54:26 --> URI Class Initialized
DEBUG - 2010-06-28 09:54:26 --> Router Class Initialized
DEBUG - 2010-06-28 09:54:26 --> Output Class Initialized
DEBUG - 2010-06-28 09:54:26 --> Input Class Initialized
DEBUG - 2010-06-28 09:54:26 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 09:54:26 --> Language Class Initialized
DEBUG - 2010-06-28 09:54:26 --> Loader Class Initialized
DEBUG - 2010-06-28 09:54:26 --> Helper loaded: context_helper
DEBUG - 2010-06-28 09:54:26 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 09:54:26 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 09:54:26 --> Database Driver Class Initialized
DEBUG - 2010-06-28 09:54:26 --> Controller Class Initialized
DEBUG - 2010-06-28 09:54:27 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 09:54:27 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 09:54:27 --> Session Class Initialized
DEBUG - 2010-06-28 09:54:27 --> Helper loaded: string_helper
DEBUG - 2010-06-28 09:54:27 --> Session routines successfully run
ERROR - 2010-06-28 09:54:27 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 104
ERROR - 2010-06-28 09:54:27 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 104
ERROR - 2010-06-28 09:54:27 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 104
ERROR - 2010-06-28 09:54:27 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 104
ERROR - 2010-06-28 09:54:27 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 104
ERROR - 2010-06-28 09:54:27 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 104
ERROR - 2010-06-28 09:54:27 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 104
DEBUG - 2010-06-28 09:54:27 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-28 09:54:27 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 104
ERROR - 2010-06-28 09:54:27 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 104
ERROR - 2010-06-28 09:54:27 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 496
ERROR - 2010-06-28 09:54:27 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 104
ERROR - 2010-06-28 09:54:27 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 104
ERROR - 2010-06-28 09:54:27 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 233
ERROR - 2010-06-28 09:54:27 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-28 09:54:28 --> Severity: Notice  --> Object of class Domain to string conversion D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-28 09:54:28 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 224
ERROR - 2010-06-28 09:54:28 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-28 09:54:28 --> Severity: Notice  --> Object of class Domain to string conversion D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-28 09:54:28 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 224
DEBUG - 2010-06-28 09:54:28 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 09:54:28 --> Final output sent to browser
DEBUG - 2010-06-28 09:54:28 --> Total execution time: 2.0754
DEBUG - 2010-06-28 09:55:22 --> Config Class Initialized
DEBUG - 2010-06-28 09:55:22 --> Hooks Class Initialized
DEBUG - 2010-06-28 09:55:22 --> URI Class Initialized
DEBUG - 2010-06-28 09:55:22 --> Router Class Initialized
DEBUG - 2010-06-28 09:55:22 --> Output Class Initialized
DEBUG - 2010-06-28 09:55:22 --> Input Class Initialized
DEBUG - 2010-06-28 09:55:22 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 09:55:22 --> Language Class Initialized
DEBUG - 2010-06-28 09:55:22 --> Loader Class Initialized
DEBUG - 2010-06-28 09:55:22 --> Helper loaded: context_helper
DEBUG - 2010-06-28 09:55:22 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 09:55:22 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 09:55:22 --> Database Driver Class Initialized
DEBUG - 2010-06-28 09:55:22 --> Controller Class Initialized
DEBUG - 2010-06-28 09:55:22 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 09:55:22 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 09:55:22 --> Session Class Initialized
DEBUG - 2010-06-28 09:55:23 --> Helper loaded: string_helper
DEBUG - 2010-06-28 09:55:23 --> Session routines successfully run
ERROR - 2010-06-28 09:55:23 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-28 09:55:23 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-28 09:55:23 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-28 09:55:23 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-28 09:55:23 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-28 09:55:23 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-28 09:55:23 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
DEBUG - 2010-06-28 09:55:23 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-28 09:55:23 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-28 09:55:23 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-28 09:55:23 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 497
ERROR - 2010-06-28 09:55:23 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-28 09:55:23 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-28 09:55:23 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 233
ERROR - 2010-06-28 09:55:23 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-28 09:55:23 --> Severity: Notice  --> Object of class Domain to string conversion D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-28 09:55:23 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 224
ERROR - 2010-06-28 09:55:24 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-28 09:55:24 --> Severity: Notice  --> Object of class Domain to string conversion D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-28 09:55:24 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 224
DEBUG - 2010-06-28 09:55:24 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 09:55:24 --> Final output sent to browser
DEBUG - 2010-06-28 09:55:24 --> Total execution time: 2.1228
DEBUG - 2010-06-28 09:55:54 --> Config Class Initialized
DEBUG - 2010-06-28 09:55:54 --> Hooks Class Initialized
DEBUG - 2010-06-28 09:55:54 --> URI Class Initialized
DEBUG - 2010-06-28 09:55:54 --> Router Class Initialized
DEBUG - 2010-06-28 09:55:54 --> Output Class Initialized
DEBUG - 2010-06-28 09:55:54 --> Input Class Initialized
DEBUG - 2010-06-28 09:55:54 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 09:55:54 --> Language Class Initialized
DEBUG - 2010-06-28 09:55:54 --> Loader Class Initialized
DEBUG - 2010-06-28 09:55:54 --> Helper loaded: context_helper
DEBUG - 2010-06-28 09:55:55 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 09:55:55 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 09:55:55 --> Database Driver Class Initialized
DEBUG - 2010-06-28 09:55:55 --> Controller Class Initialized
DEBUG - 2010-06-28 09:55:55 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 09:55:55 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 09:55:55 --> Session Class Initialized
DEBUG - 2010-06-28 09:55:55 --> Helper loaded: string_helper
DEBUG - 2010-06-28 09:55:55 --> Session routines successfully run
DEBUG - 2010-06-28 09:55:56 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 09:55:56 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 09:55:56 --> Final output sent to browser
DEBUG - 2010-06-28 09:55:56 --> Total execution time: 1.8538
DEBUG - 2010-06-28 09:56:12 --> Config Class Initialized
DEBUG - 2010-06-28 09:56:12 --> Hooks Class Initialized
DEBUG - 2010-06-28 09:56:12 --> URI Class Initialized
DEBUG - 2010-06-28 09:56:12 --> Router Class Initialized
DEBUG - 2010-06-28 09:56:12 --> Output Class Initialized
DEBUG - 2010-06-28 09:56:12 --> Input Class Initialized
DEBUG - 2010-06-28 09:56:12 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 09:56:12 --> Language Class Initialized
DEBUG - 2010-06-28 09:56:12 --> Loader Class Initialized
DEBUG - 2010-06-28 09:56:12 --> Helper loaded: context_helper
DEBUG - 2010-06-28 09:56:12 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 09:56:12 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 09:56:13 --> Database Driver Class Initialized
DEBUG - 2010-06-28 09:56:13 --> Controller Class Initialized
DEBUG - 2010-06-28 09:56:13 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 09:56:13 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 09:56:13 --> Session Class Initialized
DEBUG - 2010-06-28 09:56:13 --> Helper loaded: string_helper
DEBUG - 2010-06-28 09:56:13 --> Session routines successfully run
ERROR - 2010-06-28 09:56:13 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:56:13 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:56:13 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:56:13 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:56:13 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:56:13 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:56:13 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
DEBUG - 2010-06-28 09:56:13 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-28 09:56:13 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:56:13 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:56:13 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 499
ERROR - 2010-06-28 09:56:14 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:56:14 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:56:14 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 233
ERROR - 2010-06-28 09:56:14 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-28 09:56:14 --> Severity: Notice  --> Object of class Domain to string conversion D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-28 09:56:14 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 224
ERROR - 2010-06-28 09:56:14 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-28 09:56:14 --> Severity: Notice  --> Object of class Domain to string conversion D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-28 09:56:14 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 224
DEBUG - 2010-06-28 09:56:14 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 09:56:14 --> Final output sent to browser
DEBUG - 2010-06-28 09:56:14 --> Total execution time: 2.1932
DEBUG - 2010-06-28 09:56:33 --> Config Class Initialized
DEBUG - 2010-06-28 09:56:33 --> Hooks Class Initialized
DEBUG - 2010-06-28 09:56:33 --> URI Class Initialized
DEBUG - 2010-06-28 09:56:34 --> Router Class Initialized
DEBUG - 2010-06-28 09:56:34 --> Output Class Initialized
DEBUG - 2010-06-28 09:56:34 --> Input Class Initialized
DEBUG - 2010-06-28 09:56:34 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 09:56:34 --> Language Class Initialized
DEBUG - 2010-06-28 09:56:34 --> Loader Class Initialized
DEBUG - 2010-06-28 09:56:34 --> Helper loaded: context_helper
DEBUG - 2010-06-28 09:56:34 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 09:56:34 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 09:56:34 --> Database Driver Class Initialized
DEBUG - 2010-06-28 09:56:34 --> Controller Class Initialized
DEBUG - 2010-06-28 09:56:34 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 09:56:34 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 09:56:34 --> Session Class Initialized
DEBUG - 2010-06-28 09:56:34 --> Helper loaded: string_helper
DEBUG - 2010-06-28 09:56:34 --> Session routines successfully run
ERROR - 2010-06-28 09:56:34 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:56:35 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:56:35 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:56:35 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:56:35 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:56:35 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:56:35 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
DEBUG - 2010-06-28 09:56:35 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-28 09:56:35 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:56:35 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:56:35 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 499
ERROR - 2010-06-28 09:56:35 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:56:35 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:56:35 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 233
ERROR - 2010-06-28 09:56:35 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-28 09:56:35 --> Severity: Notice  --> Object of class Domain to string conversion D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-28 09:56:35 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 224
ERROR - 2010-06-28 09:56:35 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-28 09:56:36 --> Severity: Notice  --> Object of class Domain to string conversion D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-28 09:56:36 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 224
DEBUG - 2010-06-28 09:56:36 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 09:56:36 --> Final output sent to browser
DEBUG - 2010-06-28 09:56:36 --> Total execution time: 2.3217
DEBUG - 2010-06-28 09:56:56 --> Config Class Initialized
DEBUG - 2010-06-28 09:56:56 --> Hooks Class Initialized
DEBUG - 2010-06-28 09:56:56 --> URI Class Initialized
DEBUG - 2010-06-28 09:56:56 --> Router Class Initialized
DEBUG - 2010-06-28 09:56:56 --> Output Class Initialized
DEBUG - 2010-06-28 09:56:56 --> Input Class Initialized
DEBUG - 2010-06-28 09:56:56 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 09:56:56 --> Language Class Initialized
DEBUG - 2010-06-28 09:56:56 --> Loader Class Initialized
DEBUG - 2010-06-28 09:56:56 --> Helper loaded: context_helper
DEBUG - 2010-06-28 09:56:56 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 09:56:56 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 09:56:56 --> Database Driver Class Initialized
DEBUG - 2010-06-28 09:56:56 --> Controller Class Initialized
DEBUG - 2010-06-28 09:56:56 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 09:56:57 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 09:56:57 --> Session Class Initialized
DEBUG - 2010-06-28 09:56:57 --> Helper loaded: string_helper
DEBUG - 2010-06-28 09:56:57 --> Session routines successfully run
ERROR - 2010-06-28 09:56:57 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:56:57 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:56:57 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:56:57 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:56:57 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:56:57 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:56:57 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
DEBUG - 2010-06-28 09:56:57 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-28 09:56:57 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:56:57 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:56:57 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 499
ERROR - 2010-06-28 09:56:57 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:56:57 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:56:58 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 233
ERROR - 2010-06-28 09:56:58 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-28 09:56:58 --> Severity: Notice  --> Object of class Domain to string conversion D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-28 09:56:58 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 224
ERROR - 2010-06-28 09:56:58 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-28 09:56:58 --> Severity: Notice  --> Object of class Domain to string conversion D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-28 09:56:58 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 224
DEBUG - 2010-06-28 09:56:58 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 09:56:58 --> Final output sent to browser
DEBUG - 2010-06-28 09:56:58 --> Total execution time: 2.3318
DEBUG - 2010-06-28 09:57:39 --> Config Class Initialized
DEBUG - 2010-06-28 09:57:39 --> Hooks Class Initialized
DEBUG - 2010-06-28 09:57:39 --> URI Class Initialized
DEBUG - 2010-06-28 09:57:39 --> Router Class Initialized
DEBUG - 2010-06-28 09:57:39 --> Output Class Initialized
DEBUG - 2010-06-28 09:57:39 --> Input Class Initialized
DEBUG - 2010-06-28 09:57:40 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 09:57:40 --> Language Class Initialized
DEBUG - 2010-06-28 09:57:40 --> Loader Class Initialized
DEBUG - 2010-06-28 09:57:40 --> Helper loaded: context_helper
DEBUG - 2010-06-28 09:57:40 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 09:57:40 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 09:57:40 --> Database Driver Class Initialized
DEBUG - 2010-06-28 09:57:40 --> Controller Class Initialized
DEBUG - 2010-06-28 09:57:40 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 09:57:40 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 09:57:40 --> Session Class Initialized
DEBUG - 2010-06-28 09:57:40 --> Helper loaded: string_helper
DEBUG - 2010-06-28 09:57:40 --> Session routines successfully run
ERROR - 2010-06-28 09:57:40 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:57:40 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:57:40 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:57:41 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:57:41 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:57:41 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:57:41 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
DEBUG - 2010-06-28 09:57:41 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-28 09:57:41 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:57:41 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:57:41 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 499
ERROR - 2010-06-28 09:57:41 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:57:41 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 107
ERROR - 2010-06-28 09:57:41 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 233
ERROR - 2010-06-28 09:57:41 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-28 09:57:41 --> Severity: Notice  --> Object of class Domain to string conversion D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-28 09:57:41 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 224
ERROR - 2010-06-28 09:57:41 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-28 09:57:41 --> Severity: Notice  --> Object of class Domain to string conversion D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-28 09:57:41 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 224
DEBUG - 2010-06-28 09:57:42 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 09:57:42 --> Final output sent to browser
DEBUG - 2010-06-28 09:57:42 --> Total execution time: 2.3911
DEBUG - 2010-06-28 09:58:31 --> Config Class Initialized
DEBUG - 2010-06-28 09:58:31 --> Hooks Class Initialized
DEBUG - 2010-06-28 09:58:31 --> URI Class Initialized
DEBUG - 2010-06-28 09:58:31 --> Router Class Initialized
DEBUG - 2010-06-28 09:58:31 --> Output Class Initialized
DEBUG - 2010-06-28 09:58:32 --> Input Class Initialized
DEBUG - 2010-06-28 09:58:32 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 09:58:32 --> Language Class Initialized
DEBUG - 2010-06-28 09:58:32 --> Loader Class Initialized
DEBUG - 2010-06-28 09:58:32 --> Helper loaded: context_helper
DEBUG - 2010-06-28 09:58:32 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 09:58:32 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 09:58:32 --> Database Driver Class Initialized
DEBUG - 2010-06-28 09:58:32 --> Controller Class Initialized
DEBUG - 2010-06-28 09:58:32 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 09:58:32 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 09:58:32 --> Session Class Initialized
DEBUG - 2010-06-28 09:58:32 --> Helper loaded: string_helper
DEBUG - 2010-06-28 09:58:32 --> Session routines successfully run
ERROR - 2010-06-28 09:58:32 --> Severity: Warning  --> array_key_exists() [<a href='function.array-key-exists'>function.array-key-exists</a>]: The second argument should be either an array or an object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 76
ERROR - 2010-06-28 09:58:32 --> Severity: Warning  --> array_key_exists() [<a href='function.array-key-exists'>function.array-key-exists</a>]: The second argument should be either an array or an object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 76
ERROR - 2010-06-28 09:58:33 --> Severity: Warning  --> array_key_exists() [<a href='function.array-key-exists'>function.array-key-exists</a>]: The second argument should be either an array or an object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 76
ERROR - 2010-06-28 09:58:33 --> Severity: Warning  --> array_key_exists() [<a href='function.array-key-exists'>function.array-key-exists</a>]: The second argument should be either an array or an object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 76
ERROR - 2010-06-28 09:58:33 --> Severity: Warning  --> array_key_exists() [<a href='function.array-key-exists'>function.array-key-exists</a>]: The second argument should be either an array or an object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 76
ERROR - 2010-06-28 09:58:33 --> Severity: Warning  --> array_key_exists() [<a href='function.array-key-exists'>function.array-key-exists</a>]: The second argument should be either an array or an object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 76
ERROR - 2010-06-28 09:58:34 --> Severity: Warning  --> array_key_exists() [<a href='function.array-key-exists'>function.array-key-exists</a>]: The second argument should be either an array or an object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 76
DEBUG - 2010-06-28 09:58:34 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-28 09:58:34 --> Severity: Warning  --> array_key_exists() [<a href='function.array-key-exists'>function.array-key-exists</a>]: The second argument should be either an array or an object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 76
ERROR - 2010-06-28 09:58:34 --> Severity: Warning  --> array_key_exists() [<a href='function.array-key-exists'>function.array-key-exists</a>]: The second argument should be either an array or an object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 76
DEBUG - 2010-06-28 09:58:34 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 09:58:34 --> Final output sent to browser
DEBUG - 2010-06-28 09:58:34 --> Total execution time: 2.6123
DEBUG - 2010-06-28 09:59:02 --> Config Class Initialized
DEBUG - 2010-06-28 09:59:02 --> Hooks Class Initialized
DEBUG - 2010-06-28 09:59:02 --> URI Class Initialized
DEBUG - 2010-06-28 09:59:02 --> Router Class Initialized
DEBUG - 2010-06-28 09:59:02 --> Output Class Initialized
DEBUG - 2010-06-28 09:59:02 --> Input Class Initialized
DEBUG - 2010-06-28 09:59:02 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 09:59:03 --> Language Class Initialized
DEBUG - 2010-06-28 09:59:03 --> Loader Class Initialized
DEBUG - 2010-06-28 09:59:03 --> Helper loaded: context_helper
DEBUG - 2010-06-28 09:59:03 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 09:59:03 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 09:59:03 --> Database Driver Class Initialized
DEBUG - 2010-06-28 09:59:03 --> Controller Class Initialized
DEBUG - 2010-06-28 09:59:03 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 09:59:03 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 09:59:03 --> Session Class Initialized
DEBUG - 2010-06-28 09:59:03 --> Helper loaded: string_helper
DEBUG - 2010-06-28 09:59:03 --> Session routines successfully run
DEBUG - 2010-06-28 09:59:04 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 09:59:04 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 09:59:04 --> Final output sent to browser
DEBUG - 2010-06-28 09:59:04 --> Total execution time: 2.0586
DEBUG - 2010-06-28 10:00:33 --> Config Class Initialized
DEBUG - 2010-06-28 10:00:33 --> Hooks Class Initialized
DEBUG - 2010-06-28 10:00:33 --> URI Class Initialized
DEBUG - 2010-06-28 10:00:33 --> Router Class Initialized
DEBUG - 2010-06-28 10:00:33 --> Output Class Initialized
DEBUG - 2010-06-28 10:00:33 --> Input Class Initialized
DEBUG - 2010-06-28 10:00:33 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 10:00:33 --> Language Class Initialized
DEBUG - 2010-06-28 10:00:33 --> Loader Class Initialized
DEBUG - 2010-06-28 10:00:33 --> Helper loaded: context_helper
DEBUG - 2010-06-28 10:00:33 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 10:00:33 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 10:00:33 --> Database Driver Class Initialized
DEBUG - 2010-06-28 10:00:33 --> Controller Class Initialized
DEBUG - 2010-06-28 10:00:33 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 10:00:34 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 10:00:34 --> Session Class Initialized
DEBUG - 2010-06-28 10:00:34 --> Helper loaded: string_helper
DEBUG - 2010-06-28 10:00:34 --> Session routines successfully run
DEBUG - 2010-06-28 10:00:34 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 10:00:35 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 10:00:35 --> Final output sent to browser
DEBUG - 2010-06-28 10:00:35 --> Total execution time: 2.0088
DEBUG - 2010-06-28 10:00:53 --> Config Class Initialized
DEBUG - 2010-06-28 10:00:53 --> Hooks Class Initialized
DEBUG - 2010-06-28 10:00:53 --> URI Class Initialized
DEBUG - 2010-06-28 10:00:53 --> Router Class Initialized
DEBUG - 2010-06-28 10:00:53 --> Output Class Initialized
DEBUG - 2010-06-28 10:00:53 --> Input Class Initialized
DEBUG - 2010-06-28 10:00:53 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 10:00:54 --> Language Class Initialized
DEBUG - 2010-06-28 10:00:54 --> Loader Class Initialized
DEBUG - 2010-06-28 10:00:54 --> Helper loaded: context_helper
DEBUG - 2010-06-28 10:00:54 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 10:00:54 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 10:00:54 --> Database Driver Class Initialized
DEBUG - 2010-06-28 10:00:54 --> Controller Class Initialized
DEBUG - 2010-06-28 10:00:54 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 10:00:54 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 10:00:54 --> Session Class Initialized
DEBUG - 2010-06-28 10:00:54 --> Helper loaded: string_helper
DEBUG - 2010-06-28 10:00:54 --> Session routines successfully run
DEBUG - 2010-06-28 10:00:55 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 10:00:55 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 10:00:55 --> Final output sent to browser
DEBUG - 2010-06-28 10:00:55 --> Total execution time: 1.9974
DEBUG - 2010-06-28 10:01:02 --> Config Class Initialized
DEBUG - 2010-06-28 10:01:02 --> Hooks Class Initialized
DEBUG - 2010-06-28 10:01:02 --> URI Class Initialized
DEBUG - 2010-06-28 10:01:02 --> Router Class Initialized
DEBUG - 2010-06-28 10:01:02 --> Output Class Initialized
DEBUG - 2010-06-28 10:01:02 --> Input Class Initialized
DEBUG - 2010-06-28 10:01:02 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 10:01:02 --> Language Class Initialized
DEBUG - 2010-06-28 10:01:02 --> Loader Class Initialized
DEBUG - 2010-06-28 10:01:02 --> Helper loaded: context_helper
DEBUG - 2010-06-28 10:01:02 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 10:01:02 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 10:01:02 --> Database Driver Class Initialized
DEBUG - 2010-06-28 10:01:02 --> Controller Class Initialized
DEBUG - 2010-06-28 10:01:03 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 10:01:03 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 10:01:03 --> Session Class Initialized
DEBUG - 2010-06-28 10:01:03 --> Helper loaded: string_helper
DEBUG - 2010-06-28 10:01:03 --> Session routines successfully run
DEBUG - 2010-06-28 10:01:04 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 10:01:04 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 10:01:04 --> Final output sent to browser
DEBUG - 2010-06-28 10:01:04 --> Total execution time: 2.0994
DEBUG - 2010-06-28 10:07:17 --> Config Class Initialized
DEBUG - 2010-06-28 10:07:17 --> Hooks Class Initialized
DEBUG - 2010-06-28 10:07:17 --> URI Class Initialized
DEBUG - 2010-06-28 10:07:17 --> Router Class Initialized
DEBUG - 2010-06-28 10:07:17 --> Output Class Initialized
DEBUG - 2010-06-28 10:07:17 --> Input Class Initialized
DEBUG - 2010-06-28 10:07:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 10:07:17 --> Language Class Initialized
DEBUG - 2010-06-28 10:07:17 --> Loader Class Initialized
DEBUG - 2010-06-28 10:07:17 --> Helper loaded: context_helper
DEBUG - 2010-06-28 10:07:17 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 10:07:18 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 10:07:18 --> Database Driver Class Initialized
DEBUG - 2010-06-28 10:07:18 --> Controller Class Initialized
DEBUG - 2010-06-28 10:07:18 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 10:07:18 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 10:07:18 --> Session Class Initialized
DEBUG - 2010-06-28 10:07:18 --> Helper loaded: string_helper
DEBUG - 2010-06-28 10:07:18 --> Session routines successfully run
DEBUG - 2010-06-28 10:07:19 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 10:07:19 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 10:07:19 --> Final output sent to browser
DEBUG - 2010-06-28 10:07:19 --> Total execution time: 2.0499
DEBUG - 2010-06-28 10:08:46 --> Config Class Initialized
DEBUG - 2010-06-28 10:08:46 --> Hooks Class Initialized
DEBUG - 2010-06-28 10:08:46 --> URI Class Initialized
DEBUG - 2010-06-28 10:08:46 --> Router Class Initialized
DEBUG - 2010-06-28 10:08:46 --> Output Class Initialized
DEBUG - 2010-06-28 10:08:46 --> Input Class Initialized
DEBUG - 2010-06-28 10:08:46 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 10:08:46 --> Language Class Initialized
DEBUG - 2010-06-28 10:08:46 --> Loader Class Initialized
DEBUG - 2010-06-28 10:08:46 --> Helper loaded: context_helper
DEBUG - 2010-06-28 10:08:46 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 10:08:46 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 10:08:46 --> Database Driver Class Initialized
DEBUG - 2010-06-28 10:08:46 --> Controller Class Initialized
DEBUG - 2010-06-28 10:08:46 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 10:08:47 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 10:08:47 --> Session Class Initialized
DEBUG - 2010-06-28 10:08:47 --> Helper loaded: string_helper
DEBUG - 2010-06-28 10:08:47 --> Session routines successfully run
DEBUG - 2010-06-28 10:08:47 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 10:08:48 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 10:08:48 --> Final output sent to browser
DEBUG - 2010-06-28 10:08:48 --> Total execution time: 2.3580
DEBUG - 2010-06-28 10:33:24 --> Config Class Initialized
DEBUG - 2010-06-28 10:33:24 --> Hooks Class Initialized
DEBUG - 2010-06-28 10:33:24 --> URI Class Initialized
DEBUG - 2010-06-28 10:33:24 --> Router Class Initialized
DEBUG - 2010-06-28 10:33:24 --> Output Class Initialized
DEBUG - 2010-06-28 10:33:24 --> Input Class Initialized
DEBUG - 2010-06-28 10:33:24 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 10:33:25 --> Language Class Initialized
DEBUG - 2010-06-28 10:33:25 --> Loader Class Initialized
DEBUG - 2010-06-28 10:33:25 --> Helper loaded: context_helper
DEBUG - 2010-06-28 10:33:25 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 10:33:25 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 10:33:25 --> Database Driver Class Initialized
DEBUG - 2010-06-28 10:33:25 --> Controller Class Initialized
DEBUG - 2010-06-28 10:33:25 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 10:33:25 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 10:33:25 --> Session Class Initialized
DEBUG - 2010-06-28 10:33:25 --> Helper loaded: string_helper
DEBUG - 2010-06-28 10:33:25 --> Session routines successfully run
DEBUG - 2010-06-28 10:33:26 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 10:33:26 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 10:33:27 --> Final output sent to browser
DEBUG - 2010-06-28 10:33:27 --> Total execution time: 2.4742
DEBUG - 2010-06-28 11:52:11 --> Config Class Initialized
DEBUG - 2010-06-28 11:52:11 --> Hooks Class Initialized
DEBUG - 2010-06-28 11:52:11 --> URI Class Initialized
DEBUG - 2010-06-28 11:52:11 --> Router Class Initialized
DEBUG - 2010-06-28 11:52:11 --> Output Class Initialized
DEBUG - 2010-06-28 11:52:11 --> Input Class Initialized
DEBUG - 2010-06-28 11:52:11 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 11:52:12 --> Language Class Initialized
DEBUG - 2010-06-28 11:52:12 --> Loader Class Initialized
DEBUG - 2010-06-28 11:52:12 --> Helper loaded: context_helper
DEBUG - 2010-06-28 11:52:12 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 11:52:12 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 11:52:12 --> Database Driver Class Initialized
DEBUG - 2010-06-28 11:52:12 --> Controller Class Initialized
DEBUG - 2010-06-28 11:52:12 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 11:52:12 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 11:52:12 --> Session Class Initialized
DEBUG - 2010-06-28 11:52:12 --> Helper loaded: string_helper
DEBUG - 2010-06-28 11:52:12 --> Session routines successfully run
DEBUG - 2010-06-28 11:52:13 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 11:52:14 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 11:52:14 --> Final output sent to browser
DEBUG - 2010-06-28 11:52:14 --> Total execution time: 2.7618
DEBUG - 2010-06-28 11:52:36 --> Config Class Initialized
DEBUG - 2010-06-28 11:52:36 --> Hooks Class Initialized
DEBUG - 2010-06-28 11:52:36 --> URI Class Initialized
DEBUG - 2010-06-28 11:52:36 --> Router Class Initialized
DEBUG - 2010-06-28 11:52:36 --> Output Class Initialized
DEBUG - 2010-06-28 11:52:36 --> Input Class Initialized
DEBUG - 2010-06-28 11:52:36 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 11:52:36 --> Language Class Initialized
DEBUG - 2010-06-28 11:52:36 --> Loader Class Initialized
DEBUG - 2010-06-28 11:52:36 --> Helper loaded: context_helper
DEBUG - 2010-06-28 11:52:37 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 11:52:37 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 11:52:37 --> Database Driver Class Initialized
DEBUG - 2010-06-28 11:52:37 --> Controller Class Initialized
DEBUG - 2010-06-28 11:52:37 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 11:52:37 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 11:52:37 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 11:52:38 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 11:52:38 --> Final output sent to browser
DEBUG - 2010-06-28 11:52:38 --> Total execution time: 2.3099
DEBUG - 2010-06-28 12:16:19 --> Config Class Initialized
DEBUG - 2010-06-28 12:16:19 --> Hooks Class Initialized
DEBUG - 2010-06-28 12:16:19 --> URI Class Initialized
DEBUG - 2010-06-28 12:16:19 --> Router Class Initialized
DEBUG - 2010-06-28 12:16:19 --> Output Class Initialized
DEBUG - 2010-06-28 12:16:19 --> Input Class Initialized
DEBUG - 2010-06-28 12:16:20 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 12:16:20 --> Language Class Initialized
DEBUG - 2010-06-28 12:16:20 --> Loader Class Initialized
DEBUG - 2010-06-28 12:16:20 --> Helper loaded: context_helper
DEBUG - 2010-06-28 12:16:20 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 12:16:20 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 12:16:20 --> Database Driver Class Initialized
DEBUG - 2010-06-28 12:21:04 --> Config Class Initialized
DEBUG - 2010-06-28 12:21:05 --> Hooks Class Initialized
DEBUG - 2010-06-28 12:21:05 --> URI Class Initialized
DEBUG - 2010-06-28 12:21:05 --> Router Class Initialized
DEBUG - 2010-06-28 12:21:05 --> Output Class Initialized
DEBUG - 2010-06-28 12:21:05 --> Input Class Initialized
DEBUG - 2010-06-28 12:21:05 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 12:21:05 --> Language Class Initialized
DEBUG - 2010-06-28 12:21:05 --> Loader Class Initialized
DEBUG - 2010-06-28 12:21:05 --> Helper loaded: context_helper
DEBUG - 2010-06-28 12:21:05 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 12:21:05 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 12:21:05 --> Database Driver Class Initialized
DEBUG - 2010-06-28 12:21:05 --> Controller Class Initialized
DEBUG - 2010-06-28 12:21:05 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 12:21:06 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 12:21:06 --> Session Class Initialized
DEBUG - 2010-06-28 12:21:06 --> Helper loaded: string_helper
DEBUG - 2010-06-28 12:21:06 --> Session routines successfully run
DEBUG - 2010-06-28 12:21:06 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 12:21:07 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 12:21:07 --> Final output sent to browser
DEBUG - 2010-06-28 12:21:07 --> Total execution time: 2.5103
DEBUG - 2010-06-28 12:48:27 --> Config Class Initialized
DEBUG - 2010-06-28 12:48:27 --> Hooks Class Initialized
DEBUG - 2010-06-28 12:48:27 --> URI Class Initialized
DEBUG - 2010-06-28 12:48:27 --> Router Class Initialized
DEBUG - 2010-06-28 12:48:27 --> Output Class Initialized
DEBUG - 2010-06-28 12:48:27 --> Input Class Initialized
DEBUG - 2010-06-28 12:48:27 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 12:48:28 --> Language Class Initialized
DEBUG - 2010-06-28 12:48:28 --> Loader Class Initialized
DEBUG - 2010-06-28 12:48:28 --> Helper loaded: context_helper
DEBUG - 2010-06-28 12:48:28 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 12:48:28 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 12:48:28 --> Database Driver Class Initialized
DEBUG - 2010-06-28 12:48:28 --> Controller Class Initialized
DEBUG - 2010-06-28 12:48:28 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 12:48:28 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 12:48:28 --> Session Class Initialized
DEBUG - 2010-06-28 12:48:28 --> Helper loaded: string_helper
DEBUG - 2010-06-28 12:48:28 --> Session routines successfully run
DEBUG - 2010-06-28 12:48:29 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-28 12:48:29 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 233
ERROR - 2010-06-28 12:48:29 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-28 12:48:29 --> Severity: Notice  --> Object of class Domain to string conversion D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-28 12:48:29 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 224
ERROR - 2010-06-28 12:48:29 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-28 12:48:29 --> Severity: Notice  --> Object of class Domain to string conversion D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-28 12:48:29 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 224
DEBUG - 2010-06-28 12:48:29 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 12:48:29 --> Final output sent to browser
DEBUG - 2010-06-28 12:48:29 --> Total execution time: 2.3611
DEBUG - 2010-06-28 12:49:05 --> Config Class Initialized
DEBUG - 2010-06-28 12:49:05 --> Hooks Class Initialized
DEBUG - 2010-06-28 12:49:05 --> URI Class Initialized
DEBUG - 2010-06-28 12:49:05 --> Router Class Initialized
DEBUG - 2010-06-28 12:49:05 --> Output Class Initialized
DEBUG - 2010-06-28 12:49:05 --> Input Class Initialized
DEBUG - 2010-06-28 12:49:05 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 12:49:05 --> Language Class Initialized
DEBUG - 2010-06-28 12:49:05 --> Loader Class Initialized
DEBUG - 2010-06-28 12:49:06 --> Helper loaded: context_helper
DEBUG - 2010-06-28 12:49:06 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 12:49:06 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 12:49:06 --> Database Driver Class Initialized
DEBUG - 2010-06-28 12:49:06 --> Controller Class Initialized
DEBUG - 2010-06-28 12:49:06 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 12:49:06 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 12:49:06 --> Session Class Initialized
DEBUG - 2010-06-28 12:49:06 --> Helper loaded: string_helper
DEBUG - 2010-06-28 12:49:06 --> Session routines successfully run
DEBUG - 2010-06-28 12:49:07 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-28 12:49:07 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 233
ERROR - 2010-06-28 12:49:07 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-28 12:49:07 --> Severity: Notice  --> Object of class Domain to string conversion D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-28 12:49:07 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 224
ERROR - 2010-06-28 12:49:07 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-28 12:49:07 --> Severity: Notice  --> Object of class Domain to string conversion D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-28 12:49:07 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 224
DEBUG - 2010-06-28 12:49:07 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 12:49:07 --> Final output sent to browser
DEBUG - 2010-06-28 12:49:07 --> Total execution time: 2.2353
DEBUG - 2010-06-28 12:50:26 --> Config Class Initialized
DEBUG - 2010-06-28 12:50:26 --> Hooks Class Initialized
DEBUG - 2010-06-28 12:50:26 --> URI Class Initialized
DEBUG - 2010-06-28 12:50:26 --> Router Class Initialized
DEBUG - 2010-06-28 12:50:26 --> Output Class Initialized
DEBUG - 2010-06-28 12:50:26 --> Input Class Initialized
DEBUG - 2010-06-28 12:50:26 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 12:50:26 --> Language Class Initialized
DEBUG - 2010-06-28 12:50:26 --> Loader Class Initialized
DEBUG - 2010-06-28 12:50:26 --> Helper loaded: context_helper
DEBUG - 2010-06-28 12:50:26 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 12:50:26 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 12:50:27 --> Database Driver Class Initialized
DEBUG - 2010-06-28 12:50:27 --> Controller Class Initialized
DEBUG - 2010-06-28 12:50:27 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 12:50:27 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 12:50:27 --> Session Class Initialized
DEBUG - 2010-06-28 12:50:27 --> Helper loaded: string_helper
DEBUG - 2010-06-28 12:50:27 --> Session routines successfully run
DEBUG - 2010-06-28 12:50:27 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 12:50:28 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 12:50:28 --> Final output sent to browser
DEBUG - 2010-06-28 12:50:28 --> Total execution time: 2.4497
DEBUG - 2010-06-28 12:50:31 --> Config Class Initialized
DEBUG - 2010-06-28 12:50:31 --> Hooks Class Initialized
DEBUG - 2010-06-28 12:50:31 --> URI Class Initialized
DEBUG - 2010-06-28 12:50:31 --> Router Class Initialized
DEBUG - 2010-06-28 12:50:31 --> Output Class Initialized
DEBUG - 2010-06-28 12:50:31 --> Input Class Initialized
DEBUG - 2010-06-28 12:50:31 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 12:50:31 --> Language Class Initialized
DEBUG - 2010-06-28 12:50:31 --> Loader Class Initialized
DEBUG - 2010-06-28 12:50:31 --> Helper loaded: context_helper
DEBUG - 2010-06-28 12:50:31 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 12:50:31 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 12:50:31 --> Database Driver Class Initialized
DEBUG - 2010-06-28 12:50:32 --> Controller Class Initialized
DEBUG - 2010-06-28 12:50:32 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 12:50:32 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 12:50:32 --> Session Class Initialized
DEBUG - 2010-06-28 12:50:32 --> Helper loaded: string_helper
DEBUG - 2010-06-28 12:50:32 --> Session routines successfully run
DEBUG - 2010-06-28 12:50:32 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 12:50:33 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 12:50:33 --> Final output sent to browser
DEBUG - 2010-06-28 12:50:33 --> Total execution time: 2.4540
DEBUG - 2010-06-28 12:50:34 --> Config Class Initialized
DEBUG - 2010-06-28 12:50:35 --> Hooks Class Initialized
DEBUG - 2010-06-28 12:50:35 --> URI Class Initialized
DEBUG - 2010-06-28 12:50:35 --> Router Class Initialized
DEBUG - 2010-06-28 12:50:35 --> Output Class Initialized
DEBUG - 2010-06-28 12:50:35 --> Input Class Initialized
DEBUG - 2010-06-28 12:50:35 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 12:50:35 --> Language Class Initialized
DEBUG - 2010-06-28 12:50:35 --> Loader Class Initialized
DEBUG - 2010-06-28 12:50:35 --> Helper loaded: context_helper
DEBUG - 2010-06-28 12:50:35 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 12:50:35 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 12:50:35 --> Database Driver Class Initialized
DEBUG - 2010-06-28 12:50:35 --> Controller Class Initialized
DEBUG - 2010-06-28 12:50:35 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 12:50:36 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 12:50:36 --> Session Class Initialized
DEBUG - 2010-06-28 12:50:36 --> Helper loaded: string_helper
DEBUG - 2010-06-28 12:50:36 --> Session routines successfully run
DEBUG - 2010-06-28 12:50:36 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 12:50:37 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 12:50:37 --> Final output sent to browser
DEBUG - 2010-06-28 12:50:37 --> Total execution time: 2.4713
DEBUG - 2010-06-28 14:36:37 --> Config Class Initialized
DEBUG - 2010-06-28 14:36:37 --> Hooks Class Initialized
DEBUG - 2010-06-28 14:36:37 --> URI Class Initialized
DEBUG - 2010-06-28 14:36:37 --> Router Class Initialized
DEBUG - 2010-06-28 14:36:37 --> Output Class Initialized
DEBUG - 2010-06-28 14:36:37 --> Input Class Initialized
DEBUG - 2010-06-28 14:36:37 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 14:36:37 --> Language Class Initialized
DEBUG - 2010-06-28 14:36:38 --> Loader Class Initialized
DEBUG - 2010-06-28 14:36:38 --> Helper loaded: context_helper
DEBUG - 2010-06-28 14:36:38 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 14:36:38 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 14:36:38 --> Database Driver Class Initialized
DEBUG - 2010-06-28 14:36:38 --> Controller Class Initialized
DEBUG - 2010-06-28 14:36:38 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 14:36:38 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 14:36:38 --> Session Class Initialized
DEBUG - 2010-06-28 14:36:38 --> Helper loaded: string_helper
DEBUG - 2010-06-28 14:36:38 --> Session routines successfully run
DEBUG - 2010-06-28 14:36:39 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 14:36:39 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 14:36:39 --> Final output sent to browser
DEBUG - 2010-06-28 14:36:39 --> Total execution time: 2.0762
DEBUG - 2010-06-28 14:36:46 --> Config Class Initialized
DEBUG - 2010-06-28 14:36:46 --> Hooks Class Initialized
DEBUG - 2010-06-28 14:36:46 --> URI Class Initialized
DEBUG - 2010-06-28 14:36:46 --> Router Class Initialized
DEBUG - 2010-06-28 14:36:46 --> Output Class Initialized
DEBUG - 2010-06-28 14:36:46 --> Input Class Initialized
DEBUG - 2010-06-28 14:36:46 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 14:36:46 --> Language Class Initialized
DEBUG - 2010-06-28 14:36:46 --> Loader Class Initialized
DEBUG - 2010-06-28 14:36:46 --> Helper loaded: context_helper
DEBUG - 2010-06-28 14:36:47 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 14:36:47 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 14:36:47 --> Database Driver Class Initialized
DEBUG - 2010-06-28 14:36:47 --> Controller Class Initialized
DEBUG - 2010-06-28 14:36:47 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 14:36:47 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 14:36:47 --> Session Class Initialized
DEBUG - 2010-06-28 14:36:47 --> Helper loaded: string_helper
DEBUG - 2010-06-28 14:36:47 --> Session routines successfully run
DEBUG - 2010-06-28 14:36:48 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 14:36:48 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 14:36:48 --> Final output sent to browser
DEBUG - 2010-06-28 14:36:48 --> Total execution time: 1.8661
DEBUG - 2010-06-28 14:37:03 --> Config Class Initialized
DEBUG - 2010-06-28 14:37:03 --> Hooks Class Initialized
DEBUG - 2010-06-28 14:37:03 --> URI Class Initialized
DEBUG - 2010-06-28 14:37:03 --> Router Class Initialized
DEBUG - 2010-06-28 14:37:03 --> Output Class Initialized
DEBUG - 2010-06-28 14:37:03 --> Input Class Initialized
DEBUG - 2010-06-28 14:37:03 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 14:37:03 --> Language Class Initialized
DEBUG - 2010-06-28 14:37:03 --> Loader Class Initialized
DEBUG - 2010-06-28 14:37:03 --> Helper loaded: context_helper
DEBUG - 2010-06-28 14:37:03 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 14:37:03 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 14:37:04 --> Database Driver Class Initialized
DEBUG - 2010-06-28 14:37:04 --> Controller Class Initialized
DEBUG - 2010-06-28 14:37:04 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 14:37:04 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 14:37:04 --> Session Class Initialized
DEBUG - 2010-06-28 14:37:04 --> Helper loaded: string_helper
DEBUG - 2010-06-28 14:37:04 --> Session routines successfully run
DEBUG - 2010-06-28 14:37:04 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 14:37:04 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 14:37:05 --> Final output sent to browser
DEBUG - 2010-06-28 14:37:05 --> Total execution time: 1.9130
DEBUG - 2010-06-28 14:37:06 --> Config Class Initialized
DEBUG - 2010-06-28 14:37:06 --> Hooks Class Initialized
DEBUG - 2010-06-28 14:37:06 --> URI Class Initialized
DEBUG - 2010-06-28 14:37:06 --> Router Class Initialized
DEBUG - 2010-06-28 14:37:06 --> Output Class Initialized
DEBUG - 2010-06-28 14:37:06 --> Input Class Initialized
DEBUG - 2010-06-28 14:37:06 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 14:37:07 --> Language Class Initialized
DEBUG - 2010-06-28 14:37:07 --> Loader Class Initialized
DEBUG - 2010-06-28 14:37:07 --> Helper loaded: context_helper
DEBUG - 2010-06-28 14:37:07 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 14:37:07 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 14:37:07 --> Database Driver Class Initialized
DEBUG - 2010-06-28 14:37:07 --> Controller Class Initialized
DEBUG - 2010-06-28 14:37:07 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 14:37:07 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 14:37:07 --> Session Class Initialized
DEBUG - 2010-06-28 14:37:07 --> Helper loaded: string_helper
DEBUG - 2010-06-28 14:37:07 --> Session routines successfully run
DEBUG - 2010-06-28 14:37:08 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 14:37:08 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 14:37:08 --> Final output sent to browser
DEBUG - 2010-06-28 14:37:08 --> Total execution time: 1.8635
DEBUG - 2010-06-28 14:37:40 --> Config Class Initialized
DEBUG - 2010-06-28 14:37:40 --> Hooks Class Initialized
DEBUG - 2010-06-28 14:37:41 --> URI Class Initialized
DEBUG - 2010-06-28 14:37:41 --> Router Class Initialized
DEBUG - 2010-06-28 14:37:41 --> Output Class Initialized
DEBUG - 2010-06-28 14:37:41 --> Input Class Initialized
DEBUG - 2010-06-28 14:37:41 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 14:37:41 --> Language Class Initialized
DEBUG - 2010-06-28 14:37:41 --> Loader Class Initialized
DEBUG - 2010-06-28 14:37:41 --> Helper loaded: context_helper
DEBUG - 2010-06-28 14:37:41 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 14:37:41 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 14:37:41 --> Database Driver Class Initialized
DEBUG - 2010-06-28 14:37:41 --> Controller Class Initialized
DEBUG - 2010-06-28 14:37:41 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 14:37:42 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 14:37:42 --> Session Class Initialized
DEBUG - 2010-06-28 14:37:42 --> Helper loaded: string_helper
DEBUG - 2010-06-28 14:37:42 --> Session routines successfully run
DEBUG - 2010-06-28 14:37:42 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 14:37:42 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 14:37:42 --> Final output sent to browser
DEBUG - 2010-06-28 14:37:42 --> Total execution time: 2.0458
DEBUG - 2010-06-28 14:38:50 --> Config Class Initialized
DEBUG - 2010-06-28 14:38:50 --> Hooks Class Initialized
DEBUG - 2010-06-28 14:38:50 --> URI Class Initialized
DEBUG - 2010-06-28 14:38:50 --> Router Class Initialized
DEBUG - 2010-06-28 14:38:50 --> Output Class Initialized
DEBUG - 2010-06-28 14:38:50 --> Input Class Initialized
DEBUG - 2010-06-28 14:38:50 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 14:38:50 --> Language Class Initialized
DEBUG - 2010-06-28 14:38:50 --> Loader Class Initialized
DEBUG - 2010-06-28 14:38:50 --> Helper loaded: context_helper
DEBUG - 2010-06-28 14:38:51 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 14:38:51 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 14:38:51 --> Database Driver Class Initialized
DEBUG - 2010-06-28 14:38:51 --> Controller Class Initialized
DEBUG - 2010-06-28 14:38:51 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 14:38:51 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 14:38:51 --> Session Class Initialized
DEBUG - 2010-06-28 14:38:51 --> Helper loaded: string_helper
DEBUG - 2010-06-28 14:38:51 --> Session routines successfully run
DEBUG - 2010-06-28 14:38:51 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 14:38:52 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 14:38:52 --> Final output sent to browser
DEBUG - 2010-06-28 14:38:52 --> Total execution time: 1.8825
DEBUG - 2010-06-28 14:39:16 --> Config Class Initialized
DEBUG - 2010-06-28 14:39:16 --> Hooks Class Initialized
DEBUG - 2010-06-28 14:39:16 --> URI Class Initialized
DEBUG - 2010-06-28 14:39:16 --> Router Class Initialized
DEBUG - 2010-06-28 14:39:16 --> Output Class Initialized
DEBUG - 2010-06-28 14:39:16 --> Input Class Initialized
DEBUG - 2010-06-28 14:39:16 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 14:39:17 --> Language Class Initialized
DEBUG - 2010-06-28 14:39:17 --> Loader Class Initialized
DEBUG - 2010-06-28 14:39:17 --> Helper loaded: context_helper
DEBUG - 2010-06-28 14:39:17 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 14:39:17 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 14:39:17 --> Database Driver Class Initialized
DEBUG - 2010-06-28 14:39:17 --> Controller Class Initialized
DEBUG - 2010-06-28 14:39:17 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 14:39:17 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 14:39:17 --> Session Class Initialized
DEBUG - 2010-06-28 14:39:17 --> Helper loaded: string_helper
DEBUG - 2010-06-28 14:39:17 --> Session routines successfully run
DEBUG - 2010-06-28 14:39:18 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 14:39:18 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 14:39:18 --> Final output sent to browser
DEBUG - 2010-06-28 14:39:18 --> Total execution time: 2.1666
DEBUG - 2010-06-28 14:42:32 --> Config Class Initialized
DEBUG - 2010-06-28 14:42:32 --> Hooks Class Initialized
DEBUG - 2010-06-28 14:42:32 --> URI Class Initialized
DEBUG - 2010-06-28 14:42:32 --> Router Class Initialized
DEBUG - 2010-06-28 14:42:33 --> Output Class Initialized
DEBUG - 2010-06-28 14:42:33 --> Input Class Initialized
DEBUG - 2010-06-28 14:42:33 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 14:42:33 --> Language Class Initialized
DEBUG - 2010-06-28 14:42:33 --> Loader Class Initialized
DEBUG - 2010-06-28 14:42:33 --> Helper loaded: context_helper
DEBUG - 2010-06-28 14:42:33 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 14:42:33 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 14:42:33 --> Database Driver Class Initialized
DEBUG - 2010-06-28 14:42:33 --> Controller Class Initialized
DEBUG - 2010-06-28 14:42:33 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 14:42:33 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 14:42:33 --> Session Class Initialized
DEBUG - 2010-06-28 14:42:34 --> Helper loaded: string_helper
DEBUG - 2010-06-28 14:42:34 --> Session routines successfully run
DEBUG - 2010-06-28 14:42:34 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 14:42:34 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 14:42:34 --> Final output sent to browser
DEBUG - 2010-06-28 14:42:34 --> Total execution time: 2.3696
DEBUG - 2010-06-28 14:42:50 --> Config Class Initialized
DEBUG - 2010-06-28 14:42:50 --> Hooks Class Initialized
DEBUG - 2010-06-28 14:42:50 --> URI Class Initialized
DEBUG - 2010-06-28 14:42:50 --> Router Class Initialized
DEBUG - 2010-06-28 14:42:50 --> Output Class Initialized
DEBUG - 2010-06-28 14:42:50 --> Input Class Initialized
DEBUG - 2010-06-28 14:42:50 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 14:42:50 --> Language Class Initialized
DEBUG - 2010-06-28 14:42:51 --> Loader Class Initialized
DEBUG - 2010-06-28 14:42:51 --> Helper loaded: context_helper
DEBUG - 2010-06-28 14:42:51 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 14:42:51 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 14:42:51 --> Database Driver Class Initialized
DEBUG - 2010-06-28 14:42:51 --> Controller Class Initialized
DEBUG - 2010-06-28 14:42:51 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 14:42:51 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 14:42:51 --> Session Class Initialized
DEBUG - 2010-06-28 14:42:51 --> Helper loaded: string_helper
DEBUG - 2010-06-28 14:42:51 --> Session routines successfully run
DEBUG - 2010-06-28 14:42:52 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 14:42:52 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 14:42:52 --> Final output sent to browser
DEBUG - 2010-06-28 14:42:52 --> Total execution time: 2.0267
DEBUG - 2010-06-28 14:43:34 --> Config Class Initialized
DEBUG - 2010-06-28 14:43:35 --> Hooks Class Initialized
DEBUG - 2010-06-28 14:43:35 --> URI Class Initialized
DEBUG - 2010-06-28 14:43:35 --> Router Class Initialized
DEBUG - 2010-06-28 14:43:35 --> Output Class Initialized
DEBUG - 2010-06-28 14:43:35 --> Input Class Initialized
DEBUG - 2010-06-28 14:43:35 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 14:43:35 --> Language Class Initialized
DEBUG - 2010-06-28 14:43:35 --> Loader Class Initialized
DEBUG - 2010-06-28 14:43:35 --> Helper loaded: context_helper
DEBUG - 2010-06-28 14:43:35 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 14:43:35 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 14:43:35 --> Database Driver Class Initialized
DEBUG - 2010-06-28 14:43:35 --> Controller Class Initialized
DEBUG - 2010-06-28 14:43:36 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 14:43:36 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 14:43:36 --> Session Class Initialized
DEBUG - 2010-06-28 14:43:36 --> Helper loaded: string_helper
DEBUG - 2010-06-28 14:43:36 --> Session routines successfully run
DEBUG - 2010-06-28 14:43:36 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 14:43:37 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 14:43:37 --> Final output sent to browser
DEBUG - 2010-06-28 14:43:37 --> Total execution time: 2.6327
DEBUG - 2010-06-28 14:43:48 --> Config Class Initialized
DEBUG - 2010-06-28 14:43:48 --> Hooks Class Initialized
DEBUG - 2010-06-28 14:43:48 --> URI Class Initialized
DEBUG - 2010-06-28 14:43:49 --> Router Class Initialized
DEBUG - 2010-06-28 14:43:49 --> Output Class Initialized
DEBUG - 2010-06-28 14:43:49 --> Input Class Initialized
DEBUG - 2010-06-28 14:43:49 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 14:43:49 --> Language Class Initialized
DEBUG - 2010-06-28 14:43:49 --> Loader Class Initialized
DEBUG - 2010-06-28 14:43:49 --> Helper loaded: context_helper
DEBUG - 2010-06-28 14:43:49 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 14:43:49 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 14:43:49 --> Database Driver Class Initialized
DEBUG - 2010-06-28 14:43:49 --> Controller Class Initialized
DEBUG - 2010-06-28 14:43:49 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 14:43:50 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 14:43:50 --> Session Class Initialized
DEBUG - 2010-06-28 14:43:50 --> Helper loaded: string_helper
DEBUG - 2010-06-28 14:43:50 --> Session routines successfully run
DEBUG - 2010-06-28 14:43:50 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 14:43:50 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 14:43:50 --> Final output sent to browser
DEBUG - 2010-06-28 14:43:50 --> Total execution time: 2.0293
DEBUG - 2010-06-28 14:44:30 --> Config Class Initialized
DEBUG - 2010-06-28 14:44:30 --> Hooks Class Initialized
DEBUG - 2010-06-28 14:44:30 --> URI Class Initialized
DEBUG - 2010-06-28 14:44:30 --> Router Class Initialized
DEBUG - 2010-06-28 14:44:30 --> Output Class Initialized
DEBUG - 2010-06-28 14:44:30 --> Input Class Initialized
DEBUG - 2010-06-28 14:44:30 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 14:44:30 --> Language Class Initialized
DEBUG - 2010-06-28 14:44:31 --> Loader Class Initialized
DEBUG - 2010-06-28 14:44:31 --> Helper loaded: context_helper
DEBUG - 2010-06-28 14:44:31 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 14:44:31 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 14:44:31 --> Database Driver Class Initialized
DEBUG - 2010-06-28 14:44:31 --> Controller Class Initialized
DEBUG - 2010-06-28 14:44:31 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 14:44:31 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 14:44:31 --> Session Class Initialized
DEBUG - 2010-06-28 14:44:31 --> Helper loaded: string_helper
DEBUG - 2010-06-28 14:44:31 --> Session routines successfully run
DEBUG - 2010-06-28 14:44:32 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 14:44:32 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 14:44:32 --> Final output sent to browser
DEBUG - 2010-06-28 14:44:32 --> Total execution time: 2.0403
DEBUG - 2010-06-28 14:44:56 --> Config Class Initialized
DEBUG - 2010-06-28 14:44:56 --> Hooks Class Initialized
DEBUG - 2010-06-28 14:44:56 --> URI Class Initialized
DEBUG - 2010-06-28 14:44:56 --> Router Class Initialized
DEBUG - 2010-06-28 14:44:56 --> Output Class Initialized
DEBUG - 2010-06-28 14:44:56 --> Input Class Initialized
DEBUG - 2010-06-28 14:44:57 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 14:44:57 --> Language Class Initialized
DEBUG - 2010-06-28 14:44:57 --> Loader Class Initialized
DEBUG - 2010-06-28 14:44:57 --> Helper loaded: context_helper
DEBUG - 2010-06-28 14:44:57 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 14:44:57 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 14:44:57 --> Database Driver Class Initialized
DEBUG - 2010-06-28 14:44:57 --> Controller Class Initialized
DEBUG - 2010-06-28 14:44:57 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 14:44:57 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 14:44:57 --> Session Class Initialized
DEBUG - 2010-06-28 14:44:57 --> Helper loaded: string_helper
DEBUG - 2010-06-28 14:44:57 --> Session routines successfully run
DEBUG - 2010-06-28 14:44:58 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 14:44:58 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 14:44:58 --> Final output sent to browser
DEBUG - 2010-06-28 14:44:58 --> Total execution time: 2.0497
DEBUG - 2010-06-28 14:46:10 --> Config Class Initialized
DEBUG - 2010-06-28 14:46:10 --> Hooks Class Initialized
DEBUG - 2010-06-28 14:46:10 --> URI Class Initialized
DEBUG - 2010-06-28 14:46:10 --> Router Class Initialized
DEBUG - 2010-06-28 14:46:10 --> Output Class Initialized
DEBUG - 2010-06-28 14:46:10 --> Input Class Initialized
DEBUG - 2010-06-28 14:46:10 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 14:46:11 --> Language Class Initialized
DEBUG - 2010-06-28 14:46:11 --> Loader Class Initialized
DEBUG - 2010-06-28 14:46:11 --> Helper loaded: context_helper
DEBUG - 2010-06-28 14:46:11 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 14:46:11 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 14:46:11 --> Database Driver Class Initialized
DEBUG - 2010-06-28 14:46:11 --> Controller Class Initialized
DEBUG - 2010-06-28 14:46:11 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 14:46:11 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 14:46:11 --> Session Class Initialized
DEBUG - 2010-06-28 14:46:11 --> Helper loaded: string_helper
DEBUG - 2010-06-28 14:46:11 --> Session routines successfully run
DEBUG - 2010-06-28 14:46:12 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 14:46:12 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 14:46:12 --> Final output sent to browser
DEBUG - 2010-06-28 14:46:12 --> Total execution time: 2.0675
DEBUG - 2010-06-28 14:46:25 --> Config Class Initialized
DEBUG - 2010-06-28 14:46:25 --> Hooks Class Initialized
DEBUG - 2010-06-28 14:46:25 --> URI Class Initialized
DEBUG - 2010-06-28 14:46:26 --> Router Class Initialized
DEBUG - 2010-06-28 14:46:26 --> Output Class Initialized
DEBUG - 2010-06-28 14:46:26 --> Input Class Initialized
DEBUG - 2010-06-28 14:46:26 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 14:46:26 --> Language Class Initialized
DEBUG - 2010-06-28 14:46:26 --> Loader Class Initialized
DEBUG - 2010-06-28 14:46:26 --> Helper loaded: context_helper
DEBUG - 2010-06-28 14:46:26 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 14:46:26 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 14:46:26 --> Database Driver Class Initialized
DEBUG - 2010-06-28 14:46:26 --> Controller Class Initialized
DEBUG - 2010-06-28 14:46:26 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 14:46:27 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 14:46:27 --> Session Class Initialized
DEBUG - 2010-06-28 14:46:27 --> Helper loaded: string_helper
DEBUG - 2010-06-28 14:46:27 --> Session routines successfully run
DEBUG - 2010-06-28 14:46:27 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 14:46:27 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 14:46:27 --> Final output sent to browser
DEBUG - 2010-06-28 14:46:27 --> Total execution time: 2.0741
DEBUG - 2010-06-28 14:48:15 --> Config Class Initialized
DEBUG - 2010-06-28 14:48:15 --> Hooks Class Initialized
DEBUG - 2010-06-28 14:48:15 --> URI Class Initialized
DEBUG - 2010-06-28 14:48:15 --> Router Class Initialized
DEBUG - 2010-06-28 14:48:15 --> Output Class Initialized
DEBUG - 2010-06-28 14:48:15 --> Input Class Initialized
DEBUG - 2010-06-28 14:48:16 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 14:48:16 --> Language Class Initialized
DEBUG - 2010-06-28 14:48:16 --> Loader Class Initialized
DEBUG - 2010-06-28 14:48:16 --> Helper loaded: context_helper
DEBUG - 2010-06-28 14:48:16 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 14:48:16 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 14:48:16 --> Database Driver Class Initialized
DEBUG - 2010-06-28 14:48:16 --> Controller Class Initialized
DEBUG - 2010-06-28 14:48:16 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 14:48:16 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 14:48:16 --> Session Class Initialized
DEBUG - 2010-06-28 14:48:16 --> Helper loaded: string_helper
DEBUG - 2010-06-28 14:48:16 --> Session routines successfully run
DEBUG - 2010-06-28 14:48:17 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 14:48:17 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 14:48:17 --> Final output sent to browser
DEBUG - 2010-06-28 14:48:17 --> Total execution time: 2.0953
DEBUG - 2010-06-28 14:48:44 --> Config Class Initialized
DEBUG - 2010-06-28 14:48:45 --> Hooks Class Initialized
DEBUG - 2010-06-28 14:48:45 --> URI Class Initialized
DEBUG - 2010-06-28 14:48:45 --> Router Class Initialized
DEBUG - 2010-06-28 14:48:45 --> Output Class Initialized
DEBUG - 2010-06-28 14:48:45 --> Input Class Initialized
DEBUG - 2010-06-28 14:48:45 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 14:48:45 --> Language Class Initialized
DEBUG - 2010-06-28 14:48:45 --> Loader Class Initialized
DEBUG - 2010-06-28 14:48:45 --> Helper loaded: context_helper
DEBUG - 2010-06-28 14:48:45 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 14:48:45 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 14:48:45 --> Database Driver Class Initialized
DEBUG - 2010-06-28 14:48:45 --> Controller Class Initialized
DEBUG - 2010-06-28 14:48:46 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 14:48:46 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 14:48:46 --> Session Class Initialized
DEBUG - 2010-06-28 14:48:46 --> Helper loaded: string_helper
DEBUG - 2010-06-28 14:48:46 --> Session routines successfully run
DEBUG - 2010-06-28 14:48:46 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 14:48:46 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 14:48:46 --> Final output sent to browser
DEBUG - 2010-06-28 14:48:47 --> Total execution time: 2.0820
DEBUG - 2010-06-28 14:49:16 --> Config Class Initialized
DEBUG - 2010-06-28 14:49:16 --> Hooks Class Initialized
DEBUG - 2010-06-28 14:49:16 --> URI Class Initialized
DEBUG - 2010-06-28 14:49:16 --> Router Class Initialized
DEBUG - 2010-06-28 14:49:16 --> Output Class Initialized
DEBUG - 2010-06-28 14:49:16 --> Input Class Initialized
DEBUG - 2010-06-28 14:49:16 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 14:49:17 --> Language Class Initialized
DEBUG - 2010-06-28 14:49:17 --> Loader Class Initialized
DEBUG - 2010-06-28 14:49:17 --> Helper loaded: context_helper
DEBUG - 2010-06-28 14:49:17 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 14:49:17 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 14:49:17 --> Database Driver Class Initialized
DEBUG - 2010-06-28 14:49:17 --> Controller Class Initialized
DEBUG - 2010-06-28 14:49:17 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 14:49:17 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 14:49:17 --> Session Class Initialized
DEBUG - 2010-06-28 14:49:17 --> Helper loaded: string_helper
DEBUG - 2010-06-28 14:49:18 --> Session routines successfully run
DEBUG - 2010-06-28 14:49:18 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 14:49:18 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 14:49:18 --> Final output sent to browser
DEBUG - 2010-06-28 14:49:18 --> Total execution time: 2.1175
DEBUG - 2010-06-28 14:49:48 --> Config Class Initialized
DEBUG - 2010-06-28 14:49:48 --> Hooks Class Initialized
DEBUG - 2010-06-28 14:49:48 --> URI Class Initialized
DEBUG - 2010-06-28 14:49:48 --> Router Class Initialized
DEBUG - 2010-06-28 14:49:48 --> Output Class Initialized
DEBUG - 2010-06-28 14:49:48 --> Input Class Initialized
DEBUG - 2010-06-28 14:49:49 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 14:49:49 --> Language Class Initialized
DEBUG - 2010-06-28 14:49:49 --> Loader Class Initialized
DEBUG - 2010-06-28 14:49:49 --> Helper loaded: context_helper
DEBUG - 2010-06-28 14:49:49 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 14:49:49 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 14:49:49 --> Database Driver Class Initialized
DEBUG - 2010-06-28 14:49:49 --> Controller Class Initialized
DEBUG - 2010-06-28 14:49:49 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 14:49:49 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 14:49:49 --> Session Class Initialized
DEBUG - 2010-06-28 14:49:49 --> Helper loaded: string_helper
DEBUG - 2010-06-28 14:49:50 --> Session routines successfully run
DEBUG - 2010-06-28 14:49:50 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 14:49:50 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 14:49:50 --> Final output sent to browser
DEBUG - 2010-06-28 14:49:50 --> Total execution time: 2.1742
DEBUG - 2010-06-28 14:50:46 --> Config Class Initialized
DEBUG - 2010-06-28 14:50:46 --> Hooks Class Initialized
DEBUG - 2010-06-28 14:50:46 --> URI Class Initialized
DEBUG - 2010-06-28 14:50:46 --> Router Class Initialized
DEBUG - 2010-06-28 14:50:46 --> Output Class Initialized
DEBUG - 2010-06-28 14:50:46 --> Input Class Initialized
DEBUG - 2010-06-28 14:50:46 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 14:50:46 --> Language Class Initialized
DEBUG - 2010-06-28 14:50:47 --> Loader Class Initialized
DEBUG - 2010-06-28 14:50:47 --> Helper loaded: context_helper
DEBUG - 2010-06-28 14:50:47 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 14:50:47 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 14:50:47 --> Database Driver Class Initialized
DEBUG - 2010-06-28 14:50:47 --> Controller Class Initialized
DEBUG - 2010-06-28 14:50:47 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 14:50:47 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 14:50:47 --> Session Class Initialized
DEBUG - 2010-06-28 14:50:47 --> Helper loaded: string_helper
DEBUG - 2010-06-28 14:50:47 --> Session routines successfully run
DEBUG - 2010-06-28 14:50:48 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 14:50:48 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 14:50:48 --> Final output sent to browser
DEBUG - 2010-06-28 14:50:48 --> Total execution time: 2.1349
DEBUG - 2010-06-28 14:53:14 --> Config Class Initialized
DEBUG - 2010-06-28 14:53:14 --> Hooks Class Initialized
DEBUG - 2010-06-28 14:53:14 --> URI Class Initialized
DEBUG - 2010-06-28 14:53:14 --> Router Class Initialized
DEBUG - 2010-06-28 14:53:15 --> Output Class Initialized
DEBUG - 2010-06-28 14:53:15 --> Input Class Initialized
DEBUG - 2010-06-28 14:53:15 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 14:53:15 --> Language Class Initialized
DEBUG - 2010-06-28 14:53:15 --> Loader Class Initialized
DEBUG - 2010-06-28 14:53:15 --> Helper loaded: context_helper
DEBUG - 2010-06-28 14:53:15 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 14:53:15 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 14:53:15 --> Database Driver Class Initialized
DEBUG - 2010-06-28 14:53:15 --> Controller Class Initialized
DEBUG - 2010-06-28 14:53:15 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 14:53:15 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 14:53:16 --> Session Class Initialized
DEBUG - 2010-06-28 14:53:16 --> Helper loaded: string_helper
DEBUG - 2010-06-28 14:53:16 --> Session routines successfully run
DEBUG - 2010-06-28 14:53:16 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 14:53:17 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 14:53:17 --> Final output sent to browser
DEBUG - 2010-06-28 14:53:17 --> Total execution time: 2.8100
DEBUG - 2010-06-28 14:54:26 --> Config Class Initialized
DEBUG - 2010-06-28 14:54:26 --> Hooks Class Initialized
DEBUG - 2010-06-28 14:54:26 --> URI Class Initialized
DEBUG - 2010-06-28 14:54:26 --> Router Class Initialized
DEBUG - 2010-06-28 14:54:27 --> Output Class Initialized
DEBUG - 2010-06-28 14:54:27 --> Input Class Initialized
DEBUG - 2010-06-28 14:54:27 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 14:54:27 --> Language Class Initialized
DEBUG - 2010-06-28 14:54:27 --> Loader Class Initialized
DEBUG - 2010-06-28 14:54:27 --> Helper loaded: context_helper
DEBUG - 2010-06-28 14:54:27 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 14:54:27 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 14:54:27 --> Database Driver Class Initialized
DEBUG - 2010-06-28 14:54:27 --> Controller Class Initialized
DEBUG - 2010-06-28 14:54:27 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 14:54:27 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 14:54:28 --> Session Class Initialized
DEBUG - 2010-06-28 14:54:28 --> Helper loaded: string_helper
DEBUG - 2010-06-28 14:54:28 --> Session routines successfully run
DEBUG - 2010-06-28 14:54:28 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 14:54:28 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 14:54:28 --> Final output sent to browser
DEBUG - 2010-06-28 14:54:28 --> Total execution time: 2.1610
DEBUG - 2010-06-28 14:56:39 --> Config Class Initialized
DEBUG - 2010-06-28 14:56:39 --> Hooks Class Initialized
DEBUG - 2010-06-28 14:56:39 --> URI Class Initialized
DEBUG - 2010-06-28 14:56:39 --> Router Class Initialized
DEBUG - 2010-06-28 14:56:39 --> Output Class Initialized
DEBUG - 2010-06-28 14:56:39 --> Input Class Initialized
DEBUG - 2010-06-28 14:56:40 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 14:56:40 --> Language Class Initialized
DEBUG - 2010-06-28 14:56:40 --> Loader Class Initialized
DEBUG - 2010-06-28 14:56:40 --> Helper loaded: context_helper
DEBUG - 2010-06-28 14:56:40 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 14:56:40 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 14:56:40 --> Database Driver Class Initialized
DEBUG - 2010-06-28 14:56:40 --> Controller Class Initialized
DEBUG - 2010-06-28 14:56:40 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 14:56:40 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 14:56:40 --> Session Class Initialized
DEBUG - 2010-06-28 14:56:41 --> Helper loaded: string_helper
DEBUG - 2010-06-28 14:56:41 --> Session routines successfully run
DEBUG - 2010-06-28 14:56:42 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 14:56:43 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 14:56:43 --> Final output sent to browser
DEBUG - 2010-06-28 14:56:43 --> Total execution time: 4.3768
DEBUG - 2010-06-28 15:03:54 --> Config Class Initialized
DEBUG - 2010-06-28 15:03:54 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:03:54 --> URI Class Initialized
DEBUG - 2010-06-28 15:03:54 --> Router Class Initialized
DEBUG - 2010-06-28 15:03:54 --> Output Class Initialized
DEBUG - 2010-06-28 15:03:55 --> Input Class Initialized
DEBUG - 2010-06-28 15:03:55 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:03:55 --> Language Class Initialized
DEBUG - 2010-06-28 15:03:55 --> Loader Class Initialized
DEBUG - 2010-06-28 15:03:55 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:03:55 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:03:55 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:03:55 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:03:55 --> Controller Class Initialized
DEBUG - 2010-06-28 15:03:55 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:03:55 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:03:55 --> Session Class Initialized
DEBUG - 2010-06-28 15:03:56 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:03:56 --> Session routines successfully run
DEBUG - 2010-06-28 15:03:56 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-28 15:03:56 --> Severity: Warning  --> Missing argument 3 for get_cache(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php on line 675 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 96
ERROR - 2010-06-28 15:03:56 --> Severity: Notice  --> Undefined variable: value D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 100
ERROR - 2010-06-28 15:03:57 --> Severity: Warning  --> Missing argument 3 for set_cache(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php on line 690 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 74
ERROR - 2010-06-28 15:03:57 --> Severity: Notice  --> Undefined variable: value D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 78
ERROR - 2010-06-28 15:03:57 --> Severity: Warning  --> Missing argument 3 for get_cache(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php on line 675 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 96
ERROR - 2010-06-28 15:03:57 --> Severity: Notice  --> Undefined variable: value D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 100
ERROR - 2010-06-28 15:03:57 --> Severity: Warning  --> Missing argument 3 for set_cache(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php on line 690 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 74
ERROR - 2010-06-28 15:03:57 --> Severity: Notice  --> Undefined variable: value D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 78
DEBUG - 2010-06-28 15:03:58 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:03:58 --> Final output sent to browser
DEBUG - 2010-06-28 15:03:58 --> Total execution time: 3.5224
DEBUG - 2010-06-28 15:04:20 --> Config Class Initialized
DEBUG - 2010-06-28 15:04:20 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:04:20 --> URI Class Initialized
DEBUG - 2010-06-28 15:04:20 --> Router Class Initialized
DEBUG - 2010-06-28 15:04:20 --> Output Class Initialized
DEBUG - 2010-06-28 15:04:20 --> Input Class Initialized
DEBUG - 2010-06-28 15:04:20 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:04:20 --> Language Class Initialized
DEBUG - 2010-06-28 15:04:20 --> Loader Class Initialized
DEBUG - 2010-06-28 15:04:20 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:04:21 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:04:21 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:04:21 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:04:21 --> Controller Class Initialized
DEBUG - 2010-06-28 15:04:21 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:04:21 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:04:21 --> Session Class Initialized
DEBUG - 2010-06-28 15:04:21 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:04:21 --> Session routines successfully run
DEBUG - 2010-06-28 15:04:22 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:04:23 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:04:23 --> Final output sent to browser
DEBUG - 2010-06-28 15:04:23 --> Total execution time: 3.1549
DEBUG - 2010-06-28 15:04:56 --> Config Class Initialized
DEBUG - 2010-06-28 15:04:56 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:04:56 --> URI Class Initialized
DEBUG - 2010-06-28 15:04:56 --> Router Class Initialized
DEBUG - 2010-06-28 15:04:56 --> Output Class Initialized
DEBUG - 2010-06-28 15:04:56 --> Input Class Initialized
DEBUG - 2010-06-28 15:04:56 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:04:56 --> Language Class Initialized
DEBUG - 2010-06-28 15:04:56 --> Loader Class Initialized
DEBUG - 2010-06-28 15:04:57 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:04:57 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:04:57 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:04:57 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:04:57 --> Controller Class Initialized
DEBUG - 2010-06-28 15:04:57 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:04:57 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:04:57 --> Session Class Initialized
DEBUG - 2010-06-28 15:04:57 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:04:57 --> Session routines successfully run
DEBUG - 2010-06-28 15:04:58 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:04:59 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:04:59 --> Final output sent to browser
DEBUG - 2010-06-28 15:04:59 --> Total execution time: 2.8660
DEBUG - 2010-06-28 15:05:31 --> Config Class Initialized
DEBUG - 2010-06-28 15:05:31 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:05:32 --> URI Class Initialized
DEBUG - 2010-06-28 15:05:32 --> Router Class Initialized
DEBUG - 2010-06-28 15:05:32 --> Output Class Initialized
DEBUG - 2010-06-28 15:05:32 --> Input Class Initialized
DEBUG - 2010-06-28 15:05:32 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:05:32 --> Language Class Initialized
DEBUG - 2010-06-28 15:05:32 --> Loader Class Initialized
DEBUG - 2010-06-28 15:05:32 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:05:32 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:05:32 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:05:32 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:05:32 --> Controller Class Initialized
DEBUG - 2010-06-28 15:05:33 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:05:33 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:05:33 --> Session Class Initialized
DEBUG - 2010-06-28 15:05:33 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:05:33 --> Session routines successfully run
DEBUG - 2010-06-28 15:05:33 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:05:34 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:05:34 --> Final output sent to browser
DEBUG - 2010-06-28 15:05:34 --> Total execution time: 2.8582
DEBUG - 2010-06-28 15:06:47 --> Config Class Initialized
DEBUG - 2010-06-28 15:06:47 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:06:47 --> URI Class Initialized
DEBUG - 2010-06-28 15:06:47 --> Router Class Initialized
DEBUG - 2010-06-28 15:06:47 --> Output Class Initialized
DEBUG - 2010-06-28 15:06:47 --> Input Class Initialized
DEBUG - 2010-06-28 15:06:47 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:06:47 --> Language Class Initialized
DEBUG - 2010-06-28 15:06:47 --> Loader Class Initialized
DEBUG - 2010-06-28 15:06:47 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:06:48 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:06:48 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:06:48 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:06:48 --> Controller Class Initialized
DEBUG - 2010-06-28 15:06:48 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:06:48 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:06:48 --> Session Class Initialized
DEBUG - 2010-06-28 15:06:48 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:06:48 --> Session routines successfully run
DEBUG - 2010-06-28 15:06:49 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:06:50 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:06:50 --> Final output sent to browser
DEBUG - 2010-06-28 15:06:50 --> Total execution time: 2.8914
DEBUG - 2010-06-28 15:07:46 --> Config Class Initialized
DEBUG - 2010-06-28 15:07:46 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:07:46 --> URI Class Initialized
DEBUG - 2010-06-28 15:07:46 --> Router Class Initialized
DEBUG - 2010-06-28 15:07:47 --> Output Class Initialized
DEBUG - 2010-06-28 15:07:47 --> Input Class Initialized
DEBUG - 2010-06-28 15:07:47 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:07:47 --> Language Class Initialized
DEBUG - 2010-06-28 15:07:47 --> Loader Class Initialized
DEBUG - 2010-06-28 15:07:47 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:07:47 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:07:47 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:07:47 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:07:47 --> Controller Class Initialized
DEBUG - 2010-06-28 15:07:47 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:07:47 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:07:48 --> Session Class Initialized
DEBUG - 2010-06-28 15:07:48 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:07:48 --> Session routines successfully run
DEBUG - 2010-06-28 15:07:48 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:07:49 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:07:49 --> Final output sent to browser
DEBUG - 2010-06-28 15:07:49 --> Total execution time: 2.5536
DEBUG - 2010-06-28 15:08:00 --> Config Class Initialized
DEBUG - 2010-06-28 15:08:00 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:08:00 --> URI Class Initialized
DEBUG - 2010-06-28 15:08:00 --> Router Class Initialized
DEBUG - 2010-06-28 15:08:00 --> Output Class Initialized
DEBUG - 2010-06-28 15:08:00 --> Input Class Initialized
DEBUG - 2010-06-28 15:08:01 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:08:01 --> Language Class Initialized
DEBUG - 2010-06-28 15:08:01 --> Loader Class Initialized
DEBUG - 2010-06-28 15:08:01 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:08:01 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:08:01 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:08:01 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:08:01 --> Controller Class Initialized
DEBUG - 2010-06-28 15:08:01 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:08:01 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:08:01 --> Session Class Initialized
DEBUG - 2010-06-28 15:08:01 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:08:02 --> Session routines successfully run
DEBUG - 2010-06-28 15:08:02 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:08:03 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:08:03 --> Final output sent to browser
DEBUG - 2010-06-28 15:08:03 --> Total execution time: 2.9225
DEBUG - 2010-06-28 15:08:06 --> Config Class Initialized
DEBUG - 2010-06-28 15:08:06 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:08:06 --> URI Class Initialized
DEBUG - 2010-06-28 15:08:06 --> Router Class Initialized
DEBUG - 2010-06-28 15:08:07 --> Output Class Initialized
DEBUG - 2010-06-28 15:08:07 --> Input Class Initialized
DEBUG - 2010-06-28 15:08:07 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:08:07 --> Language Class Initialized
DEBUG - 2010-06-28 15:08:07 --> Loader Class Initialized
DEBUG - 2010-06-28 15:08:07 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:08:07 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:08:07 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:08:07 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:08:07 --> Controller Class Initialized
DEBUG - 2010-06-28 15:08:07 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:08:08 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:08:08 --> Session Class Initialized
DEBUG - 2010-06-28 15:08:08 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:08:08 --> Session routines successfully run
DEBUG - 2010-06-28 15:08:08 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:08:09 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:08:09 --> Final output sent to browser
DEBUG - 2010-06-28 15:08:09 --> Total execution time: 3.1168
DEBUG - 2010-06-28 15:08:21 --> Config Class Initialized
DEBUG - 2010-06-28 15:08:21 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:08:21 --> URI Class Initialized
DEBUG - 2010-06-28 15:08:21 --> Router Class Initialized
DEBUG - 2010-06-28 15:08:21 --> Output Class Initialized
DEBUG - 2010-06-28 15:08:21 --> Input Class Initialized
DEBUG - 2010-06-28 15:08:21 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:08:22 --> Language Class Initialized
DEBUG - 2010-06-28 15:08:22 --> Loader Class Initialized
DEBUG - 2010-06-28 15:08:22 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:08:22 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:08:22 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:08:22 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:08:22 --> Controller Class Initialized
DEBUG - 2010-06-28 15:08:22 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:08:22 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:08:22 --> Session Class Initialized
DEBUG - 2010-06-28 15:08:22 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:08:23 --> Session routines successfully run
DEBUG - 2010-06-28 15:08:23 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:08:23 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:08:24 --> Final output sent to browser
DEBUG - 2010-06-28 15:08:24 --> Total execution time: 2.5612
DEBUG - 2010-06-28 15:08:26 --> Config Class Initialized
DEBUG - 2010-06-28 15:08:26 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:08:26 --> URI Class Initialized
DEBUG - 2010-06-28 15:08:26 --> Router Class Initialized
DEBUG - 2010-06-28 15:08:26 --> Output Class Initialized
DEBUG - 2010-06-28 15:08:27 --> Input Class Initialized
DEBUG - 2010-06-28 15:08:27 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:08:27 --> Language Class Initialized
DEBUG - 2010-06-28 15:08:27 --> Loader Class Initialized
DEBUG - 2010-06-28 15:08:27 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:08:27 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:08:27 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:08:27 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:08:27 --> Controller Class Initialized
DEBUG - 2010-06-28 15:08:27 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:08:27 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:08:28 --> Session Class Initialized
DEBUG - 2010-06-28 15:08:28 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:08:28 --> Session routines successfully run
DEBUG - 2010-06-28 15:08:28 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:08:29 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:08:29 --> Final output sent to browser
DEBUG - 2010-06-28 15:08:29 --> Total execution time: 2.6859
DEBUG - 2010-06-28 15:08:32 --> Config Class Initialized
DEBUG - 2010-06-28 15:08:32 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:08:32 --> URI Class Initialized
DEBUG - 2010-06-28 15:08:32 --> Router Class Initialized
DEBUG - 2010-06-28 15:08:32 --> Output Class Initialized
DEBUG - 2010-06-28 15:08:32 --> Input Class Initialized
DEBUG - 2010-06-28 15:08:32 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:08:32 --> Language Class Initialized
DEBUG - 2010-06-28 15:08:32 --> Loader Class Initialized
DEBUG - 2010-06-28 15:08:32 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:08:32 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:08:32 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:08:33 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:08:33 --> Controller Class Initialized
DEBUG - 2010-06-28 15:08:33 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:08:33 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:08:33 --> Session Class Initialized
DEBUG - 2010-06-28 15:08:33 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:08:33 --> Session routines successfully run
DEBUG - 2010-06-28 15:08:34 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:08:34 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:08:34 --> Final output sent to browser
DEBUG - 2010-06-28 15:08:34 --> Total execution time: 2.5841
DEBUG - 2010-06-28 15:08:48 --> Config Class Initialized
DEBUG - 2010-06-28 15:08:48 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:08:48 --> URI Class Initialized
DEBUG - 2010-06-28 15:08:48 --> Router Class Initialized
DEBUG - 2010-06-28 15:08:48 --> Output Class Initialized
DEBUG - 2010-06-28 15:08:49 --> Input Class Initialized
DEBUG - 2010-06-28 15:08:49 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:08:49 --> Language Class Initialized
DEBUG - 2010-06-28 15:08:49 --> Loader Class Initialized
DEBUG - 2010-06-28 15:08:49 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:08:49 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:08:49 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:08:49 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:08:49 --> Controller Class Initialized
DEBUG - 2010-06-28 15:08:49 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:08:50 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:08:50 --> Session Class Initialized
DEBUG - 2010-06-28 15:08:50 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:08:50 --> Session routines successfully run
DEBUG - 2010-06-28 15:08:50 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:08:51 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:08:51 --> Final output sent to browser
DEBUG - 2010-06-28 15:08:51 --> Total execution time: 2.6677
DEBUG - 2010-06-28 15:09:26 --> Config Class Initialized
DEBUG - 2010-06-28 15:09:26 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:09:26 --> URI Class Initialized
DEBUG - 2010-06-28 15:09:26 --> Router Class Initialized
DEBUG - 2010-06-28 15:09:26 --> Output Class Initialized
DEBUG - 2010-06-28 15:09:27 --> Input Class Initialized
DEBUG - 2010-06-28 15:09:27 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:09:27 --> Language Class Initialized
DEBUG - 2010-06-28 15:09:27 --> Loader Class Initialized
DEBUG - 2010-06-28 15:09:27 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:09:27 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:09:27 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:09:27 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:09:27 --> Controller Class Initialized
DEBUG - 2010-06-28 15:09:27 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:09:27 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:09:28 --> Session Class Initialized
DEBUG - 2010-06-28 15:09:28 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:09:28 --> Session routines successfully run
DEBUG - 2010-06-28 15:09:28 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:09:29 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:09:29 --> Final output sent to browser
DEBUG - 2010-06-28 15:09:29 --> Total execution time: 2.6371
DEBUG - 2010-06-28 15:09:41 --> Config Class Initialized
DEBUG - 2010-06-28 15:09:41 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:09:41 --> URI Class Initialized
DEBUG - 2010-06-28 15:09:41 --> Router Class Initialized
DEBUG - 2010-06-28 15:09:41 --> Output Class Initialized
DEBUG - 2010-06-28 15:09:41 --> Input Class Initialized
DEBUG - 2010-06-28 15:09:41 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:09:42 --> Language Class Initialized
DEBUG - 2010-06-28 15:09:42 --> Loader Class Initialized
DEBUG - 2010-06-28 15:09:42 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:09:42 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:09:42 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:09:42 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:09:42 --> Controller Class Initialized
DEBUG - 2010-06-28 15:09:42 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:09:42 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:10:28 --> Config Class Initialized
DEBUG - 2010-06-28 15:10:28 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:10:28 --> URI Class Initialized
DEBUG - 2010-06-28 15:10:28 --> Router Class Initialized
DEBUG - 2010-06-28 15:10:28 --> Output Class Initialized
DEBUG - 2010-06-28 15:10:28 --> Input Class Initialized
DEBUG - 2010-06-28 15:10:28 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:10:28 --> Language Class Initialized
DEBUG - 2010-06-28 15:10:29 --> Loader Class Initialized
DEBUG - 2010-06-28 15:10:29 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:10:29 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:10:29 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:10:29 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:10:29 --> Controller Class Initialized
DEBUG - 2010-06-28 15:10:29 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:10:29 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:10:29 --> Session Class Initialized
DEBUG - 2010-06-28 15:10:29 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:10:29 --> Session routines successfully run
DEBUG - 2010-06-28 15:10:30 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:10:30 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:10:31 --> Final output sent to browser
DEBUG - 2010-06-28 15:10:31 --> Total execution time: 2.7562
DEBUG - 2010-06-28 15:11:08 --> Config Class Initialized
DEBUG - 2010-06-28 15:11:09 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:11:09 --> URI Class Initialized
DEBUG - 2010-06-28 15:11:09 --> Router Class Initialized
DEBUG - 2010-06-28 15:11:09 --> Output Class Initialized
DEBUG - 2010-06-28 15:11:09 --> Input Class Initialized
DEBUG - 2010-06-28 15:11:09 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:11:09 --> Language Class Initialized
DEBUG - 2010-06-28 15:11:09 --> Loader Class Initialized
DEBUG - 2010-06-28 15:11:09 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:11:09 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:11:10 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:11:10 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:11:10 --> Controller Class Initialized
DEBUG - 2010-06-28 15:11:10 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:11:10 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:11:10 --> Session Class Initialized
DEBUG - 2010-06-28 15:11:10 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:11:10 --> Session routines successfully run
DEBUG - 2010-06-28 15:11:11 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:11:11 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:11:11 --> Final output sent to browser
DEBUG - 2010-06-28 15:11:11 --> Total execution time: 2.8307
DEBUG - 2010-06-28 15:11:14 --> Config Class Initialized
DEBUG - 2010-06-28 15:11:14 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:11:14 --> URI Class Initialized
DEBUG - 2010-06-28 15:11:14 --> Router Class Initialized
DEBUG - 2010-06-28 15:11:14 --> Output Class Initialized
DEBUG - 2010-06-28 15:11:14 --> Input Class Initialized
DEBUG - 2010-06-28 15:11:14 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:11:15 --> Language Class Initialized
DEBUG - 2010-06-28 15:11:15 --> Loader Class Initialized
DEBUG - 2010-06-28 15:11:15 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:11:15 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:11:15 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:11:15 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:11:15 --> Controller Class Initialized
DEBUG - 2010-06-28 15:11:15 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:11:15 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:11:15 --> Session Class Initialized
DEBUG - 2010-06-28 15:11:15 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:11:16 --> Session routines successfully run
DEBUG - 2010-06-28 15:11:16 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:11:17 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:11:17 --> Final output sent to browser
DEBUG - 2010-06-28 15:11:17 --> Total execution time: 3.0539
DEBUG - 2010-06-28 15:11:24 --> Config Class Initialized
DEBUG - 2010-06-28 15:11:25 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:11:25 --> URI Class Initialized
DEBUG - 2010-06-28 15:11:25 --> Router Class Initialized
DEBUG - 2010-06-28 15:11:25 --> Output Class Initialized
DEBUG - 2010-06-28 15:11:25 --> Input Class Initialized
DEBUG - 2010-06-28 15:11:25 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:11:25 --> Language Class Initialized
DEBUG - 2010-06-28 15:11:25 --> Loader Class Initialized
DEBUG - 2010-06-28 15:11:25 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:11:25 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:11:26 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:11:26 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:11:26 --> Controller Class Initialized
DEBUG - 2010-06-28 15:11:26 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:11:26 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:11:26 --> Session Class Initialized
DEBUG - 2010-06-28 15:11:26 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:11:26 --> Session routines successfully run
DEBUG - 2010-06-28 15:11:27 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:11:27 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:11:27 --> Final output sent to browser
DEBUG - 2010-06-28 15:11:27 --> Total execution time: 2.7422
DEBUG - 2010-06-28 15:17:08 --> Config Class Initialized
DEBUG - 2010-06-28 15:17:08 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:17:08 --> URI Class Initialized
DEBUG - 2010-06-28 15:17:08 --> Router Class Initialized
DEBUG - 2010-06-28 15:17:08 --> Output Class Initialized
DEBUG - 2010-06-28 15:17:08 --> Input Class Initialized
DEBUG - 2010-06-28 15:17:08 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:17:08 --> Language Class Initialized
DEBUG - 2010-06-28 15:17:08 --> Loader Class Initialized
DEBUG - 2010-06-28 15:17:09 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:17:09 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:17:09 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:17:09 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:17:09 --> Controller Class Initialized
DEBUG - 2010-06-28 15:17:09 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:17:09 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:17:09 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 15:17:09 --> Session Class Initialized
DEBUG - 2010-06-28 15:17:09 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:17:10 --> Session routines successfully run
DEBUG - 2010-06-28 15:17:10 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:17:10 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:17:11 --> Final output sent to browser
DEBUG - 2010-06-28 15:17:11 --> Total execution time: 2.8527
DEBUG - 2010-06-28 15:17:14 --> Config Class Initialized
DEBUG - 2010-06-28 15:17:14 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:17:14 --> URI Class Initialized
DEBUG - 2010-06-28 15:17:14 --> Router Class Initialized
DEBUG - 2010-06-28 15:17:14 --> Output Class Initialized
DEBUG - 2010-06-28 15:17:14 --> Input Class Initialized
DEBUG - 2010-06-28 15:17:14 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:17:15 --> Language Class Initialized
DEBUG - 2010-06-28 15:17:15 --> Loader Class Initialized
DEBUG - 2010-06-28 15:17:15 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:17:15 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:17:15 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:17:15 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:17:15 --> Controller Class Initialized
DEBUG - 2010-06-28 15:17:15 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:17:15 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:17:15 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 15:17:16 --> Session Class Initialized
DEBUG - 2010-06-28 15:17:16 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:17:16 --> Session routines successfully run
DEBUG - 2010-06-28 15:17:16 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:17:17 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:17:17 --> Final output sent to browser
DEBUG - 2010-06-28 15:17:17 --> Total execution time: 2.8697
DEBUG - 2010-06-28 15:17:42 --> Config Class Initialized
DEBUG - 2010-06-28 15:17:42 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:17:42 --> URI Class Initialized
DEBUG - 2010-06-28 15:17:43 --> Router Class Initialized
DEBUG - 2010-06-28 15:17:43 --> Output Class Initialized
DEBUG - 2010-06-28 15:17:43 --> Input Class Initialized
DEBUG - 2010-06-28 15:17:43 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:17:43 --> Language Class Initialized
DEBUG - 2010-06-28 15:17:43 --> Loader Class Initialized
DEBUG - 2010-06-28 15:17:43 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:17:43 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:17:43 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:17:43 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:17:43 --> Controller Class Initialized
DEBUG - 2010-06-28 15:17:44 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:17:44 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:17:44 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 15:17:44 --> Session Class Initialized
DEBUG - 2010-06-28 15:17:44 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:17:44 --> Session routines successfully run
DEBUG - 2010-06-28 15:17:44 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:17:45 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:17:45 --> Final output sent to browser
DEBUG - 2010-06-28 15:17:45 --> Total execution time: 2.8149
DEBUG - 2010-06-28 15:19:13 --> Config Class Initialized
DEBUG - 2010-06-28 15:19:13 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:19:13 --> URI Class Initialized
DEBUG - 2010-06-28 15:19:13 --> Router Class Initialized
DEBUG - 2010-06-28 15:19:13 --> Output Class Initialized
DEBUG - 2010-06-28 15:19:13 --> Input Class Initialized
DEBUG - 2010-06-28 15:19:13 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:19:13 --> Language Class Initialized
DEBUG - 2010-06-28 15:19:14 --> Loader Class Initialized
DEBUG - 2010-06-28 15:19:14 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:19:14 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:19:14 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:19:14 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:19:14 --> Controller Class Initialized
DEBUG - 2010-06-28 15:19:14 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:19:14 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:19:14 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 15:19:15 --> Session Class Initialized
DEBUG - 2010-06-28 15:19:15 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:19:15 --> Session routines successfully run
DEBUG - 2010-06-28 15:19:15 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:19:16 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:19:16 --> Final output sent to browser
DEBUG - 2010-06-28 15:19:16 --> Total execution time: 3.2291
DEBUG - 2010-06-28 15:19:18 --> Config Class Initialized
DEBUG - 2010-06-28 15:19:18 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:19:18 --> URI Class Initialized
DEBUG - 2010-06-28 15:19:18 --> Router Class Initialized
DEBUG - 2010-06-28 15:19:18 --> Output Class Initialized
DEBUG - 2010-06-28 15:19:18 --> Input Class Initialized
DEBUG - 2010-06-28 15:19:18 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:19:18 --> Language Class Initialized
DEBUG - 2010-06-28 15:19:19 --> Loader Class Initialized
DEBUG - 2010-06-28 15:19:19 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:19:19 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:19:19 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:19:19 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:19:19 --> Controller Class Initialized
DEBUG - 2010-06-28 15:19:19 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:19:19 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:19:19 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 15:19:19 --> Session Class Initialized
DEBUG - 2010-06-28 15:19:20 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:19:20 --> Session routines successfully run
DEBUG - 2010-06-28 15:19:20 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:19:21 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:19:21 --> Final output sent to browser
DEBUG - 2010-06-28 15:19:21 --> Total execution time: 2.8369
DEBUG - 2010-06-28 15:19:22 --> Config Class Initialized
DEBUG - 2010-06-28 15:19:22 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:19:22 --> URI Class Initialized
DEBUG - 2010-06-28 15:19:22 --> Router Class Initialized
DEBUG - 2010-06-28 15:19:23 --> Output Class Initialized
DEBUG - 2010-06-28 15:19:23 --> Input Class Initialized
DEBUG - 2010-06-28 15:19:23 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:19:23 --> Language Class Initialized
DEBUG - 2010-06-28 15:19:23 --> Loader Class Initialized
DEBUG - 2010-06-28 15:19:23 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:19:23 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:19:23 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:19:23 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:19:23 --> Controller Class Initialized
DEBUG - 2010-06-28 15:19:24 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:19:24 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:19:24 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 15:19:24 --> Session Class Initialized
DEBUG - 2010-06-28 15:19:24 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:19:24 --> Session routines successfully run
DEBUG - 2010-06-28 15:19:24 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:19:25 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:19:25 --> Final output sent to browser
DEBUG - 2010-06-28 15:19:25 --> Total execution time: 2.8074
DEBUG - 2010-06-28 15:19:53 --> Config Class Initialized
DEBUG - 2010-06-28 15:19:53 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:19:53 --> URI Class Initialized
DEBUG - 2010-06-28 15:19:53 --> Router Class Initialized
DEBUG - 2010-06-28 15:19:54 --> Output Class Initialized
DEBUG - 2010-06-28 15:19:54 --> Input Class Initialized
DEBUG - 2010-06-28 15:19:54 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:19:54 --> Language Class Initialized
DEBUG - 2010-06-28 15:19:54 --> Loader Class Initialized
DEBUG - 2010-06-28 15:19:54 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:19:54 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:19:54 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:19:54 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:19:54 --> Controller Class Initialized
DEBUG - 2010-06-28 15:19:54 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:19:55 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:19:55 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 15:19:55 --> Session Class Initialized
DEBUG - 2010-06-28 15:19:55 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:19:55 --> Session routines successfully run
DEBUG - 2010-06-28 15:19:55 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:19:56 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:19:56 --> Final output sent to browser
DEBUG - 2010-06-28 15:19:56 --> Total execution time: 2.8566
DEBUG - 2010-06-28 15:19:59 --> Config Class Initialized
DEBUG - 2010-06-28 15:19:59 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:19:59 --> URI Class Initialized
DEBUG - 2010-06-28 15:19:59 --> Router Class Initialized
DEBUG - 2010-06-28 15:19:59 --> Output Class Initialized
DEBUG - 2010-06-28 15:19:59 --> Input Class Initialized
DEBUG - 2010-06-28 15:19:59 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:19:59 --> Language Class Initialized
DEBUG - 2010-06-28 15:19:59 --> Loader Class Initialized
DEBUG - 2010-06-28 15:19:59 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:20:00 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:20:00 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:20:00 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:20:00 --> Controller Class Initialized
DEBUG - 2010-06-28 15:20:00 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:20:00 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:20:00 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 15:20:00 --> Session Class Initialized
DEBUG - 2010-06-28 15:20:00 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:20:00 --> Session routines successfully run
DEBUG - 2010-06-28 15:20:03 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:20:04 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:20:04 --> Final output sent to browser
DEBUG - 2010-06-28 15:20:04 --> Total execution time: 5.1755
DEBUG - 2010-06-28 15:20:11 --> Config Class Initialized
DEBUG - 2010-06-28 15:20:11 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:20:11 --> URI Class Initialized
DEBUG - 2010-06-28 15:20:11 --> Router Class Initialized
DEBUG - 2010-06-28 15:20:11 --> Output Class Initialized
DEBUG - 2010-06-28 15:20:11 --> Input Class Initialized
DEBUG - 2010-06-28 15:20:11 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:20:11 --> Language Class Initialized
DEBUG - 2010-06-28 15:20:11 --> Loader Class Initialized
DEBUG - 2010-06-28 15:20:11 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:20:11 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:20:12 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:20:12 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:20:12 --> Controller Class Initialized
DEBUG - 2010-06-28 15:20:12 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:20:12 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:20:12 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 15:20:12 --> Session Class Initialized
DEBUG - 2010-06-28 15:20:12 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:20:12 --> Session routines successfully run
DEBUG - 2010-06-28 15:20:13 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:20:13 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:20:13 --> Final output sent to browser
DEBUG - 2010-06-28 15:20:13 --> Total execution time: 2.8768
DEBUG - 2010-06-28 15:20:28 --> Config Class Initialized
DEBUG - 2010-06-28 15:20:28 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:20:28 --> URI Class Initialized
DEBUG - 2010-06-28 15:20:28 --> Router Class Initialized
DEBUG - 2010-06-28 15:20:28 --> Output Class Initialized
DEBUG - 2010-06-28 15:20:28 --> Input Class Initialized
DEBUG - 2010-06-28 15:20:28 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:20:28 --> Language Class Initialized
DEBUG - 2010-06-28 15:20:28 --> Loader Class Initialized
DEBUG - 2010-06-28 15:20:29 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:20:29 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:20:29 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:20:29 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:20:29 --> Controller Class Initialized
DEBUG - 2010-06-28 15:20:29 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:20:29 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:20:29 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 15:20:29 --> Session Class Initialized
DEBUG - 2010-06-28 15:20:29 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:20:30 --> Session routines successfully run
DEBUG - 2010-06-28 15:20:30 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:20:30 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:20:31 --> Final output sent to browser
DEBUG - 2010-06-28 15:20:31 --> Total execution time: 2.9116
DEBUG - 2010-06-28 15:20:57 --> Config Class Initialized
DEBUG - 2010-06-28 15:20:57 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:20:57 --> URI Class Initialized
DEBUG - 2010-06-28 15:20:58 --> Router Class Initialized
DEBUG - 2010-06-28 15:20:58 --> Output Class Initialized
DEBUG - 2010-06-28 15:20:58 --> Input Class Initialized
DEBUG - 2010-06-28 15:20:58 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:20:58 --> Language Class Initialized
DEBUG - 2010-06-28 15:20:58 --> Loader Class Initialized
DEBUG - 2010-06-28 15:20:58 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:20:58 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:20:58 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:20:58 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:20:59 --> Controller Class Initialized
DEBUG - 2010-06-28 15:20:59 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:20:59 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:20:59 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 15:20:59 --> Session Class Initialized
DEBUG - 2010-06-28 15:20:59 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:20:59 --> Session routines successfully run
DEBUG - 2010-06-28 15:21:00 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:21:00 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:21:00 --> Final output sent to browser
DEBUG - 2010-06-28 15:21:00 --> Total execution time: 3.0582
DEBUG - 2010-06-28 15:21:10 --> Config Class Initialized
DEBUG - 2010-06-28 15:21:10 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:21:10 --> URI Class Initialized
DEBUG - 2010-06-28 15:21:10 --> Router Class Initialized
DEBUG - 2010-06-28 15:21:10 --> Output Class Initialized
DEBUG - 2010-06-28 15:21:10 --> Input Class Initialized
DEBUG - 2010-06-28 15:21:11 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:21:11 --> Language Class Initialized
DEBUG - 2010-06-28 15:21:11 --> Loader Class Initialized
DEBUG - 2010-06-28 15:21:11 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:21:11 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:21:11 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:21:11 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:21:11 --> Controller Class Initialized
DEBUG - 2010-06-28 15:21:11 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:21:11 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:21:12 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 15:21:12 --> Session Class Initialized
DEBUG - 2010-06-28 15:21:12 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:21:12 --> Session routines successfully run
DEBUG - 2010-06-28 15:21:12 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:21:13 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:21:13 --> Final output sent to browser
DEBUG - 2010-06-28 15:21:13 --> Total execution time: 2.9789
DEBUG - 2010-06-28 15:21:28 --> Config Class Initialized
DEBUG - 2010-06-28 15:21:28 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:21:28 --> URI Class Initialized
DEBUG - 2010-06-28 15:21:28 --> Router Class Initialized
DEBUG - 2010-06-28 15:21:28 --> Output Class Initialized
DEBUG - 2010-06-28 15:21:29 --> Input Class Initialized
DEBUG - 2010-06-28 15:21:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:21:29 --> Language Class Initialized
DEBUG - 2010-06-28 15:21:29 --> Loader Class Initialized
DEBUG - 2010-06-28 15:21:29 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:21:29 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:21:29 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:21:29 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:21:29 --> Controller Class Initialized
DEBUG - 2010-06-28 15:21:29 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:21:30 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:21:30 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 15:21:30 --> Session Class Initialized
DEBUG - 2010-06-28 15:21:30 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:21:30 --> Session routines successfully run
DEBUG - 2010-06-28 15:21:31 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:21:32 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:21:32 --> Final output sent to browser
DEBUG - 2010-06-28 15:21:32 --> Total execution time: 3.6380
DEBUG - 2010-06-28 15:22:00 --> Config Class Initialized
DEBUG - 2010-06-28 15:22:00 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:22:01 --> URI Class Initialized
DEBUG - 2010-06-28 15:22:01 --> Router Class Initialized
DEBUG - 2010-06-28 15:22:01 --> Output Class Initialized
DEBUG - 2010-06-28 15:22:01 --> Input Class Initialized
DEBUG - 2010-06-28 15:22:01 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:22:01 --> Language Class Initialized
DEBUG - 2010-06-28 15:22:01 --> Loader Class Initialized
DEBUG - 2010-06-28 15:22:01 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:22:01 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:22:01 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:22:02 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:22:02 --> Controller Class Initialized
DEBUG - 2010-06-28 15:22:02 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:22:02 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:22:02 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 15:22:02 --> Session Class Initialized
DEBUG - 2010-06-28 15:22:02 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:22:02 --> Session routines successfully run
DEBUG - 2010-06-28 15:22:03 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:22:03 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:22:03 --> Final output sent to browser
DEBUG - 2010-06-28 15:22:03 --> Total execution time: 2.9281
DEBUG - 2010-06-28 15:22:15 --> Config Class Initialized
DEBUG - 2010-06-28 15:22:15 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:22:15 --> URI Class Initialized
DEBUG - 2010-06-28 15:22:15 --> Router Class Initialized
DEBUG - 2010-06-28 15:22:16 --> Output Class Initialized
DEBUG - 2010-06-28 15:22:16 --> Input Class Initialized
DEBUG - 2010-06-28 15:22:16 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:22:16 --> Language Class Initialized
DEBUG - 2010-06-28 15:22:16 --> Loader Class Initialized
DEBUG - 2010-06-28 15:22:16 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:22:16 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:22:16 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:22:16 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:22:16 --> Controller Class Initialized
DEBUG - 2010-06-28 15:22:17 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:22:17 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:22:17 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 15:22:17 --> Session Class Initialized
DEBUG - 2010-06-28 15:22:17 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:22:17 --> Session routines successfully run
DEBUG - 2010-06-28 15:22:18 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:22:18 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:22:18 --> Final output sent to browser
DEBUG - 2010-06-28 15:22:18 --> Total execution time: 2.9553
DEBUG - 2010-06-28 15:22:22 --> Config Class Initialized
DEBUG - 2010-06-28 15:22:22 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:22:22 --> URI Class Initialized
DEBUG - 2010-06-28 15:22:22 --> Router Class Initialized
DEBUG - 2010-06-28 15:22:22 --> Output Class Initialized
DEBUG - 2010-06-28 15:22:22 --> Input Class Initialized
DEBUG - 2010-06-28 15:22:22 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:22:23 --> Language Class Initialized
DEBUG - 2010-06-28 15:22:23 --> Loader Class Initialized
DEBUG - 2010-06-28 15:22:23 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:22:23 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:22:23 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:22:23 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:22:23 --> Controller Class Initialized
DEBUG - 2010-06-28 15:22:23 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:22:23 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:22:24 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 15:22:24 --> Session Class Initialized
DEBUG - 2010-06-28 15:22:24 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:22:24 --> Session routines successfully run
DEBUG - 2010-06-28 15:22:24 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:22:25 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:22:25 --> Final output sent to browser
DEBUG - 2010-06-28 15:22:25 --> Total execution time: 3.0949
DEBUG - 2010-06-28 15:24:11 --> Config Class Initialized
DEBUG - 2010-06-28 15:24:11 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:24:12 --> URI Class Initialized
DEBUG - 2010-06-28 15:24:12 --> Router Class Initialized
DEBUG - 2010-06-28 15:24:12 --> Output Class Initialized
DEBUG - 2010-06-28 15:24:12 --> Input Class Initialized
DEBUG - 2010-06-28 15:24:12 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:24:12 --> Language Class Initialized
DEBUG - 2010-06-28 15:24:12 --> Loader Class Initialized
DEBUG - 2010-06-28 15:24:12 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:24:12 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:24:12 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:24:13 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:24:13 --> Controller Class Initialized
DEBUG - 2010-06-28 15:24:13 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:24:13 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:24:13 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 15:24:13 --> Session Class Initialized
DEBUG - 2010-06-28 15:24:13 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:24:13 --> Session routines successfully run
DEBUG - 2010-06-28 15:24:14 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:24:14 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:24:14 --> Final output sent to browser
DEBUG - 2010-06-28 15:24:14 --> Total execution time: 2.9453
DEBUG - 2010-06-28 15:26:17 --> Config Class Initialized
DEBUG - 2010-06-28 15:26:18 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:26:18 --> URI Class Initialized
DEBUG - 2010-06-28 15:26:18 --> Router Class Initialized
DEBUG - 2010-06-28 15:26:18 --> Output Class Initialized
DEBUG - 2010-06-28 15:26:18 --> Input Class Initialized
DEBUG - 2010-06-28 15:26:18 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:26:18 --> Language Class Initialized
DEBUG - 2010-06-28 15:26:18 --> Loader Class Initialized
DEBUG - 2010-06-28 15:26:18 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:26:19 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:26:19 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:26:19 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:26:31 --> Config Class Initialized
DEBUG - 2010-06-28 15:26:31 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:26:31 --> URI Class Initialized
DEBUG - 2010-06-28 15:26:31 --> Router Class Initialized
DEBUG - 2010-06-28 15:26:31 --> Output Class Initialized
DEBUG - 2010-06-28 15:26:31 --> Input Class Initialized
DEBUG - 2010-06-28 15:26:31 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:26:31 --> Language Class Initialized
DEBUG - 2010-06-28 15:26:31 --> Loader Class Initialized
DEBUG - 2010-06-28 15:26:32 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:26:32 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:26:32 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:26:32 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:26:32 --> Controller Class Initialized
DEBUG - 2010-06-28 15:26:32 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:26:32 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:26:32 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 15:26:32 --> Session Class Initialized
DEBUG - 2010-06-28 15:26:33 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:26:33 --> Session routines successfully run
DEBUG - 2010-06-28 15:26:33 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-28 15:26:34 --> Severity: Notice  --> Undefined property: Ut_domain::$CI D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php 88
ERROR - 2010-06-28 15:26:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php 88
DEBUG - 2010-06-28 15:26:47 --> Config Class Initialized
DEBUG - 2010-06-28 15:26:47 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:26:47 --> URI Class Initialized
DEBUG - 2010-06-28 15:26:47 --> Router Class Initialized
DEBUG - 2010-06-28 15:26:47 --> Output Class Initialized
DEBUG - 2010-06-28 15:26:47 --> Input Class Initialized
DEBUG - 2010-06-28 15:26:47 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:26:47 --> Language Class Initialized
DEBUG - 2010-06-28 15:26:48 --> Loader Class Initialized
DEBUG - 2010-06-28 15:26:48 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:26:48 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:26:48 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:26:48 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:26:48 --> Controller Class Initialized
DEBUG - 2010-06-28 15:26:48 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:26:48 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:26:48 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 15:26:48 --> Session Class Initialized
DEBUG - 2010-06-28 15:26:49 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:26:49 --> Session routines successfully run
DEBUG - 2010-06-28 15:26:49 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-28 15:26:50 --> Severity: Warning  --> Missing argument 1 for Generic_object::find_all(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 88 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 618
ERROR - 2010-06-28 15:26:50 --> Severity: Notice  --> Undefined variable: cond D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 620
ERROR - 2010-06-28 15:26:50 --> Severity: Notice  --> Undefined variable: obj D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 638
DEBUG - 2010-06-28 15:26:50 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:26:50 --> Final output sent to browser
DEBUG - 2010-06-28 15:26:50 --> Total execution time: 3.3373
DEBUG - 2010-06-28 15:27:55 --> Config Class Initialized
DEBUG - 2010-06-28 15:27:55 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:27:55 --> URI Class Initialized
DEBUG - 2010-06-28 15:27:55 --> Router Class Initialized
DEBUG - 2010-06-28 15:27:55 --> Output Class Initialized
DEBUG - 2010-06-28 15:27:55 --> Input Class Initialized
DEBUG - 2010-06-28 15:27:55 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:27:55 --> Language Class Initialized
DEBUG - 2010-06-28 15:27:55 --> Loader Class Initialized
DEBUG - 2010-06-28 15:27:56 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:27:56 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:27:56 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:27:56 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:27:56 --> Controller Class Initialized
DEBUG - 2010-06-28 15:27:56 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:27:56 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:27:56 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 15:27:57 --> Session Class Initialized
DEBUG - 2010-06-28 15:27:57 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:27:57 --> Session routines successfully run
DEBUG - 2010-06-28 15:27:57 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-28 15:27:58 --> Severity: Notice  --> Undefined variable: obj D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 641
DEBUG - 2010-06-28 15:27:58 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:27:58 --> Final output sent to browser
DEBUG - 2010-06-28 15:27:58 --> Total execution time: 3.6846
DEBUG - 2010-06-28 15:28:22 --> Config Class Initialized
DEBUG - 2010-06-28 15:28:22 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:28:22 --> URI Class Initialized
DEBUG - 2010-06-28 15:28:22 --> Router Class Initialized
DEBUG - 2010-06-28 15:28:22 --> Output Class Initialized
DEBUG - 2010-06-28 15:28:22 --> Input Class Initialized
DEBUG - 2010-06-28 15:28:22 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:28:22 --> Language Class Initialized
DEBUG - 2010-06-28 15:28:22 --> Loader Class Initialized
DEBUG - 2010-06-28 15:28:23 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:28:23 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:28:23 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:28:23 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:28:23 --> Controller Class Initialized
DEBUG - 2010-06-28 15:28:23 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:28:23 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:28:23 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 15:28:23 --> Session Class Initialized
DEBUG - 2010-06-28 15:28:23 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:28:24 --> Session routines successfully run
DEBUG - 2010-06-28 15:28:24 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:28:24 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:28:25 --> Final output sent to browser
DEBUG - 2010-06-28 15:28:25 --> Total execution time: 3.0798
DEBUG - 2010-06-28 15:29:05 --> Config Class Initialized
DEBUG - 2010-06-28 15:29:05 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:29:05 --> URI Class Initialized
DEBUG - 2010-06-28 15:29:05 --> Router Class Initialized
DEBUG - 2010-06-28 15:29:05 --> Output Class Initialized
DEBUG - 2010-06-28 15:29:05 --> Input Class Initialized
DEBUG - 2010-06-28 15:29:05 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:29:06 --> Language Class Initialized
DEBUG - 2010-06-28 15:29:06 --> Loader Class Initialized
DEBUG - 2010-06-28 15:29:06 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:29:06 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:29:06 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:29:06 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:29:06 --> Controller Class Initialized
DEBUG - 2010-06-28 15:29:06 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:29:06 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:29:06 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 15:29:07 --> Session Class Initialized
DEBUG - 2010-06-28 15:29:07 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:29:07 --> Session routines successfully run
DEBUG - 2010-06-28 15:29:07 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:29:08 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:29:08 --> Final output sent to browser
DEBUG - 2010-06-28 15:29:08 --> Total execution time: 3.3356
DEBUG - 2010-06-28 15:29:57 --> Config Class Initialized
DEBUG - 2010-06-28 15:29:57 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:29:57 --> URI Class Initialized
DEBUG - 2010-06-28 15:29:57 --> Router Class Initialized
DEBUG - 2010-06-28 15:29:57 --> Output Class Initialized
DEBUG - 2010-06-28 15:29:57 --> Input Class Initialized
DEBUG - 2010-06-28 15:29:57 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:29:57 --> Language Class Initialized
DEBUG - 2010-06-28 15:29:58 --> Loader Class Initialized
DEBUG - 2010-06-28 15:29:58 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:29:58 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:29:58 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:29:58 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:29:58 --> Controller Class Initialized
DEBUG - 2010-06-28 15:29:58 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:29:58 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:29:58 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 15:29:59 --> Session Class Initialized
DEBUG - 2010-06-28 15:29:59 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:29:59 --> Session routines successfully run
DEBUG - 2010-06-28 15:29:59 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:30:00 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:30:00 --> Final output sent to browser
DEBUG - 2010-06-28 15:30:00 --> Total execution time: 3.2244
DEBUG - 2010-06-28 15:33:26 --> Config Class Initialized
DEBUG - 2010-06-28 15:33:26 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:33:26 --> URI Class Initialized
DEBUG - 2010-06-28 15:33:26 --> Router Class Initialized
DEBUG - 2010-06-28 15:33:26 --> Output Class Initialized
DEBUG - 2010-06-28 15:33:26 --> Input Class Initialized
DEBUG - 2010-06-28 15:33:27 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:33:27 --> Language Class Initialized
DEBUG - 2010-06-28 15:33:27 --> Loader Class Initialized
DEBUG - 2010-06-28 15:33:27 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:33:27 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:33:27 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:33:27 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:33:27 --> Controller Class Initialized
DEBUG - 2010-06-28 15:33:28 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:33:28 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:33:28 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 15:33:28 --> Session Class Initialized
DEBUG - 2010-06-28 15:33:28 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:33:28 --> Session routines successfully run
DEBUG - 2010-06-28 15:33:29 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:33:29 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:33:29 --> Final output sent to browser
DEBUG - 2010-06-28 15:33:29 --> Total execution time: 3.2458
DEBUG - 2010-06-28 15:33:47 --> Config Class Initialized
DEBUG - 2010-06-28 15:33:47 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:33:48 --> URI Class Initialized
DEBUG - 2010-06-28 15:33:48 --> Router Class Initialized
DEBUG - 2010-06-28 15:33:48 --> Output Class Initialized
DEBUG - 2010-06-28 15:33:48 --> Input Class Initialized
DEBUG - 2010-06-28 15:33:48 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:33:48 --> Language Class Initialized
DEBUG - 2010-06-28 15:33:48 --> Loader Class Initialized
DEBUG - 2010-06-28 15:33:48 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:33:48 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:33:49 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:33:49 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:33:49 --> Controller Class Initialized
DEBUG - 2010-06-28 15:33:49 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:33:49 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:33:49 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 15:33:49 --> Session Class Initialized
DEBUG - 2010-06-28 15:33:49 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:33:49 --> Session routines successfully run
DEBUG - 2010-06-28 15:33:50 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:33:50 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:33:51 --> Final output sent to browser
DEBUG - 2010-06-28 15:33:51 --> Total execution time: 3.2326
DEBUG - 2010-06-28 15:34:00 --> Config Class Initialized
DEBUG - 2010-06-28 15:34:01 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:34:01 --> URI Class Initialized
DEBUG - 2010-06-28 15:34:01 --> Router Class Initialized
DEBUG - 2010-06-28 15:34:01 --> Output Class Initialized
DEBUG - 2010-06-28 15:34:01 --> Input Class Initialized
DEBUG - 2010-06-28 15:34:01 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:34:01 --> Language Class Initialized
DEBUG - 2010-06-28 15:34:01 --> Loader Class Initialized
DEBUG - 2010-06-28 15:34:01 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:34:02 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:34:02 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:34:02 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:34:02 --> Controller Class Initialized
DEBUG - 2010-06-28 15:34:02 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:34:02 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:34:02 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 15:34:02 --> Session Class Initialized
DEBUG - 2010-06-28 15:34:03 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:34:03 --> Session routines successfully run
DEBUG - 2010-06-28 15:34:03 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:34:04 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:34:04 --> Final output sent to browser
DEBUG - 2010-06-28 15:34:04 --> Total execution time: 3.2341
DEBUG - 2010-06-28 15:36:18 --> Config Class Initialized
DEBUG - 2010-06-28 15:36:19 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:36:19 --> URI Class Initialized
DEBUG - 2010-06-28 15:36:19 --> Router Class Initialized
DEBUG - 2010-06-28 15:36:19 --> Output Class Initialized
DEBUG - 2010-06-28 15:36:19 --> Input Class Initialized
DEBUG - 2010-06-28 15:36:19 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:36:19 --> Language Class Initialized
DEBUG - 2010-06-28 15:36:20 --> Loader Class Initialized
DEBUG - 2010-06-28 15:36:20 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:36:20 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:36:20 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:36:20 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:36:20 --> Controller Class Initialized
DEBUG - 2010-06-28 15:36:20 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:36:20 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:36:20 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 15:36:21 --> Session Class Initialized
DEBUG - 2010-06-28 15:36:21 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:36:21 --> Session routines successfully run
DEBUG - 2010-06-28 15:36:21 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:36:22 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:36:22 --> Final output sent to browser
DEBUG - 2010-06-28 15:36:22 --> Total execution time: 3.4095
DEBUG - 2010-06-28 15:36:43 --> Config Class Initialized
DEBUG - 2010-06-28 15:36:43 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:36:43 --> URI Class Initialized
DEBUG - 2010-06-28 15:36:43 --> Router Class Initialized
DEBUG - 2010-06-28 15:36:43 --> Output Class Initialized
DEBUG - 2010-06-28 15:36:43 --> Input Class Initialized
DEBUG - 2010-06-28 15:36:43 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:36:44 --> Language Class Initialized
DEBUG - 2010-06-28 15:36:44 --> Loader Class Initialized
DEBUG - 2010-06-28 15:36:44 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:36:44 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:36:44 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:36:44 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:36:44 --> Controller Class Initialized
DEBUG - 2010-06-28 15:36:44 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:36:44 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:36:45 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 15:36:45 --> Session Class Initialized
DEBUG - 2010-06-28 15:36:45 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:36:45 --> Session routines successfully run
DEBUG - 2010-06-28 15:36:45 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:36:46 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:36:46 --> Final output sent to browser
DEBUG - 2010-06-28 15:36:46 --> Total execution time: 3.2451
DEBUG - 2010-06-28 15:37:28 --> Config Class Initialized
DEBUG - 2010-06-28 15:37:28 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:37:28 --> URI Class Initialized
DEBUG - 2010-06-28 15:37:28 --> Router Class Initialized
DEBUG - 2010-06-28 15:37:28 --> Output Class Initialized
DEBUG - 2010-06-28 15:37:29 --> Input Class Initialized
DEBUG - 2010-06-28 15:37:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:37:29 --> Language Class Initialized
DEBUG - 2010-06-28 15:37:29 --> Loader Class Initialized
DEBUG - 2010-06-28 15:37:29 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:37:29 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:37:29 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:37:29 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:37:29 --> Controller Class Initialized
DEBUG - 2010-06-28 15:37:30 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:37:30 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:37:30 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 15:37:30 --> Session Class Initialized
DEBUG - 2010-06-28 15:37:30 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:37:30 --> Session routines successfully run
DEBUG - 2010-06-28 15:37:31 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:37:31 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:37:31 --> Final output sent to browser
DEBUG - 2010-06-28 15:37:31 --> Total execution time: 3.1789
DEBUG - 2010-06-28 15:39:31 --> Config Class Initialized
DEBUG - 2010-06-28 15:39:31 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:39:31 --> URI Class Initialized
DEBUG - 2010-06-28 15:39:32 --> Router Class Initialized
DEBUG - 2010-06-28 15:39:32 --> Output Class Initialized
DEBUG - 2010-06-28 15:39:32 --> Input Class Initialized
DEBUG - 2010-06-28 15:39:32 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:39:32 --> Language Class Initialized
DEBUG - 2010-06-28 15:39:32 --> Loader Class Initialized
DEBUG - 2010-06-28 15:39:32 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:39:32 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:39:33 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:39:33 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:39:33 --> Controller Class Initialized
DEBUG - 2010-06-28 15:39:33 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:39:33 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:39:33 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 15:39:33 --> Session Class Initialized
DEBUG - 2010-06-28 15:39:33 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:39:33 --> Session routines successfully run
DEBUG - 2010-06-28 15:39:34 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:39:34 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:39:34 --> Final output sent to browser
DEBUG - 2010-06-28 15:39:35 --> Total execution time: 3.2559
DEBUG - 2010-06-28 15:40:08 --> Config Class Initialized
DEBUG - 2010-06-28 15:40:08 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:40:08 --> URI Class Initialized
DEBUG - 2010-06-28 15:40:08 --> Router Class Initialized
DEBUG - 2010-06-28 15:40:08 --> Output Class Initialized
DEBUG - 2010-06-28 15:40:08 --> Input Class Initialized
DEBUG - 2010-06-28 15:40:08 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:40:08 --> Language Class Initialized
DEBUG - 2010-06-28 15:40:09 --> Loader Class Initialized
DEBUG - 2010-06-28 15:40:09 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:40:09 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:40:09 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:40:09 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:40:09 --> Controller Class Initialized
DEBUG - 2010-06-28 15:40:09 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:40:09 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:40:09 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 15:40:10 --> Session Class Initialized
DEBUG - 2010-06-28 15:40:10 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:40:10 --> Session routines successfully run
DEBUG - 2010-06-28 15:40:10 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:40:11 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:40:11 --> Final output sent to browser
DEBUG - 2010-06-28 15:40:11 --> Total execution time: 3.3107
DEBUG - 2010-06-28 15:40:55 --> Config Class Initialized
DEBUG - 2010-06-28 15:40:55 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:40:55 --> URI Class Initialized
DEBUG - 2010-06-28 15:40:56 --> Router Class Initialized
DEBUG - 2010-06-28 15:40:56 --> Output Class Initialized
DEBUG - 2010-06-28 15:40:56 --> Input Class Initialized
DEBUG - 2010-06-28 15:40:56 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:40:56 --> Language Class Initialized
DEBUG - 2010-06-28 15:40:56 --> Loader Class Initialized
DEBUG - 2010-06-28 15:40:56 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:40:56 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:40:56 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:40:57 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:40:57 --> Controller Class Initialized
DEBUG - 2010-06-28 15:40:57 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:40:57 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:40:57 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 15:40:57 --> Session Class Initialized
DEBUG - 2010-06-28 15:40:57 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:40:57 --> Session routines successfully run
DEBUG - 2010-06-28 15:40:58 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:40:58 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:40:58 --> Final output sent to browser
DEBUG - 2010-06-28 15:40:59 --> Total execution time: 3.2561
DEBUG - 2010-06-28 15:41:48 --> Config Class Initialized
DEBUG - 2010-06-28 15:41:48 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:41:48 --> URI Class Initialized
DEBUG - 2010-06-28 15:41:48 --> Router Class Initialized
DEBUG - 2010-06-28 15:41:48 --> Output Class Initialized
DEBUG - 2010-06-28 15:41:49 --> Input Class Initialized
DEBUG - 2010-06-28 15:41:49 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:41:49 --> Language Class Initialized
DEBUG - 2010-06-28 15:41:49 --> Loader Class Initialized
DEBUG - 2010-06-28 15:41:49 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:41:49 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:41:49 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:41:49 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:41:50 --> Controller Class Initialized
DEBUG - 2010-06-28 15:41:50 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:41:50 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:41:50 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 15:41:50 --> Session Class Initialized
DEBUG - 2010-06-28 15:41:50 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:41:50 --> Session routines successfully run
DEBUG - 2010-06-28 15:41:51 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:41:51 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:41:51 --> Final output sent to browser
DEBUG - 2010-06-28 15:41:51 --> Total execution time: 3.2509
DEBUG - 2010-06-28 15:42:37 --> Config Class Initialized
DEBUG - 2010-06-28 15:42:37 --> Hooks Class Initialized
DEBUG - 2010-06-28 15:42:37 --> URI Class Initialized
DEBUG - 2010-06-28 15:42:38 --> Router Class Initialized
DEBUG - 2010-06-28 15:42:38 --> Output Class Initialized
DEBUG - 2010-06-28 15:42:38 --> Input Class Initialized
DEBUG - 2010-06-28 15:42:38 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 15:42:38 --> Language Class Initialized
DEBUG - 2010-06-28 15:42:38 --> Loader Class Initialized
DEBUG - 2010-06-28 15:42:38 --> Helper loaded: context_helper
DEBUG - 2010-06-28 15:42:38 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 15:42:38 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 15:42:39 --> Database Driver Class Initialized
DEBUG - 2010-06-28 15:42:39 --> Controller Class Initialized
DEBUG - 2010-06-28 15:42:39 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 15:42:39 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 15:42:39 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 15:42:39 --> Session Class Initialized
DEBUG - 2010-06-28 15:42:39 --> Helper loaded: string_helper
DEBUG - 2010-06-28 15:42:39 --> Session routines successfully run
DEBUG - 2010-06-28 15:42:40 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 15:42:40 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 15:42:41 --> Final output sent to browser
DEBUG - 2010-06-28 15:42:41 --> Total execution time: 3.3519
DEBUG - 2010-06-28 16:33:03 --> Config Class Initialized
DEBUG - 2010-06-28 16:33:03 --> Hooks Class Initialized
DEBUG - 2010-06-28 16:33:03 --> URI Class Initialized
DEBUG - 2010-06-28 16:33:03 --> Router Class Initialized
DEBUG - 2010-06-28 16:33:03 --> Output Class Initialized
DEBUG - 2010-06-28 16:33:03 --> Input Class Initialized
DEBUG - 2010-06-28 16:33:03 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 16:33:03 --> Language Class Initialized
DEBUG - 2010-06-28 16:33:04 --> Loader Class Initialized
DEBUG - 2010-06-28 16:33:04 --> Helper loaded: context_helper
ERROR - 2010-06-28 16:33:04 --> Unable to load the requested class: kalsobject
DEBUG - 2010-06-28 16:33:28 --> Config Class Initialized
DEBUG - 2010-06-28 16:33:28 --> Hooks Class Initialized
DEBUG - 2010-06-28 16:33:28 --> URI Class Initialized
DEBUG - 2010-06-28 16:33:28 --> Router Class Initialized
DEBUG - 2010-06-28 16:33:28 --> Output Class Initialized
DEBUG - 2010-06-28 16:33:28 --> Input Class Initialized
DEBUG - 2010-06-28 16:33:28 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 16:33:29 --> Language Class Initialized
DEBUG - 2010-06-28 16:33:29 --> Loader Class Initialized
DEBUG - 2010-06-28 16:33:29 --> Helper loaded: context_helper
DEBUG - 2010-06-28 16:33:29 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 16:33:29 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 16:33:29 --> Database Driver Class Initialized
DEBUG - 2010-06-28 16:33:29 --> Controller Class Initialized
DEBUG - 2010-06-28 16:33:29 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 16:33:30 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 16:33:30 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 16:33:48 --> Config Class Initialized
DEBUG - 2010-06-28 16:33:48 --> Hooks Class Initialized
DEBUG - 2010-06-28 16:33:48 --> URI Class Initialized
DEBUG - 2010-06-28 16:33:49 --> Router Class Initialized
DEBUG - 2010-06-28 16:33:49 --> Output Class Initialized
DEBUG - 2010-06-28 16:33:49 --> Input Class Initialized
DEBUG - 2010-06-28 16:33:49 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 16:33:49 --> Language Class Initialized
DEBUG - 2010-06-28 16:33:49 --> Loader Class Initialized
DEBUG - 2010-06-28 16:33:49 --> Helper loaded: context_helper
DEBUG - 2010-06-28 16:33:49 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 16:33:49 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 16:33:50 --> Database Driver Class Initialized
DEBUG - 2010-06-28 16:33:50 --> Controller Class Initialized
DEBUG - 2010-06-28 16:33:50 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 16:33:50 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 16:33:50 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 16:33:50 --> Session Class Initialized
DEBUG - 2010-06-28 16:33:50 --> Helper loaded: string_helper
DEBUG - 2010-06-28 16:33:50 --> Session routines successfully run
DEBUG - 2010-06-28 16:34:33 --> Config Class Initialized
DEBUG - 2010-06-28 16:34:33 --> Hooks Class Initialized
DEBUG - 2010-06-28 16:34:33 --> URI Class Initialized
DEBUG - 2010-06-28 16:34:33 --> Router Class Initialized
DEBUG - 2010-06-28 16:34:34 --> Output Class Initialized
DEBUG - 2010-06-28 16:34:34 --> Input Class Initialized
DEBUG - 2010-06-28 16:34:34 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 16:34:34 --> Language Class Initialized
DEBUG - 2010-06-28 16:34:34 --> Loader Class Initialized
DEBUG - 2010-06-28 16:34:34 --> Helper loaded: context_helper
DEBUG - 2010-06-28 16:34:34 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 16:34:34 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 16:34:34 --> Database Driver Class Initialized
DEBUG - 2010-06-28 16:34:35 --> Controller Class Initialized
DEBUG - 2010-06-28 16:34:35 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 16:34:35 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 16:34:35 --> Helper loaded: cookie_helper
DEBUG - 2010-06-28 16:34:35 --> Session Class Initialized
DEBUG - 2010-06-28 16:34:35 --> Helper loaded: string_helper
DEBUG - 2010-06-28 16:34:35 --> Session routines successfully run
DEBUG - 2010-06-28 16:34:36 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-28 16:34:36 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-28 16:34:36 --> Final output sent to browser
DEBUG - 2010-06-28 16:34:36 --> Total execution time: 3.2818
DEBUG - 2010-06-28 16:38:28 --> Config Class Initialized
DEBUG - 2010-06-28 16:38:28 --> Hooks Class Initialized
DEBUG - 2010-06-28 16:38:28 --> URI Class Initialized
DEBUG - 2010-06-28 16:38:28 --> Router Class Initialized
DEBUG - 2010-06-28 16:38:28 --> Output Class Initialized
DEBUG - 2010-06-28 16:38:29 --> Input Class Initialized
DEBUG - 2010-06-28 16:38:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 16:38:29 --> Language Class Initialized
DEBUG - 2010-06-28 16:38:29 --> Loader Class Initialized
DEBUG - 2010-06-28 16:38:29 --> Helper loaded: context_helper
DEBUG - 2010-06-28 16:38:29 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 16:38:29 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 16:38:29 --> Database Driver Class Initialized
DEBUG - 2010-06-28 16:38:30 --> Controller Class Initialized
DEBUG - 2010-06-28 16:38:30 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 16:38:30 --> Helper loaded: unit_test_helper
ERROR - 2010-06-28 16:38:30 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Webpage.php 28
DEBUG - 2010-06-28 16:39:20 --> Config Class Initialized
DEBUG - 2010-06-28 16:39:20 --> Hooks Class Initialized
DEBUG - 2010-06-28 16:39:20 --> URI Class Initialized
DEBUG - 2010-06-28 16:39:21 --> Router Class Initialized
DEBUG - 2010-06-28 16:39:21 --> Output Class Initialized
DEBUG - 2010-06-28 16:39:21 --> Input Class Initialized
DEBUG - 2010-06-28 16:39:21 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-28 16:39:21 --> Language Class Initialized
DEBUG - 2010-06-28 16:39:21 --> Loader Class Initialized
DEBUG - 2010-06-28 16:39:21 --> Helper loaded: context_helper
DEBUG - 2010-06-28 16:39:21 --> Helper loaded: kals_helper
DEBUG - 2010-06-28 16:39:22 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-28 16:39:22 --> Database Driver Class Initialized
DEBUG - 2010-06-28 16:39:22 --> Controller Class Initialized
DEBUG - 2010-06-28 16:39:22 --> Unit Testing Class Initialized
DEBUG - 2010-06-28 16:39:22 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-28 16:39:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-28 16:39:26 --> Language file loaded: language/zh_tw/unit_test_lang.php
