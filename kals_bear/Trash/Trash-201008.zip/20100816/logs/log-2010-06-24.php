<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2010-06-24 04:22:30 --> Config Class Initialized
DEBUG - 2010-06-24 04:22:30 --> Hooks Class Initialized
DEBUG - 2010-06-24 04:22:30 --> URI Class Initialized
DEBUG - 2010-06-24 04:22:30 --> Router Class Initialized
DEBUG - 2010-06-24 04:22:30 --> Output Class Initialized
DEBUG - 2010-06-24 04:22:30 --> Input Class Initialized
DEBUG - 2010-06-24 04:22:30 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 04:22:30 --> Language Class Initialized
DEBUG - 2010-06-24 04:22:30 --> Loader Class Initialized
DEBUG - 2010-06-24 04:22:30 --> Helper loaded: object_helper
DEBUG - 2010-06-24 04:22:30 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 04:22:30 --> Helper loaded: context_helper
DEBUG - 2010-06-24 04:22:30 --> Session Class Initialized
DEBUG - 2010-06-24 04:22:31 --> Helper loaded: string_helper
DEBUG - 2010-06-24 04:22:31 --> A session cookie was not found.
DEBUG - 2010-06-24 04:22:31 --> Session routines successfully run
DEBUG - 2010-06-24 04:22:31 --> Helper loaded: context_helper
DEBUG - 2010-06-24 04:22:31 --> Controller Class Initialized
DEBUG - 2010-06-24 04:22:31 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 04:22:31 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 04:22:31 --> Database Driver Class Initialized
DEBUG - 2010-06-24 04:22:31 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 04:22:31 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 04:22:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:22:31 --> User class already loaded. Second attempt ignored.
ERROR - 2010-06-24 04:22:31 --> Severity: Notice  --> Undefined property: User::$load D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 208
ERROR - 2010-06-24 04:22:31 --> Severity: Notice  --> Undefined property: User::$load D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 208
ERROR - 2010-06-24 04:22:31 --> Severity: Notice  --> Undefined property: User::$load D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 208
ERROR - 2010-06-24 04:22:31 --> Severity: Notice  --> Undefined property: User::$load D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 208
DEBUG - 2010-06-24 04:22:31 --> User Agent Class Initialized
DEBUG - 2010-06-24 04:22:31 --> Config file loaded: config/config.php
ERROR - 2010-06-24 04:22:31 --> Severity: Notice  --> Undefined property: User::$load D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 208
ERROR - 2010-06-24 04:22:31 --> Severity: Notice  --> Undefined property: User::$load D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 208
DEBUG - 2010-06-24 04:22:31 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 04:22:31 --> Config file loaded: config/kals.php
ERROR - 2010-06-24 04:22:31 --> Severity: Notice  --> Undefined property: User::$load D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 208
ERROR - 2010-06-24 04:22:31 --> Severity: Notice  --> Undefined property: User::$load D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 208
ERROR - 2010-06-24 04:22:31 --> Severity: Notice  --> Undefined property: User::$load D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 208
ERROR - 2010-06-24 04:22:31 --> Severity: Notice  --> Undefined property: User::$load D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 208
DEBUG - 2010-06-24 04:22:31 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2010-06-24 04:22:31 --> Severity: Notice  --> Undefined property: User::$load D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 208
ERROR - 2010-06-24 04:22:31 --> Severity: Notice  --> Undefined property: User::$load D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 208
ERROR - 2010-06-24 04:22:31 --> Severity: Notice  --> Undefined property: User::$load D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 208
INFO  - 2010-06-24 04:22:31 --> User update: (58) pudding : 
DEBUG - 2010-06-24 04:22:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:22:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:22:31 --> User class already loaded. Second attempt ignored.
ERROR - 2010-06-24 04:22:31 --> Severity: Notice  --> Undefined property: User::$load D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 208
DEBUG - 2010-06-24 04:22:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:22:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:22:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:22:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:22:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:22:31 --> Helper loaded: email_helper
ERROR - 2010-06-24 04:22:31 --> Severity: Notice  --> Undefined property: User::$load D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 208
ERROR - 2010-06-24 04:22:31 --> Severity: Notice  --> Undefined property: User::$load D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 208
ERROR - 2010-06-24 04:22:31 --> Severity: Notice  --> Undefined property: User::$load D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 208
ERROR - 2010-06-24 04:22:31 --> Severity: Notice  --> Undefined property: User::$load D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 208
ERROR - 2010-06-24 04:22:31 --> Severity: Notice  --> Undefined property: User::$load D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 208
DEBUG - 2010-06-24 04:22:31 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2010-06-24 04:22:31 --> Severity: Notice  --> Undefined property: User::$load D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 208
ERROR - 2010-06-24 04:22:31 --> Severity: Notice  --> Undefined property: User::$load D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 208
ERROR - 2010-06-24 04:22:31 --> Severity: Notice  --> Undefined property: User::$load D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 208
DEBUG - 2010-06-24 04:22:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:22:31 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-24 04:22:31 --> Severity: Notice  --> Undefined property: User::$load D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 208
DEBUG - 2010-06-24 04:22:31 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-24 04:22:31 --> Final output sent to browser
DEBUG - 2010-06-24 04:22:31 --> Total execution time: 0.6387
DEBUG - 2010-06-24 04:22:59 --> Config Class Initialized
DEBUG - 2010-06-24 04:22:59 --> Hooks Class Initialized
DEBUG - 2010-06-24 04:22:59 --> URI Class Initialized
DEBUG - 2010-06-24 04:22:59 --> Router Class Initialized
DEBUG - 2010-06-24 04:22:59 --> Output Class Initialized
DEBUG - 2010-06-24 04:22:59 --> Input Class Initialized
DEBUG - 2010-06-24 04:22:59 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 04:22:59 --> Language Class Initialized
DEBUG - 2010-06-24 04:22:59 --> Loader Class Initialized
DEBUG - 2010-06-24 04:22:59 --> Helper loaded: object_helper
DEBUG - 2010-06-24 04:22:59 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 04:22:59 --> Helper loaded: context_helper
DEBUG - 2010-06-24 04:22:59 --> Session Class Initialized
DEBUG - 2010-06-24 04:22:59 --> Helper loaded: string_helper
DEBUG - 2010-06-24 04:22:59 --> Session routines successfully run
DEBUG - 2010-06-24 04:22:59 --> Helper loaded: context_helper
DEBUG - 2010-06-24 04:22:59 --> Controller Class Initialized
DEBUG - 2010-06-24 04:22:59 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 04:22:59 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 04:22:59 --> Database Driver Class Initialized
DEBUG - 2010-06-24 04:22:59 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 04:22:59 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 04:22:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:22:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:22:59 --> User Agent Class Initialized
DEBUG - 2010-06-24 04:22:59 --> Config file loaded: config/config.php
DEBUG - 2010-06-24 04:22:59 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:22:59 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 04:22:59 --> Config file loaded: config/kals.php
INFO  - 2010-06-24 04:22:59 --> User update: (60) pudding : 
DEBUG - 2010-06-24 04:22:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:22:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:22:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:22:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:23:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:23:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:23:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:23:00 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:23:00 --> Helper loaded: email_helper
DEBUG - 2010-06-24 04:23:00 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:23:00 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:23:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:23:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:23:00 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-24 04:23:00 --> Final output sent to browser
DEBUG - 2010-06-24 04:23:00 --> Total execution time: 0.4606
DEBUG - 2010-06-24 04:23:07 --> Config Class Initialized
DEBUG - 2010-06-24 04:23:07 --> Hooks Class Initialized
DEBUG - 2010-06-24 04:23:07 --> URI Class Initialized
DEBUG - 2010-06-24 04:23:07 --> Router Class Initialized
DEBUG - 2010-06-24 04:23:07 --> Output Class Initialized
DEBUG - 2010-06-24 04:23:07 --> Input Class Initialized
DEBUG - 2010-06-24 04:23:07 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 04:23:07 --> Language Class Initialized
DEBUG - 2010-06-24 04:23:07 --> Loader Class Initialized
DEBUG - 2010-06-24 04:23:07 --> Helper loaded: object_helper
DEBUG - 2010-06-24 04:23:07 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 04:23:07 --> Helper loaded: context_helper
DEBUG - 2010-06-24 04:23:07 --> Session Class Initialized
DEBUG - 2010-06-24 04:23:07 --> Helper loaded: string_helper
DEBUG - 2010-06-24 04:23:07 --> Session routines successfully run
DEBUG - 2010-06-24 04:23:07 --> Helper loaded: context_helper
DEBUG - 2010-06-24 04:23:07 --> Controller Class Initialized
DEBUG - 2010-06-24 04:23:07 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 04:23:07 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 04:23:07 --> Database Driver Class Initialized
DEBUG - 2010-06-24 04:23:07 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 04:23:07 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 04:23:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:23:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:23:07 --> User Agent Class Initialized
DEBUG - 2010-06-24 04:23:07 --> Config file loaded: config/config.php
DEBUG - 2010-06-24 04:23:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:23:07 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 04:23:07 --> Config file loaded: config/kals.php
INFO  - 2010-06-24 04:23:07 --> User update: (62) pudding : 
DEBUG - 2010-06-24 04:23:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:23:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:23:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:23:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:23:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:23:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:23:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:23:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:23:07 --> Helper loaded: email_helper
DEBUG - 2010-06-24 04:23:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:23:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:23:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:23:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:23:07 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-24 04:23:07 --> Final output sent to browser
DEBUG - 2010-06-24 04:23:07 --> Total execution time: 0.3482
DEBUG - 2010-06-24 04:27:16 --> Config Class Initialized
DEBUG - 2010-06-24 04:27:16 --> Hooks Class Initialized
DEBUG - 2010-06-24 04:27:16 --> URI Class Initialized
DEBUG - 2010-06-24 04:27:16 --> Router Class Initialized
DEBUG - 2010-06-24 04:27:16 --> Output Class Initialized
DEBUG - 2010-06-24 04:27:16 --> Input Class Initialized
DEBUG - 2010-06-24 04:27:16 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 04:27:16 --> Language Class Initialized
DEBUG - 2010-06-24 04:27:16 --> Loader Class Initialized
DEBUG - 2010-06-24 04:27:16 --> Helper loaded: object_helper
DEBUG - 2010-06-24 04:27:16 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 04:27:16 --> Helper loaded: context_helper
DEBUG - 2010-06-24 04:27:16 --> Session Class Initialized
DEBUG - 2010-06-24 04:27:16 --> Helper loaded: string_helper
DEBUG - 2010-06-24 04:27:16 --> Session routines successfully run
DEBUG - 2010-06-24 04:27:16 --> Helper loaded: context_helper
DEBUG - 2010-06-24 04:27:16 --> Controller Class Initialized
DEBUG - 2010-06-24 04:27:16 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 04:27:16 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 04:27:17 --> Database Driver Class Initialized
DEBUG - 2010-06-24 04:27:17 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 04:27:17 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 04:27:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:27:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:27:17 --> User Agent Class Initialized
DEBUG - 2010-06-24 04:27:17 --> Config file loaded: config/config.php
DEBUG - 2010-06-24 04:27:17 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:27:17 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 04:27:17 --> Config file loaded: config/kals.php
INFO  - 2010-06-24 04:27:17 --> User update: (64) pudding : 
DEBUG - 2010-06-24 04:27:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:27:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:27:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:27:17 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:27:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:27:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:27:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:27:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:27:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:27:17 --> Helper loaded: email_helper
DEBUG - 2010-06-24 04:27:17 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:27:17 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:27:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:27:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:27:17 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-24 04:27:17 --> Final output sent to browser
DEBUG - 2010-06-24 04:27:17 --> Total execution time: 0.4594
DEBUG - 2010-06-24 04:29:37 --> Config Class Initialized
DEBUG - 2010-06-24 04:29:37 --> Hooks Class Initialized
DEBUG - 2010-06-24 04:29:37 --> URI Class Initialized
DEBUG - 2010-06-24 04:29:37 --> Router Class Initialized
DEBUG - 2010-06-24 04:29:37 --> Output Class Initialized
DEBUG - 2010-06-24 04:29:37 --> Input Class Initialized
DEBUG - 2010-06-24 04:29:37 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 04:29:37 --> Language Class Initialized
DEBUG - 2010-06-24 04:29:37 --> Loader Class Initialized
DEBUG - 2010-06-24 04:29:37 --> Helper loaded: object_helper
DEBUG - 2010-06-24 04:29:37 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 04:29:37 --> Helper loaded: context_helper
DEBUG - 2010-06-24 04:29:37 --> Session Class Initialized
DEBUG - 2010-06-24 04:29:37 --> Helper loaded: string_helper
DEBUG - 2010-06-24 04:29:37 --> Session routines successfully run
DEBUG - 2010-06-24 04:29:37 --> Helper loaded: context_helper
DEBUG - 2010-06-24 04:29:37 --> Controller Class Initialized
DEBUG - 2010-06-24 04:29:37 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 04:29:37 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 04:29:37 --> Database Driver Class Initialized
DEBUG - 2010-06-24 04:29:37 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 04:29:37 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 04:29:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:29:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:29:37 --> User Agent Class Initialized
DEBUG - 2010-06-24 04:29:37 --> Config file loaded: config/config.php
DEBUG - 2010-06-24 04:29:37 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:29:37 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 04:29:37 --> Config file loaded: config/kals.php
INFO  - 2010-06-24 04:29:37 --> User update: (66) pudding : 
DEBUG - 2010-06-24 04:29:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:29:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:29:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:29:37 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:29:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:29:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:29:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:29:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:29:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:29:37 --> Helper loaded: email_helper
DEBUG - 2010-06-24 04:29:37 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:29:37 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:29:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:29:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:29:37 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-24 04:29:37 --> Final output sent to browser
DEBUG - 2010-06-24 04:29:37 --> Total execution time: 0.4958
DEBUG - 2010-06-24 04:30:22 --> Config Class Initialized
DEBUG - 2010-06-24 04:30:22 --> Hooks Class Initialized
DEBUG - 2010-06-24 04:30:22 --> URI Class Initialized
DEBUG - 2010-06-24 04:30:22 --> Router Class Initialized
DEBUG - 2010-06-24 04:30:22 --> Output Class Initialized
DEBUG - 2010-06-24 04:30:22 --> Input Class Initialized
DEBUG - 2010-06-24 04:30:22 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 04:30:22 --> Language Class Initialized
DEBUG - 2010-06-24 04:30:22 --> Loader Class Initialized
DEBUG - 2010-06-24 04:30:22 --> Helper loaded: object_helper
DEBUG - 2010-06-24 04:30:22 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 04:30:22 --> Helper loaded: context_helper
DEBUG - 2010-06-24 04:30:22 --> Session Class Initialized
DEBUG - 2010-06-24 04:30:22 --> Helper loaded: string_helper
DEBUG - 2010-06-24 04:30:22 --> Session routines successfully run
DEBUG - 2010-06-24 04:30:22 --> Helper loaded: context_helper
DEBUG - 2010-06-24 04:30:22 --> Controller Class Initialized
DEBUG - 2010-06-24 04:30:22 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 04:30:22 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 04:30:22 --> Database Driver Class Initialized
DEBUG - 2010-06-24 04:30:22 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 04:30:22 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 04:30:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:30:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:30:22 --> User Agent Class Initialized
DEBUG - 2010-06-24 04:30:22 --> Config file loaded: config/config.php
DEBUG - 2010-06-24 04:30:22 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:30:22 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 04:30:22 --> Config file loaded: config/kals.php
INFO  - 2010-06-24 04:30:22 --> User update: (68) pudding : 
DEBUG - 2010-06-24 04:30:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:30:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:30:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:30:22 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:30:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:30:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:30:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:30:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:30:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:30:22 --> Helper loaded: email_helper
DEBUG - 2010-06-24 04:30:22 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:30:22 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:30:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:30:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:30:22 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-24 04:30:22 --> Final output sent to browser
DEBUG - 2010-06-24 04:30:22 --> Total execution time: 0.5171
DEBUG - 2010-06-24 04:37:46 --> Config Class Initialized
DEBUG - 2010-06-24 04:37:47 --> Hooks Class Initialized
DEBUG - 2010-06-24 04:37:47 --> URI Class Initialized
DEBUG - 2010-06-24 04:37:47 --> Router Class Initialized
DEBUG - 2010-06-24 04:37:47 --> Output Class Initialized
DEBUG - 2010-06-24 04:37:47 --> Input Class Initialized
DEBUG - 2010-06-24 04:37:47 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 04:37:47 --> Language Class Initialized
DEBUG - 2010-06-24 04:37:47 --> Loader Class Initialized
DEBUG - 2010-06-24 04:37:47 --> Helper loaded: object_helper
DEBUG - 2010-06-24 04:37:47 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 04:37:47 --> Helper loaded: context_helper
DEBUG - 2010-06-24 04:37:47 --> Session Class Initialized
DEBUG - 2010-06-24 04:37:47 --> Helper loaded: string_helper
DEBUG - 2010-06-24 04:37:47 --> Session routines successfully run
DEBUG - 2010-06-24 04:37:47 --> Helper loaded: context_helper
DEBUG - 2010-06-24 04:37:47 --> Controller Class Initialized
DEBUG - 2010-06-24 04:37:47 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 04:37:47 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 04:37:47 --> Database Driver Class Initialized
DEBUG - 2010-06-24 04:37:47 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 04:37:47 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 04:37:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:37:47 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:37:47 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 04:37:47 --> Config file loaded: config/kals.php
INFO  - 2010-06-24 04:37:47 --> User update: (70) pudding : 
DEBUG - 2010-06-24 04:37:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:37:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:37:47 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:37:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:37:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:37:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:37:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:37:47 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:37:47 --> Helper loaded: email_helper
DEBUG - 2010-06-24 04:37:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:37:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:37:47 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-24 04:37:47 --> Final output sent to browser
DEBUG - 2010-06-24 04:37:47 --> Total execution time: 0.5144
DEBUG - 2010-06-24 04:41:11 --> Config Class Initialized
DEBUG - 2010-06-24 04:41:11 --> Hooks Class Initialized
DEBUG - 2010-06-24 04:41:11 --> URI Class Initialized
DEBUG - 2010-06-24 04:41:11 --> Router Class Initialized
DEBUG - 2010-06-24 04:41:11 --> Output Class Initialized
DEBUG - 2010-06-24 04:41:12 --> Input Class Initialized
DEBUG - 2010-06-24 04:41:12 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 04:41:12 --> Language Class Initialized
DEBUG - 2010-06-24 04:41:12 --> Loader Class Initialized
DEBUG - 2010-06-24 04:41:12 --> Helper loaded: object_helper
DEBUG - 2010-06-24 04:41:12 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 04:41:12 --> Helper loaded: context_helper
DEBUG - 2010-06-24 04:41:12 --> Session Class Initialized
DEBUG - 2010-06-24 04:41:12 --> Helper loaded: string_helper
DEBUG - 2010-06-24 04:41:12 --> Session routines successfully run
DEBUG - 2010-06-24 04:41:12 --> Helper loaded: context_helper
DEBUG - 2010-06-24 04:41:12 --> Controller Class Initialized
DEBUG - 2010-06-24 04:41:12 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 04:41:12 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 04:41:12 --> Database Driver Class Initialized
DEBUG - 2010-06-24 04:41:12 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 04:41:12 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 04:41:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:41:12 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:41:12 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 04:41:12 --> Config file loaded: config/kals.php
INFO  - 2010-06-24 04:41:12 --> User update: (72) pudding : 
DEBUG - 2010-06-24 04:41:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:41:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:41:12 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:41:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:41:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:41:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:41:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:41:12 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:41:12 --> Helper loaded: email_helper
DEBUG - 2010-06-24 04:41:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:41:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:41:12 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-24 04:41:12 --> Final output sent to browser
DEBUG - 2010-06-24 04:41:12 --> Total execution time: 0.5508
DEBUG - 2010-06-24 04:43:05 --> Config Class Initialized
DEBUG - 2010-06-24 04:43:06 --> Hooks Class Initialized
DEBUG - 2010-06-24 04:43:06 --> URI Class Initialized
DEBUG - 2010-06-24 04:43:06 --> Router Class Initialized
DEBUG - 2010-06-24 04:43:06 --> Output Class Initialized
DEBUG - 2010-06-24 04:43:06 --> Input Class Initialized
DEBUG - 2010-06-24 04:43:06 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 04:43:06 --> Language Class Initialized
DEBUG - 2010-06-24 04:43:06 --> Loader Class Initialized
DEBUG - 2010-06-24 04:43:06 --> Helper loaded: object_helper
DEBUG - 2010-06-24 04:43:06 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 04:43:06 --> Helper loaded: context_helper
DEBUG - 2010-06-24 04:43:06 --> Session Class Initialized
DEBUG - 2010-06-24 04:43:06 --> Helper loaded: string_helper
DEBUG - 2010-06-24 04:43:06 --> Session routines successfully run
DEBUG - 2010-06-24 04:43:06 --> Helper loaded: context_helper
DEBUG - 2010-06-24 04:43:06 --> Controller Class Initialized
DEBUG - 2010-06-24 04:43:06 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 04:43:06 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 04:43:06 --> Database Driver Class Initialized
DEBUG - 2010-06-24 04:43:06 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 04:43:06 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 04:43:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:43:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:43:06 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 04:43:06 --> Config file loaded: config/kals.php
INFO  - 2010-06-24 04:43:06 --> User update: (74) pudding : 
DEBUG - 2010-06-24 04:43:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:43:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:43:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:43:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:43:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:43:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:43:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:43:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:43:06 --> Helper loaded: email_helper
DEBUG - 2010-06-24 04:43:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:43:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 04:43:06 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-24 04:43:06 --> Final output sent to browser
DEBUG - 2010-06-24 04:43:06 --> Total execution time: 0.5808
DEBUG - 2010-06-24 05:01:39 --> Config Class Initialized
DEBUG - 2010-06-24 05:01:39 --> Hooks Class Initialized
DEBUG - 2010-06-24 05:01:39 --> URI Class Initialized
DEBUG - 2010-06-24 05:01:39 --> Router Class Initialized
DEBUG - 2010-06-24 05:01:39 --> Output Class Initialized
DEBUG - 2010-06-24 05:01:39 --> Input Class Initialized
DEBUG - 2010-06-24 05:01:39 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 05:01:39 --> Language Class Initialized
DEBUG - 2010-06-24 05:01:39 --> Loader Class Initialized
DEBUG - 2010-06-24 05:01:39 --> Helper loaded: object_helper
DEBUG - 2010-06-24 05:01:39 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 05:01:39 --> Helper loaded: context_helper
DEBUG - 2010-06-24 05:01:39 --> Session Class Initialized
DEBUG - 2010-06-24 05:01:39 --> Helper loaded: string_helper
DEBUG - 2010-06-24 05:01:39 --> Session routines successfully run
DEBUG - 2010-06-24 05:01:39 --> Helper loaded: context_helper
DEBUG - 2010-06-24 05:01:40 --> Controller Class Initialized
DEBUG - 2010-06-24 05:01:40 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 05:01:40 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 05:01:40 --> Database Driver Class Initialized
DEBUG - 2010-06-24 05:01:40 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 05:01:40 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 05:01:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 05:01:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 05:01:40 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 05:01:40 --> Config file loaded: config/kals.php
INFO  - 2010-06-24 05:01:40 --> User update: (76) pudding : 
DEBUG - 2010-06-24 05:01:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 05:01:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 05:01:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 05:01:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 05:01:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 05:01:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 05:01:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 05:01:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 05:01:40 --> Helper loaded: email_helper
DEBUG - 2010-06-24 05:01:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 05:01:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 05:01:40 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-24 05:01:40 --> Final output sent to browser
DEBUG - 2010-06-24 05:01:40 --> Total execution time: 0.7778
DEBUG - 2010-06-24 07:36:51 --> Config Class Initialized
DEBUG - 2010-06-24 07:36:51 --> Hooks Class Initialized
DEBUG - 2010-06-24 07:36:51 --> URI Class Initialized
DEBUG - 2010-06-24 07:36:51 --> Router Class Initialized
DEBUG - 2010-06-24 07:36:51 --> Output Class Initialized
DEBUG - 2010-06-24 07:36:51 --> Input Class Initialized
DEBUG - 2010-06-24 07:36:51 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 07:36:51 --> Language Class Initialized
DEBUG - 2010-06-24 07:36:51 --> Loader Class Initialized
DEBUG - 2010-06-24 07:36:51 --> Helper loaded: object_helper
DEBUG - 2010-06-24 07:36:51 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 07:36:51 --> Helper loaded: context_helper
DEBUG - 2010-06-24 07:36:51 --> Session Class Initialized
DEBUG - 2010-06-24 07:36:51 --> Helper loaded: string_helper
DEBUG - 2010-06-24 07:36:51 --> A session cookie was not found.
DEBUG - 2010-06-24 07:36:51 --> Session routines successfully run
DEBUG - 2010-06-24 07:36:51 --> Helper loaded: context_helper
DEBUG - 2010-06-24 07:36:51 --> Controller Class Initialized
DEBUG - 2010-06-24 07:36:51 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 07:36:51 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 07:36:51 --> Database Driver Class Initialized
DEBUG - 2010-06-24 07:36:51 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 07:36:51 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 07:36:51 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-24 07:36:51 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 75
DEBUG - 2010-06-24 07:36:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:36:51 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 07:36:51 --> Config file loaded: config/kals.php
INFO  - 2010-06-24 07:36:51 --> User update: (78) pudding : 
DEBUG - 2010-06-24 07:36:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:36:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:36:52 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:36:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:36:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:36:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:36:52 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-24 07:36:52 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 75
DEBUG - 2010-06-24 07:36:52 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:36:52 --> Helper loaded: email_helper
DEBUG - 2010-06-24 07:36:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:36:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:36:52 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-24 07:36:52 --> Final output sent to browser
DEBUG - 2010-06-24 07:36:52 --> Total execution time: 0.9367
DEBUG - 2010-06-24 07:37:59 --> Config Class Initialized
DEBUG - 2010-06-24 07:37:59 --> Hooks Class Initialized
DEBUG - 2010-06-24 07:37:59 --> URI Class Initialized
DEBUG - 2010-06-24 07:37:59 --> Router Class Initialized
DEBUG - 2010-06-24 07:37:59 --> Output Class Initialized
DEBUG - 2010-06-24 07:37:59 --> Input Class Initialized
DEBUG - 2010-06-24 07:37:59 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 07:37:59 --> Language Class Initialized
DEBUG - 2010-06-24 07:37:59 --> Loader Class Initialized
DEBUG - 2010-06-24 07:37:59 --> Helper loaded: object_helper
DEBUG - 2010-06-24 07:37:59 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 07:37:59 --> Helper loaded: context_helper
DEBUG - 2010-06-24 07:37:59 --> Session Class Initialized
DEBUG - 2010-06-24 07:37:59 --> Helper loaded: string_helper
DEBUG - 2010-06-24 07:37:59 --> Session routines successfully run
DEBUG - 2010-06-24 07:37:59 --> Helper loaded: context_helper
DEBUG - 2010-06-24 07:37:59 --> Controller Class Initialized
DEBUG - 2010-06-24 07:37:59 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 07:37:59 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 07:37:59 --> Database Driver Class Initialized
DEBUG - 2010-06-24 07:37:59 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 07:37:59 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 07:37:59 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-24 07:37:59 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 73
DEBUG - 2010-06-24 07:37:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:37:59 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 07:37:59 --> Config file loaded: config/kals.php
INFO  - 2010-06-24 07:37:59 --> User update: (80) pudding : 
DEBUG - 2010-06-24 07:37:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:37:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:37:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:37:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:37:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:37:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:37:59 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-24 07:37:59 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 73
DEBUG - 2010-06-24 07:37:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:37:59 --> Helper loaded: email_helper
DEBUG - 2010-06-24 07:37:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:37:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:37:59 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-24 07:37:59 --> Final output sent to browser
DEBUG - 2010-06-24 07:37:59 --> Total execution time: 0.7569
DEBUG - 2010-06-24 07:38:52 --> Config Class Initialized
DEBUG - 2010-06-24 07:38:52 --> Hooks Class Initialized
DEBUG - 2010-06-24 07:38:52 --> URI Class Initialized
DEBUG - 2010-06-24 07:38:52 --> Router Class Initialized
DEBUG - 2010-06-24 07:38:52 --> Output Class Initialized
DEBUG - 2010-06-24 07:38:52 --> Input Class Initialized
DEBUG - 2010-06-24 07:38:52 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 07:38:52 --> Language Class Initialized
DEBUG - 2010-06-24 07:38:52 --> Loader Class Initialized
DEBUG - 2010-06-24 07:38:52 --> Helper loaded: object_helper
DEBUG - 2010-06-24 07:38:52 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 07:38:52 --> Helper loaded: context_helper
DEBUG - 2010-06-24 07:38:52 --> Session Class Initialized
DEBUG - 2010-06-24 07:38:52 --> Helper loaded: string_helper
DEBUG - 2010-06-24 07:38:53 --> Session routines successfully run
DEBUG - 2010-06-24 07:38:53 --> Helper loaded: context_helper
DEBUG - 2010-06-24 07:38:53 --> Controller Class Initialized
DEBUG - 2010-06-24 07:38:53 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 07:38:53 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 07:38:53 --> Database Driver Class Initialized
DEBUG - 2010-06-24 07:38:53 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 07:38:53 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 07:38:53 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-24 07:38:53 --> Severity: Warning  --> Illegal offset type in isset or empty D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 74
DEBUG - 2010-06-24 07:38:53 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:38:53 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 07:38:53 --> Config file loaded: config/kals.php
INFO  - 2010-06-24 07:38:53 --> User update: (82) pudding : 
DEBUG - 2010-06-24 07:38:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:38:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:38:53 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:38:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:38:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:38:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:38:53 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-24 07:38:53 --> Severity: Warning  --> Illegal offset type in isset or empty D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 74
DEBUG - 2010-06-24 07:38:53 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:38:53 --> Helper loaded: email_helper
DEBUG - 2010-06-24 07:38:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:38:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:38:53 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-24 07:38:53 --> Final output sent to browser
DEBUG - 2010-06-24 07:38:53 --> Total execution time: 0.7529
DEBUG - 2010-06-24 07:39:40 --> Config Class Initialized
DEBUG - 2010-06-24 07:39:40 --> Hooks Class Initialized
DEBUG - 2010-06-24 07:39:40 --> URI Class Initialized
DEBUG - 2010-06-24 07:39:40 --> Router Class Initialized
DEBUG - 2010-06-24 07:39:40 --> Output Class Initialized
DEBUG - 2010-06-24 07:39:40 --> Input Class Initialized
DEBUG - 2010-06-24 07:39:40 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 07:39:40 --> Language Class Initialized
DEBUG - 2010-06-24 07:39:40 --> Loader Class Initialized
DEBUG - 2010-06-24 07:39:40 --> Helper loaded: object_helper
DEBUG - 2010-06-24 07:39:40 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 07:39:40 --> Helper loaded: context_helper
DEBUG - 2010-06-24 07:39:40 --> Session Class Initialized
DEBUG - 2010-06-24 07:39:40 --> Helper loaded: string_helper
DEBUG - 2010-06-24 07:39:40 --> Session routines successfully run
DEBUG - 2010-06-24 07:39:40 --> Helper loaded: context_helper
DEBUG - 2010-06-24 07:39:40 --> Controller Class Initialized
DEBUG - 2010-06-24 07:39:40 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 07:39:40 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 07:39:40 --> Database Driver Class Initialized
DEBUG - 2010-06-24 07:39:40 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 07:39:40 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 07:39:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:39:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:39:40 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 07:39:40 --> Config file loaded: config/kals.php
INFO  - 2010-06-24 07:39:40 --> User update: (84) pudding : 
DEBUG - 2010-06-24 07:39:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:39:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:39:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:39:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:39:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:39:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:39:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:39:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:39:40 --> Helper loaded: email_helper
DEBUG - 2010-06-24 07:39:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:39:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 07:39:40 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-24 07:39:40 --> Final output sent to browser
DEBUG - 2010-06-24 07:39:40 --> Total execution time: 0.8205
DEBUG - 2010-06-24 11:40:31 --> Config Class Initialized
DEBUG - 2010-06-24 11:40:31 --> Hooks Class Initialized
DEBUG - 2010-06-24 11:40:31 --> URI Class Initialized
DEBUG - 2010-06-24 11:40:31 --> Router Class Initialized
DEBUG - 2010-06-24 11:40:31 --> Output Class Initialized
DEBUG - 2010-06-24 11:40:31 --> Input Class Initialized
DEBUG - 2010-06-24 11:40:31 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 11:40:31 --> Language Class Initialized
DEBUG - 2010-06-24 11:40:31 --> Loader Class Initialized
DEBUG - 2010-06-24 11:40:31 --> Helper loaded: object_helper
DEBUG - 2010-06-24 11:40:31 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 11:40:31 --> Helper loaded: context_helper
DEBUG - 2010-06-24 11:40:31 --> Session Class Initialized
DEBUG - 2010-06-24 11:40:31 --> Helper loaded: string_helper
DEBUG - 2010-06-24 11:40:31 --> A session cookie was not found.
DEBUG - 2010-06-24 11:40:31 --> Session routines successfully run
DEBUG - 2010-06-24 11:40:31 --> Helper loaded: context_helper
DEBUG - 2010-06-24 11:40:31 --> Controller Class Initialized
DEBUG - 2010-06-24 11:40:31 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 11:40:31 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 11:40:31 --> Database Driver Class Initialized
DEBUG - 2010-06-24 11:40:31 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 11:40:31 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 11:40:31 --> Domain class already loaded. Second attempt ignored.
INFO  - 2010-06-24 11:40:32 --> Webpage Create: (14) /p/5x1uan#response-1650638188 PHP布丁 說 [CODING D4] 目前進度5/182。希望今天能夠打起精神好好地來做！ - #5x1uan
DEBUG - 2010-06-24 11:40:32 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 11:40:32 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 11:40:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 11:40:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 11:40:32 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 11:40:32 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 11:40:32 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-24 11:40:32 --> Final output sent to browser
DEBUG - 2010-06-24 11:40:32 --> Total execution time: 1.1483
DEBUG - 2010-06-24 11:40:35 --> Config Class Initialized
DEBUG - 2010-06-24 11:40:35 --> Hooks Class Initialized
DEBUG - 2010-06-24 11:40:35 --> URI Class Initialized
DEBUG - 2010-06-24 11:40:35 --> Router Class Initialized
DEBUG - 2010-06-24 11:40:35 --> Output Class Initialized
DEBUG - 2010-06-24 11:40:35 --> Input Class Initialized
DEBUG - 2010-06-24 11:40:35 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 11:40:35 --> Language Class Initialized
DEBUG - 2010-06-24 11:40:36 --> Loader Class Initialized
DEBUG - 2010-06-24 11:40:36 --> Helper loaded: object_helper
DEBUG - 2010-06-24 11:40:36 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 11:40:36 --> Helper loaded: context_helper
DEBUG - 2010-06-24 11:40:36 --> Session Class Initialized
DEBUG - 2010-06-24 11:40:36 --> Helper loaded: string_helper
DEBUG - 2010-06-24 11:40:36 --> Session routines successfully run
DEBUG - 2010-06-24 11:40:36 --> Helper loaded: context_helper
DEBUG - 2010-06-24 11:40:36 --> Controller Class Initialized
DEBUG - 2010-06-24 11:40:36 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 11:40:36 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 11:40:36 --> Database Driver Class Initialized
DEBUG - 2010-06-24 11:40:36 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 11:40:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 11:40:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 11:40:36 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 11:40:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 11:40:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 11:40:36 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-24 11:40:36 --> Final output sent to browser
DEBUG - 2010-06-24 11:40:36 --> Total execution time: 1.1348
DEBUG - 2010-06-24 11:40:54 --> Config Class Initialized
DEBUG - 2010-06-24 11:40:54 --> Hooks Class Initialized
DEBUG - 2010-06-24 11:40:54 --> URI Class Initialized
DEBUG - 2010-06-24 11:40:54 --> Router Class Initialized
DEBUG - 2010-06-24 11:40:54 --> Output Class Initialized
DEBUG - 2010-06-24 11:40:54 --> Input Class Initialized
DEBUG - 2010-06-24 11:40:54 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 11:40:54 --> Language Class Initialized
DEBUG - 2010-06-24 11:40:55 --> Loader Class Initialized
DEBUG - 2010-06-24 11:40:55 --> Helper loaded: object_helper
DEBUG - 2010-06-24 11:40:55 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 11:40:55 --> Helper loaded: context_helper
DEBUG - 2010-06-24 11:40:55 --> Session Class Initialized
DEBUG - 2010-06-24 11:40:55 --> Helper loaded: string_helper
DEBUG - 2010-06-24 11:40:55 --> Session routines successfully run
DEBUG - 2010-06-24 11:40:55 --> Helper loaded: context_helper
DEBUG - 2010-06-24 11:40:55 --> Controller Class Initialized
DEBUG - 2010-06-24 11:40:55 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 11:40:55 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 11:40:55 --> Database Driver Class Initialized
DEBUG - 2010-06-24 11:40:55 --> Language file loaded: language/zh_tw/kals_actor_lang.php
ERROR - 2010-06-24 11:40:55 --> Severity: Warning  --> include_once(KALSActor) [<a href='function.include-once'>function.include-once</a>]: failed to open stream: No such file or directory D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\Group.php 2
ERROR - 2010-06-24 11:40:55 --> Severity: Warning  --> include_once() [<a href='function.include'>function.include</a>]: Failed opening 'KALSActor' for inclusion (include_path='.;D:\xampp\php\pear\') D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\Group.php 2
DEBUG - 2010-06-24 11:40:55 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 11:40:55 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 11:40:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 11:40:55 --> User class already loaded. Second attempt ignored.
ERROR - 2010-06-24 11:40:55 --> Severity: Notice  --> Use of undefined constant FASLE - assumed 'FASLE' D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\Group.php 230
DEBUG - 2010-06-24 11:40:55 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 11:40:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 11:40:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 11:42:17 --> Config Class Initialized
DEBUG - 2010-06-24 11:42:17 --> Hooks Class Initialized
DEBUG - 2010-06-24 11:42:17 --> URI Class Initialized
DEBUG - 2010-06-24 11:42:17 --> Router Class Initialized
DEBUG - 2010-06-24 11:42:17 --> Output Class Initialized
DEBUG - 2010-06-24 11:42:17 --> Input Class Initialized
DEBUG - 2010-06-24 11:42:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 11:42:17 --> Language Class Initialized
DEBUG - 2010-06-24 11:42:17 --> Loader Class Initialized
DEBUG - 2010-06-24 11:42:17 --> Helper loaded: object_helper
DEBUG - 2010-06-24 11:42:17 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 11:42:17 --> Helper loaded: context_helper
DEBUG - 2010-06-24 11:42:17 --> Session Class Initialized
DEBUG - 2010-06-24 11:42:17 --> Helper loaded: string_helper
DEBUG - 2010-06-24 11:42:17 --> Session routines successfully run
DEBUG - 2010-06-24 11:42:17 --> Helper loaded: context_helper
DEBUG - 2010-06-24 11:42:17 --> Controller Class Initialized
DEBUG - 2010-06-24 11:42:18 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 11:42:18 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 11:42:18 --> Database Driver Class Initialized
DEBUG - 2010-06-24 11:42:18 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 11:42:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 11:42:18 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 11:42:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 11:42:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 11:42:18 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 11:42:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 11:42:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 11:45:07 --> Config Class Initialized
DEBUG - 2010-06-24 11:45:07 --> Hooks Class Initialized
DEBUG - 2010-06-24 11:45:07 --> URI Class Initialized
DEBUG - 2010-06-24 11:45:07 --> Router Class Initialized
DEBUG - 2010-06-24 11:45:07 --> Output Class Initialized
DEBUG - 2010-06-24 11:45:08 --> Input Class Initialized
DEBUG - 2010-06-24 11:45:08 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 11:45:08 --> Language Class Initialized
DEBUG - 2010-06-24 11:45:08 --> Loader Class Initialized
DEBUG - 2010-06-24 11:45:08 --> Helper loaded: object_helper
DEBUG - 2010-06-24 11:45:08 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 11:45:08 --> Helper loaded: context_helper
DEBUG - 2010-06-24 11:45:08 --> Session Class Initialized
DEBUG - 2010-06-24 11:45:08 --> Helper loaded: string_helper
DEBUG - 2010-06-24 11:45:08 --> Session routines successfully run
DEBUG - 2010-06-24 11:45:08 --> Helper loaded: context_helper
DEBUG - 2010-06-24 11:45:08 --> Controller Class Initialized
DEBUG - 2010-06-24 11:45:08 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 11:45:08 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 11:45:08 --> Database Driver Class Initialized
DEBUG - 2010-06-24 11:45:08 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 11:45:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 11:45:08 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 11:45:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 11:45:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 11:45:27 --> Config Class Initialized
DEBUG - 2010-06-24 11:45:27 --> Hooks Class Initialized
DEBUG - 2010-06-24 11:45:27 --> URI Class Initialized
DEBUG - 2010-06-24 11:45:27 --> Router Class Initialized
DEBUG - 2010-06-24 11:45:27 --> Output Class Initialized
DEBUG - 2010-06-24 11:45:27 --> Input Class Initialized
DEBUG - 2010-06-24 11:45:27 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 11:45:27 --> Language Class Initialized
DEBUG - 2010-06-24 11:45:27 --> Loader Class Initialized
DEBUG - 2010-06-24 11:45:28 --> Helper loaded: object_helper
DEBUG - 2010-06-24 11:45:28 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 11:45:28 --> Helper loaded: context_helper
DEBUG - 2010-06-24 11:45:28 --> Session Class Initialized
DEBUG - 2010-06-24 11:45:28 --> Helper loaded: string_helper
DEBUG - 2010-06-24 11:45:28 --> Session routines successfully run
DEBUG - 2010-06-24 11:45:28 --> Helper loaded: context_helper
DEBUG - 2010-06-24 11:45:28 --> Controller Class Initialized
DEBUG - 2010-06-24 11:45:28 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 11:45:28 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 11:45:28 --> Database Driver Class Initialized
DEBUG - 2010-06-24 11:45:28 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 11:45:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 11:45:28 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 11:45:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 11:45:28 --> User class already loaded. Second attempt ignored.
ERROR - 2010-06-24 11:45:28 --> Severity: Notice  --> Undefined index:  group_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\Group.php 204
ERROR - 2010-06-24 11:45:28 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  null value in column &quot;group_id&quot; violates not-null constraint D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-24 11:45:28 --> DB Transaction Failure
ERROR - 2010-06-24 11:45:28 --> Query error: ERROR:  null value in column "group_id" violates not-null constraint
DEBUG - 2010-06-24 11:45:28 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-06-24 11:45:28 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-24 11:47:21 --> Config Class Initialized
DEBUG - 2010-06-24 11:47:21 --> Hooks Class Initialized
DEBUG - 2010-06-24 11:47:21 --> URI Class Initialized
DEBUG - 2010-06-24 11:47:21 --> Router Class Initialized
DEBUG - 2010-06-24 11:47:21 --> Output Class Initialized
DEBUG - 2010-06-24 11:47:21 --> Input Class Initialized
DEBUG - 2010-06-24 11:47:21 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 11:47:21 --> Language Class Initialized
DEBUG - 2010-06-24 11:47:21 --> Loader Class Initialized
DEBUG - 2010-06-24 11:47:21 --> Helper loaded: object_helper
DEBUG - 2010-06-24 11:47:21 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 11:47:21 --> Helper loaded: context_helper
DEBUG - 2010-06-24 11:47:21 --> Session Class Initialized
DEBUG - 2010-06-24 11:47:21 --> Helper loaded: string_helper
DEBUG - 2010-06-24 11:47:21 --> Session routines successfully run
DEBUG - 2010-06-24 11:47:21 --> Helper loaded: context_helper
DEBUG - 2010-06-24 11:47:21 --> Controller Class Initialized
DEBUG - 2010-06-24 11:47:21 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 11:47:21 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 11:47:21 --> Database Driver Class Initialized
DEBUG - 2010-06-24 11:47:21 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 11:47:21 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 11:47:21 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 11:47:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 11:47:21 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 11:47:21 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 11:47:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 11:47:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 11:48:04 --> Config Class Initialized
DEBUG - 2010-06-24 11:48:04 --> Hooks Class Initialized
DEBUG - 2010-06-24 11:48:04 --> URI Class Initialized
DEBUG - 2010-06-24 11:48:04 --> Router Class Initialized
DEBUG - 2010-06-24 11:48:04 --> Output Class Initialized
DEBUG - 2010-06-24 11:48:04 --> Input Class Initialized
DEBUG - 2010-06-24 11:48:04 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 11:48:04 --> Language Class Initialized
DEBUG - 2010-06-24 11:48:04 --> Loader Class Initialized
DEBUG - 2010-06-24 11:48:04 --> Helper loaded: object_helper
DEBUG - 2010-06-24 11:48:04 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 11:48:04 --> Helper loaded: context_helper
DEBUG - 2010-06-24 11:48:04 --> Session Class Initialized
DEBUG - 2010-06-24 11:48:04 --> Helper loaded: string_helper
DEBUG - 2010-06-24 11:48:04 --> Session routines successfully run
DEBUG - 2010-06-24 11:48:04 --> Helper loaded: context_helper
DEBUG - 2010-06-24 11:48:04 --> Controller Class Initialized
DEBUG - 2010-06-24 11:48:05 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 11:48:05 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 11:48:05 --> Database Driver Class Initialized
DEBUG - 2010-06-24 11:48:05 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 11:48:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 11:48:05 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 11:48:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 11:48:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 11:48:05 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 11:48:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 11:48:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:00:43 --> Config Class Initialized
DEBUG - 2010-06-24 12:00:43 --> Hooks Class Initialized
DEBUG - 2010-06-24 12:00:43 --> URI Class Initialized
DEBUG - 2010-06-24 12:00:43 --> Router Class Initialized
DEBUG - 2010-06-24 12:00:43 --> Output Class Initialized
DEBUG - 2010-06-24 12:00:43 --> Input Class Initialized
DEBUG - 2010-06-24 12:00:43 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 12:00:43 --> Language Class Initialized
DEBUG - 2010-06-24 12:00:43 --> Loader Class Initialized
DEBUG - 2010-06-24 12:00:43 --> Helper loaded: object_helper
DEBUG - 2010-06-24 12:00:43 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 12:00:43 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:00:43 --> Session Class Initialized
DEBUG - 2010-06-24 12:00:43 --> Helper loaded: string_helper
DEBUG - 2010-06-24 12:00:43 --> Session routines successfully run
DEBUG - 2010-06-24 12:00:43 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:00:43 --> Controller Class Initialized
DEBUG - 2010-06-24 12:00:43 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 12:00:43 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 12:00:43 --> Database Driver Class Initialized
DEBUG - 2010-06-24 12:00:43 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 12:00:43 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:00:43 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 12:00:43 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:00:43 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:00:43 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 12:00:43 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:00:43 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:00:53 --> Config Class Initialized
DEBUG - 2010-06-24 12:00:53 --> Hooks Class Initialized
DEBUG - 2010-06-24 12:00:53 --> URI Class Initialized
DEBUG - 2010-06-24 12:00:53 --> Router Class Initialized
DEBUG - 2010-06-24 12:00:53 --> Output Class Initialized
DEBUG - 2010-06-24 12:00:53 --> Input Class Initialized
DEBUG - 2010-06-24 12:00:53 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 12:00:53 --> Language Class Initialized
DEBUG - 2010-06-24 12:00:53 --> Loader Class Initialized
DEBUG - 2010-06-24 12:00:53 --> Helper loaded: object_helper
DEBUG - 2010-06-24 12:00:53 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 12:00:53 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:00:53 --> Session Class Initialized
DEBUG - 2010-06-24 12:00:53 --> Helper loaded: string_helper
DEBUG - 2010-06-24 12:00:53 --> Session routines successfully run
DEBUG - 2010-06-24 12:00:53 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:00:53 --> Controller Class Initialized
DEBUG - 2010-06-24 12:00:53 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 12:00:53 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 12:00:53 --> Database Driver Class Initialized
DEBUG - 2010-06-24 12:00:53 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 12:00:53 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:00:53 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 12:00:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:00:53 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:00:53 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 12:00:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:00:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:01:31 --> Config Class Initialized
DEBUG - 2010-06-24 12:01:31 --> Hooks Class Initialized
DEBUG - 2010-06-24 12:01:31 --> URI Class Initialized
DEBUG - 2010-06-24 12:01:31 --> Router Class Initialized
DEBUG - 2010-06-24 12:01:31 --> Output Class Initialized
DEBUG - 2010-06-24 12:01:31 --> Input Class Initialized
DEBUG - 2010-06-24 12:01:31 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 12:01:31 --> Language Class Initialized
DEBUG - 2010-06-24 12:01:31 --> Loader Class Initialized
DEBUG - 2010-06-24 12:01:31 --> Helper loaded: object_helper
DEBUG - 2010-06-24 12:01:31 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 12:01:31 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:01:31 --> Session Class Initialized
DEBUG - 2010-06-24 12:01:31 --> Helper loaded: string_helper
DEBUG - 2010-06-24 12:01:31 --> Session routines successfully run
DEBUG - 2010-06-24 12:01:31 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:01:31 --> Controller Class Initialized
DEBUG - 2010-06-24 12:01:31 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 12:01:31 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 12:01:31 --> Database Driver Class Initialized
DEBUG - 2010-06-24 12:01:31 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 12:01:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:01:31 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 12:01:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:01:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:01:31 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 12:01:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:01:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:02:47 --> Config Class Initialized
DEBUG - 2010-06-24 12:02:47 --> Hooks Class Initialized
DEBUG - 2010-06-24 12:02:47 --> URI Class Initialized
DEBUG - 2010-06-24 12:02:47 --> Router Class Initialized
DEBUG - 2010-06-24 12:02:47 --> Output Class Initialized
DEBUG - 2010-06-24 12:02:47 --> Input Class Initialized
DEBUG - 2010-06-24 12:02:47 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 12:02:47 --> Language Class Initialized
DEBUG - 2010-06-24 12:02:47 --> Loader Class Initialized
DEBUG - 2010-06-24 12:02:47 --> Helper loaded: object_helper
DEBUG - 2010-06-24 12:02:47 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 12:02:47 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:02:47 --> Session Class Initialized
DEBUG - 2010-06-24 12:02:47 --> Helper loaded: string_helper
DEBUG - 2010-06-24 12:02:47 --> Session routines successfully run
DEBUG - 2010-06-24 12:02:47 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:02:47 --> Controller Class Initialized
DEBUG - 2010-06-24 12:02:47 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 12:02:47 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 12:02:47 --> Database Driver Class Initialized
DEBUG - 2010-06-24 12:02:47 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 12:02:47 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:02:47 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 12:02:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:02:47 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:02:47 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 12:02:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:02:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:03:17 --> Config Class Initialized
DEBUG - 2010-06-24 12:03:17 --> Hooks Class Initialized
DEBUG - 2010-06-24 12:03:17 --> URI Class Initialized
DEBUG - 2010-06-24 12:03:17 --> Router Class Initialized
DEBUG - 2010-06-24 12:03:17 --> Output Class Initialized
DEBUG - 2010-06-24 12:03:17 --> Input Class Initialized
DEBUG - 2010-06-24 12:03:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 12:03:17 --> Language Class Initialized
DEBUG - 2010-06-24 12:03:17 --> Loader Class Initialized
DEBUG - 2010-06-24 12:03:17 --> Helper loaded: object_helper
DEBUG - 2010-06-24 12:03:17 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 12:03:17 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:03:17 --> Session Class Initialized
DEBUG - 2010-06-24 12:03:17 --> Helper loaded: string_helper
DEBUG - 2010-06-24 12:03:17 --> Session routines successfully run
DEBUG - 2010-06-24 12:03:17 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:03:17 --> Controller Class Initialized
DEBUG - 2010-06-24 12:03:17 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 12:03:17 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 12:03:17 --> Database Driver Class Initialized
DEBUG - 2010-06-24 12:03:18 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 12:03:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:03:18 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 12:03:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:03:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:03:18 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 12:03:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:03:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:03:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:03:32 --> Config Class Initialized
DEBUG - 2010-06-24 12:03:32 --> Hooks Class Initialized
DEBUG - 2010-06-24 12:03:32 --> URI Class Initialized
DEBUG - 2010-06-24 12:03:32 --> Router Class Initialized
DEBUG - 2010-06-24 12:03:32 --> Output Class Initialized
DEBUG - 2010-06-24 12:03:32 --> Input Class Initialized
DEBUG - 2010-06-24 12:03:32 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 12:03:33 --> Language Class Initialized
DEBUG - 2010-06-24 12:03:33 --> Loader Class Initialized
DEBUG - 2010-06-24 12:03:33 --> Helper loaded: object_helper
DEBUG - 2010-06-24 12:03:33 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 12:03:33 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:03:33 --> Session Class Initialized
DEBUG - 2010-06-24 12:03:33 --> Helper loaded: string_helper
DEBUG - 2010-06-24 12:03:33 --> Session routines successfully run
DEBUG - 2010-06-24 12:03:33 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:03:33 --> Controller Class Initialized
DEBUG - 2010-06-24 12:03:33 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 12:03:33 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 12:03:33 --> Database Driver Class Initialized
DEBUG - 2010-06-24 12:03:33 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 12:03:33 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:03:33 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 12:03:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:03:33 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:03:33 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 12:03:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:03:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:03:33 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:12:09 --> Config Class Initialized
DEBUG - 2010-06-24 12:12:09 --> Hooks Class Initialized
DEBUG - 2010-06-24 12:12:09 --> URI Class Initialized
DEBUG - 2010-06-24 12:12:09 --> Router Class Initialized
DEBUG - 2010-06-24 12:12:09 --> Output Class Initialized
DEBUG - 2010-06-24 12:12:09 --> Input Class Initialized
DEBUG - 2010-06-24 12:12:09 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 12:12:09 --> Language Class Initialized
DEBUG - 2010-06-24 12:12:09 --> Loader Class Initialized
DEBUG - 2010-06-24 12:12:09 --> Helper loaded: object_helper
DEBUG - 2010-06-24 12:12:09 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 12:12:09 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:12:09 --> Session Class Initialized
DEBUG - 2010-06-24 12:12:09 --> Helper loaded: string_helper
DEBUG - 2010-06-24 12:12:09 --> Session routines successfully run
DEBUG - 2010-06-24 12:12:09 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:12:09 --> Controller Class Initialized
DEBUG - 2010-06-24 12:12:09 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 12:12:09 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 12:12:09 --> Database Driver Class Initialized
DEBUG - 2010-06-24 12:12:09 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 12:12:09 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:12:09 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 12:12:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:12:09 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:12:09 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 12:12:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:12:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:12:10 --> User class already loaded. Second attempt ignored.
ERROR - 2010-06-24 12:12:10 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  missing FROM-clause entry for table &quot;domain&quot;
LINE 1: SELECT &quot;domain&quot;.&quot;domain_id&quot;
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-24 12:12:10 --> DB Transaction Failure
ERROR - 2010-06-24 12:12:10 --> Query error: ERROR:  missing FROM-clause entry for table "domain"
LINE 1: SELECT "domain"."domain_id"
               ^
DEBUG - 2010-06-24 12:12:10 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-06-24 12:12:28 --> Config Class Initialized
DEBUG - 2010-06-24 12:12:28 --> Hooks Class Initialized
DEBUG - 2010-06-24 12:12:28 --> URI Class Initialized
DEBUG - 2010-06-24 12:12:28 --> Router Class Initialized
DEBUG - 2010-06-24 12:12:28 --> Output Class Initialized
DEBUG - 2010-06-24 12:12:28 --> Input Class Initialized
DEBUG - 2010-06-24 12:12:28 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 12:12:28 --> Language Class Initialized
DEBUG - 2010-06-24 12:12:28 --> Loader Class Initialized
DEBUG - 2010-06-24 12:12:28 --> Helper loaded: object_helper
DEBUG - 2010-06-24 12:12:28 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 12:12:28 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:12:28 --> Session Class Initialized
DEBUG - 2010-06-24 12:12:28 --> Helper loaded: string_helper
DEBUG - 2010-06-24 12:12:28 --> Session routines successfully run
DEBUG - 2010-06-24 12:12:28 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:12:28 --> Controller Class Initialized
DEBUG - 2010-06-24 12:12:28 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 12:12:28 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 12:12:28 --> Database Driver Class Initialized
DEBUG - 2010-06-24 12:12:28 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 12:12:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:12:28 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 12:12:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:12:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:12:28 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 12:12:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:12:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:12:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:12:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:12:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:12:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:12:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:12:29 --> User class already loaded. Second attempt ignored.
ERROR - 2010-06-24 12:12:29 --> Severity: Notice  --> Undefined offset:  0 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_actor\ut_group.php 84
DEBUG - 2010-06-24 12:17:19 --> Config Class Initialized
DEBUG - 2010-06-24 12:17:19 --> Hooks Class Initialized
DEBUG - 2010-06-24 12:17:19 --> URI Class Initialized
DEBUG - 2010-06-24 12:17:19 --> Router Class Initialized
DEBUG - 2010-06-24 12:17:19 --> Output Class Initialized
DEBUG - 2010-06-24 12:17:19 --> Input Class Initialized
DEBUG - 2010-06-24 12:17:19 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 12:17:20 --> Language Class Initialized
DEBUG - 2010-06-24 12:17:20 --> Loader Class Initialized
DEBUG - 2010-06-24 12:17:20 --> Helper loaded: object_helper
DEBUG - 2010-06-24 12:17:20 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 12:17:20 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:17:20 --> Session Class Initialized
DEBUG - 2010-06-24 12:17:20 --> Helper loaded: string_helper
DEBUG - 2010-06-24 12:17:20 --> Session routines successfully run
DEBUG - 2010-06-24 12:17:20 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:17:20 --> Controller Class Initialized
DEBUG - 2010-06-24 12:17:20 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 12:17:20 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 12:17:20 --> Database Driver Class Initialized
DEBUG - 2010-06-24 12:17:20 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 12:17:20 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 12:17:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:17:20 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:17:20 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 12:17:20 --> Config file loaded: config/kals.php
INFO  - 2010-06-24 12:17:20 --> User update: (86) pudding : 
DEBUG - 2010-06-24 12:17:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:17:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:17:20 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:17:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:17:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:17:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:17:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:17:20 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:17:20 --> Helper loaded: email_helper
DEBUG - 2010-06-24 12:17:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:17:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:17:21 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-24 12:17:21 --> Final output sent to browser
DEBUG - 2010-06-24 12:17:21 --> Total execution time: 1.3032
DEBUG - 2010-06-24 12:20:11 --> Config Class Initialized
DEBUG - 2010-06-24 12:20:11 --> Hooks Class Initialized
DEBUG - 2010-06-24 12:20:11 --> URI Class Initialized
DEBUG - 2010-06-24 12:20:11 --> Router Class Initialized
DEBUG - 2010-06-24 12:20:11 --> Output Class Initialized
DEBUG - 2010-06-24 12:20:11 --> Input Class Initialized
DEBUG - 2010-06-24 12:20:11 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 12:20:11 --> Language Class Initialized
DEBUG - 2010-06-24 12:20:11 --> Loader Class Initialized
DEBUG - 2010-06-24 12:20:11 --> Helper loaded: object_helper
DEBUG - 2010-06-24 12:20:11 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 12:20:11 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:20:11 --> Session Class Initialized
DEBUG - 2010-06-24 12:20:11 --> Helper loaded: string_helper
DEBUG - 2010-06-24 12:20:11 --> Session routines successfully run
DEBUG - 2010-06-24 12:20:11 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:20:11 --> Controller Class Initialized
DEBUG - 2010-06-24 12:20:11 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 12:20:11 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 12:20:11 --> Database Driver Class Initialized
DEBUG - 2010-06-24 12:20:11 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 12:20:11 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:20:11 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 12:20:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:20:11 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:20:11 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 12:20:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:20:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:20:12 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:20:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:20:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:20:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:20:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:20:12 --> User class already loaded. Second attempt ignored.
ERROR - 2010-06-24 12:20:12 --> Severity: Warning  --> array_push() [<a href='function.array-push'>function.array-push</a>]: First argument should be an array D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\Group.php 330
DEBUG - 2010-06-24 12:20:12 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:20:12 --> Config file loaded: config/kals.php
ERROR - 2010-06-24 12:20:12 --> Severity: Notice  --> Undefined variable: user D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_actor\ut_group.php 90
ERROR - 2010-06-24 12:20:12 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\Group.php 61
DEBUG - 2010-06-24 12:21:24 --> Config Class Initialized
DEBUG - 2010-06-24 12:21:24 --> Hooks Class Initialized
DEBUG - 2010-06-24 12:21:24 --> URI Class Initialized
DEBUG - 2010-06-24 12:21:24 --> Router Class Initialized
DEBUG - 2010-06-24 12:21:24 --> Output Class Initialized
DEBUG - 2010-06-24 12:21:24 --> Input Class Initialized
DEBUG - 2010-06-24 12:21:24 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 12:21:24 --> Language Class Initialized
DEBUG - 2010-06-24 12:21:24 --> Loader Class Initialized
DEBUG - 2010-06-24 12:21:24 --> Helper loaded: object_helper
DEBUG - 2010-06-24 12:21:24 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 12:21:24 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:21:24 --> Session Class Initialized
DEBUG - 2010-06-24 12:21:24 --> Helper loaded: string_helper
DEBUG - 2010-06-24 12:21:24 --> Session routines successfully run
DEBUG - 2010-06-24 12:21:25 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:21:25 --> Controller Class Initialized
DEBUG - 2010-06-24 12:21:25 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 12:21:25 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 12:21:25 --> Database Driver Class Initialized
DEBUG - 2010-06-24 12:21:25 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 12:21:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:21:25 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 12:21:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:21:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:21:25 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 12:21:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:21:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:21:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:21:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:21:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:21:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:21:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:21:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:21:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:21:25 --> Config file loaded: config/kals.php
ERROR - 2010-06-24 12:21:25 --> Severity: Notice  --> Undefined variable: user D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_actor\ut_group.php 90
ERROR - 2010-06-24 12:21:25 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\Group.php 61
DEBUG - 2010-06-24 12:23:10 --> Config Class Initialized
DEBUG - 2010-06-24 12:23:10 --> Hooks Class Initialized
DEBUG - 2010-06-24 12:23:10 --> URI Class Initialized
DEBUG - 2010-06-24 12:23:10 --> Router Class Initialized
DEBUG - 2010-06-24 12:23:10 --> Output Class Initialized
DEBUG - 2010-06-24 12:23:10 --> Input Class Initialized
DEBUG - 2010-06-24 12:23:10 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 12:23:10 --> Language Class Initialized
DEBUG - 2010-06-24 12:23:10 --> Loader Class Initialized
DEBUG - 2010-06-24 12:23:10 --> Helper loaded: object_helper
DEBUG - 2010-06-24 12:23:10 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 12:23:10 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:23:10 --> Session Class Initialized
DEBUG - 2010-06-24 12:23:10 --> Helper loaded: string_helper
DEBUG - 2010-06-24 12:23:10 --> Session routines successfully run
DEBUG - 2010-06-24 12:23:10 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:23:10 --> Controller Class Initialized
DEBUG - 2010-06-24 12:23:10 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 12:23:10 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 12:23:10 --> Database Driver Class Initialized
DEBUG - 2010-06-24 12:23:10 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 12:23:10 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:23:10 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 12:23:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:23:11 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:23:11 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 12:23:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:23:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:23:11 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:23:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:23:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:23:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:23:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:23:11 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:23:11 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:23:11 --> Config file loaded: config/kals.php
ERROR - 2010-06-24 12:23:11 --> Severity: Warning  --> array_key_exists() [<a href='function.array-key-exists'>function.array-key-exists</a>]: The first argument should be either a string or an integer D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 299
DEBUG - 2010-06-24 12:27:38 --> Config Class Initialized
DEBUG - 2010-06-24 12:27:38 --> Hooks Class Initialized
DEBUG - 2010-06-24 12:27:38 --> URI Class Initialized
DEBUG - 2010-06-24 12:27:38 --> Router Class Initialized
DEBUG - 2010-06-24 12:27:38 --> Output Class Initialized
DEBUG - 2010-06-24 12:27:38 --> Input Class Initialized
DEBUG - 2010-06-24 12:27:38 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 12:27:38 --> Language Class Initialized
DEBUG - 2010-06-24 12:27:38 --> Loader Class Initialized
DEBUG - 2010-06-24 12:27:38 --> Helper loaded: object_helper
DEBUG - 2010-06-24 12:27:38 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 12:27:38 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:27:38 --> Session Class Initialized
DEBUG - 2010-06-24 12:27:38 --> Helper loaded: string_helper
DEBUG - 2010-06-24 12:27:38 --> Session routines successfully run
DEBUG - 2010-06-24 12:27:38 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:27:38 --> Controller Class Initialized
DEBUG - 2010-06-24 12:27:38 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 12:27:38 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 12:27:38 --> Database Driver Class Initialized
DEBUG - 2010-06-24 12:27:38 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 12:27:38 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:27:38 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 12:27:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:27:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:27:39 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 12:27:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:27:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:27:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:27:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:27:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:27:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:27:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:27:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:27:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:27:39 --> Config file loaded: config/kals.php
DEBUG - 2010-06-24 12:31:22 --> Config Class Initialized
DEBUG - 2010-06-24 12:31:22 --> Hooks Class Initialized
DEBUG - 2010-06-24 12:31:22 --> URI Class Initialized
DEBUG - 2010-06-24 12:31:22 --> Router Class Initialized
DEBUG - 2010-06-24 12:31:22 --> Output Class Initialized
DEBUG - 2010-06-24 12:31:22 --> Input Class Initialized
DEBUG - 2010-06-24 12:31:22 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 12:31:22 --> Language Class Initialized
DEBUG - 2010-06-24 12:31:22 --> Loader Class Initialized
DEBUG - 2010-06-24 12:31:22 --> Helper loaded: object_helper
DEBUG - 2010-06-24 12:31:22 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 12:31:22 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:31:22 --> Session Class Initialized
DEBUG - 2010-06-24 12:31:22 --> Helper loaded: string_helper
DEBUG - 2010-06-24 12:31:22 --> Session routines successfully run
DEBUG - 2010-06-24 12:31:22 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:31:22 --> Controller Class Initialized
DEBUG - 2010-06-24 12:31:22 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 12:31:22 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 12:31:22 --> Database Driver Class Initialized
DEBUG - 2010-06-24 12:31:22 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 12:31:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:31:22 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 12:31:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:31:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:31:22 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 12:31:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:31:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:31:23 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:31:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:31:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:31:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:31:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:31:23 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:31:23 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:31:23 --> Config file loaded: config/kals.php
DEBUG - 2010-06-24 12:31:23 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:31:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:31:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:31:23 --> User class already loaded. Second attempt ignored.
ERROR - 2010-06-24 12:31:23 --> Severity: Notice  --> Undefined variable: groups D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\Group.php 344
ERROR - 2010-06-24 12:31:23 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\Group.php 344
DEBUG - 2010-06-24 12:31:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:31:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:31:23 --> User class already loaded. Second attempt ignored.
ERROR - 2010-06-24 12:31:23 --> Severity: Notice  --> Undefined property: CI_DB_postgre_result::$result D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 502
ERROR - 2010-06-24 12:31:23 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 502
ERROR - 2010-06-24 12:31:23 --> Severity: Notice  --> Undefined offset:  0 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_actor\ut_group.php 128
DEBUG - 2010-06-24 12:44:43 --> Config Class Initialized
DEBUG - 2010-06-24 12:44:43 --> Hooks Class Initialized
DEBUG - 2010-06-24 12:44:43 --> URI Class Initialized
DEBUG - 2010-06-24 12:44:43 --> Router Class Initialized
DEBUG - 2010-06-24 12:44:43 --> Output Class Initialized
DEBUG - 2010-06-24 12:44:43 --> Input Class Initialized
DEBUG - 2010-06-24 12:44:43 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 12:44:43 --> Language Class Initialized
DEBUG - 2010-06-24 12:44:43 --> Loader Class Initialized
DEBUG - 2010-06-24 12:44:43 --> Helper loaded: object_helper
DEBUG - 2010-06-24 12:44:43 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 12:44:43 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:44:43 --> Session Class Initialized
DEBUG - 2010-06-24 12:44:43 --> Helper loaded: string_helper
DEBUG - 2010-06-24 12:44:43 --> Session routines successfully run
DEBUG - 2010-06-24 12:44:43 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:44:43 --> Controller Class Initialized
DEBUG - 2010-06-24 12:44:43 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 12:44:43 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 12:44:43 --> Database Driver Class Initialized
DEBUG - 2010-06-24 12:44:43 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 12:44:44 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:44:44 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 12:44:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:44:44 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:44:44 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 12:44:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:44:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:44:44 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:44:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:44:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:44:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:44:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:44:44 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:44:44 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:44:44 --> Config file loaded: config/kals.php
DEBUG - 2010-06-24 12:44:44 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:44:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:44:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:44:44 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:44:44 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:44:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:44:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:44:44 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:17 --> Config Class Initialized
DEBUG - 2010-06-24 12:46:17 --> Hooks Class Initialized
DEBUG - 2010-06-24 12:46:17 --> URI Class Initialized
DEBUG - 2010-06-24 12:46:17 --> Router Class Initialized
DEBUG - 2010-06-24 12:46:17 --> Output Class Initialized
ERROR - 2010-06-24 12:46:17 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/812b4ba287f5ee0bc9d43bbf5bbe87fb) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
DEBUG - 2010-06-24 12:46:17 --> Input Class Initialized
DEBUG - 2010-06-24 12:46:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 12:46:17 --> Language Class Initialized
DEBUG - 2010-06-24 12:46:17 --> Loader Class Initialized
DEBUG - 2010-06-24 12:46:17 --> Helper loaded: object_helper
DEBUG - 2010-06-24 12:46:17 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 12:46:17 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:46:17 --> Session Class Initialized
DEBUG - 2010-06-24 12:46:17 --> Helper loaded: string_helper
DEBUG - 2010-06-24 12:46:17 --> Session routines successfully run
DEBUG - 2010-06-24 12:46:18 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:46:18 --> Controller Class Initialized
DEBUG - 2010-06-24 12:46:18 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 12:46:18 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 12:46:18 --> Database Driver Class Initialized
DEBUG - 2010-06-24 12:46:18 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 12:46:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:18 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 12:46:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:18 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 12:46:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:18 --> Config file loaded: config/kals.php
DEBUG - 2010-06-24 12:46:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:19 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:19 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:19 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:19 --> User class already loaded. Second attempt ignored.
ERROR - 2010-06-24 12:46:19 --> Severity: Notice  --> Undefined property: CI_DB_postgre_result::$result D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\Group.php 284
ERROR - 2010-06-24 12:46:19 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\Group.php 284
DEBUG - 2010-06-24 12:46:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:19 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-24 12:46:19 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;0&quot; does not exist
LINE 2: WHERE &quot;0&quot; = 'group_id'
              ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-24 12:46:19 --> DB Transaction Failure
ERROR - 2010-06-24 12:46:19 --> Query error: ERROR:  column "0" does not exist
LINE 2: WHERE "0" = 'group_id'
              ^
DEBUG - 2010-06-24 12:46:19 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-06-24 12:46:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-24 12:46:49 --> Config Class Initialized
DEBUG - 2010-06-24 12:46:49 --> Hooks Class Initialized
DEBUG - 2010-06-24 12:46:49 --> URI Class Initialized
DEBUG - 2010-06-24 12:46:49 --> Router Class Initialized
DEBUG - 2010-06-24 12:46:49 --> Output Class Initialized
DEBUG - 2010-06-24 12:46:49 --> Input Class Initialized
DEBUG - 2010-06-24 12:46:49 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 12:46:49 --> Language Class Initialized
DEBUG - 2010-06-24 12:46:49 --> Loader Class Initialized
DEBUG - 2010-06-24 12:46:49 --> Helper loaded: object_helper
DEBUG - 2010-06-24 12:46:49 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 12:46:49 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:46:49 --> Session Class Initialized
DEBUG - 2010-06-24 12:46:49 --> Helper loaded: string_helper
DEBUG - 2010-06-24 12:46:49 --> Session routines successfully run
DEBUG - 2010-06-24 12:46:49 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:46:49 --> Controller Class Initialized
DEBUG - 2010-06-24 12:46:49 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 12:46:49 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 12:46:50 --> Database Driver Class Initialized
DEBUG - 2010-06-24 12:46:50 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 12:46:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:50 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 12:46:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:50 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 12:46:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:50 --> Config file loaded: config/kals.php
DEBUG - 2010-06-24 12:46:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:51 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:46:51 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-24 12:46:51 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;0&quot; does not exist
LINE 2: WHERE &quot;0&quot; = 'group_id'
              ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-24 12:46:51 --> DB Transaction Failure
ERROR - 2010-06-24 12:46:51 --> Query error: ERROR:  column "0" does not exist
LINE 2: WHERE "0" = 'group_id'
              ^
DEBUG - 2010-06-24 12:46:51 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-06-24 12:47:48 --> Config Class Initialized
DEBUG - 2010-06-24 12:47:49 --> Hooks Class Initialized
DEBUG - 2010-06-24 12:47:49 --> URI Class Initialized
DEBUG - 2010-06-24 12:47:49 --> Router Class Initialized
DEBUG - 2010-06-24 12:47:49 --> Output Class Initialized
DEBUG - 2010-06-24 12:47:49 --> Input Class Initialized
DEBUG - 2010-06-24 12:47:49 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 12:47:49 --> Language Class Initialized
DEBUG - 2010-06-24 12:47:49 --> Loader Class Initialized
DEBUG - 2010-06-24 12:47:49 --> Helper loaded: object_helper
DEBUG - 2010-06-24 12:47:49 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 12:47:49 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:47:49 --> Session Class Initialized
DEBUG - 2010-06-24 12:47:49 --> Helper loaded: string_helper
DEBUG - 2010-06-24 12:47:49 --> Session routines successfully run
DEBUG - 2010-06-24 12:47:49 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:47:49 --> Controller Class Initialized
DEBUG - 2010-06-24 12:47:49 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 12:47:49 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 12:47:49 --> Database Driver Class Initialized
DEBUG - 2010-06-24 12:47:49 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 12:47:49 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:47:49 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 12:47:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:47:49 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:47:50 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 12:47:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:47:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:47:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:47:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:47:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:47:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:47:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:47:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:47:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:47:50 --> Config file loaded: config/kals.php
DEBUG - 2010-06-24 12:47:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:47:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:47:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:47:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:47:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:47:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:47:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:47:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:47:50 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:47:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:47:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:47:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:47:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:47:51 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:47:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:47:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:47:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:47:51 --> User class already loaded. Second attempt ignored.
ERROR - 2010-06-24 12:47:51 --> Severity: 4096  --> Object of class Group could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 233
ERROR - 2010-06-24 12:47:51 --> Severity: 4096  --> Object of class Group could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-24 12:47:51 --> Severity: Notice  --> Object of class Group to string conversion D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-24 12:47:51 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  update or delete on table &quot;user&quot; violates foreign key constraint &quot;domain2user_user_id_fkey&quot; on table &quot;domain2user&quot;
DETAIL:  Key (user_id)=(88) is still referenced from table &quot;domain2user&quot;. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-24 12:47:51 --> DB Transaction Failure
ERROR - 2010-06-24 12:47:51 --> Query error: ERROR:  update or delete on table "user" violates foreign key constraint "domain2user_user_id_fkey" on table "domain2user"
DETAIL:  Key (user_id)=(88) is still referenced from table "domain2user".
DEBUG - 2010-06-24 12:47:51 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-06-24 12:47:51 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-24 12:49:37 --> Config Class Initialized
DEBUG - 2010-06-24 12:49:37 --> Hooks Class Initialized
DEBUG - 2010-06-24 12:49:37 --> URI Class Initialized
DEBUG - 2010-06-24 12:49:37 --> Router Class Initialized
DEBUG - 2010-06-24 12:49:37 --> Output Class Initialized
ERROR - 2010-06-24 12:49:38 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/98f13708210194c475687be6106a3b84) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
DEBUG - 2010-06-24 12:49:38 --> Input Class Initialized
DEBUG - 2010-06-24 12:49:38 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 12:49:38 --> Language Class Initialized
DEBUG - 2010-06-24 12:49:38 --> Loader Class Initialized
DEBUG - 2010-06-24 12:49:38 --> Helper loaded: object_helper
DEBUG - 2010-06-24 12:49:38 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 12:49:38 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:49:38 --> Session Class Initialized
DEBUG - 2010-06-24 12:49:38 --> Helper loaded: string_helper
DEBUG - 2010-06-24 12:49:38 --> Session routines successfully run
DEBUG - 2010-06-24 12:49:38 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:49:38 --> Controller Class Initialized
DEBUG - 2010-06-24 12:49:38 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 12:49:38 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 12:49:38 --> Database Driver Class Initialized
DEBUG - 2010-06-24 12:49:38 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 12:49:38 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:49:38 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 12:49:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:49:38 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:49:38 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 12:49:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:49:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:49:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:49:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:49:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:49:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:49:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:49:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:49:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:49:39 --> Config file loaded: config/kals.php
DEBUG - 2010-06-24 12:49:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:49:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:49:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:49:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:49:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:49:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:49:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:49:39 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:49:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:49:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:49:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:49:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:49:39 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:49:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:49:40 --> User class already loaded. Second attempt ignored.
ERROR - 2010-06-24 12:49:40 --> Severity: 4096  --> Object of class Group could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 233
ERROR - 2010-06-24 12:49:40 --> Severity: 4096  --> Object of class Group could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-24 12:49:40 --> Severity: Notice  --> Object of class Group to string conversion D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-24 12:49:40 --> Severity: 4096  --> Object of class Group could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 224
ERROR - 2010-06-24 12:49:40 --> Severity: 4096  --> Object of class Group could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-24 12:49:40 --> Severity: Notice  --> Object of class Group to string conversion D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 152
ERROR - 2010-06-24 12:49:40 --> Severity: 4096  --> Object of class Group could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 224
DEBUG - 2010-06-24 12:49:40 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-24 12:49:40 --> Final output sent to browser
DEBUG - 2010-06-24 12:49:40 --> Total execution time: 2.6929
DEBUG - 2010-06-24 12:52:53 --> Config Class Initialized
DEBUG - 2010-06-24 12:52:53 --> Hooks Class Initialized
DEBUG - 2010-06-24 12:52:53 --> URI Class Initialized
DEBUG - 2010-06-24 12:52:53 --> Router Class Initialized
DEBUG - 2010-06-24 12:52:53 --> Output Class Initialized
DEBUG - 2010-06-24 12:52:53 --> Input Class Initialized
DEBUG - 2010-06-24 12:52:53 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 12:52:53 --> Language Class Initialized
DEBUG - 2010-06-24 12:52:53 --> Loader Class Initialized
DEBUG - 2010-06-24 12:52:53 --> Helper loaded: object_helper
DEBUG - 2010-06-24 12:52:53 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 12:52:53 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:52:53 --> Session Class Initialized
DEBUG - 2010-06-24 12:52:53 --> Helper loaded: string_helper
DEBUG - 2010-06-24 12:52:53 --> Session routines successfully run
DEBUG - 2010-06-24 12:52:53 --> Helper loaded: context_helper
DEBUG - 2010-06-24 12:52:53 --> Controller Class Initialized
DEBUG - 2010-06-24 12:52:53 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 12:52:54 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 12:52:54 --> Database Driver Class Initialized
DEBUG - 2010-06-24 12:52:54 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 12:52:54 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:52:54 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 12:52:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:52:54 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:52:54 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 12:52:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:52:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:52:54 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:52:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:52:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:52:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:52:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:52:54 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:52:54 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:52:54 --> Config file loaded: config/kals.php
DEBUG - 2010-06-24 12:52:54 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:52:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:52:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:52:54 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:52:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:52:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:52:55 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:52:55 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:52:55 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:52:55 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:52:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:52:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:52:55 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:52:55 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:52:55 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 12:52:55 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-24 12:52:55 --> Final output sent to browser
DEBUG - 2010-06-24 12:52:55 --> Total execution time: 2.3746
DEBUG - 2010-06-24 14:19:48 --> Config Class Initialized
DEBUG - 2010-06-24 14:19:48 --> Hooks Class Initialized
DEBUG - 2010-06-24 14:19:48 --> URI Class Initialized
DEBUG - 2010-06-24 14:19:48 --> Router Class Initialized
DEBUG - 2010-06-24 14:19:48 --> Output Class Initialized
DEBUG - 2010-06-24 14:19:48 --> Input Class Initialized
DEBUG - 2010-06-24 14:19:48 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 14:19:48 --> Language Class Initialized
DEBUG - 2010-06-24 14:19:48 --> Loader Class Initialized
DEBUG - 2010-06-24 14:19:48 --> Helper loaded: object_helper
DEBUG - 2010-06-24 14:19:48 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 14:19:48 --> Helper loaded: context_helper
DEBUG - 2010-06-24 14:19:48 --> Session Class Initialized
DEBUG - 2010-06-24 14:19:48 --> Helper loaded: string_helper
DEBUG - 2010-06-24 14:19:48 --> Session routines successfully run
DEBUG - 2010-06-24 14:19:48 --> Helper loaded: context_helper
DEBUG - 2010-06-24 14:19:48 --> Controller Class Initialized
DEBUG - 2010-06-24 14:19:48 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 14:19:49 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 14:19:49 --> Database Driver Class Initialized
DEBUG - 2010-06-24 14:19:49 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 14:19:49 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:19:49 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 14:19:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:19:49 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:19:49 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 14:19:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:19:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:19:49 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:19:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:19:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:19:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:19:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:19:49 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:19:49 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:19:49 --> Config file loaded: config/kals.php
DEBUG - 2010-06-24 14:19:49 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:19:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:19:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:19:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:19:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:19:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:19:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:19:50 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:19:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:19:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:19:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:19:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:19:50 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:19:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:19:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:19:50 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-24 14:19:50 --> Final output sent to browser
DEBUG - 2010-06-24 14:19:50 --> Total execution time: 2.6455
DEBUG - 2010-06-24 14:20:25 --> Config Class Initialized
DEBUG - 2010-06-24 14:20:25 --> Hooks Class Initialized
DEBUG - 2010-06-24 14:20:25 --> URI Class Initialized
DEBUG - 2010-06-24 14:20:25 --> Router Class Initialized
DEBUG - 2010-06-24 14:20:25 --> Output Class Initialized
DEBUG - 2010-06-24 14:20:25 --> Input Class Initialized
DEBUG - 2010-06-24 14:20:25 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 14:20:25 --> Language Class Initialized
DEBUG - 2010-06-24 14:20:25 --> Loader Class Initialized
DEBUG - 2010-06-24 14:20:25 --> Helper loaded: object_helper
DEBUG - 2010-06-24 14:20:25 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 14:20:25 --> Helper loaded: context_helper
DEBUG - 2010-06-24 14:20:25 --> Session Class Initialized
DEBUG - 2010-06-24 14:20:25 --> Helper loaded: string_helper
DEBUG - 2010-06-24 14:20:25 --> Session routines successfully run
DEBUG - 2010-06-24 14:20:25 --> Helper loaded: context_helper
DEBUG - 2010-06-24 14:20:25 --> Controller Class Initialized
DEBUG - 2010-06-24 14:20:25 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 14:20:25 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 14:20:26 --> Database Driver Class Initialized
DEBUG - 2010-06-24 14:20:26 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 14:20:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:20:26 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 14:20:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:20:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:20:26 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 14:20:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:20:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:20:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:20:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:20:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:20:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:20:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:20:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:20:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:20:26 --> Config file loaded: config/kals.php
ERROR - 2010-06-24 14:20:26 --> Severity: Notice  --> Undefined variable: user2 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_actor\ut_group.php 170
DEBUG - 2010-06-24 14:20:44 --> Config Class Initialized
DEBUG - 2010-06-24 14:20:44 --> Hooks Class Initialized
DEBUG - 2010-06-24 14:20:44 --> URI Class Initialized
DEBUG - 2010-06-24 14:20:44 --> Router Class Initialized
DEBUG - 2010-06-24 14:20:44 --> Output Class Initialized
DEBUG - 2010-06-24 14:20:44 --> Input Class Initialized
DEBUG - 2010-06-24 14:20:44 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 14:20:44 --> Language Class Initialized
DEBUG - 2010-06-24 14:20:44 --> Loader Class Initialized
DEBUG - 2010-06-24 14:20:44 --> Helper loaded: object_helper
DEBUG - 2010-06-24 14:20:44 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 14:20:44 --> Helper loaded: context_helper
DEBUG - 2010-06-24 14:20:44 --> Session Class Initialized
DEBUG - 2010-06-24 14:20:44 --> Helper loaded: string_helper
DEBUG - 2010-06-24 14:20:45 --> Session routines successfully run
DEBUG - 2010-06-24 14:20:45 --> Helper loaded: context_helper
DEBUG - 2010-06-24 14:20:45 --> Controller Class Initialized
DEBUG - 2010-06-24 14:20:45 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 14:20:45 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 14:20:45 --> Database Driver Class Initialized
DEBUG - 2010-06-24 14:20:45 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 14:20:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:20:45 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 14:20:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:20:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:20:45 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 14:20:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:20:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:20:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:20:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:20:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:20:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:20:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:20:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:20:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:20:46 --> Config file loaded: config/kals.php
DEBUG - 2010-06-24 14:20:46 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-24 14:20:46 --> Final output sent to browser
DEBUG - 2010-06-24 14:20:46 --> Total execution time: 1.7594
DEBUG - 2010-06-24 14:22:18 --> Config Class Initialized
DEBUG - 2010-06-24 14:22:18 --> Hooks Class Initialized
DEBUG - 2010-06-24 14:22:18 --> URI Class Initialized
DEBUG - 2010-06-24 14:22:18 --> Router Class Initialized
DEBUG - 2010-06-24 14:22:18 --> Output Class Initialized
DEBUG - 2010-06-24 14:22:18 --> Input Class Initialized
DEBUG - 2010-06-24 14:22:18 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 14:22:18 --> Language Class Initialized
DEBUG - 2010-06-24 14:22:18 --> Loader Class Initialized
DEBUG - 2010-06-24 14:22:18 --> Helper loaded: object_helper
DEBUG - 2010-06-24 14:22:18 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 14:22:18 --> Helper loaded: context_helper
DEBUG - 2010-06-24 14:22:18 --> Session Class Initialized
DEBUG - 2010-06-24 14:22:18 --> Helper loaded: string_helper
DEBUG - 2010-06-24 14:22:18 --> Session routines successfully run
DEBUG - 2010-06-24 14:22:19 --> Helper loaded: context_helper
DEBUG - 2010-06-24 14:22:19 --> Controller Class Initialized
DEBUG - 2010-06-24 14:22:19 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 14:22:19 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 14:22:19 --> Database Driver Class Initialized
DEBUG - 2010-06-24 14:22:19 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 14:22:19 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:22:19 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 14:22:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:22:19 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:22:19 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 14:22:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:22:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:22:19 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:22:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:22:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:22:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:22:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:22:19 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:22:19 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:22:20 --> Config file loaded: config/kals.php
DEBUG - 2010-06-24 14:22:20 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-24 14:22:20 --> Final output sent to browser
DEBUG - 2010-06-24 14:22:20 --> Total execution time: 1.8296
DEBUG - 2010-06-24 14:23:13 --> Config Class Initialized
DEBUG - 2010-06-24 14:23:14 --> Hooks Class Initialized
DEBUG - 2010-06-24 14:23:14 --> URI Class Initialized
DEBUG - 2010-06-24 14:23:14 --> Router Class Initialized
DEBUG - 2010-06-24 14:23:14 --> Output Class Initialized
DEBUG - 2010-06-24 14:23:14 --> Input Class Initialized
DEBUG - 2010-06-24 14:23:14 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 14:23:14 --> Language Class Initialized
DEBUG - 2010-06-24 14:23:14 --> Loader Class Initialized
DEBUG - 2010-06-24 14:23:14 --> Helper loaded: object_helper
DEBUG - 2010-06-24 14:23:14 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 14:23:14 --> Helper loaded: context_helper
DEBUG - 2010-06-24 14:23:14 --> Session Class Initialized
DEBUG - 2010-06-24 14:23:14 --> Helper loaded: string_helper
DEBUG - 2010-06-24 14:23:14 --> Session routines successfully run
DEBUG - 2010-06-24 14:23:14 --> Helper loaded: context_helper
DEBUG - 2010-06-24 14:23:14 --> Controller Class Initialized
DEBUG - 2010-06-24 14:23:14 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 14:23:14 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 14:23:14 --> Database Driver Class Initialized
DEBUG - 2010-06-24 14:23:14 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 14:23:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:23:15 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 14:23:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:23:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:23:15 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 14:23:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:23:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:23:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:23:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:23:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:23:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:23:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:23:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:23:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:23:15 --> Config file loaded: config/kals.php
DEBUG - 2010-06-24 14:23:15 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-24 14:23:15 --> Final output sent to browser
DEBUG - 2010-06-24 14:23:15 --> Total execution time: 1.8365
DEBUG - 2010-06-24 14:23:53 --> Config Class Initialized
DEBUG - 2010-06-24 14:23:53 --> Hooks Class Initialized
DEBUG - 2010-06-24 14:23:54 --> URI Class Initialized
DEBUG - 2010-06-24 14:23:54 --> Router Class Initialized
DEBUG - 2010-06-24 14:23:54 --> Output Class Initialized
DEBUG - 2010-06-24 14:23:54 --> Input Class Initialized
DEBUG - 2010-06-24 14:23:54 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-24 14:23:54 --> Language Class Initialized
DEBUG - 2010-06-24 14:23:54 --> Loader Class Initialized
DEBUG - 2010-06-24 14:23:54 --> Helper loaded: object_helper
DEBUG - 2010-06-24 14:23:54 --> Helper loaded: kals_helper
DEBUG - 2010-06-24 14:23:54 --> Helper loaded: context_helper
DEBUG - 2010-06-24 14:23:54 --> Session Class Initialized
DEBUG - 2010-06-24 14:23:54 --> Helper loaded: string_helper
DEBUG - 2010-06-24 14:23:54 --> Session routines successfully run
DEBUG - 2010-06-24 14:23:54 --> Helper loaded: context_helper
DEBUG - 2010-06-24 14:23:54 --> Controller Class Initialized
DEBUG - 2010-06-24 14:23:54 --> Unit Testing Class Initialized
DEBUG - 2010-06-24 14:23:54 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-24 14:23:54 --> Database Driver Class Initialized
DEBUG - 2010-06-24 14:23:54 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-24 14:23:54 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:23:55 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-24 14:23:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:23:55 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:23:55 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-24 14:23:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:23:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:23:55 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:23:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:23:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:23:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:23:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:23:55 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:23:55 --> Config file loaded: config/kals.php
DEBUG - 2010-06-24 14:23:55 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-24 14:23:55 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-24 14:23:55 --> Final output sent to browser
DEBUG - 2010-06-24 14:23:55 --> Total execution time: 1.8714
