<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2010-06-23 07:05:13 --> Config Class Initialized
DEBUG - 2010-06-23 07:05:13 --> Hooks Class Initialized
DEBUG - 2010-06-23 07:05:13 --> URI Class Initialized
DEBUG - 2010-06-23 07:05:13 --> No URI present. Default controller set.
DEBUG - 2010-06-23 07:05:13 --> Router Class Initialized
DEBUG - 2010-06-23 07:05:13 --> Output Class Initialized
DEBUG - 2010-06-23 07:05:13 --> Input Class Initialized
DEBUG - 2010-06-23 07:05:13 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 07:05:13 --> Language Class Initialized
DEBUG - 2010-06-23 07:05:13 --> Loader Class Initialized
DEBUG - 2010-06-23 07:05:13 --> Helper loaded: object_helper
DEBUG - 2010-06-23 07:05:13 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 07:05:13 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:05:13 --> Session Class Initialized
DEBUG - 2010-06-23 07:05:13 --> Helper loaded: string_helper
DEBUG - 2010-06-23 07:05:13 --> A session cookie was not found.
DEBUG - 2010-06-23 07:05:13 --> Session routines successfully run
DEBUG - 2010-06-23 07:05:13 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:05:13 --> Controller Class Initialized
DEBUG - 2010-06-23 07:05:13 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 07:05:13 --> Final output sent to browser
DEBUG - 2010-06-23 07:05:13 --> Total execution time: 0.1992
DEBUG - 2010-06-23 07:24:57 --> Config Class Initialized
DEBUG - 2010-06-23 07:24:57 --> Hooks Class Initialized
DEBUG - 2010-06-23 07:24:57 --> URI Class Initialized
DEBUG - 2010-06-23 07:24:57 --> No URI present. Default controller set.
DEBUG - 2010-06-23 07:24:57 --> Router Class Initialized
DEBUG - 2010-06-23 07:24:57 --> Output Class Initialized
DEBUG - 2010-06-23 07:24:57 --> Input Class Initialized
DEBUG - 2010-06-23 07:24:57 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 07:24:57 --> Language Class Initialized
DEBUG - 2010-06-23 07:24:57 --> Loader Class Initialized
DEBUG - 2010-06-23 07:24:57 --> Helper loaded: object_helper
DEBUG - 2010-06-23 07:24:57 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 07:24:57 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:24:57 --> Session Class Initialized
DEBUG - 2010-06-23 07:24:57 --> Helper loaded: string_helper
DEBUG - 2010-06-23 07:24:57 --> A session cookie was not found.
DEBUG - 2010-06-23 07:24:57 --> Session routines successfully run
DEBUG - 2010-06-23 07:24:57 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:24:57 --> Controller Class Initialized
DEBUG - 2010-06-23 07:24:57 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 07:24:57 --> Final output sent to browser
DEBUG - 2010-06-23 07:24:57 --> Total execution time: 0.0956
DEBUG - 2010-06-23 07:27:28 --> Config Class Initialized
DEBUG - 2010-06-23 07:27:28 --> Hooks Class Initialized
DEBUG - 2010-06-23 07:27:28 --> URI Class Initialized
DEBUG - 2010-06-23 07:27:28 --> No URI present. Default controller set.
DEBUG - 2010-06-23 07:27:28 --> Router Class Initialized
DEBUG - 2010-06-23 07:27:28 --> Output Class Initialized
DEBUG - 2010-06-23 07:27:28 --> Input Class Initialized
DEBUG - 2010-06-23 07:27:28 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 07:27:28 --> Language Class Initialized
DEBUG - 2010-06-23 07:27:28 --> Loader Class Initialized
DEBUG - 2010-06-23 07:27:28 --> Helper loaded: object_helper
DEBUG - 2010-06-23 07:27:28 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 07:27:28 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:27:28 --> Session Class Initialized
DEBUG - 2010-06-23 07:27:28 --> Helper loaded: string_helper
DEBUG - 2010-06-23 07:27:28 --> Session routines successfully run
DEBUG - 2010-06-23 07:27:28 --> Helper loaded: context_helper
ERROR - 2010-06-23 07:27:28 --> Severity: Warning  --> fopen(D:\xampp\htdocs\CodeIgniter_1.7.2/system/logs/log-2010-06-23.php) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Log.php 97
DEBUG - 2010-06-23 07:27:28 --> User Agent Class Initialized
ERROR - 2010-06-23 07:27:28 --> Severity: Notice  --> Undefined property: CI_Loader::$agent D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\views\welcome_message.php 49
DEBUG - 2010-06-23 07:27:52 --> Config Class Initialized
DEBUG - 2010-06-23 07:27:52 --> Hooks Class Initialized
DEBUG - 2010-06-23 07:27:52 --> URI Class Initialized
DEBUG - 2010-06-23 07:27:52 --> No URI present. Default controller set.
DEBUG - 2010-06-23 07:27:52 --> Router Class Initialized
DEBUG - 2010-06-23 07:27:52 --> Output Class Initialized
DEBUG - 2010-06-23 07:27:52 --> Input Class Initialized
DEBUG - 2010-06-23 07:27:52 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 07:27:52 --> Language Class Initialized
DEBUG - 2010-06-23 07:27:52 --> Loader Class Initialized
DEBUG - 2010-06-23 07:27:52 --> Helper loaded: object_helper
DEBUG - 2010-06-23 07:27:52 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 07:27:52 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:27:52 --> Session Class Initialized
DEBUG - 2010-06-23 07:27:52 --> Helper loaded: string_helper
DEBUG - 2010-06-23 07:27:52 --> Session routines successfully run
DEBUG - 2010-06-23 07:27:52 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:27:52 --> Controller Class Initialized
DEBUG - 2010-06-23 07:27:52 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 07:27:52 --> User Agent Class Initialized
DEBUG - 2010-06-23 07:27:52 --> Final output sent to browser
DEBUG - 2010-06-23 07:27:52 --> Total execution time: 0.1185
DEBUG - 2010-06-23 07:33:38 --> Config Class Initialized
DEBUG - 2010-06-23 07:33:38 --> Hooks Class Initialized
DEBUG - 2010-06-23 07:33:38 --> URI Class Initialized
DEBUG - 2010-06-23 07:33:38 --> No URI present. Default controller set.
DEBUG - 2010-06-23 07:33:38 --> Router Class Initialized
DEBUG - 2010-06-23 07:33:38 --> Output Class Initialized
DEBUG - 2010-06-23 07:33:38 --> Input Class Initialized
DEBUG - 2010-06-23 07:33:38 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 07:33:38 --> Language Class Initialized
DEBUG - 2010-06-23 07:33:38 --> Loader Class Initialized
DEBUG - 2010-06-23 07:33:38 --> Helper loaded: object_helper
DEBUG - 2010-06-23 07:33:38 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 07:33:38 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:33:38 --> Session Class Initialized
DEBUG - 2010-06-23 07:33:38 --> Helper loaded: string_helper
DEBUG - 2010-06-23 07:33:38 --> Session routines successfully run
DEBUG - 2010-06-23 07:33:38 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:33:38 --> Controller Class Initialized
DEBUG - 2010-06-23 07:33:38 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 07:33:38 --> User Agent Class Initialized
DEBUG - 2010-06-23 07:33:38 --> Final output sent to browser
DEBUG - 2010-06-23 07:33:38 --> Total execution time: 0.1385
DEBUG - 2010-06-23 07:33:54 --> Config Class Initialized
DEBUG - 2010-06-23 07:33:54 --> Hooks Class Initialized
DEBUG - 2010-06-23 07:33:54 --> URI Class Initialized
DEBUG - 2010-06-23 07:33:54 --> No URI present. Default controller set.
DEBUG - 2010-06-23 07:33:54 --> Router Class Initialized
DEBUG - 2010-06-23 07:33:54 --> Output Class Initialized
DEBUG - 2010-06-23 07:33:54 --> Input Class Initialized
DEBUG - 2010-06-23 07:33:54 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 07:33:54 --> Language Class Initialized
DEBUG - 2010-06-23 07:33:54 --> Loader Class Initialized
DEBUG - 2010-06-23 07:33:54 --> Helper loaded: object_helper
DEBUG - 2010-06-23 07:33:54 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 07:33:54 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:33:54 --> Session Class Initialized
DEBUG - 2010-06-23 07:33:54 --> Helper loaded: string_helper
DEBUG - 2010-06-23 07:33:54 --> Session routines successfully run
DEBUG - 2010-06-23 07:33:54 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:33:54 --> Controller Class Initialized
DEBUG - 2010-06-23 07:33:54 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 07:33:55 --> User Agent Class Initialized
DEBUG - 2010-06-23 07:33:55 --> Final output sent to browser
DEBUG - 2010-06-23 07:33:55 --> Total execution time: 0.1503
DEBUG - 2010-06-23 07:38:49 --> Config Class Initialized
DEBUG - 2010-06-23 07:38:49 --> Hooks Class Initialized
DEBUG - 2010-06-23 07:38:49 --> URI Class Initialized
DEBUG - 2010-06-23 07:38:49 --> No URI present. Default controller set.
DEBUG - 2010-06-23 07:38:49 --> Router Class Initialized
DEBUG - 2010-06-23 07:38:49 --> Output Class Initialized
DEBUG - 2010-06-23 07:38:49 --> Input Class Initialized
DEBUG - 2010-06-23 07:38:49 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 07:38:49 --> Language Class Initialized
DEBUG - 2010-06-23 07:38:49 --> Loader Class Initialized
DEBUG - 2010-06-23 07:38:49 --> Helper loaded: object_helper
DEBUG - 2010-06-23 07:38:49 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 07:38:49 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:38:49 --> Session Class Initialized
DEBUG - 2010-06-23 07:38:49 --> Helper loaded: string_helper
DEBUG - 2010-06-23 07:38:49 --> A session cookie was not found.
DEBUG - 2010-06-23 07:38:49 --> Session routines successfully run
DEBUG - 2010-06-23 07:38:49 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:38:49 --> Controller Class Initialized
DEBUG - 2010-06-23 07:38:49 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 07:38:49 --> Database Driver Class Initialized
DEBUG - 2010-06-23 07:38:49 --> Final output sent to browser
DEBUG - 2010-06-23 07:38:49 --> Total execution time: 0.2495
DEBUG - 2010-06-23 07:40:16 --> Config Class Initialized
DEBUG - 2010-06-23 07:40:16 --> Hooks Class Initialized
DEBUG - 2010-06-23 07:40:16 --> URI Class Initialized
DEBUG - 2010-06-23 07:40:16 --> No URI present. Default controller set.
DEBUG - 2010-06-23 07:40:16 --> Router Class Initialized
DEBUG - 2010-06-23 07:40:16 --> Output Class Initialized
DEBUG - 2010-06-23 07:40:16 --> Input Class Initialized
DEBUG - 2010-06-23 07:40:16 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 07:40:16 --> Language Class Initialized
DEBUG - 2010-06-23 07:40:16 --> Loader Class Initialized
DEBUG - 2010-06-23 07:40:16 --> Helper loaded: object_helper
DEBUG - 2010-06-23 07:40:16 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 07:40:16 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:40:16 --> Session Class Initialized
DEBUG - 2010-06-23 07:40:16 --> Helper loaded: string_helper
DEBUG - 2010-06-23 07:40:16 --> A session cookie was not found.
DEBUG - 2010-06-23 07:40:16 --> Session routines successfully run
DEBUG - 2010-06-23 07:40:16 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:40:16 --> Controller Class Initialized
DEBUG - 2010-06-23 07:40:16 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 07:40:16 --> Database Driver Class Initialized
DEBUG - 2010-06-23 07:40:16 --> Final output sent to browser
DEBUG - 2010-06-23 07:40:16 --> Total execution time: 0.2141
DEBUG - 2010-06-23 07:40:20 --> Config Class Initialized
DEBUG - 2010-06-23 07:40:20 --> Hooks Class Initialized
DEBUG - 2010-06-23 07:40:20 --> URI Class Initialized
DEBUG - 2010-06-23 07:40:20 --> No URI present. Default controller set.
DEBUG - 2010-06-23 07:40:20 --> Router Class Initialized
DEBUG - 2010-06-23 07:40:20 --> Output Class Initialized
DEBUG - 2010-06-23 07:40:20 --> Input Class Initialized
DEBUG - 2010-06-23 07:40:20 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 07:40:20 --> Language Class Initialized
DEBUG - 2010-06-23 07:40:20 --> Loader Class Initialized
DEBUG - 2010-06-23 07:40:20 --> Helper loaded: object_helper
DEBUG - 2010-06-23 07:40:20 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 07:40:20 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:40:20 --> Session Class Initialized
DEBUG - 2010-06-23 07:40:20 --> Helper loaded: string_helper
DEBUG - 2010-06-23 07:40:20 --> Session routines successfully run
DEBUG - 2010-06-23 07:40:20 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:40:20 --> Controller Class Initialized
DEBUG - 2010-06-23 07:40:20 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 07:40:20 --> Database Driver Class Initialized
DEBUG - 2010-06-23 07:40:20 --> Final output sent to browser
DEBUG - 2010-06-23 07:40:20 --> Total execution time: 0.1936
DEBUG - 2010-06-23 07:41:30 --> Config Class Initialized
DEBUG - 2010-06-23 07:41:30 --> Hooks Class Initialized
DEBUG - 2010-06-23 07:41:30 --> URI Class Initialized
DEBUG - 2010-06-23 07:41:30 --> No URI present. Default controller set.
DEBUG - 2010-06-23 07:41:30 --> Router Class Initialized
DEBUG - 2010-06-23 07:41:30 --> Output Class Initialized
DEBUG - 2010-06-23 07:41:30 --> Input Class Initialized
DEBUG - 2010-06-23 07:41:30 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 07:41:30 --> Language Class Initialized
DEBUG - 2010-06-23 07:41:30 --> Loader Class Initialized
DEBUG - 2010-06-23 07:41:30 --> Helper loaded: object_helper
DEBUG - 2010-06-23 07:41:30 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 07:41:30 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:41:30 --> Session Class Initialized
DEBUG - 2010-06-23 07:41:30 --> Helper loaded: string_helper
DEBUG - 2010-06-23 07:41:30 --> Session routines successfully run
DEBUG - 2010-06-23 07:41:30 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:41:30 --> Controller Class Initialized
DEBUG - 2010-06-23 07:41:30 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 07:41:30 --> User Agent Class Initialized
ERROR - 2010-06-23 07:41:30 --> Severity: Notice  --> Undefined property: Welcome::$user_agent D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\welcome.php 16
DEBUG - 2010-06-23 07:41:37 --> Config Class Initialized
DEBUG - 2010-06-23 07:41:37 --> Hooks Class Initialized
DEBUG - 2010-06-23 07:41:37 --> URI Class Initialized
DEBUG - 2010-06-23 07:41:37 --> No URI present. Default controller set.
DEBUG - 2010-06-23 07:41:37 --> Router Class Initialized
DEBUG - 2010-06-23 07:41:38 --> Output Class Initialized
DEBUG - 2010-06-23 07:41:38 --> Input Class Initialized
DEBUG - 2010-06-23 07:41:38 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 07:41:38 --> Language Class Initialized
DEBUG - 2010-06-23 07:41:38 --> Loader Class Initialized
DEBUG - 2010-06-23 07:41:38 --> Helper loaded: object_helper
DEBUG - 2010-06-23 07:41:38 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 07:41:38 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:41:38 --> Session Class Initialized
DEBUG - 2010-06-23 07:41:38 --> Helper loaded: string_helper
DEBUG - 2010-06-23 07:41:38 --> Session routines successfully run
DEBUG - 2010-06-23 07:41:38 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:41:38 --> Controller Class Initialized
DEBUG - 2010-06-23 07:41:38 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 07:41:38 --> User Agent Class Initialized
ERROR - 2010-06-23 07:41:38 --> Severity: Notice  --> Undefined property: Welcome::$user_agent D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\welcome.php 16
DEBUG - 2010-06-23 07:41:39 --> Config Class Initialized
DEBUG - 2010-06-23 07:41:39 --> Hooks Class Initialized
DEBUG - 2010-06-23 07:41:39 --> URI Class Initialized
DEBUG - 2010-06-23 07:41:39 --> No URI present. Default controller set.
DEBUG - 2010-06-23 07:41:39 --> Router Class Initialized
DEBUG - 2010-06-23 07:41:39 --> Output Class Initialized
DEBUG - 2010-06-23 07:41:39 --> Input Class Initialized
DEBUG - 2010-06-23 07:41:39 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 07:41:39 --> Language Class Initialized
DEBUG - 2010-06-23 07:41:39 --> Loader Class Initialized
DEBUG - 2010-06-23 07:41:39 --> Helper loaded: object_helper
DEBUG - 2010-06-23 07:41:39 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 07:41:39 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:41:39 --> Session Class Initialized
DEBUG - 2010-06-23 07:41:39 --> Helper loaded: string_helper
DEBUG - 2010-06-23 07:41:39 --> Session routines successfully run
DEBUG - 2010-06-23 07:41:39 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:41:39 --> Controller Class Initialized
DEBUG - 2010-06-23 07:41:39 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 07:41:39 --> User Agent Class Initialized
ERROR - 2010-06-23 07:41:39 --> Severity: Notice  --> Undefined property: Welcome::$user_agent D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\welcome.php 16
DEBUG - 2010-06-23 07:41:54 --> Config Class Initialized
DEBUG - 2010-06-23 07:41:54 --> Hooks Class Initialized
DEBUG - 2010-06-23 07:41:54 --> URI Class Initialized
DEBUG - 2010-06-23 07:41:54 --> No URI present. Default controller set.
DEBUG - 2010-06-23 07:41:54 --> Router Class Initialized
DEBUG - 2010-06-23 07:41:54 --> Output Class Initialized
DEBUG - 2010-06-23 07:41:54 --> Input Class Initialized
DEBUG - 2010-06-23 07:41:54 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 07:41:54 --> Language Class Initialized
DEBUG - 2010-06-23 07:41:54 --> Loader Class Initialized
DEBUG - 2010-06-23 07:41:54 --> Helper loaded: object_helper
DEBUG - 2010-06-23 07:41:54 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 07:41:54 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:41:54 --> Session Class Initialized
DEBUG - 2010-06-23 07:41:54 --> Helper loaded: string_helper
DEBUG - 2010-06-23 07:41:54 --> Session routines successfully run
DEBUG - 2010-06-23 07:41:54 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:41:54 --> Controller Class Initialized
DEBUG - 2010-06-23 07:41:54 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 07:41:54 --> User Agent Class Initialized
ERROR - 2010-06-23 07:41:54 --> Severity: Notice  --> Undefined property: Welcome::$user_agent D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\welcome.php 16
DEBUG - 2010-06-23 07:42:28 --> Config Class Initialized
DEBUG - 2010-06-23 07:42:28 --> Hooks Class Initialized
DEBUG - 2010-06-23 07:42:28 --> URI Class Initialized
DEBUG - 2010-06-23 07:42:28 --> No URI present. Default controller set.
DEBUG - 2010-06-23 07:42:28 --> Router Class Initialized
DEBUG - 2010-06-23 07:42:28 --> Output Class Initialized
DEBUG - 2010-06-23 07:42:28 --> Input Class Initialized
DEBUG - 2010-06-23 07:42:28 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 07:42:28 --> Language Class Initialized
DEBUG - 2010-06-23 07:42:28 --> Loader Class Initialized
DEBUG - 2010-06-23 07:42:28 --> Helper loaded: object_helper
DEBUG - 2010-06-23 07:42:28 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 07:42:28 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:42:28 --> Session Class Initialized
DEBUG - 2010-06-23 07:42:28 --> Helper loaded: string_helper
DEBUG - 2010-06-23 07:42:28 --> Session routines successfully run
DEBUG - 2010-06-23 07:42:28 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:42:28 --> Controller Class Initialized
DEBUG - 2010-06-23 07:42:28 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 07:42:28 --> User Agent Class Initialized
DEBUG - 2010-06-23 07:42:28 --> Final output sent to browser
DEBUG - 2010-06-23 07:42:28 --> Total execution time: 0.2331
DEBUG - 2010-06-23 07:42:32 --> Config Class Initialized
DEBUG - 2010-06-23 07:42:32 --> Hooks Class Initialized
DEBUG - 2010-06-23 07:42:32 --> URI Class Initialized
DEBUG - 2010-06-23 07:42:32 --> No URI present. Default controller set.
DEBUG - 2010-06-23 07:42:32 --> Router Class Initialized
DEBUG - 2010-06-23 07:42:32 --> Output Class Initialized
DEBUG - 2010-06-23 07:42:32 --> Input Class Initialized
DEBUG - 2010-06-23 07:42:32 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 07:42:32 --> Language Class Initialized
DEBUG - 2010-06-23 07:42:32 --> Loader Class Initialized
DEBUG - 2010-06-23 07:42:32 --> Helper loaded: object_helper
DEBUG - 2010-06-23 07:42:32 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 07:42:32 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:42:32 --> Session Class Initialized
DEBUG - 2010-06-23 07:42:32 --> Helper loaded: string_helper
DEBUG - 2010-06-23 07:42:32 --> Session routines successfully run
DEBUG - 2010-06-23 07:42:32 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:42:32 --> Controller Class Initialized
DEBUG - 2010-06-23 07:42:32 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 07:42:32 --> User Agent Class Initialized
DEBUG - 2010-06-23 07:42:32 --> Final output sent to browser
DEBUG - 2010-06-23 07:42:32 --> Total execution time: 0.2393
DEBUG - 2010-06-23 07:43:23 --> Config Class Initialized
DEBUG - 2010-06-23 07:43:23 --> Hooks Class Initialized
DEBUG - 2010-06-23 07:43:23 --> URI Class Initialized
DEBUG - 2010-06-23 07:43:23 --> No URI present. Default controller set.
DEBUG - 2010-06-23 07:43:23 --> Router Class Initialized
DEBUG - 2010-06-23 07:43:23 --> Output Class Initialized
DEBUG - 2010-06-23 07:43:23 --> Input Class Initialized
DEBUG - 2010-06-23 07:43:23 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 07:43:23 --> Language Class Initialized
DEBUG - 2010-06-23 07:43:23 --> Loader Class Initialized
DEBUG - 2010-06-23 07:43:23 --> Helper loaded: object_helper
DEBUG - 2010-06-23 07:43:23 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 07:43:23 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:43:23 --> Session Class Initialized
DEBUG - 2010-06-23 07:43:23 --> Helper loaded: string_helper
DEBUG - 2010-06-23 07:43:23 --> Session routines successfully run
DEBUG - 2010-06-23 07:43:23 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:43:23 --> Controller Class Initialized
DEBUG - 2010-06-23 07:43:23 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 07:43:23 --> User Agent Class Initialized
DEBUG - 2010-06-23 07:43:23 --> Final output sent to browser
DEBUG - 2010-06-23 07:43:23 --> Total execution time: 0.2521
DEBUG - 2010-06-23 07:43:34 --> Config Class Initialized
DEBUG - 2010-06-23 07:43:35 --> Hooks Class Initialized
DEBUG - 2010-06-23 07:43:35 --> URI Class Initialized
DEBUG - 2010-06-23 07:43:35 --> No URI present. Default controller set.
DEBUG - 2010-06-23 07:43:35 --> Router Class Initialized
DEBUG - 2010-06-23 07:43:35 --> Output Class Initialized
DEBUG - 2010-06-23 07:43:35 --> Input Class Initialized
DEBUG - 2010-06-23 07:43:35 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 07:43:35 --> Language Class Initialized
DEBUG - 2010-06-23 07:43:35 --> Loader Class Initialized
DEBUG - 2010-06-23 07:43:35 --> Helper loaded: object_helper
DEBUG - 2010-06-23 07:43:35 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 07:43:35 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:43:35 --> Session Class Initialized
DEBUG - 2010-06-23 07:43:35 --> Helper loaded: string_helper
DEBUG - 2010-06-23 07:43:35 --> Session routines successfully run
DEBUG - 2010-06-23 07:43:35 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:43:35 --> Controller Class Initialized
DEBUG - 2010-06-23 07:43:35 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 07:43:35 --> User Agent Class Initialized
DEBUG - 2010-06-23 07:43:35 --> Final output sent to browser
DEBUG - 2010-06-23 07:43:35 --> Total execution time: 0.2630
DEBUG - 2010-06-23 07:43:39 --> Config Class Initialized
DEBUG - 2010-06-23 07:43:39 --> Hooks Class Initialized
DEBUG - 2010-06-23 07:43:39 --> URI Class Initialized
DEBUG - 2010-06-23 07:43:39 --> No URI present. Default controller set.
DEBUG - 2010-06-23 07:43:39 --> Router Class Initialized
DEBUG - 2010-06-23 07:43:39 --> Output Class Initialized
DEBUG - 2010-06-23 07:43:39 --> Input Class Initialized
DEBUG - 2010-06-23 07:43:39 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 07:43:39 --> Language Class Initialized
DEBUG - 2010-06-23 07:43:39 --> Loader Class Initialized
DEBUG - 2010-06-23 07:43:39 --> Helper loaded: object_helper
DEBUG - 2010-06-23 07:43:39 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 07:43:39 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:43:39 --> Session Class Initialized
DEBUG - 2010-06-23 07:43:39 --> Helper loaded: string_helper
DEBUG - 2010-06-23 07:43:39 --> Session routines successfully run
DEBUG - 2010-06-23 07:43:39 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:43:39 --> Controller Class Initialized
DEBUG - 2010-06-23 07:43:39 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 07:43:39 --> User Agent Class Initialized
DEBUG - 2010-06-23 07:43:39 --> Final output sent to browser
DEBUG - 2010-06-23 07:43:39 --> Total execution time: 0.2743
DEBUG - 2010-06-23 07:43:44 --> Config Class Initialized
DEBUG - 2010-06-23 07:43:44 --> Hooks Class Initialized
DEBUG - 2010-06-23 07:43:44 --> URI Class Initialized
DEBUG - 2010-06-23 07:43:44 --> No URI present. Default controller set.
DEBUG - 2010-06-23 07:43:44 --> Router Class Initialized
DEBUG - 2010-06-23 07:43:44 --> Output Class Initialized
DEBUG - 2010-06-23 07:43:44 --> Input Class Initialized
DEBUG - 2010-06-23 07:43:44 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 07:43:44 --> Language Class Initialized
DEBUG - 2010-06-23 07:43:44 --> Loader Class Initialized
DEBUG - 2010-06-23 07:43:44 --> Helper loaded: object_helper
DEBUG - 2010-06-23 07:43:44 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 07:43:44 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:43:44 --> Session Class Initialized
DEBUG - 2010-06-23 07:43:44 --> Helper loaded: string_helper
DEBUG - 2010-06-23 07:43:44 --> Session routines successfully run
DEBUG - 2010-06-23 07:43:44 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:43:44 --> Controller Class Initialized
DEBUG - 2010-06-23 07:43:44 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 07:43:44 --> User Agent Class Initialized
DEBUG - 2010-06-23 07:43:44 --> Final output sent to browser
DEBUG - 2010-06-23 07:43:44 --> Total execution time: 0.2810
DEBUG - 2010-06-23 07:43:49 --> Config Class Initialized
DEBUG - 2010-06-23 07:43:49 --> Hooks Class Initialized
DEBUG - 2010-06-23 07:43:49 --> URI Class Initialized
DEBUG - 2010-06-23 07:43:49 --> No URI present. Default controller set.
DEBUG - 2010-06-23 07:43:49 --> Router Class Initialized
DEBUG - 2010-06-23 07:43:49 --> Output Class Initialized
DEBUG - 2010-06-23 07:43:49 --> Input Class Initialized
DEBUG - 2010-06-23 07:43:49 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 07:43:49 --> Language Class Initialized
DEBUG - 2010-06-23 07:43:49 --> Loader Class Initialized
DEBUG - 2010-06-23 07:43:49 --> Helper loaded: object_helper
DEBUG - 2010-06-23 07:43:49 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 07:43:49 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:43:49 --> Session Class Initialized
DEBUG - 2010-06-23 07:43:49 --> Helper loaded: string_helper
DEBUG - 2010-06-23 07:43:49 --> Session routines successfully run
DEBUG - 2010-06-23 07:43:49 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:43:49 --> Controller Class Initialized
DEBUG - 2010-06-23 07:43:49 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 07:43:49 --> User Agent Class Initialized
DEBUG - 2010-06-23 07:43:49 --> Final output sent to browser
DEBUG - 2010-06-23 07:43:49 --> Total execution time: 0.2996
DEBUG - 2010-06-23 07:51:52 --> Config Class Initialized
DEBUG - 2010-06-23 07:51:52 --> Hooks Class Initialized
DEBUG - 2010-06-23 07:51:52 --> URI Class Initialized
DEBUG - 2010-06-23 07:51:52 --> No URI present. Default controller set.
DEBUG - 2010-06-23 07:51:52 --> Router Class Initialized
DEBUG - 2010-06-23 07:51:52 --> Output Class Initialized
DEBUG - 2010-06-23 07:51:52 --> Input Class Initialized
DEBUG - 2010-06-23 07:51:52 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 07:51:52 --> Language Class Initialized
DEBUG - 2010-06-23 07:51:52 --> Loader Class Initialized
DEBUG - 2010-06-23 07:51:52 --> Helper loaded: object_helper
DEBUG - 2010-06-23 07:51:52 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 07:51:52 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:51:52 --> Session Class Initialized
DEBUG - 2010-06-23 07:51:52 --> Helper loaded: string_helper
DEBUG - 2010-06-23 07:51:52 --> Session routines successfully run
DEBUG - 2010-06-23 07:51:52 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:51:52 --> Controller Class Initialized
DEBUG - 2010-06-23 07:51:52 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 07:51:52 --> User Agent Class Initialized
ERROR - 2010-06-23 07:51:52 --> Severity: Notice  --> Undefined property: MY_User_agent::$config D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\MY_User_agent.php 37
DEBUG - 2010-06-23 07:52:27 --> Config Class Initialized
DEBUG - 2010-06-23 07:52:27 --> Hooks Class Initialized
DEBUG - 2010-06-23 07:52:27 --> URI Class Initialized
DEBUG - 2010-06-23 07:52:27 --> No URI present. Default controller set.
DEBUG - 2010-06-23 07:52:27 --> Router Class Initialized
DEBUG - 2010-06-23 07:52:27 --> Output Class Initialized
DEBUG - 2010-06-23 07:52:27 --> Input Class Initialized
DEBUG - 2010-06-23 07:52:27 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 07:52:27 --> Language Class Initialized
DEBUG - 2010-06-23 07:52:27 --> Loader Class Initialized
DEBUG - 2010-06-23 07:52:27 --> Helper loaded: object_helper
DEBUG - 2010-06-23 07:52:27 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 07:52:27 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:52:27 --> Session Class Initialized
DEBUG - 2010-06-23 07:52:27 --> Helper loaded: string_helper
DEBUG - 2010-06-23 07:52:27 --> Session routines successfully run
DEBUG - 2010-06-23 07:52:27 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:52:27 --> Controller Class Initialized
DEBUG - 2010-06-23 07:52:27 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 07:52:27 --> User Agent Class Initialized
ERROR - 2010-06-23 07:52:27 --> Severity: Notice  --> Undefined property: MY_User_agent::$config D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\MY_User_agent.php 37
DEBUG - 2010-06-23 07:54:31 --> Config Class Initialized
DEBUG - 2010-06-23 07:54:31 --> Hooks Class Initialized
DEBUG - 2010-06-23 07:54:31 --> URI Class Initialized
DEBUG - 2010-06-23 07:54:31 --> No URI present. Default controller set.
DEBUG - 2010-06-23 07:54:31 --> Router Class Initialized
DEBUG - 2010-06-23 07:54:31 --> Output Class Initialized
DEBUG - 2010-06-23 07:54:31 --> Input Class Initialized
DEBUG - 2010-06-23 07:54:31 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 07:54:31 --> Language Class Initialized
DEBUG - 2010-06-23 07:54:31 --> Loader Class Initialized
DEBUG - 2010-06-23 07:54:31 --> Helper loaded: object_helper
DEBUG - 2010-06-23 07:54:31 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 07:54:31 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:54:31 --> Session Class Initialized
DEBUG - 2010-06-23 07:54:31 --> Helper loaded: string_helper
DEBUG - 2010-06-23 07:54:31 --> Session routines successfully run
DEBUG - 2010-06-23 07:54:31 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:54:31 --> Controller Class Initialized
DEBUG - 2010-06-23 07:54:31 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 07:54:31 --> User Agent Class Initialized
ERROR - 2010-06-23 07:54:31 --> Severity: Notice  --> Undefined variable: CI D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\MY_User_agent.php 39
ERROR - 2010-06-23 07:54:31 --> Severity: Notice  --> Object of class Welcome could not be converted to int D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\MY_User_agent.php 39
ERROR - 2010-06-23 07:54:31 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\MY_User_agent.php 40
DEBUG - 2010-06-23 07:55:17 --> Config Class Initialized
DEBUG - 2010-06-23 07:55:17 --> Hooks Class Initialized
DEBUG - 2010-06-23 07:55:17 --> URI Class Initialized
DEBUG - 2010-06-23 07:55:17 --> No URI present. Default controller set.
DEBUG - 2010-06-23 07:55:17 --> Router Class Initialized
DEBUG - 2010-06-23 07:55:17 --> Output Class Initialized
DEBUG - 2010-06-23 07:55:17 --> Input Class Initialized
DEBUG - 2010-06-23 07:55:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 07:55:17 --> Language Class Initialized
DEBUG - 2010-06-23 07:55:17 --> Loader Class Initialized
DEBUG - 2010-06-23 07:55:17 --> Helper loaded: object_helper
DEBUG - 2010-06-23 07:55:17 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 07:55:17 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:55:17 --> Session Class Initialized
DEBUG - 2010-06-23 07:55:17 --> Helper loaded: string_helper
DEBUG - 2010-06-23 07:55:17 --> Session routines successfully run
DEBUG - 2010-06-23 07:55:17 --> Helper loaded: context_helper
DEBUG - 2010-06-23 07:55:17 --> Controller Class Initialized
DEBUG - 2010-06-23 07:55:17 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 07:55:17 --> User Agent Class Initialized
DEBUG - 2010-06-23 07:55:17 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 07:55:17 --> Final output sent to browser
DEBUG - 2010-06-23 07:55:17 --> Total execution time: 0.3408
DEBUG - 2010-06-23 08:01:36 --> Config Class Initialized
DEBUG - 2010-06-23 08:01:36 --> Hooks Class Initialized
DEBUG - 2010-06-23 08:01:36 --> URI Class Initialized
DEBUG - 2010-06-23 08:01:36 --> No URI present. Default controller set.
DEBUG - 2010-06-23 08:01:36 --> Router Class Initialized
DEBUG - 2010-06-23 08:01:36 --> Output Class Initialized
DEBUG - 2010-06-23 08:01:36 --> Input Class Initialized
DEBUG - 2010-06-23 08:01:37 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 08:01:37 --> Language Class Initialized
DEBUG - 2010-06-23 08:01:37 --> Loader Class Initialized
DEBUG - 2010-06-23 08:01:37 --> Helper loaded: object_helper
DEBUG - 2010-06-23 08:01:37 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 08:01:37 --> Helper loaded: context_helper
DEBUG - 2010-06-23 08:01:37 --> Session Class Initialized
DEBUG - 2010-06-23 08:01:37 --> Helper loaded: string_helper
DEBUG - 2010-06-23 08:01:37 --> Session routines successfully run
DEBUG - 2010-06-23 08:01:37 --> Helper loaded: context_helper
DEBUG - 2010-06-23 08:01:37 --> Controller Class Initialized
DEBUG - 2010-06-23 08:01:37 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 08:01:37 --> User Agent Class Initialized
DEBUG - 2010-06-23 08:01:37 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 08:01:37 --> Final output sent to browser
DEBUG - 2010-06-23 08:01:37 --> Total execution time: 0.3690
DEBUG - 2010-06-23 08:01:46 --> Config Class Initialized
DEBUG - 2010-06-23 08:01:46 --> Hooks Class Initialized
DEBUG - 2010-06-23 08:01:46 --> URI Class Initialized
DEBUG - 2010-06-23 08:01:46 --> No URI present. Default controller set.
DEBUG - 2010-06-23 08:01:47 --> Router Class Initialized
DEBUG - 2010-06-23 08:01:47 --> Output Class Initialized
DEBUG - 2010-06-23 08:01:47 --> Input Class Initialized
DEBUG - 2010-06-23 08:01:47 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 08:01:47 --> Language Class Initialized
DEBUG - 2010-06-23 08:01:47 --> Loader Class Initialized
DEBUG - 2010-06-23 08:01:47 --> Helper loaded: object_helper
DEBUG - 2010-06-23 08:01:47 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 08:01:47 --> Helper loaded: context_helper
DEBUG - 2010-06-23 08:01:47 --> Session Class Initialized
DEBUG - 2010-06-23 08:01:47 --> Helper loaded: string_helper
DEBUG - 2010-06-23 08:01:47 --> Session routines successfully run
DEBUG - 2010-06-23 08:01:47 --> Helper loaded: context_helper
DEBUG - 2010-06-23 08:01:47 --> Controller Class Initialized
DEBUG - 2010-06-23 08:01:47 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 08:01:47 --> User Agent Class Initialized
DEBUG - 2010-06-23 08:01:47 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 08:01:47 --> Final output sent to browser
DEBUG - 2010-06-23 08:01:47 --> Total execution time: 0.3721
DEBUG - 2010-06-23 08:01:59 --> Config Class Initialized
DEBUG - 2010-06-23 08:01:59 --> Hooks Class Initialized
DEBUG - 2010-06-23 08:01:59 --> URI Class Initialized
DEBUG - 2010-06-23 08:01:59 --> No URI present. Default controller set.
DEBUG - 2010-06-23 08:01:59 --> Router Class Initialized
DEBUG - 2010-06-23 08:01:59 --> Output Class Initialized
DEBUG - 2010-06-23 08:01:59 --> Input Class Initialized
DEBUG - 2010-06-23 08:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 08:01:59 --> Language Class Initialized
DEBUG - 2010-06-23 08:01:59 --> Loader Class Initialized
DEBUG - 2010-06-23 08:01:59 --> Helper loaded: object_helper
DEBUG - 2010-06-23 08:01:59 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 08:01:59 --> Helper loaded: context_helper
DEBUG - 2010-06-23 08:01:59 --> Session Class Initialized
DEBUG - 2010-06-23 08:01:59 --> Helper loaded: string_helper
DEBUG - 2010-06-23 08:01:59 --> Session routines successfully run
DEBUG - 2010-06-23 08:01:59 --> Helper loaded: context_helper
DEBUG - 2010-06-23 08:01:59 --> Controller Class Initialized
DEBUG - 2010-06-23 08:01:59 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 08:01:59 --> User Agent Class Initialized
DEBUG - 2010-06-23 08:01:59 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 08:01:59 --> Final output sent to browser
DEBUG - 2010-06-23 08:01:59 --> Total execution time: 0.4352
DEBUG - 2010-06-23 08:02:17 --> Config Class Initialized
DEBUG - 2010-06-23 08:02:17 --> Hooks Class Initialized
DEBUG - 2010-06-23 08:02:17 --> URI Class Initialized
DEBUG - 2010-06-23 08:02:17 --> No URI present. Default controller set.
DEBUG - 2010-06-23 08:02:17 --> Router Class Initialized
DEBUG - 2010-06-23 08:02:17 --> Output Class Initialized
DEBUG - 2010-06-23 08:02:17 --> Input Class Initialized
DEBUG - 2010-06-23 08:02:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 08:02:17 --> Language Class Initialized
DEBUG - 2010-06-23 08:02:17 --> Loader Class Initialized
DEBUG - 2010-06-23 08:02:18 --> Helper loaded: object_helper
DEBUG - 2010-06-23 08:02:18 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 08:02:18 --> Helper loaded: context_helper
DEBUG - 2010-06-23 08:02:18 --> Session Class Initialized
DEBUG - 2010-06-23 08:02:18 --> Helper loaded: string_helper
DEBUG - 2010-06-23 08:02:18 --> Session routines successfully run
DEBUG - 2010-06-23 08:02:18 --> Helper loaded: context_helper
DEBUG - 2010-06-23 08:02:18 --> Controller Class Initialized
DEBUG - 2010-06-23 08:02:18 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 08:02:18 --> User Agent Class Initialized
DEBUG - 2010-06-23 08:02:18 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 08:02:18 --> Final output sent to browser
DEBUG - 2010-06-23 08:02:18 --> Total execution time: 0.4083
DEBUG - 2010-06-23 08:02:33 --> Config Class Initialized
DEBUG - 2010-06-23 08:02:33 --> Hooks Class Initialized
DEBUG - 2010-06-23 08:02:33 --> URI Class Initialized
DEBUG - 2010-06-23 08:02:33 --> No URI present. Default controller set.
DEBUG - 2010-06-23 08:02:33 --> Router Class Initialized
DEBUG - 2010-06-23 08:02:33 --> Output Class Initialized
DEBUG - 2010-06-23 08:02:33 --> Input Class Initialized
DEBUG - 2010-06-23 08:02:33 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 08:02:33 --> Language Class Initialized
DEBUG - 2010-06-23 08:02:33 --> Loader Class Initialized
DEBUG - 2010-06-23 08:02:33 --> Helper loaded: object_helper
DEBUG - 2010-06-23 08:02:33 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 08:02:33 --> Helper loaded: context_helper
DEBUG - 2010-06-23 08:02:33 --> Session Class Initialized
DEBUG - 2010-06-23 08:02:33 --> Helper loaded: string_helper
DEBUG - 2010-06-23 08:02:33 --> Session routines successfully run
DEBUG - 2010-06-23 08:02:33 --> Helper loaded: context_helper
DEBUG - 2010-06-23 08:02:33 --> Controller Class Initialized
DEBUG - 2010-06-23 08:02:33 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 08:02:33 --> User Agent Class Initialized
DEBUG - 2010-06-23 08:02:33 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 08:02:33 --> Final output sent to browser
DEBUG - 2010-06-23 08:02:33 --> Total execution time: 0.4024
DEBUG - 2010-06-23 09:34:23 --> Config Class Initialized
DEBUG - 2010-06-23 09:34:23 --> Hooks Class Initialized
DEBUG - 2010-06-23 09:34:23 --> URI Class Initialized
DEBUG - 2010-06-23 09:34:23 --> Router Class Initialized
DEBUG - 2010-06-23 09:34:23 --> Output Class Initialized
DEBUG - 2010-06-23 09:34:23 --> Input Class Initialized
DEBUG - 2010-06-23 09:34:23 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 09:34:23 --> Language Class Initialized
DEBUG - 2010-06-23 09:34:23 --> Loader Class Initialized
DEBUG - 2010-06-23 09:34:23 --> Helper loaded: object_helper
DEBUG - 2010-06-23 09:34:23 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 09:34:23 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:34:23 --> Session Class Initialized
DEBUG - 2010-06-23 09:34:23 --> Helper loaded: string_helper
DEBUG - 2010-06-23 09:34:23 --> Session routines successfully run
DEBUG - 2010-06-23 09:34:23 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:34:23 --> Controller Class Initialized
DEBUG - 2010-06-23 09:34:23 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 09:34:23 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 09:34:23 --> Database Driver Class Initialized
DEBUG - 2010-06-23 09:34:23 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 09:34:23 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 09:34:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:35:29 --> Config Class Initialized
DEBUG - 2010-06-23 09:35:29 --> Hooks Class Initialized
DEBUG - 2010-06-23 09:35:29 --> URI Class Initialized
DEBUG - 2010-06-23 09:35:29 --> Router Class Initialized
DEBUG - 2010-06-23 09:35:29 --> Output Class Initialized
DEBUG - 2010-06-23 09:35:29 --> Input Class Initialized
DEBUG - 2010-06-23 09:35:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 09:35:29 --> Language Class Initialized
DEBUG - 2010-06-23 09:35:29 --> Loader Class Initialized
DEBUG - 2010-06-23 09:35:29 --> Helper loaded: object_helper
DEBUG - 2010-06-23 09:35:29 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 09:35:29 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:35:29 --> Session Class Initialized
DEBUG - 2010-06-23 09:35:29 --> Helper loaded: string_helper
DEBUG - 2010-06-23 09:35:29 --> Session routines successfully run
DEBUG - 2010-06-23 09:35:29 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:35:29 --> Controller Class Initialized
DEBUG - 2010-06-23 09:35:29 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 09:35:29 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 09:35:29 --> Database Driver Class Initialized
DEBUG - 2010-06-23 09:35:29 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 09:35:29 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 09:35:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:36:02 --> Config Class Initialized
DEBUG - 2010-06-23 09:36:02 --> Hooks Class Initialized
DEBUG - 2010-06-23 09:36:02 --> URI Class Initialized
DEBUG - 2010-06-23 09:36:02 --> Router Class Initialized
DEBUG - 2010-06-23 09:36:02 --> Output Class Initialized
DEBUG - 2010-06-23 09:36:02 --> Input Class Initialized
DEBUG - 2010-06-23 09:36:02 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 09:36:02 --> Language Class Initialized
DEBUG - 2010-06-23 09:36:02 --> Loader Class Initialized
DEBUG - 2010-06-23 09:36:02 --> Helper loaded: object_helper
DEBUG - 2010-06-23 09:36:02 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 09:36:02 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:36:02 --> Session Class Initialized
DEBUG - 2010-06-23 09:36:02 --> Helper loaded: string_helper
DEBUG - 2010-06-23 09:36:02 --> Session routines successfully run
DEBUG - 2010-06-23 09:36:02 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:36:02 --> Controller Class Initialized
DEBUG - 2010-06-23 09:36:02 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 09:36:02 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 09:36:02 --> Database Driver Class Initialized
DEBUG - 2010-06-23 09:36:02 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 09:36:02 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 09:36:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:36:18 --> Config Class Initialized
DEBUG - 2010-06-23 09:36:18 --> Hooks Class Initialized
DEBUG - 2010-06-23 09:36:18 --> URI Class Initialized
DEBUG - 2010-06-23 09:36:18 --> Router Class Initialized
DEBUG - 2010-06-23 09:36:18 --> Output Class Initialized
DEBUG - 2010-06-23 09:36:18 --> Input Class Initialized
DEBUG - 2010-06-23 09:36:18 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 09:36:18 --> Language Class Initialized
DEBUG - 2010-06-23 09:36:18 --> Loader Class Initialized
DEBUG - 2010-06-23 09:36:18 --> Helper loaded: object_helper
DEBUG - 2010-06-23 09:36:18 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 09:36:18 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:36:18 --> Session Class Initialized
DEBUG - 2010-06-23 09:36:18 --> Helper loaded: string_helper
DEBUG - 2010-06-23 09:36:18 --> Session routines successfully run
DEBUG - 2010-06-23 09:36:18 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:36:18 --> Controller Class Initialized
DEBUG - 2010-06-23 09:36:18 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 09:36:18 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 09:36:18 --> Database Driver Class Initialized
DEBUG - 2010-06-23 09:36:18 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 09:36:18 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 09:36:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:36:34 --> Config Class Initialized
DEBUG - 2010-06-23 09:36:34 --> Hooks Class Initialized
DEBUG - 2010-06-23 09:36:34 --> URI Class Initialized
DEBUG - 2010-06-23 09:36:34 --> Router Class Initialized
DEBUG - 2010-06-23 09:36:34 --> Output Class Initialized
DEBUG - 2010-06-23 09:36:34 --> Input Class Initialized
DEBUG - 2010-06-23 09:36:34 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 09:36:34 --> Language Class Initialized
DEBUG - 2010-06-23 09:36:34 --> Loader Class Initialized
DEBUG - 2010-06-23 09:36:34 --> Helper loaded: object_helper
DEBUG - 2010-06-23 09:36:34 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 09:36:34 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:36:34 --> Session Class Initialized
DEBUG - 2010-06-23 09:36:34 --> Helper loaded: string_helper
DEBUG - 2010-06-23 09:36:34 --> Session routines successfully run
DEBUG - 2010-06-23 09:36:34 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:36:34 --> Controller Class Initialized
DEBUG - 2010-06-23 09:36:34 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 09:36:34 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 09:36:34 --> Database Driver Class Initialized
DEBUG - 2010-06-23 09:36:34 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 09:36:34 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 09:36:34 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 09:36:34 --> Severity: Notice  --> Undefined variable: doamin D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 188
DEBUG - 2010-06-23 09:36:46 --> Config Class Initialized
DEBUG - 2010-06-23 09:36:46 --> Hooks Class Initialized
DEBUG - 2010-06-23 09:36:46 --> URI Class Initialized
DEBUG - 2010-06-23 09:36:46 --> Router Class Initialized
DEBUG - 2010-06-23 09:36:46 --> Output Class Initialized
DEBUG - 2010-06-23 09:36:46 --> Input Class Initialized
DEBUG - 2010-06-23 09:36:46 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 09:36:46 --> Language Class Initialized
DEBUG - 2010-06-23 09:36:46 --> Loader Class Initialized
DEBUG - 2010-06-23 09:36:46 --> Helper loaded: object_helper
DEBUG - 2010-06-23 09:36:46 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 09:36:46 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:36:46 --> Session Class Initialized
DEBUG - 2010-06-23 09:36:46 --> Helper loaded: string_helper
DEBUG - 2010-06-23 09:36:46 --> Session routines successfully run
DEBUG - 2010-06-23 09:36:46 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:36:46 --> Controller Class Initialized
DEBUG - 2010-06-23 09:36:46 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 09:36:46 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 09:36:46 --> Database Driver Class Initialized
DEBUG - 2010-06-23 09:36:46 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 09:36:46 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 09:36:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:37:15 --> Config Class Initialized
DEBUG - 2010-06-23 09:37:15 --> Hooks Class Initialized
DEBUG - 2010-06-23 09:37:15 --> URI Class Initialized
DEBUG - 2010-06-23 09:37:15 --> Router Class Initialized
DEBUG - 2010-06-23 09:37:15 --> Output Class Initialized
DEBUG - 2010-06-23 09:37:15 --> Input Class Initialized
DEBUG - 2010-06-23 09:37:16 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 09:37:16 --> Language Class Initialized
DEBUG - 2010-06-23 09:37:16 --> Loader Class Initialized
DEBUG - 2010-06-23 09:37:16 --> Helper loaded: object_helper
DEBUG - 2010-06-23 09:37:16 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 09:37:16 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:37:16 --> Session Class Initialized
DEBUG - 2010-06-23 09:37:16 --> Helper loaded: string_helper
DEBUG - 2010-06-23 09:37:16 --> Session routines successfully run
DEBUG - 2010-06-23 09:37:16 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:37:16 --> Controller Class Initialized
DEBUG - 2010-06-23 09:37:16 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 09:37:16 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 09:37:16 --> Database Driver Class Initialized
DEBUG - 2010-06-23 09:37:16 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 09:37:16 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 09:37:16 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 09:37:16 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column user.deleted does not exist
LINE 4: WHERE &quot;user&quot;.&quot;deleted&quot; = 0
              ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-23 09:37:16 --> DB Transaction Failure
ERROR - 2010-06-23 09:37:16 --> Query error: ERROR:  column user.deleted does not exist
LINE 4: WHERE "user"."deleted" = 0
              ^
DEBUG - 2010-06-23 09:37:16 --> Language file loaded: language/zh-TW/db_lang.php
DEBUG - 2010-06-23 09:38:39 --> Config Class Initialized
DEBUG - 2010-06-23 09:38:39 --> Hooks Class Initialized
DEBUG - 2010-06-23 09:38:39 --> URI Class Initialized
DEBUG - 2010-06-23 09:38:39 --> Router Class Initialized
DEBUG - 2010-06-23 09:38:40 --> Output Class Initialized
DEBUG - 2010-06-23 09:38:40 --> Input Class Initialized
DEBUG - 2010-06-23 09:38:40 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 09:38:40 --> Language Class Initialized
DEBUG - 2010-06-23 09:38:40 --> Loader Class Initialized
DEBUG - 2010-06-23 09:38:40 --> Helper loaded: object_helper
DEBUG - 2010-06-23 09:38:40 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 09:38:40 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:38:40 --> Session Class Initialized
DEBUG - 2010-06-23 09:38:40 --> Helper loaded: string_helper
DEBUG - 2010-06-23 09:38:40 --> Session routines successfully run
DEBUG - 2010-06-23 09:38:40 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:38:40 --> Controller Class Initialized
DEBUG - 2010-06-23 09:38:40 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 09:38:40 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 09:38:40 --> Database Driver Class Initialized
DEBUG - 2010-06-23 09:38:40 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 09:38:40 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 09:38:40 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 09:38:40 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  operator does not exist: boolean = integer
LINE 4: WHERE &quot;user&quot;.&quot;deleted&quot; = 0
                               ^
HINT:  No operator matches the given name and argument type(s). You might need to add explicit type casts. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-23 09:38:40 --> DB Transaction Failure
ERROR - 2010-06-23 09:38:40 --> Query error: ERROR:  operator does not exist: boolean = integer
LINE 4: WHERE "user"."deleted" = 0
                               ^
HINT:  No operator matches the given name and argument type(s). You might need to add explicit type casts.
DEBUG - 2010-06-23 09:38:40 --> Language file loaded: language/zh-TW/db_lang.php
DEBUG - 2010-06-23 09:39:15 --> Config Class Initialized
DEBUG - 2010-06-23 09:39:15 --> Hooks Class Initialized
DEBUG - 2010-06-23 09:39:15 --> URI Class Initialized
DEBUG - 2010-06-23 09:39:15 --> Router Class Initialized
DEBUG - 2010-06-23 09:39:15 --> Output Class Initialized
DEBUG - 2010-06-23 09:39:15 --> Input Class Initialized
DEBUG - 2010-06-23 09:39:15 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 09:39:15 --> Language Class Initialized
DEBUG - 2010-06-23 09:39:15 --> Loader Class Initialized
DEBUG - 2010-06-23 09:39:15 --> Helper loaded: object_helper
DEBUG - 2010-06-23 09:39:15 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 09:39:15 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:39:15 --> Session Class Initialized
DEBUG - 2010-06-23 09:39:15 --> Helper loaded: string_helper
DEBUG - 2010-06-23 09:39:15 --> Session routines successfully run
DEBUG - 2010-06-23 09:39:15 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:39:15 --> Controller Class Initialized
DEBUG - 2010-06-23 09:39:15 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 09:39:15 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 09:39:15 --> Database Driver Class Initialized
DEBUG - 2010-06-23 09:39:15 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 09:39:15 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 09:39:15 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 09:39:15 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  operator does not exist: boolean = integer
LINE 4: WHERE &quot;user&quot;.&quot;deleted&quot; = 0
                               ^
HINT:  No operator matches the given name and argument type(s). You might need to add explicit type casts. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-23 09:39:15 --> DB Transaction Failure
ERROR - 2010-06-23 09:39:15 --> Query error: ERROR:  operator does not exist: boolean = integer
LINE 4: WHERE "user"."deleted" = 0
                               ^
HINT:  No operator matches the given name and argument type(s). You might need to add explicit type casts.
DEBUG - 2010-06-23 09:39:16 --> Language file loaded: language/zh-TW/db_lang.php
DEBUG - 2010-06-23 09:39:32 --> Config Class Initialized
DEBUG - 2010-06-23 09:39:32 --> Hooks Class Initialized
DEBUG - 2010-06-23 09:39:32 --> URI Class Initialized
DEBUG - 2010-06-23 09:39:32 --> Router Class Initialized
DEBUG - 2010-06-23 09:39:32 --> Output Class Initialized
DEBUG - 2010-06-23 09:39:32 --> Input Class Initialized
DEBUG - 2010-06-23 09:39:32 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 09:39:32 --> Language Class Initialized
DEBUG - 2010-06-23 09:39:32 --> Loader Class Initialized
DEBUG - 2010-06-23 09:39:32 --> Helper loaded: object_helper
DEBUG - 2010-06-23 09:39:32 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 09:39:32 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:39:32 --> Session Class Initialized
DEBUG - 2010-06-23 09:39:32 --> Helper loaded: string_helper
DEBUG - 2010-06-23 09:39:32 --> Session routines successfully run
DEBUG - 2010-06-23 09:39:32 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:39:32 --> Controller Class Initialized
DEBUG - 2010-06-23 09:39:32 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 09:39:32 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 09:39:32 --> Database Driver Class Initialized
DEBUG - 2010-06-23 09:39:32 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 09:39:32 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 09:39:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:39:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:40:08 --> Config Class Initialized
DEBUG - 2010-06-23 09:40:08 --> Hooks Class Initialized
DEBUG - 2010-06-23 09:40:08 --> URI Class Initialized
DEBUG - 2010-06-23 09:40:08 --> Router Class Initialized
DEBUG - 2010-06-23 09:40:08 --> Output Class Initialized
DEBUG - 2010-06-23 09:40:08 --> Input Class Initialized
DEBUG - 2010-06-23 09:40:08 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 09:40:08 --> Language Class Initialized
DEBUG - 2010-06-23 09:40:08 --> Loader Class Initialized
DEBUG - 2010-06-23 09:40:08 --> Helper loaded: object_helper
DEBUG - 2010-06-23 09:40:08 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 09:40:08 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:40:08 --> Session Class Initialized
DEBUG - 2010-06-23 09:40:08 --> Helper loaded: string_helper
DEBUG - 2010-06-23 09:40:08 --> Session routines successfully run
DEBUG - 2010-06-23 09:40:08 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:40:08 --> Controller Class Initialized
DEBUG - 2010-06-23 09:40:08 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 09:40:08 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 09:40:08 --> Database Driver Class Initialized
DEBUG - 2010-06-23 09:40:08 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 09:40:08 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 09:40:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:40:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:40:08 --> User Agent Class Initialized
DEBUG - 2010-06-23 09:40:08 --> Config file loaded: config/config.php
ERROR - 2010-06-23 09:40:08 --> 無法建立User，由於沒有設定關連的Domain
DEBUG - 2010-06-23 09:40:36 --> Config Class Initialized
DEBUG - 2010-06-23 09:40:36 --> Hooks Class Initialized
DEBUG - 2010-06-23 09:40:36 --> URI Class Initialized
DEBUG - 2010-06-23 09:40:36 --> Router Class Initialized
DEBUG - 2010-06-23 09:40:36 --> Output Class Initialized
DEBUG - 2010-06-23 09:40:36 --> Input Class Initialized
DEBUG - 2010-06-23 09:40:36 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 09:40:36 --> Language Class Initialized
DEBUG - 2010-06-23 09:40:36 --> Loader Class Initialized
DEBUG - 2010-06-23 09:40:37 --> Helper loaded: object_helper
DEBUG - 2010-06-23 09:40:37 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 09:40:37 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:40:37 --> Session Class Initialized
DEBUG - 2010-06-23 09:40:37 --> Helper loaded: string_helper
DEBUG - 2010-06-23 09:40:37 --> Session routines successfully run
DEBUG - 2010-06-23 09:40:37 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:40:37 --> Controller Class Initialized
DEBUG - 2010-06-23 09:40:37 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 09:40:37 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 09:40:37 --> Database Driver Class Initialized
DEBUG - 2010-06-23 09:40:37 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 09:40:37 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 09:40:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:40:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:40:37 --> User Agent Class Initialized
DEBUG - 2010-06-23 09:40:37 --> Config file loaded: config/config.php
ERROR - 2010-06-23 09:40:37 --> 無法建立User，由於沒有設定關連的Domain
ERROR - 2010-06-23 09:40:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php:210) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-23 09:41:06 --> Config Class Initialized
DEBUG - 2010-06-23 09:41:06 --> Hooks Class Initialized
DEBUG - 2010-06-23 09:41:06 --> URI Class Initialized
DEBUG - 2010-06-23 09:41:06 --> Router Class Initialized
DEBUG - 2010-06-23 09:41:06 --> Output Class Initialized
DEBUG - 2010-06-23 09:41:06 --> Input Class Initialized
DEBUG - 2010-06-23 09:41:06 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 09:41:06 --> Language Class Initialized
DEBUG - 2010-06-23 09:41:06 --> Loader Class Initialized
DEBUG - 2010-06-23 09:41:06 --> Helper loaded: object_helper
DEBUG - 2010-06-23 09:41:07 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 09:41:07 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:41:07 --> Session Class Initialized
DEBUG - 2010-06-23 09:41:07 --> Helper loaded: string_helper
DEBUG - 2010-06-23 09:41:07 --> Session routines successfully run
DEBUG - 2010-06-23 09:41:07 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:41:07 --> Controller Class Initialized
DEBUG - 2010-06-23 09:41:07 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 09:41:07 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 09:41:07 --> Database Driver Class Initialized
DEBUG - 2010-06-23 09:41:07 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 09:41:07 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 09:41:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:41:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:41:07 --> User Agent Class Initialized
DEBUG - 2010-06-23 09:41:07 --> Config file loaded: config/config.php
ERROR - 2010-06-23 09:41:07 --> 無法建立User，由於沒有設定關連的Domain
DEBUG - 2010-06-23 09:41:24 --> Config Class Initialized
DEBUG - 2010-06-23 09:41:24 --> Hooks Class Initialized
DEBUG - 2010-06-23 09:41:24 --> URI Class Initialized
DEBUG - 2010-06-23 09:41:24 --> Router Class Initialized
DEBUG - 2010-06-23 09:41:24 --> Output Class Initialized
DEBUG - 2010-06-23 09:41:24 --> Input Class Initialized
DEBUG - 2010-06-23 09:41:24 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 09:41:24 --> Language Class Initialized
DEBUG - 2010-06-23 09:41:24 --> Loader Class Initialized
DEBUG - 2010-06-23 09:41:24 --> Helper loaded: object_helper
DEBUG - 2010-06-23 09:41:24 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 09:41:25 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:41:25 --> Session Class Initialized
DEBUG - 2010-06-23 09:41:25 --> Helper loaded: string_helper
DEBUG - 2010-06-23 09:41:25 --> Session routines successfully run
DEBUG - 2010-06-23 09:41:25 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:41:25 --> Controller Class Initialized
DEBUG - 2010-06-23 09:41:25 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 09:41:25 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 09:41:25 --> Database Driver Class Initialized
DEBUG - 2010-06-23 09:41:25 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 09:41:25 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 09:41:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:41:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:41:25 --> User Agent Class Initialized
DEBUG - 2010-06-23 09:41:25 --> Config file loaded: config/config.php
ERROR - 2010-06-23 09:41:25 --> 無法建立User，由於沒有設定關連的Domain
ERROR - 2010-06-23 09:41:25 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php:242) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-23 09:41:45 --> Config Class Initialized
DEBUG - 2010-06-23 09:41:45 --> Hooks Class Initialized
DEBUG - 2010-06-23 09:41:45 --> URI Class Initialized
DEBUG - 2010-06-23 09:41:45 --> Router Class Initialized
DEBUG - 2010-06-23 09:41:45 --> Output Class Initialized
DEBUG - 2010-06-23 09:41:45 --> Input Class Initialized
DEBUG - 2010-06-23 09:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 09:41:45 --> Language Class Initialized
DEBUG - 2010-06-23 09:41:45 --> Loader Class Initialized
DEBUG - 2010-06-23 09:41:45 --> Helper loaded: object_helper
DEBUG - 2010-06-23 09:41:45 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 09:41:45 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:41:45 --> Session Class Initialized
DEBUG - 2010-06-23 09:41:45 --> Helper loaded: string_helper
DEBUG - 2010-06-23 09:41:45 --> Session routines successfully run
DEBUG - 2010-06-23 09:41:45 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:41:45 --> Controller Class Initialized
DEBUG - 2010-06-23 09:41:45 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 09:41:45 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 09:41:45 --> Database Driver Class Initialized
DEBUG - 2010-06-23 09:41:45 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 09:41:45 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 09:41:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:41:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:41:45 --> User Agent Class Initialized
DEBUG - 2010-06-23 09:41:45 --> Config file loaded: config/config.php
ERROR - 2010-06-23 09:41:45 --> 無法建立User，由於沒有設定關連的Domain
DEBUG - 2010-06-23 09:41:56 --> Config Class Initialized
DEBUG - 2010-06-23 09:41:56 --> Hooks Class Initialized
DEBUG - 2010-06-23 09:41:56 --> URI Class Initialized
DEBUG - 2010-06-23 09:41:56 --> Router Class Initialized
DEBUG - 2010-06-23 09:41:56 --> Output Class Initialized
DEBUG - 2010-06-23 09:41:56 --> Input Class Initialized
DEBUG - 2010-06-23 09:41:56 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 09:41:56 --> Language Class Initialized
DEBUG - 2010-06-23 09:41:56 --> Loader Class Initialized
DEBUG - 2010-06-23 09:41:56 --> Helper loaded: object_helper
DEBUG - 2010-06-23 09:41:56 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 09:41:56 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:41:56 --> Session Class Initialized
DEBUG - 2010-06-23 09:41:56 --> Helper loaded: string_helper
DEBUG - 2010-06-23 09:41:56 --> Session routines successfully run
DEBUG - 2010-06-23 09:41:56 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:41:56 --> Controller Class Initialized
DEBUG - 2010-06-23 09:41:56 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 09:41:56 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 09:41:56 --> Database Driver Class Initialized
DEBUG - 2010-06-23 09:41:57 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 09:41:57 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 09:41:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:41:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:41:57 --> User Agent Class Initialized
DEBUG - 2010-06-23 09:41:57 --> Config file loaded: config/config.php
ERROR - 2010-06-23 09:41:57 --> 無法建立User，由於沒有設定關連的Domain
ERROR - 2010-06-23 09:41:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php:243) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-23 09:44:22 --> Config Class Initialized
DEBUG - 2010-06-23 09:44:22 --> Hooks Class Initialized
DEBUG - 2010-06-23 09:44:22 --> URI Class Initialized
DEBUG - 2010-06-23 09:44:22 --> Router Class Initialized
DEBUG - 2010-06-23 09:44:22 --> Output Class Initialized
DEBUG - 2010-06-23 09:44:22 --> Input Class Initialized
DEBUG - 2010-06-23 09:44:22 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 09:44:22 --> Language Class Initialized
DEBUG - 2010-06-23 09:44:22 --> Loader Class Initialized
DEBUG - 2010-06-23 09:44:22 --> Helper loaded: object_helper
DEBUG - 2010-06-23 09:44:22 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 09:44:22 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:44:22 --> Session Class Initialized
DEBUG - 2010-06-23 09:44:22 --> Helper loaded: string_helper
DEBUG - 2010-06-23 09:44:22 --> Session routines successfully run
DEBUG - 2010-06-23 09:44:22 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:44:22 --> Controller Class Initialized
DEBUG - 2010-06-23 09:44:22 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 09:44:22 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 09:44:22 --> Database Driver Class Initialized
DEBUG - 2010-06-23 09:44:22 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 09:44:22 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 09:44:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:44:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:44:50 --> Config Class Initialized
DEBUG - 2010-06-23 09:44:50 --> Hooks Class Initialized
DEBUG - 2010-06-23 09:44:50 --> URI Class Initialized
DEBUG - 2010-06-23 09:44:50 --> Router Class Initialized
DEBUG - 2010-06-23 09:44:50 --> Output Class Initialized
DEBUG - 2010-06-23 09:44:51 --> Input Class Initialized
DEBUG - 2010-06-23 09:44:51 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 09:44:51 --> Language Class Initialized
DEBUG - 2010-06-23 09:44:51 --> Loader Class Initialized
DEBUG - 2010-06-23 09:44:51 --> Helper loaded: object_helper
DEBUG - 2010-06-23 09:44:51 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 09:44:51 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:44:51 --> Session Class Initialized
DEBUG - 2010-06-23 09:44:51 --> Helper loaded: string_helper
DEBUG - 2010-06-23 09:44:51 --> Session routines successfully run
DEBUG - 2010-06-23 09:44:51 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:44:51 --> Controller Class Initialized
DEBUG - 2010-06-23 09:44:51 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 09:44:51 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 09:44:51 --> Database Driver Class Initialized
DEBUG - 2010-06-23 09:44:51 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 09:44:51 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 09:44:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:44:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:44:51 --> User Agent Class Initialized
DEBUG - 2010-06-23 09:44:51 --> Config file loaded: config/config.php
ERROR - 2010-06-23 09:44:51 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;photo&quot; is of type boolean but expression is of type integer
LINE 1: ... &quot;style&quot;, &quot;password&quot;) VALUES ('pudding', NULL, 0, 0, 'zh-TW'...
                                                             ^
HINT:  You will need to rewrite or cast the expression. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-23 09:44:51 --> DB Transaction Failure
ERROR - 2010-06-23 09:44:51 --> Query error: ERROR:  column "photo" is of type boolean but expression is of type integer
LINE 1: ... "style", "password") VALUES ('pudding', NULL, 0, 0, 'zh-TW'...
                                                             ^
HINT:  You will need to rewrite or cast the expression.
DEBUG - 2010-06-23 09:44:51 --> Language file loaded: language/zh-TW/db_lang.php
DEBUG - 2010-06-23 09:47:24 --> Config Class Initialized
DEBUG - 2010-06-23 09:47:24 --> Hooks Class Initialized
DEBUG - 2010-06-23 09:47:24 --> URI Class Initialized
DEBUG - 2010-06-23 09:47:24 --> Router Class Initialized
DEBUG - 2010-06-23 09:47:24 --> Output Class Initialized
DEBUG - 2010-06-23 09:47:24 --> Input Class Initialized
DEBUG - 2010-06-23 09:47:24 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 09:47:24 --> Language Class Initialized
DEBUG - 2010-06-23 09:47:24 --> Loader Class Initialized
DEBUG - 2010-06-23 09:47:24 --> Helper loaded: object_helper
DEBUG - 2010-06-23 09:47:24 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 09:47:24 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:47:24 --> Session Class Initialized
DEBUG - 2010-06-23 09:47:24 --> Helper loaded: string_helper
DEBUG - 2010-06-23 09:47:24 --> Session routines successfully run
DEBUG - 2010-06-23 09:47:24 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:47:24 --> Controller Class Initialized
DEBUG - 2010-06-23 09:47:24 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 09:47:24 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 09:47:24 --> Database Driver Class Initialized
DEBUG - 2010-06-23 09:47:24 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 09:47:25 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 09:47:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:47:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:47:25 --> User Agent Class Initialized
DEBUG - 2010-06-23 09:47:25 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 09:47:25 --> Language file loaded: language/zh-TW/unit_test_lang.php
DEBUG - 2010-06-23 09:47:25 --> Config Class Initialized
DEBUG - 2010-06-23 09:47:25 --> Hooks Class Initialized
DEBUG - 2010-06-23 09:47:25 --> URI Class Initialized
DEBUG - 2010-06-23 09:47:25 --> Router Class Initialized
DEBUG - 2010-06-23 09:47:25 --> Output Class Initialized
DEBUG - 2010-06-23 09:47:25 --> Input Class Initialized
DEBUG - 2010-06-23 09:47:25 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 09:47:25 --> Language Class Initialized
DEBUG - 2010-06-23 09:47:25 --> Loader Class Initialized
DEBUG - 2010-06-23 09:47:25 --> Helper loaded: object_helper
DEBUG - 2010-06-23 09:47:25 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 09:47:25 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:47:25 --> Session Class Initialized
DEBUG - 2010-06-23 09:47:25 --> Helper loaded: string_helper
DEBUG - 2010-06-23 09:47:25 --> Session routines successfully run
DEBUG - 2010-06-23 09:47:25 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:47:25 --> Controller Class Initialized
DEBUG - 2010-06-23 09:47:25 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 09:47:25 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 09:47:26 --> Database Driver Class Initialized
DEBUG - 2010-06-23 09:47:26 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 09:47:26 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 09:47:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:47:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:47:26 --> User Agent Class Initialized
DEBUG - 2010-06-23 09:47:26 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 09:47:26 --> Language file loaded: language/zh-TW/unit_test_lang.php
DEBUG - 2010-06-23 09:50:30 --> Config Class Initialized
DEBUG - 2010-06-23 09:50:30 --> Hooks Class Initialized
DEBUG - 2010-06-23 09:50:30 --> URI Class Initialized
DEBUG - 2010-06-23 09:50:30 --> Router Class Initialized
DEBUG - 2010-06-23 09:50:30 --> Output Class Initialized
DEBUG - 2010-06-23 09:50:30 --> Input Class Initialized
DEBUG - 2010-06-23 09:50:30 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 09:50:30 --> Language Class Initialized
DEBUG - 2010-06-23 09:50:30 --> Loader Class Initialized
DEBUG - 2010-06-23 09:50:30 --> Helper loaded: object_helper
DEBUG - 2010-06-23 09:50:30 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 09:50:30 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:50:30 --> Session Class Initialized
DEBUG - 2010-06-23 09:50:30 --> Helper loaded: string_helper
DEBUG - 2010-06-23 09:50:30 --> Session routines successfully run
DEBUG - 2010-06-23 09:50:30 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:50:30 --> Controller Class Initialized
DEBUG - 2010-06-23 09:50:30 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 09:50:30 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 09:50:30 --> Database Driver Class Initialized
DEBUG - 2010-06-23 09:50:30 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 09:50:30 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 09:50:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:50:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:50:30 --> User Agent Class Initialized
DEBUG - 2010-06-23 09:50:30 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 09:50:30 --> Language file loaded: language/zh-TW/unit_test_lang.php
ERROR - 2010-06-23 09:50:30 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php:121) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-23 09:50:57 --> Config Class Initialized
DEBUG - 2010-06-23 09:50:57 --> Hooks Class Initialized
DEBUG - 2010-06-23 09:50:57 --> URI Class Initialized
DEBUG - 2010-06-23 09:50:57 --> Router Class Initialized
DEBUG - 2010-06-23 09:50:57 --> Output Class Initialized
DEBUG - 2010-06-23 09:50:57 --> Input Class Initialized
DEBUG - 2010-06-23 09:50:57 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 09:50:57 --> Language Class Initialized
DEBUG - 2010-06-23 09:50:57 --> Loader Class Initialized
DEBUG - 2010-06-23 09:50:57 --> Helper loaded: object_helper
DEBUG - 2010-06-23 09:50:58 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 09:50:58 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:50:58 --> Session Class Initialized
DEBUG - 2010-06-23 09:50:58 --> Helper loaded: string_helper
DEBUG - 2010-06-23 09:50:58 --> Session routines successfully run
DEBUG - 2010-06-23 09:50:58 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:50:58 --> Controller Class Initialized
DEBUG - 2010-06-23 09:50:58 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 09:50:58 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 09:50:58 --> Database Driver Class Initialized
DEBUG - 2010-06-23 09:50:58 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 09:50:58 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 09:50:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:50:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:50:58 --> User Agent Class Initialized
DEBUG - 2010-06-23 09:50:58 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 09:50:58 --> Language file loaded: language/zh-TW/unit_test_lang.php
DEBUG - 2010-06-23 09:50:58 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 09:50:58 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2010-06-23 09:50:58 --> Severity: Notice  --> Undefined property: User::$get_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 239
INFO  - 2010-06-23 09:50:58 --> User update: () pudding : 
DEBUG - 2010-06-23 09:50:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:50:58 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 09:50:58 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid reference to FROM-clause entry for table &quot;user&quot;
LINE 3: JOIN &quot;domain2user&quot; ON &quot;domain2user&quot;.&quot;user_id&quot; = &quot;user&quot;.&quot;user...
                                                        ^
HINT:  There is an entry for table &quot;user&quot;, but it cannot be referenced from this part of the query. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-23 09:50:58 --> DB Transaction Failure
ERROR - 2010-06-23 09:50:58 --> Query error: ERROR:  invalid reference to FROM-clause entry for table "user"
LINE 3: JOIN "domain2user" ON "domain2user"."user_id" = "user"."user...
                                                        ^
HINT:  There is an entry for table "user", but it cannot be referenced from this part of the query.
DEBUG - 2010-06-23 09:50:58 --> Language file loaded: language/zh-TW/db_lang.php
ERROR - 2010-06-23 09:50:58 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php:121) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-23 09:57:07 --> Config Class Initialized
DEBUG - 2010-06-23 09:57:07 --> Hooks Class Initialized
DEBUG - 2010-06-23 09:57:07 --> URI Class Initialized
DEBUG - 2010-06-23 09:57:07 --> Router Class Initialized
DEBUG - 2010-06-23 09:57:07 --> Output Class Initialized
DEBUG - 2010-06-23 09:57:07 --> Input Class Initialized
DEBUG - 2010-06-23 09:57:07 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 09:57:07 --> Language Class Initialized
DEBUG - 2010-06-23 09:57:07 --> Loader Class Initialized
DEBUG - 2010-06-23 09:57:07 --> Helper loaded: object_helper
DEBUG - 2010-06-23 09:57:07 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 09:57:07 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:57:07 --> Session Class Initialized
DEBUG - 2010-06-23 09:57:07 --> Helper loaded: string_helper
DEBUG - 2010-06-23 09:57:07 --> Session routines successfully run
DEBUG - 2010-06-23 09:57:08 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:57:08 --> Controller Class Initialized
DEBUG - 2010-06-23 09:57:08 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 09:57:08 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 09:57:08 --> Database Driver Class Initialized
DEBUG - 2010-06-23 09:57:08 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 09:57:08 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 09:57:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:57:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:57:08 --> User Agent Class Initialized
DEBUG - 2010-06-23 09:57:08 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 09:57:08 --> Language file loaded: language/zh-TW/unit_test_lang.php
DEBUG - 2010-06-23 09:57:08 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 09:57:08 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2010-06-23 09:57:08 --> Severity: Notice  --> Undefined property: User::$get_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 238
INFO  - 2010-06-23 09:57:08 --> User update: () pudding : 
DEBUG - 2010-06-23 09:57:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:57:08 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 09:57:08 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid reference to FROM-clause entry for table &quot;user&quot;
LINE 3: JOIN &quot;domain2user&quot; ON &quot;domain2user&quot;.&quot;user_id&quot; = &quot;user&quot;.&quot;user...
                                                        ^
HINT:  There is an entry for table &quot;user&quot;, but it cannot be referenced from this part of the query. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-23 09:57:08 --> DB Transaction Failure
ERROR - 2010-06-23 09:57:08 --> Query error: ERROR:  invalid reference to FROM-clause entry for table "user"
LINE 3: JOIN "domain2user" ON "domain2user"."user_id" = "user"."user...
                                                        ^
HINT:  There is an entry for table "user", but it cannot be referenced from this part of the query.
DEBUG - 2010-06-23 09:57:08 --> Language file loaded: language/zh-TW/db_lang.php
ERROR - 2010-06-23 09:57:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-23 09:57:45 --> Config Class Initialized
DEBUG - 2010-06-23 09:57:45 --> Hooks Class Initialized
DEBUG - 2010-06-23 09:57:45 --> URI Class Initialized
DEBUG - 2010-06-23 09:57:46 --> Router Class Initialized
DEBUG - 2010-06-23 09:57:46 --> Output Class Initialized
DEBUG - 2010-06-23 09:57:46 --> Input Class Initialized
DEBUG - 2010-06-23 09:57:46 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 09:57:46 --> Language Class Initialized
DEBUG - 2010-06-23 09:57:46 --> Loader Class Initialized
DEBUG - 2010-06-23 09:57:46 --> Helper loaded: object_helper
DEBUG - 2010-06-23 09:57:46 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 09:57:46 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:57:46 --> Session Class Initialized
DEBUG - 2010-06-23 09:57:46 --> Helper loaded: string_helper
DEBUG - 2010-06-23 09:57:46 --> Session routines successfully run
DEBUG - 2010-06-23 09:57:46 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:57:46 --> Controller Class Initialized
DEBUG - 2010-06-23 09:57:46 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 09:57:46 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 09:57:46 --> Database Driver Class Initialized
DEBUG - 2010-06-23 09:57:46 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 09:57:46 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 09:57:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:57:46 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:57:46 --> User Agent Class Initialized
DEBUG - 2010-06-23 09:57:46 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 09:57:46 --> Language file loaded: language/zh-TW/unit_test_lang.php
DEBUG - 2010-06-23 09:57:46 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 09:57:46 --> User_agent class already loaded. Second attempt ignored.
INFO  - 2010-06-23 09:57:46 --> User update: (6) pudding : 
DEBUG - 2010-06-23 09:57:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:57:47 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 09:57:47 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid reference to FROM-clause entry for table &quot;user&quot;
LINE 3: JOIN &quot;domain2user&quot; ON &quot;domain2user&quot;.&quot;user_id&quot; = &quot;user&quot;.&quot;user...
                                                        ^
HINT:  There is an entry for table &quot;user&quot;, but it cannot be referenced from this part of the query. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-23 09:57:47 --> DB Transaction Failure
ERROR - 2010-06-23 09:57:47 --> Query error: ERROR:  invalid reference to FROM-clause entry for table "user"
LINE 3: JOIN "domain2user" ON "domain2user"."user_id" = "user"."user...
                                                        ^
HINT:  There is an entry for table "user", but it cannot be referenced from this part of the query.
DEBUG - 2010-06-23 09:57:47 --> Language file loaded: language/zh-TW/db_lang.php
DEBUG - 2010-06-23 09:58:33 --> Config Class Initialized
DEBUG - 2010-06-23 09:58:34 --> Hooks Class Initialized
DEBUG - 2010-06-23 09:58:34 --> URI Class Initialized
DEBUG - 2010-06-23 09:58:34 --> Router Class Initialized
DEBUG - 2010-06-23 09:58:34 --> Output Class Initialized
DEBUG - 2010-06-23 09:58:34 --> Input Class Initialized
DEBUG - 2010-06-23 09:58:34 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 09:58:34 --> Language Class Initialized
DEBUG - 2010-06-23 09:58:34 --> Loader Class Initialized
DEBUG - 2010-06-23 09:58:34 --> Helper loaded: object_helper
DEBUG - 2010-06-23 09:58:34 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 09:58:34 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:58:34 --> Session Class Initialized
DEBUG - 2010-06-23 09:58:34 --> Helper loaded: string_helper
DEBUG - 2010-06-23 09:58:34 --> Session routines successfully run
DEBUG - 2010-06-23 09:58:34 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:58:34 --> Controller Class Initialized
DEBUG - 2010-06-23 09:58:34 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 09:58:34 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 09:58:34 --> Database Driver Class Initialized
DEBUG - 2010-06-23 09:58:34 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 09:58:34 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 09:58:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:58:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:58:34 --> User Agent Class Initialized
DEBUG - 2010-06-23 09:58:34 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 09:58:34 --> Language file loaded: language/zh-TW/unit_test_lang.php
DEBUG - 2010-06-23 09:58:34 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 09:58:34 --> User_agent class already loaded. Second attempt ignored.
INFO  - 2010-06-23 09:58:35 --> User update: (7) pudding : 
DEBUG - 2010-06-23 09:58:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:58:35 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 09:58:35 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid reference to FROM-clause entry for table &quot;user&quot;
LINE 3: JOIN &quot;domain2user&quot; ON &quot;domain2user&quot;.&quot;user_id&quot; = &quot;user&quot;.&quot;user...
                                                        ^
HINT:  There is an entry for table &quot;user&quot;, but it cannot be referenced from this part of the query. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-23 09:58:35 --> DB Transaction Failure
ERROR - 2010-06-23 09:58:35 --> Query error: ERROR:  invalid reference to FROM-clause entry for table "user"
LINE 3: JOIN "domain2user" ON "domain2user"."user_id" = "user"."user...
                                                        ^
HINT:  There is an entry for table "user", but it cannot be referenced from this part of the query.
DEBUG - 2010-06-23 09:58:35 --> Language file loaded: language/zh-TW/db_lang.php
ERROR - 2010-06-23 09:58:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\object_helper.php:49) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-23 09:59:16 --> Config Class Initialized
DEBUG - 2010-06-23 09:59:16 --> Hooks Class Initialized
DEBUG - 2010-06-23 09:59:16 --> URI Class Initialized
DEBUG - 2010-06-23 09:59:16 --> Router Class Initialized
DEBUG - 2010-06-23 09:59:16 --> Output Class Initialized
DEBUG - 2010-06-23 09:59:16 --> Input Class Initialized
DEBUG - 2010-06-23 09:59:16 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 09:59:16 --> Language Class Initialized
DEBUG - 2010-06-23 09:59:16 --> Loader Class Initialized
DEBUG - 2010-06-23 09:59:16 --> Helper loaded: object_helper
DEBUG - 2010-06-23 09:59:16 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 09:59:16 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:59:16 --> Session Class Initialized
DEBUG - 2010-06-23 09:59:16 --> Helper loaded: string_helper
DEBUG - 2010-06-23 09:59:16 --> Session routines successfully run
DEBUG - 2010-06-23 09:59:16 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:59:16 --> Controller Class Initialized
DEBUG - 2010-06-23 09:59:16 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 09:59:16 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 09:59:17 --> Database Driver Class Initialized
DEBUG - 2010-06-23 09:59:17 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 09:59:17 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 09:59:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:59:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:59:17 --> User Agent Class Initialized
DEBUG - 2010-06-23 09:59:17 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 09:59:17 --> Language file loaded: language/zh-TW/unit_test_lang.php
DEBUG - 2010-06-23 09:59:17 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 09:59:17 --> User_agent class already loaded. Second attempt ignored.
INFO  - 2010-06-23 09:59:17 --> User update: (8) pudding : 
DEBUG - 2010-06-23 09:59:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:59:17 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 09:59:17 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid reference to FROM-clause entry for table &quot;user&quot;
LINE 3: JOIN &quot;domain2user&quot; ON &quot;domain2user&quot;.&quot;user_id&quot; = &quot;user&quot;.&quot;user...
                                                        ^
HINT:  There is an entry for table &quot;user&quot;, but it cannot be referenced from this part of the query. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-23 09:59:17 --> DB Transaction Failure
ERROR - 2010-06-23 09:59:17 --> Query error: ERROR:  invalid reference to FROM-clause entry for table "user"
LINE 3: JOIN "domain2user" ON "domain2user"."user_id" = "user"."user...
                                                        ^
HINT:  There is an entry for table "user", but it cannot be referenced from this part of the query.
DEBUG - 2010-06-23 09:59:17 --> Language file loaded: language/zh-TW/db_lang.php
DEBUG - 2010-06-23 09:59:52 --> Config Class Initialized
DEBUG - 2010-06-23 09:59:52 --> Hooks Class Initialized
DEBUG - 2010-06-23 09:59:52 --> URI Class Initialized
DEBUG - 2010-06-23 09:59:52 --> Router Class Initialized
DEBUG - 2010-06-23 09:59:52 --> Output Class Initialized
DEBUG - 2010-06-23 09:59:52 --> Input Class Initialized
DEBUG - 2010-06-23 09:59:52 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 09:59:52 --> Language Class Initialized
DEBUG - 2010-06-23 09:59:52 --> Loader Class Initialized
DEBUG - 2010-06-23 09:59:52 --> Helper loaded: object_helper
DEBUG - 2010-06-23 09:59:52 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 09:59:53 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:59:53 --> Session Class Initialized
DEBUG - 2010-06-23 09:59:53 --> Helper loaded: string_helper
DEBUG - 2010-06-23 09:59:53 --> Session routines successfully run
DEBUG - 2010-06-23 09:59:53 --> Helper loaded: context_helper
DEBUG - 2010-06-23 09:59:53 --> Controller Class Initialized
DEBUG - 2010-06-23 09:59:53 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 09:59:53 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 09:59:53 --> Database Driver Class Initialized
DEBUG - 2010-06-23 09:59:53 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 09:59:53 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 09:59:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:59:53 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:59:53 --> User Agent Class Initialized
DEBUG - 2010-06-23 09:59:53 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 09:59:53 --> Language file loaded: language/zh-TW/unit_test_lang.php
DEBUG - 2010-06-23 09:59:53 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 09:59:53 --> User_agent class already loaded. Second attempt ignored.
INFO  - 2010-06-23 09:59:53 --> User update: (9) pudding : 
DEBUG - 2010-06-23 09:59:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 09:59:53 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 09:59:53 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid reference to FROM-clause entry for table &quot;user&quot;
LINE 3: JOIN &quot;domain2user&quot; ON &quot;domain2user&quot;.&quot;user_id&quot; = &quot;user&quot;.&quot;user...
                                                        ^
HINT:  There is an entry for table &quot;user&quot;, but it cannot be referenced from this part of the query. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-23 09:59:53 --> DB Transaction Failure
ERROR - 2010-06-23 09:59:53 --> Query error: ERROR:  invalid reference to FROM-clause entry for table "user"
LINE 3: JOIN "domain2user" ON "domain2user"."user_id" = "user"."user...
                                                        ^
HINT:  There is an entry for table "user", but it cannot be referenced from this part of the query.
DEBUG - 2010-06-23 09:59:53 --> Language file loaded: language/zh-TW/db_lang.php
ERROR - 2010-06-23 09:59:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\object_helper.php:50) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-23 10:06:54 --> Config Class Initialized
DEBUG - 2010-06-23 10:06:54 --> Hooks Class Initialized
DEBUG - 2010-06-23 10:06:54 --> URI Class Initialized
DEBUG - 2010-06-23 10:06:54 --> Router Class Initialized
DEBUG - 2010-06-23 10:06:54 --> Output Class Initialized
DEBUG - 2010-06-23 10:06:54 --> Input Class Initialized
DEBUG - 2010-06-23 10:06:54 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 10:06:54 --> Language Class Initialized
DEBUG - 2010-06-23 10:06:54 --> Loader Class Initialized
DEBUG - 2010-06-23 10:06:54 --> Helper loaded: object_helper
DEBUG - 2010-06-23 10:06:54 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 10:06:54 --> Helper loaded: context_helper
DEBUG - 2010-06-23 10:06:54 --> Session Class Initialized
DEBUG - 2010-06-23 10:06:54 --> Helper loaded: string_helper
DEBUG - 2010-06-23 10:06:54 --> Session routines successfully run
DEBUG - 2010-06-23 10:06:54 --> Helper loaded: context_helper
DEBUG - 2010-06-23 10:06:54 --> Controller Class Initialized
DEBUG - 2010-06-23 10:06:54 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 10:06:55 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 10:06:55 --> Database Driver Class Initialized
DEBUG - 2010-06-23 10:06:55 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 10:06:55 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 10:06:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 10:06:55 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 10:06:55 --> User Agent Class Initialized
DEBUG - 2010-06-23 10:06:55 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 10:06:55 --> Language file loaded: language/zh-TW/unit_test_lang.php
DEBUG - 2010-06-23 10:06:55 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 10:06:55 --> User_agent class already loaded. Second attempt ignored.
INFO  - 2010-06-23 10:06:55 --> User update: (10) pudding : 
DEBUG - 2010-06-23 10:06:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 10:06:55 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 10:06:55 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid reference to FROM-clause entry for table &quot;user&quot;
LINE 3: JOIN &quot;domain2user&quot; ON &quot;domain2user&quot;.&quot;user_id&quot; = &quot;user&quot;.&quot;user...
                                                        ^
HINT:  There is an entry for table &quot;user&quot;, but it cannot be referenced from this part of the query. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-23 10:06:55 --> DB Transaction Failure
ERROR - 2010-06-23 10:06:55 --> Query error: ERROR:  invalid reference to FROM-clause entry for table "user"
LINE 3: JOIN "domain2user" ON "domain2user"."user_id" = "user"."user...
                                                        ^
HINT:  There is an entry for table "user", but it cannot be referenced from this part of the query.
DEBUG - 2010-06-23 10:06:55 --> Language file loaded: language/zh-TW/db_lang.php
ERROR - 2010-06-23 10:06:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\object_helper.php:52) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-23 10:07:30 --> Config Class Initialized
DEBUG - 2010-06-23 10:07:30 --> Hooks Class Initialized
DEBUG - 2010-06-23 10:07:30 --> URI Class Initialized
DEBUG - 2010-06-23 10:07:30 --> Router Class Initialized
DEBUG - 2010-06-23 10:07:30 --> Output Class Initialized
DEBUG - 2010-06-23 10:07:30 --> Input Class Initialized
DEBUG - 2010-06-23 10:07:30 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 10:07:30 --> Language Class Initialized
DEBUG - 2010-06-23 10:07:30 --> Loader Class Initialized
DEBUG - 2010-06-23 10:07:30 --> Helper loaded: object_helper
DEBUG - 2010-06-23 10:07:30 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 10:07:31 --> Helper loaded: context_helper
DEBUG - 2010-06-23 10:07:31 --> Session Class Initialized
DEBUG - 2010-06-23 10:07:31 --> Helper loaded: string_helper
DEBUG - 2010-06-23 10:07:31 --> Session routines successfully run
DEBUG - 2010-06-23 10:07:31 --> Helper loaded: context_helper
DEBUG - 2010-06-23 10:07:31 --> Controller Class Initialized
DEBUG - 2010-06-23 10:07:31 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 10:07:31 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 10:07:31 --> Database Driver Class Initialized
DEBUG - 2010-06-23 10:07:31 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 10:07:31 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 10:07:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 10:07:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 10:07:31 --> User Agent Class Initialized
DEBUG - 2010-06-23 10:07:31 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 10:07:31 --> Language file loaded: language/zh-TW/unit_test_lang.php
DEBUG - 2010-06-23 10:07:31 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 10:07:31 --> User_agent class already loaded. Second attempt ignored.
INFO  - 2010-06-23 10:07:31 --> User update: (11) pudding : 
DEBUG - 2010-06-23 10:07:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 10:07:31 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 10:07:31 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid reference to FROM-clause entry for table &quot;user&quot;
LINE 3: JOIN &quot;domain2user&quot; ON &quot;domain2user&quot;.&quot;user_id&quot; = &quot;user&quot;.&quot;user...
                                                        ^
HINT:  There is an entry for table &quot;user&quot;, but it cannot be referenced from this part of the query. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-23 10:07:31 --> DB Transaction Failure
ERROR - 2010-06-23 10:07:31 --> Query error: ERROR:  invalid reference to FROM-clause entry for table "user"
LINE 3: JOIN "domain2user" ON "domain2user"."user_id" = "user"."user...
                                                        ^
HINT:  There is an entry for table "user", but it cannot be referenced from this part of the query.
DEBUG - 2010-06-23 10:07:32 --> Language file loaded: language/zh-TW/db_lang.php
ERROR - 2010-06-23 10:07:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\object_helper.php:52) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-23 10:07:57 --> Config Class Initialized
DEBUG - 2010-06-23 10:07:57 --> Hooks Class Initialized
DEBUG - 2010-06-23 10:07:57 --> URI Class Initialized
DEBUG - 2010-06-23 10:07:57 --> Router Class Initialized
DEBUG - 2010-06-23 10:07:57 --> Output Class Initialized
DEBUG - 2010-06-23 10:07:57 --> Input Class Initialized
DEBUG - 2010-06-23 10:07:57 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 10:07:57 --> Language Class Initialized
DEBUG - 2010-06-23 10:07:57 --> Loader Class Initialized
DEBUG - 2010-06-23 10:07:57 --> Helper loaded: object_helper
DEBUG - 2010-06-23 10:07:57 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 10:07:57 --> Helper loaded: context_helper
DEBUG - 2010-06-23 10:07:57 --> Session Class Initialized
DEBUG - 2010-06-23 10:07:57 --> Helper loaded: string_helper
DEBUG - 2010-06-23 10:07:57 --> Session routines successfully run
DEBUG - 2010-06-23 10:07:57 --> Helper loaded: context_helper
DEBUG - 2010-06-23 10:07:57 --> Controller Class Initialized
DEBUG - 2010-06-23 10:07:57 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 10:07:57 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 10:07:57 --> Database Driver Class Initialized
DEBUG - 2010-06-23 10:07:57 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 10:07:58 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 10:07:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 10:07:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 10:07:58 --> User Agent Class Initialized
DEBUG - 2010-06-23 10:07:58 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 10:07:58 --> Language file loaded: language/zh-TW/unit_test_lang.php
DEBUG - 2010-06-23 10:07:58 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 10:07:58 --> User_agent class already loaded. Second attempt ignored.
INFO  - 2010-06-23 10:07:58 --> User update: (12) pudding : 
DEBUG - 2010-06-23 10:07:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 10:07:58 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 10:07:58 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid reference to FROM-clause entry for table &quot;user&quot;
LINE 3: JOIN &quot;domain2user&quot; ON &quot;domain2user&quot;.&quot;user_id&quot; = &quot;user&quot;.&quot;user...
                                                        ^
HINT:  There is an entry for table &quot;user&quot;, but it cannot be referenced from this part of the query. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-23 10:07:58 --> DB Transaction Failure
ERROR - 2010-06-23 10:07:58 --> Query error: ERROR:  invalid reference to FROM-clause entry for table "user"
LINE 3: JOIN "domain2user" ON "domain2user"."user_id" = "user"."user...
                                                        ^
HINT:  There is an entry for table "user", but it cannot be referenced from this part of the query.
DEBUG - 2010-06-23 10:07:58 --> Language file loaded: language/zh-TW/db_lang.php
ERROR - 2010-06-23 10:07:58 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\object_helper.php:52) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-23 10:08:40 --> Config Class Initialized
DEBUG - 2010-06-23 10:08:40 --> Hooks Class Initialized
DEBUG - 2010-06-23 10:08:40 --> URI Class Initialized
DEBUG - 2010-06-23 10:08:40 --> Router Class Initialized
DEBUG - 2010-06-23 10:08:40 --> Output Class Initialized
DEBUG - 2010-06-23 10:08:40 --> Input Class Initialized
DEBUG - 2010-06-23 10:08:40 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 10:08:40 --> Language Class Initialized
DEBUG - 2010-06-23 10:08:40 --> Loader Class Initialized
DEBUG - 2010-06-23 10:08:40 --> Helper loaded: object_helper
DEBUG - 2010-06-23 10:08:40 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 10:08:41 --> Helper loaded: context_helper
DEBUG - 2010-06-23 10:08:41 --> Session Class Initialized
DEBUG - 2010-06-23 10:08:41 --> Helper loaded: string_helper
DEBUG - 2010-06-23 10:08:41 --> Session routines successfully run
DEBUG - 2010-06-23 10:08:41 --> Helper loaded: context_helper
DEBUG - 2010-06-23 10:08:41 --> Controller Class Initialized
DEBUG - 2010-06-23 10:08:41 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 10:08:41 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 10:08:41 --> Database Driver Class Initialized
DEBUG - 2010-06-23 10:08:41 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 10:08:41 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 10:08:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 10:08:41 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 10:08:41 --> User Agent Class Initialized
DEBUG - 2010-06-23 10:08:41 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 10:08:41 --> Language file loaded: language/zh-TW/unit_test_lang.php
DEBUG - 2010-06-23 10:08:41 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 10:08:41 --> User_agent class already loaded. Second attempt ignored.
INFO  - 2010-06-23 10:08:41 --> User update: (13) pudding : 
DEBUG - 2010-06-23 10:08:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 10:08:41 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 10:08:41 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid reference to FROM-clause entry for table &quot;user&quot;
LINE 3: JOIN &quot;domain2user&quot; ON &quot;domain2user&quot;.&quot;user_id&quot; = &quot;user&quot;.&quot;user...
                                                        ^
HINT:  There is an entry for table &quot;user&quot;, but it cannot be referenced from this part of the query. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-23 10:08:41 --> DB Transaction Failure
ERROR - 2010-06-23 10:08:42 --> Query error: ERROR:  invalid reference to FROM-clause entry for table "user"
LINE 3: JOIN "domain2user" ON "domain2user"."user_id" = "user"."user...
                                                        ^
HINT:  There is an entry for table "user", but it cannot be referenced from this part of the query.
DEBUG - 2010-06-23 10:08:42 --> Language file loaded: language/zh-TW/db_lang.php
ERROR - 2010-06-23 10:08:42 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php:243) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-23 10:08:59 --> Config Class Initialized
DEBUG - 2010-06-23 10:08:59 --> Hooks Class Initialized
DEBUG - 2010-06-23 10:08:59 --> URI Class Initialized
DEBUG - 2010-06-23 10:08:59 --> Router Class Initialized
DEBUG - 2010-06-23 10:08:59 --> Output Class Initialized
DEBUG - 2010-06-23 10:08:59 --> Input Class Initialized
DEBUG - 2010-06-23 10:08:59 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 10:08:59 --> Language Class Initialized
DEBUG - 2010-06-23 10:08:59 --> Loader Class Initialized
DEBUG - 2010-06-23 10:08:59 --> Helper loaded: object_helper
DEBUG - 2010-06-23 10:08:59 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 10:08:59 --> Helper loaded: context_helper
DEBUG - 2010-06-23 10:08:59 --> Session Class Initialized
DEBUG - 2010-06-23 10:08:59 --> Helper loaded: string_helper
DEBUG - 2010-06-23 10:08:59 --> Session routines successfully run
DEBUG - 2010-06-23 10:08:59 --> Helper loaded: context_helper
DEBUG - 2010-06-23 10:08:59 --> Controller Class Initialized
DEBUG - 2010-06-23 10:08:59 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 10:08:59 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 10:08:59 --> Database Driver Class Initialized
DEBUG - 2010-06-23 10:08:59 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 10:08:59 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 10:09:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 10:09:00 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 10:09:00 --> User Agent Class Initialized
DEBUG - 2010-06-23 10:09:00 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 10:09:00 --> Language file loaded: language/zh-TW/unit_test_lang.php
DEBUG - 2010-06-23 10:09:00 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 10:09:00 --> User_agent class already loaded. Second attempt ignored.
INFO  - 2010-06-23 10:09:00 --> User update: (14) pudding : 
DEBUG - 2010-06-23 10:09:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 10:09:00 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 10:09:00 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid reference to FROM-clause entry for table &quot;user&quot;
LINE 3: JOIN &quot;domain2user&quot; ON &quot;domain2user&quot;.&quot;user_id&quot; = &quot;user&quot;.&quot;user...
                                                        ^
HINT:  There is an entry for table &quot;user&quot;, but it cannot be referenced from this part of the query. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-23 10:09:00 --> DB Transaction Failure
ERROR - 2010-06-23 10:09:00 --> Query error: ERROR:  invalid reference to FROM-clause entry for table "user"
LINE 3: JOIN "domain2user" ON "domain2user"."user_id" = "user"."user...
                                                        ^
HINT:  There is an entry for table "user", but it cannot be referenced from this part of the query.
DEBUG - 2010-06-23 10:09:00 --> Language file loaded: language/zh-TW/db_lang.php
ERROR - 2010-06-23 10:09:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php:249) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-23 10:09:11 --> Config Class Initialized
DEBUG - 2010-06-23 10:09:11 --> Hooks Class Initialized
DEBUG - 2010-06-23 10:09:11 --> URI Class Initialized
DEBUG - 2010-06-23 10:09:11 --> Router Class Initialized
DEBUG - 2010-06-23 10:09:11 --> Output Class Initialized
DEBUG - 2010-06-23 10:09:11 --> Input Class Initialized
DEBUG - 2010-06-23 10:09:11 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 10:09:11 --> Language Class Initialized
DEBUG - 2010-06-23 10:09:11 --> Loader Class Initialized
DEBUG - 2010-06-23 10:09:11 --> Helper loaded: object_helper
DEBUG - 2010-06-23 10:09:11 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 10:09:11 --> Helper loaded: context_helper
DEBUG - 2010-06-23 10:09:11 --> Session Class Initialized
DEBUG - 2010-06-23 10:09:12 --> Helper loaded: string_helper
DEBUG - 2010-06-23 10:09:12 --> Session routines successfully run
DEBUG - 2010-06-23 10:09:12 --> Helper loaded: context_helper
DEBUG - 2010-06-23 10:09:12 --> Controller Class Initialized
DEBUG - 2010-06-23 10:09:12 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 10:09:12 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 10:09:12 --> Database Driver Class Initialized
DEBUG - 2010-06-23 10:09:12 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 10:09:12 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 10:09:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 10:09:12 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 10:09:12 --> User Agent Class Initialized
DEBUG - 2010-06-23 10:09:12 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 10:09:12 --> Language file loaded: language/zh-TW/unit_test_lang.php
DEBUG - 2010-06-23 10:09:12 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 10:09:12 --> User_agent class already loaded. Second attempt ignored.
INFO  - 2010-06-23 10:09:12 --> User update: (15) pudding : 
DEBUG - 2010-06-23 10:09:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 10:09:12 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 10:09:12 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid reference to FROM-clause entry for table &quot;user&quot;
LINE 3: JOIN &quot;domain2user&quot; ON &quot;domain2user&quot;.&quot;user_id&quot; = &quot;user&quot;.&quot;user...
                                                        ^
HINT:  There is an entry for table &quot;user&quot;, but it cannot be referenced from this part of the query. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-23 10:09:12 --> DB Transaction Failure
ERROR - 2010-06-23 10:09:12 --> Query error: ERROR:  invalid reference to FROM-clause entry for table "user"
LINE 3: JOIN "domain2user" ON "domain2user"."user_id" = "user"."user...
                                                        ^
HINT:  There is an entry for table "user", but it cannot be referenced from this part of the query.
DEBUG - 2010-06-23 10:09:13 --> Language file loaded: language/zh-TW/db_lang.php
ERROR - 2010-06-23 10:09:13 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php:252) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-23 10:09:30 --> Config Class Initialized
DEBUG - 2010-06-23 10:09:30 --> Hooks Class Initialized
DEBUG - 2010-06-23 10:09:30 --> URI Class Initialized
DEBUG - 2010-06-23 10:09:30 --> Router Class Initialized
DEBUG - 2010-06-23 10:09:30 --> Output Class Initialized
DEBUG - 2010-06-23 10:09:30 --> Input Class Initialized
DEBUG - 2010-06-23 10:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 10:09:30 --> Language Class Initialized
DEBUG - 2010-06-23 10:09:30 --> Loader Class Initialized
DEBUG - 2010-06-23 10:09:30 --> Helper loaded: object_helper
DEBUG - 2010-06-23 10:09:30 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 10:09:30 --> Helper loaded: context_helper
DEBUG - 2010-06-23 10:09:30 --> Session Class Initialized
DEBUG - 2010-06-23 10:09:30 --> Helper loaded: string_helper
DEBUG - 2010-06-23 10:09:30 --> Session routines successfully run
DEBUG - 2010-06-23 10:09:30 --> Helper loaded: context_helper
DEBUG - 2010-06-23 10:09:30 --> Controller Class Initialized
DEBUG - 2010-06-23 10:09:30 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 10:09:30 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 10:09:30 --> Database Driver Class Initialized
DEBUG - 2010-06-23 10:09:31 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 10:09:31 --> Config Class Initialized
DEBUG - 2010-06-23 10:09:31 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 10:09:31 --> Hooks Class Initialized
DEBUG - 2010-06-23 10:09:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 10:09:31 --> URI Class Initialized
DEBUG - 2010-06-23 10:09:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 10:09:31 --> Router Class Initialized
DEBUG - 2010-06-23 10:09:31 --> User Agent Class Initialized
DEBUG - 2010-06-23 10:09:31 --> Output Class Initialized
DEBUG - 2010-06-23 10:09:31 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 10:09:31 --> Input Class Initialized
DEBUG - 2010-06-23 10:09:31 --> Language file loaded: language/zh-TW/unit_test_lang.php
DEBUG - 2010-06-23 10:09:31 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 10:09:31 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 10:09:31 --> Language Class Initialized
DEBUG - 2010-06-23 10:09:31 --> User_agent class already loaded. Second attempt ignored.
INFO  - 2010-06-23 10:09:31 --> User update: (16) pudding : 
DEBUG - 2010-06-23 10:09:31 --> Loader Class Initialized
DEBUG - 2010-06-23 10:09:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 10:09:31 --> Helper loaded: object_helper
DEBUG - 2010-06-23 10:09:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 10:09:31 --> Helper loaded: kals_helper
ERROR - 2010-06-23 10:09:31 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid reference to FROM-clause entry for table &quot;user&quot;
LINE 3: JOIN &quot;domain2user&quot; ON &quot;domain2user&quot;.&quot;user_id&quot; = &quot;user&quot;.&quot;user...
                                                        ^
HINT:  There is an entry for table &quot;user&quot;, but it cannot be referenced from this part of the query. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-23 10:09:31 --> Helper loaded: context_helper
DEBUG - 2010-06-23 10:09:31 --> DB Transaction Failure
DEBUG - 2010-06-23 10:09:31 --> Session Class Initialized
ERROR - 2010-06-23 10:09:31 --> Query error: ERROR:  invalid reference to FROM-clause entry for table "user"
LINE 3: JOIN "domain2user" ON "domain2user"."user_id" = "user"."user...
                                                        ^
HINT:  There is an entry for table "user", but it cannot be referenced from this part of the query.
DEBUG - 2010-06-23 10:09:31 --> Language file loaded: language/zh-TW/db_lang.php
DEBUG - 2010-06-23 10:09:31 --> Helper loaded: string_helper
ERROR - 2010-06-23 10:09:31 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php:252) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-23 10:09:31 --> Session routines successfully run
DEBUG - 2010-06-23 10:09:31 --> Helper loaded: context_helper
DEBUG - 2010-06-23 10:09:31 --> Controller Class Initialized
DEBUG - 2010-06-23 10:09:31 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 10:09:31 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 10:09:32 --> Database Driver Class Initialized
DEBUG - 2010-06-23 10:09:32 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 10:09:32 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 10:09:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 10:09:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 10:09:32 --> User Agent Class Initialized
DEBUG - 2010-06-23 10:09:32 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 10:09:32 --> Language file loaded: language/zh-TW/unit_test_lang.php
DEBUG - 2010-06-23 10:09:32 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 10:09:32 --> User_agent class already loaded. Second attempt ignored.
INFO  - 2010-06-23 10:09:32 --> User update: (17) pudding : 
DEBUG - 2010-06-23 10:09:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 10:09:32 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 10:09:32 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid reference to FROM-clause entry for table &quot;user&quot;
LINE 3: JOIN &quot;domain2user&quot; ON &quot;domain2user&quot;.&quot;user_id&quot; = &quot;user&quot;.&quot;user...
                                                        ^
HINT:  There is an entry for table &quot;user&quot;, but it cannot be referenced from this part of the query. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-23 10:09:32 --> DB Transaction Failure
ERROR - 2010-06-23 10:09:32 --> Query error: ERROR:  invalid reference to FROM-clause entry for table "user"
LINE 3: JOIN "domain2user" ON "domain2user"."user_id" = "user"."user...
                                                        ^
HINT:  There is an entry for table "user", but it cannot be referenced from this part of the query.
DEBUG - 2010-06-23 10:09:32 --> Language file loaded: language/zh-TW/db_lang.php
ERROR - 2010-06-23 10:09:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php:252) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-23 10:10:12 --> Config Class Initialized
DEBUG - 2010-06-23 10:10:12 --> Hooks Class Initialized
DEBUG - 2010-06-23 10:10:12 --> URI Class Initialized
DEBUG - 2010-06-23 10:10:13 --> Router Class Initialized
DEBUG - 2010-06-23 10:10:13 --> Output Class Initialized
DEBUG - 2010-06-23 10:10:13 --> Input Class Initialized
DEBUG - 2010-06-23 10:10:13 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 10:10:13 --> Language Class Initialized
DEBUG - 2010-06-23 10:10:13 --> Loader Class Initialized
DEBUG - 2010-06-23 10:10:13 --> Helper loaded: object_helper
DEBUG - 2010-06-23 10:10:13 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 10:10:13 --> Helper loaded: context_helper
DEBUG - 2010-06-23 10:10:13 --> Session Class Initialized
DEBUG - 2010-06-23 10:10:13 --> Helper loaded: string_helper
DEBUG - 2010-06-23 10:10:13 --> Session routines successfully run
DEBUG - 2010-06-23 10:10:13 --> Helper loaded: context_helper
DEBUG - 2010-06-23 10:10:13 --> Controller Class Initialized
DEBUG - 2010-06-23 10:10:13 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 10:10:13 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 10:10:13 --> Database Driver Class Initialized
DEBUG - 2010-06-23 10:10:13 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 10:10:13 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 10:10:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 10:10:14 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 10:10:14 --> User Agent Class Initialized
DEBUG - 2010-06-23 10:10:14 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 10:10:14 --> Language file loaded: language/zh-TW/unit_test_lang.php
DEBUG - 2010-06-23 10:10:14 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 10:10:14 --> User_agent class already loaded. Second attempt ignored.
INFO  - 2010-06-23 10:10:14 --> User update: (18) pudding : 
DEBUG - 2010-06-23 10:10:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 10:10:14 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 10:10:14 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid reference to FROM-clause entry for table &quot;user&quot;
LINE 3: JOIN &quot;domain2user&quot; ON &quot;domain2user&quot;.&quot;user_id&quot; = &quot;user&quot;.&quot;user...
                                                        ^
HINT:  There is an entry for table &quot;user&quot;, but it cannot be referenced from this part of the query. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-23 10:10:14 --> DB Transaction Failure
ERROR - 2010-06-23 10:10:14 --> Query error: ERROR:  invalid reference to FROM-clause entry for table "user"
LINE 3: JOIN "domain2user" ON "domain2user"."user_id" = "user"."user...
                                                        ^
HINT:  There is an entry for table "user", but it cannot be referenced from this part of the query.
DEBUG - 2010-06-23 10:10:14 --> Language file loaded: language/zh-TW/db_lang.php
DEBUG - 2010-06-23 10:10:25 --> Config Class Initialized
DEBUG - 2010-06-23 10:10:25 --> Hooks Class Initialized
DEBUG - 2010-06-23 10:10:26 --> URI Class Initialized
DEBUG - 2010-06-23 10:10:26 --> Router Class Initialized
DEBUG - 2010-06-23 10:10:26 --> Output Class Initialized
DEBUG - 2010-06-23 10:10:26 --> Input Class Initialized
DEBUG - 2010-06-23 10:10:26 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 10:10:26 --> Language Class Initialized
DEBUG - 2010-06-23 10:10:26 --> Loader Class Initialized
DEBUG - 2010-06-23 10:10:26 --> Helper loaded: object_helper
DEBUG - 2010-06-23 10:10:26 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 10:10:26 --> Helper loaded: context_helper
DEBUG - 2010-06-23 10:10:26 --> Session Class Initialized
DEBUG - 2010-06-23 10:10:26 --> Helper loaded: string_helper
DEBUG - 2010-06-23 10:10:26 --> Session routines successfully run
DEBUG - 2010-06-23 10:10:26 --> Helper loaded: context_helper
DEBUG - 2010-06-23 10:10:26 --> Controller Class Initialized
DEBUG - 2010-06-23 10:10:26 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 10:10:26 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 10:10:26 --> Database Driver Class Initialized
DEBUG - 2010-06-23 10:10:26 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 10:10:27 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 10:10:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 10:10:27 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 10:10:27 --> User Agent Class Initialized
DEBUG - 2010-06-23 10:10:27 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 10:10:27 --> Language file loaded: language/zh-TW/unit_test_lang.php
DEBUG - 2010-06-23 10:10:27 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 10:10:27 --> User_agent class already loaded. Second attempt ignored.
INFO  - 2010-06-23 10:10:27 --> User update: (19) pudding : 
DEBUG - 2010-06-23 10:10:27 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 10:10:27 --> Final output sent to browser
DEBUG - 2010-06-23 10:10:27 --> Total execution time: 1.6331
DEBUG - 2010-06-23 11:11:09 --> Config Class Initialized
DEBUG - 2010-06-23 11:11:09 --> Hooks Class Initialized
DEBUG - 2010-06-23 11:11:09 --> URI Class Initialized
DEBUG - 2010-06-23 11:11:09 --> Router Class Initialized
DEBUG - 2010-06-23 11:11:09 --> Output Class Initialized
DEBUG - 2010-06-23 11:11:09 --> Input Class Initialized
DEBUG - 2010-06-23 11:11:09 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 11:11:09 --> Language Class Initialized
DEBUG - 2010-06-23 11:11:10 --> Loader Class Initialized
DEBUG - 2010-06-23 11:11:10 --> Helper loaded: object_helper
DEBUG - 2010-06-23 11:11:10 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 11:11:10 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:11:10 --> Session Class Initialized
DEBUG - 2010-06-23 11:11:10 --> Helper loaded: string_helper
DEBUG - 2010-06-23 11:11:10 --> Session routines successfully run
DEBUG - 2010-06-23 11:11:10 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:11:10 --> Controller Class Initialized
DEBUG - 2010-06-23 11:11:10 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 11:11:10 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 11:11:10 --> Database Driver Class Initialized
DEBUG - 2010-06-23 11:11:10 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 11:11:10 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 11:11:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:11:10 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:11:10 --> User Agent Class Initialized
DEBUG - 2010-06-23 11:11:10 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 11:11:11 --> Language file loaded: language/zh-TW/unit_test_lang.php
DEBUG - 2010-06-23 11:11:11 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 11:11:11 --> User_agent class already loaded. Second attempt ignored.
INFO  - 2010-06-23 11:11:11 --> User update: (20) pudding : 
DEBUG - 2010-06-23 11:11:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:11:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:11:43 --> Config Class Initialized
DEBUG - 2010-06-23 11:11:43 --> Hooks Class Initialized
DEBUG - 2010-06-23 11:11:43 --> URI Class Initialized
DEBUG - 2010-06-23 11:11:43 --> Router Class Initialized
DEBUG - 2010-06-23 11:11:43 --> Output Class Initialized
DEBUG - 2010-06-23 11:11:44 --> Input Class Initialized
DEBUG - 2010-06-23 11:11:44 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 11:11:44 --> Language Class Initialized
DEBUG - 2010-06-23 11:11:44 --> Loader Class Initialized
DEBUG - 2010-06-23 11:11:44 --> Helper loaded: object_helper
DEBUG - 2010-06-23 11:11:44 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 11:11:44 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:11:44 --> Session Class Initialized
DEBUG - 2010-06-23 11:11:44 --> Helper loaded: string_helper
DEBUG - 2010-06-23 11:11:44 --> Session routines successfully run
DEBUG - 2010-06-23 11:11:44 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:11:44 --> Controller Class Initialized
DEBUG - 2010-06-23 11:11:44 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 11:11:44 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 11:11:44 --> Database Driver Class Initialized
DEBUG - 2010-06-23 11:11:44 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 11:11:44 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 11:11:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:11:44 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:11:44 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 11:12:05 --> Config Class Initialized
DEBUG - 2010-06-23 11:12:05 --> Hooks Class Initialized
DEBUG - 2010-06-23 11:12:05 --> URI Class Initialized
DEBUG - 2010-06-23 11:12:05 --> Router Class Initialized
DEBUG - 2010-06-23 11:12:05 --> Output Class Initialized
DEBUG - 2010-06-23 11:12:05 --> Input Class Initialized
DEBUG - 2010-06-23 11:12:05 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 11:12:05 --> Language Class Initialized
DEBUG - 2010-06-23 11:12:06 --> Loader Class Initialized
DEBUG - 2010-06-23 11:12:06 --> Helper loaded: object_helper
DEBUG - 2010-06-23 11:12:06 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 11:12:06 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:12:06 --> Session Class Initialized
DEBUG - 2010-06-23 11:12:06 --> Helper loaded: string_helper
DEBUG - 2010-06-23 11:12:06 --> Session routines successfully run
DEBUG - 2010-06-23 11:12:06 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:12:06 --> Controller Class Initialized
DEBUG - 2010-06-23 11:12:06 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 11:12:06 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 11:12:06 --> Database Driver Class Initialized
DEBUG - 2010-06-23 11:12:06 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 11:12:06 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 11:12:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:12:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:12:06 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 11:12:06 --> User Agent Class Initialized
DEBUG - 2010-06-23 11:12:06 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 11:12:07 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 11:12:07 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-23 11:12:07 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
DEBUG - 2010-06-23 11:12:07 --> Language file loaded: language/zh-TW/unit_test_lang.php
DEBUG - 2010-06-23 11:12:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:12:07 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 11:12:07 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  null value in column &quot;name&quot; violates not-null constraint D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-23 11:12:07 --> DB Transaction Failure
ERROR - 2010-06-23 11:12:07 --> Query error: ERROR:  null value in column "name" violates not-null constraint
DEBUG - 2010-06-23 11:12:07 --> Language file loaded: language/zh-TW/db_lang.php
ERROR - 2010-06-23 11:12:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-23 11:14:06 --> Config Class Initialized
DEBUG - 2010-06-23 11:14:06 --> Hooks Class Initialized
DEBUG - 2010-06-23 11:14:06 --> URI Class Initialized
DEBUG - 2010-06-23 11:14:06 --> Router Class Initialized
DEBUG - 2010-06-23 11:14:06 --> Output Class Initialized
DEBUG - 2010-06-23 11:14:06 --> Input Class Initialized
DEBUG - 2010-06-23 11:14:06 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 11:14:06 --> Language Class Initialized
DEBUG - 2010-06-23 11:14:06 --> Loader Class Initialized
DEBUG - 2010-06-23 11:14:06 --> Helper loaded: object_helper
DEBUG - 2010-06-23 11:14:06 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 11:14:06 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:14:06 --> Session Class Initialized
DEBUG - 2010-06-23 11:14:06 --> Helper loaded: string_helper
DEBUG - 2010-06-23 11:14:06 --> Session routines successfully run
DEBUG - 2010-06-23 11:14:07 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:14:07 --> Controller Class Initialized
DEBUG - 2010-06-23 11:14:07 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 11:14:07 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 11:14:07 --> Database Driver Class Initialized
DEBUG - 2010-06-23 11:14:07 --> Language file loaded: language/zh-TW/kals_resource_lang.php
DEBUG - 2010-06-23 11:14:07 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 11:14:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:14:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:14:07 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 11:14:07 --> User Agent Class Initialized
DEBUG - 2010-06-23 11:14:07 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 11:14:07 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 11:14:07 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-23 11:14:07 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
DEBUG - 2010-06-23 11:14:07 --> Language file loaded: language/zh-TW/unit_test_lang.php
DEBUG - 2010-06-23 11:14:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:14:07 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 11:14:07 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  null value in column &quot;name&quot; violates not-null constraint D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-23 11:14:08 --> DB Transaction Failure
ERROR - 2010-06-23 11:14:08 --> Query error: ERROR:  null value in column "name" violates not-null constraint
DEBUG - 2010-06-23 11:14:08 --> Language file loaded: language/zh-TW/db_lang.php
ERROR - 2010-06-23 11:14:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-23 11:14:54 --> Config Class Initialized
DEBUG - 2010-06-23 11:14:54 --> Hooks Class Initialized
DEBUG - 2010-06-23 11:14:54 --> URI Class Initialized
DEBUG - 2010-06-23 11:14:54 --> Router Class Initialized
DEBUG - 2010-06-23 11:14:54 --> Output Class Initialized
DEBUG - 2010-06-23 11:14:54 --> Input Class Initialized
DEBUG - 2010-06-23 11:14:54 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 11:14:54 --> Language Class Initialized
DEBUG - 2010-06-23 11:14:54 --> Loader Class Initialized
DEBUG - 2010-06-23 11:14:54 --> Helper loaded: object_helper
DEBUG - 2010-06-23 11:14:55 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 11:14:55 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:14:55 --> Session Class Initialized
DEBUG - 2010-06-23 11:14:55 --> Helper loaded: string_helper
DEBUG - 2010-06-23 11:14:55 --> Session routines successfully run
DEBUG - 2010-06-23 11:14:55 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:14:55 --> Controller Class Initialized
DEBUG - 2010-06-23 11:14:55 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 11:14:55 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 11:14:55 --> Database Driver Class Initialized
DEBUG - 2010-06-23 11:14:55 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 11:14:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:14:56 --> Language file loaded: language/zh-TW/unit_test_lang.php
DEBUG - 2010-06-23 11:15:42 --> Config Class Initialized
DEBUG - 2010-06-23 11:15:42 --> Hooks Class Initialized
DEBUG - 2010-06-23 11:15:42 --> URI Class Initialized
DEBUG - 2010-06-23 11:15:42 --> Router Class Initialized
DEBUG - 2010-06-23 11:15:42 --> Output Class Initialized
DEBUG - 2010-06-23 11:15:42 --> Input Class Initialized
DEBUG - 2010-06-23 11:15:42 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 11:15:42 --> Language Class Initialized
DEBUG - 2010-06-23 11:15:42 --> Loader Class Initialized
DEBUG - 2010-06-23 11:15:42 --> Helper loaded: object_helper
DEBUG - 2010-06-23 11:15:42 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 11:15:42 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:15:43 --> Session Class Initialized
DEBUG - 2010-06-23 11:15:43 --> Helper loaded: string_helper
DEBUG - 2010-06-23 11:15:43 --> Session routines successfully run
DEBUG - 2010-06-23 11:15:43 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:15:43 --> Controller Class Initialized
DEBUG - 2010-06-23 11:15:43 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 11:15:43 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 11:15:43 --> Database Driver Class Initialized
DEBUG - 2010-06-23 11:15:43 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 11:15:43 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:15:43 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:15:44 --> Language file loaded: language/zh-TW/unit_test_lang.php
DEBUG - 2010-06-23 11:17:26 --> Config Class Initialized
DEBUG - 2010-06-23 11:17:26 --> Hooks Class Initialized
DEBUG - 2010-06-23 11:17:26 --> URI Class Initialized
DEBUG - 2010-06-23 11:17:27 --> Router Class Initialized
DEBUG - 2010-06-23 11:17:27 --> Output Class Initialized
DEBUG - 2010-06-23 11:17:27 --> Input Class Initialized
DEBUG - 2010-06-23 11:17:27 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 11:17:27 --> Language Class Initialized
DEBUG - 2010-06-23 11:17:58 --> Config Class Initialized
DEBUG - 2010-06-23 11:17:58 --> Hooks Class Initialized
DEBUG - 2010-06-23 11:17:58 --> URI Class Initialized
DEBUG - 2010-06-23 11:17:58 --> Router Class Initialized
DEBUG - 2010-06-23 11:17:58 --> Output Class Initialized
DEBUG - 2010-06-23 11:17:58 --> Input Class Initialized
DEBUG - 2010-06-23 11:17:58 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 11:17:58 --> Language Class Initialized
DEBUG - 2010-06-23 11:17:58 --> Loader Class Initialized
DEBUG - 2010-06-23 11:17:58 --> Helper loaded: object_helper
DEBUG - 2010-06-23 11:17:58 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 11:17:58 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:17:58 --> Session Class Initialized
DEBUG - 2010-06-23 11:17:58 --> Helper loaded: string_helper
DEBUG - 2010-06-23 11:17:58 --> Session routines successfully run
DEBUG - 2010-06-23 11:17:58 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:17:59 --> Controller Class Initialized
DEBUG - 2010-06-23 11:17:59 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 11:17:59 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 11:17:59 --> Database Driver Class Initialized
DEBUG - 2010-06-23 11:17:59 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 11:17:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:17:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:17:59 --> Language file loaded: language/zh-TW/unit_test_lang.php
DEBUG - 2010-06-23 11:17:59 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 11:17:59 --> 
DEBUG - 2010-06-23 11:18:31 --> Config Class Initialized
DEBUG - 2010-06-23 11:18:31 --> Hooks Class Initialized
DEBUG - 2010-06-23 11:18:31 --> URI Class Initialized
DEBUG - 2010-06-23 11:18:31 --> Router Class Initialized
DEBUG - 2010-06-23 11:18:31 --> Output Class Initialized
DEBUG - 2010-06-23 11:18:31 --> Input Class Initialized
DEBUG - 2010-06-23 11:18:31 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 11:18:31 --> Language Class Initialized
DEBUG - 2010-06-23 11:18:31 --> Loader Class Initialized
DEBUG - 2010-06-23 11:18:32 --> Helper loaded: object_helper
DEBUG - 2010-06-23 11:18:32 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 11:18:32 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:18:32 --> Session Class Initialized
DEBUG - 2010-06-23 11:18:32 --> Helper loaded: string_helper
DEBUG - 2010-06-23 11:18:32 --> Session routines successfully run
DEBUG - 2010-06-23 11:18:32 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:18:32 --> Controller Class Initialized
DEBUG - 2010-06-23 11:18:32 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 11:18:32 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 11:18:32 --> Database Driver Class Initialized
DEBUG - 2010-06-23 11:18:32 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 11:18:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:18:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:18:32 --> Language file loaded: language/zh-TW/unit_test_lang.php
DEBUG - 2010-06-23 11:18:32 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 11:18:32 --> 
DEBUG - 2010-06-23 11:19:35 --> Config Class Initialized
DEBUG - 2010-06-23 11:19:36 --> Hooks Class Initialized
DEBUG - 2010-06-23 11:19:36 --> URI Class Initialized
DEBUG - 2010-06-23 11:19:36 --> Router Class Initialized
DEBUG - 2010-06-23 11:19:36 --> Output Class Initialized
DEBUG - 2010-06-23 11:19:36 --> Input Class Initialized
DEBUG - 2010-06-23 11:19:36 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 11:19:36 --> Language Class Initialized
DEBUG - 2010-06-23 11:19:36 --> Loader Class Initialized
DEBUG - 2010-06-23 11:19:36 --> Helper loaded: object_helper
DEBUG - 2010-06-23 11:19:36 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 11:19:36 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:19:36 --> Session Class Initialized
DEBUG - 2010-06-23 11:19:36 --> Helper loaded: string_helper
DEBUG - 2010-06-23 11:19:36 --> Session routines successfully run
DEBUG - 2010-06-23 11:19:36 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:19:36 --> Controller Class Initialized
DEBUG - 2010-06-23 11:19:36 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 11:19:36 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 11:19:37 --> Database Driver Class Initialized
DEBUG - 2010-06-23 11:19:37 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 11:19:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:19:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:19:37 --> Language file loaded: language/zh-TW/unit_test_lang.php
DEBUG - 2010-06-23 11:19:37 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 11:19:37 --> 
ERROR - 2010-06-23 11:19:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php:61) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-23 11:20:07 --> Config Class Initialized
DEBUG - 2010-06-23 11:20:07 --> Hooks Class Initialized
DEBUG - 2010-06-23 11:20:07 --> URI Class Initialized
DEBUG - 2010-06-23 11:20:07 --> Router Class Initialized
DEBUG - 2010-06-23 11:20:07 --> Output Class Initialized
DEBUG - 2010-06-23 11:20:07 --> Input Class Initialized
DEBUG - 2010-06-23 11:20:07 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 11:20:07 --> Language Class Initialized
DEBUG - 2010-06-23 11:20:07 --> Loader Class Initialized
DEBUG - 2010-06-23 11:20:07 --> Helper loaded: object_helper
DEBUG - 2010-06-23 11:20:07 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 11:20:07 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:20:07 --> Session Class Initialized
DEBUG - 2010-06-23 11:20:08 --> Helper loaded: string_helper
DEBUG - 2010-06-23 11:20:08 --> Session routines successfully run
DEBUG - 2010-06-23 11:20:08 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:20:08 --> Controller Class Initialized
DEBUG - 2010-06-23 11:20:08 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 11:20:08 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 11:20:08 --> Database Driver Class Initialized
DEBUG - 2010-06-23 11:20:08 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 11:20:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:20:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:20:08 --> Language file loaded: language/zh-TW/unit_test_lang.php
DEBUG - 2010-06-23 11:20:08 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 11:20:08 --> 
ERROR - 2010-06-23 11:20:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php:195) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-23 11:21:43 --> Config Class Initialized
DEBUG - 2010-06-23 11:21:43 --> Hooks Class Initialized
DEBUG - 2010-06-23 11:21:43 --> URI Class Initialized
DEBUG - 2010-06-23 11:21:43 --> Router Class Initialized
DEBUG - 2010-06-23 11:21:43 --> Output Class Initialized
DEBUG - 2010-06-23 11:21:43 --> Input Class Initialized
DEBUG - 2010-06-23 11:21:43 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 11:21:43 --> Language Class Initialized
DEBUG - 2010-06-23 11:21:43 --> Loader Class Initialized
DEBUG - 2010-06-23 11:21:43 --> Helper loaded: object_helper
DEBUG - 2010-06-23 11:21:43 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 11:21:44 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:21:44 --> Session Class Initialized
DEBUG - 2010-06-23 11:21:44 --> Helper loaded: string_helper
DEBUG - 2010-06-23 11:21:44 --> Session routines successfully run
DEBUG - 2010-06-23 11:21:44 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:21:44 --> Controller Class Initialized
DEBUG - 2010-06-23 11:21:44 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 11:21:44 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 11:21:44 --> Database Driver Class Initialized
DEBUG - 2010-06-23 11:21:44 --> Language file loaded: language/zh-TW/kals_actor_lang.php
DEBUG - 2010-06-23 11:21:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:21:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:21:44 --> Language file loaded: language/zh-TW/unit_test_lang.php
DEBUG - 2010-06-23 11:21:44 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 11:21:44 --> 
ERROR - 2010-06-23 11:21:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php:170) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-23 11:25:23 --> Config Class Initialized
DEBUG - 2010-06-23 11:25:24 --> Hooks Class Initialized
DEBUG - 2010-06-23 11:25:24 --> URI Class Initialized
DEBUG - 2010-06-23 11:25:24 --> No URI present. Default controller set.
DEBUG - 2010-06-23 11:25:24 --> Router Class Initialized
DEBUG - 2010-06-23 11:25:24 --> Output Class Initialized
DEBUG - 2010-06-23 11:25:24 --> Input Class Initialized
DEBUG - 2010-06-23 11:25:24 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 11:25:24 --> Language Class Initialized
DEBUG - 2010-06-23 11:25:24 --> Loader Class Initialized
DEBUG - 2010-06-23 11:25:24 --> Helper loaded: object_helper
DEBUG - 2010-06-23 11:25:24 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 11:25:24 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:25:24 --> Session Class Initialized
DEBUG - 2010-06-23 11:25:24 --> Helper loaded: string_helper
DEBUG - 2010-06-23 11:25:24 --> Session routines successfully run
DEBUG - 2010-06-23 11:25:24 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:25:24 --> Controller Class Initialized
DEBUG - 2010-06-23 11:25:24 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 11:25:25 --> User Agent Class Initialized
DEBUG - 2010-06-23 11:25:25 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 11:25:25 --> Final output sent to browser
DEBUG - 2010-06-23 11:25:25 --> Total execution time: 1.2374
DEBUG - 2010-06-23 11:25:40 --> Config Class Initialized
DEBUG - 2010-06-23 11:25:40 --> Hooks Class Initialized
DEBUG - 2010-06-23 11:25:40 --> URI Class Initialized
DEBUG - 2010-06-23 11:25:40 --> No URI present. Default controller set.
DEBUG - 2010-06-23 11:25:40 --> Router Class Initialized
DEBUG - 2010-06-23 11:25:40 --> Output Class Initialized
DEBUG - 2010-06-23 11:25:40 --> Input Class Initialized
DEBUG - 2010-06-23 11:25:40 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 11:25:40 --> Language Class Initialized
DEBUG - 2010-06-23 11:25:40 --> Loader Class Initialized
DEBUG - 2010-06-23 11:25:40 --> Helper loaded: object_helper
DEBUG - 2010-06-23 11:25:40 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 11:25:40 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:25:41 --> Session Class Initialized
DEBUG - 2010-06-23 11:25:41 --> Helper loaded: string_helper
DEBUG - 2010-06-23 11:25:41 --> Session routines successfully run
DEBUG - 2010-06-23 11:25:41 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:25:41 --> Controller Class Initialized
DEBUG - 2010-06-23 11:25:41 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 11:25:41 --> User Agent Class Initialized
DEBUG - 2010-06-23 11:25:41 --> Final output sent to browser
DEBUG - 2010-06-23 11:25:41 --> Total execution time: 1.1662
DEBUG - 2010-06-23 11:27:34 --> Config Class Initialized
DEBUG - 2010-06-23 11:27:34 --> Hooks Class Initialized
DEBUG - 2010-06-23 11:27:34 --> URI Class Initialized
DEBUG - 2010-06-23 11:27:34 --> No URI present. Default controller set.
DEBUG - 2010-06-23 11:27:34 --> Router Class Initialized
DEBUG - 2010-06-23 11:27:34 --> Output Class Initialized
DEBUG - 2010-06-23 11:27:34 --> Input Class Initialized
DEBUG - 2010-06-23 11:27:34 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 11:27:34 --> Language Class Initialized
DEBUG - 2010-06-23 11:27:35 --> Loader Class Initialized
DEBUG - 2010-06-23 11:27:35 --> Helper loaded: object_helper
DEBUG - 2010-06-23 11:27:35 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 11:27:35 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:27:35 --> Session Class Initialized
DEBUG - 2010-06-23 11:27:35 --> Helper loaded: string_helper
DEBUG - 2010-06-23 11:27:35 --> Session routines successfully run
DEBUG - 2010-06-23 11:27:35 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:27:35 --> Controller Class Initialized
DEBUG - 2010-06-23 11:27:35 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 11:27:35 --> User Agent Class Initialized
DEBUG - 2010-06-23 11:27:35 --> Final output sent to browser
DEBUG - 2010-06-23 11:27:35 --> Total execution time: 1.1971
DEBUG - 2010-06-23 11:27:51 --> Config Class Initialized
DEBUG - 2010-06-23 11:27:51 --> Hooks Class Initialized
DEBUG - 2010-06-23 11:27:51 --> URI Class Initialized
DEBUG - 2010-06-23 11:27:51 --> No URI present. Default controller set.
DEBUG - 2010-06-23 11:27:51 --> Router Class Initialized
DEBUG - 2010-06-23 11:27:51 --> Output Class Initialized
DEBUG - 2010-06-23 11:27:51 --> Input Class Initialized
DEBUG - 2010-06-23 11:27:51 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 11:27:52 --> Language Class Initialized
DEBUG - 2010-06-23 11:27:52 --> Loader Class Initialized
DEBUG - 2010-06-23 11:27:52 --> Helper loaded: object_helper
DEBUG - 2010-06-23 11:27:52 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 11:27:52 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:27:52 --> Session Class Initialized
DEBUG - 2010-06-23 11:27:52 --> Helper loaded: string_helper
DEBUG - 2010-06-23 11:27:52 --> Session routines successfully run
DEBUG - 2010-06-23 11:27:52 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:27:52 --> Controller Class Initialized
DEBUG - 2010-06-23 11:27:52 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 11:27:52 --> User Agent Class Initialized
DEBUG - 2010-06-23 11:27:52 --> Final output sent to browser
DEBUG - 2010-06-23 11:27:52 --> Total execution time: 1.2162
DEBUG - 2010-06-23 11:28:17 --> Config Class Initialized
DEBUG - 2010-06-23 11:28:17 --> Hooks Class Initialized
DEBUG - 2010-06-23 11:28:17 --> URI Class Initialized
DEBUG - 2010-06-23 11:28:17 --> No URI present. Default controller set.
DEBUG - 2010-06-23 11:28:17 --> Router Class Initialized
DEBUG - 2010-06-23 11:28:17 --> Output Class Initialized
DEBUG - 2010-06-23 11:28:17 --> Input Class Initialized
DEBUG - 2010-06-23 11:28:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 11:28:17 --> Language Class Initialized
DEBUG - 2010-06-23 11:28:17 --> Loader Class Initialized
DEBUG - 2010-06-23 11:28:17 --> Helper loaded: object_helper
DEBUG - 2010-06-23 11:28:17 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 11:28:17 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:28:17 --> Session Class Initialized
DEBUG - 2010-06-23 11:28:18 --> Helper loaded: string_helper
DEBUG - 2010-06-23 11:28:18 --> Session routines successfully run
DEBUG - 2010-06-23 11:28:18 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:28:18 --> Controller Class Initialized
DEBUG - 2010-06-23 11:28:18 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 11:28:18 --> User Agent Class Initialized
DEBUG - 2010-06-23 11:28:18 --> Final output sent to browser
DEBUG - 2010-06-23 11:28:18 --> Total execution time: 1.2806
DEBUG - 2010-06-23 11:28:51 --> Config Class Initialized
DEBUG - 2010-06-23 11:28:51 --> Hooks Class Initialized
DEBUG - 2010-06-23 11:28:51 --> URI Class Initialized
DEBUG - 2010-06-23 11:28:51 --> No URI present. Default controller set.
DEBUG - 2010-06-23 11:28:51 --> Router Class Initialized
DEBUG - 2010-06-23 11:28:51 --> Output Class Initialized
DEBUG - 2010-06-23 11:28:51 --> Input Class Initialized
DEBUG - 2010-06-23 11:28:51 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 11:28:51 --> Language Class Initialized
DEBUG - 2010-06-23 11:28:51 --> Loader Class Initialized
DEBUG - 2010-06-23 11:28:51 --> Helper loaded: object_helper
DEBUG - 2010-06-23 11:28:51 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 11:28:52 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:28:52 --> Session Class Initialized
DEBUG - 2010-06-23 11:28:52 --> Helper loaded: string_helper
DEBUG - 2010-06-23 11:28:52 --> Session routines successfully run
DEBUG - 2010-06-23 11:28:52 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:28:52 --> Controller Class Initialized
DEBUG - 2010-06-23 11:28:52 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 11:28:52 --> User Agent Class Initialized
DEBUG - 2010-06-23 11:28:52 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 11:28:52 --> Final output sent to browser
DEBUG - 2010-06-23 11:28:52 --> Total execution time: 1.2772
DEBUG - 2010-06-23 11:34:15 --> Config Class Initialized
DEBUG - 2010-06-23 11:34:15 --> Hooks Class Initialized
DEBUG - 2010-06-23 11:34:15 --> URI Class Initialized
DEBUG - 2010-06-23 11:34:15 --> Router Class Initialized
DEBUG - 2010-06-23 11:34:15 --> Output Class Initialized
DEBUG - 2010-06-23 11:34:15 --> Input Class Initialized
DEBUG - 2010-06-23 11:34:16 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 11:34:16 --> Language Class Initialized
DEBUG - 2010-06-23 11:34:16 --> Loader Class Initialized
DEBUG - 2010-06-23 11:34:16 --> Helper loaded: object_helper
DEBUG - 2010-06-23 11:34:16 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 11:34:16 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:34:16 --> Session Class Initialized
DEBUG - 2010-06-23 11:34:16 --> Helper loaded: string_helper
DEBUG - 2010-06-23 11:34:16 --> Session routines successfully run
DEBUG - 2010-06-23 11:34:16 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:34:16 --> Controller Class Initialized
DEBUG - 2010-06-23 11:34:16 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 11:34:16 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 11:34:16 --> Database Driver Class Initialized
DEBUG - 2010-06-23 11:34:16 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 11:34:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:34:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:34:17 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 11:34:17 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 11:34:17 --> 
ERROR - 2010-06-23 11:34:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php:170) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-23 11:35:28 --> Config Class Initialized
DEBUG - 2010-06-23 11:35:28 --> Hooks Class Initialized
DEBUG - 2010-06-23 11:35:28 --> URI Class Initialized
DEBUG - 2010-06-23 11:35:28 --> Router Class Initialized
DEBUG - 2010-06-23 11:35:28 --> Output Class Initialized
DEBUG - 2010-06-23 11:35:28 --> Input Class Initialized
DEBUG - 2010-06-23 11:35:28 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 11:35:28 --> Language Class Initialized
DEBUG - 2010-06-23 11:35:28 --> Loader Class Initialized
DEBUG - 2010-06-23 11:35:29 --> Helper loaded: object_helper
DEBUG - 2010-06-23 11:35:29 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 11:35:29 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:35:29 --> Session Class Initialized
DEBUG - 2010-06-23 11:35:29 --> Helper loaded: string_helper
DEBUG - 2010-06-23 11:35:29 --> Session routines successfully run
DEBUG - 2010-06-23 11:35:29 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:35:29 --> Controller Class Initialized
DEBUG - 2010-06-23 11:35:29 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 11:35:29 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 11:35:29 --> Database Driver Class Initialized
DEBUG - 2010-06-23 11:35:29 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 11:35:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:35:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:35:29 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 11:35:29 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 11:35:30 --> 無法刪除Domain
ERROR - 2010-06-23 11:35:30 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php:170) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-23 11:36:28 --> Config Class Initialized
DEBUG - 2010-06-23 11:36:28 --> Hooks Class Initialized
DEBUG - 2010-06-23 11:36:28 --> URI Class Initialized
DEBUG - 2010-06-23 11:36:28 --> Router Class Initialized
DEBUG - 2010-06-23 11:36:28 --> Output Class Initialized
DEBUG - 2010-06-23 11:36:28 --> Input Class Initialized
DEBUG - 2010-06-23 11:36:28 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 11:36:28 --> Language Class Initialized
DEBUG - 2010-06-23 11:36:29 --> Loader Class Initialized
DEBUG - 2010-06-23 11:36:29 --> Helper loaded: object_helper
DEBUG - 2010-06-23 11:36:29 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 11:36:29 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:36:29 --> Session Class Initialized
DEBUG - 2010-06-23 11:36:29 --> Helper loaded: string_helper
DEBUG - 2010-06-23 11:36:29 --> Session routines successfully run
DEBUG - 2010-06-23 11:36:29 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:36:29 --> Controller Class Initialized
DEBUG - 2010-06-23 11:36:29 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 11:36:29 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 11:36:29 --> Database Driver Class Initialized
DEBUG - 2010-06-23 11:36:29 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 11:36:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:36:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:36:29 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 11:36:30 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 11:36:30 --> 無法刪除Domain
ERROR - 2010-06-23 11:36:30 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\KALSResource.php:33) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-23 11:36:53 --> Config Class Initialized
DEBUG - 2010-06-23 11:36:53 --> Hooks Class Initialized
DEBUG - 2010-06-23 11:36:53 --> URI Class Initialized
DEBUG - 2010-06-23 11:36:53 --> Router Class Initialized
DEBUG - 2010-06-23 11:36:53 --> Output Class Initialized
DEBUG - 2010-06-23 11:36:53 --> Input Class Initialized
DEBUG - 2010-06-23 11:36:53 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 11:36:53 --> Language Class Initialized
DEBUG - 2010-06-23 11:36:53 --> Loader Class Initialized
DEBUG - 2010-06-23 11:36:53 --> Helper loaded: object_helper
DEBUG - 2010-06-23 11:36:53 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 11:36:53 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:36:54 --> Session Class Initialized
DEBUG - 2010-06-23 11:36:54 --> Helper loaded: string_helper
DEBUG - 2010-06-23 11:36:54 --> Session routines successfully run
DEBUG - 2010-06-23 11:36:54 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:36:54 --> Controller Class Initialized
DEBUG - 2010-06-23 11:36:54 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 11:36:54 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 11:36:54 --> Database Driver Class Initialized
DEBUG - 2010-06-23 11:36:54 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 11:36:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:36:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:36:54 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 11:36:54 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 11:36:54 --> 無法刪除Domain
ERROR - 2010-06-23 11:36:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\KALSResource.php:33) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-23 11:37:24 --> Config Class Initialized
DEBUG - 2010-06-23 11:37:24 --> Hooks Class Initialized
DEBUG - 2010-06-23 11:37:24 --> URI Class Initialized
DEBUG - 2010-06-23 11:37:24 --> Router Class Initialized
DEBUG - 2010-06-23 11:37:24 --> Output Class Initialized
DEBUG - 2010-06-23 11:37:24 --> Input Class Initialized
DEBUG - 2010-06-23 11:37:24 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 11:37:24 --> Language Class Initialized
DEBUG - 2010-06-23 11:37:24 --> Loader Class Initialized
DEBUG - 2010-06-23 11:37:25 --> Helper loaded: object_helper
DEBUG - 2010-06-23 11:37:25 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 11:37:25 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:37:25 --> Session Class Initialized
DEBUG - 2010-06-23 11:37:25 --> Helper loaded: string_helper
DEBUG - 2010-06-23 11:37:25 --> Session routines successfully run
DEBUG - 2010-06-23 11:37:25 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:37:25 --> Controller Class Initialized
DEBUG - 2010-06-23 11:37:25 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 11:37:25 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 11:37:25 --> Database Driver Class Initialized
DEBUG - 2010-06-23 11:37:25 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 11:37:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:37:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:37:25 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 11:37:26 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 11:37:26 --> 無法刪除Domain
ERROR - 2010-06-23 11:37:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php:195) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-23 11:39:31 --> Config Class Initialized
DEBUG - 2010-06-23 11:39:31 --> Hooks Class Initialized
DEBUG - 2010-06-23 11:39:31 --> URI Class Initialized
DEBUG - 2010-06-23 11:39:31 --> Router Class Initialized
DEBUG - 2010-06-23 11:39:31 --> Output Class Initialized
DEBUG - 2010-06-23 11:39:31 --> Input Class Initialized
DEBUG - 2010-06-23 11:39:31 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 11:39:32 --> Language Class Initialized
DEBUG - 2010-06-23 11:39:32 --> Loader Class Initialized
DEBUG - 2010-06-23 11:39:32 --> Helper loaded: object_helper
DEBUG - 2010-06-23 11:39:32 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 11:39:32 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:39:32 --> Session Class Initialized
DEBUG - 2010-06-23 11:39:32 --> Helper loaded: string_helper
DEBUG - 2010-06-23 11:39:32 --> Session routines successfully run
DEBUG - 2010-06-23 11:39:32 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:39:32 --> Controller Class Initialized
DEBUG - 2010-06-23 11:39:32 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 11:39:32 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 11:39:32 --> Database Driver Class Initialized
DEBUG - 2010-06-23 11:39:32 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 11:39:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:39:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:39:33 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 11:39:33 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 11:39:33 --> 無法刪除Domain
DEBUG - 2010-06-23 11:39:41 --> Config Class Initialized
DEBUG - 2010-06-23 11:39:41 --> Hooks Class Initialized
DEBUG - 2010-06-23 11:39:42 --> URI Class Initialized
DEBUG - 2010-06-23 11:39:42 --> Router Class Initialized
DEBUG - 2010-06-23 11:39:42 --> Output Class Initialized
DEBUG - 2010-06-23 11:39:42 --> Input Class Initialized
DEBUG - 2010-06-23 11:39:42 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 11:39:42 --> Language Class Initialized
DEBUG - 2010-06-23 11:39:42 --> Loader Class Initialized
DEBUG - 2010-06-23 11:39:42 --> Helper loaded: object_helper
DEBUG - 2010-06-23 11:39:42 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 11:39:42 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:39:42 --> Session Class Initialized
DEBUG - 2010-06-23 11:39:42 --> Helper loaded: string_helper
DEBUG - 2010-06-23 11:39:42 --> Session routines successfully run
DEBUG - 2010-06-23 11:39:42 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:39:42 --> Controller Class Initialized
DEBUG - 2010-06-23 11:39:43 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 11:39:43 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 11:39:43 --> Database Driver Class Initialized
DEBUG - 2010-06-23 11:39:43 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 11:39:43 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:39:43 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:39:43 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 11:39:43 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 11:39:43 --> 無法刪除Domain
DEBUG - 2010-06-23 11:39:55 --> Config Class Initialized
DEBUG - 2010-06-23 11:39:55 --> Hooks Class Initialized
DEBUG - 2010-06-23 11:39:56 --> URI Class Initialized
DEBUG - 2010-06-23 11:39:56 --> Router Class Initialized
DEBUG - 2010-06-23 11:39:56 --> Output Class Initialized
DEBUG - 2010-06-23 11:39:56 --> Input Class Initialized
DEBUG - 2010-06-23 11:39:56 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 11:39:56 --> Language Class Initialized
DEBUG - 2010-06-23 11:39:56 --> Loader Class Initialized
DEBUG - 2010-06-23 11:39:56 --> Helper loaded: object_helper
DEBUG - 2010-06-23 11:39:56 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 11:39:56 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:39:56 --> Session Class Initialized
DEBUG - 2010-06-23 11:39:56 --> Helper loaded: string_helper
DEBUG - 2010-06-23 11:39:56 --> Session routines successfully run
DEBUG - 2010-06-23 11:39:56 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:39:56 --> Controller Class Initialized
DEBUG - 2010-06-23 11:39:56 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 11:39:57 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 11:39:57 --> Database Driver Class Initialized
DEBUG - 2010-06-23 11:39:57 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 11:39:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:39:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:39:57 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 11:39:57 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 11:39:57 --> 無法刪除Domain
DEBUG - 2010-06-23 11:46:33 --> Config Class Initialized
DEBUG - 2010-06-23 11:46:33 --> Hooks Class Initialized
DEBUG - 2010-06-23 11:46:33 --> URI Class Initialized
DEBUG - 2010-06-23 11:46:33 --> Config Class Initialized
DEBUG - 2010-06-23 11:46:33 --> Router Class Initialized
DEBUG - 2010-06-23 11:46:33 --> Hooks Class Initialized
DEBUG - 2010-06-23 11:46:33 --> Output Class Initialized
DEBUG - 2010-06-23 11:46:33 --> URI Class Initialized
DEBUG - 2010-06-23 11:46:33 --> Input Class Initialized
DEBUG - 2010-06-23 11:46:33 --> Router Class Initialized
DEBUG - 2010-06-23 11:46:33 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 11:46:33 --> Output Class Initialized
DEBUG - 2010-06-23 11:46:33 --> Language Class Initialized
DEBUG - 2010-06-23 11:46:33 --> Input Class Initialized
DEBUG - 2010-06-23 11:46:33 --> Loader Class Initialized
DEBUG - 2010-06-23 11:46:33 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 11:46:33 --> Language Class Initialized
DEBUG - 2010-06-23 11:46:33 --> Helper loaded: object_helper
DEBUG - 2010-06-23 11:46:33 --> Loader Class Initialized
DEBUG - 2010-06-23 11:46:33 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 11:46:33 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:46:33 --> Helper loaded: object_helper
DEBUG - 2010-06-23 11:46:34 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 11:46:34 --> Session Class Initialized
DEBUG - 2010-06-23 11:46:34 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:46:34 --> Session Class Initialized
DEBUG - 2010-06-23 11:46:34 --> Helper loaded: string_helper
DEBUG - 2010-06-23 11:46:34 --> Helper loaded: string_helper
DEBUG - 2010-06-23 11:46:34 --> Session routines successfully run
DEBUG - 2010-06-23 11:46:34 --> Session routines successfully run
DEBUG - 2010-06-23 11:46:34 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:46:34 --> Controller Class Initialized
DEBUG - 2010-06-23 11:46:34 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:46:34 --> Controller Class Initialized
DEBUG - 2010-06-23 11:46:34 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 11:46:34 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 11:46:34 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 11:46:34 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 11:46:34 --> Database Driver Class Initialized
DEBUG - 2010-06-23 11:46:34 --> Database Driver Class Initialized
DEBUG - 2010-06-23 11:46:34 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 11:46:34 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 11:46:34 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 11:46:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:46:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:46:35 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:46:35 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 11:46:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:46:35 --> User Agent Class Initialized
DEBUG - 2010-06-23 11:46:35 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 11:46:35 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 11:46:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:46:35 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
ERROR - 2010-06-23 11:46:35 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
DEBUG - 2010-06-23 11:46:35 --> Final output sent to browser
ERROR - 2010-06-23 11:46:35 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
DEBUG - 2010-06-23 11:46:35 --> Total execution time: 2.1945
DEBUG - 2010-06-23 11:46:35 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 11:46:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:46:35 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 11:46:35 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  null value in column &quot;name&quot; violates not-null constraint D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-23 11:46:35 --> DB Transaction Failure
ERROR - 2010-06-23 11:46:35 --> Query error: ERROR:  null value in column "name" violates not-null constraint
DEBUG - 2010-06-23 11:46:35 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-06-23 11:46:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-23 11:56:33 --> Config Class Initialized
DEBUG - 2010-06-23 11:56:33 --> Hooks Class Initialized
DEBUG - 2010-06-23 11:56:33 --> URI Class Initialized
DEBUG - 2010-06-23 11:56:33 --> Router Class Initialized
DEBUG - 2010-06-23 11:56:33 --> Output Class Initialized
DEBUG - 2010-06-23 11:56:33 --> Input Class Initialized
DEBUG - 2010-06-23 11:56:33 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 11:56:33 --> Language Class Initialized
DEBUG - 2010-06-23 11:56:33 --> Loader Class Initialized
DEBUG - 2010-06-23 11:56:33 --> Helper loaded: object_helper
DEBUG - 2010-06-23 11:56:33 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 11:56:33 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:56:33 --> Session Class Initialized
DEBUG - 2010-06-23 11:56:34 --> Helper loaded: string_helper
DEBUG - 2010-06-23 11:56:34 --> Session routines successfully run
DEBUG - 2010-06-23 11:56:34 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:56:34 --> Controller Class Initialized
DEBUG - 2010-06-23 11:56:34 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 11:56:34 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 11:56:34 --> Database Driver Class Initialized
DEBUG - 2010-06-23 11:56:34 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 11:56:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:56:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:56:34 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 11:56:35 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 11:56:35 --> Final output sent to browser
DEBUG - 2010-06-23 11:56:35 --> Total execution time: 1.9803
DEBUG - 2010-06-23 11:57:29 --> Config Class Initialized
DEBUG - 2010-06-23 11:57:30 --> Hooks Class Initialized
DEBUG - 2010-06-23 11:57:30 --> URI Class Initialized
DEBUG - 2010-06-23 11:57:30 --> Router Class Initialized
DEBUG - 2010-06-23 11:57:30 --> Output Class Initialized
DEBUG - 2010-06-23 11:57:30 --> Input Class Initialized
DEBUG - 2010-06-23 11:57:30 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 11:57:30 --> Language Class Initialized
DEBUG - 2010-06-23 11:57:30 --> Loader Class Initialized
DEBUG - 2010-06-23 11:57:30 --> Helper loaded: object_helper
DEBUG - 2010-06-23 11:57:30 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 11:57:30 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:57:30 --> Session Class Initialized
DEBUG - 2010-06-23 11:57:30 --> Helper loaded: string_helper
DEBUG - 2010-06-23 11:57:30 --> Session routines successfully run
DEBUG - 2010-06-23 11:57:30 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:57:31 --> Controller Class Initialized
DEBUG - 2010-06-23 11:57:31 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 11:57:31 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 11:57:31 --> Database Driver Class Initialized
DEBUG - 2010-06-23 11:57:31 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 11:57:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:57:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:57:31 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 11:57:31 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 11:57:31 --> Final output sent to browser
DEBUG - 2010-06-23 11:57:31 --> Total execution time: 1.9449
DEBUG - 2010-06-23 11:59:02 --> Config Class Initialized
DEBUG - 2010-06-23 11:59:02 --> Hooks Class Initialized
DEBUG - 2010-06-23 11:59:02 --> URI Class Initialized
DEBUG - 2010-06-23 11:59:02 --> Router Class Initialized
DEBUG - 2010-06-23 11:59:02 --> Output Class Initialized
DEBUG - 2010-06-23 11:59:02 --> Input Class Initialized
DEBUG - 2010-06-23 11:59:02 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 11:59:02 --> Language Class Initialized
DEBUG - 2010-06-23 11:59:02 --> Loader Class Initialized
DEBUG - 2010-06-23 11:59:02 --> Helper loaded: object_helper
DEBUG - 2010-06-23 11:59:02 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 11:59:02 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:59:02 --> Session Class Initialized
DEBUG - 2010-06-23 11:59:03 --> Helper loaded: string_helper
DEBUG - 2010-06-23 11:59:03 --> Session routines successfully run
DEBUG - 2010-06-23 11:59:03 --> Helper loaded: context_helper
DEBUG - 2010-06-23 11:59:03 --> Controller Class Initialized
DEBUG - 2010-06-23 11:59:03 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 11:59:03 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 11:59:03 --> Database Driver Class Initialized
DEBUG - 2010-06-23 11:59:03 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 11:59:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:59:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 11:59:03 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 11:59:04 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 11:59:04 --> Final output sent to browser
DEBUG - 2010-06-23 11:59:04 --> Total execution time: 1.9744
DEBUG - 2010-06-23 12:01:44 --> Config Class Initialized
DEBUG - 2010-06-23 12:01:44 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:01:44 --> URI Class Initialized
DEBUG - 2010-06-23 12:01:44 --> Router Class Initialized
DEBUG - 2010-06-23 12:01:44 --> Output Class Initialized
DEBUG - 2010-06-23 12:01:44 --> Input Class Initialized
DEBUG - 2010-06-23 12:01:45 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:01:45 --> Language Class Initialized
DEBUG - 2010-06-23 12:02:08 --> Config Class Initialized
DEBUG - 2010-06-23 12:02:08 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:02:08 --> URI Class Initialized
DEBUG - 2010-06-23 12:02:08 --> Router Class Initialized
DEBUG - 2010-06-23 12:02:08 --> Output Class Initialized
DEBUG - 2010-06-23 12:02:08 --> Input Class Initialized
DEBUG - 2010-06-23 12:02:08 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:02:08 --> Language Class Initialized
DEBUG - 2010-06-23 12:02:09 --> Loader Class Initialized
DEBUG - 2010-06-23 12:02:09 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:02:09 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:02:09 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:02:09 --> Session Class Initialized
DEBUG - 2010-06-23 12:02:09 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:02:09 --> Session routines successfully run
DEBUG - 2010-06-23 12:02:09 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:02:09 --> Controller Class Initialized
DEBUG - 2010-06-23 12:02:09 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:02:09 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:02:09 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:02:09 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 12:02:09 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:02:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:02:10 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:02:10 --> User Agent Class Initialized
DEBUG - 2010-06-23 12:02:10 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 12:02:10 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 12:02:10 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 12:02:10 --> User_agent class already loaded. Second attempt ignored.
INFO  - 2010-06-23 12:02:10 --> User update: (21) pudding : 
DEBUG - 2010-06-23 12:02:10 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 12:02:10 --> Final output sent to browser
DEBUG - 2010-06-23 12:02:10 --> Total execution time: 2.1968
DEBUG - 2010-06-23 12:02:57 --> Config Class Initialized
DEBUG - 2010-06-23 12:02:57 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:02:57 --> URI Class Initialized
DEBUG - 2010-06-23 12:02:58 --> Router Class Initialized
DEBUG - 2010-06-23 12:02:58 --> Output Class Initialized
DEBUG - 2010-06-23 12:02:58 --> Input Class Initialized
DEBUG - 2010-06-23 12:02:58 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:02:58 --> Language Class Initialized
DEBUG - 2010-06-23 12:02:58 --> Loader Class Initialized
DEBUG - 2010-06-23 12:02:58 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:02:58 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:02:58 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:02:58 --> Session Class Initialized
DEBUG - 2010-06-23 12:02:58 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:02:58 --> Session routines successfully run
DEBUG - 2010-06-23 12:02:58 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:02:58 --> Controller Class Initialized
DEBUG - 2010-06-23 12:02:59 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:02:59 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:02:59 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:02:59 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 12:02:59 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:02:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:02:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:02:59 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 12:02:59 --> User Agent Class Initialized
DEBUG - 2010-06-23 12:02:59 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 12:02:59 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 12:02:59 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-23 12:02:59 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
DEBUG - 2010-06-23 12:03:00 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 12:03:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:03:00 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 12:03:00 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  null value in column &quot;name&quot; violates not-null constraint D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-23 12:03:00 --> DB Transaction Failure
ERROR - 2010-06-23 12:03:00 --> Query error: ERROR:  null value in column "name" violates not-null constraint
DEBUG - 2010-06-23 12:03:00 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-06-23 12:03:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-23 12:05:24 --> Config Class Initialized
DEBUG - 2010-06-23 12:05:24 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:05:24 --> URI Class Initialized
DEBUG - 2010-06-23 12:05:24 --> Router Class Initialized
DEBUG - 2010-06-23 12:05:24 --> Output Class Initialized
DEBUG - 2010-06-23 12:05:24 --> Input Class Initialized
DEBUG - 2010-06-23 12:05:24 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:05:24 --> Language Class Initialized
DEBUG - 2010-06-23 12:05:24 --> Loader Class Initialized
DEBUG - 2010-06-23 12:05:24 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:05:24 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:05:24 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:05:24 --> Session Class Initialized
DEBUG - 2010-06-23 12:05:24 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:05:25 --> Session routines successfully run
DEBUG - 2010-06-23 12:05:25 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:05:25 --> Controller Class Initialized
DEBUG - 2010-06-23 12:05:25 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:05:25 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:05:25 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:05:25 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:05:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:05:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:05:25 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 12:05:25 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 12:05:25 --> Final output sent to browser
DEBUG - 2010-06-23 12:05:25 --> Total execution time: 1.9414
DEBUG - 2010-06-23 12:05:59 --> Config Class Initialized
DEBUG - 2010-06-23 12:05:59 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:05:59 --> URI Class Initialized
DEBUG - 2010-06-23 12:05:59 --> Router Class Initialized
DEBUG - 2010-06-23 12:05:59 --> Output Class Initialized
DEBUG - 2010-06-23 12:05:59 --> Input Class Initialized
DEBUG - 2010-06-23 12:06:00 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:06:00 --> Language Class Initialized
DEBUG - 2010-06-23 12:06:00 --> Loader Class Initialized
DEBUG - 2010-06-23 12:06:00 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:06:00 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:06:00 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:06:00 --> Session Class Initialized
DEBUG - 2010-06-23 12:06:00 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:06:00 --> Session routines successfully run
DEBUG - 2010-06-23 12:06:00 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:06:00 --> Controller Class Initialized
DEBUG - 2010-06-23 12:06:00 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:06:00 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:06:00 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:06:01 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:06:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:06:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:06:01 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 12:06:01 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 12:06:01 --> Final output sent to browser
DEBUG - 2010-06-23 12:06:01 --> Total execution time: 1.9246
DEBUG - 2010-06-23 12:07:04 --> Config Class Initialized
DEBUG - 2010-06-23 12:07:04 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:07:04 --> URI Class Initialized
DEBUG - 2010-06-23 12:07:04 --> Router Class Initialized
DEBUG - 2010-06-23 12:07:04 --> Output Class Initialized
DEBUG - 2010-06-23 12:07:04 --> Input Class Initialized
DEBUG - 2010-06-23 12:07:04 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:07:04 --> Language Class Initialized
DEBUG - 2010-06-23 12:07:04 --> Loader Class Initialized
DEBUG - 2010-06-23 12:07:04 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:07:04 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:07:04 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:07:04 --> Session Class Initialized
DEBUG - 2010-06-23 12:07:05 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:07:05 --> Session routines successfully run
DEBUG - 2010-06-23 12:07:05 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:07:05 --> Controller Class Initialized
DEBUG - 2010-06-23 12:07:05 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:07:05 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:07:05 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:07:05 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:07:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:07:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:07:05 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 12:07:06 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 12:07:06 --> Final output sent to browser
DEBUG - 2010-06-23 12:07:06 --> Total execution time: 1.9872
DEBUG - 2010-06-23 12:07:52 --> Config Class Initialized
DEBUG - 2010-06-23 12:07:52 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:07:52 --> URI Class Initialized
DEBUG - 2010-06-23 12:07:52 --> Router Class Initialized
DEBUG - 2010-06-23 12:07:52 --> Output Class Initialized
DEBUG - 2010-06-23 12:07:52 --> Input Class Initialized
DEBUG - 2010-06-23 12:07:52 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:07:52 --> Language Class Initialized
DEBUG - 2010-06-23 12:07:52 --> Loader Class Initialized
DEBUG - 2010-06-23 12:07:53 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:07:53 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:07:53 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:07:53 --> Session Class Initialized
DEBUG - 2010-06-23 12:07:53 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:07:53 --> Session routines successfully run
DEBUG - 2010-06-23 12:07:53 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:07:53 --> Controller Class Initialized
DEBUG - 2010-06-23 12:07:53 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:07:53 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:07:53 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:07:53 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:07:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:07:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:07:54 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 12:07:54 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 12:07:54 --> Final output sent to browser
DEBUG - 2010-06-23 12:07:54 --> Total execution time: 2.1693
DEBUG - 2010-06-23 12:11:55 --> Config Class Initialized
DEBUG - 2010-06-23 12:11:55 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:11:55 --> URI Class Initialized
DEBUG - 2010-06-23 12:11:55 --> Router Class Initialized
DEBUG - 2010-06-23 12:11:55 --> Output Class Initialized
DEBUG - 2010-06-23 12:11:55 --> Input Class Initialized
DEBUG - 2010-06-23 12:11:56 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:11:56 --> Language Class Initialized
DEBUG - 2010-06-23 12:11:56 --> Loader Class Initialized
DEBUG - 2010-06-23 12:11:56 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:11:56 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:11:56 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:11:56 --> Session Class Initialized
DEBUG - 2010-06-23 12:11:56 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:11:56 --> Session routines successfully run
DEBUG - 2010-06-23 12:11:56 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:11:56 --> Controller Class Initialized
DEBUG - 2010-06-23 12:11:56 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:11:56 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:11:57 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:11:57 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 12:11:57 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:11:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:11:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:11:57 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 12:11:57 --> User Agent Class Initialized
DEBUG - 2010-06-23 12:11:57 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 12:11:57 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 12:11:57 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-23 12:11:57 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
DEBUG - 2010-06-23 12:11:57 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 12:11:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:11:57 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 12:11:58 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  null value in column &quot;name&quot; violates not-null constraint D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-23 12:11:58 --> DB Transaction Failure
ERROR - 2010-06-23 12:11:58 --> Query error: ERROR:  null value in column "name" violates not-null constraint
DEBUG - 2010-06-23 12:11:58 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-06-23 12:11:58 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-23 12:12:57 --> Config Class Initialized
DEBUG - 2010-06-23 12:12:57 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:12:57 --> URI Class Initialized
DEBUG - 2010-06-23 12:12:57 --> Router Class Initialized
DEBUG - 2010-06-23 12:12:57 --> Output Class Initialized
DEBUG - 2010-06-23 12:12:57 --> Input Class Initialized
DEBUG - 2010-06-23 12:12:57 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:12:57 --> Language Class Initialized
DEBUG - 2010-06-23 12:12:57 --> Loader Class Initialized
DEBUG - 2010-06-23 12:12:58 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:12:58 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:12:58 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:12:58 --> Session Class Initialized
DEBUG - 2010-06-23 12:12:58 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:12:58 --> Session routines successfully run
DEBUG - 2010-06-23 12:12:58 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:12:58 --> Controller Class Initialized
DEBUG - 2010-06-23 12:12:58 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:12:58 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:12:58 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:12:58 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 12:12:58 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:12:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:12:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:12:59 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 12:12:59 --> User Agent Class Initialized
DEBUG - 2010-06-23 12:12:59 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 12:12:59 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 12:12:59 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-23 12:12:59 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
DEBUG - 2010-06-23 12:12:59 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 12:12:59 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 12:12:59 --> Final output sent to browser
DEBUG - 2010-06-23 12:12:59 --> Total execution time: 2.4078
DEBUG - 2010-06-23 12:15:48 --> Config Class Initialized
DEBUG - 2010-06-23 12:15:49 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:15:49 --> URI Class Initialized
DEBUG - 2010-06-23 12:15:49 --> Router Class Initialized
DEBUG - 2010-06-23 12:15:49 --> Output Class Initialized
DEBUG - 2010-06-23 12:15:49 --> Input Class Initialized
DEBUG - 2010-06-23 12:15:49 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:15:49 --> Language Class Initialized
DEBUG - 2010-06-23 12:15:49 --> Loader Class Initialized
DEBUG - 2010-06-23 12:15:49 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:15:49 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:15:49 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:15:49 --> Session Class Initialized
DEBUG - 2010-06-23 12:15:49 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:15:50 --> Session routines successfully run
DEBUG - 2010-06-23 12:15:50 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:15:50 --> Controller Class Initialized
DEBUG - 2010-06-23 12:15:50 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:15:50 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:15:50 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:15:50 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 12:15:50 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:15:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:17:00 --> Config Class Initialized
DEBUG - 2010-06-23 12:17:00 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:17:00 --> URI Class Initialized
DEBUG - 2010-06-23 12:17:00 --> Router Class Initialized
DEBUG - 2010-06-23 12:17:00 --> Output Class Initialized
DEBUG - 2010-06-23 12:17:00 --> Input Class Initialized
DEBUG - 2010-06-23 12:17:00 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:17:00 --> Language Class Initialized
DEBUG - 2010-06-23 12:17:00 --> Loader Class Initialized
DEBUG - 2010-06-23 12:17:01 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:17:01 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:17:01 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:17:01 --> Session Class Initialized
DEBUG - 2010-06-23 12:17:01 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:17:01 --> Session routines successfully run
DEBUG - 2010-06-23 12:17:01 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:17:01 --> Controller Class Initialized
DEBUG - 2010-06-23 12:17:01 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:17:01 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:17:01 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:17:01 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 12:17:02 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:17:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:17:02 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:17:02 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 12:17:02 --> User Agent Class Initialized
DEBUG - 2010-06-23 12:17:02 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 12:17:02 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 12:17:02 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-23 12:17:02 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
DEBUG - 2010-06-23 12:17:02 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 12:17:02 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 12:17:02 --> Final output sent to browser
DEBUG - 2010-06-23 12:17:02 --> Total execution time: 2.5222
DEBUG - 2010-06-23 12:17:35 --> Config Class Initialized
DEBUG - 2010-06-23 12:17:35 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:17:35 --> URI Class Initialized
DEBUG - 2010-06-23 12:17:35 --> Router Class Initialized
DEBUG - 2010-06-23 12:17:36 --> Output Class Initialized
DEBUG - 2010-06-23 12:17:36 --> Input Class Initialized
DEBUG - 2010-06-23 12:17:36 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:17:36 --> Language Class Initialized
DEBUG - 2010-06-23 12:17:36 --> Loader Class Initialized
DEBUG - 2010-06-23 12:17:36 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:17:36 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:17:36 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:17:36 --> Session Class Initialized
DEBUG - 2010-06-23 12:17:36 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:17:36 --> Session routines successfully run
DEBUG - 2010-06-23 12:17:36 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:17:37 --> Controller Class Initialized
DEBUG - 2010-06-23 12:17:37 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:17:37 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:17:37 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:17:37 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 12:17:37 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:17:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:17:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:17:37 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 12:17:37 --> User Agent Class Initialized
DEBUG - 2010-06-23 12:17:37 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 12:17:37 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 12:17:37 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-23 12:17:38 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
DEBUG - 2010-06-23 12:17:38 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 12:17:38 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 12:17:38 --> Final output sent to browser
DEBUG - 2010-06-23 12:17:38 --> Total execution time: 2.5488
DEBUG - 2010-06-23 12:18:36 --> Config Class Initialized
DEBUG - 2010-06-23 12:18:36 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:18:36 --> URI Class Initialized
DEBUG - 2010-06-23 12:18:36 --> Router Class Initialized
DEBUG - 2010-06-23 12:18:36 --> Output Class Initialized
DEBUG - 2010-06-23 12:18:36 --> Input Class Initialized
DEBUG - 2010-06-23 12:18:36 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:18:36 --> Language Class Initialized
DEBUG - 2010-06-23 12:18:36 --> Loader Class Initialized
DEBUG - 2010-06-23 12:18:36 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:18:37 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:18:37 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:18:37 --> Session Class Initialized
DEBUG - 2010-06-23 12:18:37 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:18:37 --> Session routines successfully run
DEBUG - 2010-06-23 12:18:37 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:18:37 --> Controller Class Initialized
DEBUG - 2010-06-23 12:18:37 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:18:37 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:18:37 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:18:37 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 12:18:37 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:18:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:18:38 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:18:38 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 12:18:38 --> User Agent Class Initialized
DEBUG - 2010-06-23 12:18:38 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 12:18:38 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 12:18:38 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-23 12:18:38 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
DEBUG - 2010-06-23 12:18:38 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 12:18:38 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 12:18:38 --> Final output sent to browser
DEBUG - 2010-06-23 12:18:38 --> Total execution time: 2.7097
DEBUG - 2010-06-23 12:19:12 --> Config Class Initialized
DEBUG - 2010-06-23 12:19:13 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:19:13 --> URI Class Initialized
DEBUG - 2010-06-23 12:19:13 --> Router Class Initialized
DEBUG - 2010-06-23 12:19:13 --> Output Class Initialized
DEBUG - 2010-06-23 12:19:13 --> Input Class Initialized
DEBUG - 2010-06-23 12:19:13 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:19:13 --> Language Class Initialized
DEBUG - 2010-06-23 12:19:13 --> Loader Class Initialized
DEBUG - 2010-06-23 12:19:13 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:19:13 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:19:13 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:19:13 --> Session Class Initialized
DEBUG - 2010-06-23 12:19:14 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:19:14 --> Session routines successfully run
DEBUG - 2010-06-23 12:19:14 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:19:14 --> Controller Class Initialized
DEBUG - 2010-06-23 12:19:14 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:19:14 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:19:14 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:19:14 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 12:19:14 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:19:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:19:14 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:19:14 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 12:19:14 --> User Agent Class Initialized
DEBUG - 2010-06-23 12:19:15 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 12:19:15 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 12:19:15 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-23 12:19:15 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
DEBUG - 2010-06-23 12:19:15 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 12:19:15 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 12:19:15 --> Final output sent to browser
DEBUG - 2010-06-23 12:19:15 --> Total execution time: 2.5884
DEBUG - 2010-06-23 12:19:36 --> Config Class Initialized
DEBUG - 2010-06-23 12:19:36 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:19:36 --> URI Class Initialized
DEBUG - 2010-06-23 12:19:36 --> Router Class Initialized
DEBUG - 2010-06-23 12:19:36 --> Output Class Initialized
DEBUG - 2010-06-23 12:19:36 --> Input Class Initialized
DEBUG - 2010-06-23 12:19:36 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:19:36 --> Language Class Initialized
DEBUG - 2010-06-23 12:19:37 --> Loader Class Initialized
DEBUG - 2010-06-23 12:19:37 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:19:37 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:19:37 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:19:37 --> Session Class Initialized
DEBUG - 2010-06-23 12:19:37 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:19:37 --> Session routines successfully run
DEBUG - 2010-06-23 12:19:37 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:19:37 --> Controller Class Initialized
DEBUG - 2010-06-23 12:19:37 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:19:37 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:19:37 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:19:38 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 12:19:38 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:19:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:19:38 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:19:38 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 12:19:38 --> User Agent Class Initialized
DEBUG - 2010-06-23 12:19:38 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 12:19:38 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 12:19:38 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-23 12:19:38 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-23 12:19:38 --> Severity: Warning  --> Missing argument 1 for KALSActor::set_name(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php on line 148 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\KALSActor.php 92
ERROR - 2010-06-23 12:19:38 --> Severity: Notice  --> Undefined variable: name D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\KALSActor.php 94
DEBUG - 2010-06-23 12:19:38 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 12:19:39 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 12:19:39 --> Final output sent to browser
DEBUG - 2010-06-23 12:19:39 --> Total execution time: 2.7339
DEBUG - 2010-06-23 12:19:52 --> Config Class Initialized
DEBUG - 2010-06-23 12:19:52 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:19:53 --> URI Class Initialized
DEBUG - 2010-06-23 12:19:53 --> Router Class Initialized
DEBUG - 2010-06-23 12:19:53 --> Output Class Initialized
DEBUG - 2010-06-23 12:19:53 --> Input Class Initialized
DEBUG - 2010-06-23 12:19:53 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:19:53 --> Language Class Initialized
DEBUG - 2010-06-23 12:19:53 --> Loader Class Initialized
DEBUG - 2010-06-23 12:19:53 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:19:53 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:19:53 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:19:53 --> Session Class Initialized
DEBUG - 2010-06-23 12:19:54 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:19:54 --> Session routines successfully run
DEBUG - 2010-06-23 12:19:54 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:19:54 --> Controller Class Initialized
DEBUG - 2010-06-23 12:19:54 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:19:54 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:19:54 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:19:54 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 12:19:54 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:19:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:19:54 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:19:54 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 12:19:55 --> User Agent Class Initialized
DEBUG - 2010-06-23 12:19:55 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 12:19:55 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 12:19:55 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-23 12:19:55 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-23 12:19:55 --> Severity: Notice  --> Undefined property: stdClass::$name D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 148
DEBUG - 2010-06-23 12:19:55 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 12:19:55 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 12:19:55 --> Final output sent to browser
DEBUG - 2010-06-23 12:19:55 --> Total execution time: 2.7931
DEBUG - 2010-06-23 12:20:18 --> Config Class Initialized
DEBUG - 2010-06-23 12:20:18 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:20:18 --> URI Class Initialized
DEBUG - 2010-06-23 12:20:18 --> Router Class Initialized
DEBUG - 2010-06-23 12:20:18 --> Output Class Initialized
DEBUG - 2010-06-23 12:20:19 --> Input Class Initialized
DEBUG - 2010-06-23 12:20:19 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:20:19 --> Language Class Initialized
DEBUG - 2010-06-23 12:20:19 --> Loader Class Initialized
DEBUG - 2010-06-23 12:20:19 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:20:19 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:20:19 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:20:19 --> Session Class Initialized
DEBUG - 2010-06-23 12:20:19 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:20:19 --> Session routines successfully run
DEBUG - 2010-06-23 12:20:19 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:20:19 --> Controller Class Initialized
DEBUG - 2010-06-23 12:20:19 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:20:20 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:20:20 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:20:20 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 12:20:20 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:20:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:20:20 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:20:20 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 12:20:20 --> User Agent Class Initialized
DEBUG - 2010-06-23 12:20:20 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 12:20:20 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 12:20:20 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-23 12:20:20 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
DEBUG - 2010-06-23 12:20:21 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 12:20:21 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 12:20:21 --> Final output sent to browser
DEBUG - 2010-06-23 12:20:21 --> Total execution time: 2.6327
DEBUG - 2010-06-23 12:21:35 --> Config Class Initialized
DEBUG - 2010-06-23 12:21:35 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:21:35 --> URI Class Initialized
DEBUG - 2010-06-23 12:21:35 --> Router Class Initialized
DEBUG - 2010-06-23 12:21:35 --> Output Class Initialized
DEBUG - 2010-06-23 12:21:36 --> Input Class Initialized
DEBUG - 2010-06-23 12:21:36 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:21:36 --> Language Class Initialized
DEBUG - 2010-06-23 12:21:36 --> Loader Class Initialized
DEBUG - 2010-06-23 12:21:36 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:21:36 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:21:36 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:21:36 --> Session Class Initialized
DEBUG - 2010-06-23 12:21:36 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:21:36 --> Session routines successfully run
DEBUG - 2010-06-23 12:21:36 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:21:36 --> Controller Class Initialized
DEBUG - 2010-06-23 12:21:36 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:21:37 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:21:37 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:21:37 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 12:21:37 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:21:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:21:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:21:37 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 12:21:37 --> User Agent Class Initialized
DEBUG - 2010-06-23 12:21:37 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 12:21:37 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 12:21:37 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-23 12:21:37 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
DEBUG - 2010-06-23 12:22:47 --> Config Class Initialized
DEBUG - 2010-06-23 12:22:47 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:22:47 --> URI Class Initialized
DEBUG - 2010-06-23 12:22:47 --> Router Class Initialized
DEBUG - 2010-06-23 12:22:47 --> Output Class Initialized
DEBUG - 2010-06-23 12:22:48 --> Input Class Initialized
DEBUG - 2010-06-23 12:22:48 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:22:48 --> Language Class Initialized
DEBUG - 2010-06-23 12:22:48 --> Loader Class Initialized
DEBUG - 2010-06-23 12:22:48 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:22:48 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:22:48 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:22:48 --> Session Class Initialized
DEBUG - 2010-06-23 12:22:48 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:22:48 --> Session routines successfully run
DEBUG - 2010-06-23 12:22:48 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:22:48 --> Controller Class Initialized
DEBUG - 2010-06-23 12:22:49 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:22:49 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:22:49 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:22:49 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 12:22:49 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:22:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:22:49 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:22:49 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 12:22:49 --> User Agent Class Initialized
DEBUG - 2010-06-23 12:22:49 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 12:22:49 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 12:22:49 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-23 12:22:50 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
DEBUG - 2010-06-23 12:22:50 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 12:22:50 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 12:22:50 --> Final output sent to browser
DEBUG - 2010-06-23 12:22:50 --> Total execution time: 2.6613
DEBUG - 2010-06-23 12:23:27 --> Config Class Initialized
DEBUG - 2010-06-23 12:23:27 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:23:27 --> URI Class Initialized
DEBUG - 2010-06-23 12:23:27 --> Router Class Initialized
DEBUG - 2010-06-23 12:23:27 --> Output Class Initialized
DEBUG - 2010-06-23 12:23:27 --> Input Class Initialized
DEBUG - 2010-06-23 12:23:27 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:23:27 --> Language Class Initialized
DEBUG - 2010-06-23 12:23:28 --> Loader Class Initialized
DEBUG - 2010-06-23 12:23:28 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:23:28 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:23:28 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:23:28 --> Session Class Initialized
DEBUG - 2010-06-23 12:23:28 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:23:28 --> Session routines successfully run
DEBUG - 2010-06-23 12:23:28 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:23:28 --> Controller Class Initialized
DEBUG - 2010-06-23 12:23:28 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:23:28 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:23:29 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:23:29 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 12:23:29 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:23:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:23:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:23:29 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 12:23:29 --> User Agent Class Initialized
DEBUG - 2010-06-23 12:23:29 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 12:23:29 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 12:23:29 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 42
ERROR - 2010-06-23 12:23:29 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 42
DEBUG - 2010-06-23 12:23:29 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 12:23:30 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 12:23:30 --> Final output sent to browser
DEBUG - 2010-06-23 12:23:30 --> Total execution time: 2.7552
DEBUG - 2010-06-23 12:23:50 --> Config Class Initialized
DEBUG - 2010-06-23 12:23:50 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:23:50 --> URI Class Initialized
DEBUG - 2010-06-23 12:23:50 --> Router Class Initialized
DEBUG - 2010-06-23 12:23:51 --> Output Class Initialized
DEBUG - 2010-06-23 12:23:51 --> Input Class Initialized
DEBUG - 2010-06-23 12:23:51 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:23:51 --> Language Class Initialized
DEBUG - 2010-06-23 12:23:51 --> Loader Class Initialized
DEBUG - 2010-06-23 12:23:51 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:23:51 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:23:51 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:23:51 --> Session Class Initialized
DEBUG - 2010-06-23 12:23:51 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:23:51 --> Session routines successfully run
DEBUG - 2010-06-23 12:23:51 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:23:52 --> Controller Class Initialized
DEBUG - 2010-06-23 12:23:52 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:23:52 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:23:52 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:23:52 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 12:23:52 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:23:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:23:52 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:23:52 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 12:23:52 --> User Agent Class Initialized
DEBUG - 2010-06-23 12:23:52 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 12:23:52 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 12:23:53 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 43
ERROR - 2010-06-23 12:23:53 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 43
DEBUG - 2010-06-23 12:23:53 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 12:23:53 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 12:23:53 --> Final output sent to browser
DEBUG - 2010-06-23 12:23:53 --> Total execution time: 2.7636
DEBUG - 2010-06-23 12:24:20 --> Config Class Initialized
DEBUG - 2010-06-23 12:24:20 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:24:20 --> URI Class Initialized
DEBUG - 2010-06-23 12:24:20 --> Router Class Initialized
DEBUG - 2010-06-23 12:24:20 --> Output Class Initialized
DEBUG - 2010-06-23 12:24:20 --> Input Class Initialized
DEBUG - 2010-06-23 12:24:20 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:24:20 --> Language Class Initialized
DEBUG - 2010-06-23 12:24:21 --> Loader Class Initialized
DEBUG - 2010-06-23 12:24:21 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:24:21 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:24:21 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:24:21 --> Session Class Initialized
DEBUG - 2010-06-23 12:24:21 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:24:21 --> Session routines successfully run
DEBUG - 2010-06-23 12:24:21 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:24:21 --> Controller Class Initialized
DEBUG - 2010-06-23 12:24:21 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:24:21 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:24:21 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:24:22 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 12:24:22 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:24:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:24:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:24:22 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 12:24:22 --> User Agent Class Initialized
DEBUG - 2010-06-23 12:24:22 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 12:24:22 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 12:24:22 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 43
ERROR - 2010-06-23 12:24:22 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 43
DEBUG - 2010-06-23 12:24:22 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 12:24:23 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 12:24:23 --> Final output sent to browser
DEBUG - 2010-06-23 12:24:23 --> Total execution time: 2.7334
DEBUG - 2010-06-23 12:24:59 --> Config Class Initialized
DEBUG - 2010-06-23 12:24:59 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:24:59 --> URI Class Initialized
DEBUG - 2010-06-23 12:24:59 --> Router Class Initialized
DEBUG - 2010-06-23 12:24:59 --> Output Class Initialized
DEBUG - 2010-06-23 12:24:59 --> Input Class Initialized
DEBUG - 2010-06-23 12:25:00 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:25:00 --> Language Class Initialized
DEBUG - 2010-06-23 12:25:00 --> Loader Class Initialized
DEBUG - 2010-06-23 12:25:00 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:25:00 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:25:00 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:25:00 --> Session Class Initialized
DEBUG - 2010-06-23 12:25:00 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:25:00 --> Session routines successfully run
DEBUG - 2010-06-23 12:25:00 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:25:00 --> Controller Class Initialized
DEBUG - 2010-06-23 12:25:00 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:25:01 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:25:01 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:25:01 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 12:25:01 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:25:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:25:01 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:25:01 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 12:25:01 --> User Agent Class Initialized
DEBUG - 2010-06-23 12:25:01 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 12:25:01 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 12:25:01 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 42
ERROR - 2010-06-23 12:25:02 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 42
DEBUG - 2010-06-23 12:25:02 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 12:25:02 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 12:25:02 --> Final output sent to browser
DEBUG - 2010-06-23 12:25:02 --> Total execution time: 2.7675
DEBUG - 2010-06-23 12:25:58 --> Config Class Initialized
DEBUG - 2010-06-23 12:25:58 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:25:59 --> URI Class Initialized
DEBUG - 2010-06-23 12:25:59 --> Router Class Initialized
DEBUG - 2010-06-23 12:25:59 --> Output Class Initialized
DEBUG - 2010-06-23 12:25:59 --> Input Class Initialized
DEBUG - 2010-06-23 12:25:59 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:25:59 --> Language Class Initialized
DEBUG - 2010-06-23 12:25:59 --> Loader Class Initialized
DEBUG - 2010-06-23 12:25:59 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:25:59 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:25:59 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:25:59 --> Session Class Initialized
DEBUG - 2010-06-23 12:25:59 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:26:00 --> Session routines successfully run
DEBUG - 2010-06-23 12:26:00 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:26:00 --> Controller Class Initialized
DEBUG - 2010-06-23 12:26:00 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:26:00 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:26:00 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:26:00 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 12:26:00 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:26:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:26:00 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:26:00 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 12:26:01 --> User Agent Class Initialized
DEBUG - 2010-06-23 12:26:01 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 12:26:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:26:01 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 12:26:01 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 12:26:01 --> Final output sent to browser
DEBUG - 2010-06-23 12:26:01 --> Total execution time: 2.6312
DEBUG - 2010-06-23 12:26:35 --> Config Class Initialized
DEBUG - 2010-06-23 12:26:35 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:26:35 --> URI Class Initialized
DEBUG - 2010-06-23 12:26:35 --> Router Class Initialized
DEBUG - 2010-06-23 12:26:35 --> Output Class Initialized
DEBUG - 2010-06-23 12:26:35 --> Input Class Initialized
DEBUG - 2010-06-23 12:26:35 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:26:35 --> Language Class Initialized
DEBUG - 2010-06-23 12:26:35 --> Loader Class Initialized
DEBUG - 2010-06-23 12:26:35 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:26:36 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:26:36 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:26:36 --> Session Class Initialized
DEBUG - 2010-06-23 12:26:36 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:26:36 --> Session routines successfully run
DEBUG - 2010-06-23 12:26:36 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:26:36 --> Controller Class Initialized
DEBUG - 2010-06-23 12:26:36 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:26:36 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:26:36 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:26:36 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 12:26:37 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:26:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:26:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:26:37 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 12:26:37 --> User Agent Class Initialized
DEBUG - 2010-06-23 12:26:37 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 12:26:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:26:37 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 12:26:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:26:37 --> Domain class already loaded. Second attempt ignored.
INFO  - 2010-06-23 12:26:37 --> User update: (21) pudding : 
DEBUG - 2010-06-23 12:26:38 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 12:26:38 --> Final output sent to browser
DEBUG - 2010-06-23 12:26:38 --> Total execution time: 2.9530
DEBUG - 2010-06-23 12:27:34 --> Config Class Initialized
DEBUG - 2010-06-23 12:27:34 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:27:34 --> URI Class Initialized
DEBUG - 2010-06-23 12:27:34 --> Router Class Initialized
DEBUG - 2010-06-23 12:27:34 --> Output Class Initialized
DEBUG - 2010-06-23 12:27:34 --> Input Class Initialized
DEBUG - 2010-06-23 12:27:34 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:27:34 --> Language Class Initialized
DEBUG - 2010-06-23 12:27:34 --> Loader Class Initialized
DEBUG - 2010-06-23 12:27:35 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:27:35 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:27:35 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:27:35 --> Session Class Initialized
DEBUG - 2010-06-23 12:27:35 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:27:35 --> Session routines successfully run
DEBUG - 2010-06-23 12:27:35 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:27:35 --> Controller Class Initialized
DEBUG - 2010-06-23 12:27:35 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:27:35 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:27:35 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:27:36 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 12:27:36 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:27:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:27:36 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:27:36 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 12:27:36 --> User Agent Class Initialized
DEBUG - 2010-06-23 12:27:36 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 12:27:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:27:36 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 12:27:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:27:36 --> Domain class already loaded. Second attempt ignored.
INFO  - 2010-06-23 12:27:37 --> User update: (21) pudding : 
DEBUG - 2010-06-23 12:27:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:27:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:27:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:27:37 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:27:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:27:37 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 12:27:37 --> Final output sent to browser
DEBUG - 2010-06-23 12:27:37 --> Total execution time: 3.5383
DEBUG - 2010-06-23 12:28:25 --> Config Class Initialized
DEBUG - 2010-06-23 12:28:25 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:28:26 --> URI Class Initialized
DEBUG - 2010-06-23 12:28:26 --> Router Class Initialized
DEBUG - 2010-06-23 12:28:26 --> Output Class Initialized
DEBUG - 2010-06-23 12:28:26 --> Input Class Initialized
DEBUG - 2010-06-23 12:28:26 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:28:26 --> Language Class Initialized
DEBUG - 2010-06-23 12:28:26 --> Loader Class Initialized
DEBUG - 2010-06-23 12:28:26 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:28:26 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:28:26 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:28:26 --> Session Class Initialized
DEBUG - 2010-06-23 12:28:27 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:28:27 --> Session routines successfully run
DEBUG - 2010-06-23 12:28:27 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:28:27 --> Controller Class Initialized
DEBUG - 2010-06-23 12:28:27 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:28:27 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:28:27 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:28:27 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 12:28:27 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:28:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:28:27 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:28:28 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 12:28:28 --> User Agent Class Initialized
DEBUG - 2010-06-23 12:28:28 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 12:28:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:28:28 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 12:28:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:28:28 --> Domain class already loaded. Second attempt ignored.
INFO  - 2010-06-23 12:28:28 --> User update: (21) pudding : 
DEBUG - 2010-06-23 12:28:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:28:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:28:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:28:29 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:28:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:28:29 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 12:28:29 --> Final output sent to browser
DEBUG - 2010-06-23 12:28:29 --> Total execution time: 3.4776
DEBUG - 2010-06-23 12:28:39 --> Config Class Initialized
DEBUG - 2010-06-23 12:28:39 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:28:39 --> URI Class Initialized
DEBUG - 2010-06-23 12:28:39 --> Router Class Initialized
DEBUG - 2010-06-23 12:28:39 --> Output Class Initialized
DEBUG - 2010-06-23 12:28:39 --> Input Class Initialized
DEBUG - 2010-06-23 12:28:39 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:28:39 --> Language Class Initialized
DEBUG - 2010-06-23 12:28:40 --> Loader Class Initialized
DEBUG - 2010-06-23 12:28:40 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:28:40 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:28:40 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:28:40 --> Session Class Initialized
DEBUG - 2010-06-23 12:28:40 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:28:40 --> Session routines successfully run
DEBUG - 2010-06-23 12:28:40 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:28:40 --> Controller Class Initialized
DEBUG - 2010-06-23 12:28:40 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:28:40 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:28:41 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:28:41 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 12:28:41 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:28:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:28:41 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:28:41 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 12:28:41 --> User Agent Class Initialized
DEBUG - 2010-06-23 12:28:41 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 12:28:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:28:41 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 12:28:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:28:42 --> Domain class already loaded. Second attempt ignored.
INFO  - 2010-06-23 12:28:42 --> User update: (21) pudding : 
DEBUG - 2010-06-23 12:28:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:28:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:28:42 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:28:42 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:28:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:28:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:28:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:28:42 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 12:28:42 --> Final output sent to browser
DEBUG - 2010-06-23 12:28:43 --> Total execution time: 3.6597
DEBUG - 2010-06-23 12:29:29 --> Config Class Initialized
DEBUG - 2010-06-23 12:29:29 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:29:29 --> URI Class Initialized
DEBUG - 2010-06-23 12:29:29 --> Router Class Initialized
DEBUG - 2010-06-23 12:29:29 --> Output Class Initialized
DEBUG - 2010-06-23 12:29:29 --> Input Class Initialized
DEBUG - 2010-06-23 12:29:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:29:30 --> Language Class Initialized
DEBUG - 2010-06-23 12:29:30 --> Loader Class Initialized
DEBUG - 2010-06-23 12:29:30 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:29:30 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:29:30 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:29:30 --> Session Class Initialized
DEBUG - 2010-06-23 12:29:30 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:29:30 --> Session routines successfully run
DEBUG - 2010-06-23 12:29:30 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:29:30 --> Controller Class Initialized
DEBUG - 2010-06-23 12:29:30 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:29:31 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:29:31 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:29:31 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 12:29:31 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:29:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:29:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:29:31 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 12:29:31 --> User Agent Class Initialized
DEBUG - 2010-06-23 12:29:31 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 12:29:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:29:31 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 12:29:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:29:32 --> Domain class already loaded. Second attempt ignored.
INFO  - 2010-06-23 12:29:32 --> User update: (21) pudding : 
DEBUG - 2010-06-23 12:29:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:29:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:29:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:29:32 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:29:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:29:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:29:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:29:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:29:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:29:33 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:29:33 --> Helper loaded: email_helper
INFO  - 2010-06-23 12:29:33 --> User update: (21) pudding : puddingchen.35@gmail.com
ERROR - 2010-06-23 12:29:33 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;deleted&quot; is of type boolean but expression is of type integer
LINE 1: UPDATE &quot;user&quot; SET &quot;deleted&quot; = 1 WHERE &quot;user_id&quot; = '21'
                                      ^
HINT:  You will need to rewrite or cast the expression. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-23 12:29:33 --> DB Transaction Failure
ERROR - 2010-06-23 12:29:33 --> Query error: ERROR:  column "deleted" is of type boolean but expression is of type integer
LINE 1: UPDATE "user" SET "deleted" = 1 WHERE "user_id" = '21'
                                      ^
HINT:  You will need to rewrite or cast the expression.
DEBUG - 2010-06-23 12:29:33 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-06-23 12:29:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php:148) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-23 12:29:52 --> Config Class Initialized
DEBUG - 2010-06-23 12:29:52 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:29:52 --> URI Class Initialized
DEBUG - 2010-06-23 12:29:52 --> Router Class Initialized
DEBUG - 2010-06-23 12:29:52 --> Output Class Initialized
DEBUG - 2010-06-23 12:29:52 --> Input Class Initialized
DEBUG - 2010-06-23 12:29:52 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:29:52 --> Language Class Initialized
DEBUG - 2010-06-23 12:29:53 --> Loader Class Initialized
DEBUG - 2010-06-23 12:29:53 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:29:53 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:29:53 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:29:53 --> Session Class Initialized
DEBUG - 2010-06-23 12:29:53 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:29:53 --> Session routines successfully run
DEBUG - 2010-06-23 12:29:53 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:29:53 --> Controller Class Initialized
DEBUG - 2010-06-23 12:29:53 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:29:53 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:29:54 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:29:54 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 12:29:54 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:29:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:29:54 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:29:54 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 12:29:54 --> Helper loaded: email_helper
DEBUG - 2010-06-23 12:29:54 --> User Agent Class Initialized
DEBUG - 2010-06-23 12:29:54 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 12:29:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:29:55 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 12:29:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:29:55 --> Domain class already loaded. Second attempt ignored.
INFO  - 2010-06-23 12:29:55 --> User update: (21) pudding : puddingchen.35@gmail.com
DEBUG - 2010-06-23 12:29:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:29:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:29:55 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:29:55 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:29:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:29:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:29:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:29:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:29:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:29:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:29:56 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:29:56 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 12:29:56 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;deleted&quot; is of type boolean but expression is of type integer
LINE 1: UPDATE &quot;user&quot; SET &quot;deleted&quot; = 1 WHERE &quot;user_id&quot; = '21'
                                      ^
HINT:  You will need to rewrite or cast the expression. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-23 12:29:56 --> DB Transaction Failure
ERROR - 2010-06-23 12:29:56 --> Query error: ERROR:  column "deleted" is of type boolean but expression is of type integer
LINE 1: UPDATE "user" SET "deleted" = 1 WHERE "user_id" = '21'
                                      ^
HINT:  You will need to rewrite or cast the expression.
DEBUG - 2010-06-23 12:29:56 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-06-23 12:29:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php:148) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-23 12:31:53 --> Config Class Initialized
DEBUG - 2010-06-23 12:31:53 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:31:54 --> URI Class Initialized
DEBUG - 2010-06-23 12:31:54 --> Router Class Initialized
DEBUG - 2010-06-23 12:31:54 --> Output Class Initialized
DEBUG - 2010-06-23 12:31:54 --> Input Class Initialized
DEBUG - 2010-06-23 12:31:54 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:31:54 --> Language Class Initialized
DEBUG - 2010-06-23 12:31:54 --> Loader Class Initialized
DEBUG - 2010-06-23 12:31:54 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:31:54 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:31:54 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:31:55 --> Session Class Initialized
DEBUG - 2010-06-23 12:31:55 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:31:55 --> Session routines successfully run
DEBUG - 2010-06-23 12:31:55 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:31:55 --> Controller Class Initialized
DEBUG - 2010-06-23 12:31:55 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:31:55 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:31:55 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:31:55 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 12:31:55 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:31:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:31:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:31:56 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 12:31:56 --> Helper loaded: email_helper
DEBUG - 2010-06-23 12:31:56 --> User Agent Class Initialized
DEBUG - 2010-06-23 12:31:56 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 12:31:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:31:56 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 12:31:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:31:56 --> Domain class already loaded. Second attempt ignored.
INFO  - 2010-06-23 12:31:57 --> User update: (21) pudding : puddingchen.35@gmail.com
DEBUG - 2010-06-23 12:31:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:31:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:31:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:31:57 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:31:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:31:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:31:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:31:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:31:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:31:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:31:58 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:31:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:31:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:31:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:31:58 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 12:31:58 --> Final output sent to browser
DEBUG - 2010-06-23 12:31:58 --> Total execution time: 4.8000
DEBUG - 2010-06-23 12:45:00 --> Config Class Initialized
DEBUG - 2010-06-23 12:45:00 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:45:00 --> URI Class Initialized
DEBUG - 2010-06-23 12:45:00 --> Router Class Initialized
DEBUG - 2010-06-23 12:45:00 --> Output Class Initialized
DEBUG - 2010-06-23 12:45:00 --> Input Class Initialized
DEBUG - 2010-06-23 12:45:00 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:45:00 --> Language Class Initialized
DEBUG - 2010-06-23 12:45:00 --> Loader Class Initialized
DEBUG - 2010-06-23 12:45:01 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:45:01 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:45:01 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:45:01 --> Session Class Initialized
DEBUG - 2010-06-23 12:45:01 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:45:01 --> Session routines successfully run
DEBUG - 2010-06-23 12:45:01 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:45:01 --> Controller Class Initialized
DEBUG - 2010-06-23 12:45:01 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:45:01 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:45:02 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:45:02 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 12:45:02 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:45:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:45:02 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:45:02 --> User Agent Class Initialized
DEBUG - 2010-06-23 12:45:02 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 12:45:02 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 12:45:02 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 12:45:02 --> User_agent class already loaded. Second attempt ignored.
INFO  - 2010-06-23 12:45:03 --> User update: (22) pudding : 
DEBUG - 2010-06-23 12:45:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:45:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:45:03 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:45:03 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:45:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:45:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:45:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:45:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:45:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:45:03 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:45:04 --> Helper loaded: email_helper
INFO  - 2010-06-23 12:45:04 --> User update: (22) pudding : puddingchen.35@gmail.com
DEBUG - 2010-06-23 12:45:04 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 12:45:04 --> Final output sent to browser
DEBUG - 2010-06-23 12:45:04 --> Total execution time: 4.3918
DEBUG - 2010-06-23 12:56:52 --> Config Class Initialized
DEBUG - 2010-06-23 12:56:52 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:56:53 --> URI Class Initialized
DEBUG - 2010-06-23 12:56:53 --> Router Class Initialized
DEBUG - 2010-06-23 12:56:53 --> Output Class Initialized
DEBUG - 2010-06-23 12:56:53 --> Input Class Initialized
DEBUG - 2010-06-23 12:56:53 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:56:53 --> Language Class Initialized
DEBUG - 2010-06-23 12:56:53 --> Loader Class Initialized
DEBUG - 2010-06-23 12:56:53 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:56:53 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:56:54 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:56:54 --> Session Class Initialized
DEBUG - 2010-06-23 12:56:54 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:56:54 --> Session routines successfully run
DEBUG - 2010-06-23 12:56:54 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:56:54 --> Controller Class Initialized
DEBUG - 2010-06-23 12:56:54 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:56:54 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:56:54 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:56:54 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 12:56:55 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:56:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:56:55 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:56:55 --> User Agent Class Initialized
DEBUG - 2010-06-23 12:56:55 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 12:56:55 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 12:56:55 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 12:56:55 --> User_agent class already loaded. Second attempt ignored.
INFO  - 2010-06-23 12:56:55 --> User update: (23) pudding : 
DEBUG - 2010-06-23 12:56:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:56:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:56:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:56:56 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:56:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:56:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:56:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:56:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:56:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:56:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:56:56 --> Helper loaded: email_helper
INFO  - 2010-06-23 12:56:57 --> User update: (23) pudding : puddingchen.35@gmail.com
DEBUG - 2010-06-23 12:56:57 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 12:56:57 --> Final output sent to browser
DEBUG - 2010-06-23 12:56:57 --> Total execution time: 4.3273
DEBUG - 2010-06-23 12:58:02 --> Config Class Initialized
DEBUG - 2010-06-23 12:58:02 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:58:02 --> URI Class Initialized
DEBUG - 2010-06-23 12:58:02 --> Router Class Initialized
DEBUG - 2010-06-23 12:58:02 --> Output Class Initialized
DEBUG - 2010-06-23 12:58:02 --> Input Class Initialized
DEBUG - 2010-06-23 12:58:02 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:58:02 --> Language Class Initialized
DEBUG - 2010-06-23 12:58:03 --> Loader Class Initialized
DEBUG - 2010-06-23 12:58:03 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:58:03 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:58:03 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:58:03 --> Session Class Initialized
DEBUG - 2010-06-23 12:58:03 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:58:03 --> Session routines successfully run
DEBUG - 2010-06-23 12:58:03 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:58:03 --> Controller Class Initialized
DEBUG - 2010-06-23 12:58:04 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:58:04 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:58:04 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:58:04 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 12:58:04 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:58:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:58:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:58:04 --> User Agent Class Initialized
DEBUG - 2010-06-23 12:58:04 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 12:58:04 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 12:58:05 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 12:58:05 --> User_agent class already loaded. Second attempt ignored.
INFO  - 2010-06-23 12:58:05 --> User update: (24) pudding : 
DEBUG - 2010-06-23 12:58:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:58:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:58:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:58:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:58:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:58:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:58:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:58:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:58:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:58:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:58:06 --> Helper loaded: email_helper
INFO  - 2010-06-23 12:58:06 --> User update: (24) pudding : puddingchen.35@gmail.com
DEBUG - 2010-06-23 12:58:06 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 12:58:06 --> Final output sent to browser
DEBUG - 2010-06-23 12:58:06 --> Total execution time: 4.5293
DEBUG - 2010-06-23 12:58:33 --> Config Class Initialized
DEBUG - 2010-06-23 12:58:33 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:58:33 --> URI Class Initialized
DEBUG - 2010-06-23 12:58:34 --> Router Class Initialized
DEBUG - 2010-06-23 12:58:34 --> Output Class Initialized
DEBUG - 2010-06-23 12:58:34 --> Input Class Initialized
DEBUG - 2010-06-23 12:58:34 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:58:34 --> Language Class Initialized
DEBUG - 2010-06-23 12:58:34 --> Loader Class Initialized
DEBUG - 2010-06-23 12:58:34 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:58:34 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:58:34 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:58:34 --> Session Class Initialized
DEBUG - 2010-06-23 12:58:35 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:58:35 --> Session routines successfully run
DEBUG - 2010-06-23 12:58:35 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:58:35 --> Controller Class Initialized
DEBUG - 2010-06-23 12:58:35 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:58:35 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:58:35 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:58:35 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 12:58:35 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:58:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:58:36 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:58:36 --> User Agent Class Initialized
DEBUG - 2010-06-23 12:58:36 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 12:58:36 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 12:58:36 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 12:58:36 --> User_agent class already loaded. Second attempt ignored.
INFO  - 2010-06-23 12:58:36 --> User update: (25) pudding : 
DEBUG - 2010-06-23 12:58:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:58:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:58:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:58:37 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:58:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:58:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:58:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:58:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:58:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:58:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:58:37 --> Helper loaded: email_helper
INFO  - 2010-06-23 12:58:37 --> User update: (25) pudding : puddingchen.35@gmail.com
DEBUG - 2010-06-23 12:58:38 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 12:58:38 --> Final output sent to browser
DEBUG - 2010-06-23 12:58:38 --> Total execution time: 4.4052
DEBUG - 2010-06-23 12:59:55 --> Config Class Initialized
DEBUG - 2010-06-23 12:59:55 --> Hooks Class Initialized
DEBUG - 2010-06-23 12:59:55 --> URI Class Initialized
DEBUG - 2010-06-23 12:59:55 --> Router Class Initialized
DEBUG - 2010-06-23 12:59:55 --> Output Class Initialized
DEBUG - 2010-06-23 12:59:55 --> Input Class Initialized
DEBUG - 2010-06-23 12:59:55 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 12:59:55 --> Language Class Initialized
DEBUG - 2010-06-23 12:59:55 --> Loader Class Initialized
DEBUG - 2010-06-23 12:59:56 --> Helper loaded: object_helper
DEBUG - 2010-06-23 12:59:56 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 12:59:56 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:59:56 --> Session Class Initialized
DEBUG - 2010-06-23 12:59:56 --> Helper loaded: string_helper
DEBUG - 2010-06-23 12:59:56 --> Session routines successfully run
DEBUG - 2010-06-23 12:59:56 --> Helper loaded: context_helper
DEBUG - 2010-06-23 12:59:56 --> Controller Class Initialized
DEBUG - 2010-06-23 12:59:56 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 12:59:56 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 12:59:57 --> Database Driver Class Initialized
DEBUG - 2010-06-23 12:59:57 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 12:59:57 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 12:59:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:59:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 12:59:57 --> User Agent Class Initialized
DEBUG - 2010-06-23 12:59:57 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 12:59:57 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 13:01:17 --> Config Class Initialized
DEBUG - 2010-06-23 13:01:17 --> Hooks Class Initialized
DEBUG - 2010-06-23 13:01:17 --> URI Class Initialized
DEBUG - 2010-06-23 13:01:17 --> Router Class Initialized
DEBUG - 2010-06-23 13:01:17 --> Output Class Initialized
DEBUG - 2010-06-23 13:01:17 --> Input Class Initialized
DEBUG - 2010-06-23 13:01:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 13:01:17 --> Language Class Initialized
DEBUG - 2010-06-23 13:01:17 --> Loader Class Initialized
DEBUG - 2010-06-23 13:01:17 --> Helper loaded: object_helper
DEBUG - 2010-06-23 13:01:18 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 13:01:18 --> Helper loaded: context_helper
DEBUG - 2010-06-23 13:01:18 --> Session Class Initialized
DEBUG - 2010-06-23 13:01:18 --> Helper loaded: string_helper
DEBUG - 2010-06-23 13:01:18 --> Session routines successfully run
DEBUG - 2010-06-23 13:01:18 --> Helper loaded: context_helper
DEBUG - 2010-06-23 13:01:18 --> Controller Class Initialized
DEBUG - 2010-06-23 13:01:18 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 13:01:18 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 13:01:18 --> Database Driver Class Initialized
DEBUG - 2010-06-23 13:01:19 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 13:01:19 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 13:01:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:01:19 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:01:19 --> User Agent Class Initialized
DEBUG - 2010-06-23 13:01:19 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 13:01:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:01:19 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 13:01:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:01:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:01:20 --> Config file loaded: config/kals.php
INFO  - 2010-06-23 13:01:20 --> User update: (26) pudding : 
DEBUG - 2010-06-23 13:01:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:01:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:01:20 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:01:20 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:01:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:01:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:01:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:01:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:01:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:01:21 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:01:21 --> Helper loaded: email_helper
DEBUG - 2010-06-23 13:01:21 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:01:21 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 13:01:21 --> Final output sent to browser
DEBUG - 2010-06-23 13:01:21 --> Total execution time: 4.6510
DEBUG - 2010-06-23 13:01:52 --> Config Class Initialized
DEBUG - 2010-06-23 13:01:53 --> Hooks Class Initialized
DEBUG - 2010-06-23 13:01:53 --> URI Class Initialized
DEBUG - 2010-06-23 13:01:53 --> Router Class Initialized
DEBUG - 2010-06-23 13:01:53 --> Output Class Initialized
DEBUG - 2010-06-23 13:01:53 --> Input Class Initialized
DEBUG - 2010-06-23 13:01:53 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 13:01:53 --> Language Class Initialized
DEBUG - 2010-06-23 13:01:53 --> Loader Class Initialized
DEBUG - 2010-06-23 13:01:53 --> Helper loaded: object_helper
DEBUG - 2010-06-23 13:01:54 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 13:01:54 --> Helper loaded: context_helper
DEBUG - 2010-06-23 13:01:54 --> Session Class Initialized
DEBUG - 2010-06-23 13:01:54 --> Helper loaded: string_helper
DEBUG - 2010-06-23 13:01:54 --> Session routines successfully run
DEBUG - 2010-06-23 13:01:54 --> Helper loaded: context_helper
DEBUG - 2010-06-23 13:01:54 --> Controller Class Initialized
DEBUG - 2010-06-23 13:01:54 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 13:01:54 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 13:01:54 --> Database Driver Class Initialized
DEBUG - 2010-06-23 13:01:55 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 13:01:55 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 13:01:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:01:55 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:01:55 --> User Agent Class Initialized
DEBUG - 2010-06-23 13:01:55 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 13:01:55 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 13:02:04 --> Config Class Initialized
DEBUG - 2010-06-23 13:02:05 --> Hooks Class Initialized
DEBUG - 2010-06-23 13:02:05 --> URI Class Initialized
DEBUG - 2010-06-23 13:02:05 --> Router Class Initialized
DEBUG - 2010-06-23 13:02:05 --> Output Class Initialized
DEBUG - 2010-06-23 13:02:05 --> Input Class Initialized
DEBUG - 2010-06-23 13:02:05 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 13:02:05 --> Language Class Initialized
DEBUG - 2010-06-23 13:02:05 --> Loader Class Initialized
DEBUG - 2010-06-23 13:02:05 --> Helper loaded: object_helper
DEBUG - 2010-06-23 13:02:05 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 13:02:06 --> Helper loaded: context_helper
DEBUG - 2010-06-23 13:02:06 --> Session Class Initialized
DEBUG - 2010-06-23 13:02:06 --> Helper loaded: string_helper
DEBUG - 2010-06-23 13:02:06 --> Session routines successfully run
DEBUG - 2010-06-23 13:02:06 --> Helper loaded: context_helper
DEBUG - 2010-06-23 13:02:06 --> Controller Class Initialized
DEBUG - 2010-06-23 13:02:06 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 13:02:06 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 13:02:06 --> Database Driver Class Initialized
DEBUG - 2010-06-23 13:02:06 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 13:02:07 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 13:02:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:02:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:02:07 --> User Agent Class Initialized
DEBUG - 2010-06-23 13:02:07 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 13:02:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:02:07 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 13:02:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:02:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:02:08 --> Config file loaded: config/kals.php
INFO  - 2010-06-23 13:02:08 --> User update: (28) pudding : 
DEBUG - 2010-06-23 13:02:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:02:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:02:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:02:08 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:02:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:02:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:02:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:02:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:02:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:02:09 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:02:09 --> Helper loaded: email_helper
DEBUG - 2010-06-23 13:02:09 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:02:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:02:09 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 13:02:09 --> Final output sent to browser
DEBUG - 2010-06-23 13:02:09 --> Total execution time: 4.7434
DEBUG - 2010-06-23 13:07:03 --> Config Class Initialized
DEBUG - 2010-06-23 13:07:03 --> Hooks Class Initialized
DEBUG - 2010-06-23 13:07:03 --> URI Class Initialized
DEBUG - 2010-06-23 13:07:03 --> Router Class Initialized
DEBUG - 2010-06-23 13:07:03 --> Output Class Initialized
DEBUG - 2010-06-23 13:07:03 --> Input Class Initialized
DEBUG - 2010-06-23 13:07:03 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 13:07:03 --> Language Class Initialized
DEBUG - 2010-06-23 13:07:03 --> Loader Class Initialized
DEBUG - 2010-06-23 13:07:04 --> Helper loaded: object_helper
DEBUG - 2010-06-23 13:07:04 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 13:07:04 --> Helper loaded: context_helper
DEBUG - 2010-06-23 13:07:04 --> Session Class Initialized
DEBUG - 2010-06-23 13:07:04 --> Helper loaded: string_helper
DEBUG - 2010-06-23 13:07:04 --> Session routines successfully run
DEBUG - 2010-06-23 13:07:04 --> Helper loaded: context_helper
DEBUG - 2010-06-23 13:07:04 --> Controller Class Initialized
DEBUG - 2010-06-23 13:07:04 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 13:07:04 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 13:07:05 --> Database Driver Class Initialized
DEBUG - 2010-06-23 13:07:05 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 13:07:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:07:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:07:05 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 13:07:05 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 13:07:05 --> Final output sent to browser
DEBUG - 2010-06-23 13:07:05 --> Total execution time: 2.8349
DEBUG - 2010-06-23 13:07:28 --> Config Class Initialized
DEBUG - 2010-06-23 13:07:28 --> Hooks Class Initialized
DEBUG - 2010-06-23 13:07:28 --> URI Class Initialized
DEBUG - 2010-06-23 13:07:28 --> Router Class Initialized
DEBUG - 2010-06-23 13:07:28 --> Output Class Initialized
DEBUG - 2010-06-23 13:07:28 --> Input Class Initialized
DEBUG - 2010-06-23 13:07:28 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 13:07:28 --> Language Class Initialized
DEBUG - 2010-06-23 13:07:29 --> Loader Class Initialized
DEBUG - 2010-06-23 13:07:29 --> Helper loaded: object_helper
DEBUG - 2010-06-23 13:07:29 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 13:07:29 --> Helper loaded: context_helper
DEBUG - 2010-06-23 13:07:29 --> Session Class Initialized
DEBUG - 2010-06-23 13:07:29 --> Helper loaded: string_helper
DEBUG - 2010-06-23 13:07:29 --> Session routines successfully run
DEBUG - 2010-06-23 13:07:29 --> Helper loaded: context_helper
DEBUG - 2010-06-23 13:07:29 --> Controller Class Initialized
DEBUG - 2010-06-23 13:07:29 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 13:07:30 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 13:07:30 --> Database Driver Class Initialized
DEBUG - 2010-06-23 13:07:30 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 13:07:30 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:07:30 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 13:07:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:07:30 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:07:30 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 13:07:30 --> Final output sent to browser
DEBUG - 2010-06-23 13:07:31 --> Total execution time: 2.7420
DEBUG - 2010-06-23 13:09:53 --> Config Class Initialized
DEBUG - 2010-06-23 13:09:53 --> Hooks Class Initialized
DEBUG - 2010-06-23 13:09:53 --> URI Class Initialized
DEBUG - 2010-06-23 13:09:53 --> Router Class Initialized
DEBUG - 2010-06-23 13:09:53 --> Output Class Initialized
DEBUG - 2010-06-23 13:09:53 --> Input Class Initialized
DEBUG - 2010-06-23 13:09:54 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 13:09:54 --> Language Class Initialized
DEBUG - 2010-06-23 13:09:54 --> Loader Class Initialized
DEBUG - 2010-06-23 13:09:54 --> Helper loaded: object_helper
DEBUG - 2010-06-23 13:09:54 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 13:09:54 --> Helper loaded: context_helper
DEBUG - 2010-06-23 13:09:54 --> Session Class Initialized
DEBUG - 2010-06-23 13:09:54 --> Helper loaded: string_helper
DEBUG - 2010-06-23 13:09:54 --> Session routines successfully run
DEBUG - 2010-06-23 13:09:54 --> Helper loaded: context_helper
DEBUG - 2010-06-23 13:09:55 --> Controller Class Initialized
DEBUG - 2010-06-23 13:09:55 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 13:09:55 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 13:09:55 --> Database Driver Class Initialized
DEBUG - 2010-06-23 13:09:55 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 13:09:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:09:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:09:57 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 13:09:57 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 13:09:57 --> Final output sent to browser
DEBUG - 2010-06-23 13:09:57 --> Total execution time: 4.1011
DEBUG - 2010-06-23 13:21:39 --> Config Class Initialized
DEBUG - 2010-06-23 13:21:39 --> Hooks Class Initialized
DEBUG - 2010-06-23 13:21:39 --> URI Class Initialized
DEBUG - 2010-06-23 13:21:39 --> Router Class Initialized
DEBUG - 2010-06-23 13:21:39 --> Output Class Initialized
DEBUG - 2010-06-23 13:21:40 --> Input Class Initialized
DEBUG - 2010-06-23 13:21:40 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 13:21:40 --> Language Class Initialized
DEBUG - 2010-06-23 13:21:40 --> Loader Class Initialized
DEBUG - 2010-06-23 13:21:40 --> Helper loaded: object_helper
DEBUG - 2010-06-23 13:21:40 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 13:21:40 --> Helper loaded: context_helper
DEBUG - 2010-06-23 13:21:40 --> Session Class Initialized
DEBUG - 2010-06-23 13:21:40 --> Helper loaded: string_helper
DEBUG - 2010-06-23 13:21:40 --> Session routines successfully run
DEBUG - 2010-06-23 13:21:41 --> Helper loaded: context_helper
DEBUG - 2010-06-23 13:21:41 --> Controller Class Initialized
DEBUG - 2010-06-23 13:21:41 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 13:21:41 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 13:21:41 --> Database Driver Class Initialized
DEBUG - 2010-06-23 13:21:41 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 13:21:41 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:21:41 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 13:21:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:21:42 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:21:42 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 13:21:42 --> Final output sent to browser
DEBUG - 2010-06-23 13:21:42 --> Total execution time: 2.8072
DEBUG - 2010-06-23 13:22:53 --> Config Class Initialized
DEBUG - 2010-06-23 13:22:53 --> Hooks Class Initialized
DEBUG - 2010-06-23 13:22:53 --> URI Class Initialized
DEBUG - 2010-06-23 13:22:53 --> Config Class Initialized
DEBUG - 2010-06-23 13:22:53 --> Router Class Initialized
DEBUG - 2010-06-23 13:22:53 --> Hooks Class Initialized
DEBUG - 2010-06-23 13:22:53 --> Output Class Initialized
DEBUG - 2010-06-23 13:22:54 --> Input Class Initialized
DEBUG - 2010-06-23 13:22:54 --> URI Class Initialized
DEBUG - 2010-06-23 13:22:54 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 13:22:54 --> Router Class Initialized
DEBUG - 2010-06-23 13:22:54 --> Language Class Initialized
DEBUG - 2010-06-23 13:22:54 --> Output Class Initialized
DEBUG - 2010-06-23 13:22:54 --> Loader Class Initialized
DEBUG - 2010-06-23 13:22:54 --> Input Class Initialized
DEBUG - 2010-06-23 13:22:54 --> Helper loaded: object_helper
DEBUG - 2010-06-23 13:22:54 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 13:22:54 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 13:22:54 --> Language Class Initialized
DEBUG - 2010-06-23 13:22:54 --> Helper loaded: context_helper
DEBUG - 2010-06-23 13:22:54 --> Loader Class Initialized
DEBUG - 2010-06-23 13:22:54 --> Session Class Initialized
DEBUG - 2010-06-23 13:22:54 --> Helper loaded: object_helper
DEBUG - 2010-06-23 13:22:54 --> Helper loaded: string_helper
DEBUG - 2010-06-23 13:22:55 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 13:22:55 --> Session routines successfully run
DEBUG - 2010-06-23 13:22:55 --> Helper loaded: context_helper
DEBUG - 2010-06-23 13:22:55 --> Helper loaded: context_helper
DEBUG - 2010-06-23 13:22:55 --> Controller Class Initialized
DEBUG - 2010-06-23 13:22:55 --> Session Class Initialized
DEBUG - 2010-06-23 13:22:55 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 13:22:55 --> Helper loaded: string_helper
DEBUG - 2010-06-23 13:22:55 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 13:22:55 --> Session routines successfully run
DEBUG - 2010-06-23 13:22:55 --> Database Driver Class Initialized
DEBUG - 2010-06-23 13:22:55 --> Helper loaded: context_helper
DEBUG - 2010-06-23 13:22:55 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 13:22:55 --> Controller Class Initialized
DEBUG - 2010-06-23 13:22:55 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:22:56 --> Unit Testing Class Initialized
ERROR - 2010-06-23 13:22:56 --> Severity: Notice  --> Undefined property: Webpage::$get_uri D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Webpage.php 111
DEBUG - 2010-06-23 13:22:56 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 13:22:56 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 13:22:56 --> Database Driver Class Initialized
DEBUG - 2010-06-23 13:22:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:22:56 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 13:22:56 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:22:56 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:22:56 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
ERROR - 2010-06-23 13:22:56 --> Severity: Notice  --> Undefined property: Webpage::$get_uri D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Webpage.php 111
DEBUG - 2010-06-23 13:22:56 --> Final output sent to browser
DEBUG - 2010-06-23 13:22:56 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 13:22:56 --> Total execution time: 3.0270
DEBUG - 2010-06-23 13:22:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:22:56 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:22:56 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 13:22:57 --> Final output sent to browser
DEBUG - 2010-06-23 13:22:57 --> Total execution time: 3.3095
DEBUG - 2010-06-23 13:23:23 --> Config Class Initialized
DEBUG - 2010-06-23 13:23:23 --> Hooks Class Initialized
DEBUG - 2010-06-23 13:23:23 --> URI Class Initialized
DEBUG - 2010-06-23 13:23:23 --> Router Class Initialized
DEBUG - 2010-06-23 13:23:23 --> Output Class Initialized
DEBUG - 2010-06-23 13:23:23 --> Input Class Initialized
DEBUG - 2010-06-23 13:23:23 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 13:23:23 --> Language Class Initialized
DEBUG - 2010-06-23 13:23:24 --> Loader Class Initialized
DEBUG - 2010-06-23 13:23:24 --> Helper loaded: object_helper
DEBUG - 2010-06-23 13:23:24 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 13:23:24 --> Helper loaded: context_helper
DEBUG - 2010-06-23 13:23:24 --> Session Class Initialized
DEBUG - 2010-06-23 13:23:24 --> Helper loaded: string_helper
DEBUG - 2010-06-23 13:23:24 --> Session routines successfully run
DEBUG - 2010-06-23 13:23:24 --> Helper loaded: context_helper
DEBUG - 2010-06-23 13:23:24 --> Controller Class Initialized
DEBUG - 2010-06-23 13:23:25 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 13:23:25 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 13:23:25 --> Database Driver Class Initialized
DEBUG - 2010-06-23 13:23:25 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 13:23:25 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:23:25 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 13:23:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:23:25 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:23:25 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 13:23:26 --> Final output sent to browser
DEBUG - 2010-06-23 13:23:26 --> Total execution time: 2.8325
DEBUG - 2010-06-23 13:25:16 --> Config Class Initialized
DEBUG - 2010-06-23 13:25:16 --> Hooks Class Initialized
DEBUG - 2010-06-23 13:25:16 --> URI Class Initialized
DEBUG - 2010-06-23 13:25:16 --> Router Class Initialized
DEBUG - 2010-06-23 13:25:17 --> Output Class Initialized
DEBUG - 2010-06-23 13:25:17 --> Input Class Initialized
DEBUG - 2010-06-23 13:25:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 13:25:17 --> Language Class Initialized
DEBUG - 2010-06-23 13:25:17 --> Loader Class Initialized
DEBUG - 2010-06-23 13:25:17 --> Helper loaded: object_helper
DEBUG - 2010-06-23 13:25:17 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 13:25:17 --> Helper loaded: context_helper
DEBUG - 2010-06-23 13:25:17 --> Session Class Initialized
DEBUG - 2010-06-23 13:25:18 --> Helper loaded: string_helper
DEBUG - 2010-06-23 13:25:18 --> Session routines successfully run
DEBUG - 2010-06-23 13:25:18 --> Helper loaded: context_helper
DEBUG - 2010-06-23 13:25:18 --> Controller Class Initialized
DEBUG - 2010-06-23 13:25:18 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 13:25:18 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 13:25:18 --> Database Driver Class Initialized
DEBUG - 2010-06-23 13:25:18 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 13:25:18 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:25:19 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 13:25:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:25:19 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:25:19 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 13:25:19 --> Final output sent to browser
DEBUG - 2010-06-23 13:25:19 --> Total execution time: 2.8737
DEBUG - 2010-06-23 13:28:05 --> Config Class Initialized
DEBUG - 2010-06-23 13:28:05 --> Hooks Class Initialized
DEBUG - 2010-06-23 13:28:06 --> URI Class Initialized
DEBUG - 2010-06-23 13:28:06 --> Router Class Initialized
DEBUG - 2010-06-23 13:28:06 --> Output Class Initialized
DEBUG - 2010-06-23 13:28:06 --> Input Class Initialized
DEBUG - 2010-06-23 13:28:06 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 13:28:06 --> Language Class Initialized
DEBUG - 2010-06-23 13:28:06 --> Loader Class Initialized
DEBUG - 2010-06-23 13:28:06 --> Helper loaded: object_helper
DEBUG - 2010-06-23 13:28:06 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 13:28:07 --> Helper loaded: context_helper
DEBUG - 2010-06-23 13:28:07 --> Session Class Initialized
DEBUG - 2010-06-23 13:28:07 --> Helper loaded: string_helper
DEBUG - 2010-06-23 13:28:07 --> Session routines successfully run
DEBUG - 2010-06-23 13:28:07 --> Helper loaded: context_helper
DEBUG - 2010-06-23 13:28:07 --> Controller Class Initialized
DEBUG - 2010-06-23 13:28:07 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 13:28:07 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 13:28:07 --> Database Driver Class Initialized
DEBUG - 2010-06-23 13:28:08 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 13:28:08 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:28:08 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 13:28:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:28:08 --> Webpage class already loaded. Second attempt ignored.
ERROR - 2010-06-23 13:28:08 --> 無法刪除Domain
DEBUG - 2010-06-23 13:30:12 --> Config Class Initialized
DEBUG - 2010-06-23 13:30:13 --> Hooks Class Initialized
DEBUG - 2010-06-23 13:30:13 --> URI Class Initialized
DEBUG - 2010-06-23 13:30:13 --> Router Class Initialized
DEBUG - 2010-06-23 13:30:13 --> Output Class Initialized
DEBUG - 2010-06-23 13:30:13 --> Input Class Initialized
DEBUG - 2010-06-23 13:30:13 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 13:30:13 --> Language Class Initialized
DEBUG - 2010-06-23 13:30:13 --> Loader Class Initialized
DEBUG - 2010-06-23 13:30:13 --> Helper loaded: object_helper
DEBUG - 2010-06-23 13:30:14 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 13:30:14 --> Helper loaded: context_helper
DEBUG - 2010-06-23 13:30:14 --> Session Class Initialized
DEBUG - 2010-06-23 13:30:14 --> Helper loaded: string_helper
DEBUG - 2010-06-23 13:30:14 --> Session routines successfully run
DEBUG - 2010-06-23 13:30:14 --> Helper loaded: context_helper
DEBUG - 2010-06-23 13:30:14 --> Controller Class Initialized
DEBUG - 2010-06-23 13:30:14 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 13:30:14 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 13:30:15 --> Database Driver Class Initialized
DEBUG - 2010-06-23 13:30:15 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 13:30:15 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:30:15 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 13:30:15 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 13:30:15 --> Final output sent to browser
DEBUG - 2010-06-23 13:30:15 --> Total execution time: 2.7152
DEBUG - 2010-06-23 13:49:28 --> Config Class Initialized
DEBUG - 2010-06-23 13:49:28 --> Hooks Class Initialized
DEBUG - 2010-06-23 13:49:29 --> URI Class Initialized
DEBUG - 2010-06-23 13:49:29 --> Router Class Initialized
DEBUG - 2010-06-23 13:49:29 --> Output Class Initialized
DEBUG - 2010-06-23 13:49:29 --> Input Class Initialized
DEBUG - 2010-06-23 13:49:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 13:49:29 --> Language Class Initialized
DEBUG - 2010-06-23 13:49:29 --> Loader Class Initialized
DEBUG - 2010-06-23 13:49:29 --> Helper loaded: object_helper
DEBUG - 2010-06-23 13:49:29 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 13:49:30 --> Helper loaded: context_helper
DEBUG - 2010-06-23 13:49:30 --> Session Class Initialized
DEBUG - 2010-06-23 13:49:30 --> Helper loaded: string_helper
DEBUG - 2010-06-23 13:49:30 --> Session routines successfully run
DEBUG - 2010-06-23 13:49:30 --> Helper loaded: context_helper
DEBUG - 2010-06-23 13:49:30 --> Controller Class Initialized
DEBUG - 2010-06-23 13:49:30 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 13:49:30 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 13:49:31 --> Database Driver Class Initialized
DEBUG - 2010-06-23 13:49:31 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 13:50:09 --> Config Class Initialized
DEBUG - 2010-06-23 13:50:10 --> Hooks Class Initialized
DEBUG - 2010-06-23 13:50:10 --> URI Class Initialized
DEBUG - 2010-06-23 13:50:10 --> Router Class Initialized
DEBUG - 2010-06-23 13:50:10 --> Output Class Initialized
DEBUG - 2010-06-23 13:50:10 --> Input Class Initialized
DEBUG - 2010-06-23 13:50:10 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 13:50:10 --> Language Class Initialized
DEBUG - 2010-06-23 13:50:10 --> Loader Class Initialized
DEBUG - 2010-06-23 13:50:10 --> Helper loaded: object_helper
DEBUG - 2010-06-23 13:50:11 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 13:50:11 --> Helper loaded: context_helper
DEBUG - 2010-06-23 13:50:11 --> Session Class Initialized
DEBUG - 2010-06-23 13:50:11 --> Helper loaded: string_helper
DEBUG - 2010-06-23 13:50:11 --> Session routines successfully run
DEBUG - 2010-06-23 13:50:11 --> Helper loaded: context_helper
DEBUG - 2010-06-23 13:50:11 --> Controller Class Initialized
DEBUG - 2010-06-23 13:50:11 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 13:50:12 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 13:50:12 --> Database Driver Class Initialized
DEBUG - 2010-06-23 13:50:12 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 13:50:12 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:50:12 --> Domain class already loaded. Second attempt ignored.
INFO  - 2010-06-23 13:50:13 --> Webpage Create: (8) /p/5x1uan#response-1650638188 PHP布丁 說 [CODING D4] 目前進度5/182。希望今天能夠打起精神好好地來做！ - #5x1uan
DEBUG - 2010-06-23 13:50:13 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 13:50:13 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:50:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:50:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:50:13 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 13:50:13 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 13:50:13 --> Final output sent to browser
DEBUG - 2010-06-23 13:50:14 --> Total execution time: 3.9963
DEBUG - 2010-06-23 13:52:21 --> Config Class Initialized
DEBUG - 2010-06-23 13:52:21 --> Hooks Class Initialized
DEBUG - 2010-06-23 13:52:21 --> URI Class Initialized
DEBUG - 2010-06-23 13:52:21 --> Router Class Initialized
DEBUG - 2010-06-23 13:52:21 --> Output Class Initialized
DEBUG - 2010-06-23 13:52:22 --> Input Class Initialized
DEBUG - 2010-06-23 13:52:22 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 13:52:22 --> Language Class Initialized
DEBUG - 2010-06-23 13:52:22 --> Loader Class Initialized
DEBUG - 2010-06-23 13:52:22 --> Helper loaded: object_helper
DEBUG - 2010-06-23 13:52:22 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 13:52:22 --> Helper loaded: context_helper
DEBUG - 2010-06-23 13:52:22 --> Session Class Initialized
DEBUG - 2010-06-23 13:52:22 --> Helper loaded: string_helper
DEBUG - 2010-06-23 13:52:23 --> Session routines successfully run
DEBUG - 2010-06-23 13:52:23 --> Helper loaded: context_helper
DEBUG - 2010-06-23 13:52:23 --> Controller Class Initialized
DEBUG - 2010-06-23 13:52:23 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 13:52:23 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 13:52:23 --> Database Driver Class Initialized
DEBUG - 2010-06-23 13:52:23 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 13:52:23 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:52:23 --> Domain class already loaded. Second attempt ignored.
INFO  - 2010-06-23 13:52:24 --> Webpage Create: (9) /p/5x1uan#response-1650638188 PHP布丁 說 [CODING D4] 目前進度5/182。希望今天能夠打起精神好好地來做！ - #5x1uan
DEBUG - 2010-06-23 13:52:24 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 13:52:24 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:52:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:52:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:52:25 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 13:52:25 --> Final output sent to browser
DEBUG - 2010-06-23 13:52:25 --> Total execution time: 3.9444
DEBUG - 2010-06-23 13:56:58 --> Config Class Initialized
DEBUG - 2010-06-23 13:56:59 --> Hooks Class Initialized
DEBUG - 2010-06-23 13:56:59 --> URI Class Initialized
DEBUG - 2010-06-23 13:56:59 --> Router Class Initialized
DEBUG - 2010-06-23 13:56:59 --> Output Class Initialized
DEBUG - 2010-06-23 13:56:59 --> Input Class Initialized
DEBUG - 2010-06-23 13:56:59 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 13:56:59 --> Language Class Initialized
DEBUG - 2010-06-23 13:56:59 --> Loader Class Initialized
DEBUG - 2010-06-23 13:56:59 --> Helper loaded: object_helper
DEBUG - 2010-06-23 13:57:00 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 13:57:00 --> Helper loaded: context_helper
DEBUG - 2010-06-23 13:57:00 --> Session Class Initialized
DEBUG - 2010-06-23 13:57:00 --> Helper loaded: string_helper
DEBUG - 2010-06-23 13:57:00 --> Session routines successfully run
DEBUG - 2010-06-23 13:57:00 --> Helper loaded: context_helper
DEBUG - 2010-06-23 13:57:00 --> Controller Class Initialized
DEBUG - 2010-06-23 13:57:00 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 13:57:00 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 13:57:01 --> Database Driver Class Initialized
DEBUG - 2010-06-23 13:57:01 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 13:57:01 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:57:01 --> Domain class already loaded. Second attempt ignored.
INFO  - 2010-06-23 13:57:01 --> Webpage Create: (10) /p/5x1uan#response-1650638188 PHP布丁 說 [CODING D4] 目前進度5/182。希望今天能夠打起精神好好地來做！ - #5x1uan
DEBUG - 2010-06-23 13:57:01 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 13:57:01 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:57:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:57:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 13:57:02 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 13:57:02 --> Final output sent to browser
DEBUG - 2010-06-23 13:57:02 --> Total execution time: 3.5701
DEBUG - 2010-06-23 14:17:10 --> Config Class Initialized
DEBUG - 2010-06-23 14:17:10 --> Hooks Class Initialized
DEBUG - 2010-06-23 14:17:10 --> URI Class Initialized
DEBUG - 2010-06-23 14:17:10 --> Router Class Initialized
DEBUG - 2010-06-23 14:17:11 --> Output Class Initialized
DEBUG - 2010-06-23 14:17:11 --> Input Class Initialized
DEBUG - 2010-06-23 14:17:11 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 14:17:11 --> Language Class Initialized
DEBUG - 2010-06-23 14:17:11 --> Loader Class Initialized
DEBUG - 2010-06-23 14:17:11 --> Helper loaded: object_helper
DEBUG - 2010-06-23 14:17:11 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 14:17:11 --> Helper loaded: context_helper
DEBUG - 2010-06-23 14:17:11 --> Session Class Initialized
DEBUG - 2010-06-23 14:17:12 --> Helper loaded: string_helper
DEBUG - 2010-06-23 14:17:12 --> Session routines successfully run
DEBUG - 2010-06-23 14:17:12 --> Helper loaded: context_helper
DEBUG - 2010-06-23 14:17:12 --> Controller Class Initialized
DEBUG - 2010-06-23 14:17:12 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 14:17:12 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 14:17:12 --> Database Driver Class Initialized
DEBUG - 2010-06-23 14:17:12 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 14:17:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:17:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:17:13 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 14:17:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:17:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:17:13 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 14:17:14 --> Final output sent to browser
DEBUG - 2010-06-23 14:17:14 --> Total execution time: 3.5056
DEBUG - 2010-06-23 14:17:20 --> Config Class Initialized
DEBUG - 2010-06-23 14:17:20 --> Hooks Class Initialized
DEBUG - 2010-06-23 14:17:20 --> URI Class Initialized
DEBUG - 2010-06-23 14:17:20 --> Router Class Initialized
DEBUG - 2010-06-23 14:17:20 --> Output Class Initialized
DEBUG - 2010-06-23 14:17:21 --> Input Class Initialized
DEBUG - 2010-06-23 14:17:21 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 14:17:21 --> Language Class Initialized
DEBUG - 2010-06-23 14:17:21 --> Loader Class Initialized
DEBUG - 2010-06-23 14:17:21 --> Helper loaded: object_helper
DEBUG - 2010-06-23 14:17:21 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 14:17:21 --> Helper loaded: context_helper
DEBUG - 2010-06-23 14:17:21 --> Session Class Initialized
DEBUG - 2010-06-23 14:17:21 --> Helper loaded: string_helper
DEBUG - 2010-06-23 14:17:22 --> Session routines successfully run
DEBUG - 2010-06-23 14:17:22 --> Helper loaded: context_helper
DEBUG - 2010-06-23 14:17:22 --> Controller Class Initialized
DEBUG - 2010-06-23 14:17:22 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 14:17:22 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 14:17:22 --> Database Driver Class Initialized
DEBUG - 2010-06-23 14:17:22 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 14:17:22 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:17:23 --> Domain class already loaded. Second attempt ignored.
INFO  - 2010-06-23 14:17:23 --> Webpage Create: (11) /p/5x1uan#response-1650638188 PHP布丁 說 [CODING D4] 目前進度5/182。希望今天能夠打起精神好好地來做！ - #5x1uan
DEBUG - 2010-06-23 14:17:23 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 14:17:23 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:17:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:17:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:17:23 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:17:24 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:17:24 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 14:17:24 --> Final output sent to browser
DEBUG - 2010-06-23 14:17:24 --> Total execution time: 3.8693
DEBUG - 2010-06-23 14:24:40 --> Config Class Initialized
DEBUG - 2010-06-23 14:24:40 --> Hooks Class Initialized
DEBUG - 2010-06-23 14:24:40 --> URI Class Initialized
DEBUG - 2010-06-23 14:24:40 --> Router Class Initialized
DEBUG - 2010-06-23 14:24:40 --> Output Class Initialized
DEBUG - 2010-06-23 14:24:40 --> Input Class Initialized
DEBUG - 2010-06-23 14:24:40 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 14:24:40 --> Language Class Initialized
DEBUG - 2010-06-23 14:24:40 --> Loader Class Initialized
DEBUG - 2010-06-23 14:24:41 --> Helper loaded: object_helper
DEBUG - 2010-06-23 14:24:41 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 14:24:41 --> Helper loaded: context_helper
DEBUG - 2010-06-23 14:24:41 --> Session Class Initialized
DEBUG - 2010-06-23 14:24:41 --> Helper loaded: string_helper
DEBUG - 2010-06-23 14:24:41 --> Session routines successfully run
DEBUG - 2010-06-23 14:24:41 --> Helper loaded: context_helper
DEBUG - 2010-06-23 14:24:41 --> Controller Class Initialized
DEBUG - 2010-06-23 14:24:42 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 14:24:42 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 14:24:42 --> Database Driver Class Initialized
DEBUG - 2010-06-23 14:24:42 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 14:24:42 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:24:42 --> Domain class already loaded. Second attempt ignored.
INFO  - 2010-06-23 14:24:42 --> Webpage Create: (12) /p/5x1uan#response-1650638188 PHP布丁 說 [CODING D4] 目前進度5/182。希望今天能夠打起精神好好地來做！ - #5x1uan
DEBUG - 2010-06-23 14:24:43 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 14:24:43 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:24:43 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:24:43 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:24:43 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:24:43 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:24:43 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 14:24:43 --> Final output sent to browser
DEBUG - 2010-06-23 14:24:44 --> Total execution time: 3.8994
DEBUG - 2010-06-23 14:25:33 --> Config Class Initialized
DEBUG - 2010-06-23 14:25:33 --> Hooks Class Initialized
DEBUG - 2010-06-23 14:25:33 --> URI Class Initialized
DEBUG - 2010-06-23 14:25:33 --> Router Class Initialized
DEBUG - 2010-06-23 14:25:33 --> Output Class Initialized
DEBUG - 2010-06-23 14:25:33 --> Input Class Initialized
DEBUG - 2010-06-23 14:25:33 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 14:25:34 --> Language Class Initialized
DEBUG - 2010-06-23 14:25:34 --> Loader Class Initialized
DEBUG - 2010-06-23 14:25:34 --> Helper loaded: object_helper
DEBUG - 2010-06-23 14:25:34 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 14:25:34 --> Helper loaded: context_helper
DEBUG - 2010-06-23 14:25:34 --> Session Class Initialized
DEBUG - 2010-06-23 14:25:34 --> Helper loaded: string_helper
DEBUG - 2010-06-23 14:25:34 --> Session routines successfully run
DEBUG - 2010-06-23 14:25:34 --> Helper loaded: context_helper
DEBUG - 2010-06-23 14:25:35 --> Controller Class Initialized
DEBUG - 2010-06-23 14:25:35 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 14:25:35 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 14:36:40 --> Config Class Initialized
DEBUG - 2010-06-23 14:36:40 --> Hooks Class Initialized
DEBUG - 2010-06-23 14:36:40 --> URI Class Initialized
DEBUG - 2010-06-23 14:36:41 --> Router Class Initialized
DEBUG - 2010-06-23 14:36:41 --> Output Class Initialized
DEBUG - 2010-06-23 14:36:41 --> Input Class Initialized
DEBUG - 2010-06-23 14:36:41 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 14:36:41 --> Language Class Initialized
DEBUG - 2010-06-23 14:36:41 --> Loader Class Initialized
DEBUG - 2010-06-23 14:36:41 --> Helper loaded: object_helper
DEBUG - 2010-06-23 14:36:41 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 14:36:42 --> Helper loaded: context_helper
DEBUG - 2010-06-23 14:36:42 --> Session Class Initialized
DEBUG - 2010-06-23 14:36:42 --> Helper loaded: string_helper
DEBUG - 2010-06-23 14:36:42 --> Session routines successfully run
DEBUG - 2010-06-23 14:36:42 --> Helper loaded: context_helper
DEBUG - 2010-06-23 14:36:42 --> Controller Class Initialized
DEBUG - 2010-06-23 14:36:42 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 14:36:42 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 14:36:42 --> Database Driver Class Initialized
DEBUG - 2010-06-23 14:36:43 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 14:36:43 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 14:36:43 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:36:43 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:36:43 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 14:36:43 --> User Agent Class Initialized
DEBUG - 2010-06-23 14:36:43 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 14:36:43 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 14:36:44 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 99
DEBUG - 2010-06-23 14:36:44 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 14:39:25 --> Config Class Initialized
DEBUG - 2010-06-23 14:39:25 --> Hooks Class Initialized
DEBUG - 2010-06-23 14:39:25 --> URI Class Initialized
DEBUG - 2010-06-23 14:39:25 --> Router Class Initialized
DEBUG - 2010-06-23 14:39:26 --> Output Class Initialized
DEBUG - 2010-06-23 14:39:26 --> Input Class Initialized
DEBUG - 2010-06-23 14:39:26 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 14:39:26 --> Language Class Initialized
DEBUG - 2010-06-23 14:39:26 --> Loader Class Initialized
DEBUG - 2010-06-23 14:39:26 --> Helper loaded: object_helper
DEBUG - 2010-06-23 14:39:26 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 14:39:26 --> Helper loaded: context_helper
DEBUG - 2010-06-23 14:39:27 --> Session Class Initialized
DEBUG - 2010-06-23 14:39:27 --> Helper loaded: string_helper
DEBUG - 2010-06-23 14:39:27 --> Session routines successfully run
DEBUG - 2010-06-23 14:39:27 --> Helper loaded: context_helper
DEBUG - 2010-06-23 14:39:27 --> Controller Class Initialized
DEBUG - 2010-06-23 14:39:27 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 14:39:27 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 14:39:27 --> Database Driver Class Initialized
DEBUG - 2010-06-23 14:39:27 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 14:39:28 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 14:39:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:39:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:39:28 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 14:39:28 --> User Agent Class Initialized
DEBUG - 2010-06-23 14:39:28 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 14:39:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:39:28 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 14:44:20 --> Config Class Initialized
DEBUG - 2010-06-23 14:44:20 --> Hooks Class Initialized
DEBUG - 2010-06-23 14:44:20 --> URI Class Initialized
DEBUG - 2010-06-23 14:44:20 --> Router Class Initialized
DEBUG - 2010-06-23 14:44:20 --> Output Class Initialized
DEBUG - 2010-06-23 14:44:20 --> Input Class Initialized
DEBUG - 2010-06-23 14:44:20 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 14:44:20 --> Language Class Initialized
DEBUG - 2010-06-23 14:44:21 --> Loader Class Initialized
DEBUG - 2010-06-23 14:44:21 --> Helper loaded: object_helper
DEBUG - 2010-06-23 14:44:21 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 14:44:21 --> Helper loaded: context_helper
DEBUG - 2010-06-23 14:44:21 --> Session Class Initialized
DEBUG - 2010-06-23 14:44:21 --> Helper loaded: string_helper
DEBUG - 2010-06-23 14:44:21 --> Session routines successfully run
DEBUG - 2010-06-23 14:44:21 --> Helper loaded: context_helper
DEBUG - 2010-06-23 14:44:21 --> Controller Class Initialized
DEBUG - 2010-06-23 14:44:22 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 14:44:22 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 14:44:22 --> Database Driver Class Initialized
DEBUG - 2010-06-23 14:44:22 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 14:44:22 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 14:44:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:44:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:44:22 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 14:44:23 --> User Agent Class Initialized
DEBUG - 2010-06-23 14:44:23 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 14:44:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:44:23 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 14:45:21 --> Config Class Initialized
DEBUG - 2010-06-23 14:45:21 --> Hooks Class Initialized
DEBUG - 2010-06-23 14:45:21 --> URI Class Initialized
DEBUG - 2010-06-23 14:45:22 --> Router Class Initialized
DEBUG - 2010-06-23 14:45:22 --> Output Class Initialized
DEBUG - 2010-06-23 14:45:22 --> Input Class Initialized
DEBUG - 2010-06-23 14:45:22 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 14:45:22 --> Language Class Initialized
DEBUG - 2010-06-23 14:45:22 --> Loader Class Initialized
DEBUG - 2010-06-23 14:45:22 --> Helper loaded: object_helper
DEBUG - 2010-06-23 14:45:22 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 14:45:23 --> Helper loaded: context_helper
DEBUG - 2010-06-23 14:45:23 --> Session Class Initialized
DEBUG - 2010-06-23 14:45:23 --> Helper loaded: string_helper
DEBUG - 2010-06-23 14:45:23 --> Session routines successfully run
DEBUG - 2010-06-23 14:45:23 --> Helper loaded: context_helper
DEBUG - 2010-06-23 14:45:23 --> Controller Class Initialized
DEBUG - 2010-06-23 14:45:23 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 14:45:23 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 14:45:24 --> Database Driver Class Initialized
DEBUG - 2010-06-23 14:45:24 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 14:45:24 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 14:45:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:45:24 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:45:24 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 14:45:24 --> User Agent Class Initialized
DEBUG - 2010-06-23 14:45:24 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 14:45:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:45:25 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 14:46:10 --> Config Class Initialized
DEBUG - 2010-06-23 14:46:10 --> Hooks Class Initialized
DEBUG - 2010-06-23 14:46:10 --> URI Class Initialized
DEBUG - 2010-06-23 14:46:10 --> Router Class Initialized
DEBUG - 2010-06-23 14:46:10 --> Output Class Initialized
DEBUG - 2010-06-23 14:46:10 --> Input Class Initialized
DEBUG - 2010-06-23 14:46:11 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 14:46:11 --> Language Class Initialized
DEBUG - 2010-06-23 14:46:11 --> Loader Class Initialized
DEBUG - 2010-06-23 14:46:11 --> Helper loaded: object_helper
DEBUG - 2010-06-23 14:46:11 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 14:46:11 --> Helper loaded: context_helper
DEBUG - 2010-06-23 14:46:11 --> Session Class Initialized
DEBUG - 2010-06-23 14:46:11 --> Helper loaded: string_helper
DEBUG - 2010-06-23 14:46:11 --> Session routines successfully run
DEBUG - 2010-06-23 14:46:12 --> Helper loaded: context_helper
DEBUG - 2010-06-23 14:46:12 --> Controller Class Initialized
DEBUG - 2010-06-23 14:46:12 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 14:46:12 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 14:46:12 --> Database Driver Class Initialized
DEBUG - 2010-06-23 14:46:12 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 14:46:12 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 14:46:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:46:13 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:46:13 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 14:46:13 --> User Agent Class Initialized
DEBUG - 2010-06-23 14:46:13 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 14:46:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:46:13 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 14:46:41 --> Config Class Initialized
DEBUG - 2010-06-23 14:46:42 --> Hooks Class Initialized
DEBUG - 2010-06-23 14:46:42 --> URI Class Initialized
DEBUG - 2010-06-23 14:46:42 --> Router Class Initialized
DEBUG - 2010-06-23 14:46:42 --> Output Class Initialized
DEBUG - 2010-06-23 14:46:42 --> Input Class Initialized
DEBUG - 2010-06-23 14:46:42 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 14:46:42 --> Language Class Initialized
DEBUG - 2010-06-23 14:46:42 --> Loader Class Initialized
DEBUG - 2010-06-23 14:46:43 --> Helper loaded: object_helper
DEBUG - 2010-06-23 14:46:43 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 14:46:43 --> Helper loaded: context_helper
DEBUG - 2010-06-23 14:46:43 --> Session Class Initialized
DEBUG - 2010-06-23 14:46:43 --> Helper loaded: string_helper
DEBUG - 2010-06-23 14:46:43 --> Session routines successfully run
DEBUG - 2010-06-23 14:46:43 --> Helper loaded: context_helper
DEBUG - 2010-06-23 14:46:43 --> Controller Class Initialized
DEBUG - 2010-06-23 14:46:43 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 14:46:44 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 14:46:44 --> Database Driver Class Initialized
DEBUG - 2010-06-23 14:46:44 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 14:46:44 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 14:46:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:46:44 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:46:44 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 14:46:44 --> User Agent Class Initialized
DEBUG - 2010-06-23 14:46:45 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 14:46:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:46:45 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 14:46:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:46:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:46:45 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 14:46:45 --> Final output sent to browser
DEBUG - 2010-06-23 14:46:45 --> Total execution time: 3.8286
DEBUG - 2010-06-23 14:46:59 --> Config Class Initialized
DEBUG - 2010-06-23 14:46:59 --> Hooks Class Initialized
DEBUG - 2010-06-23 14:46:59 --> URI Class Initialized
DEBUG - 2010-06-23 14:46:59 --> Router Class Initialized
DEBUG - 2010-06-23 14:46:59 --> Output Class Initialized
DEBUG - 2010-06-23 14:46:59 --> Input Class Initialized
DEBUG - 2010-06-23 14:46:59 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 14:46:59 --> Language Class Initialized
DEBUG - 2010-06-23 14:47:00 --> Loader Class Initialized
DEBUG - 2010-06-23 14:47:00 --> Helper loaded: object_helper
DEBUG - 2010-06-23 14:47:00 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 14:47:00 --> Helper loaded: context_helper
DEBUG - 2010-06-23 14:47:00 --> Session Class Initialized
DEBUG - 2010-06-23 14:47:00 --> Helper loaded: string_helper
DEBUG - 2010-06-23 14:47:00 --> Session routines successfully run
DEBUG - 2010-06-23 14:47:00 --> Helper loaded: context_helper
DEBUG - 2010-06-23 14:47:00 --> Controller Class Initialized
DEBUG - 2010-06-23 14:47:01 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 14:47:01 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 14:47:01 --> Database Driver Class Initialized
DEBUG - 2010-06-23 14:47:01 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 14:47:01 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 14:47:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:47:01 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:47:01 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 14:47:02 --> User Agent Class Initialized
DEBUG - 2010-06-23 14:47:02 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 14:47:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:47:02 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 14:47:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:47:02 --> Domain class already loaded. Second attempt ignored.
INFO  - 2010-06-23 14:47:02 --> User update: (28) pudding : 
DEBUG - 2010-06-23 14:47:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:47:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:47:03 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:47:03 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:47:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:47:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:47:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:47:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:47:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:47:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:47:04 --> Helper loaded: email_helper
DEBUG - 2010-06-23 14:47:04 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:47:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:47:04 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 14:47:04 --> Severity: Notice  --> Undefined variable: test_result D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_actor\ut_user.php 122
ERROR - 2010-06-23 14:47:04 --> Severity: Notice  --> Undefined variable: expected_result D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_actor\ut_user.php 123
ERROR - 2010-06-23 14:47:04 --> Severity: Notice  --> Undefined variable: test_name D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_actor\ut_user.php 124
DEBUG - 2010-06-23 14:47:05 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 14:47:05 --> Final output sent to browser
DEBUG - 2010-06-23 14:47:05 --> Total execution time: 6.1448
DEBUG - 2010-06-23 14:48:00 --> Config Class Initialized
DEBUG - 2010-06-23 14:48:00 --> Hooks Class Initialized
DEBUG - 2010-06-23 14:48:00 --> URI Class Initialized
DEBUG - 2010-06-23 14:48:00 --> Router Class Initialized
DEBUG - 2010-06-23 14:48:00 --> Output Class Initialized
DEBUG - 2010-06-23 14:48:00 --> Input Class Initialized
DEBUG - 2010-06-23 14:48:00 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 14:48:01 --> Language Class Initialized
DEBUG - 2010-06-23 14:48:01 --> Loader Class Initialized
DEBUG - 2010-06-23 14:48:01 --> Helper loaded: object_helper
DEBUG - 2010-06-23 14:48:01 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 14:48:01 --> Helper loaded: context_helper
DEBUG - 2010-06-23 14:48:01 --> Session Class Initialized
DEBUG - 2010-06-23 14:48:01 --> Helper loaded: string_helper
DEBUG - 2010-06-23 14:48:01 --> Session routines successfully run
DEBUG - 2010-06-23 14:48:02 --> Helper loaded: context_helper
DEBUG - 2010-06-23 14:48:02 --> Controller Class Initialized
DEBUG - 2010-06-23 14:48:02 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 14:48:02 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 14:48:02 --> Database Driver Class Initialized
DEBUG - 2010-06-23 14:48:02 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 14:48:02 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 14:48:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:48:03 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:48:03 --> User Agent Class Initialized
DEBUG - 2010-06-23 14:48:03 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 14:48:03 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 14:48:03 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 14:48:03 --> User_agent class already loaded. Second attempt ignored.
INFO  - 2010-06-23 14:48:03 --> User update: (30) pudding : 
DEBUG - 2010-06-23 14:48:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:48:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:48:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:48:04 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:48:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:48:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:48:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:48:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:48:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:48:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:48:05 --> Helper loaded: email_helper
DEBUG - 2010-06-23 14:48:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:48:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:48:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:48:05 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 14:48:05 --> Final output sent to browser
DEBUG - 2010-06-23 14:48:05 --> Total execution time: 5.5756
DEBUG - 2010-06-23 14:52:00 --> Config Class Initialized
DEBUG - 2010-06-23 14:52:00 --> Hooks Class Initialized
DEBUG - 2010-06-23 14:52:00 --> URI Class Initialized
DEBUG - 2010-06-23 14:52:01 --> Router Class Initialized
DEBUG - 2010-06-23 14:52:01 --> Output Class Initialized
DEBUG - 2010-06-23 14:52:01 --> Input Class Initialized
DEBUG - 2010-06-23 14:52:01 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 14:52:01 --> Language Class Initialized
DEBUG - 2010-06-23 14:52:01 --> Loader Class Initialized
DEBUG - 2010-06-23 14:52:01 --> Helper loaded: object_helper
DEBUG - 2010-06-23 14:52:01 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 14:52:02 --> Helper loaded: context_helper
DEBUG - 2010-06-23 14:52:02 --> Session Class Initialized
DEBUG - 2010-06-23 14:52:02 --> Helper loaded: string_helper
DEBUG - 2010-06-23 14:52:02 --> Session routines successfully run
DEBUG - 2010-06-23 14:52:02 --> Helper loaded: context_helper
DEBUG - 2010-06-23 14:52:02 --> Controller Class Initialized
DEBUG - 2010-06-23 14:52:02 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 14:52:03 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 14:52:03 --> Database Driver Class Initialized
DEBUG - 2010-06-23 14:52:03 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 14:52:03 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 14:52:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:52:03 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:52:03 --> User Agent Class Initialized
DEBUG - 2010-06-23 14:52:03 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 14:52:04 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 14:52:04 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 14:52:04 --> User_agent class already loaded. Second attempt ignored.
INFO  - 2010-06-23 14:52:04 --> User update: (32) pudding : 
DEBUG - 2010-06-23 14:52:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:52:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:52:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:52:04 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:52:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:52:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:52:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:52:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:52:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:52:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:52:05 --> Helper loaded: email_helper
DEBUG - 2010-06-23 14:52:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:52:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:52:06 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 14:52:06 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;0&quot; does not exist
LINE 2: WHERE &quot;0&quot; = 'user_id'
              ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-23 14:52:06 --> DB Transaction Failure
ERROR - 2010-06-23 14:52:06 --> Query error: ERROR:  column "0" does not exist
LINE 2: WHERE "0" = 'user_id'
              ^
DEBUG - 2010-06-23 14:52:06 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-06-23 14:53:21 --> Config Class Initialized
DEBUG - 2010-06-23 14:53:21 --> Hooks Class Initialized
DEBUG - 2010-06-23 14:53:21 --> URI Class Initialized
DEBUG - 2010-06-23 14:53:21 --> Router Class Initialized
DEBUG - 2010-06-23 14:53:21 --> Output Class Initialized
DEBUG - 2010-06-23 14:53:21 --> Input Class Initialized
DEBUG - 2010-06-23 14:53:21 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 14:53:21 --> Language Class Initialized
DEBUG - 2010-06-23 14:53:22 --> Loader Class Initialized
DEBUG - 2010-06-23 14:53:22 --> Helper loaded: object_helper
DEBUG - 2010-06-23 14:53:22 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 14:53:22 --> Helper loaded: context_helper
DEBUG - 2010-06-23 14:53:22 --> Session Class Initialized
DEBUG - 2010-06-23 14:53:22 --> Helper loaded: string_helper
DEBUG - 2010-06-23 14:53:22 --> Session routines successfully run
DEBUG - 2010-06-23 14:53:22 --> Helper loaded: context_helper
DEBUG - 2010-06-23 14:53:23 --> Controller Class Initialized
DEBUG - 2010-06-23 14:53:23 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 14:53:23 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 14:53:23 --> Database Driver Class Initialized
DEBUG - 2010-06-23 14:53:23 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 14:53:23 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 14:53:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:53:23 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:53:24 --> User Agent Class Initialized
DEBUG - 2010-06-23 14:53:24 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 14:53:24 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 14:53:24 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 14:53:24 --> User_agent class already loaded. Second attempt ignored.
INFO  - 2010-06-23 14:53:24 --> User update: (34) pudding : 
DEBUG - 2010-06-23 14:53:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:53:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:53:24 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:53:25 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:53:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:53:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:53:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:53:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:53:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:53:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:53:25 --> Helper loaded: email_helper
DEBUG - 2010-06-23 14:53:26 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:53:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:53:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 14:53:26 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 14:53:26 --> Final output sent to browser
DEBUG - 2010-06-23 14:53:26 --> Total execution time: 5.5704
DEBUG - 2010-06-23 15:36:19 --> Config Class Initialized
DEBUG - 2010-06-23 15:36:19 --> Config Class Initialized
DEBUG - 2010-06-23 15:36:19 --> Config Class Initialized
DEBUG - 2010-06-23 15:36:19 --> Hooks Class Initialized
DEBUG - 2010-06-23 15:36:19 --> Hooks Class Initialized
DEBUG - 2010-06-23 15:36:19 --> URI Class Initialized
DEBUG - 2010-06-23 15:36:19 --> Hooks Class Initialized
DEBUG - 2010-06-23 15:36:19 --> Router Class Initialized
DEBUG - 2010-06-23 15:36:19 --> URI Class Initialized
DEBUG - 2010-06-23 15:36:19 --> Output Class Initialized
DEBUG - 2010-06-23 15:36:19 --> URI Class Initialized
DEBUG - 2010-06-23 15:36:20 --> Input Class Initialized
DEBUG - 2010-06-23 15:36:20 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 15:36:20 --> Router Class Initialized
DEBUG - 2010-06-23 15:36:20 --> Router Class Initialized
DEBUG - 2010-06-23 15:36:20 --> Language Class Initialized
DEBUG - 2010-06-23 15:36:20 --> Output Class Initialized
DEBUG - 2010-06-23 15:36:20 --> Output Class Initialized
DEBUG - 2010-06-23 15:36:20 --> Loader Class Initialized
DEBUG - 2010-06-23 15:36:20 --> Helper loaded: object_helper
DEBUG - 2010-06-23 15:36:20 --> Input Class Initialized
DEBUG - 2010-06-23 15:36:20 --> Input Class Initialized
DEBUG - 2010-06-23 15:36:20 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 15:36:20 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 15:36:21 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 15:36:21 --> Language Class Initialized
DEBUG - 2010-06-23 15:36:21 --> Helper loaded: context_helper
DEBUG - 2010-06-23 15:36:21 --> Language Class Initialized
DEBUG - 2010-06-23 15:36:21 --> Loader Class Initialized
DEBUG - 2010-06-23 15:36:21 --> Loader Class Initialized
DEBUG - 2010-06-23 15:36:21 --> Session Class Initialized
DEBUG - 2010-06-23 15:36:21 --> Helper loaded: object_helper
DEBUG - 2010-06-23 15:36:21 --> Helper loaded: object_helper
DEBUG - 2010-06-23 15:36:21 --> Helper loaded: string_helper
DEBUG - 2010-06-23 15:36:21 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 15:36:21 --> Session routines successfully run
DEBUG - 2010-06-23 15:36:21 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 15:36:22 --> Helper loaded: context_helper
DEBUG - 2010-06-23 15:36:22 --> Helper loaded: context_helper
DEBUG - 2010-06-23 15:36:22 --> Controller Class Initialized
DEBUG - 2010-06-23 15:36:22 --> Helper loaded: context_helper
DEBUG - 2010-06-23 15:36:22 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 15:36:22 --> Session Class Initialized
DEBUG - 2010-06-23 15:36:22 --> Session Class Initialized
DEBUG - 2010-06-23 15:36:22 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 15:36:22 --> Helper loaded: string_helper
DEBUG - 2010-06-23 15:36:22 --> Helper loaded: string_helper
DEBUG - 2010-06-23 15:36:22 --> Session routines successfully run
DEBUG - 2010-06-23 15:36:22 --> Session routines successfully run
DEBUG - 2010-06-23 15:36:22 --> Helper loaded: context_helper
DEBUG - 2010-06-23 15:36:22 --> Controller Class Initialized
DEBUG - 2010-06-23 15:36:22 --> Helper loaded: context_helper
DEBUG - 2010-06-23 15:36:22 --> Database Driver Class Initialized
DEBUG - 2010-06-23 15:36:23 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 15:36:23 --> Controller Class Initialized
DEBUG - 2010-06-23 15:36:23 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 15:36:23 --> Database Driver Class Initialized
DEBUG - 2010-06-23 15:36:23 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 15:36:23 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 15:36:23 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 15:36:23 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 15:36:23 --> Database Driver Class Initialized
DEBUG - 2010-06-23 15:36:23 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 15:36:23 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 15:36:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 15:36:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 15:36:24 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 15:36:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 15:36:24 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 15:36:25 --> User Agent Class Initialized
DEBUG - 2010-06-23 15:36:25 --> Config file loaded: config/config.php
INFO  - 2010-06-23 15:36:25 --> Webpage Create: (13) /p/5x1uan#response-1650638188 PHP布丁 說 [CODING D4] 目前進度5/182。希望今天能夠打起精神好好地來做！ - #5x1uan
DEBUG - 2010-06-23 15:36:25 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 15:36:25 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 15:36:25 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 15:36:25 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 15:36:25 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 15:36:25 --> Domain class already loaded. Second attempt ignored.
INFO  - 2010-06-23 15:36:25 --> User update: (36) pudding : 
DEBUG - 2010-06-23 15:36:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 15:36:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 15:36:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 15:36:26 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 15:36:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 15:36:26 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 15:36:26 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 15:36:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 15:36:26 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 15:36:26 --> Severity: Warning  --> fopen() [<a href='function.fopen'>function.fopen</a>]: php_network_getaddresses: getaddrinfo failed: �n�D���W�٥��T�A���䤣��ҭn�D��������ơC  D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 203
DEBUG - 2010-06-23 15:36:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 15:36:26 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
ERROR - 2010-06-23 15:36:26 --> Severity: Warning  --> fopen(http://www.lib.nccu.edu.tw/) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: php_network_getaddresses: getaddrinfo failed: �n�D���W�٥��T�A���䤣��ҭn�D��������ơC  D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 203
DEBUG - 2010-06-23 15:36:26 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-23 15:36:26 --> Severity: Warning  --> fread(): supplied argument is not a valid stream resource D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 204
DEBUG - 2010-06-23 15:36:26 --> Final output sent to browser
ERROR - 2010-06-23 15:36:27 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 205
DEBUG - 2010-06-23 15:36:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 15:36:27 --> Total execution time: 7.4728
DEBUG - 2010-06-23 15:36:27 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 15:36:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 15:36:27 --> Helper loaded: email_helper
DEBUG - 2010-06-23 15:36:27 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 15:36:27 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 15:36:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 15:36:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 15:36:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 15:36:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 15:36:28 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 15:36:28 --> Final output sent to browser
DEBUG - 2010-06-23 15:36:28 --> Total execution time: 8.8205
DEBUG - 2010-06-23 15:36:28 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 15:36:28 --> Final output sent to browser
DEBUG - 2010-06-23 15:36:28 --> Total execution time: 9.4124
DEBUG - 2010-06-23 16:33:26 --> Config Class Initialized
DEBUG - 2010-06-23 16:33:26 --> Hooks Class Initialized
DEBUG - 2010-06-23 16:33:26 --> URI Class Initialized
DEBUG - 2010-06-23 16:33:26 --> No URI present. Default controller set.
DEBUG - 2010-06-23 16:33:26 --> Router Class Initialized
DEBUG - 2010-06-23 16:33:27 --> Output Class Initialized
DEBUG - 2010-06-23 16:33:27 --> Input Class Initialized
DEBUG - 2010-06-23 16:33:27 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 16:33:27 --> Language Class Initialized
DEBUG - 2010-06-23 16:33:27 --> Loader Class Initialized
DEBUG - 2010-06-23 16:33:27 --> Helper loaded: object_helper
DEBUG - 2010-06-23 16:33:27 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 16:33:27 --> Helper loaded: context_helper
DEBUG - 2010-06-23 16:33:28 --> Session Class Initialized
DEBUG - 2010-06-23 16:33:28 --> Helper loaded: string_helper
DEBUG - 2010-06-23 16:33:28 --> Session routines successfully run
DEBUG - 2010-06-23 16:33:28 --> Helper loaded: context_helper
DEBUG - 2010-06-23 16:33:28 --> Controller Class Initialized
DEBUG - 2010-06-23 16:33:28 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
ERROR - 2010-06-23 16:33:28 --> Unable to load the requested class: user
DEBUG - 2010-06-23 16:33:49 --> Config Class Initialized
DEBUG - 2010-06-23 16:33:49 --> Hooks Class Initialized
DEBUG - 2010-06-23 16:33:49 --> URI Class Initialized
DEBUG - 2010-06-23 16:33:49 --> No URI present. Default controller set.
DEBUG - 2010-06-23 16:33:50 --> Router Class Initialized
DEBUG - 2010-06-23 16:33:50 --> Output Class Initialized
DEBUG - 2010-06-23 16:33:50 --> Input Class Initialized
DEBUG - 2010-06-23 16:33:50 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 16:33:50 --> Language Class Initialized
DEBUG - 2010-06-23 16:33:50 --> Loader Class Initialized
DEBUG - 2010-06-23 16:33:50 --> Helper loaded: object_helper
DEBUG - 2010-06-23 16:33:50 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 16:33:51 --> Helper loaded: context_helper
DEBUG - 2010-06-23 16:33:51 --> Session Class Initialized
DEBUG - 2010-06-23 16:33:51 --> Helper loaded: string_helper
DEBUG - 2010-06-23 16:33:51 --> Session routines successfully run
DEBUG - 2010-06-23 16:33:51 --> Helper loaded: context_helper
DEBUG - 2010-06-23 16:33:51 --> Controller Class Initialized
DEBUG - 2010-06-23 16:33:51 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 16:33:51 --> Database Driver Class Initialized
DEBUG - 2010-06-23 16:33:52 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 16:33:52 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 16:33:52 --> Final output sent to browser
DEBUG - 2010-06-23 16:33:52 --> Total execution time: 2.8126
DEBUG - 2010-06-23 16:33:55 --> Config Class Initialized
DEBUG - 2010-06-23 16:33:55 --> Hooks Class Initialized
DEBUG - 2010-06-23 16:33:55 --> URI Class Initialized
DEBUG - 2010-06-23 16:33:55 --> No URI present. Default controller set.
DEBUG - 2010-06-23 16:33:55 --> Router Class Initialized
DEBUG - 2010-06-23 16:33:56 --> Output Class Initialized
DEBUG - 2010-06-23 16:33:56 --> Input Class Initialized
DEBUG - 2010-06-23 16:33:56 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 16:33:56 --> Language Class Initialized
DEBUG - 2010-06-23 16:33:56 --> Loader Class Initialized
DEBUG - 2010-06-23 16:33:56 --> Helper loaded: object_helper
DEBUG - 2010-06-23 16:33:56 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 16:33:56 --> Helper loaded: context_helper
DEBUG - 2010-06-23 16:33:57 --> Session Class Initialized
DEBUG - 2010-06-23 16:33:57 --> Helper loaded: string_helper
DEBUG - 2010-06-23 16:33:57 --> Session routines successfully run
DEBUG - 2010-06-23 16:33:57 --> Helper loaded: context_helper
DEBUG - 2010-06-23 16:33:57 --> Controller Class Initialized
DEBUG - 2010-06-23 16:33:57 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 16:33:57 --> Database Driver Class Initialized
DEBUG - 2010-06-23 16:33:57 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 16:33:58 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 16:33:58 --> Final output sent to browser
DEBUG - 2010-06-23 16:33:58 --> Total execution time: 2.7591
DEBUG - 2010-06-23 16:34:00 --> Config Class Initialized
DEBUG - 2010-06-23 16:34:00 --> Hooks Class Initialized
DEBUG - 2010-06-23 16:34:00 --> URI Class Initialized
DEBUG - 2010-06-23 16:34:00 --> No URI present. Default controller set.
DEBUG - 2010-06-23 16:34:01 --> Router Class Initialized
DEBUG - 2010-06-23 16:34:01 --> Output Class Initialized
DEBUG - 2010-06-23 16:34:01 --> Input Class Initialized
DEBUG - 2010-06-23 16:34:01 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 16:34:01 --> Language Class Initialized
DEBUG - 2010-06-23 16:34:01 --> Loader Class Initialized
DEBUG - 2010-06-23 16:34:01 --> Helper loaded: object_helper
DEBUG - 2010-06-23 16:34:01 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 16:34:02 --> Helper loaded: context_helper
DEBUG - 2010-06-23 16:34:02 --> Session Class Initialized
DEBUG - 2010-06-23 16:34:02 --> Helper loaded: string_helper
DEBUG - 2010-06-23 16:34:02 --> Session routines successfully run
DEBUG - 2010-06-23 16:34:02 --> Helper loaded: context_helper
DEBUG - 2010-06-23 16:34:02 --> Controller Class Initialized
DEBUG - 2010-06-23 16:34:02 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 16:34:02 --> Database Driver Class Initialized
DEBUG - 2010-06-23 16:34:03 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 16:34:03 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 16:34:03 --> Final output sent to browser
DEBUG - 2010-06-23 16:34:03 --> Total execution time: 2.7717
DEBUG - 2010-06-23 16:34:05 --> Config Class Initialized
DEBUG - 2010-06-23 16:34:05 --> Hooks Class Initialized
DEBUG - 2010-06-23 16:34:05 --> URI Class Initialized
DEBUG - 2010-06-23 16:34:05 --> No URI present. Default controller set.
DEBUG - 2010-06-23 16:34:06 --> Router Class Initialized
DEBUG - 2010-06-23 16:34:06 --> Output Class Initialized
DEBUG - 2010-06-23 16:34:06 --> Input Class Initialized
DEBUG - 2010-06-23 16:34:06 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 16:34:06 --> Language Class Initialized
DEBUG - 2010-06-23 16:34:06 --> Loader Class Initialized
DEBUG - 2010-06-23 16:34:06 --> Helper loaded: object_helper
DEBUG - 2010-06-23 16:34:06 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 16:34:07 --> Helper loaded: context_helper
DEBUG - 2010-06-23 16:34:07 --> Session Class Initialized
DEBUG - 2010-06-23 16:34:07 --> Helper loaded: string_helper
DEBUG - 2010-06-23 16:34:07 --> Session routines successfully run
DEBUG - 2010-06-23 16:34:07 --> Helper loaded: context_helper
DEBUG - 2010-06-23 16:34:07 --> Controller Class Initialized
DEBUG - 2010-06-23 16:34:07 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 16:34:07 --> Database Driver Class Initialized
DEBUG - 2010-06-23 16:34:08 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 16:34:08 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 16:34:08 --> Final output sent to browser
DEBUG - 2010-06-23 16:34:08 --> Total execution time: 2.7794
DEBUG - 2010-06-23 16:34:43 --> Config Class Initialized
DEBUG - 2010-06-23 16:34:43 --> Hooks Class Initialized
DEBUG - 2010-06-23 16:34:43 --> URI Class Initialized
DEBUG - 2010-06-23 16:34:43 --> No URI present. Default controller set.
DEBUG - 2010-06-23 16:34:43 --> Router Class Initialized
DEBUG - 2010-06-23 16:34:43 --> Output Class Initialized
DEBUG - 2010-06-23 16:34:43 --> Input Class Initialized
DEBUG - 2010-06-23 16:34:43 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 16:34:44 --> Language Class Initialized
DEBUG - 2010-06-23 16:34:44 --> Loader Class Initialized
DEBUG - 2010-06-23 16:34:44 --> Helper loaded: object_helper
DEBUG - 2010-06-23 16:34:44 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 16:34:44 --> Helper loaded: context_helper
DEBUG - 2010-06-23 16:34:44 --> Session Class Initialized
DEBUG - 2010-06-23 16:34:44 --> Helper loaded: string_helper
DEBUG - 2010-06-23 16:34:44 --> Session routines successfully run
DEBUG - 2010-06-23 16:34:45 --> Helper loaded: context_helper
DEBUG - 2010-06-23 16:34:45 --> Controller Class Initialized
DEBUG - 2010-06-23 16:34:45 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 16:34:45 --> Database Driver Class Initialized
DEBUG - 2010-06-23 16:34:45 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 16:34:45 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 16:34:45 --> Final output sent to browser
DEBUG - 2010-06-23 16:34:46 --> Total execution time: 2.8498
DEBUG - 2010-06-23 16:34:47 --> Config Class Initialized
DEBUG - 2010-06-23 16:34:47 --> Hooks Class Initialized
DEBUG - 2010-06-23 16:34:47 --> URI Class Initialized
DEBUG - 2010-06-23 16:34:47 --> No URI present. Default controller set.
DEBUG - 2010-06-23 16:34:47 --> Router Class Initialized
DEBUG - 2010-06-23 16:34:47 --> Output Class Initialized
DEBUG - 2010-06-23 16:34:47 --> Input Class Initialized
DEBUG - 2010-06-23 16:34:48 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 16:34:48 --> Language Class Initialized
DEBUG - 2010-06-23 16:34:48 --> Loader Class Initialized
DEBUG - 2010-06-23 16:34:48 --> Helper loaded: object_helper
DEBUG - 2010-06-23 16:34:48 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 16:34:48 --> Helper loaded: context_helper
DEBUG - 2010-06-23 16:34:48 --> Session Class Initialized
DEBUG - 2010-06-23 16:34:48 --> Helper loaded: string_helper
DEBUG - 2010-06-23 16:34:49 --> Session routines successfully run
DEBUG - 2010-06-23 16:34:49 --> Helper loaded: context_helper
DEBUG - 2010-06-23 16:34:49 --> Controller Class Initialized
DEBUG - 2010-06-23 16:34:49 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 16:34:49 --> Database Driver Class Initialized
DEBUG - 2010-06-23 16:34:49 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 16:34:49 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 16:34:49 --> Final output sent to browser
DEBUG - 2010-06-23 16:34:50 --> Total execution time: 2.8031
DEBUG - 2010-06-23 16:34:51 --> Config Class Initialized
DEBUG - 2010-06-23 16:34:51 --> Hooks Class Initialized
DEBUG - 2010-06-23 16:34:51 --> URI Class Initialized
DEBUG - 2010-06-23 16:34:52 --> No URI present. Default controller set.
DEBUG - 2010-06-23 16:34:52 --> Router Class Initialized
DEBUG - 2010-06-23 16:34:52 --> Output Class Initialized
DEBUG - 2010-06-23 16:34:52 --> Input Class Initialized
DEBUG - 2010-06-23 16:34:52 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 16:34:52 --> Language Class Initialized
DEBUG - 2010-06-23 16:34:52 --> Loader Class Initialized
DEBUG - 2010-06-23 16:34:52 --> Helper loaded: object_helper
DEBUG - 2010-06-23 16:34:53 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 16:34:53 --> Helper loaded: context_helper
DEBUG - 2010-06-23 16:34:53 --> Session Class Initialized
DEBUG - 2010-06-23 16:34:53 --> Helper loaded: string_helper
DEBUG - 2010-06-23 16:34:53 --> Session routines successfully run
DEBUG - 2010-06-23 16:34:53 --> Helper loaded: context_helper
DEBUG - 2010-06-23 16:34:53 --> Controller Class Initialized
DEBUG - 2010-06-23 16:34:53 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-23 16:34:54 --> Database Driver Class Initialized
DEBUG - 2010-06-23 16:34:54 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 16:34:54 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 16:34:54 --> Final output sent to browser
DEBUG - 2010-06-23 16:34:54 --> Total execution time: 2.8343
DEBUG - 2010-06-23 16:39:04 --> Config Class Initialized
DEBUG - 2010-06-23 16:39:04 --> Hooks Class Initialized
DEBUG - 2010-06-23 16:39:04 --> URI Class Initialized
DEBUG - 2010-06-23 16:39:04 --> Router Class Initialized
DEBUG - 2010-06-23 16:39:05 --> Output Class Initialized
DEBUG - 2010-06-23 16:39:05 --> Input Class Initialized
DEBUG - 2010-06-23 16:39:05 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 16:39:05 --> Language Class Initialized
DEBUG - 2010-06-23 16:39:05 --> Loader Class Initialized
DEBUG - 2010-06-23 16:39:05 --> Helper loaded: object_helper
DEBUG - 2010-06-23 16:39:05 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 16:39:06 --> Helper loaded: context_helper
DEBUG - 2010-06-23 16:39:06 --> Session Class Initialized
DEBUG - 2010-06-23 16:39:06 --> Helper loaded: string_helper
DEBUG - 2010-06-23 16:39:06 --> Session routines successfully run
DEBUG - 2010-06-23 16:39:06 --> Helper loaded: context_helper
DEBUG - 2010-06-23 16:39:06 --> Controller Class Initialized
DEBUG - 2010-06-23 16:39:06 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 16:39:06 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 16:39:07 --> Database Driver Class Initialized
DEBUG - 2010-06-23 16:39:07 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 16:39:07 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 16:39:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 16:39:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 16:39:07 --> User Agent Class Initialized
DEBUG - 2010-06-23 16:39:07 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 16:39:08 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 16:39:08 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 16:39:08 --> User_agent class already loaded. Second attempt ignored.
INFO  - 2010-06-23 16:39:08 --> User update: (38) pudding : 
DEBUG - 2010-06-23 16:39:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 16:39:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 16:39:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 16:39:09 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 16:39:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 16:39:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 16:39:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 16:39:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 16:39:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 16:39:09 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 16:39:09 --> Helper loaded: email_helper
DEBUG - 2010-06-23 16:39:10 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 16:39:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 16:39:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 16:39:10 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 16:39:10 --> Final output sent to browser
DEBUG - 2010-06-23 16:39:10 --> Total execution time: 6.0674
DEBUG - 2010-06-23 17:16:47 --> Config Class Initialized
DEBUG - 2010-06-23 17:16:47 --> Hooks Class Initialized
DEBUG - 2010-06-23 17:16:47 --> URI Class Initialized
DEBUG - 2010-06-23 17:16:47 --> Router Class Initialized
DEBUG - 2010-06-23 17:16:47 --> Output Class Initialized
DEBUG - 2010-06-23 17:16:48 --> Input Class Initialized
DEBUG - 2010-06-23 17:16:48 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 17:16:48 --> Language Class Initialized
DEBUG - 2010-06-23 17:16:48 --> Loader Class Initialized
DEBUG - 2010-06-23 17:16:48 --> Helper loaded: object_helper
DEBUG - 2010-06-23 17:16:48 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 17:16:48 --> Helper loaded: context_helper
DEBUG - 2010-06-23 17:16:49 --> Session Class Initialized
DEBUG - 2010-06-23 17:16:49 --> Helper loaded: string_helper
DEBUG - 2010-06-23 17:16:49 --> Session routines successfully run
DEBUG - 2010-06-23 17:16:49 --> Helper loaded: context_helper
DEBUG - 2010-06-23 17:16:49 --> Controller Class Initialized
DEBUG - 2010-06-23 17:16:49 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 17:16:49 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 17:16:49 --> Database Driver Class Initialized
DEBUG - 2010-06-23 17:16:50 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 17:16:50 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 17:16:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:16:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:16:50 --> User Agent Class Initialized
DEBUG - 2010-06-23 17:16:50 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 17:16:50 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 17:16:51 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 17:16:51 --> User_agent class already loaded. Second attempt ignored.
INFO  - 2010-06-23 17:16:51 --> User update: (40) pudding : 
DEBUG - 2010-06-23 17:16:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:16:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:16:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:16:51 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:16:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:16:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:16:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:16:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:16:52 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:16:52 --> Helper loaded: email_helper
DEBUG - 2010-06-23 17:16:52 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:16:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:16:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:16:53 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 17:16:53 --> Final output sent to browser
DEBUG - 2010-06-23 17:16:53 --> Total execution time: 5.8841
DEBUG - 2010-06-23 17:17:13 --> Config Class Initialized
DEBUG - 2010-06-23 17:17:14 --> Hooks Class Initialized
DEBUG - 2010-06-23 17:17:14 --> URI Class Initialized
DEBUG - 2010-06-23 17:17:14 --> Router Class Initialized
DEBUG - 2010-06-23 17:17:14 --> Output Class Initialized
DEBUG - 2010-06-23 17:17:14 --> Input Class Initialized
DEBUG - 2010-06-23 17:17:14 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 17:17:14 --> Language Class Initialized
DEBUG - 2010-06-23 17:17:14 --> Loader Class Initialized
DEBUG - 2010-06-23 17:17:15 --> Helper loaded: object_helper
DEBUG - 2010-06-23 17:17:15 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 17:17:15 --> Helper loaded: context_helper
DEBUG - 2010-06-23 17:17:15 --> Session Class Initialized
DEBUG - 2010-06-23 17:17:15 --> Helper loaded: string_helper
DEBUG - 2010-06-23 17:17:15 --> Session routines successfully run
DEBUG - 2010-06-23 17:17:15 --> Helper loaded: context_helper
DEBUG - 2010-06-23 17:17:16 --> Controller Class Initialized
DEBUG - 2010-06-23 17:17:16 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 17:17:16 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 17:17:16 --> Database Driver Class Initialized
DEBUG - 2010-06-23 17:17:16 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 17:17:16 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 17:17:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:17 --> User Agent Class Initialized
DEBUG - 2010-06-23 17:17:17 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 17:17:17 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 17:17:17 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 17:17:17 --> User_agent class already loaded. Second attempt ignored.
INFO  - 2010-06-23 17:17:17 --> User update: (42) pudding : 
DEBUG - 2010-06-23 17:17:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:18 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:19 --> Helper loaded: email_helper
DEBUG - 2010-06-23 17:17:19 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:19 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 17:17:19 --> Final output sent to browser
DEBUG - 2010-06-23 17:17:19 --> Total execution time: 5.7636
DEBUG - 2010-06-23 17:17:33 --> Config Class Initialized
DEBUG - 2010-06-23 17:17:34 --> Hooks Class Initialized
DEBUG - 2010-06-23 17:17:34 --> URI Class Initialized
DEBUG - 2010-06-23 17:17:34 --> Router Class Initialized
DEBUG - 2010-06-23 17:17:34 --> Output Class Initialized
DEBUG - 2010-06-23 17:17:34 --> Input Class Initialized
DEBUG - 2010-06-23 17:17:34 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 17:17:34 --> Language Class Initialized
DEBUG - 2010-06-23 17:17:34 --> Loader Class Initialized
DEBUG - 2010-06-23 17:17:35 --> Helper loaded: object_helper
DEBUG - 2010-06-23 17:17:35 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 17:17:35 --> Helper loaded: context_helper
DEBUG - 2010-06-23 17:17:35 --> Session Class Initialized
DEBUG - 2010-06-23 17:17:35 --> Helper loaded: string_helper
DEBUG - 2010-06-23 17:17:35 --> Session routines successfully run
DEBUG - 2010-06-23 17:17:35 --> Helper loaded: context_helper
DEBUG - 2010-06-23 17:17:35 --> Controller Class Initialized
DEBUG - 2010-06-23 17:17:36 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 17:17:36 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 17:17:36 --> Database Driver Class Initialized
DEBUG - 2010-06-23 17:17:36 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 17:17:36 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 17:17:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:36 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:37 --> User Agent Class Initialized
DEBUG - 2010-06-23 17:17:37 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 17:17:37 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 17:17:37 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 17:17:37 --> User_agent class already loaded. Second attempt ignored.
INFO  - 2010-06-23 17:17:37 --> User update: (44) pudding : 
DEBUG - 2010-06-23 17:17:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:38 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:38 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:38 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:39 --> Helper loaded: email_helper
DEBUG - 2010-06-23 17:17:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:39 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 17:17:39 --> Final output sent to browser
DEBUG - 2010-06-23 17:17:39 --> Total execution time: 5.8356
DEBUG - 2010-06-23 17:17:41 --> Config Class Initialized
DEBUG - 2010-06-23 17:17:41 --> Hooks Class Initialized
DEBUG - 2010-06-23 17:17:41 --> URI Class Initialized
DEBUG - 2010-06-23 17:17:41 --> Router Class Initialized
DEBUG - 2010-06-23 17:17:41 --> Output Class Initialized
DEBUG - 2010-06-23 17:17:42 --> Input Class Initialized
DEBUG - 2010-06-23 17:17:42 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 17:17:42 --> Language Class Initialized
DEBUG - 2010-06-23 17:17:42 --> Loader Class Initialized
DEBUG - 2010-06-23 17:17:42 --> Helper loaded: object_helper
DEBUG - 2010-06-23 17:17:42 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 17:17:42 --> Helper loaded: context_helper
DEBUG - 2010-06-23 17:17:42 --> Session Class Initialized
DEBUG - 2010-06-23 17:17:43 --> Helper loaded: string_helper
DEBUG - 2010-06-23 17:17:43 --> Session routines successfully run
DEBUG - 2010-06-23 17:17:43 --> Helper loaded: context_helper
DEBUG - 2010-06-23 17:17:43 --> Controller Class Initialized
DEBUG - 2010-06-23 17:17:43 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 17:17:43 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 17:17:43 --> Database Driver Class Initialized
DEBUG - 2010-06-23 17:17:44 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 17:17:44 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 17:17:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:44 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:44 --> User Agent Class Initialized
DEBUG - 2010-06-23 17:17:44 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 17:17:44 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 17:17:44 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 17:17:45 --> User_agent class already loaded. Second attempt ignored.
INFO  - 2010-06-23 17:17:45 --> User update: (46) pudding : 
DEBUG - 2010-06-23 17:17:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:45 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:46 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:46 --> Helper loaded: email_helper
DEBUG - 2010-06-23 17:17:46 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:17:47 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 17:17:47 --> Final output sent to browser
DEBUG - 2010-06-23 17:17:47 --> Total execution time: 5.9527
DEBUG - 2010-06-23 17:19:12 --> Config Class Initialized
DEBUG - 2010-06-23 17:19:12 --> Hooks Class Initialized
DEBUG - 2010-06-23 17:19:12 --> URI Class Initialized
DEBUG - 2010-06-23 17:19:13 --> Router Class Initialized
DEBUG - 2010-06-23 17:19:13 --> Output Class Initialized
DEBUG - 2010-06-23 17:19:13 --> Input Class Initialized
DEBUG - 2010-06-23 17:19:13 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 17:19:13 --> Language Class Initialized
DEBUG - 2010-06-23 17:19:13 --> Loader Class Initialized
DEBUG - 2010-06-23 17:19:13 --> Helper loaded: object_helper
DEBUG - 2010-06-23 17:19:14 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 17:19:14 --> Helper loaded: context_helper
DEBUG - 2010-06-23 17:19:14 --> Session Class Initialized
DEBUG - 2010-06-23 17:19:14 --> Helper loaded: string_helper
DEBUG - 2010-06-23 17:19:14 --> Session routines successfully run
DEBUG - 2010-06-23 17:19:14 --> Helper loaded: context_helper
DEBUG - 2010-06-23 17:19:14 --> Controller Class Initialized
DEBUG - 2010-06-23 17:19:14 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 17:19:15 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 17:19:15 --> Database Driver Class Initialized
DEBUG - 2010-06-23 17:19:15 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 17:19:15 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 17:19:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:15 --> User Agent Class Initialized
DEBUG - 2010-06-23 17:19:16 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 17:19:16 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 17:19:16 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 17:19:16 --> User_agent class already loaded. Second attempt ignored.
INFO  - 2010-06-23 17:19:16 --> User update: (48) pudding : 
DEBUG - 2010-06-23 17:19:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:17 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:17 --> Helper loaded: email_helper
DEBUG - 2010-06-23 17:19:18 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:18 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 17:19:18 --> Final output sent to browser
DEBUG - 2010-06-23 17:19:18 --> Total execution time: 5.9118
DEBUG - 2010-06-23 17:19:22 --> Config Class Initialized
DEBUG - 2010-06-23 17:19:22 --> Hooks Class Initialized
DEBUG - 2010-06-23 17:19:22 --> URI Class Initialized
DEBUG - 2010-06-23 17:19:22 --> Router Class Initialized
DEBUG - 2010-06-23 17:19:22 --> Output Class Initialized
DEBUG - 2010-06-23 17:19:22 --> Input Class Initialized
DEBUG - 2010-06-23 17:19:23 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 17:19:23 --> Language Class Initialized
DEBUG - 2010-06-23 17:19:23 --> Loader Class Initialized
DEBUG - 2010-06-23 17:19:23 --> Helper loaded: object_helper
DEBUG - 2010-06-23 17:19:23 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 17:19:23 --> Helper loaded: context_helper
DEBUG - 2010-06-23 17:19:23 --> Session Class Initialized
DEBUG - 2010-06-23 17:19:23 --> Helper loaded: string_helper
DEBUG - 2010-06-23 17:19:24 --> Session routines successfully run
DEBUG - 2010-06-23 17:19:24 --> Helper loaded: context_helper
DEBUG - 2010-06-23 17:19:24 --> Controller Class Initialized
DEBUG - 2010-06-23 17:19:24 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 17:19:24 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 17:19:24 --> Database Driver Class Initialized
DEBUG - 2010-06-23 17:19:24 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 17:19:25 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 17:19:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:25 --> User Agent Class Initialized
DEBUG - 2010-06-23 17:19:25 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 17:19:25 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 17:19:25 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 17:19:25 --> User_agent class already loaded. Second attempt ignored.
INFO  - 2010-06-23 17:19:26 --> User update: (50) pudding : 
DEBUG - 2010-06-23 17:19:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:26 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:27 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:27 --> Helper loaded: email_helper
DEBUG - 2010-06-23 17:19:27 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:28 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 17:19:28 --> Final output sent to browser
DEBUG - 2010-06-23 17:19:28 --> Total execution time: 5.9371
DEBUG - 2010-06-23 17:19:31 --> Config Class Initialized
DEBUG - 2010-06-23 17:19:31 --> Hooks Class Initialized
DEBUG - 2010-06-23 17:19:31 --> URI Class Initialized
DEBUG - 2010-06-23 17:19:31 --> Router Class Initialized
DEBUG - 2010-06-23 17:19:31 --> Output Class Initialized
DEBUG - 2010-06-23 17:19:32 --> Input Class Initialized
DEBUG - 2010-06-23 17:19:32 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 17:19:32 --> Language Class Initialized
DEBUG - 2010-06-23 17:19:32 --> Loader Class Initialized
DEBUG - 2010-06-23 17:19:32 --> Helper loaded: object_helper
DEBUG - 2010-06-23 17:19:32 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 17:19:32 --> Helper loaded: context_helper
DEBUG - 2010-06-23 17:19:32 --> Session Class Initialized
DEBUG - 2010-06-23 17:19:33 --> Helper loaded: string_helper
DEBUG - 2010-06-23 17:19:33 --> Session routines successfully run
DEBUG - 2010-06-23 17:19:33 --> Helper loaded: context_helper
DEBUG - 2010-06-23 17:19:33 --> Controller Class Initialized
DEBUG - 2010-06-23 17:19:33 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 17:19:33 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 17:19:33 --> Database Driver Class Initialized
DEBUG - 2010-06-23 17:19:34 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 17:19:34 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 17:19:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:34 --> User Agent Class Initialized
DEBUG - 2010-06-23 17:19:34 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 17:19:34 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 17:19:35 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 17:19:35 --> User_agent class already loaded. Second attempt ignored.
INFO  - 2010-06-23 17:19:35 --> User update: (52) pudding : 
DEBUG - 2010-06-23 17:19:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:35 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:35 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:36 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:36 --> Helper loaded: email_helper
DEBUG - 2010-06-23 17:19:36 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:19:37 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 17:19:37 --> Final output sent to browser
DEBUG - 2010-06-23 17:19:37 --> Total execution time: 6.1762
DEBUG - 2010-06-23 17:20:08 --> Config Class Initialized
DEBUG - 2010-06-23 17:20:08 --> Hooks Class Initialized
DEBUG - 2010-06-23 17:20:08 --> URI Class Initialized
DEBUG - 2010-06-23 17:20:09 --> Router Class Initialized
DEBUG - 2010-06-23 17:20:09 --> Output Class Initialized
DEBUG - 2010-06-23 17:20:09 --> Input Class Initialized
DEBUG - 2010-06-23 17:20:09 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 17:20:09 --> Language Class Initialized
DEBUG - 2010-06-23 17:20:09 --> Loader Class Initialized
DEBUG - 2010-06-23 17:20:09 --> Helper loaded: object_helper
DEBUG - 2010-06-23 17:20:10 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 17:20:10 --> Helper loaded: context_helper
DEBUG - 2010-06-23 17:20:10 --> Session Class Initialized
DEBUG - 2010-06-23 17:20:10 --> Helper loaded: string_helper
DEBUG - 2010-06-23 17:20:10 --> Session routines successfully run
DEBUG - 2010-06-23 17:20:10 --> Helper loaded: context_helper
DEBUG - 2010-06-23 17:20:10 --> Controller Class Initialized
DEBUG - 2010-06-23 17:20:11 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 17:20:11 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 17:20:11 --> Database Driver Class Initialized
DEBUG - 2010-06-23 17:20:11 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 17:20:11 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 17:20:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:20:11 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:20:12 --> User Agent Class Initialized
DEBUG - 2010-06-23 17:20:12 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 17:20:12 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 17:20:12 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 17:20:12 --> User_agent class already loaded. Second attempt ignored.
INFO  - 2010-06-23 17:20:12 --> User update: (54) pudding : 
DEBUG - 2010-06-23 17:20:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:20:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:20:13 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:20:13 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:20:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:20:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:20:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:20:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:20:13 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:20:14 --> Helper loaded: email_helper
DEBUG - 2010-06-23 17:20:14 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:20:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:20:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:20:14 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 17:20:14 --> Final output sent to browser
DEBUG - 2010-06-23 17:20:14 --> Total execution time: 6.0464
DEBUG - 2010-06-23 17:21:49 --> Config Class Initialized
DEBUG - 2010-06-23 17:21:49 --> Hooks Class Initialized
DEBUG - 2010-06-23 17:21:49 --> URI Class Initialized
DEBUG - 2010-06-23 17:21:50 --> Router Class Initialized
DEBUG - 2010-06-23 17:21:50 --> Output Class Initialized
DEBUG - 2010-06-23 17:21:50 --> Input Class Initialized
DEBUG - 2010-06-23 17:21:50 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-23 17:21:50 --> Language Class Initialized
DEBUG - 2010-06-23 17:21:50 --> Loader Class Initialized
DEBUG - 2010-06-23 17:21:50 --> Helper loaded: object_helper
DEBUG - 2010-06-23 17:21:50 --> Helper loaded: kals_helper
DEBUG - 2010-06-23 17:21:51 --> Helper loaded: context_helper
DEBUG - 2010-06-23 17:21:51 --> Session Class Initialized
DEBUG - 2010-06-23 17:21:51 --> Helper loaded: string_helper
DEBUG - 2010-06-23 17:21:51 --> Session routines successfully run
DEBUG - 2010-06-23 17:21:51 --> Helper loaded: context_helper
DEBUG - 2010-06-23 17:21:51 --> Controller Class Initialized
DEBUG - 2010-06-23 17:21:51 --> Unit Testing Class Initialized
DEBUG - 2010-06-23 17:21:52 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-23 17:21:52 --> Database Driver Class Initialized
DEBUG - 2010-06-23 17:21:52 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-23 17:21:52 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-23 17:21:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:21:52 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:21:52 --> User Agent Class Initialized
DEBUG - 2010-06-23 17:21:53 --> Config file loaded: config/config.php
DEBUG - 2010-06-23 17:21:53 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-23 17:21:53 --> Config file loaded: config/kals.php
DEBUG - 2010-06-23 17:21:53 --> User_agent class already loaded. Second attempt ignored.
INFO  - 2010-06-23 17:21:53 --> User update: (56) pudding : 
DEBUG - 2010-06-23 17:21:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:21:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:21:54 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:21:54 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:21:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:21:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:21:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:21:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:21:54 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:21:54 --> Helper loaded: email_helper
DEBUG - 2010-06-23 17:21:55 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:21:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:21:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-23 17:21:55 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-23 17:21:55 --> Final output sent to browser
DEBUG - 2010-06-23 17:21:55 --> Total execution time: 6.0980
