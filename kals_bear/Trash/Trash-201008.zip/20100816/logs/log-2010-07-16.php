<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-07-16 01:46:46 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  missing FROM-clause entry for table &quot;annotation&quot;
LINE 3: LEFT JOIN &quot;policy&quot; ON &quot;policy&quot;.&quot;resource_id&quot; = &quot;annotation&quot;....
                                                       ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-16 01:46:46 --> Query error: ERROR:  missing FROM-clause entry for table "annotation"
LINE 3: LEFT JOIN "policy" ON "policy"."resource_id" = "annotation"....
                                                       ^
ERROR - 2010-07-16 04:24:55 --> Severity: Notice  --> Undefined index:  form D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\search\Search_engine.php 365
ERROR - 2010-07-16 04:24:55 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  operator does not exist: integer &gt;=
LINE 6: ...ebpage_id = 138 AND ( (overlap_scope_0.from_index &gt;= AND ove...
                                                             ^
HINT:  No operator matches the given name and argument type(s). You might need to add explicit type casts. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-16 04:24:55 --> Query error: ERROR:  operator does not exist: integer >=
LINE 6: ...ebpage_id = 138 AND ( (overlap_scope_0.from_index >= AND ove...
                                                             ^
HINT:  No operator matches the given name and argument type(s). You might need to add explicit type casts.
ERROR - 2010-07-16 04:24:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-16 04:35:37 --> Severity: Notice  --> Undefined index:  score D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_annotation.php 315
ERROR - 2010-07-16 04:57:32 --> Severity: Notice  --> Undefined index:  score D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_annotation.php 315
ERROR - 2010-07-16 05:01:22 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/b6d767d2f8ed5d21a44b0e5886680cb9) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-16 05:01:23 --> Severity: Notice  --> Undefined index:  score D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_annotation.php 315
ERROR - 2010-07-16 05:21:55 --> Severity: Notice  --> Undefined index:  score D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_annotation.php 315
ERROR - 2010-07-16 05:28:41 --> Severity: Notice  --> Undefined index:  like_count D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Annotation_like_collection.php 55
ERROR - 2010-07-16 05:28:41 --> Severity: Notice  --> Undefined index:  score D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_annotation.php 315
ERROR - 2010-07-16 05:30:24 --> Severity: Notice  --> Undefined index:  score D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_annotation.php 315
ERROR - 2010-07-16 05:34:09 --> Severity: Notice  --> Undefined index:  score D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_annotation.php 315
ERROR - 2010-07-16 05:34:52 --> Severity: Notice  --> Undefined index:  score D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_annotation.php 315
ERROR - 2010-07-16 05:35:00 --> Severity: Notice  --> Undefined index:  score D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_annotation.php 315
ERROR - 2010-07-16 05:35:29 --> Severity: Notice  --> Undefined index:  score D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_annotation.php 315
ERROR - 2010-07-16 05:36:57 --> Severity: Notice  --> Undefined index:  score D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_annotation.php 315
ERROR - 2010-07-16 05:44:11 --> Severity: Notice  --> Undefined index:  score D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_annotation.php 315
ERROR - 2010-07-16 05:52:02 --> Severity: Notice  --> Undefined index:  score D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_annotation.php 315
ERROR - 2010-07-16 05:53:54 --> Severity: Notice  --> Undefined index:  score D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_annotation.php 315
ERROR - 2010-07-16 05:56:49 --> Severity: Notice  --> Undefined index:  score D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_annotation.php 315
ERROR - 2010-07-16 06:00:16 --> Severity: Notice  --> Undefined variable: item D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_collection.php 269
ERROR - 2010-07-16 06:00:16 --> Severity: Notice  --> Undefined variable: item D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_collection.php 269
ERROR - 2010-07-16 06:00:16 --> Severity: Notice  --> Undefined variable: item D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_collection.php 269
ERROR - 2010-07-16 06:00:16 --> Severity: Notice  --> Undefined variable: item D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_collection.php 269
ERROR - 2010-07-16 06:00:16 --> Severity: Notice  --> Undefined variable: item D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_collection.php 269
ERROR - 2010-07-16 06:00:16 --> Severity: Notice  --> Undefined variable: item D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_collection.php 269
ERROR - 2010-07-16 06:00:16 --> Severity: Notice  --> Undefined variable: item D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_collection.php 269
ERROR - 2010-07-16 06:00:16 --> Severity: Notice  --> Undefined variable: item D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_collection.php 269
ERROR - 2010-07-16 06:00:16 --> Severity: Notice  --> Undefined variable: item D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_collection.php 269
ERROR - 2010-07-16 06:00:17 --> Severity: Notice  --> Undefined index:  score D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_annotation.php 315
ERROR - 2010-07-16 06:00:30 --> Severity: Notice  --> Undefined index:  score D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_annotation.php 315
ERROR - 2010-07-16 06:01:38 --> Severity: Notice  --> Undefined offset:  0 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_collection.php 270
ERROR - 2010-07-16 06:04:18 --> Severity: Notice  --> Undefined offset:  0 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_collection.php 271
ERROR - 2010-07-16 06:05:29 --> Severity: Notice  --> Undefined offset:  0 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_collection.php 271
ERROR - 2010-07-16 06:09:46 --> Severity: Notice  --> Undefined offset:  0 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_collection.php 271
ERROR - 2010-07-16 06:10:25 --> Severity: Notice  --> Undefined offset:  0 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_collection.php 271
ERROR - 2010-07-16 06:10:59 --> Severity: Notice  --> Undefined offset:  0 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_collection.php 271
ERROR - 2010-07-16 06:10:59 --> Severity: Notice  --> Undefined offset:  0 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_collection.php 271
ERROR - 2010-07-16 06:10:59 --> Severity: Notice  --> Undefined index:  score D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_annotation.php 315
ERROR - 2010-07-16 06:12:48 --> Severity: Notice  --> Undefined offset:  0 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_collection.php 272
ERROR - 2010-07-16 06:12:48 --> Severity: Notice  --> Undefined offset:  0 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_collection.php 272
ERROR - 2010-07-16 06:12:48 --> Severity: Notice  --> Undefined index:  score D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_annotation.php 315
ERROR - 2010-07-16 06:13:37 --> Severity: Notice  --> Undefined offset:  0 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_collection.php 272
ERROR - 2010-07-16 06:24:01 --> Severity: Notice  --> Undefined offset:  0 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_collection.php 272
ERROR - 2010-07-16 06:25:12 --> Severity: Notice  --> Undefined index:  score D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_annotation.php 315
ERROR - 2010-07-16 06:26:37 --> Severity: Notice  --> Undefined index:  score D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_annotation.php 315
ERROR - 2010-07-16 06:27:32 --> Severity: Notice  --> Undefined index:  score D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_annotation.php 315
ERROR - 2010-07-16 06:28:17 --> Severity: Notice  --> Undefined index:  score D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_annotation.php 315
ERROR - 2010-07-16 06:28:59 --> Severity: Notice  --> Undefined index:  score D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_annotation.php 315
ERROR - 2010-07-16 06:29:25 --> Severity: Notice  --> Undefined index:  score D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_annotation.php 315
ERROR - 2010-07-16 06:29:43 --> Severity: Notice  --> Undefined index:  score D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_annotation.php 315
ERROR - 2010-07-16 06:30:20 --> Severity: Notice  --> Undefined index:  score D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_annotation.php 315
ERROR - 2010-07-16 06:33:30 --> Severity: Notice  --> Undefined index:  score D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_annotation.php 315
ERROR - 2010-07-16 07:12:45 --> 嘗試取出 Annotation_scope物件 的 annotation_id 欄位，但 Annotation_scope物件 不存在 annotation_id 欄位
ERROR - 2010-07-16 07:12:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:393) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-16 07:31:09 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/72b32a1f754ba1c09b3695e0cb6cde7f) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-16 07:31:09 --> 404 Page Not Found --> ut_annotation/anchor_text
ERROR - 2010-07-16 08:12:26 --> Severity: Notice  --> Undefined variable: table D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 232
ERROR - 2010-07-16 08:12:26 --> Severity: Notice  --> Undefined variable: table D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 232
ERROR - 2010-07-16 08:12:26 --> Severity: Notice  --> Undefined variable: table D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 232
ERROR - 2010-07-16 08:12:26 --> Severity: Notice  --> Undefined variable: table D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 232
ERROR - 2010-07-16 08:12:26 --> Severity: Notice  --> Undefined variable: table D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 232
ERROR - 2010-07-16 08:12:26 --> Severity: Notice  --> Undefined variable: table D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 232
ERROR - 2010-07-16 08:12:26 --> Severity: Notice  --> Undefined variable: table D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 232
ERROR - 2010-07-16 08:12:26 --> Severity: Notice  --> Undefined variable: table D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 232
ERROR - 2010-07-16 08:14:22 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/34173cb38f07f89ddbebc2ac9128303f) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-16 10:09:53 --> Severity: Notice  --> Undefined index:  annotation_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 630
ERROR - 2010-07-16 10:12:59 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/d2ddea18f00665ce8623e36bd4e3c7c5) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
