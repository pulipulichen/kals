<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-07-18 02:54:09 --> 嘗試取出 Tip_speech物件 的 tip_type_id 欄位，但 Tip_speech物件 不存在 tip_type_id 欄位
ERROR - 2010-07-18 02:54:46 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-18 02:55:29 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-18 02:55:56 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-18 02:56:07 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-18 02:56:35 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-18 02:58:25 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-18 06:16:22 --> Severity: Notice  --> Undefined variable: webpage_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\recommend\Annotation_recommend.php 60
ERROR - 2010-07-18 06:16:22 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  relation &quot;annotation2recommend&quot; does not exist
LINE 1: INSERT INTO &quot;annotation2recommend&quot; (&quot;recommended_annotation_...
                    ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-18 06:16:22 --> Query error: ERROR:  relation "annotation2recommend" does not exist
LINE 1: INSERT INTO "annotation2recommend" ("recommended_annotation_...
                    ^
ERROR - 2010-07-18 06:16:22 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-18 06:16:45 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  relation &quot;annotation2recommend&quot; does not exist
LINE 2: FROM &quot;annotation2recommend&quot;
             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-18 06:16:45 --> Query error: ERROR:  relation "annotation2recommend" does not exist
LINE 2: FROM "annotation2recommend"
             ^
ERROR - 2010-07-18 06:19:28 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;annotation2recommend_id&quot; does not exist
LINE 1: SELECT MAX(&quot;annotation2recommend_id&quot;) AS count
                   ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-18 06:19:28 --> Query error: ERROR:  column "annotation2recommend_id" does not exist
LINE 1: SELECT MAX("annotation2recommend_id") AS count
                   ^
ERROR - 2010-07-18 06:20:11 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  relation &quot;annotation2recommend&quot; does not exist
LINE 2: FROM &quot;annotation2recommend&quot;
             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-18 06:20:11 --> Query error: ERROR:  relation "annotation2recommend" does not exist
LINE 2: FROM "annotation2recommend"
             ^
ERROR - 2010-07-18 06:25:56 --> Severity: Notice  --> Object of class Annotation could not be converted to int D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 168
ERROR - 2010-07-18 06:25:56 --> 嘗試取出 Annotation_recommend物件 的 webpage_id 欄位，但 Annotation_recommend物件 不存在 webpage_id 欄位
ERROR - 2010-07-18 06:25:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-18 06:26:26 --> Severity: Notice  --> Object of class Annotation could not be converted to int D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 168
ERROR - 2010-07-18 06:27:21 --> Severity: Notice  --> Object of class Annotation could not be converted to int D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 168
ERROR - 2010-07-18 06:27:43 --> Severity: Notice  --> Object of class Annotation could not be converted to int D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 168
ERROR - 2010-07-18 09:45:00 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Annotation_scope_collection.php 509
ERROR - 2010-07-18 09:45:00 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;)&quot;
LINE 11: AND () IS NULL
              ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-18 09:45:00 --> Query error: ERROR:  syntax error at or near ")"
LINE 11: AND () IS NULL
              ^
ERROR - 2010-07-18 09:45:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-18 09:57:27 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  null value in column &quot;user_id&quot; violates not-null constraint D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-18 09:57:27 --> Query error: ERROR:  null value in column "user_id" violates not-null constraint
ERROR - 2010-07-18 09:57:52 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  null value in column &quot;user_id&quot; violates not-null constraint D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-18 09:57:52 --> Query error: ERROR:  null value in column "user_id" violates not-null constraint
ERROR - 2010-07-18 09:58:36 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  null value in column &quot;user_id&quot; violates not-null constraint D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-18 09:58:36 --> Query error: ERROR:  null value in column "user_id" violates not-null constraint
ERROR - 2010-07-18 10:01:29 --> Severity: 4096  --> Argument 1 passed to Annotation_scope_collection::add_scope() must be an instance of Annotation_scope, instance of Annotation given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_recommend\ut_tutor.php on line 68 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Annotation_scope_collection.php 121
ERROR - 2010-07-18 10:04:19 --> Severity: 4096  --> Argument 1 passed to Annotation_scope_collection::add_scope() must be an instance of Annotation_scope, instance of Annotation given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_recommend\ut_tutor.php on line 68 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Annotation_scope_collection.php 121
ERROR - 2010-07-18 10:05:03 --> Severity: Notice  --> Undefined variable: recommend_scope D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_recommend\ut_tutor.php 70
ERROR - 2010-07-18 10:06:41 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-18 10:06:42 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;)&quot;
LINE 6: AND () IS NULL
             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-18 10:06:42 --> Query error: ERROR:  syntax error at or near ")"
LINE 6: AND () IS NULL
             ^
ERROR - 2010-07-18 10:06:42 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-18 10:06:42 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;)&quot;
LINE 6: AND () IS NULL
             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-18 10:06:42 --> Query error: ERROR:  syntax error at or near ")"
LINE 6: AND () IS NULL
             ^
ERROR - 2010-07-18 10:06:43 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;)&quot;
LINE 6: AND () IS NULL
             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-18 10:06:43 --> Query error: ERROR:  syntax error at or near ")"
LINE 6: AND () IS NULL
             ^
ERROR - 2010-07-18 10:06:43 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/d82c8d1619ad8176d665453cfb2e55f0) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-18 10:06:46 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;)&quot;
LINE 8: AND () IS NULL
             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-18 10:06:46 --> Query error: ERROR:  syntax error at or near ")"
LINE 8: AND () IS NULL
             ^
ERROR - 2010-07-18 10:06:46 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;)&quot;
LINE 8: AND () IS NULL
             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-18 10:06:46 --> Query error: ERROR:  syntax error at or near ")"
LINE 8: AND () IS NULL
             ^
ERROR - 2010-07-18 10:06:46 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;)&quot;
LINE 8: AND () IS NULL
             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-18 10:06:46 --> Query error: ERROR:  syntax error at or near ")"
LINE 8: AND () IS NULL
             ^
ERROR - 2010-07-18 10:10:25 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  null value in column &quot;user_id&quot; violates not-null constraint D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-18 10:10:25 --> Query error: ERROR:  null value in column "user_id" violates not-null constraint
ERROR - 2010-07-18 10:11:23 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/9778d5d219c5080b9a6a17bef029331c) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-18 10:11:23 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-18 10:11:24 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;)&quot;
LINE 6: AND () IS NULL
             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-18 10:11:24 --> Query error: ERROR:  syntax error at or near ")"
LINE 6: AND () IS NULL
             ^
ERROR - 2010-07-18 10:11:24 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-18 10:11:24 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;)&quot;
LINE 6: AND () IS NULL
             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-18 10:11:24 --> Query error: ERROR:  syntax error at or near ")"
LINE 6: AND () IS NULL
             ^
ERROR - 2010-07-18 10:11:25 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;)&quot;
LINE 6: AND () IS NULL
             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-18 10:11:25 --> Query error: ERROR:  syntax error at or near ")"
LINE 6: AND () IS NULL
             ^
ERROR - 2010-07-18 10:11:27 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;)&quot;
LINE 8: AND () IS NULL
             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-18 10:11:27 --> Query error: ERROR:  syntax error at or near ")"
LINE 8: AND () IS NULL
             ^
ERROR - 2010-07-18 10:11:27 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/98dce83da57b0395e163467c9dae521b) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-18 10:11:27 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;)&quot;
LINE 8: AND () IS NULL
             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-18 10:11:27 --> Query error: ERROR:  syntax error at or near ")"
LINE 8: AND () IS NULL
             ^
ERROR - 2010-07-18 10:11:27 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;)&quot;
LINE 8: AND () IS NULL
             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-18 10:11:27 --> Query error: ERROR:  syntax error at or near ")"
LINE 8: AND () IS NULL
             ^
ERROR - 2010-07-18 10:11:35 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-18 10:11:35 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;)&quot;
LINE 6: AND () IS NULL
             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-18 10:11:35 --> Query error: ERROR:  syntax error at or near ")"
LINE 6: AND () IS NULL
             ^
ERROR - 2010-07-18 10:14:46 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-18 10:14:54 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-18 10:14:59 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-18 10:15:00 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-18 10:15:04 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/c16a5320fa475530d9583c34fd356ef5) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-18 10:21:32 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/093f65e080a295f8076b1c5722a46aa2) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-18 10:24:24 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/66f041e16a60928b05a7e228a89c3799) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-18 10:24:25 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-18 10:24:25 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-18 12:02:30 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-18 12:03:14 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-18 12:03:51 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-18 12:05:27 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-18 12:05:55 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-18 12:06:14 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-18 12:06:46 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-18 12:14:35 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-18 12:15:49 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-18 12:16:33 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-18 12:17:43 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-18 12:17:56 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-18 12:42:55 --> Severity: Notice  --> Undefined property: Search_annotation_user_collection::$length D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_search\ut_search.php 357
ERROR - 2010-07-18 13:07:01 --> Severity: Notice  --> Undefined variable: type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\type\Annotation_type_factory.php 130
ERROR - 2010-07-18 13:10:17 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/f7177163c833dff4b38fc8d2872f1ec6) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-18 13:10:17 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-18 13:10:17 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-18 13:22:36 --> 嘗試取出 User物件 的 has_photo 欄位，但 User物件 不存在 has_photo 欄位
ERROR - 2010-07-18 13:43:05 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/a1d0c6e83f027327d8461063f4ac58a6) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-18 13:43:08 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/812b4ba287f5ee0bc9d43bbf5bbe87fb) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-18 13:43:09 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-18 13:43:09 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
