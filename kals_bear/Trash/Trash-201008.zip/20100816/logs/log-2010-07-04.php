<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2010-07-04 09:50:30 --> Config Class Initialized
DEBUG - 2010-07-04 09:50:30 --> Hooks Class Initialized
DEBUG - 2010-07-04 09:50:30 --> URI Class Initialized
DEBUG - 2010-07-04 09:50:30 --> Router Class Initialized
DEBUG - 2010-07-04 09:50:30 --> Output Class Initialized
DEBUG - 2010-07-04 09:50:30 --> Input Class Initialized
DEBUG - 2010-07-04 09:50:30 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 09:50:30 --> Language Class Initialized
DEBUG - 2010-07-04 09:50:30 --> Loader Class Initialized
DEBUG - 2010-07-04 09:50:30 --> Helper loaded: context_helper
DEBUG - 2010-07-04 09:50:30 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 09:50:31 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 09:50:31 --> Database Driver Class Initialized
DEBUG - 2010-07-04 09:50:31 --> Controller Class Initialized
DEBUG - 2010-07-04 09:50:31 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 09:50:31 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 09:50:31 --> Session Class Initialized
DEBUG - 2010-07-04 09:50:31 --> Helper loaded: string_helper
DEBUG - 2010-07-04 09:50:31 --> A session cookie was not found.
DEBUG - 2010-07-04 09:50:31 --> Session routines successfully run
ERROR - 2010-07-04 09:50:31 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  relation &quot;anchor_text&quot; does not exist
LINE 2: FROM &quot;anchor_text&quot;
             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-04 09:50:31 --> DB Transaction Failure
ERROR - 2010-07-04 09:50:31 --> Query error: ERROR:  relation "anchor_text" does not exist
LINE 2: FROM "anchor_text"
             ^
DEBUG - 2010-07-04 09:50:31 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-07-04 09:57:06 --> Config Class Initialized
DEBUG - 2010-07-04 09:57:06 --> Hooks Class Initialized
DEBUG - 2010-07-04 09:57:06 --> URI Class Initialized
DEBUG - 2010-07-04 09:57:06 --> Router Class Initialized
DEBUG - 2010-07-04 09:57:06 --> Output Class Initialized
DEBUG - 2010-07-04 09:57:06 --> Input Class Initialized
DEBUG - 2010-07-04 09:57:06 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 09:57:06 --> Language Class Initialized
DEBUG - 2010-07-04 09:57:06 --> Loader Class Initialized
DEBUG - 2010-07-04 09:57:06 --> Helper loaded: context_helper
DEBUG - 2010-07-04 09:57:06 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 09:57:06 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 09:57:06 --> Database Driver Class Initialized
DEBUG - 2010-07-04 09:57:06 --> Controller Class Initialized
DEBUG - 2010-07-04 09:57:06 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 09:57:06 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 09:57:06 --> Session Class Initialized
DEBUG - 2010-07-04 09:57:06 --> Helper loaded: string_helper
DEBUG - 2010-07-04 09:57:06 --> Session routines successfully run
DEBUG - 2010-07-04 09:57:06 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 09:57:06 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 09:58:05 --> Config Class Initialized
DEBUG - 2010-07-04 09:58:05 --> Hooks Class Initialized
DEBUG - 2010-07-04 09:58:05 --> URI Class Initialized
DEBUG - 2010-07-04 09:58:05 --> Router Class Initialized
DEBUG - 2010-07-04 09:58:05 --> Output Class Initialized
DEBUG - 2010-07-04 09:58:05 --> Input Class Initialized
DEBUG - 2010-07-04 09:58:05 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 09:58:05 --> Language Class Initialized
DEBUG - 2010-07-04 09:58:05 --> Loader Class Initialized
DEBUG - 2010-07-04 09:58:05 --> Helper loaded: context_helper
DEBUG - 2010-07-04 09:58:05 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 09:58:05 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 09:58:05 --> Database Driver Class Initialized
DEBUG - 2010-07-04 09:58:05 --> Controller Class Initialized
DEBUG - 2010-07-04 09:58:05 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 09:58:05 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 09:58:40 --> Config Class Initialized
DEBUG - 2010-07-04 09:58:40 --> Hooks Class Initialized
DEBUG - 2010-07-04 09:58:40 --> URI Class Initialized
DEBUG - 2010-07-04 09:58:40 --> Router Class Initialized
DEBUG - 2010-07-04 09:58:40 --> Output Class Initialized
DEBUG - 2010-07-04 09:58:40 --> Input Class Initialized
DEBUG - 2010-07-04 09:58:40 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 09:58:40 --> Language Class Initialized
DEBUG - 2010-07-04 09:58:40 --> Loader Class Initialized
DEBUG - 2010-07-04 09:58:40 --> Helper loaded: context_helper
DEBUG - 2010-07-04 09:58:40 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 09:58:40 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 09:58:40 --> Database Driver Class Initialized
DEBUG - 2010-07-04 09:58:40 --> Controller Class Initialized
DEBUG - 2010-07-04 09:58:40 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 09:58:40 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 09:58:40 --> Session Class Initialized
DEBUG - 2010-07-04 09:58:40 --> Helper loaded: string_helper
DEBUG - 2010-07-04 09:58:40 --> Session routines successfully run
DEBUG - 2010-07-04 09:58:40 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 09:58:40 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 09:58:40 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-07-04 09:58:40 --> Severity: Notice  --> Undefined variable: text D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor.php 48
DEBUG - 2010-07-04 09:58:40 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 09:58:40 --> Final output sent to browser
DEBUG - 2010-07-04 09:58:40 --> Total execution time: 0.1950
DEBUG - 2010-07-04 09:59:06 --> Config Class Initialized
DEBUG - 2010-07-04 09:59:06 --> Hooks Class Initialized
DEBUG - 2010-07-04 09:59:06 --> URI Class Initialized
DEBUG - 2010-07-04 09:59:06 --> Router Class Initialized
DEBUG - 2010-07-04 09:59:06 --> Output Class Initialized
DEBUG - 2010-07-04 09:59:06 --> Input Class Initialized
DEBUG - 2010-07-04 09:59:06 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 09:59:06 --> Language Class Initialized
DEBUG - 2010-07-04 09:59:06 --> Loader Class Initialized
DEBUG - 2010-07-04 09:59:06 --> Helper loaded: context_helper
DEBUG - 2010-07-04 09:59:06 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 09:59:06 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 09:59:06 --> Database Driver Class Initialized
DEBUG - 2010-07-04 09:59:06 --> Controller Class Initialized
DEBUG - 2010-07-04 09:59:06 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 09:59:06 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 09:59:06 --> Session Class Initialized
DEBUG - 2010-07-04 09:59:06 --> Helper loaded: string_helper
DEBUG - 2010-07-04 09:59:06 --> Session routines successfully run
DEBUG - 2010-07-04 09:59:06 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 09:59:06 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 09:59:06 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 09:59:06 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 09:59:06 --> Final output sent to browser
DEBUG - 2010-07-04 09:59:06 --> Total execution time: 0.2066
DEBUG - 2010-07-04 12:44:44 --> Config Class Initialized
DEBUG - 2010-07-04 12:44:44 --> Hooks Class Initialized
DEBUG - 2010-07-04 12:44:44 --> URI Class Initialized
DEBUG - 2010-07-04 12:44:44 --> Router Class Initialized
DEBUG - 2010-07-04 12:44:44 --> Output Class Initialized
DEBUG - 2010-07-04 12:44:44 --> Input Class Initialized
DEBUG - 2010-07-04 12:44:44 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 12:44:44 --> Language Class Initialized
DEBUG - 2010-07-04 12:44:44 --> Loader Class Initialized
DEBUG - 2010-07-04 12:44:44 --> Helper loaded: context_helper
DEBUG - 2010-07-04 12:44:44 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 12:44:44 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 12:44:44 --> Database Driver Class Initialized
DEBUG - 2010-07-04 12:44:44 --> Controller Class Initialized
DEBUG - 2010-07-04 12:44:44 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 12:44:44 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 12:44:44 --> Session Class Initialized
DEBUG - 2010-07-04 12:44:44 --> Helper loaded: string_helper
DEBUG - 2010-07-04 12:44:44 --> A session cookie was not found.
DEBUG - 2010-07-04 12:44:44 --> Session routines successfully run
DEBUG - 2010-07-04 12:44:44 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: output D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 124
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: output D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 150
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: output D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 124
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: output D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 150
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 54
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: l D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 55
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: output D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 124
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: output D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 150
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: output D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 124
ERROR - 2010-07-04 12:44:45 --> Severity: Notice  --> Undefined variable: output D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 150
DEBUG - 2010-07-04 12:44:46 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 12:44:46 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 12:44:46 --> Final output sent to browser
DEBUG - 2010-07-04 12:44:46 --> Total execution time: 1.8807
DEBUG - 2010-07-04 12:45:06 --> Config Class Initialized
DEBUG - 2010-07-04 12:45:06 --> Hooks Class Initialized
DEBUG - 2010-07-04 12:45:06 --> URI Class Initialized
DEBUG - 2010-07-04 12:45:06 --> Router Class Initialized
DEBUG - 2010-07-04 12:45:06 --> Output Class Initialized
DEBUG - 2010-07-04 12:45:06 --> Input Class Initialized
DEBUG - 2010-07-04 12:45:06 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 12:45:06 --> Language Class Initialized
DEBUG - 2010-07-04 12:45:06 --> Loader Class Initialized
DEBUG - 2010-07-04 12:45:06 --> Helper loaded: context_helper
DEBUG - 2010-07-04 12:45:06 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 12:45:06 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 12:45:06 --> Database Driver Class Initialized
DEBUG - 2010-07-04 12:45:06 --> Controller Class Initialized
DEBUG - 2010-07-04 12:45:07 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 12:45:07 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 12:45:07 --> Session Class Initialized
DEBUG - 2010-07-04 12:45:07 --> Helper loaded: string_helper
DEBUG - 2010-07-04 12:45:07 --> Session routines successfully run
DEBUG - 2010-07-04 12:45:07 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-07-04 12:45:07 --> Severity: Notice  --> Undefined variable: output D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 124
ERROR - 2010-07-04 12:45:07 --> Severity: Notice  --> Undefined variable: output D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 150
ERROR - 2010-07-04 12:45:07 --> Severity: Notice  --> Undefined variable: output D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 124
ERROR - 2010-07-04 12:45:07 --> Severity: Notice  --> Undefined variable: output D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 150
ERROR - 2010-07-04 12:45:07 --> Severity: Notice  --> Undefined variable: output D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 124
ERROR - 2010-07-04 12:45:07 --> Severity: Notice  --> Undefined variable: output D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 150
ERROR - 2010-07-04 12:45:07 --> Severity: Notice  --> Undefined variable: output D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 124
ERROR - 2010-07-04 12:45:07 --> Severity: Notice  --> Undefined variable: output D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 150
DEBUG - 2010-07-04 12:45:07 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 12:45:07 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 12:45:07 --> Final output sent to browser
DEBUG - 2010-07-04 12:45:07 --> Total execution time: 0.5574
DEBUG - 2010-07-04 12:45:43 --> Config Class Initialized
DEBUG - 2010-07-04 12:45:43 --> Hooks Class Initialized
DEBUG - 2010-07-04 12:45:43 --> URI Class Initialized
DEBUG - 2010-07-04 12:45:43 --> Router Class Initialized
DEBUG - 2010-07-04 12:45:43 --> Output Class Initialized
DEBUG - 2010-07-04 12:45:43 --> Input Class Initialized
DEBUG - 2010-07-04 12:45:43 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 12:45:43 --> Language Class Initialized
DEBUG - 2010-07-04 12:45:43 --> Loader Class Initialized
DEBUG - 2010-07-04 12:45:43 --> Helper loaded: context_helper
DEBUG - 2010-07-04 12:45:43 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 12:45:43 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 12:45:43 --> Database Driver Class Initialized
DEBUG - 2010-07-04 12:45:43 --> Controller Class Initialized
DEBUG - 2010-07-04 12:45:43 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 12:45:43 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 12:45:43 --> Session Class Initialized
DEBUG - 2010-07-04 12:45:43 --> Helper loaded: string_helper
DEBUG - 2010-07-04 12:45:43 --> Session routines successfully run
DEBUG - 2010-07-04 12:45:43 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 12:45:43 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 12:45:43 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 12:45:43 --> Final output sent to browser
DEBUG - 2010-07-04 12:45:43 --> Total execution time: 0.5152
DEBUG - 2010-07-04 12:47:19 --> Config Class Initialized
DEBUG - 2010-07-04 12:47:19 --> Hooks Class Initialized
DEBUG - 2010-07-04 12:47:19 --> URI Class Initialized
DEBUG - 2010-07-04 12:47:19 --> Router Class Initialized
DEBUG - 2010-07-04 12:47:19 --> Output Class Initialized
DEBUG - 2010-07-04 12:47:19 --> Input Class Initialized
DEBUG - 2010-07-04 12:47:19 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 12:47:19 --> Language Class Initialized
DEBUG - 2010-07-04 12:47:19 --> Loader Class Initialized
DEBUG - 2010-07-04 12:47:19 --> Helper loaded: context_helper
DEBUG - 2010-07-04 12:47:19 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 12:47:19 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 12:47:19 --> Database Driver Class Initialized
DEBUG - 2010-07-04 12:47:19 --> Controller Class Initialized
DEBUG - 2010-07-04 12:47:19 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 12:47:19 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 12:47:19 --> Session Class Initialized
DEBUG - 2010-07-04 12:47:19 --> Helper loaded: string_helper
DEBUG - 2010-07-04 12:47:19 --> Session routines successfully run
DEBUG - 2010-07-04 12:47:19 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 12:47:19 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 12:47:19 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 12:47:19 --> Final output sent to browser
DEBUG - 2010-07-04 12:47:19 --> Total execution time: 0.5705
DEBUG - 2010-07-04 12:47:38 --> Config Class Initialized
DEBUG - 2010-07-04 12:47:38 --> Hooks Class Initialized
DEBUG - 2010-07-04 12:47:39 --> URI Class Initialized
DEBUG - 2010-07-04 12:47:39 --> Router Class Initialized
DEBUG - 2010-07-04 12:47:39 --> Output Class Initialized
DEBUG - 2010-07-04 12:47:39 --> Input Class Initialized
DEBUG - 2010-07-04 12:47:39 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 12:47:39 --> Language Class Initialized
DEBUG - 2010-07-04 12:47:39 --> Loader Class Initialized
DEBUG - 2010-07-04 12:47:39 --> Helper loaded: context_helper
DEBUG - 2010-07-04 12:47:39 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 12:47:39 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 12:47:39 --> Database Driver Class Initialized
DEBUG - 2010-07-04 12:47:39 --> Controller Class Initialized
DEBUG - 2010-07-04 12:47:39 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 12:47:39 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 12:47:39 --> Session Class Initialized
DEBUG - 2010-07-04 12:47:39 --> Helper loaded: string_helper
DEBUG - 2010-07-04 12:47:39 --> Session routines successfully run
DEBUG - 2010-07-04 12:47:39 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 12:47:39 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 12:47:39 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 12:47:39 --> Final output sent to browser
DEBUG - 2010-07-04 12:47:39 --> Total execution time: 0.5692
DEBUG - 2010-07-04 12:48:05 --> Config Class Initialized
DEBUG - 2010-07-04 12:48:05 --> Hooks Class Initialized
DEBUG - 2010-07-04 12:48:05 --> URI Class Initialized
DEBUG - 2010-07-04 12:48:05 --> Router Class Initialized
DEBUG - 2010-07-04 12:48:05 --> Output Class Initialized
DEBUG - 2010-07-04 12:48:05 --> Input Class Initialized
DEBUG - 2010-07-04 12:48:05 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 12:48:05 --> Language Class Initialized
DEBUG - 2010-07-04 12:48:05 --> Loader Class Initialized
DEBUG - 2010-07-04 12:48:05 --> Helper loaded: context_helper
DEBUG - 2010-07-04 12:48:05 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 12:48:05 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 12:48:05 --> Database Driver Class Initialized
DEBUG - 2010-07-04 12:48:05 --> Controller Class Initialized
DEBUG - 2010-07-04 12:48:05 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 12:48:05 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 12:48:05 --> Session Class Initialized
DEBUG - 2010-07-04 12:48:05 --> Helper loaded: string_helper
DEBUG - 2010-07-04 12:48:05 --> Session routines successfully run
DEBUG - 2010-07-04 12:48:05 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 12:48:05 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 12:48:06 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 12:48:06 --> Final output sent to browser
DEBUG - 2010-07-04 12:48:06 --> Total execution time: 0.5730
DEBUG - 2010-07-04 12:49:13 --> Config Class Initialized
DEBUG - 2010-07-04 12:49:13 --> Hooks Class Initialized
DEBUG - 2010-07-04 12:49:13 --> URI Class Initialized
DEBUG - 2010-07-04 12:49:13 --> Router Class Initialized
DEBUG - 2010-07-04 12:49:13 --> Output Class Initialized
DEBUG - 2010-07-04 12:49:13 --> Input Class Initialized
DEBUG - 2010-07-04 12:49:13 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 12:49:13 --> Language Class Initialized
DEBUG - 2010-07-04 12:49:13 --> Loader Class Initialized
DEBUG - 2010-07-04 12:49:13 --> Helper loaded: context_helper
DEBUG - 2010-07-04 12:49:13 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 12:49:13 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 12:49:13 --> Database Driver Class Initialized
DEBUG - 2010-07-04 12:49:13 --> Controller Class Initialized
DEBUG - 2010-07-04 12:49:13 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 12:49:13 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 12:49:13 --> Session Class Initialized
DEBUG - 2010-07-04 12:49:13 --> Helper loaded: string_helper
DEBUG - 2010-07-04 12:49:13 --> Session routines successfully run
DEBUG - 2010-07-04 12:49:14 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 12:49:14 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 12:49:14 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 12:49:14 --> Final output sent to browser
DEBUG - 2010-07-04 12:49:14 --> Total execution time: 0.5935
DEBUG - 2010-07-04 12:51:27 --> Config Class Initialized
DEBUG - 2010-07-04 12:51:27 --> Hooks Class Initialized
DEBUG - 2010-07-04 12:51:27 --> URI Class Initialized
DEBUG - 2010-07-04 12:51:27 --> Router Class Initialized
DEBUG - 2010-07-04 12:51:27 --> Output Class Initialized
DEBUG - 2010-07-04 12:51:27 --> Input Class Initialized
DEBUG - 2010-07-04 12:51:28 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 12:51:28 --> Language Class Initialized
DEBUG - 2010-07-04 12:51:28 --> Loader Class Initialized
DEBUG - 2010-07-04 12:51:28 --> Helper loaded: context_helper
DEBUG - 2010-07-04 12:51:28 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 12:51:28 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 12:51:28 --> Database Driver Class Initialized
DEBUG - 2010-07-04 12:51:28 --> Controller Class Initialized
DEBUG - 2010-07-04 12:51:28 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 12:51:28 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 12:51:28 --> Session Class Initialized
DEBUG - 2010-07-04 12:51:28 --> Helper loaded: string_helper
DEBUG - 2010-07-04 12:51:28 --> Session routines successfully run
DEBUG - 2010-07-04 12:51:28 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 12:51:28 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 12:51:28 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 12:51:28 --> Final output sent to browser
DEBUG - 2010-07-04 12:51:28 --> Total execution time: 0.6286
DEBUG - 2010-07-04 12:55:26 --> Config Class Initialized
DEBUG - 2010-07-04 12:55:27 --> Hooks Class Initialized
DEBUG - 2010-07-04 12:55:27 --> URI Class Initialized
DEBUG - 2010-07-04 12:55:27 --> Router Class Initialized
DEBUG - 2010-07-04 12:55:27 --> Output Class Initialized
DEBUG - 2010-07-04 12:55:27 --> Input Class Initialized
DEBUG - 2010-07-04 12:55:27 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 12:55:27 --> Language Class Initialized
DEBUG - 2010-07-04 12:55:27 --> Loader Class Initialized
DEBUG - 2010-07-04 12:55:27 --> Helper loaded: context_helper
DEBUG - 2010-07-04 12:55:27 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 12:55:27 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 12:55:27 --> Database Driver Class Initialized
DEBUG - 2010-07-04 12:55:27 --> Controller Class Initialized
DEBUG - 2010-07-04 12:55:27 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 12:55:27 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 12:55:27 --> Session Class Initialized
DEBUG - 2010-07-04 12:55:27 --> Helper loaded: string_helper
DEBUG - 2010-07-04 12:55:27 --> Session routines successfully run
DEBUG - 2010-07-04 12:55:27 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 12:55:27 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 12:55:27 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 12:55:27 --> Final output sent to browser
DEBUG - 2010-07-04 12:55:27 --> Total execution time: 0.6361
DEBUG - 2010-07-04 12:56:11 --> Config Class Initialized
DEBUG - 2010-07-04 12:56:11 --> Hooks Class Initialized
DEBUG - 2010-07-04 12:56:11 --> URI Class Initialized
DEBUG - 2010-07-04 12:56:11 --> Router Class Initialized
DEBUG - 2010-07-04 12:56:11 --> Output Class Initialized
DEBUG - 2010-07-04 12:56:11 --> Input Class Initialized
DEBUG - 2010-07-04 12:56:11 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 12:56:11 --> Language Class Initialized
DEBUG - 2010-07-04 12:56:11 --> Loader Class Initialized
DEBUG - 2010-07-04 12:56:11 --> Helper loaded: context_helper
DEBUG - 2010-07-04 12:56:11 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 12:56:11 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 12:56:11 --> Database Driver Class Initialized
DEBUG - 2010-07-04 12:56:11 --> Controller Class Initialized
DEBUG - 2010-07-04 12:56:11 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 12:56:11 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 12:56:11 --> Session Class Initialized
DEBUG - 2010-07-04 12:56:11 --> Helper loaded: string_helper
DEBUG - 2010-07-04 12:56:11 --> Session routines successfully run
DEBUG - 2010-07-04 12:56:11 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 12:56:12 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 12:56:12 --> Final output sent to browser
DEBUG - 2010-07-04 12:56:12 --> Total execution time: 0.4455
DEBUG - 2010-07-04 13:07:51 --> Config Class Initialized
DEBUG - 2010-07-04 13:07:51 --> Hooks Class Initialized
DEBUG - 2010-07-04 13:07:51 --> URI Class Initialized
DEBUG - 2010-07-04 13:07:51 --> Router Class Initialized
DEBUG - 2010-07-04 13:07:51 --> Output Class Initialized
DEBUG - 2010-07-04 13:07:51 --> Input Class Initialized
DEBUG - 2010-07-04 13:07:51 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 13:07:51 --> Language Class Initialized
DEBUG - 2010-07-04 13:07:51 --> Loader Class Initialized
DEBUG - 2010-07-04 13:07:51 --> Helper loaded: context_helper
DEBUG - 2010-07-04 13:07:51 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 13:07:51 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 13:07:51 --> Database Driver Class Initialized
DEBUG - 2010-07-04 13:07:51 --> Controller Class Initialized
DEBUG - 2010-07-04 13:07:51 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 13:07:51 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 13:07:51 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 13:07:51 --> Session Class Initialized
DEBUG - 2010-07-04 13:07:51 --> Helper loaded: string_helper
DEBUG - 2010-07-04 13:07:51 --> Session routines successfully run
DEBUG - 2010-07-04 13:07:51 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 13:07:51 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 13:07:51 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 13:07:51 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 13:07:51 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 13:07:51 --> Final output sent to browser
DEBUG - 2010-07-04 13:07:51 --> Total execution time: 0.5713
DEBUG - 2010-07-04 13:08:05 --> Config Class Initialized
DEBUG - 2010-07-04 13:08:05 --> Hooks Class Initialized
DEBUG - 2010-07-04 13:08:06 --> URI Class Initialized
DEBUG - 2010-07-04 13:08:06 --> Router Class Initialized
DEBUG - 2010-07-04 13:08:06 --> Output Class Initialized
DEBUG - 2010-07-04 13:08:06 --> Input Class Initialized
DEBUG - 2010-07-04 13:08:06 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 13:08:06 --> Language Class Initialized
DEBUG - 2010-07-04 13:08:06 --> Loader Class Initialized
DEBUG - 2010-07-04 13:08:06 --> Helper loaded: context_helper
DEBUG - 2010-07-04 13:08:06 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 13:08:06 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 13:08:06 --> Database Driver Class Initialized
DEBUG - 2010-07-04 13:08:06 --> Controller Class Initialized
DEBUG - 2010-07-04 13:08:06 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 13:08:06 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 13:08:06 --> Session Class Initialized
DEBUG - 2010-07-04 13:08:06 --> Helper loaded: string_helper
DEBUG - 2010-07-04 13:08:06 --> Session routines successfully run
DEBUG - 2010-07-04 13:08:06 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 13:08:06 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 13:08:06 --> Final output sent to browser
DEBUG - 2010-07-04 13:08:06 --> Total execution time: 0.4659
DEBUG - 2010-07-04 13:11:14 --> Config Class Initialized
DEBUG - 2010-07-04 13:11:14 --> Hooks Class Initialized
DEBUG - 2010-07-04 13:11:14 --> URI Class Initialized
DEBUG - 2010-07-04 13:11:14 --> Router Class Initialized
DEBUG - 2010-07-04 13:11:14 --> Output Class Initialized
DEBUG - 2010-07-04 13:11:14 --> Input Class Initialized
DEBUG - 2010-07-04 13:11:14 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 13:11:14 --> Language Class Initialized
DEBUG - 2010-07-04 13:11:14 --> Loader Class Initialized
DEBUG - 2010-07-04 13:11:14 --> Helper loaded: context_helper
DEBUG - 2010-07-04 13:11:14 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 13:11:14 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 13:11:14 --> Database Driver Class Initialized
DEBUG - 2010-07-04 13:11:14 --> Controller Class Initialized
DEBUG - 2010-07-04 13:11:15 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 13:11:15 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 13:11:15 --> Session Class Initialized
DEBUG - 2010-07-04 13:11:15 --> Helper loaded: string_helper
DEBUG - 2010-07-04 13:11:15 --> Session routines successfully run
DEBUG - 2010-07-04 13:11:15 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 13:11:15 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 13:11:15 --> Final output sent to browser
DEBUG - 2010-07-04 13:11:15 --> Total execution time: 0.4822
DEBUG - 2010-07-04 13:11:48 --> Config Class Initialized
DEBUG - 2010-07-04 13:11:48 --> Hooks Class Initialized
DEBUG - 2010-07-04 13:11:48 --> URI Class Initialized
DEBUG - 2010-07-04 13:11:48 --> Router Class Initialized
DEBUG - 2010-07-04 13:11:48 --> Output Class Initialized
DEBUG - 2010-07-04 13:11:48 --> Input Class Initialized
DEBUG - 2010-07-04 13:11:48 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 13:11:48 --> Language Class Initialized
DEBUG - 2010-07-04 13:11:48 --> Loader Class Initialized
DEBUG - 2010-07-04 13:11:48 --> Helper loaded: context_helper
DEBUG - 2010-07-04 13:11:48 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 13:11:48 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 13:11:48 --> Database Driver Class Initialized
DEBUG - 2010-07-04 13:11:48 --> Controller Class Initialized
DEBUG - 2010-07-04 13:11:48 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 13:11:48 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 13:11:48 --> Session Class Initialized
DEBUG - 2010-07-04 13:11:48 --> Helper loaded: string_helper
DEBUG - 2010-07-04 13:11:48 --> Session routines successfully run
DEBUG - 2010-07-04 13:11:48 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 13:11:48 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 13:11:48 --> Final output sent to browser
DEBUG - 2010-07-04 13:11:48 --> Total execution time: 0.4798
DEBUG - 2010-07-04 13:12:13 --> Config Class Initialized
DEBUG - 2010-07-04 13:12:13 --> Hooks Class Initialized
DEBUG - 2010-07-04 13:12:13 --> URI Class Initialized
DEBUG - 2010-07-04 13:12:13 --> Router Class Initialized
DEBUG - 2010-07-04 13:12:13 --> Output Class Initialized
DEBUG - 2010-07-04 13:12:13 --> Input Class Initialized
DEBUG - 2010-07-04 13:12:13 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 13:12:13 --> Language Class Initialized
DEBUG - 2010-07-04 13:12:13 --> Loader Class Initialized
DEBUG - 2010-07-04 13:12:13 --> Helper loaded: context_helper
DEBUG - 2010-07-04 13:12:13 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 13:12:13 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 13:12:13 --> Database Driver Class Initialized
DEBUG - 2010-07-04 13:12:13 --> Controller Class Initialized
DEBUG - 2010-07-04 13:12:13 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 13:12:13 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 13:12:13 --> Session Class Initialized
DEBUG - 2010-07-04 13:12:13 --> Helper loaded: string_helper
DEBUG - 2010-07-04 13:12:13 --> Session routines successfully run
DEBUG - 2010-07-04 13:12:13 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 13:12:13 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 13:12:13 --> Final output sent to browser
DEBUG - 2010-07-04 13:12:13 --> Total execution time: 0.4850
DEBUG - 2010-07-04 13:14:04 --> Config Class Initialized
DEBUG - 2010-07-04 13:14:04 --> Hooks Class Initialized
DEBUG - 2010-07-04 13:14:04 --> URI Class Initialized
DEBUG - 2010-07-04 13:14:04 --> Router Class Initialized
DEBUG - 2010-07-04 13:14:04 --> Output Class Initialized
DEBUG - 2010-07-04 13:14:04 --> Input Class Initialized
DEBUG - 2010-07-04 13:14:04 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 13:14:04 --> Language Class Initialized
DEBUG - 2010-07-04 13:14:04 --> Loader Class Initialized
DEBUG - 2010-07-04 13:14:04 --> Helper loaded: context_helper
DEBUG - 2010-07-04 13:14:04 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 13:14:04 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 13:14:04 --> Database Driver Class Initialized
DEBUG - 2010-07-04 13:14:04 --> Controller Class Initialized
DEBUG - 2010-07-04 13:14:04 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 13:14:04 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 13:14:04 --> Session Class Initialized
DEBUG - 2010-07-04 13:14:04 --> Helper loaded: string_helper
DEBUG - 2010-07-04 13:14:04 --> Session routines successfully run
DEBUG - 2010-07-04 13:14:04 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 13:14:04 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 13:14:04 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 13:14:04 --> Final output sent to browser
DEBUG - 2010-07-04 13:14:04 --> Total execution time: 0.7122
DEBUG - 2010-07-04 13:18:24 --> Config Class Initialized
DEBUG - 2010-07-04 13:18:24 --> Hooks Class Initialized
DEBUG - 2010-07-04 13:18:24 --> URI Class Initialized
DEBUG - 2010-07-04 13:18:24 --> Router Class Initialized
DEBUG - 2010-07-04 13:18:24 --> Output Class Initialized
DEBUG - 2010-07-04 13:18:24 --> Input Class Initialized
DEBUG - 2010-07-04 13:18:24 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 13:18:24 --> Language Class Initialized
DEBUG - 2010-07-04 13:18:24 --> Loader Class Initialized
DEBUG - 2010-07-04 13:18:24 --> Helper loaded: context_helper
DEBUG - 2010-07-04 13:18:24 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 13:18:24 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 13:18:24 --> Database Driver Class Initialized
DEBUG - 2010-07-04 13:18:24 --> Controller Class Initialized
DEBUG - 2010-07-04 13:18:24 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 13:18:24 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 13:18:24 --> Session Class Initialized
DEBUG - 2010-07-04 13:18:24 --> Helper loaded: string_helper
DEBUG - 2010-07-04 13:18:24 --> Session routines successfully run
DEBUG - 2010-07-04 13:18:24 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 13:18:25 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 13:18:25 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 13:18:25 --> Final output sent to browser
DEBUG - 2010-07-04 13:18:25 --> Total execution time: 0.7107
DEBUG - 2010-07-04 13:19:29 --> Config Class Initialized
DEBUG - 2010-07-04 13:19:29 --> Hooks Class Initialized
DEBUG - 2010-07-04 13:19:29 --> URI Class Initialized
DEBUG - 2010-07-04 13:19:29 --> Router Class Initialized
DEBUG - 2010-07-04 13:19:29 --> Output Class Initialized
DEBUG - 2010-07-04 13:19:29 --> Input Class Initialized
DEBUG - 2010-07-04 13:19:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 13:19:29 --> Language Class Initialized
DEBUG - 2010-07-04 13:19:29 --> Loader Class Initialized
DEBUG - 2010-07-04 13:19:29 --> Helper loaded: context_helper
DEBUG - 2010-07-04 13:19:29 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 13:19:29 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 13:19:29 --> Database Driver Class Initialized
DEBUG - 2010-07-04 13:19:29 --> Controller Class Initialized
DEBUG - 2010-07-04 13:19:29 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 13:19:29 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 13:19:29 --> Session Class Initialized
DEBUG - 2010-07-04 13:19:29 --> Helper loaded: string_helper
DEBUG - 2010-07-04 13:19:29 --> Session routines successfully run
DEBUG - 2010-07-04 13:19:29 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 13:19:29 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 13:19:29 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 13:19:29 --> Final output sent to browser
DEBUG - 2010-07-04 13:19:29 --> Total execution time: 0.6372
DEBUG - 2010-07-04 13:21:11 --> Config Class Initialized
DEBUG - 2010-07-04 13:21:11 --> Hooks Class Initialized
DEBUG - 2010-07-04 13:21:11 --> URI Class Initialized
DEBUG - 2010-07-04 13:21:11 --> Router Class Initialized
DEBUG - 2010-07-04 13:21:11 --> Output Class Initialized
DEBUG - 2010-07-04 13:21:11 --> Input Class Initialized
DEBUG - 2010-07-04 13:21:11 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 13:21:11 --> Language Class Initialized
DEBUG - 2010-07-04 13:21:11 --> Loader Class Initialized
DEBUG - 2010-07-04 13:21:11 --> Helper loaded: context_helper
DEBUG - 2010-07-04 13:21:11 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 13:21:11 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 13:21:11 --> Database Driver Class Initialized
DEBUG - 2010-07-04 13:21:11 --> Controller Class Initialized
DEBUG - 2010-07-04 13:21:11 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 13:21:11 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 13:21:11 --> Session Class Initialized
DEBUG - 2010-07-04 13:21:11 --> Helper loaded: string_helper
DEBUG - 2010-07-04 13:21:11 --> Session routines successfully run
DEBUG - 2010-07-04 13:21:11 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 13:21:11 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 13:21:11 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 13:21:11 --> Final output sent to browser
DEBUG - 2010-07-04 13:21:11 --> Total execution time: 0.7303
DEBUG - 2010-07-04 13:21:54 --> Config Class Initialized
DEBUG - 2010-07-04 13:21:54 --> Hooks Class Initialized
DEBUG - 2010-07-04 13:21:54 --> URI Class Initialized
DEBUG - 2010-07-04 13:21:54 --> Router Class Initialized
DEBUG - 2010-07-04 13:21:54 --> Output Class Initialized
DEBUG - 2010-07-04 13:21:54 --> Input Class Initialized
DEBUG - 2010-07-04 13:21:54 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 13:21:54 --> Language Class Initialized
DEBUG - 2010-07-04 13:21:54 --> Loader Class Initialized
DEBUG - 2010-07-04 13:21:54 --> Helper loaded: context_helper
DEBUG - 2010-07-04 13:21:54 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 13:21:54 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 13:21:54 --> Database Driver Class Initialized
DEBUG - 2010-07-04 13:21:54 --> Controller Class Initialized
DEBUG - 2010-07-04 13:21:54 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 13:21:54 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 13:21:54 --> Session Class Initialized
DEBUG - 2010-07-04 13:21:54 --> Helper loaded: string_helper
DEBUG - 2010-07-04 13:21:54 --> Session routines successfully run
DEBUG - 2010-07-04 13:21:54 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 13:21:54 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 13:21:55 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 13:21:55 --> Final output sent to browser
DEBUG - 2010-07-04 13:21:55 --> Total execution time: 0.7430
DEBUG - 2010-07-04 13:22:12 --> Config Class Initialized
DEBUG - 2010-07-04 13:22:12 --> Hooks Class Initialized
DEBUG - 2010-07-04 13:22:12 --> URI Class Initialized
DEBUG - 2010-07-04 13:22:12 --> Router Class Initialized
DEBUG - 2010-07-04 13:22:12 --> Output Class Initialized
DEBUG - 2010-07-04 13:22:12 --> Input Class Initialized
DEBUG - 2010-07-04 13:22:13 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 13:22:13 --> Language Class Initialized
DEBUG - 2010-07-04 13:22:13 --> Loader Class Initialized
DEBUG - 2010-07-04 13:22:13 --> Helper loaded: context_helper
DEBUG - 2010-07-04 13:22:13 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 13:22:13 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 13:22:13 --> Database Driver Class Initialized
DEBUG - 2010-07-04 13:22:13 --> Controller Class Initialized
DEBUG - 2010-07-04 13:22:13 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 13:22:13 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 13:22:13 --> Session Class Initialized
DEBUG - 2010-07-04 13:22:13 --> Helper loaded: string_helper
DEBUG - 2010-07-04 13:22:13 --> Session routines successfully run
DEBUG - 2010-07-04 13:22:13 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 13:22:13 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 13:22:13 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 13:22:13 --> Final output sent to browser
DEBUG - 2010-07-04 13:22:13 --> Total execution time: 0.7304
DEBUG - 2010-07-04 13:22:38 --> Config Class Initialized
DEBUG - 2010-07-04 13:22:38 --> Hooks Class Initialized
DEBUG - 2010-07-04 13:22:38 --> URI Class Initialized
DEBUG - 2010-07-04 13:22:38 --> Router Class Initialized
DEBUG - 2010-07-04 13:22:38 --> Output Class Initialized
DEBUG - 2010-07-04 13:22:39 --> Input Class Initialized
DEBUG - 2010-07-04 13:22:39 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 13:22:39 --> Language Class Initialized
DEBUG - 2010-07-04 13:22:39 --> Loader Class Initialized
DEBUG - 2010-07-04 13:22:39 --> Helper loaded: context_helper
DEBUG - 2010-07-04 13:22:39 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 13:22:39 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 13:22:39 --> Database Driver Class Initialized
DEBUG - 2010-07-04 13:22:39 --> Controller Class Initialized
DEBUG - 2010-07-04 13:22:39 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 13:22:39 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 13:22:39 --> Session Class Initialized
DEBUG - 2010-07-04 13:22:39 --> Helper loaded: string_helper
DEBUG - 2010-07-04 13:22:39 --> Session routines successfully run
DEBUG - 2010-07-04 13:22:39 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 13:22:39 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 13:22:39 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 13:22:39 --> Final output sent to browser
DEBUG - 2010-07-04 13:22:39 --> Total execution time: 0.7646
DEBUG - 2010-07-04 13:27:14 --> Config Class Initialized
DEBUG - 2010-07-04 13:27:14 --> Hooks Class Initialized
DEBUG - 2010-07-04 13:27:15 --> URI Class Initialized
DEBUG - 2010-07-04 13:27:15 --> Router Class Initialized
DEBUG - 2010-07-04 13:27:15 --> Output Class Initialized
DEBUG - 2010-07-04 13:27:15 --> Input Class Initialized
DEBUG - 2010-07-04 13:27:15 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 13:27:15 --> Language Class Initialized
DEBUG - 2010-07-04 13:27:15 --> Loader Class Initialized
DEBUG - 2010-07-04 13:27:15 --> Helper loaded: context_helper
DEBUG - 2010-07-04 13:27:15 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 13:27:15 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 13:27:15 --> Database Driver Class Initialized
DEBUG - 2010-07-04 13:27:15 --> Controller Class Initialized
DEBUG - 2010-07-04 13:27:15 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 13:27:15 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 13:27:15 --> Session Class Initialized
DEBUG - 2010-07-04 13:27:15 --> Helper loaded: string_helper
DEBUG - 2010-07-04 13:27:15 --> Session routines successfully run
DEBUG - 2010-07-04 13:27:15 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 13:27:15 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 13:27:15 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 13:27:15 --> Final output sent to browser
DEBUG - 2010-07-04 13:27:15 --> Total execution time: 0.8308
DEBUG - 2010-07-04 13:27:44 --> Config Class Initialized
DEBUG - 2010-07-04 13:27:44 --> Hooks Class Initialized
DEBUG - 2010-07-04 13:27:44 --> URI Class Initialized
DEBUG - 2010-07-04 13:27:44 --> Router Class Initialized
DEBUG - 2010-07-04 13:27:44 --> Output Class Initialized
DEBUG - 2010-07-04 13:27:44 --> Input Class Initialized
DEBUG - 2010-07-04 13:27:45 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 13:27:45 --> Language Class Initialized
DEBUG - 2010-07-04 13:27:45 --> Loader Class Initialized
DEBUG - 2010-07-04 13:27:45 --> Helper loaded: context_helper
DEBUG - 2010-07-04 13:27:45 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 13:27:45 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 13:27:45 --> Database Driver Class Initialized
DEBUG - 2010-07-04 13:27:45 --> Controller Class Initialized
DEBUG - 2010-07-04 13:27:45 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 13:27:45 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 13:27:45 --> Session Class Initialized
DEBUG - 2010-07-04 13:27:45 --> Helper loaded: string_helper
DEBUG - 2010-07-04 13:27:45 --> Session routines successfully run
DEBUG - 2010-07-04 13:27:45 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 13:27:45 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 13:27:45 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 13:27:45 --> Final output sent to browser
DEBUG - 2010-07-04 13:27:45 --> Total execution time: 0.7933
DEBUG - 2010-07-04 13:52:18 --> Config Class Initialized
DEBUG - 2010-07-04 13:52:18 --> Hooks Class Initialized
DEBUG - 2010-07-04 13:52:18 --> URI Class Initialized
DEBUG - 2010-07-04 13:52:18 --> Router Class Initialized
DEBUG - 2010-07-04 13:52:18 --> Output Class Initialized
DEBUG - 2010-07-04 13:52:18 --> Input Class Initialized
DEBUG - 2010-07-04 13:52:18 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 13:52:18 --> Language Class Initialized
DEBUG - 2010-07-04 13:52:18 --> Loader Class Initialized
DEBUG - 2010-07-04 13:52:18 --> Helper loaded: context_helper
DEBUG - 2010-07-04 13:52:18 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 13:52:18 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 13:52:18 --> Database Driver Class Initialized
DEBUG - 2010-07-04 13:52:18 --> Controller Class Initialized
DEBUG - 2010-07-04 13:52:18 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 13:52:18 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 13:52:19 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 13:52:19 --> Session Class Initialized
DEBUG - 2010-07-04 13:52:19 --> Helper loaded: string_helper
DEBUG - 2010-07-04 13:52:19 --> Session routines successfully run
DEBUG - 2010-07-04 13:52:19 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 13:52:19 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 13:52:19 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 13:52:19 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 13:53:28 --> Config Class Initialized
DEBUG - 2010-07-04 13:53:28 --> Hooks Class Initialized
DEBUG - 2010-07-04 13:53:29 --> URI Class Initialized
DEBUG - 2010-07-04 13:53:29 --> Router Class Initialized
DEBUG - 2010-07-04 13:53:29 --> Output Class Initialized
DEBUG - 2010-07-04 13:53:29 --> Input Class Initialized
DEBUG - 2010-07-04 13:53:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 13:53:29 --> Language Class Initialized
DEBUG - 2010-07-04 13:53:29 --> Loader Class Initialized
DEBUG - 2010-07-04 13:53:29 --> Helper loaded: context_helper
DEBUG - 2010-07-04 13:53:29 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 13:53:29 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 13:53:29 --> Database Driver Class Initialized
DEBUG - 2010-07-04 13:53:29 --> Controller Class Initialized
DEBUG - 2010-07-04 13:53:29 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 13:53:29 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 13:53:29 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 13:53:29 --> Session Class Initialized
DEBUG - 2010-07-04 13:53:29 --> Helper loaded: string_helper
DEBUG - 2010-07-04 13:53:29 --> Session routines successfully run
DEBUG - 2010-07-04 13:53:29 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 13:53:29 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 13:53:29 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 13:53:29 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 13:53:29 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 13:53:29 --> Final output sent to browser
DEBUG - 2010-07-04 13:53:29 --> Total execution time: 0.7349
DEBUG - 2010-07-04 13:54:34 --> Config Class Initialized
DEBUG - 2010-07-04 13:54:34 --> Hooks Class Initialized
DEBUG - 2010-07-04 13:54:34 --> URI Class Initialized
DEBUG - 2010-07-04 13:54:34 --> Router Class Initialized
DEBUG - 2010-07-04 13:54:34 --> Output Class Initialized
DEBUG - 2010-07-04 13:54:34 --> Input Class Initialized
DEBUG - 2010-07-04 13:54:34 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 13:54:34 --> Language Class Initialized
DEBUG - 2010-07-04 13:54:34 --> Loader Class Initialized
DEBUG - 2010-07-04 13:54:34 --> Helper loaded: context_helper
DEBUG - 2010-07-04 13:54:34 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 13:54:34 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 13:54:34 --> Database Driver Class Initialized
DEBUG - 2010-07-04 13:54:34 --> Controller Class Initialized
DEBUG - 2010-07-04 13:54:34 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 13:54:34 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 13:54:34 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 13:54:34 --> Session Class Initialized
DEBUG - 2010-07-04 13:54:34 --> Helper loaded: string_helper
DEBUG - 2010-07-04 13:54:34 --> Session routines successfully run
DEBUG - 2010-07-04 13:54:34 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 13:54:34 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 13:54:34 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 13:54:34 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 13:54:34 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 13:54:34 --> Final output sent to browser
DEBUG - 2010-07-04 13:54:34 --> Total execution time: 0.7422
DEBUG - 2010-07-04 13:55:27 --> Config Class Initialized
DEBUG - 2010-07-04 13:55:27 --> Hooks Class Initialized
DEBUG - 2010-07-04 13:55:27 --> URI Class Initialized
DEBUG - 2010-07-04 13:55:27 --> Router Class Initialized
DEBUG - 2010-07-04 13:55:27 --> Output Class Initialized
DEBUG - 2010-07-04 13:55:27 --> Input Class Initialized
DEBUG - 2010-07-04 13:55:27 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 13:55:27 --> Language Class Initialized
DEBUG - 2010-07-04 13:55:27 --> Loader Class Initialized
DEBUG - 2010-07-04 13:55:27 --> Helper loaded: context_helper
DEBUG - 2010-07-04 13:55:27 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 13:55:27 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 13:55:27 --> Database Driver Class Initialized
DEBUG - 2010-07-04 13:55:27 --> Controller Class Initialized
DEBUG - 2010-07-04 13:55:27 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 13:55:27 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 13:55:27 --> Session Class Initialized
DEBUG - 2010-07-04 13:55:27 --> Helper loaded: string_helper
DEBUG - 2010-07-04 13:55:27 --> Session routines successfully run
DEBUG - 2010-07-04 13:55:27 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 13:55:27 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 13:55:28 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 13:55:28 --> Final output sent to browser
DEBUG - 2010-07-04 13:55:28 --> Total execution time: 0.9069
DEBUG - 2010-07-04 13:57:52 --> Config Class Initialized
DEBUG - 2010-07-04 13:57:52 --> Hooks Class Initialized
DEBUG - 2010-07-04 13:57:52 --> URI Class Initialized
DEBUG - 2010-07-04 13:57:52 --> Router Class Initialized
DEBUG - 2010-07-04 13:57:52 --> Output Class Initialized
DEBUG - 2010-07-04 13:57:52 --> Input Class Initialized
DEBUG - 2010-07-04 13:57:52 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 13:57:52 --> Language Class Initialized
DEBUG - 2010-07-04 13:57:52 --> Loader Class Initialized
DEBUG - 2010-07-04 13:57:53 --> Helper loaded: context_helper
DEBUG - 2010-07-04 13:57:53 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 13:57:53 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 13:57:53 --> Database Driver Class Initialized
DEBUG - 2010-07-04 13:57:53 --> Controller Class Initialized
DEBUG - 2010-07-04 13:57:53 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 13:57:53 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 13:57:53 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 13:57:53 --> Session Class Initialized
DEBUG - 2010-07-04 13:57:53 --> Helper loaded: string_helper
DEBUG - 2010-07-04 13:57:53 --> Session routines successfully run
DEBUG - 2010-07-04 13:57:53 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 13:57:53 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 13:57:53 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 13:57:53 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 13:57:53 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 13:57:53 --> Final output sent to browser
DEBUG - 2010-07-04 13:57:53 --> Total execution time: 0.7927
DEBUG - 2010-07-04 13:58:51 --> Config Class Initialized
DEBUG - 2010-07-04 13:58:51 --> Hooks Class Initialized
DEBUG - 2010-07-04 13:58:51 --> URI Class Initialized
DEBUG - 2010-07-04 13:58:51 --> Router Class Initialized
DEBUG - 2010-07-04 13:58:51 --> Output Class Initialized
DEBUG - 2010-07-04 13:58:51 --> Input Class Initialized
DEBUG - 2010-07-04 13:58:51 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 13:58:51 --> Language Class Initialized
DEBUG - 2010-07-04 13:58:51 --> Loader Class Initialized
DEBUG - 2010-07-04 13:58:51 --> Helper loaded: context_helper
DEBUG - 2010-07-04 13:58:51 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 13:58:51 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 13:58:51 --> Database Driver Class Initialized
DEBUG - 2010-07-04 13:58:51 --> Controller Class Initialized
DEBUG - 2010-07-04 13:58:51 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 13:58:51 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 13:58:51 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 13:58:51 --> Session Class Initialized
DEBUG - 2010-07-04 13:58:51 --> Helper loaded: string_helper
DEBUG - 2010-07-04 13:58:52 --> Session routines successfully run
DEBUG - 2010-07-04 13:58:52 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 13:58:52 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 13:58:52 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 13:58:52 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 13:58:52 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 13:58:52 --> Final output sent to browser
DEBUG - 2010-07-04 13:58:52 --> Total execution time: 0.8187
DEBUG - 2010-07-04 13:59:09 --> Config Class Initialized
DEBUG - 2010-07-04 13:59:09 --> Hooks Class Initialized
DEBUG - 2010-07-04 13:59:09 --> URI Class Initialized
DEBUG - 2010-07-04 13:59:09 --> Router Class Initialized
DEBUG - 2010-07-04 13:59:09 --> Output Class Initialized
DEBUG - 2010-07-04 13:59:09 --> Input Class Initialized
DEBUG - 2010-07-04 13:59:09 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 13:59:09 --> Language Class Initialized
DEBUG - 2010-07-04 13:59:09 --> Loader Class Initialized
DEBUG - 2010-07-04 13:59:09 --> Helper loaded: context_helper
DEBUG - 2010-07-04 13:59:09 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 13:59:09 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 13:59:09 --> Database Driver Class Initialized
DEBUG - 2010-07-04 13:59:09 --> Controller Class Initialized
DEBUG - 2010-07-04 13:59:09 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 13:59:09 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 13:59:09 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 13:59:09 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 13:59:10 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 13:59:10 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 13:59:10 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 13:59:10 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 13:59:10 --> Final output sent to browser
DEBUG - 2010-07-04 13:59:10 --> Total execution time: 0.7458
DEBUG - 2010-07-04 14:20:08 --> Config Class Initialized
DEBUG - 2010-07-04 14:20:08 --> Hooks Class Initialized
DEBUG - 2010-07-04 14:20:08 --> URI Class Initialized
DEBUG - 2010-07-04 14:20:08 --> Router Class Initialized
DEBUG - 2010-07-04 14:20:08 --> Output Class Initialized
DEBUG - 2010-07-04 14:20:08 --> Input Class Initialized
DEBUG - 2010-07-04 14:20:08 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 14:20:08 --> Language Class Initialized
DEBUG - 2010-07-04 14:20:08 --> Loader Class Initialized
DEBUG - 2010-07-04 14:20:08 --> Helper loaded: context_helper
DEBUG - 2010-07-04 14:20:08 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 14:20:08 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 14:20:08 --> Database Driver Class Initialized
DEBUG - 2010-07-04 14:20:08 --> Controller Class Initialized
DEBUG - 2010-07-04 14:20:08 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 14:20:08 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 14:20:08 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 14:20:09 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 14:20:09 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 14:20:09 --> Final output sent to browser
DEBUG - 2010-07-04 14:20:09 --> Total execution time: 0.9804
DEBUG - 2010-07-04 14:20:33 --> Config Class Initialized
DEBUG - 2010-07-04 14:20:33 --> Hooks Class Initialized
DEBUG - 2010-07-04 14:20:33 --> URI Class Initialized
DEBUG - 2010-07-04 14:20:33 --> Router Class Initialized
DEBUG - 2010-07-04 14:20:33 --> Output Class Initialized
DEBUG - 2010-07-04 14:20:33 --> Input Class Initialized
DEBUG - 2010-07-04 14:20:33 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 14:20:33 --> Language Class Initialized
DEBUG - 2010-07-04 14:20:33 --> Loader Class Initialized
DEBUG - 2010-07-04 14:20:33 --> Helper loaded: context_helper
DEBUG - 2010-07-04 14:20:33 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 14:20:33 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 14:20:33 --> Database Driver Class Initialized
DEBUG - 2010-07-04 14:20:33 --> Controller Class Initialized
DEBUG - 2010-07-04 14:20:33 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 14:20:33 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 14:20:33 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 14:20:33 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 14:20:33 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 14:20:34 --> Final output sent to browser
DEBUG - 2010-07-04 14:20:34 --> Total execution time: 0.8332
DEBUG - 2010-07-04 14:21:00 --> Config Class Initialized
DEBUG - 2010-07-04 14:21:00 --> Hooks Class Initialized
DEBUG - 2010-07-04 14:21:00 --> URI Class Initialized
DEBUG - 2010-07-04 14:21:00 --> Router Class Initialized
DEBUG - 2010-07-04 14:21:00 --> Output Class Initialized
DEBUG - 2010-07-04 14:21:00 --> Input Class Initialized
DEBUG - 2010-07-04 14:21:00 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 14:21:00 --> Language Class Initialized
DEBUG - 2010-07-04 14:21:00 --> Loader Class Initialized
DEBUG - 2010-07-04 14:21:00 --> Helper loaded: context_helper
DEBUG - 2010-07-04 14:21:00 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 14:21:00 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 14:21:00 --> Database Driver Class Initialized
DEBUG - 2010-07-04 14:21:00 --> Controller Class Initialized
DEBUG - 2010-07-04 14:21:00 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 14:21:00 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 14:21:00 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 14:21:00 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 14:21:00 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 14:21:00 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 14:21:24 --> Config Class Initialized
DEBUG - 2010-07-04 14:21:24 --> Hooks Class Initialized
DEBUG - 2010-07-04 14:21:24 --> URI Class Initialized
DEBUG - 2010-07-04 14:21:24 --> Router Class Initialized
DEBUG - 2010-07-04 14:21:24 --> Output Class Initialized
DEBUG - 2010-07-04 14:21:24 --> Input Class Initialized
DEBUG - 2010-07-04 14:21:24 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 14:21:24 --> Language Class Initialized
DEBUG - 2010-07-04 14:21:24 --> Loader Class Initialized
DEBUG - 2010-07-04 14:21:24 --> Helper loaded: context_helper
DEBUG - 2010-07-04 14:21:24 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 14:21:24 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 14:21:24 --> Database Driver Class Initialized
DEBUG - 2010-07-04 14:21:25 --> Controller Class Initialized
DEBUG - 2010-07-04 14:21:25 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 14:21:25 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 14:21:25 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 14:21:25 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 14:21:25 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 14:21:25 --> Segmentor class already loaded. Second attempt ignored.
ERROR - 2010-07-04 14:21:25 --> Severity: Notice  --> Undefined property: Scope_anchor_text::$id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Scope_anchor_text.php 133
DEBUG - 2010-07-04 14:48:27 --> Config Class Initialized
DEBUG - 2010-07-04 14:48:27 --> Hooks Class Initialized
DEBUG - 2010-07-04 14:48:27 --> URI Class Initialized
DEBUG - 2010-07-04 14:48:27 --> Router Class Initialized
DEBUG - 2010-07-04 14:48:27 --> Output Class Initialized
DEBUG - 2010-07-04 14:48:27 --> Input Class Initialized
DEBUG - 2010-07-04 14:48:27 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 14:48:27 --> Language Class Initialized
DEBUG - 2010-07-04 14:48:27 --> Loader Class Initialized
DEBUG - 2010-07-04 14:48:27 --> Helper loaded: context_helper
DEBUG - 2010-07-04 14:48:27 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 14:48:27 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 14:48:27 --> Database Driver Class Initialized
DEBUG - 2010-07-04 14:48:27 --> Controller Class Initialized
DEBUG - 2010-07-04 14:48:27 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 14:48:27 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 14:48:27 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 14:48:27 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 14:48:27 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 14:48:27 --> Segmentor class already loaded. Second attempt ignored.
ERROR - 2010-07-04 14:48:27 --> Severity: Notice  --> Undefined property: Scope_anchor_text::$id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Scope_anchor_text.php 133
DEBUG - 2010-07-04 14:49:35 --> Config Class Initialized
DEBUG - 2010-07-04 14:49:35 --> Hooks Class Initialized
DEBUG - 2010-07-04 14:49:35 --> URI Class Initialized
DEBUG - 2010-07-04 14:49:35 --> Router Class Initialized
DEBUG - 2010-07-04 14:49:35 --> Output Class Initialized
DEBUG - 2010-07-04 14:49:35 --> Input Class Initialized
DEBUG - 2010-07-04 14:49:35 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 14:49:35 --> Language Class Initialized
DEBUG - 2010-07-04 14:49:35 --> Loader Class Initialized
DEBUG - 2010-07-04 14:49:35 --> Helper loaded: context_helper
DEBUG - 2010-07-04 14:49:35 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 14:49:35 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 14:49:35 --> Database Driver Class Initialized
DEBUG - 2010-07-04 14:49:35 --> Controller Class Initialized
DEBUG - 2010-07-04 14:49:35 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 14:49:35 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 14:49:35 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 14:49:35 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 14:49:35 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 14:49:35 --> Segmentor class already loaded. Second attempt ignored.
ERROR - 2010-07-04 14:49:35 --> Severity: Notice  --> Undefined property: Scope_anchor_text::$id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Scope_anchor_text.php 133
ERROR - 2010-07-04 14:49:35 --> Severity: Warning  --> Missing argument 1 for Generic_object::_get_table_data(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Scope_anchor_text.php on line 138 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 629
ERROR - 2010-07-04 14:49:35 --> Severity: Warning  --> Missing argument 2 for Generic_object::_get_table_data(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Scope_anchor_text.php on line 138 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 629
ERROR - 2010-07-04 14:49:35 --> Severity: Notice  --> Undefined variable: table_fields D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 634
ERROR - 2010-07-04 14:49:35 --> Severity: Notice  --> Undefined variable: data D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 635
DEBUG - 2010-07-04 14:49:35 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 14:49:35 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 14:49:35 --> Final output sent to browser
DEBUG - 2010-07-04 14:49:35 --> Total execution time: 0.9110
DEBUG - 2010-07-04 14:52:47 --> Config Class Initialized
DEBUG - 2010-07-04 14:52:47 --> Hooks Class Initialized
DEBUG - 2010-07-04 14:52:47 --> URI Class Initialized
DEBUG - 2010-07-04 14:52:47 --> Router Class Initialized
DEBUG - 2010-07-04 14:52:47 --> Output Class Initialized
DEBUG - 2010-07-04 14:52:47 --> Input Class Initialized
DEBUG - 2010-07-04 14:52:47 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 14:52:47 --> Language Class Initialized
DEBUG - 2010-07-04 14:52:47 --> Loader Class Initialized
DEBUG - 2010-07-04 14:52:47 --> Helper loaded: context_helper
DEBUG - 2010-07-04 14:52:47 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 14:52:47 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 14:52:47 --> Database Driver Class Initialized
DEBUG - 2010-07-04 14:52:47 --> Controller Class Initialized
DEBUG - 2010-07-04 14:52:47 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 14:52:47 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 14:52:47 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 14:52:47 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 14:52:48 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 14:52:48 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 14:52:48 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 14:52:48 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 14:52:48 --> Final output sent to browser
DEBUG - 2010-07-04 14:52:48 --> Total execution time: 1.0374
DEBUG - 2010-07-04 14:56:10 --> Config Class Initialized
DEBUG - 2010-07-04 14:56:10 --> Hooks Class Initialized
DEBUG - 2010-07-04 14:56:10 --> URI Class Initialized
DEBUG - 2010-07-04 14:56:10 --> Router Class Initialized
DEBUG - 2010-07-04 14:56:10 --> Output Class Initialized
DEBUG - 2010-07-04 14:56:10 --> Input Class Initialized
DEBUG - 2010-07-04 14:56:10 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 14:56:10 --> Language Class Initialized
DEBUG - 2010-07-04 14:56:10 --> Loader Class Initialized
DEBUG - 2010-07-04 14:56:10 --> Helper loaded: context_helper
DEBUG - 2010-07-04 14:56:10 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 14:56:10 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 14:56:10 --> Database Driver Class Initialized
DEBUG - 2010-07-04 14:56:10 --> Controller Class Initialized
DEBUG - 2010-07-04 14:56:10 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 14:56:10 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 14:56:10 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 14:56:10 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 14:56:10 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 14:56:10 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 14:56:33 --> Config Class Initialized
DEBUG - 2010-07-04 14:56:33 --> Hooks Class Initialized
DEBUG - 2010-07-04 14:56:33 --> URI Class Initialized
DEBUG - 2010-07-04 14:56:33 --> Router Class Initialized
DEBUG - 2010-07-04 14:56:33 --> Output Class Initialized
DEBUG - 2010-07-04 14:56:33 --> Input Class Initialized
DEBUG - 2010-07-04 14:56:33 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 14:56:33 --> Language Class Initialized
DEBUG - 2010-07-04 14:56:33 --> Loader Class Initialized
DEBUG - 2010-07-04 14:56:33 --> Helper loaded: context_helper
DEBUG - 2010-07-04 14:56:33 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 14:56:33 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 14:56:33 --> Database Driver Class Initialized
DEBUG - 2010-07-04 14:56:33 --> Controller Class Initialized
DEBUG - 2010-07-04 14:56:33 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 14:56:33 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 14:56:33 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 14:56:33 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 14:56:33 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 14:56:33 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 14:56:33 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 14:56:33 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 14:56:33 --> Final output sent to browser
DEBUG - 2010-07-04 14:56:34 --> Total execution time: 0.8027
DEBUG - 2010-07-04 15:39:54 --> Config Class Initialized
DEBUG - 2010-07-04 15:39:54 --> Hooks Class Initialized
DEBUG - 2010-07-04 15:39:54 --> URI Class Initialized
DEBUG - 2010-07-04 15:39:54 --> No URI present. Default controller set.
DEBUG - 2010-07-04 15:39:54 --> Router Class Initialized
DEBUG - 2010-07-04 15:39:54 --> Output Class Initialized
DEBUG - 2010-07-04 15:39:54 --> Input Class Initialized
DEBUG - 2010-07-04 15:39:54 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 15:39:54 --> Language Class Initialized
DEBUG - 2010-07-04 15:39:54 --> Loader Class Initialized
DEBUG - 2010-07-04 15:39:54 --> Helper loaded: context_helper
DEBUG - 2010-07-04 15:39:54 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 15:39:54 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 15:39:54 --> Database Driver Class Initialized
DEBUG - 2010-07-04 15:39:54 --> Controller Class Initialized
ERROR - 2010-07-04 15:39:54 --> Severity: Notice  --> Undefined property: B::$t D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\welcome.php 11
DEBUG - 2010-07-04 15:39:54 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-07-04 15:40:30 --> Config Class Initialized
DEBUG - 2010-07-04 15:40:30 --> Hooks Class Initialized
DEBUG - 2010-07-04 15:40:30 --> URI Class Initialized
DEBUG - 2010-07-04 15:40:30 --> No URI present. Default controller set.
DEBUG - 2010-07-04 15:40:30 --> Router Class Initialized
DEBUG - 2010-07-04 15:40:30 --> Output Class Initialized
DEBUG - 2010-07-04 15:40:30 --> Input Class Initialized
DEBUG - 2010-07-04 15:40:30 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 15:40:30 --> Language Class Initialized
DEBUG - 2010-07-04 15:40:30 --> Loader Class Initialized
DEBUG - 2010-07-04 15:40:30 --> Helper loaded: context_helper
DEBUG - 2010-07-04 15:40:30 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 15:40:30 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 15:40:31 --> Database Driver Class Initialized
DEBUG - 2010-07-04 15:40:31 --> Controller Class Initialized
DEBUG - 2010-07-04 15:40:31 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-07-04 15:40:52 --> Config Class Initialized
DEBUG - 2010-07-04 15:40:52 --> Hooks Class Initialized
DEBUG - 2010-07-04 15:40:52 --> URI Class Initialized
DEBUG - 2010-07-04 15:40:52 --> No URI present. Default controller set.
DEBUG - 2010-07-04 15:40:52 --> Router Class Initialized
DEBUG - 2010-07-04 15:40:52 --> Output Class Initialized
DEBUG - 2010-07-04 15:40:52 --> Input Class Initialized
DEBUG - 2010-07-04 15:40:52 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 15:40:52 --> Language Class Initialized
DEBUG - 2010-07-04 15:40:52 --> Loader Class Initialized
DEBUG - 2010-07-04 15:40:52 --> Helper loaded: context_helper
DEBUG - 2010-07-04 15:40:52 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 15:40:52 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 15:40:52 --> Database Driver Class Initialized
DEBUG - 2010-07-04 15:40:52 --> Controller Class Initialized
DEBUG - 2010-07-04 15:40:53 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-07-04 15:41:04 --> Config Class Initialized
DEBUG - 2010-07-04 15:41:04 --> Hooks Class Initialized
DEBUG - 2010-07-04 15:41:04 --> URI Class Initialized
DEBUG - 2010-07-04 15:41:05 --> No URI present. Default controller set.
DEBUG - 2010-07-04 15:41:05 --> Router Class Initialized
DEBUG - 2010-07-04 15:41:05 --> Output Class Initialized
DEBUG - 2010-07-04 15:41:05 --> Input Class Initialized
DEBUG - 2010-07-04 15:41:05 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 15:41:05 --> Language Class Initialized
DEBUG - 2010-07-04 15:41:05 --> Loader Class Initialized
DEBUG - 2010-07-04 15:41:05 --> Helper loaded: context_helper
DEBUG - 2010-07-04 15:41:05 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 15:41:05 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 15:41:05 --> Database Driver Class Initialized
DEBUG - 2010-07-04 15:41:05 --> Controller Class Initialized
DEBUG - 2010-07-04 15:42:29 --> Config Class Initialized
DEBUG - 2010-07-04 15:42:29 --> Hooks Class Initialized
DEBUG - 2010-07-04 15:42:29 --> URI Class Initialized
DEBUG - 2010-07-04 15:42:29 --> No URI present. Default controller set.
DEBUG - 2010-07-04 15:42:29 --> Router Class Initialized
DEBUG - 2010-07-04 15:42:29 --> Output Class Initialized
DEBUG - 2010-07-04 15:42:29 --> Input Class Initialized
DEBUG - 2010-07-04 15:42:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 15:42:29 --> Language Class Initialized
DEBUG - 2010-07-04 15:42:38 --> Config Class Initialized
DEBUG - 2010-07-04 15:42:38 --> Hooks Class Initialized
DEBUG - 2010-07-04 15:42:38 --> URI Class Initialized
DEBUG - 2010-07-04 15:42:38 --> No URI present. Default controller set.
DEBUG - 2010-07-04 15:42:38 --> Router Class Initialized
DEBUG - 2010-07-04 15:42:38 --> Output Class Initialized
DEBUG - 2010-07-04 15:42:39 --> Input Class Initialized
DEBUG - 2010-07-04 15:42:39 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 15:42:39 --> Language Class Initialized
DEBUG - 2010-07-04 15:42:39 --> Loader Class Initialized
DEBUG - 2010-07-04 15:42:39 --> Helper loaded: context_helper
DEBUG - 2010-07-04 15:42:39 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 15:42:39 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 15:42:39 --> Database Driver Class Initialized
DEBUG - 2010-07-04 15:42:39 --> Controller Class Initialized
ERROR - 2010-07-04 15:42:39 --> Severity: Notice  --> Undefined variable: t D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\welcome.php 8
DEBUG - 2010-07-04 15:48:50 --> Config Class Initialized
DEBUG - 2010-07-04 15:48:50 --> Hooks Class Initialized
DEBUG - 2010-07-04 15:48:50 --> URI Class Initialized
DEBUG - 2010-07-04 15:48:50 --> No URI present. Default controller set.
DEBUG - 2010-07-04 15:48:50 --> Router Class Initialized
DEBUG - 2010-07-04 15:48:50 --> Output Class Initialized
DEBUG - 2010-07-04 15:48:51 --> Input Class Initialized
DEBUG - 2010-07-04 15:48:51 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 15:48:51 --> Language Class Initialized
DEBUG - 2010-07-04 17:05:46 --> Config Class Initialized
DEBUG - 2010-07-04 17:05:46 --> Hooks Class Initialized
DEBUG - 2010-07-04 17:05:46 --> URI Class Initialized
DEBUG - 2010-07-04 17:05:46 --> Router Class Initialized
DEBUG - 2010-07-04 17:05:46 --> Output Class Initialized
DEBUG - 2010-07-04 17:05:46 --> Input Class Initialized
DEBUG - 2010-07-04 17:05:46 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-04 17:05:46 --> Language Class Initialized
DEBUG - 2010-07-04 17:05:46 --> Loader Class Initialized
DEBUG - 2010-07-04 17:05:46 --> Helper loaded: context_helper
DEBUG - 2010-07-04 17:05:47 --> Helper loaded: kals_helper
DEBUG - 2010-07-04 17:05:47 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-04 17:05:47 --> Database Driver Class Initialized
DEBUG - 2010-07-04 17:05:47 --> Controller Class Initialized
DEBUG - 2010-07-04 17:05:47 --> Unit Testing Class Initialized
DEBUG - 2010-07-04 17:05:47 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-04 17:05:47 --> Config file loaded: config/kals.php
DEBUG - 2010-07-04 17:05:47 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 17:05:47 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 17:05:47 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-04 17:05:47 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-04 17:05:47 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-04 17:05:47 --> Final output sent to browser
DEBUG - 2010-07-04 17:05:47 --> Total execution time: 0.8439
