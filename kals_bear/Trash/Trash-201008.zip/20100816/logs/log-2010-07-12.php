<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-07-12 08:55:12 --> Severity: Warning  --> Missing argument 1 for Generic_object::_get_cache_cond(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php on line 222 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1043
ERROR - 2010-07-12 08:55:12 --> Severity: Notice  --> Undefined variable: data D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1045
ERROR - 2010-07-12 08:55:12 --> Severity: Notice  --> Undefined variable: data D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1045
ERROR - 2010-07-12 08:55:12 --> Severity: Notice  --> Undefined variable: data D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1058
ERROR - 2010-07-12 08:55:12 --> Severity: Notice  --> Undefined variable: data D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1066
ERROR - 2010-07-12 08:55:12 --> Severity: Warning  --> Missing argument 1 for Generic_object::_get_cache_cond(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php on line 222 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1043
ERROR - 2010-07-12 08:55:12 --> Severity: Notice  --> Undefined variable: data D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1045
ERROR - 2010-07-12 08:55:12 --> Severity: Notice  --> Undefined variable: data D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1045
ERROR - 2010-07-12 08:55:12 --> Severity: Notice  --> Undefined variable: data D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1058
ERROR - 2010-07-12 08:55:12 --> Severity: Notice  --> Undefined variable: data D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1066
ERROR - 2010-07-12 08:55:12 --> Severity: Warning  --> Missing argument 1 for Generic_object::_get_cache_cond(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php on line 222 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1043
ERROR - 2010-07-12 08:55:12 --> Severity: Notice  --> Undefined variable: data D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1045
ERROR - 2010-07-12 08:55:12 --> Severity: Notice  --> Undefined variable: data D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1045
ERROR - 2010-07-12 08:55:12 --> Severity: Notice  --> Undefined variable: data D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1058
ERROR - 2010-07-12 08:55:12 --> Severity: Notice  --> Undefined variable: data D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1066
ERROR - 2010-07-12 08:55:12 --> Severity: Warning  --> Missing argument 1 for Generic_object::_get_cache_cond(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php on line 222 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1043
ERROR - 2010-07-12 08:55:12 --> Severity: Notice  --> Undefined variable: data D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1045
ERROR - 2010-07-12 08:55:12 --> Severity: Notice  --> Undefined variable: data D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1045
ERROR - 2010-07-12 08:55:12 --> Severity: Notice  --> Undefined variable: data D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1058
ERROR - 2010-07-12 08:55:12 --> Severity: Notice  --> Undefined variable: data D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1066
ERROR - 2010-07-12 08:55:12 --> Severity: Warning  --> Missing argument 1 for Generic_object::_get_cache_cond(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php on line 222 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1043
ERROR - 2010-07-12 08:55:12 --> Severity: Notice  --> Undefined variable: data D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1045
ERROR - 2010-07-12 08:55:12 --> Severity: Notice  --> Undefined variable: data D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1045
ERROR - 2010-07-12 08:55:12 --> Severity: Notice  --> Undefined variable: data D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1058
ERROR - 2010-07-12 08:55:12 --> Severity: Notice  --> Undefined variable: data D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1066
ERROR - 2010-07-12 09:05:04 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/ed3d2c21991e3bef5e069713af9fa6ca) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-12 09:09:42 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/4e732ced3463d06de0ca9a15b6153677) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-12 09:10:09 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/14bfa6bb14875e45bba028a21ed38046) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-12 09:39:27 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/f899139df5e1059396431415e770c6dd) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-12 11:11:20 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/03afdbd66e7929b125f8597834fa83a4) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-12 13:04:17 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/d3d9446802a44259755d38e6d163e820) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-12 13:07:27 --> Severity: Notice  --> Undefined variable: item D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\views\misc\unit_test_index.php 123
ERROR - 2010-07-12 13:07:27 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\views\misc\unit_test_index.php 123
ERROR - 2010-07-12 13:10:26 --> Unable to load the requested class: kalsactor
ERROR - 2010-07-12 13:13:07 --> 管理Webpage錯誤
ERROR - 2010-07-12 13:36:26 --> 404 Page Not Found --> ut_fuzzyut_output_lang_var
ERROR - 2010-07-12 13:36:26 --> 404 Page Not Found --> ut_kals_actorut_notification
ERROR - 2010-07-12 13:36:26 --> 404 Page Not Found --> ut_kals_actorut_user
ERROR - 2010-07-12 13:36:27 --> 404 Page Not Found --> ut_kals_resourceut_domain
ERROR - 2010-07-12 13:36:27 --> 404 Page Not Found --> ut_kals_resourceut_webpage
ERROR - 2010-07-12 13:36:27 --> 404 Page Not Found --> ut_miscut_kals_helper
ERROR - 2010-07-12 13:36:27 --> 404 Page Not Found --> ut_kals_resourceut_annotation
ERROR - 2010-07-12 13:36:27 --> 404 Page Not Found --> ut_policyut_action
ERROR - 2010-07-12 13:36:27 --> 404 Page Not Found --> ut_policyut_auth
ERROR - 2010-07-12 13:36:27 --> 404 Page Not Found --> ut_scopeut_scope
ERROR - 2010-07-12 13:36:27 --> 404 Page Not Found --> ut_scopeut_scope_anchor_text
ERROR - 2010-07-12 13:36:27 --> 404 Page Not Found --> ut_scopeut_scope_collection
ERROR - 2010-07-12 13:36:28 --> 404 Page Not Found --> ut_scopeut_segmentor
ERROR - 2010-07-12 13:36:28 --> 404 Page Not Found --> ut_typeut_type
ERROR - 2010-07-12 13:36:40 --> 404 Page Not Found --> ut_fuzzyut_output_lang_var
ERROR - 2010-07-12 13:36:40 --> 404 Page Not Found --> ut_kals_actorut_group
ERROR - 2010-07-12 13:36:41 --> 404 Page Not Found --> ut_kals_actorut_notification
ERROR - 2010-07-12 13:36:41 --> 404 Page Not Found --> ut_kals_actorut_user
ERROR - 2010-07-12 13:36:41 --> 404 Page Not Found --> ut_kals_resourceut_domain
ERROR - 2010-07-12 13:36:41 --> 404 Page Not Found --> ut_kals_resourceut_annotation
ERROR - 2010-07-12 13:36:41 --> 404 Page Not Found --> ut_miscut_kals_helper
ERROR - 2010-07-12 13:36:41 --> 404 Page Not Found --> ut_policyut_action
ERROR - 2010-07-12 13:36:41 --> 404 Page Not Found --> ut_policyut_auth
ERROR - 2010-07-12 13:36:42 --> 404 Page Not Found --> ut_scopeut_scope
ERROR - 2010-07-12 13:36:42 --> 404 Page Not Found --> ut_scopeut_scope_anchor_text
ERROR - 2010-07-12 13:36:42 --> 404 Page Not Found --> ut_scopeut_scope_collection
ERROR - 2010-07-12 13:36:42 --> 404 Page Not Found --> ut_scopeut_segmentor
ERROR - 2010-07-12 13:36:42 --> 404 Page Not Found --> ut_typeut_type
ERROR - 2010-07-12 13:36:59 --> 404 Page Not Found --> ut_fuzzyut_output_lang_var
ERROR - 2010-07-12 13:36:59 --> 404 Page Not Found --> ut_kals_resourceut_webpage
ERROR - 2010-07-12 13:36:59 --> 404 Page Not Found --> ut_scopeut_scope
ERROR - 2010-07-12 13:37:00 --> 404 Page Not Found --> ut_kals_actorut_notification
ERROR - 2010-07-12 13:37:00 --> 404 Page Not Found --> ut_kals_actorut_group
ERROR - 2010-07-12 13:37:00 --> 404 Page Not Found --> ut_kals_actorut_user
ERROR - 2010-07-12 13:37:00 --> 404 Page Not Found --> ut_kals_resourceut_domain
ERROR - 2010-07-12 13:37:00 --> 404 Page Not Found --> ut_kals_resourceut_annotation
ERROR - 2010-07-12 13:37:00 --> 404 Page Not Found --> ut_scopeut_segmentor
ERROR - 2010-07-12 13:37:00 --> 404 Page Not Found --> ut_miscut_kals_helper
ERROR - 2010-07-12 13:37:00 --> 404 Page Not Found --> ut_scopeut_scope_collection
ERROR - 2010-07-12 13:37:00 --> 404 Page Not Found --> ut_policyut_auth
ERROR - 2010-07-12 13:37:00 --> 404 Page Not Found --> ut_policyut_action
ERROR - 2010-07-12 13:37:00 --> 404 Page Not Found --> ut_scopeut_scope_anchor_text
ERROR - 2010-07-12 13:37:00 --> 404 Page Not Found --> ut_typeut_type
ERROR - 2010-07-12 13:37:42 --> 404 Page Not Found --> ut_fuzzyut_output_lang_var
ERROR - 2010-07-12 13:37:42 --> 404 Page Not Found --> ut_kals_resourceut_webpage
ERROR - 2010-07-12 13:37:42 --> 404 Page Not Found --> ut_scopeut_scope
ERROR - 2010-07-12 13:37:43 --> 404 Page Not Found --> ut_kals_actorut_group
ERROR - 2010-07-12 13:37:43 --> 404 Page Not Found --> ut_kals_actorut_notification
ERROR - 2010-07-12 13:37:43 --> 404 Page Not Found --> ut_kals_actorut_user
ERROR - 2010-07-12 13:37:43 --> 404 Page Not Found --> ut_kals_resourceut_domain
ERROR - 2010-07-12 13:37:43 --> 404 Page Not Found --> ut_kals_resourceut_annotation
ERROR - 2010-07-12 13:37:43 --> 404 Page Not Found --> ut_policyut_action
ERROR - 2010-07-12 13:37:43 --> 404 Page Not Found --> ut_miscut_kals_helper
ERROR - 2010-07-12 13:37:43 --> 404 Page Not Found --> ut_policyut_auth
ERROR - 2010-07-12 13:37:43 --> 404 Page Not Found --> ut_scopeut_scope_anchor_text
ERROR - 2010-07-12 13:37:43 --> 404 Page Not Found --> ut_scopeut_scope_collection
ERROR - 2010-07-12 13:37:43 --> 404 Page Not Found --> ut_scopeut_segmentor
ERROR - 2010-07-12 13:37:43 --> 404 Page Not Found --> ut_typeut_type
ERROR - 2010-07-12 13:38:15 --> 404 Page Not Found --> ut_kals_resourceut_domain
ERROR - 2010-07-12 13:38:15 --> 404 Page Not Found --> ut_policyut_action
ERROR - 2010-07-12 13:38:15 --> 404 Page Not Found --> ut_scopeut_segmentor
ERROR - 2010-07-12 13:38:16 --> 404 Page Not Found --> ut_kals_actorut_group
ERROR - 2010-07-12 13:38:16 --> 404 Page Not Found --> ut_kals_actorut_notification
ERROR - 2010-07-12 13:38:16 --> 404 Page Not Found --> ut_kals_actorut_user
ERROR - 2010-07-12 13:38:16 --> 404 Page Not Found --> ut_kals_resourceut_annotation
ERROR - 2010-07-12 13:38:16 --> 404 Page Not Found --> ut_miscut_kals_helper
ERROR - 2010-07-12 13:38:16 --> 404 Page Not Found --> ut_kals_resourceut_webpage
ERROR - 2010-07-12 13:38:16 --> 404 Page Not Found --> ut_policyut_auth
ERROR - 2010-07-12 13:38:17 --> 404 Page Not Found --> ut_scopeut_scope_anchor_text
ERROR - 2010-07-12 13:38:17 --> 404 Page Not Found --> ut_scopeut_scope
ERROR - 2010-07-12 13:38:17 --> 404 Page Not Found --> ut_scopeut_scope_collection
ERROR - 2010-07-12 13:38:17 --> 404 Page Not Found --> ut_typeut_type
ERROR - 2010-07-12 13:40:41 --> 404 Page Not Found --> ut_fuzzyut_output_lang_var
ERROR - 2010-07-12 13:41:12 --> 404 Page Not Found --> ut_fuzzyut_output_lang_var
ERROR - 2010-07-12 13:41:44 --> 404 Page Not Found --> ut_fuzzyut_output_lang_var
ERROR - 2010-07-12 13:41:56 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/c9f0f895fb98ab9159f51fd0297e236d) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-12 14:03:02 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/c0c7c76d30bd3dcaefc96f40275bdc0a) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-12 14:05:40 --> 嘗試取出 Policy物件 的 action 欄位，但 Policy物件 不存在 action 欄位
ERROR - 2010-07-12 14:05:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:393) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-12 14:08:52 --> 嘗試取出 Policy物件 的 action 欄位，但 Policy物件 不存在 action 欄位
ERROR - 2010-07-12 14:08:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:393) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-12 14:09:26 --> 嘗試取出 Policy物件 的 action 欄位，但 Policy物件 不存在 action 欄位
ERROR - 2010-07-12 14:09:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:393) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-12 14:10:12 --> 嘗試取出 Policy物件 的 action 欄位，但 Policy物件 不存在 action 欄位
ERROR - 2010-07-12 14:10:12 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:393) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-12 14:11:57 --> 嘗試取出 Policy物件 的 action 欄位，但 Policy物件 不存在 action 欄位
ERROR - 2010-07-12 14:11:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:393) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-12 14:12:55 --> 嘗試取出 Policy物件 的 action 欄位，但 Policy物件 不存在 action 欄位
ERROR - 2010-07-12 14:12:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:393) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-12 14:14:37 --> 嘗試取出 Policy物件 的 action 欄位，但 Policy物件 不存在 action 欄位
ERROR - 2010-07-12 14:14:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:393) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-12 14:15:13 --> 嘗試取出 Policy物件 的 action 欄位，但 Policy物件 不存在 action 欄位
ERROR - 2010-07-12 14:15:13 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:393) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-12 14:19:22 --> 嘗試取出 Policy物件 的 action 欄位，但 Policy物件 不存在 action 欄位
ERROR - 2010-07-12 14:19:22 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:393) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-12 16:55:14 --> Severity: Warning  --> Illegal offset type in isset or empty D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_collection.php 334
ERROR - 2010-07-12 16:55:14 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_collection.php 335
ERROR - 2010-07-12 16:55:14 --> Severity: Notice  --> Undefined property: Action_webpage_administration::$get_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Authorize_manager.php 127
ERROR - 2010-07-12 16:55:14 --> Severity: 4096  --> Argument 1 passed to Policy_collection::allow() must be an instance of Action, null given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Authorize_manager.php on line 127 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Policy_collection.php 78
ERROR - 2010-07-12 16:55:14 --> Severity: 4096  --> Argument 1 passed to Policy_collection::get_policy() must be an instance of Action, null given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Policy_collection.php on line 80 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Policy_collection.php 101
ERROR - 2010-07-12 16:56:49 --> Severity: Notice  --> Undefined property: Action_webpage_administration::$get_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Authorize_manager.php 127
ERROR - 2010-07-12 16:56:49 --> Severity: 4096  --> Argument 1 passed to Policy_collection::allow() must be an instance of Action, null given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Authorize_manager.php on line 127 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Policy_collection.php 78
ERROR - 2010-07-12 16:56:49 --> Severity: 4096  --> Argument 1 passed to Policy_collection::get_policy() must be an instance of Action, null given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Policy_collection.php on line 80 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Policy_collection.php 101
ERROR - 2010-07-12 16:58:37 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/02e74f10e0327ad868d138f2b4fdd6f0) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-12 16:59:04 --> Severity: 4096  --> Object of class Action_webpage_administration could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 405
ERROR - 2010-07-12 17:00:19 --> Severity: 4096  --> Object of class Action_webpage_administration could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 405
ERROR - 2010-07-12 17:01:42 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/f457c545a9ded88f18ecee47145a72c0) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-12 17:01:42 --> Severity: 4096  --> Object of class Action_webpage_administration could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 405
ERROR - 2010-07-12 17:02:31 --> Severity: 4096  --> Object of class Action_webpage_administration could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 405
ERROR - 2010-07-12 17:03:03 --> Severity: 4096  --> Object of class Action_webpage_administration could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 405
ERROR - 2010-07-12 17:03:56 --> Severity: 4096  --> Object of class Action_webpage_administration could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 405
ERROR - 2010-07-12 17:03:56 --> Severity: 4096  --> Object of class Action_webpage_read could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 405
ERROR - 2010-07-12 17:03:56 --> Severity: 4096  --> Object of class Action_domain_administration could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 405
ERROR - 2010-07-12 17:03:56 --> Severity: 4096  --> Object of class Policy_collection could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 328
ERROR - 2010-07-12 17:03:56 --> Severity: 4096  --> Object of class Policy_collection could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 244
ERROR - 2010-07-12 17:03:56 --> Severity: Notice  --> Object of class Policy_collection to string conversion D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 244
ERROR - 2010-07-12 17:04:45 --> Severity: 4096  --> Object of class Action_webpage_administration could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 405
ERROR - 2010-07-12 17:04:45 --> Severity: 4096  --> Object of class Action_webpage_read could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 405
ERROR - 2010-07-12 17:04:45 --> Severity: 4096  --> Object of class Action_domain_administration could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 405
ERROR - 2010-07-12 17:04:45 --> Severity: 4096  --> Object of class Policy_collection could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 328
ERROR - 2010-07-12 17:04:45 --> Severity: 4096  --> Object of class Policy_collection could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 244
ERROR - 2010-07-12 17:04:45 --> Severity: Notice  --> Object of class Policy_collection to string conversion D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 244
ERROR - 2010-07-12 17:06:03 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/45c48cce2e2d7fbdea1afc51c7c6ad26) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-12 17:06:04 --> Severity: 4096  --> Object of class Action_webpage_administration could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 405
ERROR - 2010-07-12 17:06:04 --> Severity: 4096  --> Object of class Action_webpage_read could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 405
ERROR - 2010-07-12 17:06:04 --> Severity: 4096  --> Object of class Action_domain_administration could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 405
ERROR - 2010-07-12 17:06:04 --> Severity: 4096  --> Object of class Policy_collection could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 328
ERROR - 2010-07-12 17:06:04 --> Severity: 4096  --> Object of class Policy_collection could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 244
ERROR - 2010-07-12 17:06:04 --> Severity: Notice  --> Object of class Policy_collection to string conversion D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 244
ERROR - 2010-07-12 17:06:04 --> 嘗試取出 Policy_actor物件 的  欄位，但 Policy_actor物件 不存在  欄位
ERROR - 2010-07-12 17:06:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:393) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-12 17:06:45 --> Severity: 4096  --> Object of class Policy_collection could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 328
ERROR - 2010-07-12 17:06:45 --> Severity: 4096  --> Object of class Policy_collection could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 244
ERROR - 2010-07-12 17:06:45 --> Severity: Notice  --> Object of class Policy_collection to string conversion D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 244
ERROR - 2010-07-12 17:06:45 --> 嘗試取出 Policy_actor物件 的  欄位，但 Policy_actor物件 不存在  欄位
ERROR - 2010-07-12 17:06:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:393) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-12 17:09:07 --> Severity: 4096  --> Object of class Policy_collection could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 328
ERROR - 2010-07-12 17:09:07 --> Severity: 4096  --> Object of class Policy_collection could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 244
ERROR - 2010-07-12 17:09:07 --> Severity: Notice  --> Object of class Policy_collection to string conversion D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 244
ERROR - 2010-07-12 17:09:07 --> 嘗試取出 Policy_actor物件 的  欄位，但 Policy_actor物件 不存在  欄位
ERROR - 2010-07-12 17:09:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:393) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-12 17:10:24 --> 嘗試取出 Policy_actor物件 的  欄位，但 Policy_actor物件 不存在  欄位
ERROR - 2010-07-12 17:10:24 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:393) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-12 17:12:17 --> 嘗試取出 Policy_actor物件 的  欄位，但 Policy_actor物件 不存在  欄位
ERROR - 2010-07-12 17:12:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:393) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
