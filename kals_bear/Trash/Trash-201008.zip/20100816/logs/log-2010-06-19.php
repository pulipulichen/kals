<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2010-06-19 09:20:27 --> Config Class Initialized
DEBUG - 2010-06-19 09:20:27 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:20:27 --> URI Class Initialized
DEBUG - 2010-06-19 09:20:27 --> Router Class Initialized
DEBUG - 2010-06-19 09:20:27 --> Output Class Initialized
DEBUG - 2010-06-19 09:20:27 --> Input Class Initialized
DEBUG - 2010-06-19 09:20:27 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:20:27 --> Language Class Initialized
DEBUG - 2010-06-19 09:20:27 --> Loader Class Initialized
DEBUG - 2010-06-19 09:20:27 --> Controller Class Initialized
DEBUG - 2010-06-19 09:21:45 --> Config Class Initialized
DEBUG - 2010-06-19 09:21:45 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:21:45 --> URI Class Initialized
DEBUG - 2010-06-19 09:21:45 --> Router Class Initialized
DEBUG - 2010-06-19 09:21:45 --> Output Class Initialized
DEBUG - 2010-06-19 09:21:45 --> Input Class Initialized
DEBUG - 2010-06-19 09:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:21:45 --> Language Class Initialized
DEBUG - 2010-06-19 09:21:45 --> Loader Class Initialized
DEBUG - 2010-06-19 09:21:45 --> Controller Class Initialized
DEBUG - 2010-06-19 09:21:51 --> Config Class Initialized
DEBUG - 2010-06-19 09:21:51 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:21:51 --> URI Class Initialized
DEBUG - 2010-06-19 09:21:51 --> Router Class Initialized
DEBUG - 2010-06-19 09:21:51 --> Output Class Initialized
DEBUG - 2010-06-19 09:21:51 --> Input Class Initialized
DEBUG - 2010-06-19 09:21:51 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:21:51 --> Language Class Initialized
DEBUG - 2010-06-19 09:21:51 --> Loader Class Initialized
DEBUG - 2010-06-19 09:21:51 --> Controller Class Initialized
DEBUG - 2010-06-19 09:22:41 --> Config Class Initialized
DEBUG - 2010-06-19 09:22:41 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:22:41 --> URI Class Initialized
DEBUG - 2010-06-19 09:22:41 --> Router Class Initialized
DEBUG - 2010-06-19 09:22:41 --> Output Class Initialized
DEBUG - 2010-06-19 09:22:41 --> Input Class Initialized
DEBUG - 2010-06-19 09:22:41 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:22:42 --> Language Class Initialized
DEBUG - 2010-06-19 09:22:42 --> Loader Class Initialized
DEBUG - 2010-06-19 09:22:42 --> Controller Class Initialized
DEBUG - 2010-06-19 09:22:51 --> Config Class Initialized
DEBUG - 2010-06-19 09:22:51 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:22:51 --> URI Class Initialized
DEBUG - 2010-06-19 09:22:51 --> Router Class Initialized
DEBUG - 2010-06-19 09:22:51 --> Output Class Initialized
DEBUG - 2010-06-19 09:22:51 --> Input Class Initialized
DEBUG - 2010-06-19 09:22:51 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:22:51 --> Language Class Initialized
DEBUG - 2010-06-19 09:22:51 --> Loader Class Initialized
DEBUG - 2010-06-19 09:22:51 --> Controller Class Initialized
INFO  - 2010-06-19 09:22:51 --> test2
DEBUG - 2010-06-19 09:22:51 --> Final output sent to browser
DEBUG - 2010-06-19 09:22:51 --> Total execution time: 0.1851
DEBUG - 2010-06-19 09:23:30 --> Config Class Initialized
DEBUG - 2010-06-19 09:23:30 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:23:30 --> URI Class Initialized
DEBUG - 2010-06-19 09:23:30 --> Router Class Initialized
DEBUG - 2010-06-19 09:23:30 --> Output Class Initialized
DEBUG - 2010-06-19 09:23:30 --> Input Class Initialized
DEBUG - 2010-06-19 09:23:30 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:23:30 --> Language Class Initialized
DEBUG - 2010-06-19 09:23:30 --> Loader Class Initialized
DEBUG - 2010-06-19 09:23:30 --> Controller Class Initialized
INFO  - 2010-06-19 09:23:30 --> test2
DEBUG - 2010-06-19 09:23:30 --> Final output sent to browser
DEBUG - 2010-06-19 09:23:30 --> Total execution time: 0.1579
DEBUG - 2010-06-19 09:24:15 --> Config Class Initialized
DEBUG - 2010-06-19 09:24:15 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:24:15 --> URI Class Initialized
DEBUG - 2010-06-19 09:24:15 --> Router Class Initialized
DEBUG - 2010-06-19 09:24:15 --> Output Class Initialized
DEBUG - 2010-06-19 09:24:15 --> Input Class Initialized
DEBUG - 2010-06-19 09:24:15 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:24:15 --> Language Class Initialized
DEBUG - 2010-06-19 09:24:15 --> Loader Class Initialized
DEBUG - 2010-06-19 09:24:15 --> Controller Class Initialized
DEBUG - 2010-06-19 09:29:30 --> Config Class Initialized
DEBUG - 2010-06-19 09:29:30 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:29:30 --> URI Class Initialized
DEBUG - 2010-06-19 09:29:30 --> Router Class Initialized
DEBUG - 2010-06-19 09:29:30 --> Output Class Initialized
DEBUG - 2010-06-19 09:29:30 --> Input Class Initialized
DEBUG - 2010-06-19 09:29:30 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:29:30 --> Language Class Initialized
DEBUG - 2010-06-19 09:29:30 --> Loader Class Initialized
DEBUG - 2010-06-19 09:29:30 --> Controller Class Initialized
DEBUG - 2010-06-19 09:29:30 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 09:29:30 --> Model Class Initialized
DEBUG - 2010-06-19 09:30:28 --> Config Class Initialized
DEBUG - 2010-06-19 09:30:28 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:30:28 --> URI Class Initialized
DEBUG - 2010-06-19 09:30:28 --> Router Class Initialized
DEBUG - 2010-06-19 09:30:28 --> Output Class Initialized
DEBUG - 2010-06-19 09:30:28 --> Input Class Initialized
DEBUG - 2010-06-19 09:30:28 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:30:28 --> Language Class Initialized
DEBUG - 2010-06-19 09:30:28 --> Loader Class Initialized
DEBUG - 2010-06-19 09:30:28 --> Controller Class Initialized
DEBUG - 2010-06-19 09:30:28 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 09:31:13 --> Config Class Initialized
DEBUG - 2010-06-19 09:31:13 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:31:13 --> URI Class Initialized
DEBUG - 2010-06-19 09:31:13 --> Router Class Initialized
DEBUG - 2010-06-19 09:31:13 --> Output Class Initialized
DEBUG - 2010-06-19 09:31:13 --> Input Class Initialized
DEBUG - 2010-06-19 09:31:13 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:31:13 --> Language Class Initialized
DEBUG - 2010-06-19 09:31:13 --> Loader Class Initialized
DEBUG - 2010-06-19 09:31:13 --> Controller Class Initialized
DEBUG - 2010-06-19 09:31:13 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 09:31:58 --> Config Class Initialized
DEBUG - 2010-06-19 09:31:58 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:31:58 --> URI Class Initialized
DEBUG - 2010-06-19 09:31:58 --> Router Class Initialized
DEBUG - 2010-06-19 09:31:58 --> Output Class Initialized
DEBUG - 2010-06-19 09:31:58 --> Input Class Initialized
DEBUG - 2010-06-19 09:31:58 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:31:58 --> Language Class Initialized
DEBUG - 2010-06-19 09:31:58 --> Loader Class Initialized
DEBUG - 2010-06-19 09:31:58 --> Controller Class Initialized
DEBUG - 2010-06-19 09:31:58 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 09:31:58 --> Helper loaded: kals_helper
ERROR - 2010-06-19 09:31:58 --> Severity: Notice  --> Undefined property: Ut_domain::$db D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 67
DEBUG - 2010-06-19 09:33:02 --> Config Class Initialized
DEBUG - 2010-06-19 09:33:02 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:33:02 --> URI Class Initialized
DEBUG - 2010-06-19 09:33:02 --> Router Class Initialized
DEBUG - 2010-06-19 09:33:02 --> Output Class Initialized
DEBUG - 2010-06-19 09:33:02 --> Input Class Initialized
DEBUG - 2010-06-19 09:33:02 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:33:02 --> Language Class Initialized
DEBUG - 2010-06-19 09:33:02 --> Loader Class Initialized
DEBUG - 2010-06-19 09:33:02 --> Controller Class Initialized
DEBUG - 2010-06-19 09:33:02 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 09:33:02 --> Helper loaded: kals_helper
ERROR - 2010-06-19 09:33:02 --> Severity: Notice  --> Undefined property: Ut_domain::$db D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 65
DEBUG - 2010-06-19 09:33:29 --> Config Class Initialized
DEBUG - 2010-06-19 09:33:29 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:33:29 --> URI Class Initialized
DEBUG - 2010-06-19 09:33:29 --> Router Class Initialized
DEBUG - 2010-06-19 09:33:29 --> Output Class Initialized
DEBUG - 2010-06-19 09:33:29 --> Input Class Initialized
DEBUG - 2010-06-19 09:33:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:33:29 --> Language Class Initialized
DEBUG - 2010-06-19 09:33:29 --> Loader Class Initialized
DEBUG - 2010-06-19 09:33:29 --> Controller Class Initialized
DEBUG - 2010-06-19 09:33:29 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 09:33:29 --> Helper loaded: kals_helper
ERROR - 2010-06-19 09:33:29 --> Severity: Notice  --> Undefined property: Ut_domain::$db D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 65
DEBUG - 2010-06-19 09:33:48 --> Config Class Initialized
DEBUG - 2010-06-19 09:33:48 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:33:48 --> URI Class Initialized
DEBUG - 2010-06-19 09:33:48 --> Router Class Initialized
DEBUG - 2010-06-19 09:33:48 --> Output Class Initialized
DEBUG - 2010-06-19 09:33:48 --> Input Class Initialized
DEBUG - 2010-06-19 09:33:48 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:33:48 --> Language Class Initialized
DEBUG - 2010-06-19 09:33:48 --> Loader Class Initialized
DEBUG - 2010-06-19 09:33:48 --> Controller Class Initialized
DEBUG - 2010-06-19 09:33:48 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 09:33:48 --> Helper loaded: kals_helper
ERROR - 2010-06-19 09:33:48 --> Severity: Notice  --> Undefined property: Ut_domain::$db D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 64
DEBUG - 2010-06-19 09:33:57 --> Config Class Initialized
DEBUG - 2010-06-19 09:33:57 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:33:57 --> URI Class Initialized
DEBUG - 2010-06-19 09:33:57 --> Router Class Initialized
DEBUG - 2010-06-19 09:33:57 --> Output Class Initialized
DEBUG - 2010-06-19 09:33:57 --> Input Class Initialized
DEBUG - 2010-06-19 09:33:57 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:33:57 --> Language Class Initialized
DEBUG - 2010-06-19 09:33:57 --> Loader Class Initialized
DEBUG - 2010-06-19 09:33:57 --> Controller Class Initialized
DEBUG - 2010-06-19 09:33:57 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 09:33:57 --> Helper loaded: kals_helper
ERROR - 2010-06-19 09:33:57 --> Severity: Notice  --> Undefined property: Ut_domain::$db D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 65
DEBUG - 2010-06-19 09:35:30 --> Config Class Initialized
DEBUG - 2010-06-19 09:35:30 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:35:30 --> URI Class Initialized
DEBUG - 2010-06-19 09:35:30 --> Router Class Initialized
DEBUG - 2010-06-19 09:35:30 --> Output Class Initialized
DEBUG - 2010-06-19 09:35:30 --> Input Class Initialized
DEBUG - 2010-06-19 09:35:30 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:35:30 --> Language Class Initialized
DEBUG - 2010-06-19 09:35:31 --> Loader Class Initialized
DEBUG - 2010-06-19 09:35:31 --> Controller Class Initialized
DEBUG - 2010-06-19 09:35:31 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 09:35:31 --> Database Driver Class Initialized
ERROR - 2010-06-19 09:35:31 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'postgres'@'localhost' (using password: YES) D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\mysql\mysql_driver.php 88
ERROR - 2010-06-19 09:35:31 --> Unable to connect to the database
DEBUG - 2010-06-19 09:35:31 --> Language file loaded: language/english/db_lang.php
DEBUG - 2010-06-19 09:35:55 --> Config Class Initialized
DEBUG - 2010-06-19 09:35:55 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:35:55 --> URI Class Initialized
DEBUG - 2010-06-19 09:35:55 --> Router Class Initialized
DEBUG - 2010-06-19 09:35:55 --> Output Class Initialized
DEBUG - 2010-06-19 09:35:55 --> Input Class Initialized
DEBUG - 2010-06-19 09:35:55 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:35:55 --> Language Class Initialized
DEBUG - 2010-06-19 09:35:55 --> Loader Class Initialized
DEBUG - 2010-06-19 09:35:55 --> Controller Class Initialized
DEBUG - 2010-06-19 09:35:55 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 09:35:55 --> Database Driver Class Initialized
ERROR - 2010-06-19 09:35:55 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'postgres'@'localhost' (using password: YES) D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\mysql\mysql_driver.php 88
ERROR - 2010-06-19 09:35:55 --> Unable to connect to the database
DEBUG - 2010-06-19 09:35:55 --> Language file loaded: language/english/db_lang.php
DEBUG - 2010-06-19 09:36:27 --> Config Class Initialized
DEBUG - 2010-06-19 09:36:27 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:36:27 --> URI Class Initialized
DEBUG - 2010-06-19 09:36:27 --> Router Class Initialized
DEBUG - 2010-06-19 09:36:27 --> Output Class Initialized
DEBUG - 2010-06-19 09:36:27 --> Input Class Initialized
DEBUG - 2010-06-19 09:36:27 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:36:27 --> Language Class Initialized
DEBUG - 2010-06-19 09:36:27 --> Loader Class Initialized
DEBUG - 2010-06-19 09:36:27 --> Controller Class Initialized
DEBUG - 2010-06-19 09:36:27 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 09:36:27 --> Database Driver Class Initialized
ERROR - 2010-06-19 09:36:27 --> Unable to select database: kals
DEBUG - 2010-06-19 09:36:27 --> Language file loaded: language/english/db_lang.php
DEBUG - 2010-06-19 09:36:45 --> Config Class Initialized
DEBUG - 2010-06-19 09:36:45 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:36:45 --> URI Class Initialized
DEBUG - 2010-06-19 09:36:45 --> Router Class Initialized
DEBUG - 2010-06-19 09:36:45 --> Output Class Initialized
DEBUG - 2010-06-19 09:36:45 --> Input Class Initialized
DEBUG - 2010-06-19 09:36:45 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:36:45 --> Language Class Initialized
DEBUG - 2010-06-19 09:36:45 --> Loader Class Initialized
DEBUG - 2010-06-19 09:36:45 --> Controller Class Initialized
DEBUG - 2010-06-19 09:36:45 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 09:36:45 --> Database Driver Class Initialized
ERROR - 2010-06-19 09:36:45 --> Severity: Warning  --> pg_pconnect() [<a href='function.pg-pconnect'>function.pg-pconnect</a>]: Unable to connect to PostgreSQL server: fe_sendauth: no password supplied D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 99
ERROR - 2010-06-19 09:36:45 --> Unable to connect to the database
DEBUG - 2010-06-19 09:36:45 --> Language file loaded: language/english/db_lang.php
DEBUG - 2010-06-19 09:37:44 --> Config Class Initialized
DEBUG - 2010-06-19 09:37:44 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:37:44 --> URI Class Initialized
DEBUG - 2010-06-19 09:37:44 --> Router Class Initialized
DEBUG - 2010-06-19 09:37:44 --> Output Class Initialized
DEBUG - 2010-06-19 09:37:44 --> Input Class Initialized
DEBUG - 2010-06-19 09:37:44 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:37:44 --> Language Class Initialized
DEBUG - 2010-06-19 09:37:44 --> Loader Class Initialized
DEBUG - 2010-06-19 09:37:44 --> Controller Class Initialized
DEBUG - 2010-06-19 09:37:45 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 09:37:45 --> Database Driver Class Initialized
DEBUG - 2010-06-19 09:37:45 --> Helper loaded: kals_helper
ERROR - 2010-06-19 09:37:45 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;url&quot; does not exist
LINE 3: WHERE &quot;url&quot; = 'http://www.plurk.com/p/5uuz7o#response-163267...
              ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-19 09:37:45 --> DB Transaction Failure
ERROR - 2010-06-19 09:37:45 --> Query error: ERROR:  column "url" does not exist
LINE 3: WHERE "url" = 'http://www.plurk.com/p/5uuz7o#response-163267...
              ^
DEBUG - 2010-06-19 09:37:45 --> Language file loaded: language/english/db_lang.php
ERROR - 2010-06-19 09:37:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php:64) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-19 09:38:32 --> Config Class Initialized
DEBUG - 2010-06-19 09:38:32 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:38:32 --> URI Class Initialized
DEBUG - 2010-06-19 09:38:32 --> Router Class Initialized
DEBUG - 2010-06-19 09:38:32 --> Output Class Initialized
DEBUG - 2010-06-19 09:38:32 --> Input Class Initialized
DEBUG - 2010-06-19 09:38:32 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:38:32 --> Language Class Initialized
DEBUG - 2010-06-19 09:38:32 --> Loader Class Initialized
DEBUG - 2010-06-19 09:38:32 --> Controller Class Initialized
DEBUG - 2010-06-19 09:38:32 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 09:38:32 --> Database Driver Class Initialized
DEBUG - 2010-06-19 09:38:32 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 09:40:25 --> Config Class Initialized
DEBUG - 2010-06-19 09:40:25 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:40:25 --> URI Class Initialized
DEBUG - 2010-06-19 09:40:25 --> Router Class Initialized
DEBUG - 2010-06-19 09:40:25 --> Output Class Initialized
DEBUG - 2010-06-19 09:40:25 --> Input Class Initialized
DEBUG - 2010-06-19 09:40:25 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:40:25 --> Language Class Initialized
DEBUG - 2010-06-19 09:40:25 --> Loader Class Initialized
DEBUG - 2010-06-19 09:40:25 --> Controller Class Initialized
DEBUG - 2010-06-19 09:40:25 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 09:40:25 --> Database Driver Class Initialized
DEBUG - 2010-06-19 09:40:25 --> Helper loaded: kals_helper
ERROR - 2010-06-19 09:40:25 --> Unable to load the requested class: kals_resource
DEBUG - 2010-06-19 09:40:48 --> Config Class Initialized
DEBUG - 2010-06-19 09:40:48 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:40:48 --> URI Class Initialized
DEBUG - 2010-06-19 09:40:48 --> Router Class Initialized
DEBUG - 2010-06-19 09:40:48 --> Output Class Initialized
DEBUG - 2010-06-19 09:40:48 --> Input Class Initialized
DEBUG - 2010-06-19 09:40:48 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:40:48 --> Language Class Initialized
DEBUG - 2010-06-19 09:40:48 --> Loader Class Initialized
DEBUG - 2010-06-19 09:40:48 --> Controller Class Initialized
DEBUG - 2010-06-19 09:40:48 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 09:40:48 --> Database Driver Class Initialized
DEBUG - 2010-06-19 09:40:48 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 09:40:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 09:42:27 --> Config Class Initialized
DEBUG - 2010-06-19 09:42:27 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:42:27 --> URI Class Initialized
DEBUG - 2010-06-19 09:42:27 --> Router Class Initialized
DEBUG - 2010-06-19 09:42:27 --> Output Class Initialized
DEBUG - 2010-06-19 09:42:27 --> Input Class Initialized
DEBUG - 2010-06-19 09:42:27 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:42:27 --> Language Class Initialized
DEBUG - 2010-06-19 09:42:27 --> Loader Class Initialized
DEBUG - 2010-06-19 09:42:27 --> Controller Class Initialized
DEBUG - 2010-06-19 09:42:27 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 09:42:27 --> Database Driver Class Initialized
DEBUG - 2010-06-19 09:42:27 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 09:42:27 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-19 09:42:28 --> Severity: Notice  --> Undefined variable: date D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 120
DEBUG - 2010-06-19 09:42:28 --> Language file loaded: language/english/db_lang.php
ERROR - 2010-06-19 09:42:28 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-19 09:42:45 --> Config Class Initialized
DEBUG - 2010-06-19 09:42:45 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:42:45 --> URI Class Initialized
DEBUG - 2010-06-19 09:42:45 --> Router Class Initialized
DEBUG - 2010-06-19 09:42:45 --> Output Class Initialized
DEBUG - 2010-06-19 09:42:45 --> Input Class Initialized
DEBUG - 2010-06-19 09:42:46 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:42:46 --> Language Class Initialized
DEBUG - 2010-06-19 09:42:46 --> Loader Class Initialized
DEBUG - 2010-06-19 09:42:46 --> Controller Class Initialized
DEBUG - 2010-06-19 09:42:46 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 09:42:46 --> Database Driver Class Initialized
DEBUG - 2010-06-19 09:42:46 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 09:42:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 09:42:46 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-19 09:42:46 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 09:42:46 --> Final output sent to browser
DEBUG - 2010-06-19 09:42:46 --> Total execution time: 0.9877
DEBUG - 2010-06-19 09:46:23 --> Config Class Initialized
DEBUG - 2010-06-19 09:46:23 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:46:23 --> URI Class Initialized
DEBUG - 2010-06-19 09:46:23 --> Router Class Initialized
DEBUG - 2010-06-19 09:46:23 --> Output Class Initialized
DEBUG - 2010-06-19 09:46:23 --> Input Class Initialized
DEBUG - 2010-06-19 09:46:23 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:46:23 --> Language Class Initialized
DEBUG - 2010-06-19 09:46:23 --> Loader Class Initialized
DEBUG - 2010-06-19 09:46:23 --> Controller Class Initialized
DEBUG - 2010-06-19 09:46:23 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 09:46:23 --> Database Driver Class Initialized
DEBUG - 2010-06-19 09:46:23 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 09:46:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 09:47:31 --> Config Class Initialized
DEBUG - 2010-06-19 09:47:31 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:47:31 --> URI Class Initialized
DEBUG - 2010-06-19 09:47:31 --> Router Class Initialized
DEBUG - 2010-06-19 09:47:31 --> Output Class Initialized
DEBUG - 2010-06-19 09:47:31 --> Input Class Initialized
DEBUG - 2010-06-19 09:47:31 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:47:31 --> Language Class Initialized
DEBUG - 2010-06-19 09:47:31 --> Loader Class Initialized
DEBUG - 2010-06-19 09:47:31 --> Controller Class Initialized
DEBUG - 2010-06-19 09:47:31 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 09:47:31 --> Database Driver Class Initialized
DEBUG - 2010-06-19 09:47:31 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 09:47:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 09:48:26 --> Config Class Initialized
DEBUG - 2010-06-19 09:48:26 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:48:26 --> URI Class Initialized
DEBUG - 2010-06-19 09:48:26 --> Router Class Initialized
DEBUG - 2010-06-19 09:48:26 --> Output Class Initialized
DEBUG - 2010-06-19 09:48:26 --> Input Class Initialized
DEBUG - 2010-06-19 09:48:26 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:48:26 --> Language Class Initialized
DEBUG - 2010-06-19 09:48:26 --> Loader Class Initialized
DEBUG - 2010-06-19 09:48:26 --> Controller Class Initialized
DEBUG - 2010-06-19 09:48:26 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 09:48:26 --> Database Driver Class Initialized
DEBUG - 2010-06-19 09:48:26 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 09:48:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 09:49:23 --> Config Class Initialized
DEBUG - 2010-06-19 09:49:23 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:49:23 --> URI Class Initialized
DEBUG - 2010-06-19 09:49:23 --> Router Class Initialized
DEBUG - 2010-06-19 09:49:23 --> Output Class Initialized
DEBUG - 2010-06-19 09:49:23 --> Input Class Initialized
DEBUG - 2010-06-19 09:49:23 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:49:23 --> Language Class Initialized
DEBUG - 2010-06-19 09:49:23 --> Loader Class Initialized
DEBUG - 2010-06-19 09:49:23 --> Controller Class Initialized
DEBUG - 2010-06-19 09:49:23 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 09:49:23 --> Database Driver Class Initialized
DEBUG - 2010-06-19 09:49:23 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 09:49:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 09:49:29 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-19 09:49:29 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 09:49:29 --> Final output sent to browser
DEBUG - 2010-06-19 09:49:29 --> Total execution time: 6.3183
DEBUG - 2010-06-19 09:52:22 --> Config Class Initialized
DEBUG - 2010-06-19 09:52:22 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:52:22 --> URI Class Initialized
DEBUG - 2010-06-19 09:52:22 --> Router Class Initialized
DEBUG - 2010-06-19 09:52:22 --> Output Class Initialized
DEBUG - 2010-06-19 09:52:22 --> Input Class Initialized
DEBUG - 2010-06-19 09:52:22 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:52:22 --> Language Class Initialized
DEBUG - 2010-06-19 09:52:22 --> Loader Class Initialized
DEBUG - 2010-06-19 09:52:22 --> Controller Class Initialized
DEBUG - 2010-06-19 09:52:22 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 09:52:22 --> Database Driver Class Initialized
DEBUG - 2010-06-19 09:52:22 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 09:52:22 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-19 09:52:23 --> Severity: Notice  --> Undefined variable: db D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 77
DEBUG - 2010-06-19 09:53:08 --> Config Class Initialized
DEBUG - 2010-06-19 09:53:08 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:53:08 --> URI Class Initialized
DEBUG - 2010-06-19 09:53:08 --> Router Class Initialized
DEBUG - 2010-06-19 09:53:08 --> Output Class Initialized
DEBUG - 2010-06-19 09:53:08 --> Input Class Initialized
DEBUG - 2010-06-19 09:53:08 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:53:08 --> Language Class Initialized
DEBUG - 2010-06-19 09:53:08 --> Loader Class Initialized
DEBUG - 2010-06-19 09:53:08 --> Controller Class Initialized
DEBUG - 2010-06-19 09:53:08 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 09:53:09 --> Database Driver Class Initialized
DEBUG - 2010-06-19 09:53:09 --> Helper loaded: kals_helper
ERROR - 2010-06-19 09:53:09 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;domain_id&quot; does not exist
LINE 1: SELECT &quot;domain_id&quot;, &quot;host&quot;, &quot;title&quot;
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-19 09:53:09 --> DB Transaction Failure
ERROR - 2010-06-19 09:53:09 --> Query error: ERROR:  column "domain_id" does not exist
LINE 1: SELECT "domain_id", "host", "title"
               ^
DEBUG - 2010-06-19 09:53:09 --> Language file loaded: language/english/db_lang.php
DEBUG - 2010-06-19 09:54:21 --> Config Class Initialized
DEBUG - 2010-06-19 09:54:22 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:54:22 --> URI Class Initialized
DEBUG - 2010-06-19 09:54:22 --> Router Class Initialized
DEBUG - 2010-06-19 09:54:22 --> Output Class Initialized
DEBUG - 2010-06-19 09:54:22 --> Input Class Initialized
DEBUG - 2010-06-19 09:54:22 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:54:22 --> Language Class Initialized
DEBUG - 2010-06-19 09:54:22 --> Loader Class Initialized
DEBUG - 2010-06-19 09:54:22 --> Controller Class Initialized
DEBUG - 2010-06-19 09:54:22 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 09:54:22 --> Database Driver Class Initialized
DEBUG - 2010-06-19 09:54:22 --> Helper loaded: kals_helper
ERROR - 2010-06-19 09:54:22 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;domain_id&quot; does not exist
LINE 1: SELECT &quot;domain_id&quot;, &quot;host&quot;, &quot;title&quot;
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-19 09:54:22 --> DB Transaction Failure
ERROR - 2010-06-19 09:54:22 --> Query error: ERROR:  column "domain_id" does not exist
LINE 1: SELECT "domain_id", "host", "title"
               ^
DEBUG - 2010-06-19 09:54:22 --> Language file loaded: language/english/db_lang.php
DEBUG - 2010-06-19 09:55:08 --> Config Class Initialized
DEBUG - 2010-06-19 09:55:08 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:55:08 --> URI Class Initialized
DEBUG - 2010-06-19 09:55:08 --> Router Class Initialized
DEBUG - 2010-06-19 09:55:08 --> Output Class Initialized
DEBUG - 2010-06-19 09:55:08 --> Input Class Initialized
DEBUG - 2010-06-19 09:55:08 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:55:08 --> Language Class Initialized
DEBUG - 2010-06-19 09:55:08 --> Loader Class Initialized
DEBUG - 2010-06-19 09:55:08 --> Controller Class Initialized
DEBUG - 2010-06-19 09:55:08 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 09:55:08 --> Database Driver Class Initialized
DEBUG - 2010-06-19 09:55:08 --> Helper loaded: kals_helper
ERROR - 2010-06-19 09:55:08 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;domain_id&quot; does not exist
LINE 1: SELECT &quot;domain_id&quot;, &quot;host&quot;, &quot;title&quot;
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-19 09:55:08 --> DB Transaction Failure
ERROR - 2010-06-19 09:55:08 --> Query error: ERROR:  column "domain_id" does not exist
LINE 1: SELECT "domain_id", "host", "title"
               ^
DEBUG - 2010-06-19 09:55:08 --> Language file loaded: language/english/db_lang.php
DEBUG - 2010-06-19 09:55:26 --> Config Class Initialized
DEBUG - 2010-06-19 09:55:26 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:55:26 --> URI Class Initialized
DEBUG - 2010-06-19 09:55:26 --> Router Class Initialized
DEBUG - 2010-06-19 09:55:26 --> Output Class Initialized
DEBUG - 2010-06-19 09:55:26 --> Input Class Initialized
DEBUG - 2010-06-19 09:55:26 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:55:26 --> Language Class Initialized
DEBUG - 2010-06-19 09:55:26 --> Loader Class Initialized
DEBUG - 2010-06-19 09:55:26 --> Controller Class Initialized
DEBUG - 2010-06-19 09:55:26 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 09:55:26 --> Database Driver Class Initialized
DEBUG - 2010-06-19 09:55:26 --> Helper loaded: kals_helper
ERROR - 2010-06-19 09:55:26 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;domain_id&quot; does not exist
LINE 1: SELECT &quot;domain_id&quot;, &quot;host&quot;, &quot;title&quot;
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-19 09:55:26 --> DB Transaction Failure
ERROR - 2010-06-19 09:55:26 --> Query error: ERROR:  column "domain_id" does not exist
LINE 1: SELECT "domain_id", "host", "title"
               ^
DEBUG - 2010-06-19 09:55:26 --> Language file loaded: language/english/db_lang.php
DEBUG - 2010-06-19 09:55:55 --> Config Class Initialized
DEBUG - 2010-06-19 09:55:55 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:55:55 --> URI Class Initialized
DEBUG - 2010-06-19 09:55:55 --> Router Class Initialized
DEBUG - 2010-06-19 09:55:55 --> Output Class Initialized
DEBUG - 2010-06-19 09:55:55 --> Input Class Initialized
DEBUG - 2010-06-19 09:55:55 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:55:55 --> Language Class Initialized
DEBUG - 2010-06-19 09:55:55 --> Loader Class Initialized
DEBUG - 2010-06-19 09:55:55 --> Controller Class Initialized
DEBUG - 2010-06-19 09:55:55 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 09:55:55 --> Database Driver Class Initialized
DEBUG - 2010-06-19 09:55:55 --> Helper loaded: kals_helper
ERROR - 2010-06-19 09:55:55 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;domain_id&quot; does not exist
LINE 1: SELECT &quot;domain_id&quot;, &quot;host&quot;, &quot;title&quot;
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-19 09:55:55 --> DB Transaction Failure
ERROR - 2010-06-19 09:55:55 --> Query error: ERROR:  column "domain_id" does not exist
LINE 1: SELECT "domain_id", "host", "title"
               ^
DEBUG - 2010-06-19 09:55:55 --> Language file loaded: language/english/db_lang.php
DEBUG - 2010-06-19 09:56:16 --> Config Class Initialized
DEBUG - 2010-06-19 09:56:16 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:56:16 --> URI Class Initialized
DEBUG - 2010-06-19 09:56:16 --> Router Class Initialized
DEBUG - 2010-06-19 09:56:16 --> Output Class Initialized
DEBUG - 2010-06-19 09:56:16 --> Input Class Initialized
DEBUG - 2010-06-19 09:56:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:56:17 --> Language Class Initialized
DEBUG - 2010-06-19 09:56:17 --> Loader Class Initialized
DEBUG - 2010-06-19 09:56:17 --> Controller Class Initialized
DEBUG - 2010-06-19 09:56:17 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 09:56:17 --> Database Driver Class Initialized
DEBUG - 2010-06-19 09:56:17 --> Helper loaded: kals_helper
ERROR - 2010-06-19 09:56:17 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;domain_id&quot; does not exist
LINE 1: SELECT &quot;domain_id&quot;, &quot;host&quot;, &quot;title&quot;
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-19 09:56:17 --> DB Transaction Failure
ERROR - 2010-06-19 09:56:17 --> Query error: ERROR:  column "domain_id" does not exist
LINE 1: SELECT "domain_id", "host", "title"
               ^
DEBUG - 2010-06-19 09:56:17 --> Language file loaded: language/english/db_lang.php
DEBUG - 2010-06-19 09:56:23 --> Config Class Initialized
DEBUG - 2010-06-19 09:56:23 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:56:23 --> URI Class Initialized
DEBUG - 2010-06-19 09:56:23 --> Router Class Initialized
DEBUG - 2010-06-19 09:56:23 --> Output Class Initialized
DEBUG - 2010-06-19 09:56:23 --> Input Class Initialized
DEBUG - 2010-06-19 09:56:23 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:56:23 --> Language Class Initialized
DEBUG - 2010-06-19 09:56:23 --> Loader Class Initialized
DEBUG - 2010-06-19 09:56:23 --> Controller Class Initialized
DEBUG - 2010-06-19 09:56:23 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 09:56:23 --> Database Driver Class Initialized
DEBUG - 2010-06-19 09:56:23 --> Helper loaded: kals_helper
ERROR - 2010-06-19 09:56:23 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;domain_id&quot; does not exist
LINE 1: SELECT &quot;domain_id&quot;, &quot;host&quot;, &quot;title&quot;
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-19 09:56:23 --> DB Transaction Failure
ERROR - 2010-06-19 09:56:23 --> Query error: ERROR:  column "domain_id" does not exist
LINE 1: SELECT "domain_id", "host", "title"
               ^
DEBUG - 2010-06-19 09:56:23 --> Language file loaded: language/english/db_lang.php
ERROR - 2010-06-19 09:56:23 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php:28) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-19 09:56:53 --> Config Class Initialized
DEBUG - 2010-06-19 09:56:53 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:56:53 --> URI Class Initialized
DEBUG - 2010-06-19 09:56:53 --> Router Class Initialized
DEBUG - 2010-06-19 09:56:53 --> Output Class Initialized
DEBUG - 2010-06-19 09:56:53 --> Input Class Initialized
DEBUG - 2010-06-19 09:56:53 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:56:53 --> Language Class Initialized
DEBUG - 2010-06-19 09:56:53 --> Loader Class Initialized
DEBUG - 2010-06-19 09:56:53 --> Controller Class Initialized
DEBUG - 2010-06-19 09:56:54 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 09:56:54 --> Database Driver Class Initialized
DEBUG - 2010-06-19 09:56:54 --> Helper loaded: kals_helper
ERROR - 2010-06-19 09:56:54 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;domain_id&quot; does not exist
LINE 1: SELECT &quot;domain_id&quot;, &quot;host&quot;, &quot;title&quot;
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-19 09:56:54 --> DB Transaction Failure
ERROR - 2010-06-19 09:56:54 --> Query error: ERROR:  column "domain_id" does not exist
LINE 1: SELECT "domain_id", "host", "title"
               ^
DEBUG - 2010-06-19 09:56:54 --> Language file loaded: language/english/db_lang.php
ERROR - 2010-06-19 09:56:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php:66) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-19 09:57:01 --> Config Class Initialized
DEBUG - 2010-06-19 09:57:01 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:57:01 --> URI Class Initialized
DEBUG - 2010-06-19 09:57:01 --> Router Class Initialized
DEBUG - 2010-06-19 09:57:01 --> Output Class Initialized
DEBUG - 2010-06-19 09:57:01 --> Input Class Initialized
DEBUG - 2010-06-19 09:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:57:01 --> Language Class Initialized
DEBUG - 2010-06-19 09:57:01 --> Loader Class Initialized
DEBUG - 2010-06-19 09:57:01 --> Controller Class Initialized
DEBUG - 2010-06-19 09:57:01 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 09:57:01 --> Database Driver Class Initialized
DEBUG - 2010-06-19 09:57:01 --> Helper loaded: kals_helper
ERROR - 2010-06-19 09:57:01 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;domain_id&quot; does not exist
LINE 1: SELECT &quot;domain_id&quot;, &quot;host&quot;, &quot;title&quot;
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-19 09:57:01 --> DB Transaction Failure
ERROR - 2010-06-19 09:57:01 --> Query error: ERROR:  column "domain_id" does not exist
LINE 1: SELECT "domain_id", "host", "title"
               ^
DEBUG - 2010-06-19 09:57:01 --> Language file loaded: language/english/db_lang.php
ERROR - 2010-06-19 09:57:01 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php:68) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-19 09:59:17 --> Config Class Initialized
DEBUG - 2010-06-19 09:59:17 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:59:17 --> URI Class Initialized
DEBUG - 2010-06-19 09:59:17 --> Router Class Initialized
DEBUG - 2010-06-19 09:59:17 --> Output Class Initialized
DEBUG - 2010-06-19 09:59:17 --> Input Class Initialized
DEBUG - 2010-06-19 09:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:59:17 --> Language Class Initialized
DEBUG - 2010-06-19 09:59:17 --> Loader Class Initialized
DEBUG - 2010-06-19 09:59:17 --> Controller Class Initialized
DEBUG - 2010-06-19 09:59:17 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 09:59:17 --> Database Driver Class Initialized
DEBUG - 2010-06-19 09:59:17 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 09:59:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 09:59:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 09:59:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 09:59:17 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-19 09:59:17 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 09:59:17 --> Final output sent to browser
DEBUG - 2010-06-19 09:59:17 --> Total execution time: 0.7810
DEBUG - 2010-06-19 09:59:28 --> Config Class Initialized
DEBUG - 2010-06-19 09:59:28 --> Hooks Class Initialized
DEBUG - 2010-06-19 09:59:28 --> URI Class Initialized
DEBUG - 2010-06-19 09:59:28 --> Router Class Initialized
DEBUG - 2010-06-19 09:59:28 --> Output Class Initialized
DEBUG - 2010-06-19 09:59:28 --> Input Class Initialized
DEBUG - 2010-06-19 09:59:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 09:59:29 --> Language Class Initialized
DEBUG - 2010-06-19 09:59:29 --> Loader Class Initialized
DEBUG - 2010-06-19 09:59:29 --> Controller Class Initialized
DEBUG - 2010-06-19 09:59:29 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 09:59:29 --> Database Driver Class Initialized
DEBUG - 2010-06-19 09:59:29 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 09:59:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 09:59:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 09:59:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 09:59:29 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-19 09:59:29 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 09:59:29 --> Final output sent to browser
DEBUG - 2010-06-19 09:59:29 --> Total execution time: 0.9802
DEBUG - 2010-06-19 10:01:49 --> Config Class Initialized
DEBUG - 2010-06-19 10:01:49 --> Hooks Class Initialized
DEBUG - 2010-06-19 10:01:49 --> URI Class Initialized
DEBUG - 2010-06-19 10:01:49 --> Router Class Initialized
DEBUG - 2010-06-19 10:01:49 --> Output Class Initialized
DEBUG - 2010-06-19 10:01:49 --> Input Class Initialized
DEBUG - 2010-06-19 10:01:49 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 10:01:49 --> Language Class Initialized
DEBUG - 2010-06-19 10:01:49 --> Loader Class Initialized
DEBUG - 2010-06-19 10:01:49 --> Controller Class Initialized
DEBUG - 2010-06-19 10:01:49 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 10:01:50 --> Database Driver Class Initialized
DEBUG - 2010-06-19 10:01:50 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 10:01:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 10:01:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 10:01:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 10:01:50 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-19 10:01:50 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 10:01:50 --> Final output sent to browser
DEBUG - 2010-06-19 10:01:50 --> Total execution time: 0.9668
DEBUG - 2010-06-19 10:02:38 --> Config Class Initialized
DEBUG - 2010-06-19 10:02:39 --> Hooks Class Initialized
DEBUG - 2010-06-19 10:02:39 --> URI Class Initialized
DEBUG - 2010-06-19 10:02:39 --> Router Class Initialized
DEBUG - 2010-06-19 10:02:39 --> Output Class Initialized
DEBUG - 2010-06-19 10:02:39 --> Input Class Initialized
DEBUG - 2010-06-19 10:02:39 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 10:02:39 --> Language Class Initialized
DEBUG - 2010-06-19 10:02:39 --> Loader Class Initialized
DEBUG - 2010-06-19 10:02:39 --> Controller Class Initialized
DEBUG - 2010-06-19 10:02:39 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 10:02:39 --> Database Driver Class Initialized
DEBUG - 2010-06-19 10:02:39 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 10:02:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 10:02:39 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-19 10:02:39 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 10:02:39 --> Final output sent to browser
DEBUG - 2010-06-19 10:02:39 --> Total execution time: 0.3120
DEBUG - 2010-06-19 10:02:54 --> Config Class Initialized
DEBUG - 2010-06-19 10:02:54 --> Hooks Class Initialized
DEBUG - 2010-06-19 10:02:54 --> URI Class Initialized
DEBUG - 2010-06-19 10:02:54 --> Router Class Initialized
DEBUG - 2010-06-19 10:02:54 --> Output Class Initialized
DEBUG - 2010-06-19 10:02:54 --> Input Class Initialized
DEBUG - 2010-06-19 10:02:54 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 10:02:54 --> Language Class Initialized
DEBUG - 2010-06-19 10:02:55 --> Loader Class Initialized
DEBUG - 2010-06-19 10:02:55 --> Controller Class Initialized
DEBUG - 2010-06-19 10:02:55 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 10:02:55 --> Database Driver Class Initialized
DEBUG - 2010-06-19 10:02:55 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 10:02:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 10:02:55 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-19 10:02:55 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 10:02:55 --> Final output sent to browser
DEBUG - 2010-06-19 10:02:55 --> Total execution time: 0.3182
DEBUG - 2010-06-19 10:06:13 --> Config Class Initialized
DEBUG - 2010-06-19 10:06:13 --> Hooks Class Initialized
DEBUG - 2010-06-19 10:06:13 --> URI Class Initialized
DEBUG - 2010-06-19 10:06:13 --> Router Class Initialized
DEBUG - 2010-06-19 10:06:13 --> Output Class Initialized
DEBUG - 2010-06-19 10:06:13 --> Input Class Initialized
DEBUG - 2010-06-19 10:06:13 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 10:06:13 --> Language Class Initialized
DEBUG - 2010-06-19 10:06:13 --> Loader Class Initialized
DEBUG - 2010-06-19 10:06:13 --> Controller Class Initialized
DEBUG - 2010-06-19 10:06:13 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 10:06:13 --> Database Driver Class Initialized
DEBUG - 2010-06-19 10:06:14 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 10:06:14 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-19 10:06:14 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 112
DEBUG - 2010-06-19 10:06:14 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-19 10:06:14 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 10:06:14 --> Final output sent to browser
DEBUG - 2010-06-19 10:06:14 --> Total execution time: 0.3437
DEBUG - 2010-06-19 10:06:38 --> Config Class Initialized
DEBUG - 2010-06-19 10:06:38 --> Hooks Class Initialized
DEBUG - 2010-06-19 10:06:38 --> URI Class Initialized
DEBUG - 2010-06-19 10:06:38 --> Router Class Initialized
DEBUG - 2010-06-19 10:06:38 --> Output Class Initialized
DEBUG - 2010-06-19 10:06:38 --> Input Class Initialized
DEBUG - 2010-06-19 10:06:38 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 10:06:38 --> Language Class Initialized
DEBUG - 2010-06-19 10:06:38 --> Loader Class Initialized
DEBUG - 2010-06-19 10:06:38 --> Controller Class Initialized
DEBUG - 2010-06-19 10:06:38 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 10:06:38 --> Database Driver Class Initialized
DEBUG - 2010-06-19 10:06:38 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 10:06:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 10:06:39 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-19 10:06:39 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 10:06:39 --> Final output sent to browser
DEBUG - 2010-06-19 10:06:39 --> Total execution time: 0.3259
DEBUG - 2010-06-19 10:07:52 --> Config Class Initialized
DEBUG - 2010-06-19 10:07:52 --> Hooks Class Initialized
DEBUG - 2010-06-19 10:07:52 --> URI Class Initialized
DEBUG - 2010-06-19 10:07:52 --> Router Class Initialized
DEBUG - 2010-06-19 10:07:52 --> Output Class Initialized
DEBUG - 2010-06-19 10:07:52 --> Input Class Initialized
DEBUG - 2010-06-19 10:07:52 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 10:07:52 --> Language Class Initialized
DEBUG - 2010-06-19 10:07:52 --> Loader Class Initialized
DEBUG - 2010-06-19 10:07:52 --> Controller Class Initialized
DEBUG - 2010-06-19 10:07:52 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 10:07:52 --> Database Driver Class Initialized
DEBUG - 2010-06-19 10:07:52 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 10:07:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 10:07:52 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-19 10:07:52 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 10:07:52 --> Final output sent to browser
DEBUG - 2010-06-19 10:07:52 --> Total execution time: 0.3827
DEBUG - 2010-06-19 10:08:15 --> Config Class Initialized
DEBUG - 2010-06-19 10:08:15 --> Hooks Class Initialized
DEBUG - 2010-06-19 10:08:15 --> URI Class Initialized
DEBUG - 2010-06-19 10:08:15 --> Router Class Initialized
DEBUG - 2010-06-19 10:08:15 --> Output Class Initialized
DEBUG - 2010-06-19 10:08:15 --> Input Class Initialized
DEBUG - 2010-06-19 10:08:15 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 10:08:15 --> Language Class Initialized
DEBUG - 2010-06-19 10:08:15 --> Loader Class Initialized
DEBUG - 2010-06-19 10:08:15 --> Controller Class Initialized
DEBUG - 2010-06-19 10:08:15 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 10:08:15 --> Database Driver Class Initialized
DEBUG - 2010-06-19 10:08:15 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 10:08:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 10:08:16 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-19 10:08:16 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 10:08:16 --> Final output sent to browser
DEBUG - 2010-06-19 10:08:16 --> Total execution time: 0.4311
DEBUG - 2010-06-19 10:09:34 --> Config Class Initialized
DEBUG - 2010-06-19 10:09:34 --> Hooks Class Initialized
DEBUG - 2010-06-19 10:09:34 --> URI Class Initialized
DEBUG - 2010-06-19 10:09:34 --> Router Class Initialized
DEBUG - 2010-06-19 10:09:34 --> Output Class Initialized
DEBUG - 2010-06-19 10:09:34 --> Input Class Initialized
DEBUG - 2010-06-19 10:09:34 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 10:09:34 --> Language Class Initialized
DEBUG - 2010-06-19 10:09:34 --> Loader Class Initialized
DEBUG - 2010-06-19 10:09:34 --> Controller Class Initialized
DEBUG - 2010-06-19 10:09:34 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 10:09:34 --> Database Driver Class Initialized
DEBUG - 2010-06-19 10:09:34 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 10:09:34 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-19 10:09:34 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 115
DEBUG - 2010-06-19 10:09:34 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-19 10:09:34 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 10:09:35 --> Final output sent to browser
DEBUG - 2010-06-19 10:09:35 --> Total execution time: 0.4234
DEBUG - 2010-06-19 10:09:51 --> Config Class Initialized
DEBUG - 2010-06-19 10:09:51 --> Hooks Class Initialized
DEBUG - 2010-06-19 10:09:51 --> URI Class Initialized
DEBUG - 2010-06-19 10:09:51 --> Router Class Initialized
DEBUG - 2010-06-19 10:09:51 --> Output Class Initialized
DEBUG - 2010-06-19 10:09:51 --> Input Class Initialized
DEBUG - 2010-06-19 10:09:51 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 10:09:51 --> Language Class Initialized
DEBUG - 2010-06-19 10:09:51 --> Loader Class Initialized
DEBUG - 2010-06-19 10:09:51 --> Controller Class Initialized
DEBUG - 2010-06-19 10:09:51 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 10:09:51 --> Database Driver Class Initialized
DEBUG - 2010-06-19 10:09:51 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 10:09:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 10:09:51 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-19 10:09:51 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 10:09:51 --> Final output sent to browser
DEBUG - 2010-06-19 10:09:51 --> Total execution time: 0.4268
DEBUG - 2010-06-19 10:10:06 --> Config Class Initialized
DEBUG - 2010-06-19 10:10:06 --> Hooks Class Initialized
DEBUG - 2010-06-19 10:10:06 --> URI Class Initialized
DEBUG - 2010-06-19 10:10:06 --> Router Class Initialized
DEBUG - 2010-06-19 10:10:06 --> Output Class Initialized
DEBUG - 2010-06-19 10:10:06 --> Input Class Initialized
DEBUG - 2010-06-19 10:10:06 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 10:10:06 --> Language Class Initialized
DEBUG - 2010-06-19 10:10:06 --> Loader Class Initialized
DEBUG - 2010-06-19 10:10:06 --> Controller Class Initialized
DEBUG - 2010-06-19 10:10:06 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 10:10:06 --> Database Driver Class Initialized
DEBUG - 2010-06-19 10:10:06 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 10:10:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 10:10:06 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-19 10:10:06 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 10:10:06 --> Final output sent to browser
DEBUG - 2010-06-19 10:10:06 --> Total execution time: 0.4151
DEBUG - 2010-06-19 10:10:17 --> Config Class Initialized
DEBUG - 2010-06-19 10:10:17 --> Hooks Class Initialized
DEBUG - 2010-06-19 10:10:17 --> URI Class Initialized
DEBUG - 2010-06-19 10:10:17 --> Router Class Initialized
DEBUG - 2010-06-19 10:10:17 --> Output Class Initialized
DEBUG - 2010-06-19 10:10:17 --> Input Class Initialized
DEBUG - 2010-06-19 10:10:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 10:10:17 --> Language Class Initialized
DEBUG - 2010-06-19 10:10:17 --> Loader Class Initialized
DEBUG - 2010-06-19 10:10:17 --> Controller Class Initialized
DEBUG - 2010-06-19 10:10:17 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 10:10:17 --> Database Driver Class Initialized
DEBUG - 2010-06-19 10:10:17 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 10:10:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 10:10:17 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-19 10:10:17 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 10:10:17 --> Final output sent to browser
DEBUG - 2010-06-19 10:10:17 --> Total execution time: 0.4267
DEBUG - 2010-06-19 10:10:32 --> Config Class Initialized
DEBUG - 2010-06-19 10:10:32 --> Hooks Class Initialized
DEBUG - 2010-06-19 10:10:32 --> URI Class Initialized
DEBUG - 2010-06-19 10:10:32 --> Router Class Initialized
DEBUG - 2010-06-19 10:10:33 --> Output Class Initialized
DEBUG - 2010-06-19 10:10:33 --> Input Class Initialized
DEBUG - 2010-06-19 10:10:33 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 10:10:33 --> Language Class Initialized
DEBUG - 2010-06-19 10:10:33 --> Loader Class Initialized
DEBUG - 2010-06-19 10:10:33 --> Controller Class Initialized
DEBUG - 2010-06-19 10:10:33 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 10:10:33 --> Database Driver Class Initialized
DEBUG - 2010-06-19 10:10:33 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 10:10:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 10:10:33 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-19 10:10:33 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 10:10:33 --> Final output sent to browser
DEBUG - 2010-06-19 10:10:33 --> Total execution time: 0.4580
DEBUG - 2010-06-19 10:11:29 --> Config Class Initialized
DEBUG - 2010-06-19 10:11:29 --> Hooks Class Initialized
DEBUG - 2010-06-19 10:11:29 --> URI Class Initialized
DEBUG - 2010-06-19 10:11:29 --> Router Class Initialized
DEBUG - 2010-06-19 10:11:29 --> Output Class Initialized
DEBUG - 2010-06-19 10:11:29 --> Input Class Initialized
DEBUG - 2010-06-19 10:11:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 10:11:29 --> Language Class Initialized
DEBUG - 2010-06-19 10:11:29 --> Loader Class Initialized
DEBUG - 2010-06-19 10:11:29 --> Controller Class Initialized
DEBUG - 2010-06-19 10:11:29 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 10:11:29 --> Database Driver Class Initialized
DEBUG - 2010-06-19 10:11:29 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 10:11:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 10:11:29 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-19 10:11:30 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 10:11:30 --> Final output sent to browser
DEBUG - 2010-06-19 10:11:30 --> Total execution time: 0.4675
DEBUG - 2010-06-19 10:11:55 --> Config Class Initialized
DEBUG - 2010-06-19 10:11:55 --> Hooks Class Initialized
DEBUG - 2010-06-19 10:11:55 --> URI Class Initialized
DEBUG - 2010-06-19 10:11:55 --> Router Class Initialized
DEBUG - 2010-06-19 10:11:56 --> Output Class Initialized
DEBUG - 2010-06-19 10:11:56 --> Input Class Initialized
DEBUG - 2010-06-19 10:11:56 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 10:11:56 --> Language Class Initialized
DEBUG - 2010-06-19 10:11:56 --> Loader Class Initialized
DEBUG - 2010-06-19 10:11:56 --> Controller Class Initialized
DEBUG - 2010-06-19 10:11:56 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 10:11:56 --> Database Driver Class Initialized
DEBUG - 2010-06-19 10:11:56 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 10:11:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 10:11:56 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-19 10:11:56 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 10:11:56 --> Final output sent to browser
DEBUG - 2010-06-19 10:11:56 --> Total execution time: 0.4010
DEBUG - 2010-06-19 10:12:15 --> Config Class Initialized
DEBUG - 2010-06-19 10:12:15 --> Hooks Class Initialized
DEBUG - 2010-06-19 10:12:15 --> URI Class Initialized
DEBUG - 2010-06-19 10:12:15 --> Router Class Initialized
DEBUG - 2010-06-19 10:12:15 --> Output Class Initialized
DEBUG - 2010-06-19 10:12:15 --> Input Class Initialized
DEBUG - 2010-06-19 10:12:15 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 10:12:15 --> Language Class Initialized
DEBUG - 2010-06-19 10:12:15 --> Loader Class Initialized
DEBUG - 2010-06-19 10:12:15 --> Controller Class Initialized
DEBUG - 2010-06-19 10:12:15 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 10:12:15 --> Database Driver Class Initialized
DEBUG - 2010-06-19 10:12:15 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 10:12:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 10:12:15 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-19 10:12:15 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 10:12:15 --> Final output sent to browser
DEBUG - 2010-06-19 10:12:15 --> Total execution time: 0.4304
DEBUG - 2010-06-19 10:12:34 --> Config Class Initialized
DEBUG - 2010-06-19 10:12:34 --> Hooks Class Initialized
DEBUG - 2010-06-19 10:12:34 --> URI Class Initialized
DEBUG - 2010-06-19 10:12:35 --> Router Class Initialized
DEBUG - 2010-06-19 10:12:35 --> Output Class Initialized
DEBUG - 2010-06-19 10:12:35 --> Input Class Initialized
DEBUG - 2010-06-19 10:12:35 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 10:12:35 --> Language Class Initialized
DEBUG - 2010-06-19 10:12:35 --> Loader Class Initialized
DEBUG - 2010-06-19 10:12:35 --> Controller Class Initialized
DEBUG - 2010-06-19 10:12:35 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 10:12:35 --> Database Driver Class Initialized
DEBUG - 2010-06-19 10:12:35 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 10:12:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 10:12:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 10:12:35 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-19 10:12:35 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 10:12:35 --> Final output sent to browser
DEBUG - 2010-06-19 10:12:35 --> Total execution time: 0.4187
DEBUG - 2010-06-19 10:12:48 --> Config Class Initialized
DEBUG - 2010-06-19 10:12:48 --> Hooks Class Initialized
DEBUG - 2010-06-19 10:12:48 --> URI Class Initialized
DEBUG - 2010-06-19 10:12:48 --> Router Class Initialized
DEBUG - 2010-06-19 10:12:48 --> Output Class Initialized
DEBUG - 2010-06-19 10:12:48 --> Input Class Initialized
DEBUG - 2010-06-19 10:12:48 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 10:12:48 --> Language Class Initialized
DEBUG - 2010-06-19 10:12:48 --> Loader Class Initialized
DEBUG - 2010-06-19 10:12:48 --> Controller Class Initialized
DEBUG - 2010-06-19 10:12:48 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 10:12:48 --> Database Driver Class Initialized
DEBUG - 2010-06-19 10:12:48 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 10:12:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 10:12:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 10:12:49 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-19 10:12:49 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 10:12:49 --> Final output sent to browser
DEBUG - 2010-06-19 10:12:49 --> Total execution time: 1.0506
DEBUG - 2010-06-19 10:12:54 --> Config Class Initialized
DEBUG - 2010-06-19 10:12:54 --> Hooks Class Initialized
DEBUG - 2010-06-19 10:12:54 --> URI Class Initialized
DEBUG - 2010-06-19 10:12:54 --> Router Class Initialized
DEBUG - 2010-06-19 10:12:54 --> Output Class Initialized
DEBUG - 2010-06-19 10:12:54 --> Input Class Initialized
DEBUG - 2010-06-19 10:12:54 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 10:12:54 --> Language Class Initialized
DEBUG - 2010-06-19 10:12:54 --> Loader Class Initialized
DEBUG - 2010-06-19 10:12:54 --> Controller Class Initialized
DEBUG - 2010-06-19 10:12:54 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 10:12:54 --> Database Driver Class Initialized
DEBUG - 2010-06-19 10:12:54 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 10:12:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 10:12:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 10:12:54 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-19 10:12:54 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 10:12:54 --> Final output sent to browser
DEBUG - 2010-06-19 10:12:54 --> Total execution time: 0.4309
DEBUG - 2010-06-19 10:23:28 --> Config Class Initialized
DEBUG - 2010-06-19 10:23:28 --> Hooks Class Initialized
DEBUG - 2010-06-19 10:23:28 --> URI Class Initialized
DEBUG - 2010-06-19 10:23:28 --> Router Class Initialized
DEBUG - 2010-06-19 10:23:28 --> Output Class Initialized
DEBUG - 2010-06-19 10:23:28 --> Input Class Initialized
DEBUG - 2010-06-19 10:23:28 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 10:23:28 --> Language Class Initialized
DEBUG - 2010-06-19 10:23:28 --> Loader Class Initialized
DEBUG - 2010-06-19 10:23:28 --> Controller Class Initialized
DEBUG - 2010-06-19 10:23:28 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 10:23:28 --> Database Driver Class Initialized
DEBUG - 2010-06-19 10:23:28 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 10:23:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 10:23:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 10:23:29 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-19 10:23:29 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 10:23:29 --> Final output sent to browser
DEBUG - 2010-06-19 10:23:29 --> Total execution time: 0.4498
DEBUG - 2010-06-19 14:10:08 --> Config Class Initialized
DEBUG - 2010-06-19 14:10:08 --> Hooks Class Initialized
DEBUG - 2010-06-19 14:10:08 --> URI Class Initialized
DEBUG - 2010-06-19 14:10:08 --> Router Class Initialized
DEBUG - 2010-06-19 14:10:08 --> Output Class Initialized
DEBUG - 2010-06-19 14:10:08 --> Input Class Initialized
DEBUG - 2010-06-19 14:10:08 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 14:10:08 --> Language Class Initialized
DEBUG - 2010-06-19 14:10:08 --> Loader Class Initialized
DEBUG - 2010-06-19 14:10:08 --> Controller Class Initialized
DEBUG - 2010-06-19 14:10:08 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 14:10:08 --> Session Class Initialized
DEBUG - 2010-06-19 14:10:08 --> Helper loaded: string_helper
DEBUG - 2010-06-19 14:10:08 --> A session cookie was not found.
DEBUG - 2010-06-19 14:10:08 --> Session routines successfully run
DEBUG - 2010-06-19 14:10:08 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 14:10:08 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:10:08 --> Database Driver Class Initialized
DEBUG - 2010-06-19 14:10:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:10:09 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-19 14:10:09 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 14:10:09 --> Final output sent to browser
DEBUG - 2010-06-19 14:10:09 --> Total execution time: 1.0659
DEBUG - 2010-06-19 14:11:25 --> Config Class Initialized
DEBUG - 2010-06-19 14:11:25 --> Hooks Class Initialized
DEBUG - 2010-06-19 14:11:25 --> URI Class Initialized
DEBUG - 2010-06-19 14:11:25 --> Router Class Initialized
DEBUG - 2010-06-19 14:11:25 --> Output Class Initialized
DEBUG - 2010-06-19 14:11:25 --> Input Class Initialized
DEBUG - 2010-06-19 14:11:25 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 14:11:26 --> Language Class Initialized
DEBUG - 2010-06-19 14:11:26 --> Loader Class Initialized
DEBUG - 2010-06-19 14:11:26 --> Controller Class Initialized
DEBUG - 2010-06-19 14:11:26 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 14:11:26 --> Session Class Initialized
DEBUG - 2010-06-19 14:11:26 --> Helper loaded: string_helper
DEBUG - 2010-06-19 14:11:26 --> Session routines successfully run
DEBUG - 2010-06-19 14:11:26 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 14:11:26 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:11:26 --> Database Driver Class Initialized
DEBUG - 2010-06-19 14:11:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:11:26 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-19 14:11:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:11:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:11:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:11:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:11:26 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 14:11:26 --> Final output sent to browser
DEBUG - 2010-06-19 14:11:26 --> Total execution time: 0.6553
DEBUG - 2010-06-19 14:17:39 --> Config Class Initialized
DEBUG - 2010-06-19 14:17:39 --> Hooks Class Initialized
DEBUG - 2010-06-19 14:17:39 --> URI Class Initialized
DEBUG - 2010-06-19 14:17:39 --> Router Class Initialized
DEBUG - 2010-06-19 14:17:39 --> Output Class Initialized
DEBUG - 2010-06-19 14:17:39 --> Input Class Initialized
DEBUG - 2010-06-19 14:17:39 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 14:17:39 --> Language Class Initialized
DEBUG - 2010-06-19 14:17:39 --> Loader Class Initialized
DEBUG - 2010-06-19 14:17:39 --> Controller Class Initialized
DEBUG - 2010-06-19 14:17:39 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 14:17:39 --> Session Class Initialized
DEBUG - 2010-06-19 14:17:39 --> Helper loaded: string_helper
DEBUG - 2010-06-19 14:17:40 --> Session routines successfully run
DEBUG - 2010-06-19 14:17:40 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 14:17:40 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:17:40 --> Database Driver Class Initialized
DEBUG - 2010-06-19 14:17:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:17:40 --> Language file loaded: language/english/unit_test_lang.php
ERROR - 2010-06-19 14:17:40 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-19 14:17:40 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-19 14:17:40 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-19 14:17:40 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-19 14:17:40 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-19 14:17:40 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-19 14:17:40 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-19 14:17:40 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
DEBUG - 2010-06-19 14:17:40 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 14:17:40 --> Final output sent to browser
DEBUG - 2010-06-19 14:17:40 --> Total execution time: 0.7977
DEBUG - 2010-06-19 14:18:14 --> Config Class Initialized
DEBUG - 2010-06-19 14:18:14 --> Hooks Class Initialized
DEBUG - 2010-06-19 14:18:14 --> URI Class Initialized
DEBUG - 2010-06-19 14:18:14 --> Router Class Initialized
DEBUG - 2010-06-19 14:18:14 --> Output Class Initialized
DEBUG - 2010-06-19 14:18:14 --> Input Class Initialized
DEBUG - 2010-06-19 14:18:14 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 14:18:14 --> Language Class Initialized
DEBUG - 2010-06-19 14:18:14 --> Loader Class Initialized
DEBUG - 2010-06-19 14:18:14 --> Controller Class Initialized
DEBUG - 2010-06-19 14:18:14 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 14:18:14 --> Session Class Initialized
DEBUG - 2010-06-19 14:18:14 --> Helper loaded: string_helper
DEBUG - 2010-06-19 14:18:14 --> Session routines successfully run
DEBUG - 2010-06-19 14:18:14 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 14:18:15 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:18:15 --> Database Driver Class Initialized
DEBUG - 2010-06-19 14:18:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:18:15 --> Language file loaded: language/english/unit_test_lang.php
ERROR - 2010-06-19 14:18:15 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-19 14:18:15 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-19 14:18:15 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-19 14:18:15 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-19 14:18:15 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-19 14:18:15 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-19 14:18:15 --> Severity: Notice  --> Undefined index:  scheme D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
ERROR - 2010-06-19 14:18:15 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 40
DEBUG - 2010-06-19 14:18:15 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 14:18:15 --> Final output sent to browser
DEBUG - 2010-06-19 14:18:15 --> Total execution time: 0.7726
DEBUG - 2010-06-19 14:19:24 --> Config Class Initialized
DEBUG - 2010-06-19 14:19:24 --> Hooks Class Initialized
DEBUG - 2010-06-19 14:19:24 --> URI Class Initialized
DEBUG - 2010-06-19 14:19:24 --> Router Class Initialized
DEBUG - 2010-06-19 14:19:24 --> Output Class Initialized
DEBUG - 2010-06-19 14:19:24 --> Input Class Initialized
DEBUG - 2010-06-19 14:19:24 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 14:19:24 --> Language Class Initialized
DEBUG - 2010-06-19 14:19:24 --> Loader Class Initialized
DEBUG - 2010-06-19 14:19:24 --> Controller Class Initialized
DEBUG - 2010-06-19 14:19:24 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 14:19:24 --> Session Class Initialized
DEBUG - 2010-06-19 14:19:25 --> Helper loaded: string_helper
DEBUG - 2010-06-19 14:19:25 --> Session routines successfully run
DEBUG - 2010-06-19 14:19:25 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 14:20:19 --> Config Class Initialized
DEBUG - 2010-06-19 14:20:19 --> Hooks Class Initialized
DEBUG - 2010-06-19 14:20:19 --> URI Class Initialized
DEBUG - 2010-06-19 14:20:19 --> Router Class Initialized
DEBUG - 2010-06-19 14:20:19 --> Output Class Initialized
DEBUG - 2010-06-19 14:20:19 --> Input Class Initialized
DEBUG - 2010-06-19 14:20:19 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 14:20:19 --> Language Class Initialized
DEBUG - 2010-06-19 14:20:19 --> Loader Class Initialized
DEBUG - 2010-06-19 14:20:19 --> Controller Class Initialized
DEBUG - 2010-06-19 14:20:19 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 14:20:19 --> Session Class Initialized
DEBUG - 2010-06-19 14:20:19 --> Helper loaded: string_helper
DEBUG - 2010-06-19 14:20:19 --> Session routines successfully run
DEBUG - 2010-06-19 14:20:19 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 14:20:19 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:20:19 --> Database Driver Class Initialized
DEBUG - 2010-06-19 14:20:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:20:19 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-19 14:20:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:20:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:20:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:20:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:20:19 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 14:20:19 --> Final output sent to browser
DEBUG - 2010-06-19 14:20:19 --> Total execution time: 0.6247
DEBUG - 2010-06-19 14:22:31 --> Config Class Initialized
DEBUG - 2010-06-19 14:22:31 --> Hooks Class Initialized
DEBUG - 2010-06-19 14:22:31 --> URI Class Initialized
DEBUG - 2010-06-19 14:22:31 --> Router Class Initialized
DEBUG - 2010-06-19 14:22:31 --> Output Class Initialized
DEBUG - 2010-06-19 14:22:31 --> Input Class Initialized
DEBUG - 2010-06-19 14:22:31 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 14:22:31 --> Language Class Initialized
DEBUG - 2010-06-19 14:22:31 --> Loader Class Initialized
DEBUG - 2010-06-19 14:22:31 --> Controller Class Initialized
DEBUG - 2010-06-19 14:22:31 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 14:22:31 --> Session Class Initialized
DEBUG - 2010-06-19 14:22:31 --> Helper loaded: string_helper
DEBUG - 2010-06-19 14:22:32 --> Session routines successfully run
DEBUG - 2010-06-19 14:22:32 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 14:22:32 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:22:32 --> Database Driver Class Initialized
DEBUG - 2010-06-19 14:22:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:22:32 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-19 14:22:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:22:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:22:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:22:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:22:32 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 14:22:32 --> Final output sent to browser
DEBUG - 2010-06-19 14:22:32 --> Total execution time: 0.6650
DEBUG - 2010-06-19 14:23:20 --> Config Class Initialized
DEBUG - 2010-06-19 14:23:20 --> Hooks Class Initialized
DEBUG - 2010-06-19 14:23:20 --> URI Class Initialized
DEBUG - 2010-06-19 14:23:20 --> Router Class Initialized
DEBUG - 2010-06-19 14:23:20 --> Output Class Initialized
DEBUG - 2010-06-19 14:23:20 --> Input Class Initialized
DEBUG - 2010-06-19 14:23:20 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 14:23:20 --> Language Class Initialized
DEBUG - 2010-06-19 14:23:20 --> Loader Class Initialized
DEBUG - 2010-06-19 14:23:20 --> Controller Class Initialized
DEBUG - 2010-06-19 14:23:20 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 14:23:21 --> Session Class Initialized
DEBUG - 2010-06-19 14:23:21 --> Helper loaded: string_helper
DEBUG - 2010-06-19 14:23:21 --> Session routines successfully run
DEBUG - 2010-06-19 14:23:21 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 14:23:21 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:23:21 --> Database Driver Class Initialized
DEBUG - 2010-06-19 14:23:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:23:21 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-19 14:23:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:23:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:23:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:23:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:23:21 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 14:23:21 --> Final output sent to browser
DEBUG - 2010-06-19 14:23:21 --> Total execution time: 0.6467
DEBUG - 2010-06-19 14:24:02 --> Config Class Initialized
DEBUG - 2010-06-19 14:24:02 --> Hooks Class Initialized
DEBUG - 2010-06-19 14:24:02 --> URI Class Initialized
DEBUG - 2010-06-19 14:24:02 --> Router Class Initialized
DEBUG - 2010-06-19 14:24:02 --> Output Class Initialized
DEBUG - 2010-06-19 14:24:02 --> Input Class Initialized
DEBUG - 2010-06-19 14:24:02 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 14:24:02 --> Language Class Initialized
DEBUG - 2010-06-19 14:24:02 --> Loader Class Initialized
DEBUG - 2010-06-19 14:24:02 --> Controller Class Initialized
DEBUG - 2010-06-19 14:24:02 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 14:24:02 --> Session Class Initialized
DEBUG - 2010-06-19 14:24:02 --> Helper loaded: string_helper
DEBUG - 2010-06-19 14:24:02 --> Session routines successfully run
DEBUG - 2010-06-19 14:24:02 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 14:24:02 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:24:02 --> Database Driver Class Initialized
DEBUG - 2010-06-19 14:24:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:24:02 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-19 14:24:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:24:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:24:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:24:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:24:03 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 14:24:03 --> Final output sent to browser
DEBUG - 2010-06-19 14:24:03 --> Total execution time: 0.6441
DEBUG - 2010-06-19 14:25:34 --> Config Class Initialized
DEBUG - 2010-06-19 14:25:34 --> Hooks Class Initialized
DEBUG - 2010-06-19 14:25:34 --> URI Class Initialized
DEBUG - 2010-06-19 14:25:34 --> Router Class Initialized
DEBUG - 2010-06-19 14:25:34 --> Output Class Initialized
DEBUG - 2010-06-19 14:25:34 --> Input Class Initialized
DEBUG - 2010-06-19 14:25:34 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 14:25:34 --> Language Class Initialized
DEBUG - 2010-06-19 14:25:35 --> Loader Class Initialized
DEBUG - 2010-06-19 14:25:35 --> Controller Class Initialized
DEBUG - 2010-06-19 14:25:35 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 14:25:35 --> Session Class Initialized
DEBUG - 2010-06-19 14:25:35 --> Helper loaded: string_helper
DEBUG - 2010-06-19 14:25:35 --> Session routines successfully run
DEBUG - 2010-06-19 14:25:35 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 14:25:35 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:25:35 --> Database Driver Class Initialized
DEBUG - 2010-06-19 14:25:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:25:35 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-19 14:25:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:25:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:25:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:25:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:25:35 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 14:25:35 --> Final output sent to browser
DEBUG - 2010-06-19 14:25:35 --> Total execution time: 1.0400
DEBUG - 2010-06-19 14:26:09 --> Config Class Initialized
DEBUG - 2010-06-19 14:26:09 --> Hooks Class Initialized
DEBUG - 2010-06-19 14:26:09 --> URI Class Initialized
DEBUG - 2010-06-19 14:26:09 --> Router Class Initialized
DEBUG - 2010-06-19 14:26:09 --> Output Class Initialized
DEBUG - 2010-06-19 14:26:09 --> Input Class Initialized
DEBUG - 2010-06-19 14:26:09 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 14:26:09 --> Language Class Initialized
DEBUG - 2010-06-19 14:26:09 --> Loader Class Initialized
DEBUG - 2010-06-19 14:26:09 --> Controller Class Initialized
DEBUG - 2010-06-19 14:26:09 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 14:26:09 --> Session Class Initialized
DEBUG - 2010-06-19 14:26:09 --> Helper loaded: string_helper
DEBUG - 2010-06-19 14:26:10 --> Session routines successfully run
DEBUG - 2010-06-19 14:26:10 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 14:26:10 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:26:10 --> Database Driver Class Initialized
DEBUG - 2010-06-19 14:26:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:26:10 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-19 14:26:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:26:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:26:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:26:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:26:10 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 14:26:10 --> Final output sent to browser
DEBUG - 2010-06-19 14:26:10 --> Total execution time: 0.6570
DEBUG - 2010-06-19 14:26:20 --> Config Class Initialized
DEBUG - 2010-06-19 14:26:20 --> Hooks Class Initialized
DEBUG - 2010-06-19 14:26:20 --> URI Class Initialized
DEBUG - 2010-06-19 14:26:20 --> Router Class Initialized
DEBUG - 2010-06-19 14:26:20 --> Output Class Initialized
DEBUG - 2010-06-19 14:26:20 --> Input Class Initialized
DEBUG - 2010-06-19 14:26:20 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 14:26:20 --> Language Class Initialized
DEBUG - 2010-06-19 14:26:21 --> Loader Class Initialized
DEBUG - 2010-06-19 14:26:21 --> Controller Class Initialized
DEBUG - 2010-06-19 14:26:21 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 14:26:21 --> Session Class Initialized
DEBUG - 2010-06-19 14:26:21 --> Helper loaded: string_helper
DEBUG - 2010-06-19 14:26:21 --> Session routines successfully run
DEBUG - 2010-06-19 14:26:21 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 14:26:21 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:26:21 --> Database Driver Class Initialized
DEBUG - 2010-06-19 14:26:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:26:21 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-19 14:26:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:26:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:26:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:26:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:26:21 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 14:26:21 --> Final output sent to browser
DEBUG - 2010-06-19 14:26:21 --> Total execution time: 0.7145
DEBUG - 2010-06-19 14:27:17 --> Config Class Initialized
DEBUG - 2010-06-19 14:27:18 --> Hooks Class Initialized
DEBUG - 2010-06-19 14:27:18 --> URI Class Initialized
DEBUG - 2010-06-19 14:27:18 --> Router Class Initialized
DEBUG - 2010-06-19 14:27:18 --> Output Class Initialized
DEBUG - 2010-06-19 14:27:18 --> Input Class Initialized
DEBUG - 2010-06-19 14:27:18 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 14:27:18 --> Language Class Initialized
DEBUG - 2010-06-19 14:27:18 --> Loader Class Initialized
DEBUG - 2010-06-19 14:27:18 --> Controller Class Initialized
DEBUG - 2010-06-19 14:27:18 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 14:27:18 --> Session Class Initialized
DEBUG - 2010-06-19 14:27:18 --> Helper loaded: string_helper
DEBUG - 2010-06-19 14:27:18 --> Session routines successfully run
DEBUG - 2010-06-19 14:27:18 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 14:27:18 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:27:18 --> Database Driver Class Initialized
DEBUG - 2010-06-19 14:27:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:27:18 --> Language file loaded: language/english/unit_test_lang.php
ERROR - 2010-06-19 14:27:18 --> Severity: Warning  --> Illegal offset type in isset or empty D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 107
ERROR - 2010-06-19 14:27:18 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 115
DEBUG - 2010-06-19 14:27:18 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-19 14:27:18 --> Severity: Warning  --> Illegal offset type in isset or empty D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 107
ERROR - 2010-06-19 14:27:18 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 115
DEBUG - 2010-06-19 14:27:18 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-19 14:27:18 --> Severity: Warning  --> Illegal offset type in isset or empty D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 107
ERROR - 2010-06-19 14:27:18 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 115
DEBUG - 2010-06-19 14:27:18 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-19 14:27:18 --> Severity: Warning  --> Illegal offset type in isset or empty D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 107
ERROR - 2010-06-19 14:27:18 --> Severity: 4096  --> Object of class Domain could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 115
DEBUG - 2010-06-19 14:27:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:27:18 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 14:27:18 --> Final output sent to browser
DEBUG - 2010-06-19 14:27:18 --> Total execution time: 0.8602
DEBUG - 2010-06-19 14:28:12 --> Config Class Initialized
DEBUG - 2010-06-19 14:28:12 --> Hooks Class Initialized
DEBUG - 2010-06-19 14:28:12 --> URI Class Initialized
DEBUG - 2010-06-19 14:28:12 --> Router Class Initialized
DEBUG - 2010-06-19 14:28:12 --> Output Class Initialized
DEBUG - 2010-06-19 14:28:12 --> Input Class Initialized
DEBUG - 2010-06-19 14:28:12 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 14:28:12 --> Language Class Initialized
DEBUG - 2010-06-19 14:28:12 --> Loader Class Initialized
DEBUG - 2010-06-19 14:28:12 --> Controller Class Initialized
DEBUG - 2010-06-19 14:28:12 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 14:28:12 --> Session Class Initialized
DEBUG - 2010-06-19 14:28:12 --> Helper loaded: string_helper
DEBUG - 2010-06-19 14:28:12 --> Session routines successfully run
DEBUG - 2010-06-19 14:28:12 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 14:28:12 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:28:12 --> Database Driver Class Initialized
DEBUG - 2010-06-19 14:28:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:28:12 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-19 14:28:12 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 14:28:12 --> Final output sent to browser
DEBUG - 2010-06-19 14:28:12 --> Total execution time: 0.5779
DEBUG - 2010-06-19 14:41:37 --> Config Class Initialized
DEBUG - 2010-06-19 14:41:38 --> Hooks Class Initialized
DEBUG - 2010-06-19 14:41:38 --> URI Class Initialized
DEBUG - 2010-06-19 14:41:38 --> Router Class Initialized
DEBUG - 2010-06-19 14:41:38 --> Output Class Initialized
DEBUG - 2010-06-19 14:41:38 --> Input Class Initialized
DEBUG - 2010-06-19 14:41:38 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-19 14:41:38 --> Language Class Initialized
DEBUG - 2010-06-19 14:41:38 --> Loader Class Initialized
DEBUG - 2010-06-19 14:41:38 --> Controller Class Initialized
DEBUG - 2010-06-19 14:41:38 --> Unit Testing Class Initialized
DEBUG - 2010-06-19 14:41:38 --> Session Class Initialized
DEBUG - 2010-06-19 14:41:38 --> Helper loaded: string_helper
DEBUG - 2010-06-19 14:41:38 --> Session routines successfully run
DEBUG - 2010-06-19 14:41:38 --> Helper loaded: kals_helper
DEBUG - 2010-06-19 14:41:38 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:41:38 --> Database Driver Class Initialized
DEBUG - 2010-06-19 14:41:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-19 14:41:38 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-19 14:41:38 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-19 14:41:38 --> Final output sent to browser
DEBUG - 2010-06-19 14:41:38 --> Total execution time: 0.5751
