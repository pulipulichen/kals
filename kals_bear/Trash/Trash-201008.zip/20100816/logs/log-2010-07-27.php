<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-07-27 07:19:53 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/ac627ab1ccbdb62ec96e702f07f6425b) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-27 07:20:46 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/7cbbc409ec990f19c78c75bd1e06f215) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-27 11:16:53 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/072b030ba126b2f4b2374f342be9ed44) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-27 11:20:18 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/c7e1249ffc03eb9ded908c236bd1996d) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-27 11:20:18 --> Severity: Warning  --> chmod() [<a href='function.chmod'>function.chmod</a>]: No error D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 73
ERROR - 2010-07-27 11:20:18 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/ac627ab1ccbdb62ec96e702f07f6425b) [<a href='function.unlink'>function.unlink</a>]: No such file or directory D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-27 14:14:40 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/c0c7c76d30bd3dcaefc96f40275bdc0a) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-27 14:16:21 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/a5771bce93e200c36f7cd9dfd0e5deaa) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-27 14:17:58 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/093f65e080a295f8076b1c5722a46aa2) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-27 14:18:02 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/19ca14e7ea6328a42e0eb13d585e4c22) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-27 14:20:33 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/fc490ca45c00b1249bbe3554a4fdf6fb) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-27 14:20:37 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/e2c420d928d4bf8ce0ff2ec19b371514) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-27 14:25:41 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/c51ce410c124a10e0db5e4b97fc2af39) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-27 14:27:21 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/7f39f8317fbdb1988ef4c628eba02591) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-27 14:29:45 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/44f683a84163b3523afe57c2e008bc8c) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-27 14:31:15 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/9a1158154dfa42caddbd0694a4e9bdc8) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-27 14:37:18 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/fbd7939d674997cdb4692d34de8633c4) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-27 14:42:46 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/7cbbc409ec990f19c78c75bd1e06f215) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-27 14:44:14 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/c16a5320fa475530d9583c34fd356ef5) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-27 14:55:40 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/92cc227532d17e56e07902b254dfad10) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-27 14:57:33 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/a1d0c6e83f027327d8461063f4ac58a6) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-27 14:59:08 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/66f041e16a60928b05a7e228a89c3799) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-27 14:59:34 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/d82c8d1619ad8176d665453cfb2e55f0) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-27 15:02:45 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/735b90b4568125ed6c3f678819b6e058) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-27 15:09:52 --> 404 Page Not Found --> web_appsg
ERROR - 2010-07-27 15:09:52 --> 404 Page Not Found --> web_appsg
ERROR - 2010-07-27 15:09:53 --> 404 Page Not Found --> web_appsn
ERROR - 2010-07-27 15:09:53 --> 404 Page Not Found --> web_appsa
ERROR - 2010-07-27 15:09:53 --> 404 Page Not Found --> web_appse
ERROR - 2010-07-27 15:09:53 --> 404 Page Not Found --> web_appsy
ERROR - 2010-07-27 15:09:53 --> 404 Page Not Found --> web_appsr
ERROR - 2010-07-27 15:09:53 --> 404 Page Not Found --> web_appsl
ERROR - 2010-07-27 15:09:53 --> 404 Page Not Found --> web_apps/index
ERROR - 2010-07-27 15:09:54 --> 404 Page Not Found --> web_appst
ERROR - 2010-07-27 15:09:54 --> 404 Page Not Found --> web_appss
ERROR - 2010-07-27 15:11:14 --> 404 Page Not Found --> web_appsgeneral
ERROR - 2010-07-27 15:11:15 --> 404 Page Not Found --> web_appsgeneral
ERROR - 2010-07-27 15:15:55 --> 404 Page Not Found --> web_apps/g
ERROR - 2010-07-27 15:15:56 --> 404 Page Not Found --> web_apps/n
ERROR - 2010-07-27 15:15:56 --> 404 Page Not Found --> web_apps/i
ERROR - 2010-07-27 15:15:56 --> 404 Page Not Found --> web_apps/s
ERROR - 2010-07-27 15:15:56 --> 404 Page Not Found --> web_apps/e
ERROR - 2010-07-27 15:15:56 --> 404 Page Not Found --> web_apps/l
ERROR - 2010-07-27 15:15:56 --> 404 Page Not Found --> web_apps/a
ERROR - 2010-07-27 15:15:56 --> 404 Page Not Found --> web_apps/r
ERROR - 2010-07-27 15:15:56 --> 404 Page Not Found --> web_apps/e
ERROR - 2010-07-27 15:15:57 --> 404 Page Not Found --> web_apps/t
ERROR - 2010-07-27 15:15:57 --> 404 Page Not Found --> web_apps/p
ERROR - 2010-07-27 15:18:59 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/d3d9446802a44259755d38e6d163e820) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-27 15:19:43 --> Severity: Notice  --> Undefined variable: packed D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\web_apps.php 68
ERROR - 2010-07-27 15:19:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\web_apps_helper.php 39
ERROR - 2010-07-27 15:19:43 --> Severity: Notice  --> Undefined variable: packed D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\web_apps.php 68
ERROR - 2010-07-27 15:19:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\web_apps_helper.php 39
ERROR - 2010-07-27 15:19:43 --> Severity: Notice  --> Undefined variable: packed D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\web_apps.php 68
ERROR - 2010-07-27 15:19:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\web_apps_helper.php 39
ERROR - 2010-07-27 15:19:43 --> Severity: Notice  --> Undefined variable: packed D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\web_apps.php 68
ERROR - 2010-07-27 15:19:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\web_apps_helper.php 39
ERROR - 2010-07-27 15:19:43 --> Severity: Notice  --> Undefined variable: packed D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\web_apps.php 68
ERROR - 2010-07-27 15:19:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\web_apps_helper.php 39
ERROR - 2010-07-27 15:19:43 --> Severity: Notice  --> Undefined variable: packed D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\web_apps.php 68
ERROR - 2010-07-27 15:19:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\web_apps_helper.php 39
ERROR - 2010-07-27 15:51:57 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/c7e1249ffc03eb9ded908c236bd1996d) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
