<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2010-06-29 02:52:17 --> Config Class Initialized
DEBUG - 2010-06-29 02:52:17 --> Hooks Class Initialized
DEBUG - 2010-06-29 02:52:17 --> URI Class Initialized
DEBUG - 2010-06-29 02:52:17 --> Router Class Initialized
DEBUG - 2010-06-29 02:52:17 --> Output Class Initialized
DEBUG - 2010-06-29 02:52:17 --> Input Class Initialized
DEBUG - 2010-06-29 02:52:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 02:52:17 --> Language Class Initialized
DEBUG - 2010-06-29 02:52:17 --> Loader Class Initialized
DEBUG - 2010-06-29 02:52:17 --> Helper loaded: context_helper
DEBUG - 2010-06-29 02:52:17 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 02:52:17 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 02:52:17 --> Database Driver Class Initialized
ERROR - 2010-06-29 02:52:17 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 253
DEBUG - 2010-06-29 02:52:17 --> Controller Class Initialized
DEBUG - 2010-06-29 02:52:17 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 02:52:17 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 02:52:17 --> Helper loaded: cookie_helper
DEBUG - 2010-06-29 02:52:18 --> Session Class Initialized
DEBUG - 2010-06-29 02:52:18 --> Helper loaded: string_helper
DEBUG - 2010-06-29 02:52:18 --> A session cookie was not found.
ERROR - 2010-06-29 02:52:18 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Session.php 662
DEBUG - 2010-06-29 02:52:18 --> Session routines successfully run
ERROR - 2010-06-29 02:52:18 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 253
ERROR - 2010-06-29 02:52:18 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 253
DEBUG - 2010-06-29 02:52:18 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-29 02:52:18 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 253
ERROR - 2010-06-29 02:52:19 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 243
ERROR - 2010-06-29 02:52:19 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 243
ERROR - 2010-06-29 02:52:19 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 243
DEBUG - 2010-06-29 02:52:19 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 02:52:19 --> Final output sent to browser
DEBUG - 2010-06-29 02:52:19 --> Total execution time: 1.5109
DEBUG - 2010-06-29 02:53:00 --> Config Class Initialized
DEBUG - 2010-06-29 02:53:00 --> Hooks Class Initialized
DEBUG - 2010-06-29 02:53:00 --> URI Class Initialized
DEBUG - 2010-06-29 02:53:00 --> Router Class Initialized
DEBUG - 2010-06-29 02:53:00 --> Output Class Initialized
DEBUG - 2010-06-29 02:53:00 --> Input Class Initialized
DEBUG - 2010-06-29 02:53:00 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 02:53:00 --> Language Class Initialized
DEBUG - 2010-06-29 02:53:00 --> Loader Class Initialized
DEBUG - 2010-06-29 02:53:00 --> Helper loaded: context_helper
DEBUG - 2010-06-29 02:53:00 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 02:53:00 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 02:53:00 --> Database Driver Class Initialized
ERROR - 2010-06-29 02:53:00 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 253
DEBUG - 2010-06-29 02:53:00 --> Controller Class Initialized
DEBUG - 2010-06-29 02:53:00 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 02:53:00 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 02:53:00 --> Helper loaded: cookie_helper
DEBUG - 2010-06-29 02:53:00 --> Session Class Initialized
DEBUG - 2010-06-29 02:53:00 --> Helper loaded: string_helper
DEBUG - 2010-06-29 02:53:00 --> A session cookie was not found.
ERROR - 2010-06-29 02:53:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Session.php 662
DEBUG - 2010-06-29 02:53:00 --> Session routines successfully run
DEBUG - 2010-06-29 02:53:12 --> Config Class Initialized
DEBUG - 2010-06-29 02:53:12 --> Hooks Class Initialized
DEBUG - 2010-06-29 02:53:12 --> URI Class Initialized
DEBUG - 2010-06-29 02:53:12 --> Router Class Initialized
DEBUG - 2010-06-29 02:53:12 --> Output Class Initialized
ERROR - 2010-06-29 02:53:12 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/c4ca4238a0b923820dcc509a6f75849b) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
DEBUG - 2010-06-29 02:53:12 --> Input Class Initialized
DEBUG - 2010-06-29 02:53:12 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 02:53:12 --> Language Class Initialized
DEBUG - 2010-06-29 02:53:12 --> Loader Class Initialized
DEBUG - 2010-06-29 02:53:12 --> Helper loaded: context_helper
DEBUG - 2010-06-29 02:53:12 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 02:53:12 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 02:53:12 --> Database Driver Class Initialized
ERROR - 2010-06-29 02:53:12 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 253
DEBUG - 2010-06-29 02:53:12 --> Controller Class Initialized
DEBUG - 2010-06-29 02:53:12 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 02:53:12 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 02:53:12 --> Helper loaded: cookie_helper
DEBUG - 2010-06-29 02:53:12 --> Session Class Initialized
DEBUG - 2010-06-29 02:53:12 --> Helper loaded: string_helper
DEBUG - 2010-06-29 02:53:12 --> A session cookie was not found.
ERROR - 2010-06-29 02:53:12 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Session.php 662
DEBUG - 2010-06-29 02:53:12 --> Session routines successfully run
ERROR - 2010-06-29 02:53:12 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 253
ERROR - 2010-06-29 02:53:12 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 253
DEBUG - 2010-06-29 02:53:13 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-29 02:53:13 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 253
ERROR - 2010-06-29 02:53:13 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 243
ERROR - 2010-06-29 02:53:13 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 243
ERROR - 2010-06-29 02:53:13 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 243
DEBUG - 2010-06-29 02:53:13 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 02:53:13 --> Final output sent to browser
DEBUG - 2010-06-29 02:53:13 --> Total execution time: 0.9928
DEBUG - 2010-06-29 02:53:41 --> Config Class Initialized
DEBUG - 2010-06-29 02:53:41 --> Hooks Class Initialized
DEBUG - 2010-06-29 02:53:41 --> URI Class Initialized
DEBUG - 2010-06-29 02:53:41 --> Router Class Initialized
DEBUG - 2010-06-29 02:53:41 --> Output Class Initialized
DEBUG - 2010-06-29 02:53:41 --> Input Class Initialized
DEBUG - 2010-06-29 02:53:41 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 02:53:41 --> Language Class Initialized
DEBUG - 2010-06-29 02:53:41 --> Loader Class Initialized
DEBUG - 2010-06-29 02:53:41 --> Helper loaded: context_helper
DEBUG - 2010-06-29 02:53:41 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 02:53:41 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 02:53:41 --> Database Driver Class Initialized
ERROR - 2010-06-29 02:53:41 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 253
DEBUG - 2010-06-29 02:53:41 --> Controller Class Initialized
DEBUG - 2010-06-29 02:53:41 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 02:53:41 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 02:53:41 --> Helper loaded: cookie_helper
DEBUG - 2010-06-29 02:53:41 --> Session Class Initialized
DEBUG - 2010-06-29 02:53:41 --> Helper loaded: string_helper
DEBUG - 2010-06-29 02:53:41 --> A session cookie was not found.
ERROR - 2010-06-29 02:53:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Session.php 662
DEBUG - 2010-06-29 02:53:41 --> Session routines successfully run
ERROR - 2010-06-29 02:53:41 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 253
ERROR - 2010-06-29 02:53:41 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 253
DEBUG - 2010-06-29 02:53:41 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-29 02:53:41 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 253
ERROR - 2010-06-29 02:53:42 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 253
ERROR - 2010-06-29 02:53:42 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 253
ERROR - 2010-06-29 02:53:42 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 253
DEBUG - 2010-06-29 02:53:42 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 02:53:42 --> Final output sent to browser
DEBUG - 2010-06-29 02:53:42 --> Total execution time: 1.0601
DEBUG - 2010-06-29 02:53:48 --> Config Class Initialized
DEBUG - 2010-06-29 02:53:48 --> Hooks Class Initialized
DEBUG - 2010-06-29 02:53:48 --> URI Class Initialized
DEBUG - 2010-06-29 02:53:48 --> Router Class Initialized
DEBUG - 2010-06-29 02:53:48 --> Output Class Initialized
DEBUG - 2010-06-29 02:53:48 --> Input Class Initialized
DEBUG - 2010-06-29 02:53:48 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 02:53:48 --> Language Class Initialized
DEBUG - 2010-06-29 02:53:48 --> Loader Class Initialized
DEBUG - 2010-06-29 02:53:48 --> Helper loaded: context_helper
DEBUG - 2010-06-29 02:53:48 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 02:53:48 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 02:53:48 --> Database Driver Class Initialized
DEBUG - 2010-06-29 02:53:48 --> Controller Class Initialized
DEBUG - 2010-06-29 02:53:48 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 02:53:48 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 02:53:48 --> Helper loaded: cookie_helper
DEBUG - 2010-06-29 02:53:48 --> Session Class Initialized
DEBUG - 2010-06-29 02:53:48 --> Helper loaded: string_helper
DEBUG - 2010-06-29 02:53:48 --> A session cookie was not found.
DEBUG - 2010-06-29 02:53:48 --> Session routines successfully run
DEBUG - 2010-06-29 02:53:49 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 02:53:49 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 02:53:49 --> Final output sent to browser
DEBUG - 2010-06-29 02:53:49 --> Total execution time: 0.9284
DEBUG - 2010-06-29 02:55:55 --> Config Class Initialized
DEBUG - 2010-06-29 02:55:55 --> Hooks Class Initialized
DEBUG - 2010-06-29 02:55:55 --> URI Class Initialized
DEBUG - 2010-06-29 02:55:55 --> Router Class Initialized
DEBUG - 2010-06-29 02:55:55 --> Output Class Initialized
DEBUG - 2010-06-29 02:55:55 --> Input Class Initialized
DEBUG - 2010-06-29 02:55:55 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 02:55:55 --> Language Class Initialized
DEBUG - 2010-06-29 02:55:55 --> Loader Class Initialized
DEBUG - 2010-06-29 02:55:55 --> Helper loaded: context_helper
DEBUG - 2010-06-29 02:55:55 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 02:55:55 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 02:55:55 --> Database Driver Class Initialized
DEBUG - 2010-06-29 02:55:55 --> Controller Class Initialized
DEBUG - 2010-06-29 02:55:55 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 02:55:55 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 02:55:55 --> Helper loaded: cookie_helper
DEBUG - 2010-06-29 02:55:55 --> Session Class Initialized
DEBUG - 2010-06-29 02:55:55 --> Helper loaded: string_helper
DEBUG - 2010-06-29 02:55:55 --> Session routines successfully run
DEBUG - 2010-06-29 02:55:56 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 02:55:56 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 02:55:56 --> Final output sent to browser
DEBUG - 2010-06-29 02:55:56 --> Total execution time: 1.1053
DEBUG - 2010-06-29 02:57:59 --> Config Class Initialized
DEBUG - 2010-06-29 02:57:59 --> Hooks Class Initialized
DEBUG - 2010-06-29 02:57:59 --> URI Class Initialized
DEBUG - 2010-06-29 02:57:59 --> Router Class Initialized
DEBUG - 2010-06-29 02:57:59 --> Output Class Initialized
DEBUG - 2010-06-29 02:57:59 --> Input Class Initialized
DEBUG - 2010-06-29 02:57:59 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 02:57:59 --> Language Class Initialized
DEBUG - 2010-06-29 02:57:59 --> Loader Class Initialized
DEBUG - 2010-06-29 02:57:59 --> Helper loaded: context_helper
DEBUG - 2010-06-29 02:57:59 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 02:57:59 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 02:57:59 --> Database Driver Class Initialized
DEBUG - 2010-06-29 02:57:59 --> Controller Class Initialized
DEBUG - 2010-06-29 02:57:59 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 02:57:59 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 02:57:59 --> Helper loaded: cookie_helper
DEBUG - 2010-06-29 02:57:59 --> Session Class Initialized
DEBUG - 2010-06-29 02:57:59 --> Helper loaded: string_helper
DEBUG - 2010-06-29 02:57:59 --> Session routines successfully run
DEBUG - 2010-06-29 02:57:59 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 02:58:00 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 02:58:00 --> Final output sent to browser
DEBUG - 2010-06-29 02:58:00 --> Total execution time: 0.9280
DEBUG - 2010-06-29 02:58:22 --> Config Class Initialized
DEBUG - 2010-06-29 02:58:22 --> Hooks Class Initialized
DEBUG - 2010-06-29 02:58:22 --> URI Class Initialized
DEBUG - 2010-06-29 02:58:22 --> Router Class Initialized
DEBUG - 2010-06-29 02:58:22 --> Output Class Initialized
DEBUG - 2010-06-29 02:58:22 --> Input Class Initialized
DEBUG - 2010-06-29 02:58:22 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 02:58:22 --> Language Class Initialized
DEBUG - 2010-06-29 02:58:22 --> Loader Class Initialized
DEBUG - 2010-06-29 02:58:22 --> Helper loaded: context_helper
DEBUG - 2010-06-29 02:58:22 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 02:58:22 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 02:58:22 --> Database Driver Class Initialized
DEBUG - 2010-06-29 02:58:22 --> Controller Class Initialized
DEBUG - 2010-06-29 02:58:22 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 02:58:22 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 02:58:22 --> Helper loaded: cookie_helper
DEBUG - 2010-06-29 02:58:22 --> Session Class Initialized
DEBUG - 2010-06-29 02:58:23 --> Helper loaded: string_helper
DEBUG - 2010-06-29 02:58:23 --> Session routines successfully run
DEBUG - 2010-06-29 02:58:23 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 02:58:23 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 02:58:23 --> Final output sent to browser
DEBUG - 2010-06-29 02:58:23 --> Total execution time: 0.9506
DEBUG - 2010-06-29 02:59:43 --> Config Class Initialized
DEBUG - 2010-06-29 02:59:43 --> Hooks Class Initialized
DEBUG - 2010-06-29 02:59:43 --> URI Class Initialized
DEBUG - 2010-06-29 02:59:43 --> Router Class Initialized
DEBUG - 2010-06-29 02:59:43 --> Output Class Initialized
DEBUG - 2010-06-29 02:59:43 --> Input Class Initialized
DEBUG - 2010-06-29 02:59:43 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 02:59:43 --> Language Class Initialized
DEBUG - 2010-06-29 02:59:43 --> Loader Class Initialized
DEBUG - 2010-06-29 02:59:43 --> Helper loaded: context_helper
DEBUG - 2010-06-29 02:59:43 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 02:59:43 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 02:59:43 --> Database Driver Class Initialized
DEBUG - 2010-06-29 02:59:43 --> Controller Class Initialized
DEBUG - 2010-06-29 02:59:43 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 02:59:43 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 02:59:43 --> Helper loaded: cookie_helper
DEBUG - 2010-06-29 02:59:43 --> Session Class Initialized
DEBUG - 2010-06-29 02:59:43 --> Helper loaded: string_helper
DEBUG - 2010-06-29 02:59:43 --> Session routines successfully run
DEBUG - 2010-06-29 02:59:44 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 02:59:44 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 02:59:44 --> Final output sent to browser
DEBUG - 2010-06-29 02:59:44 --> Total execution time: 0.9926
DEBUG - 2010-06-29 03:00:01 --> Config Class Initialized
DEBUG - 2010-06-29 03:00:01 --> Hooks Class Initialized
DEBUG - 2010-06-29 03:00:01 --> URI Class Initialized
DEBUG - 2010-06-29 03:00:01 --> Router Class Initialized
DEBUG - 2010-06-29 03:00:01 --> Output Class Initialized
DEBUG - 2010-06-29 03:00:01 --> Input Class Initialized
DEBUG - 2010-06-29 03:00:01 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 03:00:01 --> Language Class Initialized
DEBUG - 2010-06-29 03:00:01 --> Loader Class Initialized
DEBUG - 2010-06-29 03:00:01 --> Helper loaded: context_helper
DEBUG - 2010-06-29 03:00:01 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 03:00:01 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 03:00:01 --> Database Driver Class Initialized
DEBUG - 2010-06-29 03:00:01 --> Controller Class Initialized
DEBUG - 2010-06-29 03:00:01 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 03:00:01 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 03:00:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:00:02 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 03:04:38 --> Config Class Initialized
DEBUG - 2010-06-29 03:04:38 --> Hooks Class Initialized
DEBUG - 2010-06-29 03:04:38 --> URI Class Initialized
DEBUG - 2010-06-29 03:04:38 --> Router Class Initialized
DEBUG - 2010-06-29 03:04:38 --> Output Class Initialized
DEBUG - 2010-06-29 03:04:38 --> Input Class Initialized
DEBUG - 2010-06-29 03:04:38 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 03:04:38 --> Language Class Initialized
DEBUG - 2010-06-29 03:04:38 --> Loader Class Initialized
DEBUG - 2010-06-29 03:04:38 --> Helper loaded: context_helper
DEBUG - 2010-06-29 03:04:38 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 03:04:38 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 03:04:38 --> Database Driver Class Initialized
DEBUG - 2010-06-29 03:04:38 --> Controller Class Initialized
DEBUG - 2010-06-29 03:04:38 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 03:04:38 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 03:04:38 --> Session Class Initialized
DEBUG - 2010-06-29 03:04:38 --> Helper loaded: string_helper
DEBUG - 2010-06-29 03:04:38 --> Session routines successfully run
DEBUG - 2010-06-29 03:04:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:04:39 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 03:05:19 --> Config Class Initialized
DEBUG - 2010-06-29 03:05:19 --> Hooks Class Initialized
DEBUG - 2010-06-29 03:05:19 --> URI Class Initialized
DEBUG - 2010-06-29 03:05:19 --> Router Class Initialized
DEBUG - 2010-06-29 03:05:19 --> Output Class Initialized
DEBUG - 2010-06-29 03:05:19 --> Input Class Initialized
DEBUG - 2010-06-29 03:05:19 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 03:05:19 --> Language Class Initialized
DEBUG - 2010-06-29 03:05:19 --> Loader Class Initialized
DEBUG - 2010-06-29 03:05:20 --> Helper loaded: context_helper
DEBUG - 2010-06-29 03:05:20 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 03:05:20 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 03:05:20 --> Database Driver Class Initialized
DEBUG - 2010-06-29 03:05:20 --> Controller Class Initialized
DEBUG - 2010-06-29 03:05:20 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 03:05:20 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 03:05:20 --> Session Class Initialized
DEBUG - 2010-06-29 03:05:20 --> Helper loaded: string_helper
DEBUG - 2010-06-29 03:05:20 --> Session routines successfully run
DEBUG - 2010-06-29 03:05:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:05:24 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 03:05:39 --> Config Class Initialized
DEBUG - 2010-06-29 03:05:39 --> Hooks Class Initialized
DEBUG - 2010-06-29 03:05:39 --> URI Class Initialized
DEBUG - 2010-06-29 03:05:39 --> Router Class Initialized
DEBUG - 2010-06-29 03:05:39 --> Output Class Initialized
DEBUG - 2010-06-29 03:05:40 --> Input Class Initialized
DEBUG - 2010-06-29 03:05:40 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 03:05:40 --> Language Class Initialized
DEBUG - 2010-06-29 03:05:40 --> Loader Class Initialized
DEBUG - 2010-06-29 03:05:40 --> Helper loaded: context_helper
DEBUG - 2010-06-29 03:05:40 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 03:05:40 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 03:05:40 --> Database Driver Class Initialized
DEBUG - 2010-06-29 03:05:40 --> Controller Class Initialized
DEBUG - 2010-06-29 03:05:40 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 03:05:40 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 03:05:40 --> Session Class Initialized
DEBUG - 2010-06-29 03:05:40 --> Helper loaded: string_helper
DEBUG - 2010-06-29 03:05:40 --> Session routines successfully run
DEBUG - 2010-06-29 03:05:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:05:41 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 03:05:49 --> Config Class Initialized
DEBUG - 2010-06-29 03:05:49 --> Hooks Class Initialized
DEBUG - 2010-06-29 03:05:49 --> URI Class Initialized
DEBUG - 2010-06-29 03:05:49 --> Router Class Initialized
DEBUG - 2010-06-29 03:05:49 --> Output Class Initialized
DEBUG - 2010-06-29 03:05:49 --> Input Class Initialized
DEBUG - 2010-06-29 03:05:49 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 03:05:49 --> Language Class Initialized
DEBUG - 2010-06-29 03:05:50 --> Loader Class Initialized
DEBUG - 2010-06-29 03:05:50 --> Helper loaded: context_helper
DEBUG - 2010-06-29 03:05:50 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 03:05:50 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 03:05:50 --> Database Driver Class Initialized
DEBUG - 2010-06-29 03:05:50 --> Controller Class Initialized
DEBUG - 2010-06-29 03:05:50 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 03:05:50 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 03:05:50 --> Session Class Initialized
DEBUG - 2010-06-29 03:05:50 --> Helper loaded: string_helper
DEBUG - 2010-06-29 03:05:50 --> Session routines successfully run
DEBUG - 2010-06-29 03:05:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:05:51 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 03:06:08 --> Config Class Initialized
DEBUG - 2010-06-29 03:06:08 --> Hooks Class Initialized
DEBUG - 2010-06-29 03:06:08 --> URI Class Initialized
DEBUG - 2010-06-29 03:06:08 --> Router Class Initialized
DEBUG - 2010-06-29 03:06:08 --> Output Class Initialized
DEBUG - 2010-06-29 03:06:08 --> Input Class Initialized
DEBUG - 2010-06-29 03:06:08 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 03:06:08 --> Language Class Initialized
DEBUG - 2010-06-29 03:06:08 --> Loader Class Initialized
DEBUG - 2010-06-29 03:06:08 --> Helper loaded: context_helper
DEBUG - 2010-06-29 03:06:08 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 03:06:08 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 03:06:08 --> Database Driver Class Initialized
DEBUG - 2010-06-29 03:06:08 --> Controller Class Initialized
DEBUG - 2010-06-29 03:06:08 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 03:06:08 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 03:06:08 --> Session Class Initialized
DEBUG - 2010-06-29 03:06:08 --> Helper loaded: string_helper
DEBUG - 2010-06-29 03:06:08 --> Session routines successfully run
DEBUG - 2010-06-29 03:06:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:06:15 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 03:07:23 --> Config Class Initialized
DEBUG - 2010-06-29 03:07:23 --> Hooks Class Initialized
DEBUG - 2010-06-29 03:07:23 --> URI Class Initialized
DEBUG - 2010-06-29 03:07:23 --> Router Class Initialized
DEBUG - 2010-06-29 03:07:23 --> Output Class Initialized
DEBUG - 2010-06-29 03:07:23 --> Input Class Initialized
DEBUG - 2010-06-29 03:07:23 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 03:07:23 --> Language Class Initialized
DEBUG - 2010-06-29 03:07:23 --> Loader Class Initialized
DEBUG - 2010-06-29 03:07:23 --> Helper loaded: context_helper
DEBUG - 2010-06-29 03:07:23 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 03:07:23 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 03:07:23 --> Database Driver Class Initialized
DEBUG - 2010-06-29 03:07:23 --> Controller Class Initialized
DEBUG - 2010-06-29 03:07:23 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 03:07:23 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 03:07:23 --> Session Class Initialized
DEBUG - 2010-06-29 03:07:23 --> Helper loaded: string_helper
DEBUG - 2010-06-29 03:07:23 --> Session routines successfully run
DEBUG - 2010-06-29 03:07:33 --> Config Class Initialized
DEBUG - 2010-06-29 03:07:33 --> Hooks Class Initialized
DEBUG - 2010-06-29 03:07:33 --> URI Class Initialized
DEBUG - 2010-06-29 03:07:33 --> Router Class Initialized
DEBUG - 2010-06-29 03:07:33 --> Output Class Initialized
DEBUG - 2010-06-29 03:07:34 --> Input Class Initialized
DEBUG - 2010-06-29 03:07:34 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 03:07:34 --> Language Class Initialized
DEBUG - 2010-06-29 03:07:34 --> Loader Class Initialized
DEBUG - 2010-06-29 03:07:34 --> Helper loaded: context_helper
DEBUG - 2010-06-29 03:07:34 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 03:07:34 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 03:07:34 --> Database Driver Class Initialized
DEBUG - 2010-06-29 03:07:34 --> Controller Class Initialized
DEBUG - 2010-06-29 03:07:34 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 03:07:34 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 03:07:34 --> Session Class Initialized
DEBUG - 2010-06-29 03:07:34 --> Helper loaded: string_helper
DEBUG - 2010-06-29 03:07:34 --> Session routines successfully run
DEBUG - 2010-06-29 03:07:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:07:38 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 03:07:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:07:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:07:38 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 03:07:38 --> Final output sent to browser
DEBUG - 2010-06-29 03:07:38 --> Total execution time: 4.4987
DEBUG - 2010-06-29 03:09:29 --> Config Class Initialized
DEBUG - 2010-06-29 03:09:29 --> Hooks Class Initialized
DEBUG - 2010-06-29 03:09:29 --> URI Class Initialized
DEBUG - 2010-06-29 03:09:29 --> Router Class Initialized
DEBUG - 2010-06-29 03:09:29 --> Output Class Initialized
DEBUG - 2010-06-29 03:09:29 --> Input Class Initialized
DEBUG - 2010-06-29 03:09:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 03:09:29 --> Language Class Initialized
DEBUG - 2010-06-29 03:09:29 --> Loader Class Initialized
DEBUG - 2010-06-29 03:09:29 --> Helper loaded: context_helper
DEBUG - 2010-06-29 03:09:29 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 03:09:29 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 03:09:29 --> Database Driver Class Initialized
DEBUG - 2010-06-29 03:09:29 --> Controller Class Initialized
DEBUG - 2010-06-29 03:09:29 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 03:09:29 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 03:09:29 --> Session Class Initialized
DEBUG - 2010-06-29 03:09:29 --> Helper loaded: string_helper
DEBUG - 2010-06-29 03:09:29 --> Session routines successfully run
DEBUG - 2010-06-29 03:09:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:09:30 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 03:09:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:09:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:09:30 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 03:09:30 --> Final output sent to browser
DEBUG - 2010-06-29 03:09:30 --> Total execution time: 1.2914
DEBUG - 2010-06-29 03:09:46 --> Config Class Initialized
DEBUG - 2010-06-29 03:09:46 --> Hooks Class Initialized
DEBUG - 2010-06-29 03:09:46 --> URI Class Initialized
DEBUG - 2010-06-29 03:09:46 --> Router Class Initialized
DEBUG - 2010-06-29 03:09:46 --> Output Class Initialized
DEBUG - 2010-06-29 03:09:46 --> Input Class Initialized
DEBUG - 2010-06-29 03:09:46 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 03:09:46 --> Language Class Initialized
DEBUG - 2010-06-29 03:09:46 --> Loader Class Initialized
DEBUG - 2010-06-29 03:09:46 --> Helper loaded: context_helper
DEBUG - 2010-06-29 03:09:46 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 03:09:46 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 03:09:46 --> Database Driver Class Initialized
DEBUG - 2010-06-29 03:09:46 --> Controller Class Initialized
DEBUG - 2010-06-29 03:09:46 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 03:09:47 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 03:09:51 --> Config Class Initialized
DEBUG - 2010-06-29 03:09:51 --> Hooks Class Initialized
DEBUG - 2010-06-29 03:09:51 --> URI Class Initialized
DEBUG - 2010-06-29 03:09:51 --> Router Class Initialized
DEBUG - 2010-06-29 03:09:51 --> Output Class Initialized
DEBUG - 2010-06-29 03:09:51 --> Input Class Initialized
DEBUG - 2010-06-29 03:09:51 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 03:09:51 --> Language Class Initialized
DEBUG - 2010-06-29 03:09:51 --> Loader Class Initialized
DEBUG - 2010-06-29 03:09:51 --> Helper loaded: context_helper
DEBUG - 2010-06-29 03:09:51 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 03:09:51 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 03:09:51 --> Database Driver Class Initialized
DEBUG - 2010-06-29 03:09:51 --> Controller Class Initialized
DEBUG - 2010-06-29 03:09:51 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 03:09:51 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 03:09:51 --> Session Class Initialized
DEBUG - 2010-06-29 03:09:51 --> Helper loaded: string_helper
DEBUG - 2010-06-29 03:09:51 --> Session routines successfully run
DEBUG - 2010-06-29 03:09:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:09:52 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 03:09:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:09:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:09:52 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 03:09:52 --> Final output sent to browser
DEBUG - 2010-06-29 03:09:52 --> Total execution time: 1.7516
DEBUG - 2010-06-29 03:11:18 --> Config Class Initialized
DEBUG - 2010-06-29 03:11:18 --> Hooks Class Initialized
DEBUG - 2010-06-29 03:11:18 --> URI Class Initialized
DEBUG - 2010-06-29 03:11:18 --> Router Class Initialized
DEBUG - 2010-06-29 03:11:18 --> Output Class Initialized
DEBUG - 2010-06-29 03:11:18 --> Input Class Initialized
DEBUG - 2010-06-29 03:11:18 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 03:11:18 --> Language Class Initialized
DEBUG - 2010-06-29 03:11:18 --> Loader Class Initialized
DEBUG - 2010-06-29 03:11:18 --> Helper loaded: context_helper
DEBUG - 2010-06-29 03:11:18 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 03:11:18 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 03:11:18 --> Database Driver Class Initialized
DEBUG - 2010-06-29 03:11:18 --> Controller Class Initialized
DEBUG - 2010-06-29 03:11:18 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 03:11:18 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 03:11:18 --> Session Class Initialized
DEBUG - 2010-06-29 03:11:18 --> Helper loaded: string_helper
DEBUG - 2010-06-29 03:11:18 --> Session routines successfully run
DEBUG - 2010-06-29 03:11:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:11:20 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 03:11:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:11:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:11:20 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 03:11:20 --> Final output sent to browser
DEBUG - 2010-06-29 03:11:20 --> Total execution time: 1.9327
DEBUG - 2010-06-29 03:12:08 --> Config Class Initialized
DEBUG - 2010-06-29 03:12:08 --> Hooks Class Initialized
DEBUG - 2010-06-29 03:12:08 --> URI Class Initialized
DEBUG - 2010-06-29 03:12:08 --> Router Class Initialized
DEBUG - 2010-06-29 03:12:08 --> Output Class Initialized
DEBUG - 2010-06-29 03:12:09 --> Input Class Initialized
DEBUG - 2010-06-29 03:12:09 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 03:12:09 --> Language Class Initialized
DEBUG - 2010-06-29 03:12:09 --> Loader Class Initialized
DEBUG - 2010-06-29 03:12:09 --> Helper loaded: context_helper
DEBUG - 2010-06-29 03:12:09 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 03:12:09 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 03:12:09 --> Database Driver Class Initialized
DEBUG - 2010-06-29 03:12:09 --> Controller Class Initialized
DEBUG - 2010-06-29 03:12:09 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 03:12:09 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 03:12:09 --> Session Class Initialized
DEBUG - 2010-06-29 03:12:09 --> Helper loaded: string_helper
DEBUG - 2010-06-29 03:12:09 --> Session routines successfully run
DEBUG - 2010-06-29 03:12:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:12:10 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 03:12:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:12:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:12:10 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 03:12:10 --> Final output sent to browser
DEBUG - 2010-06-29 03:12:10 --> Total execution time: 1.2937
DEBUG - 2010-06-29 03:14:12 --> Config Class Initialized
DEBUG - 2010-06-29 03:14:12 --> Hooks Class Initialized
DEBUG - 2010-06-29 03:14:12 --> URI Class Initialized
DEBUG - 2010-06-29 03:14:12 --> Router Class Initialized
DEBUG - 2010-06-29 03:14:12 --> Output Class Initialized
DEBUG - 2010-06-29 03:14:12 --> Input Class Initialized
DEBUG - 2010-06-29 03:14:12 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 03:14:12 --> Language Class Initialized
DEBUG - 2010-06-29 03:14:12 --> Loader Class Initialized
DEBUG - 2010-06-29 03:14:12 --> Helper loaded: context_helper
DEBUG - 2010-06-29 03:14:12 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 03:14:12 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 03:14:12 --> Database Driver Class Initialized
DEBUG - 2010-06-29 03:14:12 --> Controller Class Initialized
DEBUG - 2010-06-29 03:14:12 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 03:14:12 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 03:14:12 --> Session Class Initialized
DEBUG - 2010-06-29 03:14:12 --> Helper loaded: string_helper
DEBUG - 2010-06-29 03:14:12 --> Session routines successfully run
DEBUG - 2010-06-29 03:14:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:14:13 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 03:14:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:14:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:14:13 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 03:14:13 --> Final output sent to browser
DEBUG - 2010-06-29 03:14:13 --> Total execution time: 1.5179
DEBUG - 2010-06-29 03:14:48 --> Config Class Initialized
DEBUG - 2010-06-29 03:14:48 --> Hooks Class Initialized
DEBUG - 2010-06-29 03:14:48 --> URI Class Initialized
DEBUG - 2010-06-29 03:14:48 --> Router Class Initialized
DEBUG - 2010-06-29 03:14:48 --> Output Class Initialized
DEBUG - 2010-06-29 03:14:48 --> Input Class Initialized
DEBUG - 2010-06-29 03:14:48 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 03:14:48 --> Language Class Initialized
DEBUG - 2010-06-29 03:14:48 --> Loader Class Initialized
DEBUG - 2010-06-29 03:14:48 --> Helper loaded: context_helper
DEBUG - 2010-06-29 03:14:48 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 03:14:48 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 03:14:48 --> Database Driver Class Initialized
DEBUG - 2010-06-29 03:14:48 --> Controller Class Initialized
DEBUG - 2010-06-29 03:14:48 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 03:14:48 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 03:14:48 --> Session Class Initialized
DEBUG - 2010-06-29 03:14:48 --> Helper loaded: string_helper
DEBUG - 2010-06-29 03:14:48 --> Session routines successfully run
DEBUG - 2010-06-29 03:14:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:14:49 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 03:14:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:14:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:14:49 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 03:14:49 --> Final output sent to browser
DEBUG - 2010-06-29 03:14:49 --> Total execution time: 1.5163
DEBUG - 2010-06-29 03:15:48 --> Config Class Initialized
DEBUG - 2010-06-29 03:15:48 --> Hooks Class Initialized
DEBUG - 2010-06-29 03:15:48 --> URI Class Initialized
DEBUG - 2010-06-29 03:15:48 --> Router Class Initialized
DEBUG - 2010-06-29 03:15:48 --> Output Class Initialized
DEBUG - 2010-06-29 03:15:48 --> Input Class Initialized
DEBUG - 2010-06-29 03:15:48 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 03:15:48 --> Language Class Initialized
DEBUG - 2010-06-29 03:15:48 --> Loader Class Initialized
DEBUG - 2010-06-29 03:15:48 --> Helper loaded: context_helper
DEBUG - 2010-06-29 03:15:48 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 03:15:48 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 03:15:48 --> Database Driver Class Initialized
DEBUG - 2010-06-29 03:15:48 --> Controller Class Initialized
DEBUG - 2010-06-29 03:15:48 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 03:15:48 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 03:15:48 --> Session Class Initialized
DEBUG - 2010-06-29 03:15:48 --> Helper loaded: string_helper
DEBUG - 2010-06-29 03:15:48 --> Session routines successfully run
DEBUG - 2010-06-29 03:15:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:15:50 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 03:15:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:15:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:15:50 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 03:15:50 --> Final output sent to browser
DEBUG - 2010-06-29 03:15:50 --> Total execution time: 2.1615
DEBUG - 2010-06-29 03:16:19 --> Config Class Initialized
DEBUG - 2010-06-29 03:16:19 --> Hooks Class Initialized
DEBUG - 2010-06-29 03:16:19 --> URI Class Initialized
DEBUG - 2010-06-29 03:16:19 --> Router Class Initialized
DEBUG - 2010-06-29 03:16:19 --> Output Class Initialized
DEBUG - 2010-06-29 03:16:19 --> Input Class Initialized
DEBUG - 2010-06-29 03:16:19 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 03:16:19 --> Language Class Initialized
DEBUG - 2010-06-29 03:16:19 --> Loader Class Initialized
DEBUG - 2010-06-29 03:16:19 --> Helper loaded: context_helper
DEBUG - 2010-06-29 03:16:19 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 03:16:19 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 03:16:19 --> Database Driver Class Initialized
DEBUG - 2010-06-29 03:16:19 --> Controller Class Initialized
DEBUG - 2010-06-29 03:16:19 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 03:16:19 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 03:16:19 --> Session Class Initialized
DEBUG - 2010-06-29 03:16:19 --> Helper loaded: string_helper
DEBUG - 2010-06-29 03:16:19 --> Session routines successfully run
DEBUG - 2010-06-29 03:16:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:16:20 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 03:16:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:16:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:16:20 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 03:16:20 --> Final output sent to browser
DEBUG - 2010-06-29 03:16:20 --> Total execution time: 1.4472
DEBUG - 2010-06-29 03:16:51 --> Config Class Initialized
DEBUG - 2010-06-29 03:16:51 --> Hooks Class Initialized
DEBUG - 2010-06-29 03:16:51 --> URI Class Initialized
DEBUG - 2010-06-29 03:16:51 --> Router Class Initialized
DEBUG - 2010-06-29 03:16:51 --> Output Class Initialized
DEBUG - 2010-06-29 03:16:51 --> Input Class Initialized
DEBUG - 2010-06-29 03:16:51 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 03:16:51 --> Language Class Initialized
DEBUG - 2010-06-29 03:16:51 --> Loader Class Initialized
DEBUG - 2010-06-29 03:16:51 --> Helper loaded: context_helper
DEBUG - 2010-06-29 03:16:51 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 03:16:51 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 03:16:51 --> Database Driver Class Initialized
DEBUG - 2010-06-29 03:16:51 --> Controller Class Initialized
DEBUG - 2010-06-29 03:16:51 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 03:16:51 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 03:16:51 --> Session Class Initialized
DEBUG - 2010-06-29 03:16:51 --> Helper loaded: string_helper
DEBUG - 2010-06-29 03:16:51 --> Session routines successfully run
DEBUG - 2010-06-29 03:16:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:16:52 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 03:16:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:16:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:16:52 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 03:16:52 --> Final output sent to browser
DEBUG - 2010-06-29 03:16:52 --> Total execution time: 1.5080
DEBUG - 2010-06-29 03:17:26 --> Config Class Initialized
DEBUG - 2010-06-29 03:17:26 --> Hooks Class Initialized
DEBUG - 2010-06-29 03:17:26 --> URI Class Initialized
DEBUG - 2010-06-29 03:17:26 --> Router Class Initialized
DEBUG - 2010-06-29 03:17:26 --> Output Class Initialized
DEBUG - 2010-06-29 03:17:26 --> Input Class Initialized
DEBUG - 2010-06-29 03:17:26 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 03:17:26 --> Language Class Initialized
DEBUG - 2010-06-29 03:17:26 --> Loader Class Initialized
DEBUG - 2010-06-29 03:17:26 --> Helper loaded: context_helper
DEBUG - 2010-06-29 03:17:26 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 03:17:26 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 03:17:26 --> Database Driver Class Initialized
DEBUG - 2010-06-29 03:17:26 --> Controller Class Initialized
DEBUG - 2010-06-29 03:17:26 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 03:17:26 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 03:17:26 --> Session Class Initialized
DEBUG - 2010-06-29 03:17:26 --> Helper loaded: string_helper
DEBUG - 2010-06-29 03:17:26 --> Session routines successfully run
DEBUG - 2010-06-29 03:17:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:17:27 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 03:17:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:17:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:17:27 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 03:17:27 --> Final output sent to browser
DEBUG - 2010-06-29 03:17:27 --> Total execution time: 1.5451
DEBUG - 2010-06-29 03:18:52 --> Config Class Initialized
DEBUG - 2010-06-29 03:18:52 --> Hooks Class Initialized
DEBUG - 2010-06-29 03:18:52 --> URI Class Initialized
DEBUG - 2010-06-29 03:18:52 --> Router Class Initialized
DEBUG - 2010-06-29 03:18:52 --> Output Class Initialized
DEBUG - 2010-06-29 03:18:52 --> Input Class Initialized
DEBUG - 2010-06-29 03:18:52 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 03:18:52 --> Language Class Initialized
DEBUG - 2010-06-29 03:18:52 --> Loader Class Initialized
DEBUG - 2010-06-29 03:18:52 --> Helper loaded: context_helper
DEBUG - 2010-06-29 03:18:52 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 03:18:52 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 03:18:52 --> Database Driver Class Initialized
DEBUG - 2010-06-29 03:18:52 --> Controller Class Initialized
DEBUG - 2010-06-29 03:18:52 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 03:18:52 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 03:18:52 --> Session Class Initialized
DEBUG - 2010-06-29 03:18:52 --> Helper loaded: string_helper
DEBUG - 2010-06-29 03:18:52 --> Session routines successfully run
DEBUG - 2010-06-29 03:18:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:18:53 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 03:18:53 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-29 03:18:53 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  relation &quot;161&quot; does not exist
LINE 2: FROM &quot;161&quot;
             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-29 03:18:53 --> DB Transaction Failure
ERROR - 2010-06-29 03:18:53 --> Query error: ERROR:  relation "161" does not exist
LINE 2: FROM "161"
             ^
DEBUG - 2010-06-29 03:18:53 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-06-29 03:18:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Webpage.php:74) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-29 03:19:58 --> Config Class Initialized
DEBUG - 2010-06-29 03:19:58 --> Hooks Class Initialized
DEBUG - 2010-06-29 03:19:58 --> URI Class Initialized
DEBUG - 2010-06-29 03:19:58 --> Router Class Initialized
DEBUG - 2010-06-29 03:19:58 --> Output Class Initialized
DEBUG - 2010-06-29 03:19:58 --> Input Class Initialized
DEBUG - 2010-06-29 03:19:58 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 03:19:58 --> Language Class Initialized
DEBUG - 2010-06-29 03:19:58 --> Loader Class Initialized
DEBUG - 2010-06-29 03:19:58 --> Helper loaded: context_helper
DEBUG - 2010-06-29 03:19:58 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 03:19:58 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 03:19:58 --> Database Driver Class Initialized
DEBUG - 2010-06-29 03:19:58 --> Controller Class Initialized
DEBUG - 2010-06-29 03:19:58 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 03:19:58 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 03:19:58 --> Session Class Initialized
DEBUG - 2010-06-29 03:19:58 --> Helper loaded: string_helper
DEBUG - 2010-06-29 03:19:58 --> Session routines successfully run
DEBUG - 2010-06-29 03:19:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:19:59 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 03:19:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:19:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:19:59 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 03:20:00 --> Final output sent to browser
DEBUG - 2010-06-29 03:20:00 --> Total execution time: 1.5989
DEBUG - 2010-06-29 03:20:12 --> Config Class Initialized
DEBUG - 2010-06-29 03:20:12 --> Hooks Class Initialized
DEBUG - 2010-06-29 03:20:12 --> URI Class Initialized
DEBUG - 2010-06-29 03:20:12 --> Router Class Initialized
DEBUG - 2010-06-29 03:20:12 --> Output Class Initialized
DEBUG - 2010-06-29 03:20:12 --> Input Class Initialized
DEBUG - 2010-06-29 03:20:12 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 03:20:12 --> Language Class Initialized
DEBUG - 2010-06-29 03:20:12 --> Loader Class Initialized
DEBUG - 2010-06-29 03:20:12 --> Helper loaded: context_helper
DEBUG - 2010-06-29 03:20:12 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 03:20:12 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 03:20:12 --> Database Driver Class Initialized
DEBUG - 2010-06-29 03:20:12 --> Controller Class Initialized
DEBUG - 2010-06-29 03:20:12 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 03:20:12 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 03:20:12 --> Session Class Initialized
DEBUG - 2010-06-29 03:20:12 --> Helper loaded: string_helper
DEBUG - 2010-06-29 03:20:12 --> Session routines successfully run
DEBUG - 2010-06-29 03:20:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:20:14 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 03:20:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:20:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:20:14 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 03:20:14 --> Final output sent to browser
DEBUG - 2010-06-29 03:20:14 --> Total execution time: 2.2358
DEBUG - 2010-06-29 03:21:33 --> Config Class Initialized
DEBUG - 2010-06-29 03:21:33 --> Hooks Class Initialized
DEBUG - 2010-06-29 03:21:33 --> URI Class Initialized
DEBUG - 2010-06-29 03:21:33 --> Router Class Initialized
DEBUG - 2010-06-29 03:21:33 --> Output Class Initialized
DEBUG - 2010-06-29 03:21:33 --> Input Class Initialized
DEBUG - 2010-06-29 03:21:33 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 03:21:33 --> Language Class Initialized
DEBUG - 2010-06-29 03:21:33 --> Loader Class Initialized
DEBUG - 2010-06-29 03:21:33 --> Helper loaded: context_helper
DEBUG - 2010-06-29 03:21:33 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 03:21:33 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 03:21:33 --> Database Driver Class Initialized
DEBUG - 2010-06-29 03:21:33 --> Controller Class Initialized
DEBUG - 2010-06-29 03:21:33 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 03:21:33 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 03:21:33 --> Session Class Initialized
DEBUG - 2010-06-29 03:21:33 --> Helper loaded: string_helper
DEBUG - 2010-06-29 03:21:33 --> Session routines successfully run
DEBUG - 2010-06-29 03:21:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:21:34 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 03:21:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:21:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:21:34 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 03:21:34 --> Final output sent to browser
DEBUG - 2010-06-29 03:21:34 --> Total execution time: 1.5443
DEBUG - 2010-06-29 03:22:04 --> Config Class Initialized
DEBUG - 2010-06-29 03:22:04 --> Hooks Class Initialized
DEBUG - 2010-06-29 03:22:04 --> URI Class Initialized
DEBUG - 2010-06-29 03:22:04 --> Router Class Initialized
DEBUG - 2010-06-29 03:22:04 --> Output Class Initialized
DEBUG - 2010-06-29 03:22:04 --> Input Class Initialized
DEBUG - 2010-06-29 03:22:04 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 03:22:04 --> Language Class Initialized
DEBUG - 2010-06-29 03:22:04 --> Loader Class Initialized
DEBUG - 2010-06-29 03:22:04 --> Helper loaded: context_helper
DEBUG - 2010-06-29 03:22:04 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 03:22:04 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 03:22:04 --> Database Driver Class Initialized
DEBUG - 2010-06-29 03:22:04 --> Controller Class Initialized
DEBUG - 2010-06-29 03:22:04 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 03:22:04 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 03:22:04 --> Session Class Initialized
DEBUG - 2010-06-29 03:22:04 --> Helper loaded: string_helper
DEBUG - 2010-06-29 03:22:04 --> Session routines successfully run
DEBUG - 2010-06-29 03:22:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:22:05 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 03:22:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:22:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:22:05 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 03:22:05 --> Final output sent to browser
DEBUG - 2010-06-29 03:22:05 --> Total execution time: 1.6515
DEBUG - 2010-06-29 03:22:22 --> Config Class Initialized
DEBUG - 2010-06-29 03:22:22 --> Hooks Class Initialized
DEBUG - 2010-06-29 03:22:22 --> URI Class Initialized
DEBUG - 2010-06-29 03:22:22 --> Router Class Initialized
DEBUG - 2010-06-29 03:22:22 --> Output Class Initialized
DEBUG - 2010-06-29 03:22:22 --> Input Class Initialized
DEBUG - 2010-06-29 03:22:22 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 03:22:22 --> Language Class Initialized
DEBUG - 2010-06-29 03:22:22 --> Loader Class Initialized
DEBUG - 2010-06-29 03:22:22 --> Helper loaded: context_helper
DEBUG - 2010-06-29 03:22:22 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 03:22:22 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 03:22:22 --> Database Driver Class Initialized
DEBUG - 2010-06-29 03:22:22 --> Controller Class Initialized
DEBUG - 2010-06-29 03:22:22 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 03:22:22 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 03:22:23 --> Session Class Initialized
DEBUG - 2010-06-29 03:22:23 --> Helper loaded: string_helper
DEBUG - 2010-06-29 03:22:23 --> Session routines successfully run
DEBUG - 2010-06-29 03:22:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:22:23 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 03:22:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:22:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:22:24 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 03:22:24 --> Final output sent to browser
DEBUG - 2010-06-29 03:22:24 --> Total execution time: 1.5207
DEBUG - 2010-06-29 03:23:12 --> Config Class Initialized
DEBUG - 2010-06-29 03:23:12 --> Hooks Class Initialized
DEBUG - 2010-06-29 03:23:12 --> URI Class Initialized
DEBUG - 2010-06-29 03:23:12 --> Router Class Initialized
DEBUG - 2010-06-29 03:23:12 --> Output Class Initialized
DEBUG - 2010-06-29 03:23:12 --> Input Class Initialized
DEBUG - 2010-06-29 03:23:12 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 03:23:12 --> Language Class Initialized
DEBUG - 2010-06-29 03:23:12 --> Loader Class Initialized
DEBUG - 2010-06-29 03:23:13 --> Helper loaded: context_helper
DEBUG - 2010-06-29 03:23:13 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 03:23:13 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 03:23:13 --> Database Driver Class Initialized
DEBUG - 2010-06-29 03:23:13 --> Controller Class Initialized
DEBUG - 2010-06-29 03:23:13 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 03:23:13 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 03:23:13 --> Session Class Initialized
DEBUG - 2010-06-29 03:23:13 --> Helper loaded: string_helper
DEBUG - 2010-06-29 03:23:13 --> Session routines successfully run
DEBUG - 2010-06-29 03:23:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:23:14 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 03:23:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:23:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:23:14 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 03:23:14 --> Final output sent to browser
DEBUG - 2010-06-29 03:23:14 --> Total execution time: 1.7160
DEBUG - 2010-06-29 03:23:31 --> Config Class Initialized
DEBUG - 2010-06-29 03:23:31 --> Hooks Class Initialized
DEBUG - 2010-06-29 03:23:31 --> URI Class Initialized
DEBUG - 2010-06-29 03:23:31 --> Router Class Initialized
DEBUG - 2010-06-29 03:23:31 --> Output Class Initialized
DEBUG - 2010-06-29 03:23:31 --> Input Class Initialized
DEBUG - 2010-06-29 03:23:31 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 03:23:31 --> Language Class Initialized
DEBUG - 2010-06-29 03:23:31 --> Loader Class Initialized
DEBUG - 2010-06-29 03:23:31 --> Helper loaded: context_helper
DEBUG - 2010-06-29 03:23:31 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 03:23:31 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 03:23:31 --> Database Driver Class Initialized
DEBUG - 2010-06-29 03:23:31 --> Controller Class Initialized
DEBUG - 2010-06-29 03:23:31 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 03:23:31 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 03:23:31 --> Session Class Initialized
DEBUG - 2010-06-29 03:23:31 --> Helper loaded: string_helper
DEBUG - 2010-06-29 03:23:31 --> Session routines successfully run
DEBUG - 2010-06-29 03:23:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:23:32 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 03:23:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:23:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:23:32 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 03:23:32 --> Final output sent to browser
DEBUG - 2010-06-29 03:23:32 --> Total execution time: 1.5336
DEBUG - 2010-06-29 03:23:43 --> Config Class Initialized
DEBUG - 2010-06-29 03:23:43 --> Hooks Class Initialized
DEBUG - 2010-06-29 03:23:43 --> URI Class Initialized
DEBUG - 2010-06-29 03:23:43 --> Router Class Initialized
DEBUG - 2010-06-29 03:23:43 --> Output Class Initialized
DEBUG - 2010-06-29 03:23:43 --> Input Class Initialized
DEBUG - 2010-06-29 03:23:44 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 03:23:44 --> Language Class Initialized
DEBUG - 2010-06-29 03:23:44 --> Loader Class Initialized
DEBUG - 2010-06-29 03:23:44 --> Helper loaded: context_helper
DEBUG - 2010-06-29 03:23:44 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 03:23:44 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 03:23:44 --> Database Driver Class Initialized
DEBUG - 2010-06-29 03:23:44 --> Controller Class Initialized
DEBUG - 2010-06-29 03:23:44 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 03:23:44 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 03:23:44 --> Session Class Initialized
DEBUG - 2010-06-29 03:23:44 --> Helper loaded: string_helper
DEBUG - 2010-06-29 03:23:44 --> Session routines successfully run
DEBUG - 2010-06-29 03:23:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:23:45 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 03:23:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:23:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 03:23:45 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 03:23:45 --> Final output sent to browser
DEBUG - 2010-06-29 03:23:45 --> Total execution time: 1.6753
DEBUG - 2010-06-29 11:30:45 --> Config Class Initialized
DEBUG - 2010-06-29 11:30:45 --> Hooks Class Initialized
DEBUG - 2010-06-29 11:30:45 --> URI Class Initialized
DEBUG - 2010-06-29 11:30:45 --> Router Class Initialized
DEBUG - 2010-06-29 11:30:45 --> Output Class Initialized
DEBUG - 2010-06-29 11:30:45 --> Input Class Initialized
DEBUG - 2010-06-29 11:30:45 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 11:30:45 --> Language Class Initialized
DEBUG - 2010-06-29 11:30:46 --> Loader Class Initialized
DEBUG - 2010-06-29 11:30:46 --> Helper loaded: context_helper
DEBUG - 2010-06-29 11:30:46 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 11:30:46 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 11:30:46 --> Database Driver Class Initialized
DEBUG - 2010-06-29 11:30:46 --> Controller Class Initialized
DEBUG - 2010-06-29 11:30:46 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 11:30:46 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 11:30:46 --> Helper loaded: cookie_helper
DEBUG - 2010-06-29 11:30:46 --> Session Class Initialized
DEBUG - 2010-06-29 11:30:46 --> Helper loaded: string_helper
DEBUG - 2010-06-29 11:30:46 --> A session cookie was not found.
DEBUG - 2010-06-29 11:30:46 --> Session routines successfully run
ERROR - 2010-06-29 11:30:47 --> Severity: Notice  --> Undefined index:  url D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 267
DEBUG - 2010-06-29 11:30:47 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-29 11:30:47 --> Severity: Notice  --> Undefined index:  url D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 267
ERROR - 2010-06-29 11:30:47 --> Severity: Notice  --> Undefined index:  url D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 267
DEBUG - 2010-06-29 11:30:48 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 11:30:48 --> Final output sent to browser
DEBUG - 2010-06-29 11:30:48 --> Total execution time: 2.6152
DEBUG - 2010-06-29 11:33:10 --> Config Class Initialized
DEBUG - 2010-06-29 11:33:10 --> Hooks Class Initialized
DEBUG - 2010-06-29 11:33:10 --> URI Class Initialized
DEBUG - 2010-06-29 11:33:10 --> Router Class Initialized
DEBUG - 2010-06-29 11:33:10 --> Output Class Initialized
DEBUG - 2010-06-29 11:33:10 --> Input Class Initialized
DEBUG - 2010-06-29 11:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 11:33:10 --> Language Class Initialized
DEBUG - 2010-06-29 11:33:10 --> Loader Class Initialized
DEBUG - 2010-06-29 11:33:11 --> Helper loaded: context_helper
DEBUG - 2010-06-29 11:33:11 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 11:33:11 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 11:33:11 --> Database Driver Class Initialized
DEBUG - 2010-06-29 11:33:11 --> Controller Class Initialized
DEBUG - 2010-06-29 11:33:11 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 11:33:11 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 11:33:11 --> Helper loaded: cookie_helper
DEBUG - 2010-06-29 11:33:11 --> Session Class Initialized
DEBUG - 2010-06-29 11:33:11 --> Helper loaded: string_helper
DEBUG - 2010-06-29 11:33:11 --> Session routines successfully run
DEBUG - 2010-06-29 11:33:18 --> Config Class Initialized
DEBUG - 2010-06-29 11:33:18 --> Hooks Class Initialized
DEBUG - 2010-06-29 11:33:18 --> URI Class Initialized
DEBUG - 2010-06-29 11:33:18 --> Router Class Initialized
DEBUG - 2010-06-29 11:33:18 --> Output Class Initialized
DEBUG - 2010-06-29 11:33:18 --> Input Class Initialized
DEBUG - 2010-06-29 11:33:18 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 11:33:19 --> Language Class Initialized
DEBUG - 2010-06-29 11:33:19 --> Loader Class Initialized
DEBUG - 2010-06-29 11:33:19 --> Helper loaded: context_helper
DEBUG - 2010-06-29 11:33:19 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 11:33:19 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 11:33:19 --> Database Driver Class Initialized
DEBUG - 2010-06-29 11:33:19 --> Controller Class Initialized
DEBUG - 2010-06-29 11:33:19 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 11:33:19 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 11:33:19 --> Helper loaded: cookie_helper
DEBUG - 2010-06-29 11:33:19 --> Session Class Initialized
DEBUG - 2010-06-29 11:33:19 --> Helper loaded: string_helper
DEBUG - 2010-06-29 11:33:19 --> Session routines successfully run
DEBUG - 2010-06-29 11:33:19 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 11:33:20 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 11:33:20 --> Final output sent to browser
DEBUG - 2010-06-29 11:33:20 --> Total execution time: 1.5422
DEBUG - 2010-06-29 11:33:23 --> Config Class Initialized
DEBUG - 2010-06-29 11:33:23 --> Hooks Class Initialized
DEBUG - 2010-06-29 11:33:23 --> URI Class Initialized
DEBUG - 2010-06-29 11:33:23 --> Router Class Initialized
DEBUG - 2010-06-29 11:33:23 --> Output Class Initialized
DEBUG - 2010-06-29 11:33:23 --> Input Class Initialized
DEBUG - 2010-06-29 11:33:23 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 11:33:23 --> Language Class Initialized
DEBUG - 2010-06-29 11:33:23 --> Loader Class Initialized
DEBUG - 2010-06-29 11:33:23 --> Helper loaded: context_helper
DEBUG - 2010-06-29 11:33:23 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 11:33:23 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 11:33:23 --> Database Driver Class Initialized
DEBUG - 2010-06-29 11:33:23 --> Controller Class Initialized
DEBUG - 2010-06-29 11:33:23 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 11:33:23 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 11:33:23 --> Session Class Initialized
DEBUG - 2010-06-29 11:33:23 --> Helper loaded: string_helper
DEBUG - 2010-06-29 11:33:23 --> Session routines successfully run
DEBUG - 2010-06-29 11:33:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 11:33:25 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 11:33:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 11:33:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 11:33:25 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 11:33:25 --> Final output sent to browser
DEBUG - 2010-06-29 11:33:25 --> Total execution time: 2.3319
DEBUG - 2010-06-29 11:58:48 --> Config Class Initialized
DEBUG - 2010-06-29 11:58:48 --> Hooks Class Initialized
DEBUG - 2010-06-29 11:58:48 --> URI Class Initialized
DEBUG - 2010-06-29 11:58:48 --> Router Class Initialized
DEBUG - 2010-06-29 11:58:48 --> Output Class Initialized
DEBUG - 2010-06-29 11:58:48 --> Input Class Initialized
DEBUG - 2010-06-29 11:58:48 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 11:58:48 --> Language Class Initialized
DEBUG - 2010-06-29 11:58:48 --> Loader Class Initialized
DEBUG - 2010-06-29 11:58:49 --> Helper loaded: context_helper
DEBUG - 2010-06-29 11:58:49 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 11:58:49 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 11:58:49 --> Database Driver Class Initialized
DEBUG - 2010-06-29 11:58:49 --> Controller Class Initialized
DEBUG - 2010-06-29 11:58:49 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 11:58:49 --> Helper loaded: unit_test_helper
ERROR - 2010-06-29 11:58:49 --> Severity: Warning  --> include_once(KALSActor.php) [<a href='function.include-once'>function.include-once</a>]: failed to open stream: No such file or directory D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 3
ERROR - 2010-06-29 11:58:49 --> Severity: Warning  --> include_once() [<a href='function.include'>function.include</a>]: Failed opening 'KALSActor.php' for inclusion (include_path='.;D:\xampp\php\pear\') D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 3
DEBUG - 2010-06-29 11:59:03 --> Config Class Initialized
DEBUG - 2010-06-29 11:59:03 --> Hooks Class Initialized
DEBUG - 2010-06-29 11:59:03 --> URI Class Initialized
DEBUG - 2010-06-29 11:59:03 --> Router Class Initialized
DEBUG - 2010-06-29 11:59:03 --> Output Class Initialized
DEBUG - 2010-06-29 11:59:03 --> Input Class Initialized
DEBUG - 2010-06-29 11:59:03 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 11:59:04 --> Language Class Initialized
DEBUG - 2010-06-29 11:59:04 --> Loader Class Initialized
DEBUG - 2010-06-29 11:59:04 --> Helper loaded: context_helper
DEBUG - 2010-06-29 11:59:04 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 11:59:04 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 11:59:04 --> Database Driver Class Initialized
DEBUG - 2010-06-29 11:59:04 --> Controller Class Initialized
DEBUG - 2010-06-29 11:59:04 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 11:59:04 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 11:59:20 --> Config Class Initialized
DEBUG - 2010-06-29 11:59:20 --> Hooks Class Initialized
DEBUG - 2010-06-29 11:59:21 --> URI Class Initialized
DEBUG - 2010-06-29 11:59:21 --> Router Class Initialized
DEBUG - 2010-06-29 11:59:21 --> Output Class Initialized
DEBUG - 2010-06-29 11:59:21 --> Input Class Initialized
DEBUG - 2010-06-29 11:59:21 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 11:59:21 --> Language Class Initialized
DEBUG - 2010-06-29 11:59:21 --> Loader Class Initialized
DEBUG - 2010-06-29 11:59:21 --> Helper loaded: context_helper
DEBUG - 2010-06-29 11:59:21 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 11:59:21 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 11:59:21 --> Database Driver Class Initialized
DEBUG - 2010-06-29 11:59:21 --> Controller Class Initialized
DEBUG - 2010-06-29 11:59:21 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 11:59:21 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 11:59:30 --> Config Class Initialized
DEBUG - 2010-06-29 11:59:30 --> Hooks Class Initialized
DEBUG - 2010-06-29 11:59:30 --> URI Class Initialized
DEBUG - 2010-06-29 11:59:30 --> Router Class Initialized
DEBUG - 2010-06-29 11:59:30 --> Output Class Initialized
DEBUG - 2010-06-29 11:59:30 --> Input Class Initialized
DEBUG - 2010-06-29 11:59:30 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 11:59:30 --> Language Class Initialized
DEBUG - 2010-06-29 11:59:30 --> Loader Class Initialized
DEBUG - 2010-06-29 11:59:30 --> Helper loaded: context_helper
DEBUG - 2010-06-29 11:59:30 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 11:59:30 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 11:59:30 --> Database Driver Class Initialized
DEBUG - 2010-06-29 11:59:30 --> Controller Class Initialized
DEBUG - 2010-06-29 11:59:30 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 11:59:30 --> Helper loaded: unit_test_helper
ERROR - 2010-06-29 11:59:30 --> Unable to load the requested class: group
DEBUG - 2010-06-29 12:01:25 --> Config Class Initialized
DEBUG - 2010-06-29 12:01:25 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:01:25 --> URI Class Initialized
DEBUG - 2010-06-29 12:01:25 --> Router Class Initialized
DEBUG - 2010-06-29 12:01:25 --> Output Class Initialized
DEBUG - 2010-06-29 12:01:25 --> Input Class Initialized
DEBUG - 2010-06-29 12:01:26 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:01:26 --> Language Class Initialized
DEBUG - 2010-06-29 12:01:26 --> Loader Class Initialized
DEBUG - 2010-06-29 12:01:26 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:01:26 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:01:26 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:01:26 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:01:26 --> Controller Class Initialized
DEBUG - 2010-06-29 12:01:26 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:01:26 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:01:37 --> Config Class Initialized
DEBUG - 2010-06-29 12:01:37 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:01:37 --> URI Class Initialized
DEBUG - 2010-06-29 12:01:37 --> Router Class Initialized
DEBUG - 2010-06-29 12:01:37 --> Output Class Initialized
DEBUG - 2010-06-29 12:01:37 --> Input Class Initialized
DEBUG - 2010-06-29 12:01:37 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:01:37 --> Language Class Initialized
DEBUG - 2010-06-29 12:01:37 --> Loader Class Initialized
DEBUG - 2010-06-29 12:01:37 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:01:37 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:01:37 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:01:37 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:01:37 --> Controller Class Initialized
DEBUG - 2010-06-29 12:01:38 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:01:38 --> Helper loaded: unit_test_helper
ERROR - 2010-06-29 12:01:38 --> Severity: Warning  --> Missing argument 1 for KALS_actor::__construct(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Loader.php on line 928 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\KALS_actor.php 23
ERROR - 2010-06-29 12:01:38 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\KALS_actor.php 25
DEBUG - 2010-06-29 12:01:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:01:38 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:01:38 --> Helper loaded: email_helper
DEBUG - 2010-06-29 12:01:38 --> User Agent Class Initialized
DEBUG - 2010-06-29 12:01:38 --> Session Class Initialized
DEBUG - 2010-06-29 12:01:38 --> Helper loaded: string_helper
ERROR - 2010-06-29 12:01:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Session.php 662
DEBUG - 2010-06-29 12:01:38 --> Session routines successfully run
ERROR - 2010-06-29 12:01:38 --> Severity: Notice  --> Undefined property: Ut_user::$email D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_actor\ut_user.php 44
DEBUG - 2010-06-29 12:02:08 --> Config Class Initialized
DEBUG - 2010-06-29 12:02:08 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:02:08 --> URI Class Initialized
DEBUG - 2010-06-29 12:02:08 --> Router Class Initialized
DEBUG - 2010-06-29 12:02:08 --> Output Class Initialized
DEBUG - 2010-06-29 12:02:08 --> Input Class Initialized
DEBUG - 2010-06-29 12:02:08 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:02:08 --> Language Class Initialized
DEBUG - 2010-06-29 12:02:08 --> Loader Class Initialized
DEBUG - 2010-06-29 12:02:08 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:02:08 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:02:08 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:02:08 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:02:08 --> Controller Class Initialized
DEBUG - 2010-06-29 12:02:08 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:02:08 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:02:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:02:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:02:08 --> Helper loaded: email_helper
DEBUG - 2010-06-29 12:02:08 --> User Agent Class Initialized
DEBUG - 2010-06-29 12:02:08 --> Session Class Initialized
DEBUG - 2010-06-29 12:02:09 --> Helper loaded: string_helper
DEBUG - 2010-06-29 12:02:09 --> Session routines successfully run
ERROR - 2010-06-29 12:02:09 --> Severity: Notice  --> Undefined property: Ut_user::$email D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_actor\ut_user.php 44
DEBUG - 2010-06-29 12:02:26 --> Config Class Initialized
DEBUG - 2010-06-29 12:02:26 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:02:26 --> URI Class Initialized
DEBUG - 2010-06-29 12:02:26 --> Router Class Initialized
DEBUG - 2010-06-29 12:02:26 --> Output Class Initialized
DEBUG - 2010-06-29 12:02:26 --> Input Class Initialized
DEBUG - 2010-06-29 12:02:26 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:02:26 --> Language Class Initialized
DEBUG - 2010-06-29 12:02:26 --> Loader Class Initialized
DEBUG - 2010-06-29 12:02:26 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:02:26 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:02:26 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:02:26 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:02:26 --> Controller Class Initialized
DEBUG - 2010-06-29 12:02:27 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:02:27 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:02:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:02:27 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:02:27 --> Helper loaded: email_helper
DEBUG - 2010-06-29 12:02:27 --> User Agent Class Initialized
DEBUG - 2010-06-29 12:02:27 --> Session Class Initialized
DEBUG - 2010-06-29 12:02:27 --> Helper loaded: string_helper
DEBUG - 2010-06-29 12:02:27 --> Session routines successfully run
DEBUG - 2010-06-29 12:02:58 --> Config Class Initialized
DEBUG - 2010-06-29 12:02:58 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:02:58 --> URI Class Initialized
DEBUG - 2010-06-29 12:02:59 --> Router Class Initialized
DEBUG - 2010-06-29 12:02:59 --> Output Class Initialized
DEBUG - 2010-06-29 12:02:59 --> Input Class Initialized
DEBUG - 2010-06-29 12:02:59 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:02:59 --> Language Class Initialized
DEBUG - 2010-06-29 12:02:59 --> Loader Class Initialized
DEBUG - 2010-06-29 12:02:59 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:02:59 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:02:59 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:02:59 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:02:59 --> Controller Class Initialized
DEBUG - 2010-06-29 12:02:59 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:02:59 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:02:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:02:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:02:59 --> Helper loaded: email_helper
DEBUG - 2010-06-29 12:02:59 --> User Agent Class Initialized
DEBUG - 2010-06-29 12:02:59 --> Session Class Initialized
DEBUG - 2010-06-29 12:02:59 --> Helper loaded: string_helper
DEBUG - 2010-06-29 12:02:59 --> Session routines successfully run
ERROR - 2010-06-29 12:03:00 --> Severity: Warning  --> Missing argument 2 for User::find(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php on line 784 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 115
ERROR - 2010-06-29 12:03:00 --> Severity: Notice  --> Undefined variable: keyword D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\User.php 142
ERROR - 2010-06-29 12:03:00 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  operator does not exist: boolean = integer
LINE 5: AND &quot;deleted&quot; = 0
                      ^
HINT:  No operator matches the given name and argument type(s). You might need to add explicit type casts. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-29 12:03:00 --> DB Transaction Failure
ERROR - 2010-06-29 12:03:00 --> Query error: ERROR:  operator does not exist: boolean = integer
LINE 5: AND "deleted" = 0
                      ^
HINT:  No operator matches the given name and argument type(s). You might need to add explicit type casts.
DEBUG - 2010-06-29 12:03:00 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-06-29 12:03:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-29 12:11:51 --> Config Class Initialized
DEBUG - 2010-06-29 12:11:51 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:11:51 --> URI Class Initialized
DEBUG - 2010-06-29 12:11:51 --> Router Class Initialized
DEBUG - 2010-06-29 12:11:51 --> Output Class Initialized
DEBUG - 2010-06-29 12:11:51 --> Input Class Initialized
DEBUG - 2010-06-29 12:11:51 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:11:51 --> Language Class Initialized
DEBUG - 2010-06-29 12:11:51 --> Loader Class Initialized
DEBUG - 2010-06-29 12:11:51 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:11:51 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:11:51 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:11:52 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:11:52 --> Controller Class Initialized
DEBUG - 2010-06-29 12:11:52 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:11:52 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:11:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:11:52 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:11:52 --> Helper loaded: email_helper
DEBUG - 2010-06-29 12:11:52 --> User Agent Class Initialized
DEBUG - 2010-06-29 12:11:52 --> Session Class Initialized
DEBUG - 2010-06-29 12:11:52 --> Helper loaded: string_helper
DEBUG - 2010-06-29 12:11:52 --> Session routines successfully run
DEBUG - 2010-06-29 12:11:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:11:52 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:11:52 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:11:52 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 12:12:08 --> Config Class Initialized
DEBUG - 2010-06-29 12:12:08 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:12:08 --> URI Class Initialized
DEBUG - 2010-06-29 12:12:09 --> Router Class Initialized
DEBUG - 2010-06-29 12:12:09 --> Output Class Initialized
DEBUG - 2010-06-29 12:12:09 --> Input Class Initialized
DEBUG - 2010-06-29 12:12:09 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:12:09 --> Language Class Initialized
DEBUG - 2010-06-29 12:12:09 --> Loader Class Initialized
DEBUG - 2010-06-29 12:12:09 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:12:09 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:12:09 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:12:09 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:12:09 --> Controller Class Initialized
DEBUG - 2010-06-29 12:12:09 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:12:09 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:12:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:12:09 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:12:09 --> Helper loaded: email_helper
DEBUG - 2010-06-29 12:12:09 --> User Agent Class Initialized
DEBUG - 2010-06-29 12:12:09 --> Session Class Initialized
DEBUG - 2010-06-29 12:12:09 --> Helper loaded: string_helper
DEBUG - 2010-06-29 12:12:09 --> Session routines successfully run
DEBUG - 2010-06-29 12:12:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:12:09 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:12:09 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:12:09 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 12:12:10 --> Config file loaded: config/kals.php
ERROR - 2010-06-29 12:12:10 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  operator does not exist: boolean = integer
LINE 4: AND &quot;deleted&quot; = 0
                      ^
HINT:  No operator matches the given name and argument type(s). You might need to add explicit type casts. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-29 12:12:10 --> DB Transaction Failure
ERROR - 2010-06-29 12:12:10 --> Query error: ERROR:  operator does not exist: boolean = integer
LINE 4: AND "deleted" = 0
                      ^
HINT:  No operator matches the given name and argument type(s). You might need to add explicit type casts.
DEBUG - 2010-06-29 12:12:10 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-06-29 12:13:01 --> Config Class Initialized
DEBUG - 2010-06-29 12:13:02 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:13:02 --> URI Class Initialized
DEBUG - 2010-06-29 12:13:02 --> Router Class Initialized
DEBUG - 2010-06-29 12:13:02 --> Output Class Initialized
DEBUG - 2010-06-29 12:13:02 --> Input Class Initialized
DEBUG - 2010-06-29 12:13:02 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:13:02 --> Language Class Initialized
DEBUG - 2010-06-29 12:13:02 --> Loader Class Initialized
DEBUG - 2010-06-29 12:13:02 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:13:02 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:13:02 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:13:02 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:13:02 --> Controller Class Initialized
DEBUG - 2010-06-29 12:13:02 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:13:02 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:13:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:13:02 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:13:02 --> Helper loaded: email_helper
DEBUG - 2010-06-29 12:13:02 --> User Agent Class Initialized
DEBUG - 2010-06-29 12:13:02 --> Session Class Initialized
DEBUG - 2010-06-29 12:13:02 --> Helper loaded: string_helper
DEBUG - 2010-06-29 12:13:02 --> Session routines successfully run
DEBUG - 2010-06-29 12:13:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:13:03 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:13:03 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:13:03 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 12:13:03 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 12:16:31 --> Config Class Initialized
DEBUG - 2010-06-29 12:16:31 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:16:31 --> URI Class Initialized
DEBUG - 2010-06-29 12:16:31 --> Router Class Initialized
DEBUG - 2010-06-29 12:16:31 --> Output Class Initialized
DEBUG - 2010-06-29 12:16:31 --> Input Class Initialized
DEBUG - 2010-06-29 12:16:31 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:16:31 --> Language Class Initialized
DEBUG - 2010-06-29 12:16:31 --> Loader Class Initialized
DEBUG - 2010-06-29 12:16:31 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:16:31 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:16:31 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:16:31 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:16:31 --> Controller Class Initialized
DEBUG - 2010-06-29 12:16:31 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:16:31 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:16:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:16:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:16:31 --> Helper loaded: email_helper
DEBUG - 2010-06-29 12:16:31 --> User Agent Class Initialized
DEBUG - 2010-06-29 12:16:32 --> Session Class Initialized
DEBUG - 2010-06-29 12:16:32 --> Helper loaded: string_helper
DEBUG - 2010-06-29 12:16:32 --> Session routines successfully run
DEBUG - 2010-06-29 12:16:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:16:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:16:32 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:16:32 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 12:16:32 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 12:16:32 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 12:16:32 --> Final output sent to browser
DEBUG - 2010-06-29 12:16:32 --> Total execution time: 1.1427
DEBUG - 2010-06-29 12:17:11 --> Config Class Initialized
DEBUG - 2010-06-29 12:17:11 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:17:11 --> URI Class Initialized
DEBUG - 2010-06-29 12:17:11 --> Router Class Initialized
DEBUG - 2010-06-29 12:17:11 --> Output Class Initialized
DEBUG - 2010-06-29 12:17:11 --> Input Class Initialized
DEBUG - 2010-06-29 12:17:11 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:17:11 --> Language Class Initialized
DEBUG - 2010-06-29 12:17:11 --> Loader Class Initialized
DEBUG - 2010-06-29 12:17:11 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:17:11 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:17:11 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:17:11 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:17:11 --> Controller Class Initialized
DEBUG - 2010-06-29 12:17:11 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:17:11 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:17:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:17:11 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:17:12 --> Helper loaded: email_helper
DEBUG - 2010-06-29 12:17:12 --> User Agent Class Initialized
DEBUG - 2010-06-29 12:17:12 --> Session Class Initialized
DEBUG - 2010-06-29 12:17:12 --> Helper loaded: string_helper
DEBUG - 2010-06-29 12:17:12 --> Session routines successfully run
DEBUG - 2010-06-29 12:17:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:17:12 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:17:12 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:17:12 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 12:17:12 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 12:17:25 --> Config Class Initialized
DEBUG - 2010-06-29 12:17:25 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:17:26 --> URI Class Initialized
DEBUG - 2010-06-29 12:17:26 --> Router Class Initialized
DEBUG - 2010-06-29 12:17:26 --> Output Class Initialized
DEBUG - 2010-06-29 12:17:26 --> Input Class Initialized
DEBUG - 2010-06-29 12:17:26 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:17:26 --> Language Class Initialized
DEBUG - 2010-06-29 12:17:26 --> Loader Class Initialized
DEBUG - 2010-06-29 12:17:26 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:17:26 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:17:26 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:17:26 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:17:26 --> Controller Class Initialized
DEBUG - 2010-06-29 12:17:26 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:17:26 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:17:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:17:26 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:17:26 --> Helper loaded: email_helper
DEBUG - 2010-06-29 12:17:26 --> User Agent Class Initialized
DEBUG - 2010-06-29 12:17:26 --> Session Class Initialized
DEBUG - 2010-06-29 12:17:26 --> Helper loaded: string_helper
DEBUG - 2010-06-29 12:17:26 --> Session routines successfully run
DEBUG - 2010-06-29 12:17:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:17:27 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:17:27 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:17:27 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 12:17:27 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 12:17:27 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 12:17:27 --> Final output sent to browser
DEBUG - 2010-06-29 12:17:28 --> Total execution time: 2.0176
DEBUG - 2010-06-29 12:18:48 --> Config Class Initialized
DEBUG - 2010-06-29 12:18:48 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:18:48 --> URI Class Initialized
DEBUG - 2010-06-29 12:18:48 --> Router Class Initialized
DEBUG - 2010-06-29 12:18:48 --> Output Class Initialized
DEBUG - 2010-06-29 12:18:48 --> Input Class Initialized
DEBUG - 2010-06-29 12:18:48 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:18:48 --> Language Class Initialized
DEBUG - 2010-06-29 12:18:48 --> Loader Class Initialized
DEBUG - 2010-06-29 12:18:48 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:18:48 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:18:48 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:18:48 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:18:48 --> Controller Class Initialized
DEBUG - 2010-06-29 12:18:48 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:18:48 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:19:18 --> Config Class Initialized
DEBUG - 2010-06-29 12:19:18 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:19:18 --> URI Class Initialized
DEBUG - 2010-06-29 12:19:18 --> Router Class Initialized
DEBUG - 2010-06-29 12:19:18 --> Output Class Initialized
DEBUG - 2010-06-29 12:19:18 --> Input Class Initialized
DEBUG - 2010-06-29 12:19:18 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:19:18 --> Language Class Initialized
DEBUG - 2010-06-29 12:19:18 --> Loader Class Initialized
DEBUG - 2010-06-29 12:19:18 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:19:18 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:19:18 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:19:18 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:19:18 --> Controller Class Initialized
DEBUG - 2010-06-29 12:19:18 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:19:18 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:19:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:19:18 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:19:18 --> Helper loaded: email_helper
DEBUG - 2010-06-29 12:19:18 --> User Agent Class Initialized
DEBUG - 2010-06-29 12:19:18 --> Session Class Initialized
DEBUG - 2010-06-29 12:19:18 --> Helper loaded: string_helper
DEBUG - 2010-06-29 12:19:18 --> Session routines successfully run
DEBUG - 2010-06-29 12:19:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:19:19 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:19:19 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:19:19 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 12:19:19 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 12:19:19 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 12:19:20 --> Final output sent to browser
DEBUG - 2010-06-29 12:19:20 --> Total execution time: 2.0388
DEBUG - 2010-06-29 12:19:45 --> Config Class Initialized
DEBUG - 2010-06-29 12:19:45 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:19:45 --> URI Class Initialized
DEBUG - 2010-06-29 12:19:45 --> Router Class Initialized
DEBUG - 2010-06-29 12:19:45 --> Output Class Initialized
DEBUG - 2010-06-29 12:19:45 --> Input Class Initialized
DEBUG - 2010-06-29 12:19:45 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:19:45 --> Language Class Initialized
DEBUG - 2010-06-29 12:19:45 --> Loader Class Initialized
DEBUG - 2010-06-29 12:19:45 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:19:45 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:19:45 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:19:45 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:19:45 --> Controller Class Initialized
DEBUG - 2010-06-29 12:19:45 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:19:45 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:19:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:19:45 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:19:46 --> Helper loaded: email_helper
DEBUG - 2010-06-29 12:19:46 --> User Agent Class Initialized
DEBUG - 2010-06-29 12:19:46 --> Session Class Initialized
DEBUG - 2010-06-29 12:19:46 --> Helper loaded: string_helper
DEBUG - 2010-06-29 12:19:46 --> Session routines successfully run
DEBUG - 2010-06-29 12:19:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:19:46 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:19:46 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:19:46 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 12:19:46 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 12:19:46 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 12:19:46 --> Final output sent to browser
DEBUG - 2010-06-29 12:19:46 --> Total execution time: 1.6999
DEBUG - 2010-06-29 12:20:37 --> Config Class Initialized
DEBUG - 2010-06-29 12:20:37 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:20:37 --> URI Class Initialized
DEBUG - 2010-06-29 12:20:38 --> Router Class Initialized
DEBUG - 2010-06-29 12:20:38 --> Output Class Initialized
DEBUG - 2010-06-29 12:20:38 --> Input Class Initialized
DEBUG - 2010-06-29 12:20:38 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:20:38 --> Language Class Initialized
DEBUG - 2010-06-29 12:20:38 --> Loader Class Initialized
DEBUG - 2010-06-29 12:20:38 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:20:38 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:20:38 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:20:38 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:20:38 --> Controller Class Initialized
DEBUG - 2010-06-29 12:20:38 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:20:38 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:20:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:20:38 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:20:38 --> Helper loaded: email_helper
DEBUG - 2010-06-29 12:20:38 --> User Agent Class Initialized
DEBUG - 2010-06-29 12:20:38 --> Session Class Initialized
DEBUG - 2010-06-29 12:20:38 --> Helper loaded: string_helper
DEBUG - 2010-06-29 12:20:38 --> Session routines successfully run
DEBUG - 2010-06-29 12:20:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:20:39 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:20:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:20:39 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 12:20:39 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 12:20:39 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 12:20:39 --> Final output sent to browser
DEBUG - 2010-06-29 12:20:39 --> Total execution time: 1.7321
DEBUG - 2010-06-29 12:21:20 --> Config Class Initialized
DEBUG - 2010-06-29 12:21:20 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:21:20 --> URI Class Initialized
DEBUG - 2010-06-29 12:21:20 --> Router Class Initialized
DEBUG - 2010-06-29 12:21:20 --> Output Class Initialized
DEBUG - 2010-06-29 12:21:20 --> Input Class Initialized
DEBUG - 2010-06-29 12:21:20 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:21:20 --> Language Class Initialized
DEBUG - 2010-06-29 12:21:20 --> Loader Class Initialized
DEBUG - 2010-06-29 12:21:20 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:21:21 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:21:21 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:21:21 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:21:21 --> Controller Class Initialized
DEBUG - 2010-06-29 12:21:21 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:21:21 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:21:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:21:21 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:21:21 --> Helper loaded: email_helper
DEBUG - 2010-06-29 12:21:21 --> User Agent Class Initialized
DEBUG - 2010-06-29 12:21:21 --> Session Class Initialized
DEBUG - 2010-06-29 12:21:21 --> Helper loaded: string_helper
DEBUG - 2010-06-29 12:21:21 --> Session routines successfully run
DEBUG - 2010-06-29 12:21:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:21:22 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:21:22 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:21:22 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 12:21:22 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 12:21:22 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 12:21:22 --> Final output sent to browser
DEBUG - 2010-06-29 12:21:22 --> Total execution time: 1.7099
DEBUG - 2010-06-29 12:24:37 --> Config Class Initialized
DEBUG - 2010-06-29 12:24:37 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:24:37 --> URI Class Initialized
DEBUG - 2010-06-29 12:24:37 --> Router Class Initialized
DEBUG - 2010-06-29 12:24:38 --> Output Class Initialized
DEBUG - 2010-06-29 12:24:38 --> Input Class Initialized
DEBUG - 2010-06-29 12:24:38 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:24:38 --> Language Class Initialized
DEBUG - 2010-06-29 12:24:38 --> Loader Class Initialized
DEBUG - 2010-06-29 12:24:38 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:24:38 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:24:38 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:24:38 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:24:38 --> Controller Class Initialized
DEBUG - 2010-06-29 12:24:38 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:24:38 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:24:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:24:38 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:24:38 --> Helper loaded: email_helper
DEBUG - 2010-06-29 12:24:38 --> User Agent Class Initialized
DEBUG - 2010-06-29 12:24:38 --> Session Class Initialized
DEBUG - 2010-06-29 12:24:38 --> Helper loaded: string_helper
DEBUG - 2010-06-29 12:24:39 --> Session routines successfully run
DEBUG - 2010-06-29 12:24:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:24:39 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:24:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:24:39 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 12:24:39 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 12:24:39 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 12:24:39 --> Final output sent to browser
DEBUG - 2010-06-29 12:24:39 --> Total execution time: 1.8975
DEBUG - 2010-06-29 12:25:11 --> Config Class Initialized
DEBUG - 2010-06-29 12:25:11 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:25:11 --> URI Class Initialized
DEBUG - 2010-06-29 12:25:11 --> Router Class Initialized
DEBUG - 2010-06-29 12:25:11 --> Output Class Initialized
DEBUG - 2010-06-29 12:25:11 --> Input Class Initialized
DEBUG - 2010-06-29 12:25:11 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:25:11 --> Language Class Initialized
DEBUG - 2010-06-29 12:25:12 --> Loader Class Initialized
DEBUG - 2010-06-29 12:25:12 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:25:12 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:25:12 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:25:12 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:25:12 --> Controller Class Initialized
DEBUG - 2010-06-29 12:25:12 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:25:12 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:25:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:25:12 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:25:12 --> Helper loaded: email_helper
DEBUG - 2010-06-29 12:25:12 --> User Agent Class Initialized
DEBUG - 2010-06-29 12:25:12 --> Session Class Initialized
DEBUG - 2010-06-29 12:25:12 --> Helper loaded: string_helper
DEBUG - 2010-06-29 12:25:12 --> Session routines successfully run
DEBUG - 2010-06-29 12:25:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:25:13 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:25:13 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:25:13 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 12:25:13 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 12:25:13 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 12:25:13 --> Final output sent to browser
DEBUG - 2010-06-29 12:25:13 --> Total execution time: 1.8511
DEBUG - 2010-06-29 12:25:49 --> Config Class Initialized
DEBUG - 2010-06-29 12:25:49 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:25:49 --> URI Class Initialized
DEBUG - 2010-06-29 12:25:49 --> Router Class Initialized
DEBUG - 2010-06-29 12:25:49 --> Output Class Initialized
DEBUG - 2010-06-29 12:25:49 --> Input Class Initialized
DEBUG - 2010-06-29 12:25:49 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:25:49 --> Language Class Initialized
DEBUG - 2010-06-29 12:25:49 --> Loader Class Initialized
DEBUG - 2010-06-29 12:25:49 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:25:49 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:25:49 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:25:49 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:25:49 --> Controller Class Initialized
DEBUG - 2010-06-29 12:25:49 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:25:49 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:25:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:25:50 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:25:50 --> Helper loaded: email_helper
DEBUG - 2010-06-29 12:25:50 --> User Agent Class Initialized
DEBUG - 2010-06-29 12:25:50 --> Session Class Initialized
DEBUG - 2010-06-29 12:25:50 --> Helper loaded: string_helper
DEBUG - 2010-06-29 12:25:50 --> Session routines successfully run
DEBUG - 2010-06-29 12:25:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:25:50 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:25:50 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:25:50 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 12:25:50 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 12:25:50 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 12:25:51 --> Final output sent to browser
DEBUG - 2010-06-29 12:25:51 --> Total execution time: 1.7719
DEBUG - 2010-06-29 12:25:56 --> Config Class Initialized
DEBUG - 2010-06-29 12:25:56 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:25:56 --> URI Class Initialized
DEBUG - 2010-06-29 12:25:56 --> Router Class Initialized
DEBUG - 2010-06-29 12:25:56 --> Output Class Initialized
DEBUG - 2010-06-29 12:25:56 --> Input Class Initialized
DEBUG - 2010-06-29 12:25:56 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:25:56 --> Language Class Initialized
DEBUG - 2010-06-29 12:25:56 --> Loader Class Initialized
DEBUG - 2010-06-29 12:25:56 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:25:56 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:25:57 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:25:57 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:25:57 --> Controller Class Initialized
DEBUG - 2010-06-29 12:25:57 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:25:57 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:25:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:25:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:25:57 --> Helper loaded: email_helper
DEBUG - 2010-06-29 12:25:57 --> User Agent Class Initialized
DEBUG - 2010-06-29 12:25:57 --> Session Class Initialized
DEBUG - 2010-06-29 12:25:57 --> Helper loaded: string_helper
DEBUG - 2010-06-29 12:25:57 --> Session routines successfully run
DEBUG - 2010-06-29 12:25:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:25:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:25:58 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:25:58 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 12:25:58 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 12:25:58 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 12:25:58 --> Final output sent to browser
DEBUG - 2010-06-29 12:25:58 --> Total execution time: 1.8362
DEBUG - 2010-06-29 12:26:07 --> Config Class Initialized
DEBUG - 2010-06-29 12:26:07 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:26:08 --> URI Class Initialized
DEBUG - 2010-06-29 12:26:08 --> Router Class Initialized
DEBUG - 2010-06-29 12:26:08 --> Output Class Initialized
DEBUG - 2010-06-29 12:26:08 --> Input Class Initialized
DEBUG - 2010-06-29 12:26:08 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:26:08 --> Language Class Initialized
DEBUG - 2010-06-29 12:26:08 --> Loader Class Initialized
DEBUG - 2010-06-29 12:26:08 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:26:08 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:26:08 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:26:08 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:26:08 --> Controller Class Initialized
DEBUG - 2010-06-29 12:26:08 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:26:08 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:26:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:26:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:26:08 --> Helper loaded: email_helper
DEBUG - 2010-06-29 12:26:08 --> User Agent Class Initialized
DEBUG - 2010-06-29 12:26:08 --> Session Class Initialized
DEBUG - 2010-06-29 12:26:08 --> Helper loaded: string_helper
DEBUG - 2010-06-29 12:26:09 --> Session routines successfully run
DEBUG - 2010-06-29 12:26:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:26:09 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:26:09 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:26:09 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 12:26:09 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 12:26:53 --> Config Class Initialized
DEBUG - 2010-06-29 12:26:53 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:26:53 --> URI Class Initialized
DEBUG - 2010-06-29 12:26:53 --> Router Class Initialized
DEBUG - 2010-06-29 12:26:53 --> Output Class Initialized
DEBUG - 2010-06-29 12:26:53 --> Input Class Initialized
DEBUG - 2010-06-29 12:26:53 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:26:53 --> Language Class Initialized
DEBUG - 2010-06-29 12:26:53 --> Loader Class Initialized
DEBUG - 2010-06-29 12:26:53 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:26:53 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:26:53 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:26:53 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:26:53 --> Controller Class Initialized
DEBUG - 2010-06-29 12:26:54 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:26:54 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:26:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:26:54 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:26:54 --> Helper loaded: email_helper
DEBUG - 2010-06-29 12:26:54 --> User Agent Class Initialized
DEBUG - 2010-06-29 12:26:54 --> Session Class Initialized
DEBUG - 2010-06-29 12:26:54 --> Helper loaded: string_helper
DEBUG - 2010-06-29 12:26:54 --> Session routines successfully run
DEBUG - 2010-06-29 12:26:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:26:54 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:26:55 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:26:55 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 12:26:55 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 12:26:55 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 12:26:55 --> Final output sent to browser
DEBUG - 2010-06-29 12:26:55 --> Total execution time: 1.8790
DEBUG - 2010-06-29 12:27:19 --> Config Class Initialized
DEBUG - 2010-06-29 12:27:19 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:27:19 --> URI Class Initialized
DEBUG - 2010-06-29 12:27:19 --> Router Class Initialized
DEBUG - 2010-06-29 12:27:19 --> Output Class Initialized
DEBUG - 2010-06-29 12:27:19 --> Input Class Initialized
DEBUG - 2010-06-29 12:27:19 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:27:19 --> Language Class Initialized
DEBUG - 2010-06-29 12:27:19 --> Loader Class Initialized
DEBUG - 2010-06-29 12:27:19 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:27:19 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:27:20 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:27:20 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:27:20 --> Controller Class Initialized
DEBUG - 2010-06-29 12:27:20 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:27:20 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:27:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:27:20 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:27:20 --> Helper loaded: email_helper
DEBUG - 2010-06-29 12:27:20 --> User Agent Class Initialized
DEBUG - 2010-06-29 12:27:20 --> Session Class Initialized
DEBUG - 2010-06-29 12:27:20 --> Helper loaded: string_helper
DEBUG - 2010-06-29 12:27:20 --> Session routines successfully run
DEBUG - 2010-06-29 12:27:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:27:21 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:27:21 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:27:21 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 12:27:21 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 12:27:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:27:21 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:27:21 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:27:21 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 12:27:21 --> Final output sent to browser
DEBUG - 2010-06-29 12:27:21 --> Total execution time: 2.0218
DEBUG - 2010-06-29 12:27:31 --> Config Class Initialized
DEBUG - 2010-06-29 12:27:31 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:27:31 --> URI Class Initialized
DEBUG - 2010-06-29 12:27:31 --> Router Class Initialized
DEBUG - 2010-06-29 12:27:31 --> Output Class Initialized
DEBUG - 2010-06-29 12:27:31 --> Input Class Initialized
DEBUG - 2010-06-29 12:27:31 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:27:31 --> Language Class Initialized
DEBUG - 2010-06-29 12:27:31 --> Loader Class Initialized
DEBUG - 2010-06-29 12:27:31 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:27:31 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:27:31 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:27:32 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:27:32 --> Controller Class Initialized
DEBUG - 2010-06-29 12:27:32 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:27:32 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:27:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:27:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:27:32 --> Helper loaded: email_helper
DEBUG - 2010-06-29 12:27:32 --> User Agent Class Initialized
DEBUG - 2010-06-29 12:27:32 --> Session Class Initialized
DEBUG - 2010-06-29 12:27:32 --> Helper loaded: string_helper
DEBUG - 2010-06-29 12:27:32 --> Session routines successfully run
DEBUG - 2010-06-29 12:27:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:27:33 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:27:33 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:27:33 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 12:27:33 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 12:27:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:27:33 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:27:33 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:27:33 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 12:27:33 --> Final output sent to browser
DEBUG - 2010-06-29 12:27:33 --> Total execution time: 2.0696
DEBUG - 2010-06-29 12:27:59 --> Config Class Initialized
DEBUG - 2010-06-29 12:27:59 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:27:59 --> URI Class Initialized
DEBUG - 2010-06-29 12:27:59 --> Router Class Initialized
DEBUG - 2010-06-29 12:27:59 --> Output Class Initialized
DEBUG - 2010-06-29 12:27:59 --> Input Class Initialized
DEBUG - 2010-06-29 12:27:59 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:27:59 --> Language Class Initialized
DEBUG - 2010-06-29 12:27:59 --> Loader Class Initialized
DEBUG - 2010-06-29 12:27:59 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:27:59 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:27:59 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:27:59 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:28:00 --> Controller Class Initialized
DEBUG - 2010-06-29 12:28:00 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:28:00 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:28:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:28:00 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:28:00 --> Helper loaded: email_helper
DEBUG - 2010-06-29 12:28:00 --> User Agent Class Initialized
DEBUG - 2010-06-29 12:28:00 --> Session Class Initialized
DEBUG - 2010-06-29 12:28:00 --> Helper loaded: string_helper
DEBUG - 2010-06-29 12:28:00 --> Session routines successfully run
DEBUG - 2010-06-29 12:28:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:28:01 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:28:01 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:28:01 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 12:28:01 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 12:28:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:28:01 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:28:01 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:28:01 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 12:28:01 --> Final output sent to browser
DEBUG - 2010-06-29 12:28:01 --> Total execution time: 2.1467
DEBUG - 2010-06-29 12:28:30 --> Config Class Initialized
DEBUG - 2010-06-29 12:28:30 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:28:30 --> URI Class Initialized
DEBUG - 2010-06-29 12:28:30 --> Router Class Initialized
DEBUG - 2010-06-29 12:28:30 --> Output Class Initialized
DEBUG - 2010-06-29 12:28:30 --> Input Class Initialized
DEBUG - 2010-06-29 12:28:30 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:28:30 --> Language Class Initialized
DEBUG - 2010-06-29 12:28:30 --> Loader Class Initialized
DEBUG - 2010-06-29 12:28:30 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:28:30 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:28:31 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:28:31 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:28:31 --> Controller Class Initialized
DEBUG - 2010-06-29 12:28:31 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:28:31 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:28:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:28:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:28:31 --> Helper loaded: email_helper
DEBUG - 2010-06-29 12:28:31 --> User Agent Class Initialized
DEBUG - 2010-06-29 12:28:31 --> Session Class Initialized
DEBUG - 2010-06-29 12:28:31 --> Helper loaded: string_helper
DEBUG - 2010-06-29 12:28:31 --> Session routines successfully run
DEBUG - 2010-06-29 12:28:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:28:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:28:32 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:28:32 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 12:28:32 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 12:28:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:28:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:28:32 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2010-06-29 12:28:32 --> Severity: Notice  --> Undefined property: User::$actor_type_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\KALS_actor.php 33
ERROR - 2010-06-29 12:28:32 --> Severity: Notice  --> Undefined property: User::$actor_type_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\KALS_actor.php 33
DEBUG - 2010-06-29 12:28:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:28:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:28:32 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2010-06-29 12:28:32 --> Severity: Notice  --> Undefined property: User::$actor_type_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\KALS_actor.php 33
ERROR - 2010-06-29 12:28:32 --> Severity: Notice  --> Undefined property: User::$actor_type_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\KALS_actor.php 33
DEBUG - 2010-06-29 12:28:32 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 12:28:32 --> Final output sent to browser
DEBUG - 2010-06-29 12:28:32 --> Total execution time: 2.4363
DEBUG - 2010-06-29 12:29:02 --> Config Class Initialized
DEBUG - 2010-06-29 12:29:03 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:29:03 --> URI Class Initialized
DEBUG - 2010-06-29 12:29:03 --> Router Class Initialized
DEBUG - 2010-06-29 12:29:03 --> Output Class Initialized
DEBUG - 2010-06-29 12:29:03 --> Input Class Initialized
DEBUG - 2010-06-29 12:29:03 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:29:03 --> Language Class Initialized
DEBUG - 2010-06-29 12:29:03 --> Loader Class Initialized
DEBUG - 2010-06-29 12:29:03 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:29:03 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:29:03 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:29:03 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:29:03 --> Controller Class Initialized
DEBUG - 2010-06-29 12:29:03 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:29:03 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:29:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:29:03 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:29:03 --> Helper loaded: email_helper
DEBUG - 2010-06-29 12:29:03 --> User Agent Class Initialized
DEBUG - 2010-06-29 12:29:04 --> Session Class Initialized
DEBUG - 2010-06-29 12:29:04 --> Helper loaded: string_helper
DEBUG - 2010-06-29 12:29:04 --> Session routines successfully run
DEBUG - 2010-06-29 12:29:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:29:04 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:29:04 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:29:04 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 12:29:04 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 12:29:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:29:04 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:29:04 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2010-06-29 12:29:05 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  relation &quot;group2actor&quot; does not exist
LINE 1: DELETE FROM &quot;group2actor&quot;
                    ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-29 12:29:05 --> DB Transaction Failure
ERROR - 2010-06-29 12:29:05 --> Query error: ERROR:  relation "group2actor" does not exist
LINE 1: DELETE FROM "group2actor"
                    ^
DEBUG - 2010-06-29 12:29:05 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-06-29 12:31:29 --> Config Class Initialized
DEBUG - 2010-06-29 12:31:29 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:31:29 --> URI Class Initialized
DEBUG - 2010-06-29 12:31:29 --> Router Class Initialized
DEBUG - 2010-06-29 12:31:29 --> Output Class Initialized
DEBUG - 2010-06-29 12:31:29 --> Input Class Initialized
DEBUG - 2010-06-29 12:31:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:31:29 --> Language Class Initialized
DEBUG - 2010-06-29 12:31:29 --> Loader Class Initialized
DEBUG - 2010-06-29 12:31:29 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:31:29 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:31:29 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:31:29 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:31:30 --> Controller Class Initialized
DEBUG - 2010-06-29 12:31:30 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:31:30 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:31:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:31:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:31:30 --> Helper loaded: email_helper
DEBUG - 2010-06-29 12:31:30 --> User Agent Class Initialized
DEBUG - 2010-06-29 12:31:30 --> Session Class Initialized
DEBUG - 2010-06-29 12:31:30 --> Helper loaded: string_helper
DEBUG - 2010-06-29 12:31:30 --> Session routines successfully run
DEBUG - 2010-06-29 12:31:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:31:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:31:31 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:31:31 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 12:31:31 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 12:31:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:31:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:31:31 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:31:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:31:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:31:31 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:31:31 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 12:31:31 --> Final output sent to browser
DEBUG - 2010-06-29 12:31:31 --> Total execution time: 2.4408
DEBUG - 2010-06-29 12:35:09 --> Config Class Initialized
DEBUG - 2010-06-29 12:35:09 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:35:09 --> URI Class Initialized
DEBUG - 2010-06-29 12:35:09 --> Router Class Initialized
DEBUG - 2010-06-29 12:35:09 --> Output Class Initialized
DEBUG - 2010-06-29 12:35:10 --> Input Class Initialized
DEBUG - 2010-06-29 12:35:10 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:35:10 --> Language Class Initialized
DEBUG - 2010-06-29 12:35:10 --> Loader Class Initialized
DEBUG - 2010-06-29 12:35:10 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:35:10 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:35:10 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:35:10 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:35:10 --> Controller Class Initialized
DEBUG - 2010-06-29 12:35:10 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:35:10 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:35:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:35:10 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:35:10 --> Helper loaded: email_helper
DEBUG - 2010-06-29 12:35:10 --> User Agent Class Initialized
DEBUG - 2010-06-29 12:35:10 --> Session Class Initialized
DEBUG - 2010-06-29 12:35:10 --> Helper loaded: string_helper
DEBUG - 2010-06-29 12:35:11 --> Session routines successfully run
DEBUG - 2010-06-29 12:35:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:35:11 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:35:11 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:35:11 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 12:35:11 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 12:35:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:35:11 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:35:11 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:35:11 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-06-29 12:36:03 --> Config Class Initialized
DEBUG - 2010-06-29 12:36:03 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:36:03 --> URI Class Initialized
DEBUG - 2010-06-29 12:36:03 --> Router Class Initialized
DEBUG - 2010-06-29 12:36:03 --> Output Class Initialized
DEBUG - 2010-06-29 12:36:03 --> Input Class Initialized
DEBUG - 2010-06-29 12:36:03 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:36:03 --> Language Class Initialized
DEBUG - 2010-06-29 12:36:03 --> Loader Class Initialized
DEBUG - 2010-06-29 12:36:03 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:36:03 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:36:03 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:36:03 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:36:03 --> Controller Class Initialized
DEBUG - 2010-06-29 12:36:03 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:36:04 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:36:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:36:04 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:36:04 --> Helper loaded: email_helper
DEBUG - 2010-06-29 12:36:04 --> User Agent Class Initialized
DEBUG - 2010-06-29 12:36:04 --> Session Class Initialized
DEBUG - 2010-06-29 12:36:04 --> Helper loaded: string_helper
DEBUG - 2010-06-29 12:36:04 --> Session routines successfully run
DEBUG - 2010-06-29 12:36:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:36:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:36:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:36:05 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 12:36:05 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 12:36:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:36:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:36:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:36:05 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 12:36:05 --> Final output sent to browser
DEBUG - 2010-06-29 12:36:05 --> Total execution time: 2.4059
DEBUG - 2010-06-29 12:52:47 --> Config Class Initialized
DEBUG - 2010-06-29 12:52:47 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:52:47 --> URI Class Initialized
DEBUG - 2010-06-29 12:52:47 --> Router Class Initialized
DEBUG - 2010-06-29 12:52:47 --> Output Class Initialized
DEBUG - 2010-06-29 12:52:47 --> Input Class Initialized
DEBUG - 2010-06-29 12:52:48 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:52:48 --> Language Class Initialized
DEBUG - 2010-06-29 12:52:48 --> Loader Class Initialized
DEBUG - 2010-06-29 12:52:48 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:52:48 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:52:48 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:52:48 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:52:48 --> Controller Class Initialized
DEBUG - 2010-06-29 12:52:48 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:52:48 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:52:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:52:48 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:52:48 --> Helper loaded: email_helper
DEBUG - 2010-06-29 12:52:48 --> User Agent Class Initialized
DEBUG - 2010-06-29 12:52:49 --> Session Class Initialized
DEBUG - 2010-06-29 12:52:49 --> Helper loaded: string_helper
DEBUG - 2010-06-29 12:52:49 --> Session routines successfully run
DEBUG - 2010-06-29 12:52:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:52:49 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:52:49 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:52:49 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 12:52:49 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 12:52:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:52:49 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:52:50 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:53:37 --> Config Class Initialized
DEBUG - 2010-06-29 12:53:37 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:53:37 --> URI Class Initialized
DEBUG - 2010-06-29 12:53:37 --> Router Class Initialized
DEBUG - 2010-06-29 12:53:37 --> Output Class Initialized
DEBUG - 2010-06-29 12:53:37 --> Input Class Initialized
DEBUG - 2010-06-29 12:53:37 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:53:37 --> Language Class Initialized
DEBUG - 2010-06-29 12:53:37 --> Loader Class Initialized
DEBUG - 2010-06-29 12:53:37 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:53:37 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:53:37 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:53:37 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:53:37 --> Controller Class Initialized
DEBUG - 2010-06-29 12:53:37 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:53:37 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:53:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:53:38 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:53:38 --> Helper loaded: email_helper
DEBUG - 2010-06-29 12:53:38 --> User Agent Class Initialized
DEBUG - 2010-06-29 12:53:38 --> Session Class Initialized
DEBUG - 2010-06-29 12:53:38 --> Helper loaded: string_helper
DEBUG - 2010-06-29 12:53:38 --> Session routines successfully run
DEBUG - 2010-06-29 12:53:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:53:38 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:53:38 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:53:38 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 12:53:39 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 12:53:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:53:39 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:53:39 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2010-06-29 12:53:39 --> Severity: Notice  --> Undefined property: CI_DB_postgre_driver::$_like_escape_char D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\DB_active_rec.php 728
ERROR - 2010-06-29 12:53:39 --> Severity: Notice  --> Undefined property: CI_DB_postgre_driver::$_like_escape_char D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\DB_active_rec.php 728
ERROR - 2010-06-29 12:53:39 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid input syntax for integer: &quot;http://www.plurk.com/p/5xra8r#response-1657897612&quot;
LINE 3: WHERE &quot;domain_id&quot; = 'http://www.plurk.com/p/5xra8r#response-...
                            ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-29 12:53:39 --> DB Transaction Failure
ERROR - 2010-06-29 12:53:39 --> Query error: ERROR:  invalid input syntax for integer: "http://www.plurk.com/p/5xra8r#response-1657897612"
LINE 3: WHERE "domain_id" = 'http://www.plurk.com/p/5xra8r#response-...
                            ^
DEBUG - 2010-06-29 12:53:39 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-06-29 12:53:39 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-29 12:54:48 --> Config Class Initialized
DEBUG - 2010-06-29 12:54:48 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:54:48 --> URI Class Initialized
DEBUG - 2010-06-29 12:54:48 --> Router Class Initialized
DEBUG - 2010-06-29 12:54:48 --> Output Class Initialized
DEBUG - 2010-06-29 12:54:48 --> Input Class Initialized
DEBUG - 2010-06-29 12:54:48 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:54:49 --> Language Class Initialized
DEBUG - 2010-06-29 12:54:49 --> Loader Class Initialized
DEBUG - 2010-06-29 12:54:49 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:54:49 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:54:49 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:54:49 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:54:49 --> Controller Class Initialized
DEBUG - 2010-06-29 12:54:49 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:54:49 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:54:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:54:49 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:54:49 --> Helper loaded: email_helper
DEBUG - 2010-06-29 12:54:49 --> User Agent Class Initialized
DEBUG - 2010-06-29 12:54:49 --> Session Class Initialized
DEBUG - 2010-06-29 12:54:49 --> Helper loaded: string_helper
DEBUG - 2010-06-29 12:54:49 --> Session routines successfully run
DEBUG - 2010-06-29 12:54:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:54:50 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:54:50 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:54:50 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 12:54:50 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 12:54:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:54:50 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:54:50 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2010-06-29 12:54:50 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid input syntax for integer: &quot;http://www.plurk.com/p/5xra8r#response-1657897612&quot;
LINE 3: WHERE &quot;domain_id&quot; = 'http://www.plurk.com/p/5xra8r#response-...
                            ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-29 12:54:50 --> DB Transaction Failure
ERROR - 2010-06-29 12:54:50 --> Query error: ERROR:  invalid input syntax for integer: "http://www.plurk.com/p/5xra8r#response-1657897612"
LINE 3: WHERE "domain_id" = 'http://www.plurk.com/p/5xra8r#response-...
                            ^
DEBUG - 2010-06-29 12:54:51 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-06-29 12:55:13 --> Config Class Initialized
DEBUG - 2010-06-29 12:55:13 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:55:13 --> URI Class Initialized
DEBUG - 2010-06-29 12:55:13 --> Router Class Initialized
DEBUG - 2010-06-29 12:55:13 --> Output Class Initialized
DEBUG - 2010-06-29 12:55:13 --> Input Class Initialized
DEBUG - 2010-06-29 12:55:13 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:55:13 --> Language Class Initialized
DEBUG - 2010-06-29 12:55:13 --> Loader Class Initialized
DEBUG - 2010-06-29 12:55:13 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:55:13 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:55:13 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:55:13 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:55:13 --> Controller Class Initialized
DEBUG - 2010-06-29 12:55:13 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:55:13 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:55:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:55:14 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:55:14 --> Helper loaded: email_helper
DEBUG - 2010-06-29 12:55:14 --> User Agent Class Initialized
DEBUG - 2010-06-29 12:55:14 --> Session Class Initialized
DEBUG - 2010-06-29 12:55:14 --> Helper loaded: string_helper
DEBUG - 2010-06-29 12:55:14 --> Session routines successfully run
DEBUG - 2010-06-29 12:55:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:55:14 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:55:14 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:55:15 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 12:55:15 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 12:55:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:55:15 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:55:15 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:55:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:55:15 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:55:15 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:55:15 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 12:55:15 --> Final output sent to browser
DEBUG - 2010-06-29 12:55:15 --> Total execution time: 2.5554
DEBUG - 2010-06-29 12:55:22 --> Config Class Initialized
DEBUG - 2010-06-29 12:55:22 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:55:22 --> URI Class Initialized
DEBUG - 2010-06-29 12:55:22 --> Router Class Initialized
DEBUG - 2010-06-29 12:55:23 --> Output Class Initialized
DEBUG - 2010-06-29 12:55:23 --> Input Class Initialized
DEBUG - 2010-06-29 12:55:23 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:55:23 --> Language Class Initialized
DEBUG - 2010-06-29 12:55:23 --> Loader Class Initialized
DEBUG - 2010-06-29 12:55:23 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:55:23 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:55:23 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:55:23 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:55:23 --> Controller Class Initialized
DEBUG - 2010-06-29 12:55:23 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:55:23 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:55:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:55:23 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:55:23 --> Helper loaded: email_helper
DEBUG - 2010-06-29 12:55:24 --> User Agent Class Initialized
DEBUG - 2010-06-29 12:55:24 --> Session Class Initialized
DEBUG - 2010-06-29 12:55:24 --> Helper loaded: string_helper
DEBUG - 2010-06-29 12:55:24 --> Session routines successfully run
DEBUG - 2010-06-29 12:55:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:55:24 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:55:24 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:55:24 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 12:55:24 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 12:55:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:55:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:55:25 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2010-06-29 12:55:25 --> Severity: Notice  --> Undefined property: CI_DB_postgre_driver::$_like_escape_char D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\DB_active_rec.php 728
ERROR - 2010-06-29 12:55:25 --> Severity: Notice  --> Undefined property: CI_DB_postgre_driver::$_like_escape_char D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\DB_active_rec.php 728
ERROR - 2010-06-29 12:55:25 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;e-mail&quot; does not exist
LINE 6: OR  &quot;e-mail&quot;  LIKE '%dd%' ESCAPE '' 
            ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-29 12:55:25 --> DB Transaction Failure
ERROR - 2010-06-29 12:55:25 --> Query error: ERROR:  column "e-mail" does not exist
LINE 6: OR  "e-mail"  LIKE '%dd%' ESCAPE '' 
            ^
DEBUG - 2010-06-29 12:55:25 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-06-29 12:55:25 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-29 12:55:34 --> Config Class Initialized
DEBUG - 2010-06-29 12:55:34 --> Hooks Class Initialized
DEBUG - 2010-06-29 12:55:34 --> URI Class Initialized
DEBUG - 2010-06-29 12:55:34 --> Router Class Initialized
DEBUG - 2010-06-29 12:55:34 --> Output Class Initialized
DEBUG - 2010-06-29 12:55:34 --> Input Class Initialized
DEBUG - 2010-06-29 12:55:34 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 12:55:34 --> Language Class Initialized
DEBUG - 2010-06-29 12:55:34 --> Loader Class Initialized
DEBUG - 2010-06-29 12:55:34 --> Helper loaded: context_helper
DEBUG - 2010-06-29 12:55:35 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 12:55:35 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 12:55:35 --> Database Driver Class Initialized
DEBUG - 2010-06-29 12:55:35 --> Controller Class Initialized
DEBUG - 2010-06-29 12:55:35 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 12:55:35 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 12:55:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:55:35 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:55:35 --> Helper loaded: email_helper
DEBUG - 2010-06-29 12:55:35 --> User Agent Class Initialized
DEBUG - 2010-06-29 12:55:35 --> Session Class Initialized
DEBUG - 2010-06-29 12:55:35 --> Helper loaded: string_helper
DEBUG - 2010-06-29 12:55:35 --> Session routines successfully run
DEBUG - 2010-06-29 12:55:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:55:36 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:55:36 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:55:36 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 12:55:36 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 12:55:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:55:36 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:55:36 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2010-06-29 12:55:36 --> Severity: Notice  --> Undefined property: CI_DB_postgre_driver::$_like_escape_char D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\DB_active_rec.php 728
DEBUG - 2010-06-29 12:55:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:55:36 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:55:36 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 12:55:37 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 12:55:37 --> Final output sent to browser
DEBUG - 2010-06-29 12:55:37 --> Total execution time: 2.6662
DEBUG - 2010-06-29 13:02:16 --> Config Class Initialized
DEBUG - 2010-06-29 13:02:16 --> Hooks Class Initialized
DEBUG - 2010-06-29 13:02:16 --> URI Class Initialized
DEBUG - 2010-06-29 13:02:16 --> Router Class Initialized
DEBUG - 2010-06-29 13:02:17 --> Output Class Initialized
DEBUG - 2010-06-29 13:02:17 --> Input Class Initialized
DEBUG - 2010-06-29 13:02:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 13:02:17 --> Language Class Initialized
DEBUG - 2010-06-29 13:02:17 --> Loader Class Initialized
DEBUG - 2010-06-29 13:02:17 --> Helper loaded: context_helper
DEBUG - 2010-06-29 13:02:17 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 13:02:17 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 13:02:17 --> Database Driver Class Initialized
DEBUG - 2010-06-29 13:02:17 --> Controller Class Initialized
DEBUG - 2010-06-29 13:02:17 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 13:02:17 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 13:02:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:02:18 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:02:18 --> Helper loaded: email_helper
DEBUG - 2010-06-29 13:02:18 --> User Agent Class Initialized
DEBUG - 2010-06-29 13:02:18 --> Session Class Initialized
DEBUG - 2010-06-29 13:02:18 --> Helper loaded: string_helper
DEBUG - 2010-06-29 13:02:18 --> Session routines successfully run
DEBUG - 2010-06-29 13:02:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:02:18 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:02:19 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:02:19 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 13:02:19 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 13:02:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:02:19 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:02:19 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2010-06-29 13:02:19 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;FROMuser&quot;
LINE 1: SELECT * FROMuser WHERE deleted = FALSE AND domain_id = 161 ...
                 ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-29 13:02:19 --> DB Transaction Failure
ERROR - 2010-06-29 13:02:19 --> Query error: ERROR:  syntax error at or near "FROMuser"
LINE 1: SELECT * FROMuser WHERE deleted = FALSE AND domain_id = 161 ...
                 ^
DEBUG - 2010-06-29 13:02:19 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-06-29 13:02:27 --> Config Class Initialized
DEBUG - 2010-06-29 13:02:27 --> Hooks Class Initialized
DEBUG - 2010-06-29 13:02:27 --> URI Class Initialized
DEBUG - 2010-06-29 13:02:27 --> Router Class Initialized
DEBUG - 2010-06-29 13:02:28 --> Output Class Initialized
DEBUG - 2010-06-29 13:02:28 --> Input Class Initialized
DEBUG - 2010-06-29 13:02:28 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 13:02:28 --> Language Class Initialized
DEBUG - 2010-06-29 13:02:28 --> Loader Class Initialized
DEBUG - 2010-06-29 13:02:28 --> Helper loaded: context_helper
DEBUG - 2010-06-29 13:02:28 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 13:02:28 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 13:02:28 --> Database Driver Class Initialized
DEBUG - 2010-06-29 13:02:28 --> Controller Class Initialized
DEBUG - 2010-06-29 13:02:28 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 13:02:28 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 13:02:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:02:28 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:02:28 --> Helper loaded: email_helper
DEBUG - 2010-06-29 13:02:29 --> User Agent Class Initialized
DEBUG - 2010-06-29 13:02:29 --> Session Class Initialized
DEBUG - 2010-06-29 13:02:29 --> Helper loaded: string_helper
DEBUG - 2010-06-29 13:02:29 --> Session routines successfully run
DEBUG - 2010-06-29 13:02:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:02:29 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:02:29 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:02:29 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 13:02:29 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 13:02:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:02:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:02:30 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2010-06-29 13:02:30 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;deleted&quot; does not exist
LINE 1: SELECT * FROM user WHERE deleted = FALSE AND domain_id = 161...
                                 ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-29 13:02:30 --> DB Transaction Failure
ERROR - 2010-06-29 13:02:30 --> Query error: ERROR:  column "deleted" does not exist
LINE 1: SELECT * FROM user WHERE deleted = FALSE AND domain_id = 161...
                                 ^
DEBUG - 2010-06-29 13:02:30 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-06-29 13:05:24 --> Config Class Initialized
DEBUG - 2010-06-29 13:05:24 --> Hooks Class Initialized
DEBUG - 2010-06-29 13:05:24 --> URI Class Initialized
DEBUG - 2010-06-29 13:05:24 --> Router Class Initialized
DEBUG - 2010-06-29 13:05:25 --> Output Class Initialized
DEBUG - 2010-06-29 13:05:25 --> Input Class Initialized
DEBUG - 2010-06-29 13:05:25 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 13:05:25 --> Language Class Initialized
DEBUG - 2010-06-29 13:05:25 --> Loader Class Initialized
DEBUG - 2010-06-29 13:05:25 --> Helper loaded: context_helper
DEBUG - 2010-06-29 13:05:25 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 13:05:25 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 13:05:25 --> Database Driver Class Initialized
DEBUG - 2010-06-29 13:05:25 --> Controller Class Initialized
DEBUG - 2010-06-29 13:05:25 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 13:05:25 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 13:05:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:05:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:05:25 --> Helper loaded: email_helper
DEBUG - 2010-06-29 13:05:26 --> User Agent Class Initialized
DEBUG - 2010-06-29 13:05:26 --> Session Class Initialized
DEBUG - 2010-06-29 13:05:26 --> Helper loaded: string_helper
DEBUG - 2010-06-29 13:05:26 --> Session routines successfully run
DEBUG - 2010-06-29 13:05:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:05:26 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:05:26 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:05:26 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 13:05:26 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 13:05:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:05:27 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:05:27 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2010-06-29 13:05:27 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;%&quot;
LINE 1: ...leted = FALSE AND domain_id = 161  AND (name LIKE %'dd'% OR ...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-29 13:05:27 --> DB Transaction Failure
ERROR - 2010-06-29 13:05:27 --> Query error: ERROR:  syntax error at or near "%"
LINE 1: ...leted = FALSE AND domain_id = 161  AND (name LIKE %'dd'% OR ...
                                                             ^
DEBUG - 2010-06-29 13:05:27 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-06-29 13:06:01 --> Config Class Initialized
DEBUG - 2010-06-29 13:06:01 --> Hooks Class Initialized
DEBUG - 2010-06-29 13:06:01 --> URI Class Initialized
DEBUG - 2010-06-29 13:06:01 --> Router Class Initialized
DEBUG - 2010-06-29 13:06:01 --> Output Class Initialized
DEBUG - 2010-06-29 13:06:01 --> Input Class Initialized
DEBUG - 2010-06-29 13:06:01 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 13:06:01 --> Language Class Initialized
DEBUG - 2010-06-29 13:06:01 --> Loader Class Initialized
DEBUG - 2010-06-29 13:06:01 --> Helper loaded: context_helper
DEBUG - 2010-06-29 13:06:01 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 13:06:01 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 13:06:02 --> Database Driver Class Initialized
DEBUG - 2010-06-29 13:06:02 --> Controller Class Initialized
DEBUG - 2010-06-29 13:06:02 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 13:06:02 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 13:06:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:06:02 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:06:02 --> Helper loaded: email_helper
DEBUG - 2010-06-29 13:06:02 --> User Agent Class Initialized
DEBUG - 2010-06-29 13:06:02 --> Session Class Initialized
DEBUG - 2010-06-29 13:06:02 --> Helper loaded: string_helper
DEBUG - 2010-06-29 13:06:02 --> Session routines successfully run
DEBUG - 2010-06-29 13:06:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:06:03 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:06:03 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:06:03 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 13:06:03 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 13:06:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:06:03 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:06:03 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:06:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:06:03 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:06:03 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:06:03 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 13:06:03 --> Final output sent to browser
DEBUG - 2010-06-29 13:06:04 --> Total execution time: 2.7395
DEBUG - 2010-06-29 13:07:59 --> Config Class Initialized
DEBUG - 2010-06-29 13:07:59 --> Hooks Class Initialized
DEBUG - 2010-06-29 13:07:59 --> URI Class Initialized
DEBUG - 2010-06-29 13:07:59 --> Router Class Initialized
DEBUG - 2010-06-29 13:07:59 --> Output Class Initialized
DEBUG - 2010-06-29 13:07:59 --> Input Class Initialized
DEBUG - 2010-06-29 13:07:59 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 13:07:59 --> Language Class Initialized
DEBUG - 2010-06-29 13:07:59 --> Loader Class Initialized
DEBUG - 2010-06-29 13:07:59 --> Helper loaded: context_helper
DEBUG - 2010-06-29 13:07:59 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 13:07:59 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 13:07:59 --> Database Driver Class Initialized
DEBUG - 2010-06-29 13:08:00 --> Controller Class Initialized
DEBUG - 2010-06-29 13:08:00 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 13:08:00 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 13:08:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:08:00 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:08:00 --> Helper loaded: email_helper
DEBUG - 2010-06-29 13:08:00 --> User Agent Class Initialized
DEBUG - 2010-06-29 13:08:00 --> Session Class Initialized
DEBUG - 2010-06-29 13:08:00 --> Helper loaded: string_helper
DEBUG - 2010-06-29 13:08:00 --> Session routines successfully run
DEBUG - 2010-06-29 13:08:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:08:01 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:08:01 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:08:01 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 13:08:01 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 13:08:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:08:01 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:08:01 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2010-06-29 13:08:01 --> Severity: Notice  --> Undefined property: CI_DB_postgre_driver::$_like_escape_char D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\DB_active_rec.php 728
ERROR - 2010-06-29 13:08:01 --> Severity: Notice  --> Undefined property: CI_DB_postgre_driver::$_like_escape_char D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\DB_active_rec.php 728
ERROR - 2010-06-29 13:08:02 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;e-mail&quot; does not exist
LINE 6: OR  &quot;e-mail&quot;  LIKE '%dd%' ESCAPE '' 
            ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-29 13:08:02 --> DB Transaction Failure
ERROR - 2010-06-29 13:08:02 --> Query error: ERROR:  column "e-mail" does not exist
LINE 6: OR  "e-mail"  LIKE '%dd%' ESCAPE '' 
            ^
DEBUG - 2010-06-29 13:08:02 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-06-29 13:08:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-29 13:13:44 --> Config Class Initialized
DEBUG - 2010-06-29 13:13:45 --> Hooks Class Initialized
DEBUG - 2010-06-29 13:13:45 --> URI Class Initialized
DEBUG - 2010-06-29 13:13:45 --> Router Class Initialized
DEBUG - 2010-06-29 13:13:45 --> Output Class Initialized
DEBUG - 2010-06-29 13:13:45 --> Input Class Initialized
DEBUG - 2010-06-29 13:13:45 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 13:13:45 --> Language Class Initialized
DEBUG - 2010-06-29 13:13:45 --> Loader Class Initialized
DEBUG - 2010-06-29 13:13:45 --> Helper loaded: context_helper
DEBUG - 2010-06-29 13:13:45 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 13:13:45 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 13:13:45 --> Database Driver Class Initialized
DEBUG - 2010-06-29 13:13:45 --> Controller Class Initialized
DEBUG - 2010-06-29 13:13:45 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 13:13:45 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 13:13:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:13:46 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:13:46 --> Helper loaded: email_helper
DEBUG - 2010-06-29 13:13:46 --> User Agent Class Initialized
DEBUG - 2010-06-29 13:13:46 --> Session Class Initialized
DEBUG - 2010-06-29 13:13:46 --> Helper loaded: string_helper
DEBUG - 2010-06-29 13:13:46 --> Session routines successfully run
DEBUG - 2010-06-29 13:13:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:13:47 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:13:47 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:13:47 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 13:13:47 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 13:13:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:13:47 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:13:47 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2010-06-29 13:13:47 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;e-mail&quot; does not exist
LINE 6: OR  &quot;e-mail&quot;  LIKE '%dd%' ESCAPE '!' 
            ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-06-29 13:13:47 --> DB Transaction Failure
ERROR - 2010-06-29 13:13:47 --> Query error: ERROR:  column "e-mail" does not exist
LINE 6: OR  "e-mail"  LIKE '%dd%' ESCAPE '!' 
            ^
DEBUG - 2010-06-29 13:13:47 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-06-29 13:14:05 --> Config Class Initialized
DEBUG - 2010-06-29 13:14:06 --> Hooks Class Initialized
DEBUG - 2010-06-29 13:14:06 --> URI Class Initialized
DEBUG - 2010-06-29 13:14:06 --> Router Class Initialized
DEBUG - 2010-06-29 13:14:06 --> Output Class Initialized
DEBUG - 2010-06-29 13:14:06 --> Input Class Initialized
DEBUG - 2010-06-29 13:14:06 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 13:14:06 --> Language Class Initialized
DEBUG - 2010-06-29 13:14:06 --> Loader Class Initialized
DEBUG - 2010-06-29 13:14:06 --> Helper loaded: context_helper
DEBUG - 2010-06-29 13:14:06 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 13:14:06 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 13:14:06 --> Database Driver Class Initialized
DEBUG - 2010-06-29 13:14:06 --> Controller Class Initialized
DEBUG - 2010-06-29 13:14:06 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 13:14:07 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 13:14:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:14:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:14:07 --> Helper loaded: email_helper
DEBUG - 2010-06-29 13:14:07 --> User Agent Class Initialized
DEBUG - 2010-06-29 13:14:07 --> Session Class Initialized
DEBUG - 2010-06-29 13:14:07 --> Helper loaded: string_helper
DEBUG - 2010-06-29 13:14:07 --> Session routines successfully run
DEBUG - 2010-06-29 13:14:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:14:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:14:08 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:14:08 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 13:14:08 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 13:14:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:14:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:14:08 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:14:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:14:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:14:08 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:14:08 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 13:14:08 --> Final output sent to browser
DEBUG - 2010-06-29 13:14:08 --> Total execution time: 2.9335
DEBUG - 2010-06-29 13:16:43 --> Config Class Initialized
DEBUG - 2010-06-29 13:16:43 --> Hooks Class Initialized
DEBUG - 2010-06-29 13:16:43 --> URI Class Initialized
DEBUG - 2010-06-29 13:16:43 --> Router Class Initialized
DEBUG - 2010-06-29 13:16:43 --> Output Class Initialized
DEBUG - 2010-06-29 13:16:43 --> Input Class Initialized
DEBUG - 2010-06-29 13:16:43 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 13:16:44 --> Language Class Initialized
DEBUG - 2010-06-29 13:16:44 --> Loader Class Initialized
DEBUG - 2010-06-29 13:16:44 --> Helper loaded: context_helper
DEBUG - 2010-06-29 13:16:44 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 13:16:44 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 13:16:44 --> Database Driver Class Initialized
DEBUG - 2010-06-29 13:16:44 --> Controller Class Initialized
DEBUG - 2010-06-29 13:16:44 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 13:16:44 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 13:16:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:16:44 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:16:44 --> Helper loaded: email_helper
DEBUG - 2010-06-29 13:16:44 --> User Agent Class Initialized
DEBUG - 2010-06-29 13:16:44 --> Session Class Initialized
DEBUG - 2010-06-29 13:16:45 --> Helper loaded: string_helper
DEBUG - 2010-06-29 13:16:45 --> Session routines successfully run
DEBUG - 2010-06-29 13:16:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:16:45 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:16:45 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:16:45 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 13:16:45 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 13:16:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:16:45 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:16:46 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:16:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:16:46 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:16:46 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:16:46 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 13:16:46 --> Final output sent to browser
DEBUG - 2010-06-29 13:16:46 --> Total execution time: 2.9092
DEBUG - 2010-06-29 13:21:51 --> Config Class Initialized
DEBUG - 2010-06-29 13:21:51 --> Hooks Class Initialized
DEBUG - 2010-06-29 13:21:52 --> URI Class Initialized
DEBUG - 2010-06-29 13:21:52 --> Router Class Initialized
DEBUG - 2010-06-29 13:21:52 --> Output Class Initialized
DEBUG - 2010-06-29 13:21:52 --> Input Class Initialized
DEBUG - 2010-06-29 13:21:52 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 13:21:52 --> Language Class Initialized
DEBUG - 2010-06-29 13:21:52 --> Loader Class Initialized
DEBUG - 2010-06-29 13:21:52 --> Helper loaded: context_helper
DEBUG - 2010-06-29 13:21:52 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 13:21:52 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 13:21:52 --> Database Driver Class Initialized
DEBUG - 2010-06-29 13:21:52 --> Controller Class Initialized
DEBUG - 2010-06-29 13:21:52 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 13:21:53 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 13:21:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:21:53 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:21:53 --> Helper loaded: email_helper
DEBUG - 2010-06-29 13:21:53 --> User Agent Class Initialized
DEBUG - 2010-06-29 13:21:53 --> Session Class Initialized
DEBUG - 2010-06-29 13:21:53 --> Helper loaded: string_helper
DEBUG - 2010-06-29 13:21:53 --> Session routines successfully run
DEBUG - 2010-06-29 13:21:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:21:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:21:57 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:21:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:21:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:21:57 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:21:57 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 13:21:57 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 13:21:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:21:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:21:58 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:21:58 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 13:21:58 --> Final output sent to browser
DEBUG - 2010-06-29 13:21:58 --> Total execution time: 6.4120
DEBUG - 2010-06-29 13:29:03 --> Config Class Initialized
DEBUG - 2010-06-29 13:29:03 --> Hooks Class Initialized
DEBUG - 2010-06-29 13:29:04 --> URI Class Initialized
DEBUG - 2010-06-29 13:29:04 --> Router Class Initialized
DEBUG - 2010-06-29 13:29:04 --> Output Class Initialized
DEBUG - 2010-06-29 13:29:04 --> Input Class Initialized
DEBUG - 2010-06-29 13:29:04 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 13:29:04 --> Language Class Initialized
DEBUG - 2010-06-29 13:29:04 --> Loader Class Initialized
DEBUG - 2010-06-29 13:29:04 --> Helper loaded: context_helper
DEBUG - 2010-06-29 13:29:04 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 13:29:04 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 13:29:04 --> Database Driver Class Initialized
DEBUG - 2010-06-29 13:29:04 --> Controller Class Initialized
DEBUG - 2010-06-29 13:29:05 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 13:29:05 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 13:29:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:29:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:29:05 --> Helper loaded: email_helper
DEBUG - 2010-06-29 13:29:05 --> User Agent Class Initialized
DEBUG - 2010-06-29 13:29:05 --> Session Class Initialized
DEBUG - 2010-06-29 13:29:05 --> Helper loaded: string_helper
DEBUG - 2010-06-29 13:29:05 --> Session routines successfully run
DEBUG - 2010-06-29 13:29:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:29:06 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:29:06 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:29:06 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 13:29:06 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 13:29:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:29:06 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:29:06 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:29:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:29:06 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:29:06 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:29:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:29:06 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:29:06 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2010-06-29 13:29:07 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  duplicate key value violates unique constraint &quot;user_email_key&quot; D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-06-29 13:29:07 --> DB Transaction Failure
ERROR - 2010-06-29 13:29:07 --> Query error: ERROR:  duplicate key value violates unique constraint "user_email_key"
DEBUG - 2010-06-29 13:29:07 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-06-29 13:29:50 --> Config Class Initialized
DEBUG - 2010-06-29 13:29:50 --> Hooks Class Initialized
DEBUG - 2010-06-29 13:29:50 --> URI Class Initialized
DEBUG - 2010-06-29 13:29:50 --> Router Class Initialized
DEBUG - 2010-06-29 13:29:51 --> Output Class Initialized
DEBUG - 2010-06-29 13:29:51 --> Input Class Initialized
DEBUG - 2010-06-29 13:29:51 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 13:29:51 --> Language Class Initialized
DEBUG - 2010-06-29 13:29:51 --> Loader Class Initialized
DEBUG - 2010-06-29 13:29:51 --> Helper loaded: context_helper
DEBUG - 2010-06-29 13:29:51 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 13:29:51 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 13:29:51 --> Database Driver Class Initialized
DEBUG - 2010-06-29 13:29:51 --> Controller Class Initialized
DEBUG - 2010-06-29 13:29:51 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 13:29:51 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 13:29:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:29:51 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:29:52 --> Helper loaded: email_helper
DEBUG - 2010-06-29 13:29:52 --> User Agent Class Initialized
DEBUG - 2010-06-29 13:29:52 --> Session Class Initialized
DEBUG - 2010-06-29 13:29:52 --> Helper loaded: string_helper
DEBUG - 2010-06-29 13:29:52 --> Session routines successfully run
DEBUG - 2010-06-29 13:29:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:29:52 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:29:52 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:29:53 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 13:29:53 --> Config file loaded: config/kals.php
DEBUG - 2010-06-29 13:29:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:29:53 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:29:53 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:29:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:29:53 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:29:53 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:29:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:29:53 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:29:53 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:29:53 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 13:29:53 --> Final output sent to browser
DEBUG - 2010-06-29 13:29:53 --> Total execution time: 3.1990
DEBUG - 2010-06-29 13:56:07 --> Config Class Initialized
DEBUG - 2010-06-29 13:56:07 --> Hooks Class Initialized
DEBUG - 2010-06-29 13:56:07 --> URI Class Initialized
DEBUG - 2010-06-29 13:56:07 --> Router Class Initialized
DEBUG - 2010-06-29 13:56:07 --> Output Class Initialized
DEBUG - 2010-06-29 13:56:07 --> Input Class Initialized
DEBUG - 2010-06-29 13:56:07 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 13:56:07 --> Language Class Initialized
DEBUG - 2010-06-29 13:56:07 --> Loader Class Initialized
DEBUG - 2010-06-29 13:56:07 --> Helper loaded: context_helper
DEBUG - 2010-06-29 13:56:07 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 13:56:07 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 13:56:08 --> Database Driver Class Initialized
DEBUG - 2010-06-29 13:56:08 --> Controller Class Initialized
DEBUG - 2010-06-29 13:56:08 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 13:56:08 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 13:56:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:56:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:56:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:56:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:56:08 --> Helper loaded: email_helper
DEBUG - 2010-06-29 13:56:08 --> User Agent Class Initialized
DEBUG - 2010-06-29 13:56:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:56:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:56:09 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:56:09 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 13:56:09 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 14:07:30 --> Config Class Initialized
DEBUG - 2010-06-29 14:07:30 --> Hooks Class Initialized
DEBUG - 2010-06-29 14:07:30 --> URI Class Initialized
DEBUG - 2010-06-29 14:07:30 --> Router Class Initialized
DEBUG - 2010-06-29 14:07:31 --> Output Class Initialized
DEBUG - 2010-06-29 14:07:31 --> Input Class Initialized
DEBUG - 2010-06-29 14:07:31 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 14:07:31 --> Language Class Initialized
DEBUG - 2010-06-29 14:07:31 --> Loader Class Initialized
DEBUG - 2010-06-29 14:07:31 --> Helper loaded: context_helper
DEBUG - 2010-06-29 14:07:31 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 14:07:31 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 14:07:31 --> Database Driver Class Initialized
DEBUG - 2010-06-29 14:07:31 --> Controller Class Initialized
DEBUG - 2010-06-29 14:07:31 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 14:07:31 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 14:07:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:07:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:07:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:07:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:07:32 --> Helper loaded: email_helper
DEBUG - 2010-06-29 14:07:32 --> User Agent Class Initialized
DEBUG - 2010-06-29 14:07:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:07:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:07:35 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:07:35 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:07:35 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 14:07:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:07:36 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:07:36 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:07:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:07:37 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:07:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:07:37 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2010-06-29 14:07:37 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  null value in column &quot;actor_id&quot; violates not-null constraint D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-06-29 14:07:37 --> DB Transaction Failure
ERROR - 2010-06-29 14:07:37 --> Query error: ERROR:  null value in column "actor_id" violates not-null constraint
DEBUG - 2010-06-29 14:07:37 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-06-29 14:08:28 --> Config Class Initialized
DEBUG - 2010-06-29 14:08:28 --> Hooks Class Initialized
DEBUG - 2010-06-29 14:08:28 --> URI Class Initialized
DEBUG - 2010-06-29 14:08:28 --> Router Class Initialized
DEBUG - 2010-06-29 14:08:28 --> Output Class Initialized
DEBUG - 2010-06-29 14:08:29 --> Input Class Initialized
DEBUG - 2010-06-29 14:08:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 14:08:29 --> Language Class Initialized
DEBUG - 2010-06-29 14:08:29 --> Loader Class Initialized
DEBUG - 2010-06-29 14:08:29 --> Helper loaded: context_helper
DEBUG - 2010-06-29 14:08:29 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 14:08:29 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 14:08:29 --> Database Driver Class Initialized
DEBUG - 2010-06-29 14:08:29 --> Controller Class Initialized
DEBUG - 2010-06-29 14:08:29 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 14:08:29 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 14:08:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:08:29 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:08:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:08:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:08:30 --> Helper loaded: email_helper
DEBUG - 2010-06-29 14:08:30 --> User Agent Class Initialized
DEBUG - 2010-06-29 14:08:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:08:30 --> Session Class Initialized
DEBUG - 2010-06-29 14:08:30 --> Helper loaded: string_helper
DEBUG - 2010-06-29 14:08:30 --> Session routines successfully run
DEBUG - 2010-06-29 14:08:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:08:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:08:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:08:31 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 14:08:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:08:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:08:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:08:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:08:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:08:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:08:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:08:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:08:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:08:32 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2010-06-29 14:08:32 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  null value in column &quot;actor_id&quot; violates not-null constraint D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-06-29 14:08:32 --> DB Transaction Failure
ERROR - 2010-06-29 14:08:32 --> Query error: ERROR:  null value in column "actor_id" violates not-null constraint
DEBUG - 2010-06-29 14:08:32 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-06-29 14:08:50 --> Config Class Initialized
DEBUG - 2010-06-29 14:08:50 --> Hooks Class Initialized
DEBUG - 2010-06-29 14:08:50 --> URI Class Initialized
DEBUG - 2010-06-29 14:08:51 --> Router Class Initialized
DEBUG - 2010-06-29 14:08:51 --> Output Class Initialized
DEBUG - 2010-06-29 14:08:51 --> Input Class Initialized
DEBUG - 2010-06-29 14:08:51 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 14:08:51 --> Language Class Initialized
DEBUG - 2010-06-29 14:08:51 --> Loader Class Initialized
DEBUG - 2010-06-29 14:08:51 --> Helper loaded: context_helper
DEBUG - 2010-06-29 14:08:51 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 14:08:51 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 14:08:51 --> Database Driver Class Initialized
DEBUG - 2010-06-29 14:08:51 --> Controller Class Initialized
DEBUG - 2010-06-29 14:08:51 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 14:08:51 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 14:08:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:08:52 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:08:52 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:08:52 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:08:52 --> Helper loaded: email_helper
DEBUG - 2010-06-29 14:08:52 --> User Agent Class Initialized
DEBUG - 2010-06-29 14:08:52 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:08:52 --> Session Class Initialized
DEBUG - 2010-06-29 14:08:52 --> Helper loaded: string_helper
DEBUG - 2010-06-29 14:08:52 --> Session routines successfully run
DEBUG - 2010-06-29 14:08:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:08:53 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:08:53 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:08:53 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 14:08:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:08:53 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:08:53 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:08:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:08:53 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:08:53 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:08:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:08:54 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:08:54 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:08:54 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2010-06-29 14:08:54 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  null value in column &quot;actor_id&quot; violates not-null constraint D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-06-29 14:08:54 --> DB Transaction Failure
ERROR - 2010-06-29 14:08:54 --> Query error: ERROR:  null value in column "actor_id" violates not-null constraint
DEBUG - 2010-06-29 14:08:54 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-06-29 14:08:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:356) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-29 14:10:08 --> Config Class Initialized
DEBUG - 2010-06-29 14:10:08 --> Hooks Class Initialized
DEBUG - 2010-06-29 14:10:08 --> URI Class Initialized
DEBUG - 2010-06-29 14:10:08 --> Router Class Initialized
DEBUG - 2010-06-29 14:10:09 --> Output Class Initialized
DEBUG - 2010-06-29 14:10:09 --> Input Class Initialized
DEBUG - 2010-06-29 14:10:09 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 14:10:09 --> Language Class Initialized
DEBUG - 2010-06-29 14:10:09 --> Loader Class Initialized
DEBUG - 2010-06-29 14:10:09 --> Helper loaded: context_helper
DEBUG - 2010-06-29 14:10:09 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 14:10:09 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 14:10:09 --> Database Driver Class Initialized
DEBUG - 2010-06-29 14:10:09 --> Controller Class Initialized
DEBUG - 2010-06-29 14:10:09 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 14:10:09 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 14:10:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:10:10 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:10:10 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:10:10 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:10:10 --> Helper loaded: email_helper
DEBUG - 2010-06-29 14:10:10 --> User Agent Class Initialized
DEBUG - 2010-06-29 14:10:10 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:10:10 --> Session Class Initialized
DEBUG - 2010-06-29 14:10:10 --> Helper loaded: string_helper
DEBUG - 2010-06-29 14:10:10 --> Session routines successfully run
DEBUG - 2010-06-29 14:10:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:10:11 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:10:11 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:10:11 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 14:10:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:10:11 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:10:11 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:10:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:10:11 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:10:11 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:10:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:10:12 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:10:12 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:10:12 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:06 --> Config Class Initialized
DEBUG - 2010-06-29 14:12:06 --> Hooks Class Initialized
DEBUG - 2010-06-29 14:12:06 --> URI Class Initialized
DEBUG - 2010-06-29 14:12:06 --> Router Class Initialized
DEBUG - 2010-06-29 14:12:07 --> Output Class Initialized
DEBUG - 2010-06-29 14:12:07 --> Input Class Initialized
DEBUG - 2010-06-29 14:12:07 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 14:12:07 --> Language Class Initialized
DEBUG - 2010-06-29 14:12:07 --> Loader Class Initialized
DEBUG - 2010-06-29 14:12:07 --> Helper loaded: context_helper
DEBUG - 2010-06-29 14:12:07 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 14:12:07 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 14:12:07 --> Database Driver Class Initialized
DEBUG - 2010-06-29 14:12:07 --> Controller Class Initialized
DEBUG - 2010-06-29 14:12:07 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 14:12:08 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 14:12:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:08 --> Helper loaded: email_helper
DEBUG - 2010-06-29 14:12:08 --> User Agent Class Initialized
DEBUG - 2010-06-29 14:12:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:08 --> Session Class Initialized
DEBUG - 2010-06-29 14:12:08 --> Helper loaded: string_helper
DEBUG - 2010-06-29 14:12:08 --> Session routines successfully run
DEBUG - 2010-06-29 14:12:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:09 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:09 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:09 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 14:12:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:09 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:09 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:09 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:10 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:10 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:10 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:10 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2010-06-29 14:12:10 --> Severity: Notice  --> Undefined property: Group::$type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\Group.php 89
DEBUG - 2010-06-29 14:12:51 --> Config Class Initialized
DEBUG - 2010-06-29 14:12:51 --> Hooks Class Initialized
DEBUG - 2010-06-29 14:12:51 --> URI Class Initialized
DEBUG - 2010-06-29 14:12:51 --> Router Class Initialized
DEBUG - 2010-06-29 14:12:51 --> Output Class Initialized
DEBUG - 2010-06-29 14:12:51 --> Input Class Initialized
DEBUG - 2010-06-29 14:12:51 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 14:12:51 --> Language Class Initialized
DEBUG - 2010-06-29 14:12:51 --> Loader Class Initialized
DEBUG - 2010-06-29 14:12:51 --> Helper loaded: context_helper
DEBUG - 2010-06-29 14:12:52 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 14:12:52 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 14:12:52 --> Database Driver Class Initialized
DEBUG - 2010-06-29 14:12:52 --> Controller Class Initialized
DEBUG - 2010-06-29 14:12:52 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 14:12:52 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 14:12:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:52 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:52 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:52 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:52 --> Helper loaded: email_helper
DEBUG - 2010-06-29 14:12:52 --> User Agent Class Initialized
DEBUG - 2010-06-29 14:12:53 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:53 --> Session Class Initialized
DEBUG - 2010-06-29 14:12:53 --> Helper loaded: string_helper
DEBUG - 2010-06-29 14:12:53 --> Session routines successfully run
DEBUG - 2010-06-29 14:12:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:53 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:53 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:53 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 14:12:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:54 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:54 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:54 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:54 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:54 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:54 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:12:54 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:03 --> Config Class Initialized
DEBUG - 2010-06-29 14:13:03 --> Hooks Class Initialized
DEBUG - 2010-06-29 14:13:04 --> URI Class Initialized
DEBUG - 2010-06-29 14:13:04 --> Router Class Initialized
DEBUG - 2010-06-29 14:13:04 --> Output Class Initialized
DEBUG - 2010-06-29 14:13:04 --> Input Class Initialized
DEBUG - 2010-06-29 14:13:04 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 14:13:04 --> Language Class Initialized
DEBUG - 2010-06-29 14:13:04 --> Loader Class Initialized
DEBUG - 2010-06-29 14:13:04 --> Helper loaded: context_helper
DEBUG - 2010-06-29 14:13:04 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 14:13:04 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 14:13:04 --> Database Driver Class Initialized
DEBUG - 2010-06-29 14:13:04 --> Controller Class Initialized
DEBUG - 2010-06-29 14:13:05 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 14:13:05 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 14:13:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:05 --> Helper loaded: email_helper
DEBUG - 2010-06-29 14:13:05 --> User Agent Class Initialized
DEBUG - 2010-06-29 14:13:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:05 --> Session Class Initialized
DEBUG - 2010-06-29 14:13:05 --> Helper loaded: string_helper
DEBUG - 2010-06-29 14:13:05 --> Session routines successfully run
DEBUG - 2010-06-29 14:13:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:06 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:06 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 14:13:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:06 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:09 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:09 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2010-06-29 14:13:09 --> Severity: Notice  --> Undefined property: User::$id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\KALS_actor.php 57
ERROR - 2010-06-29 14:13:09 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\KALS_actor.php 40
ERROR - 2010-06-29 14:13:09 --> Severity: Notice  --> Undefined offset:  0 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_actor\ut_group.php 130
DEBUG - 2010-06-29 14:13:55 --> Config Class Initialized
DEBUG - 2010-06-29 14:13:55 --> Hooks Class Initialized
DEBUG - 2010-06-29 14:13:55 --> URI Class Initialized
DEBUG - 2010-06-29 14:13:55 --> Router Class Initialized
DEBUG - 2010-06-29 14:13:55 --> Output Class Initialized
DEBUG - 2010-06-29 14:13:55 --> Input Class Initialized
DEBUG - 2010-06-29 14:13:55 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 14:13:55 --> Language Class Initialized
DEBUG - 2010-06-29 14:13:55 --> Loader Class Initialized
DEBUG - 2010-06-29 14:13:55 --> Helper loaded: context_helper
DEBUG - 2010-06-29 14:13:55 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 14:13:55 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 14:13:55 --> Database Driver Class Initialized
DEBUG - 2010-06-29 14:13:56 --> Controller Class Initialized
DEBUG - 2010-06-29 14:13:56 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 14:13:56 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 14:13:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:56 --> Helper loaded: email_helper
DEBUG - 2010-06-29 14:13:56 --> User Agent Class Initialized
DEBUG - 2010-06-29 14:13:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:56 --> Session Class Initialized
DEBUG - 2010-06-29 14:13:57 --> Helper loaded: string_helper
DEBUG - 2010-06-29 14:13:57 --> Session routines successfully run
DEBUG - 2010-06-29 14:13:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:57 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 14:13:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:58 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:58 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:13:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:14:00 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:14:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:14:00 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:14:00 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:14:00 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2010-06-29 14:14:00 --> Severity: Warning  --> in_array() [<a href='function.in-array'>function.in-array</a>]: Wrong datatype for second argument D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\KALS_actor.php 66
ERROR - 2010-06-29 14:14:00 --> Severity: Warning  --> array_push() [<a href='function.array-push'>function.array-push</a>]: First argument should be an array D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\KALS_actor.php 68
DEBUG - 2010-06-29 14:14:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:14:00 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:14:00 --> User class already loaded. Second attempt ignored.
ERROR - 2010-06-29 14:14:00 --> Severity: Warning  --> in_array() [<a href='function.in-array'>function.in-array</a>]: Wrong datatype for second argument D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\KALS_actor.php 66
ERROR - 2010-06-29 14:14:00 --> Severity: Warning  --> array_push() [<a href='function.array-push'>function.array-push</a>]: First argument should be an array D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\KALS_actor.php 68
DEBUG - 2010-06-29 14:14:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:14:01 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:14:01 --> User class already loaded. Second attempt ignored.
ERROR - 2010-06-29 14:14:01 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\KALS_actor.php 40
ERROR - 2010-06-29 14:14:01 --> Severity: Notice  --> Undefined offset:  0 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_actor\ut_group.php 130
DEBUG - 2010-06-29 14:15:27 --> Config Class Initialized
DEBUG - 2010-06-29 14:15:27 --> Hooks Class Initialized
DEBUG - 2010-06-29 14:15:27 --> URI Class Initialized
DEBUG - 2010-06-29 14:15:28 --> Router Class Initialized
DEBUG - 2010-06-29 14:15:28 --> Output Class Initialized
DEBUG - 2010-06-29 14:15:28 --> Input Class Initialized
DEBUG - 2010-06-29 14:15:28 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 14:15:28 --> Language Class Initialized
DEBUG - 2010-06-29 14:15:28 --> Loader Class Initialized
DEBUG - 2010-06-29 14:15:28 --> Helper loaded: context_helper
DEBUG - 2010-06-29 14:15:28 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 14:15:28 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 14:15:28 --> Database Driver Class Initialized
DEBUG - 2010-06-29 14:15:28 --> Controller Class Initialized
DEBUG - 2010-06-29 14:15:29 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 14:15:29 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 14:15:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:29 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:29 --> Helper loaded: email_helper
DEBUG - 2010-06-29 14:15:29 --> User Agent Class Initialized
DEBUG - 2010-06-29 14:15:29 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:29 --> Session Class Initialized
DEBUG - 2010-06-29 14:15:29 --> Helper loaded: string_helper
DEBUG - 2010-06-29 14:15:29 --> Session routines successfully run
DEBUG - 2010-06-29 14:15:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:30 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 14:15:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:31 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:31 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:33 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:33 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:33 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2010-06-29 14:15:33 --> Severity: Warning  --> in_array() [<a href='function.in-array'>function.in-array</a>]: Wrong datatype for second argument D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\KALS_actor.php 67
ERROR - 2010-06-29 14:15:33 --> Severity: Warning  --> array_push() [<a href='function.array-push'>function.array-push</a>]: First argument should be an array D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\KALS_actor.php 69
DEBUG - 2010-06-29 14:15:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:33 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:33 --> User class already loaded. Second attempt ignored.
ERROR - 2010-06-29 14:15:33 --> Severity: Warning  --> in_array() [<a href='function.in-array'>function.in-array</a>]: Wrong datatype for second argument D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\KALS_actor.php 67
ERROR - 2010-06-29 14:15:33 --> Severity: Warning  --> array_push() [<a href='function.array-push'>function.array-push</a>]: First argument should be an array D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\KALS_actor.php 69
DEBUG - 2010-06-29 14:15:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:34 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:34 --> User class already loaded. Second attempt ignored.
ERROR - 2010-06-29 14:15:34 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\KALS_actor.php 40
ERROR - 2010-06-29 14:15:34 --> Severity: Notice  --> Undefined offset:  0 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_actor\ut_group.php 130
DEBUG - 2010-06-29 14:15:53 --> Config Class Initialized
DEBUG - 2010-06-29 14:15:53 --> Hooks Class Initialized
DEBUG - 2010-06-29 14:15:53 --> URI Class Initialized
DEBUG - 2010-06-29 14:15:53 --> Router Class Initialized
DEBUG - 2010-06-29 14:15:53 --> Output Class Initialized
DEBUG - 2010-06-29 14:15:53 --> Input Class Initialized
DEBUG - 2010-06-29 14:15:54 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 14:15:54 --> Language Class Initialized
DEBUG - 2010-06-29 14:15:54 --> Loader Class Initialized
DEBUG - 2010-06-29 14:15:54 --> Helper loaded: context_helper
DEBUG - 2010-06-29 14:15:54 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 14:15:54 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 14:15:54 --> Database Driver Class Initialized
DEBUG - 2010-06-29 14:15:54 --> Controller Class Initialized
DEBUG - 2010-06-29 14:15:54 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 14:15:54 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 14:15:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:55 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:55 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:55 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:55 --> Helper loaded: email_helper
DEBUG - 2010-06-29 14:15:55 --> User Agent Class Initialized
DEBUG - 2010-06-29 14:15:55 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:55 --> Session Class Initialized
DEBUG - 2010-06-29 14:15:55 --> Helper loaded: string_helper
DEBUG - 2010-06-29 14:15:55 --> Session routines successfully run
DEBUG - 2010-06-29 14:15:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:56 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 14:15:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:57 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:57 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:59 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:15:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:00 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:00 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:00 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:00 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:00 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:00 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:00 --> User class already loaded. Second attempt ignored.
ERROR - 2010-06-29 14:16:00 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  relation &quot;domain2user&quot; does not exist
LINE 1: DELETE FROM &quot;domain2user&quot;
                    ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-06-29 14:16:01 --> DB Transaction Failure
ERROR - 2010-06-29 14:16:01 --> Query error: ERROR:  relation "domain2user" does not exist
LINE 1: DELETE FROM "domain2user"
                    ^
DEBUG - 2010-06-29 14:16:01 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-06-29 14:16:01 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:377) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-29 14:16:10 --> Config Class Initialized
DEBUG - 2010-06-29 14:16:11 --> Hooks Class Initialized
DEBUG - 2010-06-29 14:16:11 --> URI Class Initialized
DEBUG - 2010-06-29 14:16:11 --> Router Class Initialized
DEBUG - 2010-06-29 14:16:11 --> Output Class Initialized
DEBUG - 2010-06-29 14:16:11 --> Input Class Initialized
DEBUG - 2010-06-29 14:16:11 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 14:16:11 --> Language Class Initialized
DEBUG - 2010-06-29 14:16:11 --> Loader Class Initialized
DEBUG - 2010-06-29 14:16:11 --> Helper loaded: context_helper
DEBUG - 2010-06-29 14:16:11 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 14:16:12 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 14:16:12 --> Database Driver Class Initialized
DEBUG - 2010-06-29 14:16:12 --> Controller Class Initialized
DEBUG - 2010-06-29 14:16:12 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 14:16:12 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 14:16:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:12 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:12 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:12 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:12 --> Helper loaded: email_helper
DEBUG - 2010-06-29 14:16:13 --> User Agent Class Initialized
DEBUG - 2010-06-29 14:16:13 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:13 --> Session Class Initialized
DEBUG - 2010-06-29 14:16:13 --> Helper loaded: string_helper
DEBUG - 2010-06-29 14:16:13 --> Session routines successfully run
DEBUG - 2010-06-29 14:16:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:13 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:14 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:14 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 14:16:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:14 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:14 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:14 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:14 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:14 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:14 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:14 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:15 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:15 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:15 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:15 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:16 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:16 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:16 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:16 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:16 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:17 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:17 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:17 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:17 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:18 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:18 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:18 --> User class already loaded. Second attempt ignored.
ERROR - 2010-06-29 14:16:18 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  relation &quot;domain2user&quot; does not exist
LINE 1: DELETE FROM &quot;domain2user&quot;
                    ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-06-29 14:16:18 --> DB Transaction Failure
ERROR - 2010-06-29 14:16:18 --> Query error: ERROR:  relation "domain2user" does not exist
LINE 1: DELETE FROM "domain2user"
                    ^
DEBUG - 2010-06-29 14:16:18 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-06-29 14:16:53 --> Config Class Initialized
DEBUG - 2010-06-29 14:16:53 --> Hooks Class Initialized
DEBUG - 2010-06-29 14:16:53 --> URI Class Initialized
DEBUG - 2010-06-29 14:16:53 --> Router Class Initialized
DEBUG - 2010-06-29 14:16:53 --> Output Class Initialized
DEBUG - 2010-06-29 14:16:54 --> Input Class Initialized
DEBUG - 2010-06-29 14:16:54 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 14:16:54 --> Language Class Initialized
DEBUG - 2010-06-29 14:16:54 --> Loader Class Initialized
DEBUG - 2010-06-29 14:16:54 --> Helper loaded: context_helper
DEBUG - 2010-06-29 14:16:54 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 14:16:54 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 14:16:54 --> Database Driver Class Initialized
DEBUG - 2010-06-29 14:16:54 --> Controller Class Initialized
DEBUG - 2010-06-29 14:16:54 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 14:16:54 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 14:16:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:55 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:55 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:55 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:55 --> Helper loaded: email_helper
DEBUG - 2010-06-29 14:16:55 --> User Agent Class Initialized
DEBUG - 2010-06-29 14:16:55 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:55 --> Session Class Initialized
DEBUG - 2010-06-29 14:16:55 --> Helper loaded: string_helper
DEBUG - 2010-06-29 14:16:55 --> Session routines successfully run
DEBUG - 2010-06-29 14:16:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:56 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 14:16:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:57 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:58 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:59 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:16:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:00 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:00 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:00 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:00 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:00 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:00 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:00 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:01 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:01 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:01 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:01 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:01 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:01 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:01 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 14:17:01 --> Final output sent to browser
DEBUG - 2010-06-29 14:17:02 --> Total execution time: 8.3609
DEBUG - 2010-06-29 14:17:43 --> Config Class Initialized
DEBUG - 2010-06-29 14:17:43 --> Hooks Class Initialized
DEBUG - 2010-06-29 14:17:43 --> URI Class Initialized
DEBUG - 2010-06-29 14:17:43 --> Router Class Initialized
DEBUG - 2010-06-29 14:17:43 --> Output Class Initialized
DEBUG - 2010-06-29 14:17:43 --> Input Class Initialized
DEBUG - 2010-06-29 14:17:43 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-29 14:17:44 --> Language Class Initialized
DEBUG - 2010-06-29 14:17:44 --> Loader Class Initialized
DEBUG - 2010-06-29 14:17:44 --> Helper loaded: context_helper
DEBUG - 2010-06-29 14:17:44 --> Helper loaded: kals_helper
DEBUG - 2010-06-29 14:17:44 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-29 14:17:44 --> Database Driver Class Initialized
DEBUG - 2010-06-29 14:17:44 --> Controller Class Initialized
DEBUG - 2010-06-29 14:17:44 --> Unit Testing Class Initialized
DEBUG - 2010-06-29 14:17:44 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-29 14:17:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:45 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:45 --> Helper loaded: email_helper
DEBUG - 2010-06-29 14:17:45 --> User Agent Class Initialized
DEBUG - 2010-06-29 14:17:45 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:45 --> Session Class Initialized
DEBUG - 2010-06-29 14:17:45 --> Helper loaded: string_helper
DEBUG - 2010-06-29 14:17:45 --> Session routines successfully run
DEBUG - 2010-06-29 14:17:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:46 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:46 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:46 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-29 14:17:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:46 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:46 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:47 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:47 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:47 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:47 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:47 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:47 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:47 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:48 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:48 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:48 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:48 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:49 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:49 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:49 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:49 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:49 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:49 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:49 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:50 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:50 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:50 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:50 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:51 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:51 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-29 14:17:51 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-29 14:17:51 --> Final output sent to browser
DEBUG - 2010-06-29 14:17:51 --> Total execution time: 8.3581
