<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2010-07-08 06:32:23 --> Config Class Initialized
DEBUG - 2010-07-08 06:32:23 --> Hooks Class Initialized
DEBUG - 2010-07-08 06:32:23 --> URI Class Initialized
DEBUG - 2010-07-08 06:32:23 --> No URI present. Default controller set.
DEBUG - 2010-07-08 06:32:23 --> Router Class Initialized
DEBUG - 2010-07-08 06:32:23 --> Output Class Initialized
DEBUG - 2010-07-08 06:32:23 --> Input Class Initialized
DEBUG - 2010-07-08 06:32:23 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 06:32:23 --> Language Class Initialized
DEBUG - 2010-07-08 06:32:23 --> Loader Class Initialized
DEBUG - 2010-07-08 06:32:23 --> Helper loaded: context_helper
DEBUG - 2010-07-08 06:32:23 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 06:32:23 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 06:32:23 --> Database Driver Class Initialized
DEBUG - 2010-07-08 06:32:23 --> Controller Class Initialized
DEBUG - 2010-07-08 06:32:23 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
ERROR - 2010-07-08 06:32:23 --> Severity: 4096  --> Argument 1 passed to Welcome::test() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\welcome.php on line 16 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\welcome.php 21
ERROR - 2010-07-08 06:32:23 --> Severity: 4096  --> Argument 1 passed to Welcome::test() must be an instance of String, integer given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\welcome.php on line 17 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\welcome.php 21
ERROR - 2010-07-08 06:32:23 --> Severity: 4096  --> Argument 1 passed to Welcome::test() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\welcome.php on line 18 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\welcome.php 21
DEBUG - 2010-07-08 06:32:23 --> Final output sent to browser
DEBUG - 2010-07-08 06:32:23 --> Total execution time: 1.0204
DEBUG - 2010-07-08 06:32:46 --> Config Class Initialized
DEBUG - 2010-07-08 06:32:46 --> Hooks Class Initialized
DEBUG - 2010-07-08 06:32:46 --> URI Class Initialized
DEBUG - 2010-07-08 06:32:46 --> No URI present. Default controller set.
DEBUG - 2010-07-08 06:32:46 --> Router Class Initialized
DEBUG - 2010-07-08 06:32:46 --> Output Class Initialized
DEBUG - 2010-07-08 06:32:46 --> Input Class Initialized
DEBUG - 2010-07-08 06:32:46 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 06:32:46 --> Language Class Initialized
DEBUG - 2010-07-08 06:32:46 --> Loader Class Initialized
DEBUG - 2010-07-08 06:32:46 --> Helper loaded: context_helper
DEBUG - 2010-07-08 06:32:46 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 06:32:46 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 06:32:46 --> Database Driver Class Initialized
DEBUG - 2010-07-08 06:32:46 --> Controller Class Initialized
DEBUG - 2010-07-08 06:32:46 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
ERROR - 2010-07-08 06:32:46 --> Severity: 4096  --> Argument 1 passed to Welcome::test() must be an instance of str, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\welcome.php on line 13 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\welcome.php 18
ERROR - 2010-07-08 06:32:46 --> Severity: 4096  --> Argument 1 passed to Welcome::test() must be an instance of str, integer given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\welcome.php on line 14 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\welcome.php 18
ERROR - 2010-07-08 06:32:46 --> Severity: 4096  --> Argument 1 passed to Welcome::test() must be an instance of str, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\welcome.php on line 15 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\welcome.php 18
DEBUG - 2010-07-08 06:32:46 --> Final output sent to browser
DEBUG - 2010-07-08 06:32:46 --> Total execution time: 0.1497
DEBUG - 2010-07-08 06:33:07 --> Config Class Initialized
DEBUG - 2010-07-08 06:33:07 --> Hooks Class Initialized
DEBUG - 2010-07-08 06:33:07 --> URI Class Initialized
DEBUG - 2010-07-08 06:33:07 --> No URI present. Default controller set.
DEBUG - 2010-07-08 06:33:07 --> Router Class Initialized
DEBUG - 2010-07-08 06:33:07 --> Output Class Initialized
DEBUG - 2010-07-08 06:33:07 --> Input Class Initialized
DEBUG - 2010-07-08 06:33:07 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 06:33:07 --> Language Class Initialized
DEBUG - 2010-07-08 06:33:07 --> Loader Class Initialized
DEBUG - 2010-07-08 06:33:07 --> Helper loaded: context_helper
DEBUG - 2010-07-08 06:33:07 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 06:33:07 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 06:33:07 --> Database Driver Class Initialized
DEBUG - 2010-07-08 06:33:07 --> Controller Class Initialized
DEBUG - 2010-07-08 06:33:07 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
ERROR - 2010-07-08 06:33:07 --> Severity: 4096  --> Argument 1 passed to Welcome::test() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\welcome.php on line 14 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\welcome.php 19
ERROR - 2010-07-08 06:33:07 --> Severity: 4096  --> Argument 1 passed to Welcome::test() must be an instance of String, integer given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\welcome.php on line 15 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\welcome.php 19
ERROR - 2010-07-08 06:33:07 --> Severity: 4096  --> Argument 1 passed to Welcome::test() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\welcome.php on line 16 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\welcome.php 19
DEBUG - 2010-07-08 06:33:07 --> Final output sent to browser
DEBUG - 2010-07-08 06:33:07 --> Total execution time: 0.1397
DEBUG - 2010-07-08 06:33:12 --> Config Class Initialized
DEBUG - 2010-07-08 06:33:12 --> Hooks Class Initialized
DEBUG - 2010-07-08 06:33:12 --> URI Class Initialized
DEBUG - 2010-07-08 06:33:12 --> No URI present. Default controller set.
DEBUG - 2010-07-08 06:33:12 --> Router Class Initialized
DEBUG - 2010-07-08 06:33:12 --> Output Class Initialized
DEBUG - 2010-07-08 06:33:12 --> Input Class Initialized
DEBUG - 2010-07-08 06:33:12 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 06:33:12 --> Language Class Initialized
DEBUG - 2010-07-08 06:33:12 --> Loader Class Initialized
DEBUG - 2010-07-08 06:33:12 --> Helper loaded: context_helper
DEBUG - 2010-07-08 06:33:12 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 06:33:12 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 06:33:12 --> Database Driver Class Initialized
DEBUG - 2010-07-08 06:33:12 --> Controller Class Initialized
DEBUG - 2010-07-08 06:33:12 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
ERROR - 2010-07-08 06:33:12 --> Severity: 4096  --> Argument 1 passed to Welcome::test() must be an instance of string, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\welcome.php on line 14 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\welcome.php 19
ERROR - 2010-07-08 06:33:12 --> Severity: 4096  --> Argument 1 passed to Welcome::test() must be an instance of string, integer given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\welcome.php on line 15 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\welcome.php 19
ERROR - 2010-07-08 06:33:12 --> Severity: 4096  --> Argument 1 passed to Welcome::test() must be an instance of string, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\welcome.php on line 16 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\welcome.php 19
DEBUG - 2010-07-08 06:33:12 --> Final output sent to browser
DEBUG - 2010-07-08 06:33:12 --> Total execution time: 0.1347
DEBUG - 2010-07-08 06:34:52 --> Config Class Initialized
DEBUG - 2010-07-08 06:34:52 --> Hooks Class Initialized
DEBUG - 2010-07-08 06:34:52 --> URI Class Initialized
DEBUG - 2010-07-08 06:34:52 --> No URI present. Default controller set.
DEBUG - 2010-07-08 06:34:52 --> Router Class Initialized
DEBUG - 2010-07-08 06:34:52 --> Output Class Initialized
DEBUG - 2010-07-08 06:34:52 --> Input Class Initialized
DEBUG - 2010-07-08 06:34:52 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 06:34:53 --> Language Class Initialized
DEBUG - 2010-07-08 06:34:53 --> Loader Class Initialized
DEBUG - 2010-07-08 06:34:53 --> Helper loaded: context_helper
DEBUG - 2010-07-08 06:34:53 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 06:34:53 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 06:34:53 --> Database Driver Class Initialized
DEBUG - 2010-07-08 06:34:53 --> Controller Class Initialized
DEBUG - 2010-07-08 06:34:53 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-07-08 06:35:04 --> Config Class Initialized
DEBUG - 2010-07-08 06:35:04 --> Hooks Class Initialized
DEBUG - 2010-07-08 06:35:04 --> URI Class Initialized
DEBUG - 2010-07-08 06:35:04 --> No URI present. Default controller set.
DEBUG - 2010-07-08 06:35:04 --> Router Class Initialized
DEBUG - 2010-07-08 06:35:04 --> Output Class Initialized
DEBUG - 2010-07-08 06:35:04 --> Input Class Initialized
DEBUG - 2010-07-08 06:35:04 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 06:35:04 --> Language Class Initialized
DEBUG - 2010-07-08 06:35:04 --> Loader Class Initialized
DEBUG - 2010-07-08 06:35:04 --> Helper loaded: context_helper
DEBUG - 2010-07-08 06:35:04 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 06:35:04 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 06:35:04 --> Database Driver Class Initialized
DEBUG - 2010-07-08 06:35:04 --> Controller Class Initialized
DEBUG - 2010-07-08 06:35:04 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-07-08 06:35:04 --> Final output sent to browser
DEBUG - 2010-07-08 06:35:04 --> Total execution time: 0.1942
DEBUG - 2010-07-08 06:35:20 --> Config Class Initialized
DEBUG - 2010-07-08 06:35:20 --> Hooks Class Initialized
DEBUG - 2010-07-08 06:35:20 --> URI Class Initialized
DEBUG - 2010-07-08 06:35:20 --> No URI present. Default controller set.
DEBUG - 2010-07-08 06:35:20 --> Router Class Initialized
DEBUG - 2010-07-08 06:35:20 --> Output Class Initialized
DEBUG - 2010-07-08 06:35:20 --> Input Class Initialized
DEBUG - 2010-07-08 06:35:20 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 06:35:20 --> Language Class Initialized
DEBUG - 2010-07-08 06:35:20 --> Loader Class Initialized
DEBUG - 2010-07-08 06:35:20 --> Helper loaded: context_helper
DEBUG - 2010-07-08 06:35:20 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 06:35:20 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 06:35:20 --> Database Driver Class Initialized
DEBUG - 2010-07-08 06:35:20 --> Controller Class Initialized
DEBUG - 2010-07-08 06:35:20 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-07-08 06:35:20 --> Final output sent to browser
DEBUG - 2010-07-08 06:35:20 --> Total execution time: 0.1620
DEBUG - 2010-07-08 08:28:13 --> Config Class Initialized
DEBUG - 2010-07-08 08:28:13 --> Hooks Class Initialized
DEBUG - 2010-07-08 08:28:13 --> URI Class Initialized
DEBUG - 2010-07-08 08:28:13 --> Router Class Initialized
DEBUG - 2010-07-08 08:28:13 --> Output Class Initialized
DEBUG - 2010-07-08 08:28:13 --> Input Class Initialized
DEBUG - 2010-07-08 08:28:13 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 08:28:13 --> Language Class Initialized
DEBUG - 2010-07-08 08:28:13 --> Loader Class Initialized
DEBUG - 2010-07-08 08:28:13 --> Helper loaded: context_helper
DEBUG - 2010-07-08 08:28:13 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 08:28:13 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 08:28:13 --> Database Driver Class Initialized
DEBUG - 2010-07-08 08:28:13 --> Controller Class Initialized
DEBUG - 2010-07-08 08:28:13 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 08:28:14 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 08:28:40 --> Config Class Initialized
DEBUG - 2010-07-08 08:28:40 --> Hooks Class Initialized
DEBUG - 2010-07-08 08:28:40 --> URI Class Initialized
DEBUG - 2010-07-08 08:28:40 --> Router Class Initialized
DEBUG - 2010-07-08 08:28:40 --> Output Class Initialized
DEBUG - 2010-07-08 08:28:40 --> Input Class Initialized
DEBUG - 2010-07-08 08:28:40 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 08:28:40 --> Language Class Initialized
DEBUG - 2010-07-08 08:28:40 --> Loader Class Initialized
DEBUG - 2010-07-08 08:28:40 --> Helper loaded: context_helper
DEBUG - 2010-07-08 08:28:40 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 08:28:40 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 08:28:40 --> Database Driver Class Initialized
DEBUG - 2010-07-08 08:28:40 --> Controller Class Initialized
DEBUG - 2010-07-08 08:28:40 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 08:28:40 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 08:28:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:28:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:28:40 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:28:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:28:40 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:28:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:28:40 --> Helper loaded: email_helper
DEBUG - 2010-07-08 08:28:40 --> User Agent Class Initialized
DEBUG - 2010-07-08 08:28:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:28:40 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:28:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:28:40 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 08:28:40 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:28:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:28:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:28:41 --> Session Class Initialized
DEBUG - 2010-07-08 08:28:41 --> Helper loaded: string_helper
DEBUG - 2010-07-08 08:28:41 --> A session cookie was not found.
DEBUG - 2010-07-08 08:28:41 --> Session routines successfully run
DEBUG - 2010-07-08 08:28:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:28:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:28:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:28:41 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:28:41 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:28:41 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:28:41 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:28:41 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:28:41 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:28:41 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:28:41 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:28:41 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:28:41 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:29:33 --> Config Class Initialized
DEBUG - 2010-07-08 08:29:33 --> Hooks Class Initialized
DEBUG - 2010-07-08 08:29:33 --> URI Class Initialized
DEBUG - 2010-07-08 08:29:33 --> Router Class Initialized
DEBUG - 2010-07-08 08:29:33 --> Output Class Initialized
DEBUG - 2010-07-08 08:29:33 --> Input Class Initialized
DEBUG - 2010-07-08 08:29:33 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 08:29:33 --> Language Class Initialized
DEBUG - 2010-07-08 08:29:33 --> Loader Class Initialized
DEBUG - 2010-07-08 08:29:33 --> Helper loaded: context_helper
DEBUG - 2010-07-08 08:29:33 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 08:29:33 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 08:29:33 --> Database Driver Class Initialized
DEBUG - 2010-07-08 08:29:33 --> Controller Class Initialized
DEBUG - 2010-07-08 08:29:33 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 08:29:33 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 08:29:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:29:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:29:33 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:29:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:29:33 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:29:33 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:29:33 --> Helper loaded: email_helper
DEBUG - 2010-07-08 08:29:33 --> User Agent Class Initialized
DEBUG - 2010-07-08 08:29:33 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:29:33 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:29:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:29:34 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 08:29:34 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:29:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:29:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:29:34 --> Session Class Initialized
DEBUG - 2010-07-08 08:29:34 --> Helper loaded: string_helper
DEBUG - 2010-07-08 08:29:34 --> Session routines successfully run
DEBUG - 2010-07-08 08:29:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:29:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:29:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:29:34 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:29:34 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:29:34 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:29:34 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:29:34 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:29:34 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:29:34 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:29:34 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:29:34 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:29:34 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:29:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:29:34 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:29:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:29:34 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:29:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:29:34 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:29:34 --> Annotation class already loaded. Second attempt ignored.
ERROR - 2010-07-08 08:29:34 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;anntation_id&quot; does not exist
LINE 3: WHERE &quot;anntation_id&quot; = 59
              ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-08 08:29:34 --> DB Transaction Failure
ERROR - 2010-07-08 08:29:34 --> Query error: ERROR:  column "anntation_id" does not exist
LINE 3: WHERE "anntation_id" = 59
              ^
DEBUG - 2010-07-08 08:29:34 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-07-08 08:30:17 --> Config Class Initialized
DEBUG - 2010-07-08 08:30:17 --> Hooks Class Initialized
DEBUG - 2010-07-08 08:30:17 --> URI Class Initialized
DEBUG - 2010-07-08 08:30:17 --> Router Class Initialized
DEBUG - 2010-07-08 08:30:17 --> Output Class Initialized
DEBUG - 2010-07-08 08:30:17 --> Input Class Initialized
DEBUG - 2010-07-08 08:30:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 08:30:17 --> Language Class Initialized
DEBUG - 2010-07-08 08:30:17 --> Loader Class Initialized
DEBUG - 2010-07-08 08:30:17 --> Helper loaded: context_helper
DEBUG - 2010-07-08 08:30:17 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 08:30:17 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 08:30:17 --> Database Driver Class Initialized
DEBUG - 2010-07-08 08:30:17 --> Controller Class Initialized
DEBUG - 2010-07-08 08:30:17 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 08:30:17 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 08:30:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:17 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:17 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:17 --> Helper loaded: email_helper
DEBUG - 2010-07-08 08:30:17 --> User Agent Class Initialized
DEBUG - 2010-07-08 08:30:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:17 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:17 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 08:30:17 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:17 --> Session Class Initialized
DEBUG - 2010-07-08 08:30:17 --> Helper loaded: string_helper
DEBUG - 2010-07-08 08:30:17 --> Session routines successfully run
DEBUG - 2010-07-08 08:30:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:17 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:17 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:17 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:17 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:17 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:17 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:17 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:17 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:17 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:17 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:17 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:17 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:17 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:17 --> Annotation class already loaded. Second attempt ignored.
ERROR - 2010-07-08 08:30:18 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;)&quot;
LINE 3: AND &quot;scope_id&quot; IN () 
                           ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-08 08:30:18 --> DB Transaction Failure
ERROR - 2010-07-08 08:30:18 --> Query error: ERROR:  syntax error at or near ")"
LINE 3: AND "scope_id" IN () 
                           ^
DEBUG - 2010-07-08 08:30:18 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-07-08 08:30:53 --> Config Class Initialized
DEBUG - 2010-07-08 08:30:53 --> Hooks Class Initialized
DEBUG - 2010-07-08 08:30:53 --> URI Class Initialized
DEBUG - 2010-07-08 08:30:53 --> Router Class Initialized
DEBUG - 2010-07-08 08:30:53 --> Output Class Initialized
DEBUG - 2010-07-08 08:30:53 --> Input Class Initialized
DEBUG - 2010-07-08 08:30:53 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 08:30:53 --> Language Class Initialized
DEBUG - 2010-07-08 08:30:53 --> Loader Class Initialized
DEBUG - 2010-07-08 08:30:53 --> Helper loaded: context_helper
DEBUG - 2010-07-08 08:30:53 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 08:30:53 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 08:30:54 --> Database Driver Class Initialized
DEBUG - 2010-07-08 08:30:54 --> Controller Class Initialized
DEBUG - 2010-07-08 08:30:54 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 08:30:54 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 08:30:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> Helper loaded: email_helper
DEBUG - 2010-07-08 08:30:54 --> User Agent Class Initialized
DEBUG - 2010-07-08 08:30:54 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 08:30:54 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> Session Class Initialized
DEBUG - 2010-07-08 08:30:54 --> Helper loaded: string_helper
DEBUG - 2010-07-08 08:30:54 --> Session routines successfully run
DEBUG - 2010-07-08 08:30:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 08:30:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:54 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:30:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:29 --> Config Class Initialized
DEBUG - 2010-07-08 08:32:29 --> Hooks Class Initialized
DEBUG - 2010-07-08 08:32:29 --> URI Class Initialized
DEBUG - 2010-07-08 08:32:29 --> Router Class Initialized
DEBUG - 2010-07-08 08:32:29 --> Output Class Initialized
DEBUG - 2010-07-08 08:32:29 --> Input Class Initialized
DEBUG - 2010-07-08 08:32:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 08:32:29 --> Language Class Initialized
DEBUG - 2010-07-08 08:32:29 --> Loader Class Initialized
DEBUG - 2010-07-08 08:32:29 --> Helper loaded: context_helper
DEBUG - 2010-07-08 08:32:29 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 08:32:29 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 08:32:29 --> Database Driver Class Initialized
DEBUG - 2010-07-08 08:32:29 --> Controller Class Initialized
DEBUG - 2010-07-08 08:32:29 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 08:32:29 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 08:32:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:29 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:29 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:29 --> Helper loaded: email_helper
DEBUG - 2010-07-08 08:32:29 --> User Agent Class Initialized
DEBUG - 2010-07-08 08:32:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:29 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:29 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 08:32:29 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:29 --> Session Class Initialized
DEBUG - 2010-07-08 08:32:29 --> Helper loaded: string_helper
DEBUG - 2010-07-08 08:32:29 --> Session routines successfully run
DEBUG - 2010-07-08 08:32:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:30 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:30 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:30 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:30 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:30 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:30 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:30 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:30 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:30 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:30 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:30 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:30 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:30 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:30 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 08:32:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:30 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:30 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:30 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:30 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:30 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:32:30 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-08 08:32:30 --> Annotation_scope_collection::_load_annotation_scope is not callable as a parameter to onload
DEBUG - 2010-07-08 08:33:05 --> Config Class Initialized
DEBUG - 2010-07-08 08:33:05 --> Hooks Class Initialized
DEBUG - 2010-07-08 08:33:05 --> URI Class Initialized
DEBUG - 2010-07-08 08:33:05 --> Router Class Initialized
DEBUG - 2010-07-08 08:33:05 --> Output Class Initialized
DEBUG - 2010-07-08 08:33:05 --> Input Class Initialized
DEBUG - 2010-07-08 08:33:05 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 08:33:05 --> Language Class Initialized
DEBUG - 2010-07-08 08:33:05 --> Loader Class Initialized
DEBUG - 2010-07-08 08:33:05 --> Helper loaded: context_helper
DEBUG - 2010-07-08 08:33:05 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 08:33:05 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 08:33:05 --> Database Driver Class Initialized
DEBUG - 2010-07-08 08:33:05 --> Controller Class Initialized
DEBUG - 2010-07-08 08:33:05 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 08:33:05 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 08:33:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> Helper loaded: email_helper
DEBUG - 2010-07-08 08:33:06 --> User Agent Class Initialized
DEBUG - 2010-07-08 08:33:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 08:33:06 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> Session Class Initialized
DEBUG - 2010-07-08 08:33:06 --> Helper loaded: string_helper
DEBUG - 2010-07-08 08:33:06 --> Session routines successfully run
DEBUG - 2010-07-08 08:33:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 08:33:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:06 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-08 08:33:06 --> Annotation_scope_collection::_load_annotation_scopes is not callable as a parameter to onload
DEBUG - 2010-07-08 08:33:18 --> Config Class Initialized
DEBUG - 2010-07-08 08:33:18 --> Hooks Class Initialized
DEBUG - 2010-07-08 08:33:18 --> URI Class Initialized
DEBUG - 2010-07-08 08:33:18 --> Router Class Initialized
DEBUG - 2010-07-08 08:33:18 --> Output Class Initialized
DEBUG - 2010-07-08 08:33:18 --> Input Class Initialized
DEBUG - 2010-07-08 08:33:18 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 08:33:19 --> Language Class Initialized
DEBUG - 2010-07-08 08:33:19 --> Loader Class Initialized
DEBUG - 2010-07-08 08:33:19 --> Helper loaded: context_helper
DEBUG - 2010-07-08 08:33:19 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 08:33:19 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 08:33:19 --> Database Driver Class Initialized
DEBUG - 2010-07-08 08:33:19 --> Controller Class Initialized
DEBUG - 2010-07-08 08:33:19 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 08:33:19 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 08:33:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:19 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:19 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:19 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:19 --> Helper loaded: email_helper
DEBUG - 2010-07-08 08:33:19 --> User Agent Class Initialized
DEBUG - 2010-07-08 08:33:19 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:19 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:19 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 08:33:19 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:19 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:19 --> Session Class Initialized
DEBUG - 2010-07-08 08:33:19 --> Helper loaded: string_helper
DEBUG - 2010-07-08 08:33:19 --> Session routines successfully run
DEBUG - 2010-07-08 08:33:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:19 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:19 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:19 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:19 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:19 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:19 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:19 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:19 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:19 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:19 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:19 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:19 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:19 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:19 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:19 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:20 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 08:33:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:20 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:20 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:20 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:20 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:20 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:20 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:20 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:20 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-08 08:33:20 --> Annotation_scope_collection::_load_annotation_scopes is not callable as a parameter to onload
DEBUG - 2010-07-08 08:33:55 --> Config Class Initialized
DEBUG - 2010-07-08 08:33:55 --> Hooks Class Initialized
DEBUG - 2010-07-08 08:33:55 --> URI Class Initialized
DEBUG - 2010-07-08 08:33:55 --> Router Class Initialized
DEBUG - 2010-07-08 08:33:55 --> Output Class Initialized
DEBUG - 2010-07-08 08:33:55 --> Input Class Initialized
DEBUG - 2010-07-08 08:33:55 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 08:33:55 --> Language Class Initialized
DEBUG - 2010-07-08 08:33:55 --> Loader Class Initialized
DEBUG - 2010-07-08 08:33:55 --> Helper loaded: context_helper
DEBUG - 2010-07-08 08:33:55 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 08:33:55 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 08:33:55 --> Database Driver Class Initialized
DEBUG - 2010-07-08 08:33:56 --> Controller Class Initialized
DEBUG - 2010-07-08 08:33:56 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 08:33:56 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 08:33:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:56 --> Helper loaded: email_helper
DEBUG - 2010-07-08 08:33:56 --> User Agent Class Initialized
DEBUG - 2010-07-08 08:33:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:56 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:56 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 08:33:56 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:56 --> Session Class Initialized
DEBUG - 2010-07-08 08:33:56 --> Helper loaded: string_helper
DEBUG - 2010-07-08 08:33:56 --> Session routines successfully run
DEBUG - 2010-07-08 08:33:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:56 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:56 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:56 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:56 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:56 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:56 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:56 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:56 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:56 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:56 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:56 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:56 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:56 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:56 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 08:33:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:57 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:57 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:57 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:57 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:57 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:57 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-08 08:33:57 --> Severity: Notice  --> Undefined property: Annotation_scope_collection::$_sorted D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Annotation_scope_collection.php 299
ERROR - 2010-07-08 08:33:57 --> Severity: Notice  --> Undefined property: Annotation_scope_collection::$_sorted D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Annotation_scope_collection.php 299
DEBUG - 2010-07-08 08:33:57 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:57 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:57 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:57 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:57 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:57 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:57 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:57 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:57 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:57 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:33:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:35 --> Config Class Initialized
DEBUG - 2010-07-08 08:34:35 --> Hooks Class Initialized
DEBUG - 2010-07-08 08:34:35 --> URI Class Initialized
DEBUG - 2010-07-08 08:34:35 --> Router Class Initialized
DEBUG - 2010-07-08 08:34:35 --> Output Class Initialized
DEBUG - 2010-07-08 08:34:35 --> Input Class Initialized
DEBUG - 2010-07-08 08:34:35 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 08:34:35 --> Language Class Initialized
DEBUG - 2010-07-08 08:34:35 --> Loader Class Initialized
DEBUG - 2010-07-08 08:34:35 --> Helper loaded: context_helper
DEBUG - 2010-07-08 08:34:36 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 08:34:36 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 08:34:36 --> Database Driver Class Initialized
DEBUG - 2010-07-08 08:34:36 --> Controller Class Initialized
DEBUG - 2010-07-08 08:34:36 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 08:34:36 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 08:34:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:36 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:36 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:36 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:36 --> Helper loaded: email_helper
DEBUG - 2010-07-08 08:34:36 --> User Agent Class Initialized
DEBUG - 2010-07-08 08:34:36 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:36 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:36 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 08:34:36 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:36 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:36 --> Session Class Initialized
DEBUG - 2010-07-08 08:34:36 --> Helper loaded: string_helper
DEBUG - 2010-07-08 08:34:36 --> Session routines successfully run
DEBUG - 2010-07-08 08:34:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:36 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:36 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:36 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:36 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:36 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:36 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:36 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:37 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:37 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:37 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 08:34:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:37 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:37 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:37 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:37 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:37 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:37 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:34:37 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-08 08:34:37 --> Annotation_scope_collection::_load_annotation_scopes is not callable as a parameter to onload
DEBUG - 2010-07-08 08:35:07 --> Config Class Initialized
DEBUG - 2010-07-08 08:35:07 --> Hooks Class Initialized
DEBUG - 2010-07-08 08:35:07 --> URI Class Initialized
DEBUG - 2010-07-08 08:35:07 --> Router Class Initialized
DEBUG - 2010-07-08 08:35:07 --> Output Class Initialized
DEBUG - 2010-07-08 08:35:07 --> Input Class Initialized
DEBUG - 2010-07-08 08:35:07 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 08:35:07 --> Language Class Initialized
DEBUG - 2010-07-08 08:35:07 --> Loader Class Initialized
DEBUG - 2010-07-08 08:35:07 --> Helper loaded: context_helper
DEBUG - 2010-07-08 08:35:07 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 08:35:08 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 08:35:08 --> Database Driver Class Initialized
DEBUG - 2010-07-08 08:35:08 --> Controller Class Initialized
DEBUG - 2010-07-08 08:35:08 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 08:35:08 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 08:35:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:08 --> Helper loaded: email_helper
DEBUG - 2010-07-08 08:35:08 --> User Agent Class Initialized
DEBUG - 2010-07-08 08:35:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:08 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:08 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 08:35:08 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:08 --> Session Class Initialized
DEBUG - 2010-07-08 08:35:08 --> Helper loaded: string_helper
DEBUG - 2010-07-08 08:35:08 --> Session routines successfully run
DEBUG - 2010-07-08 08:35:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:08 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:08 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:08 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:08 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:08 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:08 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:08 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:08 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:08 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:08 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:09 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:09 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:09 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:09 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:09 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 08:35:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:09 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:09 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:09 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:09 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:09 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:09 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:09 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:09 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-08 08:35:09 --> Annotation_scope_collection::_load_annotation_scopes is not callable as a parameter to onload
DEBUG - 2010-07-08 08:35:21 --> Config Class Initialized
DEBUG - 2010-07-08 08:35:21 --> Hooks Class Initialized
DEBUG - 2010-07-08 08:35:21 --> URI Class Initialized
DEBUG - 2010-07-08 08:35:21 --> Router Class Initialized
DEBUG - 2010-07-08 08:35:21 --> Output Class Initialized
DEBUG - 2010-07-08 08:35:21 --> Input Class Initialized
DEBUG - 2010-07-08 08:35:21 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 08:35:21 --> Language Class Initialized
DEBUG - 2010-07-08 08:35:21 --> Loader Class Initialized
DEBUG - 2010-07-08 08:35:21 --> Helper loaded: context_helper
DEBUG - 2010-07-08 08:35:21 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 08:35:21 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 08:35:21 --> Database Driver Class Initialized
DEBUG - 2010-07-08 08:35:21 --> Controller Class Initialized
DEBUG - 2010-07-08 08:35:21 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 08:35:21 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 08:35:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:21 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:22 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:22 --> Helper loaded: email_helper
DEBUG - 2010-07-08 08:35:22 --> User Agent Class Initialized
DEBUG - 2010-07-08 08:35:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:22 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:22 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 08:35:22 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:22 --> Session Class Initialized
DEBUG - 2010-07-08 08:35:22 --> Helper loaded: string_helper
DEBUG - 2010-07-08 08:35:22 --> Session routines successfully run
DEBUG - 2010-07-08 08:35:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:22 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:22 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:22 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:22 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:22 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:22 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:22 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:22 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:22 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:22 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:22 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:22 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:22 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:22 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:22 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 08:35:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:23 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:23 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:23 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:23 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:23 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:23 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:23 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:23 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:23 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:23 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:23 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:35:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:00 --> Config Class Initialized
DEBUG - 2010-07-08 08:37:00 --> Hooks Class Initialized
DEBUG - 2010-07-08 08:37:01 --> URI Class Initialized
DEBUG - 2010-07-08 08:37:01 --> Router Class Initialized
DEBUG - 2010-07-08 08:37:01 --> Output Class Initialized
ERROR - 2010-07-08 08:37:01 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/d2ddea18f00665ce8623e36bd4e3c7c5) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
DEBUG - 2010-07-08 08:37:01 --> Input Class Initialized
DEBUG - 2010-07-08 08:37:01 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 08:37:01 --> Language Class Initialized
DEBUG - 2010-07-08 08:37:01 --> Loader Class Initialized
DEBUG - 2010-07-08 08:37:01 --> Helper loaded: context_helper
DEBUG - 2010-07-08 08:37:01 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 08:37:01 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 08:37:01 --> Database Driver Class Initialized
DEBUG - 2010-07-08 08:37:01 --> Controller Class Initialized
DEBUG - 2010-07-08 08:37:01 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 08:37:01 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 08:37:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:01 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:01 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:01 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:01 --> Helper loaded: email_helper
DEBUG - 2010-07-08 08:37:01 --> User Agent Class Initialized
DEBUG - 2010-07-08 08:37:01 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:01 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:01 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 08:37:01 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:01 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:01 --> Session Class Initialized
DEBUG - 2010-07-08 08:37:02 --> Helper loaded: string_helper
DEBUG - 2010-07-08 08:37:02 --> Session routines successfully run
DEBUG - 2010-07-08 08:37:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:02 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:02 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:02 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:02 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:02 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:02 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:02 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:02 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:02 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:02 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:02 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:02 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:02 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:02 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:02 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:02 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 08:37:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:02 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:02 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:02 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:02 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:02 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:02 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:02 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:03 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:03 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:03 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:03 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:03 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:03 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:03 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:03 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:03 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:03 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:03 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:03 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:37:03 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 08:37:03 --> Final output sent to browser
DEBUG - 2010-07-08 08:37:03 --> Total execution time: 2.6462
DEBUG - 2010-07-08 08:39:15 --> Config Class Initialized
DEBUG - 2010-07-08 08:39:15 --> Hooks Class Initialized
DEBUG - 2010-07-08 08:39:15 --> URI Class Initialized
DEBUG - 2010-07-08 08:39:15 --> Router Class Initialized
DEBUG - 2010-07-08 08:39:15 --> Output Class Initialized
DEBUG - 2010-07-08 08:39:15 --> Input Class Initialized
DEBUG - 2010-07-08 08:39:15 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 08:39:15 --> Language Class Initialized
DEBUG - 2010-07-08 08:39:15 --> Loader Class Initialized
DEBUG - 2010-07-08 08:39:16 --> Helper loaded: context_helper
DEBUG - 2010-07-08 08:39:16 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 08:39:16 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 08:39:16 --> Database Driver Class Initialized
DEBUG - 2010-07-08 08:39:16 --> Controller Class Initialized
DEBUG - 2010-07-08 08:39:16 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 08:39:16 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 08:39:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:16 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:16 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:16 --> Helper loaded: email_helper
DEBUG - 2010-07-08 08:39:16 --> User Agent Class Initialized
DEBUG - 2010-07-08 08:39:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:16 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:16 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 08:39:16 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:16 --> Session Class Initialized
DEBUG - 2010-07-08 08:39:16 --> Helper loaded: string_helper
DEBUG - 2010-07-08 08:39:16 --> Session routines successfully run
DEBUG - 2010-07-08 08:39:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:16 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:17 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:17 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:17 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:17 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:17 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:17 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:17 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:17 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:17 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:17 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:17 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:17 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:17 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:17 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 08:39:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:17 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:17 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:17 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:17 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:17 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:17 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:17 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:17 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:18 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:18 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:18 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:18 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:18 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:18 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:18 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:18 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:18 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:18 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:39:18 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 08:39:18 --> Final output sent to browser
DEBUG - 2010-07-08 08:39:18 --> Total execution time: 2.7968
DEBUG - 2010-07-08 08:40:47 --> Config Class Initialized
DEBUG - 2010-07-08 08:40:47 --> Hooks Class Initialized
DEBUG - 2010-07-08 08:40:47 --> URI Class Initialized
DEBUG - 2010-07-08 08:40:47 --> Router Class Initialized
DEBUG - 2010-07-08 08:40:47 --> Output Class Initialized
DEBUG - 2010-07-08 08:40:48 --> Input Class Initialized
DEBUG - 2010-07-08 08:40:48 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 08:40:48 --> Language Class Initialized
DEBUG - 2010-07-08 08:40:48 --> Loader Class Initialized
DEBUG - 2010-07-08 08:40:48 --> Helper loaded: context_helper
DEBUG - 2010-07-08 08:40:48 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 08:40:48 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 08:40:48 --> Database Driver Class Initialized
DEBUG - 2010-07-08 08:40:48 --> Controller Class Initialized
DEBUG - 2010-07-08 08:40:48 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 08:40:48 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 08:40:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:48 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:48 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:48 --> Helper loaded: email_helper
DEBUG - 2010-07-08 08:40:48 --> User Agent Class Initialized
DEBUG - 2010-07-08 08:40:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:48 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:48 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:48 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 08:40:48 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:48 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:48 --> Session Class Initialized
DEBUG - 2010-07-08 08:40:49 --> Helper loaded: string_helper
DEBUG - 2010-07-08 08:40:49 --> Session routines successfully run
DEBUG - 2010-07-08 08:40:49 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:49 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:49 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:49 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:49 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:49 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:49 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:49 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:49 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:49 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:49 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:49 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:49 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:49 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:49 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:49 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:49 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:49 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:49 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 08:40:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:49 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:49 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:49 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:49 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:50 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:50 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:50 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:50 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:50 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:50 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:50 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:50 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:50 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:50 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:50 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:50 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:50 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:50 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:50 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:50 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:50 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:40:50 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 08:40:50 --> Final output sent to browser
DEBUG - 2010-07-08 08:40:50 --> Total execution time: 3.0282
DEBUG - 2010-07-08 08:44:23 --> Config Class Initialized
DEBUG - 2010-07-08 08:44:23 --> Hooks Class Initialized
DEBUG - 2010-07-08 08:44:23 --> URI Class Initialized
DEBUG - 2010-07-08 08:44:23 --> Router Class Initialized
DEBUG - 2010-07-08 08:44:23 --> Output Class Initialized
DEBUG - 2010-07-08 08:44:23 --> Input Class Initialized
DEBUG - 2010-07-08 08:44:23 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 08:44:23 --> Language Class Initialized
DEBUG - 2010-07-08 08:44:23 --> Loader Class Initialized
DEBUG - 2010-07-08 08:44:23 --> Helper loaded: context_helper
DEBUG - 2010-07-08 08:44:23 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 08:44:23 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 08:44:23 --> Database Driver Class Initialized
DEBUG - 2010-07-08 08:44:23 --> Controller Class Initialized
DEBUG - 2010-07-08 08:44:23 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 08:44:23 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 08:44:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:23 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:23 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:23 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:24 --> Helper loaded: email_helper
DEBUG - 2010-07-08 08:44:24 --> User Agent Class Initialized
DEBUG - 2010-07-08 08:44:24 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:24 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:24 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 08:44:24 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:24 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:24 --> Session Class Initialized
DEBUG - 2010-07-08 08:44:24 --> Helper loaded: string_helper
DEBUG - 2010-07-08 08:44:24 --> Session routines successfully run
DEBUG - 2010-07-08 08:44:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:24 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:24 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:24 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:24 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:24 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:24 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:24 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:24 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:24 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:24 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:24 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:25 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:25 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:25 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:25 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 08:44:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:25 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:25 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:25 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:25 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:25 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:25 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-08 08:44:25 --> Severity: 4096  --> Object of class Annotation_scope_collection could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 411
DEBUG - 2010-07-08 08:44:25 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:25 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:25 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:25 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:25 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:25 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:25 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:26 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:26 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:26 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:26 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:44:26 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 08:44:26 --> Final output sent to browser
DEBUG - 2010-07-08 08:44:26 --> Total execution time: 3.2442
DEBUG - 2010-07-08 08:45:27 --> Config Class Initialized
DEBUG - 2010-07-08 08:45:27 --> Hooks Class Initialized
DEBUG - 2010-07-08 08:45:27 --> URI Class Initialized
DEBUG - 2010-07-08 08:45:27 --> Router Class Initialized
DEBUG - 2010-07-08 08:45:27 --> Output Class Initialized
DEBUG - 2010-07-08 08:45:27 --> Input Class Initialized
DEBUG - 2010-07-08 08:45:27 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 08:45:27 --> Language Class Initialized
DEBUG - 2010-07-08 08:45:27 --> Loader Class Initialized
DEBUG - 2010-07-08 08:45:27 --> Helper loaded: context_helper
DEBUG - 2010-07-08 08:45:27 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 08:45:27 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 08:45:27 --> Database Driver Class Initialized
DEBUG - 2010-07-08 08:45:28 --> Controller Class Initialized
DEBUG - 2010-07-08 08:45:28 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 08:45:28 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 08:45:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:28 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:28 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:28 --> Helper loaded: email_helper
DEBUG - 2010-07-08 08:45:28 --> User Agent Class Initialized
DEBUG - 2010-07-08 08:45:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:28 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:28 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 08:45:28 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:28 --> Session Class Initialized
DEBUG - 2010-07-08 08:45:28 --> Helper loaded: string_helper
DEBUG - 2010-07-08 08:45:28 --> Session routines successfully run
DEBUG - 2010-07-08 08:45:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:28 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:29 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:29 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:29 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:29 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:29 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:29 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:29 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:29 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:29 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:29 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:29 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:29 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:29 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:29 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 08:45:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:29 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:29 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:29 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:29 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:29 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:30 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:30 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:30 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:30 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:30 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:30 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:30 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:30 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:30 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:30 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:30 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:45:30 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 08:45:30 --> Final output sent to browser
DEBUG - 2010-07-08 08:45:30 --> Total execution time: 3.3039
DEBUG - 2010-07-08 08:46:08 --> Config Class Initialized
DEBUG - 2010-07-08 08:46:08 --> Hooks Class Initialized
DEBUG - 2010-07-08 08:46:08 --> URI Class Initialized
DEBUG - 2010-07-08 08:46:08 --> Router Class Initialized
DEBUG - 2010-07-08 08:46:08 --> Output Class Initialized
DEBUG - 2010-07-08 08:46:08 --> Input Class Initialized
DEBUG - 2010-07-08 08:46:08 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 08:46:08 --> Language Class Initialized
DEBUG - 2010-07-08 08:46:08 --> Loader Class Initialized
DEBUG - 2010-07-08 08:46:08 --> Helper loaded: context_helper
DEBUG - 2010-07-08 08:46:08 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 08:46:08 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 08:46:09 --> Database Driver Class Initialized
DEBUG - 2010-07-08 08:46:09 --> Controller Class Initialized
DEBUG - 2010-07-08 08:46:09 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 08:46:09 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 08:46:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:09 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:09 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:09 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:09 --> Helper loaded: email_helper
DEBUG - 2010-07-08 08:46:09 --> User Agent Class Initialized
DEBUG - 2010-07-08 08:46:09 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:09 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:09 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 08:46:09 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:09 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:09 --> Session Class Initialized
DEBUG - 2010-07-08 08:46:10 --> Helper loaded: string_helper
DEBUG - 2010-07-08 08:46:10 --> Session routines successfully run
DEBUG - 2010-07-08 08:46:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:10 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:10 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:10 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:10 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:10 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:10 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:10 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:10 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:10 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:10 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:10 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:10 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:10 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:10 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:10 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:10 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 08:46:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:11 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:11 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:11 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:11 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:11 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:11 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:11 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:11 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:11 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:11 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:11 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:11 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:11 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:11 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:11 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:11 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:11 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:11 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:11 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:12 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 08:46:12 --> Final output sent to browser
DEBUG - 2010-07-08 08:46:12 --> Total execution time: 3.6326
DEBUG - 2010-07-08 08:46:55 --> Config Class Initialized
DEBUG - 2010-07-08 08:46:55 --> Hooks Class Initialized
DEBUG - 2010-07-08 08:46:55 --> URI Class Initialized
DEBUG - 2010-07-08 08:46:55 --> Router Class Initialized
DEBUG - 2010-07-08 08:46:55 --> Output Class Initialized
DEBUG - 2010-07-08 08:46:55 --> Input Class Initialized
DEBUG - 2010-07-08 08:46:55 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 08:46:56 --> Language Class Initialized
DEBUG - 2010-07-08 08:46:56 --> Loader Class Initialized
DEBUG - 2010-07-08 08:46:56 --> Helper loaded: context_helper
DEBUG - 2010-07-08 08:46:56 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 08:46:56 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 08:46:56 --> Database Driver Class Initialized
DEBUG - 2010-07-08 08:46:56 --> Controller Class Initialized
DEBUG - 2010-07-08 08:46:56 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 08:46:56 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 08:46:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:56 --> Helper loaded: email_helper
DEBUG - 2010-07-08 08:46:56 --> User Agent Class Initialized
DEBUG - 2010-07-08 08:46:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:56 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:56 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 08:46:57 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:57 --> Session Class Initialized
DEBUG - 2010-07-08 08:46:57 --> Helper loaded: string_helper
DEBUG - 2010-07-08 08:46:57 --> Session routines successfully run
DEBUG - 2010-07-08 08:46:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:57 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:57 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:57 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:57 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:57 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:57 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:57 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:57 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:57 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:57 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:57 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:58 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:58 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:58 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 08:46:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:58 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:58 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:58 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:58 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:58 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:58 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:58 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:58 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:58 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:58 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:58 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:58 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:58 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:59 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:59 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:59 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:59 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:59 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:59 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:59 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:59 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:59 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:59 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:59 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:59 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:59 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:59 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:59 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:46:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:00 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 08:47:00 --> Final output sent to browser
DEBUG - 2010-07-08 08:47:00 --> Total execution time: 4.3586
DEBUG - 2010-07-08 08:47:24 --> Config Class Initialized
DEBUG - 2010-07-08 08:47:25 --> Hooks Class Initialized
DEBUG - 2010-07-08 08:47:25 --> URI Class Initialized
DEBUG - 2010-07-08 08:47:25 --> Router Class Initialized
DEBUG - 2010-07-08 08:47:25 --> Output Class Initialized
DEBUG - 2010-07-08 08:47:25 --> Input Class Initialized
DEBUG - 2010-07-08 08:47:25 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 08:47:25 --> Language Class Initialized
DEBUG - 2010-07-08 08:47:25 --> Loader Class Initialized
DEBUG - 2010-07-08 08:47:25 --> Helper loaded: context_helper
DEBUG - 2010-07-08 08:47:25 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 08:47:25 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 08:47:25 --> Database Driver Class Initialized
DEBUG - 2010-07-08 08:47:25 --> Controller Class Initialized
DEBUG - 2010-07-08 08:47:25 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 08:47:25 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 08:47:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:26 --> Helper loaded: email_helper
DEBUG - 2010-07-08 08:47:26 --> User Agent Class Initialized
DEBUG - 2010-07-08 08:47:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:26 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:26 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 08:47:26 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:26 --> Session Class Initialized
DEBUG - 2010-07-08 08:47:26 --> Helper loaded: string_helper
DEBUG - 2010-07-08 08:47:26 --> Session routines successfully run
DEBUG - 2010-07-08 08:47:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:26 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:26 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:26 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:26 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:26 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:26 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:26 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:27 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:27 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:27 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:27 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:27 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:27 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:27 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:27 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:27 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 08:47:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:27 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:27 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:27 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:27 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:27 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:27 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:27 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:28 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:28 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:28 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:28 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:28 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:28 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:28 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:28 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:28 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:28 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:28 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:28 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:28 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:28 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:28 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:28 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:28 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:28 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:28 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:29 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:29 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:29 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:29 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:29 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:29 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 08:47:29 --> Final output sent to browser
DEBUG - 2010-07-08 08:47:29 --> Total execution time: 4.5652
DEBUG - 2010-07-08 08:47:39 --> Config Class Initialized
DEBUG - 2010-07-08 08:47:39 --> Hooks Class Initialized
DEBUG - 2010-07-08 08:47:39 --> URI Class Initialized
DEBUG - 2010-07-08 08:47:39 --> Router Class Initialized
DEBUG - 2010-07-08 08:47:39 --> Output Class Initialized
DEBUG - 2010-07-08 08:47:39 --> Input Class Initialized
DEBUG - 2010-07-08 08:47:39 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 08:47:40 --> Language Class Initialized
DEBUG - 2010-07-08 08:47:40 --> Loader Class Initialized
DEBUG - 2010-07-08 08:47:40 --> Helper loaded: context_helper
DEBUG - 2010-07-08 08:47:40 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 08:47:40 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 08:47:40 --> Database Driver Class Initialized
DEBUG - 2010-07-08 08:47:40 --> Controller Class Initialized
DEBUG - 2010-07-08 08:47:40 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 08:47:40 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 08:47:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:40 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:40 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:40 --> Helper loaded: email_helper
DEBUG - 2010-07-08 08:47:40 --> User Agent Class Initialized
DEBUG - 2010-07-08 08:47:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:40 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:41 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 08:47:41 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:41 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:41 --> Session Class Initialized
DEBUG - 2010-07-08 08:47:41 --> Helper loaded: string_helper
DEBUG - 2010-07-08 08:47:41 --> Session routines successfully run
DEBUG - 2010-07-08 08:47:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:41 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:41 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:41 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:41 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:41 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:41 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:41 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:41 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:41 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:42 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:42 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:42 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:42 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:42 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:42 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:42 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 08:47:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:42 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:42 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:42 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:42 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:42 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:42 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:42 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:43 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:43 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:43 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:43 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:43 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:43 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:43 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:43 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:43 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:43 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:43 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:43 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:43 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:43 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:43 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:43 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:43 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:43 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:43 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:43 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:44 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:44 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:44 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:44 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:44 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:44 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:44 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:44 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:44 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:47:44 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 08:47:44 --> Final output sent to browser
DEBUG - 2010-07-08 08:47:44 --> Total execution time: 4.9210
DEBUG - 2010-07-08 08:48:44 --> Config Class Initialized
DEBUG - 2010-07-08 08:48:44 --> Hooks Class Initialized
DEBUG - 2010-07-08 08:48:44 --> URI Class Initialized
DEBUG - 2010-07-08 08:48:44 --> Router Class Initialized
DEBUG - 2010-07-08 08:48:44 --> Output Class Initialized
DEBUG - 2010-07-08 08:48:44 --> Input Class Initialized
DEBUG - 2010-07-08 08:48:44 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 08:48:45 --> Language Class Initialized
DEBUG - 2010-07-08 08:48:45 --> Loader Class Initialized
DEBUG - 2010-07-08 08:48:45 --> Helper loaded: context_helper
DEBUG - 2010-07-08 08:48:45 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 08:48:45 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 08:48:45 --> Database Driver Class Initialized
DEBUG - 2010-07-08 08:48:45 --> Controller Class Initialized
DEBUG - 2010-07-08 08:48:45 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 08:48:45 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 08:48:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:45 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:45 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:45 --> Helper loaded: email_helper
DEBUG - 2010-07-08 08:48:45 --> User Agent Class Initialized
DEBUG - 2010-07-08 08:48:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:45 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:46 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:46 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 08:48:46 --> Session Class Initialized
DEBUG - 2010-07-08 08:48:46 --> Helper loaded: string_helper
DEBUG - 2010-07-08 08:48:46 --> Session routines successfully run
DEBUG - 2010-07-08 08:48:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:46 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:46 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:46 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 08:48:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:46 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:46 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:46 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:46 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:47 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:47 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:47 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:47 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:47 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:47 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:47 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:47 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 08:48:47 --> Final output sent to browser
DEBUG - 2010-07-08 08:48:47 --> Total execution time: 2.8006
DEBUG - 2010-07-08 08:48:54 --> Config Class Initialized
DEBUG - 2010-07-08 08:48:54 --> Hooks Class Initialized
DEBUG - 2010-07-08 08:48:54 --> URI Class Initialized
DEBUG - 2010-07-08 08:48:54 --> Router Class Initialized
DEBUG - 2010-07-08 08:48:54 --> Output Class Initialized
DEBUG - 2010-07-08 08:48:54 --> Input Class Initialized
DEBUG - 2010-07-08 08:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 08:48:54 --> Language Class Initialized
DEBUG - 2010-07-08 08:48:54 --> Loader Class Initialized
DEBUG - 2010-07-08 08:48:54 --> Helper loaded: context_helper
DEBUG - 2010-07-08 08:48:54 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 08:48:54 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 08:48:54 --> Database Driver Class Initialized
DEBUG - 2010-07-08 08:48:54 --> Controller Class Initialized
DEBUG - 2010-07-08 08:48:54 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 08:48:54 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 08:48:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:55 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:55 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:55 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:55 --> Helper loaded: email_helper
DEBUG - 2010-07-08 08:48:55 --> User Agent Class Initialized
DEBUG - 2010-07-08 08:48:55 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:55 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:55 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 08:48:55 --> Session Class Initialized
DEBUG - 2010-07-08 08:48:55 --> Helper loaded: string_helper
DEBUG - 2010-07-08 08:48:55 --> Session routines successfully run
DEBUG - 2010-07-08 08:48:55 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:55 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:55 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:56 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:56 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 08:48:56 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:56 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:56 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:56 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:56 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:56 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:56 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:56 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:56 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:56 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:56 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:56 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:56 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:56 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:56 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:57 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:48:57 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 08:48:57 --> Final output sent to browser
DEBUG - 2010-07-08 08:48:57 --> Total execution time: 3.0409
DEBUG - 2010-07-08 08:51:38 --> Config Class Initialized
DEBUG - 2010-07-08 08:51:38 --> Hooks Class Initialized
DEBUG - 2010-07-08 08:51:38 --> URI Class Initialized
DEBUG - 2010-07-08 08:51:38 --> Router Class Initialized
DEBUG - 2010-07-08 08:51:38 --> Output Class Initialized
DEBUG - 2010-07-08 08:51:38 --> Input Class Initialized
DEBUG - 2010-07-08 08:51:38 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 08:51:38 --> Language Class Initialized
DEBUG - 2010-07-08 08:51:38 --> Loader Class Initialized
DEBUG - 2010-07-08 08:51:39 --> Helper loaded: context_helper
DEBUG - 2010-07-08 08:51:39 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 08:51:39 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 08:51:39 --> Database Driver Class Initialized
DEBUG - 2010-07-08 08:51:39 --> Controller Class Initialized
DEBUG - 2010-07-08 08:51:39 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 08:51:39 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 08:51:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:51:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:51:39 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:51:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:51:39 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:51:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:51:39 --> Helper loaded: email_helper
DEBUG - 2010-07-08 08:51:39 --> User Agent Class Initialized
DEBUG - 2010-07-08 08:51:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:51:39 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:51:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:51:40 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 08:51:40 --> Session Class Initialized
DEBUG - 2010-07-08 08:51:40 --> Helper loaded: string_helper
DEBUG - 2010-07-08 08:51:40 --> Session routines successfully run
DEBUG - 2010-07-08 08:51:40 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:51:40 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:51:40 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:51:40 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:51:40 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 08:51:40 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:51:40 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:51:40 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:51:40 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:51:40 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:51:40 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:51:40 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:51:41 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:51:41 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:51:41 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:51:41 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:51:41 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:51:41 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:51:41 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:51:41 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:51:41 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:56:14 --> Config Class Initialized
DEBUG - 2010-07-08 08:56:14 --> Hooks Class Initialized
DEBUG - 2010-07-08 08:56:14 --> URI Class Initialized
DEBUG - 2010-07-08 08:56:14 --> Router Class Initialized
DEBUG - 2010-07-08 08:56:14 --> Output Class Initialized
DEBUG - 2010-07-08 08:56:14 --> Input Class Initialized
DEBUG - 2010-07-08 08:56:14 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 08:56:14 --> Language Class Initialized
DEBUG - 2010-07-08 08:56:14 --> Loader Class Initialized
DEBUG - 2010-07-08 08:56:14 --> Helper loaded: context_helper
DEBUG - 2010-07-08 08:56:14 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 08:56:14 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 08:56:14 --> Database Driver Class Initialized
DEBUG - 2010-07-08 08:56:14 --> Controller Class Initialized
DEBUG - 2010-07-08 08:56:14 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 08:56:14 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 08:56:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:56:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:56:15 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:56:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:56:15 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:56:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:56:15 --> Helper loaded: email_helper
DEBUG - 2010-07-08 08:56:15 --> User Agent Class Initialized
DEBUG - 2010-07-08 08:56:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:56:15 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:56:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:56:15 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 08:56:15 --> Session Class Initialized
DEBUG - 2010-07-08 08:56:15 --> Helper loaded: string_helper
DEBUG - 2010-07-08 08:56:15 --> Session routines successfully run
DEBUG - 2010-07-08 08:56:15 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:56:15 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:56:16 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:56:16 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:56:16 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 08:56:16 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:56:16 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:56:16 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:56:16 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:56:16 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:56:16 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:56:16 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:56:16 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:56:16 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:56:16 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:56:16 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:56:16 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:56:16 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:56:16 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:56:16 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:56:17 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-08 08:56:17 --> Severity: 4096  --> Argument 1 passed to Collection_iterator::__construct() must be an instance of Collection, none given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Loader.php on line 928 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Collection_iterator.php 21
ERROR - 2010-07-08 08:56:17 --> Severity: Warning  --> Missing argument 1 for Collection_iterator::__construct(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Loader.php on line 928 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Collection_iterator.php 21
ERROR - 2010-07-08 08:56:17 --> Severity: Notice  --> Undefined variable: obj_coll D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Collection_iterator.php 22
DEBUG - 2010-07-08 08:56:59 --> Config Class Initialized
DEBUG - 2010-07-08 08:56:59 --> Hooks Class Initialized
DEBUG - 2010-07-08 08:56:59 --> URI Class Initialized
DEBUG - 2010-07-08 08:56:59 --> Router Class Initialized
DEBUG - 2010-07-08 08:56:59 --> Output Class Initialized
DEBUG - 2010-07-08 08:56:59 --> Input Class Initialized
DEBUG - 2010-07-08 08:56:59 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 08:56:59 --> Language Class Initialized
DEBUG - 2010-07-08 08:56:59 --> Loader Class Initialized
DEBUG - 2010-07-08 08:56:59 --> Helper loaded: context_helper
DEBUG - 2010-07-08 08:56:59 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 08:56:59 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 08:56:59 --> Database Driver Class Initialized
DEBUG - 2010-07-08 08:57:00 --> Controller Class Initialized
DEBUG - 2010-07-08 08:57:00 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 08:57:00 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 08:57:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:00 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:00 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:00 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:00 --> Helper loaded: email_helper
DEBUG - 2010-07-08 08:57:00 --> User Agent Class Initialized
DEBUG - 2010-07-08 08:57:00 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:00 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:00 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 08:57:00 --> Session Class Initialized
DEBUG - 2010-07-08 08:57:00 --> Helper loaded: string_helper
DEBUG - 2010-07-08 08:57:00 --> Session routines successfully run
DEBUG - 2010-07-08 08:57:01 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:01 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:01 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:01 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:01 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 08:57:01 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:01 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:01 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:01 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:01 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:01 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:01 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:01 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:01 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:01 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:01 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:01 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:02 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:02 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:02 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:02 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-08 08:57:02 --> Severity: Warning  --> Missing argument 1 for Collection_iterator::__construct(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Loader.php on line 928 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Collection_iterator.php 21
ERROR - 2010-07-08 08:57:02 --> Severity: Notice  --> Undefined variable: obj_coll D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Collection_iterator.php 22
DEBUG - 2010-07-08 08:57:35 --> Config Class Initialized
DEBUG - 2010-07-08 08:57:35 --> Hooks Class Initialized
DEBUG - 2010-07-08 08:57:35 --> URI Class Initialized
DEBUG - 2010-07-08 08:57:35 --> Router Class Initialized
DEBUG - 2010-07-08 08:57:35 --> Output Class Initialized
DEBUG - 2010-07-08 08:57:35 --> Input Class Initialized
DEBUG - 2010-07-08 08:57:35 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 08:57:35 --> Language Class Initialized
DEBUG - 2010-07-08 08:57:35 --> Loader Class Initialized
DEBUG - 2010-07-08 08:57:35 --> Helper loaded: context_helper
DEBUG - 2010-07-08 08:57:35 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 08:57:35 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 08:57:35 --> Database Driver Class Initialized
DEBUG - 2010-07-08 08:57:35 --> Controller Class Initialized
DEBUG - 2010-07-08 08:57:35 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 08:57:36 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 08:57:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:36 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:36 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:36 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:36 --> Helper loaded: email_helper
DEBUG - 2010-07-08 08:57:36 --> User Agent Class Initialized
DEBUG - 2010-07-08 08:57:36 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:36 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:36 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 08:57:36 --> Session Class Initialized
DEBUG - 2010-07-08 08:57:36 --> Helper loaded: string_helper
DEBUG - 2010-07-08 08:57:36 --> Session routines successfully run
DEBUG - 2010-07-08 08:57:36 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:37 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:37 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:37 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:37 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 08:57:37 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:37 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:37 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:37 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:37 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:37 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:37 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:37 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:37 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:37 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:37 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:37 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:37 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:38 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:38 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:57:38 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-08 08:57:38 --> Severity: Warning  --> Missing argument 1 for Collection_iterator::__construct(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Loader.php on line 928 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Collection_iterator.php 21
ERROR - 2010-07-08 08:57:38 --> Severity: Notice  --> Undefined variable: obj_coll D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Collection_iterator.php 22
DEBUG - 2010-07-08 08:58:15 --> Config Class Initialized
DEBUG - 2010-07-08 08:58:15 --> Hooks Class Initialized
DEBUG - 2010-07-08 08:58:15 --> URI Class Initialized
DEBUG - 2010-07-08 08:58:15 --> Router Class Initialized
DEBUG - 2010-07-08 08:58:15 --> Output Class Initialized
DEBUG - 2010-07-08 08:58:15 --> Input Class Initialized
DEBUG - 2010-07-08 08:58:15 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 08:58:15 --> Language Class Initialized
DEBUG - 2010-07-08 08:58:15 --> Loader Class Initialized
DEBUG - 2010-07-08 08:58:15 --> Helper loaded: context_helper
DEBUG - 2010-07-08 08:58:15 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 08:58:15 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 08:58:15 --> Database Driver Class Initialized
DEBUG - 2010-07-08 08:58:15 --> Controller Class Initialized
DEBUG - 2010-07-08 08:58:15 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 08:58:15 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 08:58:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:16 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:16 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:16 --> Helper loaded: email_helper
DEBUG - 2010-07-08 08:58:16 --> User Agent Class Initialized
DEBUG - 2010-07-08 08:58:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:16 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:16 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 08:58:16 --> Session Class Initialized
DEBUG - 2010-07-08 08:58:16 --> Helper loaded: string_helper
DEBUG - 2010-07-08 08:58:16 --> Session routines successfully run
DEBUG - 2010-07-08 08:58:17 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:17 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:17 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:17 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:17 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 08:58:17 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:17 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:17 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:17 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:17 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:17 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:17 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:17 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:17 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:17 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:17 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:18 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:18 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:18 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:18 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:18 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-08 08:58:18 --> Severity: Notice  --> Undefined variable: key D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Collection_iterator.php 57
DEBUG - 2010-07-08 08:58:18 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 08:58:18 --> Final output sent to browser
DEBUG - 2010-07-08 08:58:18 --> Total execution time: 3.4181
DEBUG - 2010-07-08 08:58:39 --> Config Class Initialized
DEBUG - 2010-07-08 08:58:39 --> Hooks Class Initialized
DEBUG - 2010-07-08 08:58:39 --> URI Class Initialized
DEBUG - 2010-07-08 08:58:39 --> Router Class Initialized
DEBUG - 2010-07-08 08:58:39 --> Output Class Initialized
DEBUG - 2010-07-08 08:58:39 --> Input Class Initialized
DEBUG - 2010-07-08 08:58:39 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 08:58:39 --> Language Class Initialized
DEBUG - 2010-07-08 08:58:39 --> Loader Class Initialized
DEBUG - 2010-07-08 08:58:39 --> Helper loaded: context_helper
DEBUG - 2010-07-08 08:58:39 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 08:58:40 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 08:58:40 --> Database Driver Class Initialized
DEBUG - 2010-07-08 08:58:40 --> Controller Class Initialized
DEBUG - 2010-07-08 08:58:40 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 08:58:40 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 08:58:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:40 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:40 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:40 --> Helper loaded: email_helper
DEBUG - 2010-07-08 08:58:40 --> User Agent Class Initialized
DEBUG - 2010-07-08 08:58:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:40 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:41 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 08:58:41 --> Session Class Initialized
DEBUG - 2010-07-08 08:58:41 --> Helper loaded: string_helper
DEBUG - 2010-07-08 08:58:41 --> Session routines successfully run
DEBUG - 2010-07-08 08:58:41 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:41 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:41 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:41 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:41 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 08:58:41 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:41 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:41 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:41 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:41 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:41 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:41 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:42 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:42 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:42 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:42 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:42 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:42 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:42 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:42 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:58:42 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-08 08:58:42 --> Severity: Notice  --> Undefined offset:  3 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Collection_iterator.php 41
DEBUG - 2010-07-08 08:58:42 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 08:58:42 --> Final output sent to browser
DEBUG - 2010-07-08 08:58:42 --> Total execution time: 3.3810
DEBUG - 2010-07-08 08:59:43 --> Config Class Initialized
DEBUG - 2010-07-08 08:59:43 --> Hooks Class Initialized
DEBUG - 2010-07-08 08:59:43 --> URI Class Initialized
DEBUG - 2010-07-08 08:59:43 --> Router Class Initialized
DEBUG - 2010-07-08 08:59:44 --> Output Class Initialized
DEBUG - 2010-07-08 08:59:44 --> Input Class Initialized
DEBUG - 2010-07-08 08:59:44 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 08:59:44 --> Language Class Initialized
DEBUG - 2010-07-08 08:59:44 --> Loader Class Initialized
DEBUG - 2010-07-08 08:59:44 --> Helper loaded: context_helper
DEBUG - 2010-07-08 08:59:44 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 08:59:44 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 08:59:44 --> Database Driver Class Initialized
DEBUG - 2010-07-08 08:59:44 --> Controller Class Initialized
DEBUG - 2010-07-08 08:59:44 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 08:59:44 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 08:59:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:59:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:59:44 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:59:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:59:45 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:59:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:59:45 --> Helper loaded: email_helper
DEBUG - 2010-07-08 08:59:45 --> User Agent Class Initialized
DEBUG - 2010-07-08 08:59:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:59:45 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:59:45 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:59:45 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 08:59:45 --> Session Class Initialized
DEBUG - 2010-07-08 08:59:45 --> Helper loaded: string_helper
DEBUG - 2010-07-08 08:59:45 --> Session routines successfully run
DEBUG - 2010-07-08 08:59:45 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:59:45 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:59:45 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:59:45 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:59:46 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 08:59:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:59:46 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:59:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:59:46 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:59:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:59:46 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:59:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:59:46 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:59:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:59:46 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:59:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:59:46 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:59:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:59:46 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:59:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:59:47 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 08:59:47 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 08:59:47 --> Final output sent to browser
DEBUG - 2010-07-08 08:59:47 --> Total execution time: 3.4366
DEBUG - 2010-07-08 09:00:23 --> Config Class Initialized
DEBUG - 2010-07-08 09:00:23 --> Hooks Class Initialized
DEBUG - 2010-07-08 09:00:23 --> URI Class Initialized
DEBUG - 2010-07-08 09:00:23 --> Router Class Initialized
DEBUG - 2010-07-08 09:00:24 --> Output Class Initialized
DEBUG - 2010-07-08 09:00:24 --> Input Class Initialized
DEBUG - 2010-07-08 09:00:24 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 09:00:24 --> Language Class Initialized
DEBUG - 2010-07-08 09:00:24 --> Loader Class Initialized
DEBUG - 2010-07-08 09:00:24 --> Helper loaded: context_helper
DEBUG - 2010-07-08 09:00:24 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 09:00:24 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 09:00:24 --> Database Driver Class Initialized
DEBUG - 2010-07-08 09:00:24 --> Controller Class Initialized
DEBUG - 2010-07-08 09:00:24 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 09:00:24 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 09:00:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:00:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:00:24 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:00:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:00:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:00:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:00:25 --> Helper loaded: email_helper
DEBUG - 2010-07-08 09:00:25 --> User Agent Class Initialized
DEBUG - 2010-07-08 09:00:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:00:25 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:00:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:00:25 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 09:00:25 --> Session Class Initialized
DEBUG - 2010-07-08 09:00:25 --> Helper loaded: string_helper
DEBUG - 2010-07-08 09:00:25 --> Session routines successfully run
DEBUG - 2010-07-08 09:00:25 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:00:25 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:00:25 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:00:26 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:00:26 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 09:00:26 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:00:26 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:00:26 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:00:26 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:00:26 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:00:26 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:00:26 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:00:26 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:00:26 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:00:26 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:00:26 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:00:26 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:00:26 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:00:27 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:00:27 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:00:27 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:00:27 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 09:00:27 --> Final output sent to browser
DEBUG - 2010-07-08 09:00:27 --> Total execution time: 3.5408
DEBUG - 2010-07-08 09:36:17 --> Config Class Initialized
DEBUG - 2010-07-08 09:36:17 --> Hooks Class Initialized
DEBUG - 2010-07-08 09:36:17 --> URI Class Initialized
DEBUG - 2010-07-08 09:36:17 --> Router Class Initialized
DEBUG - 2010-07-08 09:36:17 --> Output Class Initialized
DEBUG - 2010-07-08 09:36:17 --> Input Class Initialized
DEBUG - 2010-07-08 09:36:18 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 09:36:18 --> Language Class Initialized
DEBUG - 2010-07-08 09:36:30 --> Config Class Initialized
DEBUG - 2010-07-08 09:36:30 --> Hooks Class Initialized
DEBUG - 2010-07-08 09:36:30 --> URI Class Initialized
DEBUG - 2010-07-08 09:36:30 --> Router Class Initialized
DEBUG - 2010-07-08 09:36:30 --> Output Class Initialized
DEBUG - 2010-07-08 09:36:30 --> Input Class Initialized
DEBUG - 2010-07-08 09:36:30 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 09:36:30 --> Language Class Initialized
DEBUG - 2010-07-08 09:36:30 --> Loader Class Initialized
DEBUG - 2010-07-08 09:36:30 --> Helper loaded: context_helper
DEBUG - 2010-07-08 09:36:30 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 09:36:30 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 09:36:30 --> Database Driver Class Initialized
DEBUG - 2010-07-08 09:36:31 --> Controller Class Initialized
DEBUG - 2010-07-08 09:36:31 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 09:36:31 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 09:36:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:36:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:36:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:36:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:36:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:36:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:36:31 --> Helper loaded: email_helper
DEBUG - 2010-07-08 09:36:31 --> User Agent Class Initialized
DEBUG - 2010-07-08 09:36:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:36:32 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:36:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:36:32 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 09:36:32 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:36:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:36:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:36:32 --> Session Class Initialized
DEBUG - 2010-07-08 09:36:32 --> Helper loaded: string_helper
DEBUG - 2010-07-08 09:36:32 --> Session routines successfully run
DEBUG - 2010-07-08 09:36:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:36:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:36:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:36:32 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:36:32 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:36:33 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:36:33 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:36:33 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:36:33 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:36:33 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:36:33 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:36:33 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:36:33 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:27 --> Config Class Initialized
DEBUG - 2010-07-08 09:40:27 --> Hooks Class Initialized
DEBUG - 2010-07-08 09:40:27 --> URI Class Initialized
DEBUG - 2010-07-08 09:40:27 --> Router Class Initialized
DEBUG - 2010-07-08 09:40:28 --> Output Class Initialized
DEBUG - 2010-07-08 09:40:28 --> Input Class Initialized
DEBUG - 2010-07-08 09:40:28 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 09:40:28 --> Language Class Initialized
DEBUG - 2010-07-08 09:40:28 --> Loader Class Initialized
DEBUG - 2010-07-08 09:40:28 --> Helper loaded: context_helper
DEBUG - 2010-07-08 09:40:28 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 09:40:28 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 09:40:28 --> Database Driver Class Initialized
DEBUG - 2010-07-08 09:40:28 --> Controller Class Initialized
DEBUG - 2010-07-08 09:40:28 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 09:40:28 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 09:40:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:28 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:29 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:29 --> Helper loaded: email_helper
DEBUG - 2010-07-08 09:40:29 --> User Agent Class Initialized
DEBUG - 2010-07-08 09:40:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:29 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:29 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 09:40:29 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:29 --> Session Class Initialized
DEBUG - 2010-07-08 09:40:29 --> Helper loaded: string_helper
DEBUG - 2010-07-08 09:40:30 --> Session routines successfully run
DEBUG - 2010-07-08 09:40:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:30 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:30 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:30 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:30 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:30 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:30 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:30 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:30 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:30 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:30 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:49 --> Config Class Initialized
DEBUG - 2010-07-08 09:40:49 --> Hooks Class Initialized
DEBUG - 2010-07-08 09:40:49 --> URI Class Initialized
DEBUG - 2010-07-08 09:40:49 --> Router Class Initialized
DEBUG - 2010-07-08 09:40:49 --> Output Class Initialized
DEBUG - 2010-07-08 09:40:49 --> Input Class Initialized
DEBUG - 2010-07-08 09:40:49 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 09:40:49 --> Language Class Initialized
DEBUG - 2010-07-08 09:40:49 --> Loader Class Initialized
DEBUG - 2010-07-08 09:40:49 --> Helper loaded: context_helper
DEBUG - 2010-07-08 09:40:49 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 09:40:50 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 09:40:50 --> Database Driver Class Initialized
DEBUG - 2010-07-08 09:40:50 --> Controller Class Initialized
DEBUG - 2010-07-08 09:40:50 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 09:40:50 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 09:40:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:50 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:50 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:50 --> Helper loaded: email_helper
DEBUG - 2010-07-08 09:40:50 --> User Agent Class Initialized
DEBUG - 2010-07-08 09:40:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:50 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:51 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 09:40:51 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:51 --> Session Class Initialized
DEBUG - 2010-07-08 09:40:51 --> Helper loaded: string_helper
DEBUG - 2010-07-08 09:40:51 --> Session routines successfully run
DEBUG - 2010-07-08 09:40:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:51 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:51 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:51 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:52 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:52 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:52 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:52 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:52 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:52 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:52 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:40:59 --> Config Class Initialized
DEBUG - 2010-07-08 09:40:59 --> Hooks Class Initialized
DEBUG - 2010-07-08 09:40:59 --> URI Class Initialized
DEBUG - 2010-07-08 09:40:59 --> Router Class Initialized
DEBUG - 2010-07-08 09:40:59 --> Output Class Initialized
DEBUG - 2010-07-08 09:40:59 --> Input Class Initialized
DEBUG - 2010-07-08 09:41:00 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 09:41:00 --> Language Class Initialized
DEBUG - 2010-07-08 09:41:00 --> Loader Class Initialized
DEBUG - 2010-07-08 09:41:00 --> Helper loaded: context_helper
DEBUG - 2010-07-08 09:41:00 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 09:41:00 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 09:41:00 --> Database Driver Class Initialized
DEBUG - 2010-07-08 09:41:00 --> Controller Class Initialized
DEBUG - 2010-07-08 09:41:00 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 09:41:00 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 09:41:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:00 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:01 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:01 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:01 --> Helper loaded: email_helper
DEBUG - 2010-07-08 09:41:01 --> User Agent Class Initialized
DEBUG - 2010-07-08 09:41:01 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:01 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:01 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 09:41:01 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:01 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:01 --> Session Class Initialized
DEBUG - 2010-07-08 09:41:01 --> Helper loaded: string_helper
DEBUG - 2010-07-08 09:41:01 --> Session routines successfully run
DEBUG - 2010-07-08 09:41:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:02 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:02 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:02 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:02 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:02 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:02 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:02 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:02 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:02 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:02 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:37 --> Config Class Initialized
DEBUG - 2010-07-08 09:41:37 --> Hooks Class Initialized
DEBUG - 2010-07-08 09:41:37 --> URI Class Initialized
DEBUG - 2010-07-08 09:41:37 --> Router Class Initialized
DEBUG - 2010-07-08 09:41:37 --> Output Class Initialized
DEBUG - 2010-07-08 09:41:38 --> Input Class Initialized
DEBUG - 2010-07-08 09:41:38 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 09:41:38 --> Language Class Initialized
DEBUG - 2010-07-08 09:41:38 --> Loader Class Initialized
DEBUG - 2010-07-08 09:41:38 --> Helper loaded: context_helper
DEBUG - 2010-07-08 09:41:38 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 09:41:38 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 09:41:38 --> Database Driver Class Initialized
DEBUG - 2010-07-08 09:41:38 --> Controller Class Initialized
DEBUG - 2010-07-08 09:41:38 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 09:41:38 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 09:41:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:39 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:39 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:39 --> Helper loaded: email_helper
DEBUG - 2010-07-08 09:41:39 --> User Agent Class Initialized
DEBUG - 2010-07-08 09:41:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:39 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:40 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 09:41:40 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:40 --> Session Class Initialized
DEBUG - 2010-07-08 09:41:40 --> Helper loaded: string_helper
DEBUG - 2010-07-08 09:41:40 --> Session routines successfully run
DEBUG - 2010-07-08 09:41:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:40 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:40 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:41 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:41 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:41 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:41 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:41 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:41 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:41 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:41:41 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:42:51 --> Config Class Initialized
DEBUG - 2010-07-08 09:42:51 --> Hooks Class Initialized
DEBUG - 2010-07-08 09:42:51 --> URI Class Initialized
DEBUG - 2010-07-08 09:42:51 --> Router Class Initialized
DEBUG - 2010-07-08 09:42:51 --> Output Class Initialized
DEBUG - 2010-07-08 09:42:51 --> Input Class Initialized
DEBUG - 2010-07-08 09:42:51 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 09:42:51 --> Language Class Initialized
DEBUG - 2010-07-08 09:42:51 --> Loader Class Initialized
DEBUG - 2010-07-08 09:42:51 --> Helper loaded: context_helper
DEBUG - 2010-07-08 09:42:52 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 09:42:52 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 09:42:52 --> Database Driver Class Initialized
DEBUG - 2010-07-08 09:42:52 --> Controller Class Initialized
DEBUG - 2010-07-08 09:42:52 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 09:42:52 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 09:42:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:42:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:42:52 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:42:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:42:52 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:42:52 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:42:52 --> Helper loaded: email_helper
DEBUG - 2010-07-08 09:42:53 --> User Agent Class Initialized
DEBUG - 2010-07-08 09:42:53 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:42:53 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:42:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:42:53 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 09:42:53 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:42:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:42:53 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:42:53 --> Session Class Initialized
DEBUG - 2010-07-08 09:42:53 --> Helper loaded: string_helper
DEBUG - 2010-07-08 09:42:53 --> Session routines successfully run
DEBUG - 2010-07-08 09:42:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:42:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:42:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:42:54 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:42:54 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:42:54 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:42:54 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:42:54 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:42:54 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:42:54 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:42:54 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:42:54 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:42:54 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:43:19 --> Config Class Initialized
DEBUG - 2010-07-08 09:43:19 --> Hooks Class Initialized
DEBUG - 2010-07-08 09:43:19 --> URI Class Initialized
DEBUG - 2010-07-08 09:43:19 --> Router Class Initialized
DEBUG - 2010-07-08 09:43:19 --> Output Class Initialized
DEBUG - 2010-07-08 09:43:19 --> Input Class Initialized
DEBUG - 2010-07-08 09:43:19 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 09:43:19 --> Language Class Initialized
DEBUG - 2010-07-08 09:43:19 --> Loader Class Initialized
DEBUG - 2010-07-08 09:43:19 --> Helper loaded: context_helper
DEBUG - 2010-07-08 09:43:19 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 09:43:20 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 09:43:20 --> Database Driver Class Initialized
DEBUG - 2010-07-08 09:43:20 --> Controller Class Initialized
DEBUG - 2010-07-08 09:43:20 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 09:43:20 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 09:43:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:43:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:43:20 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:43:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:43:20 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:43:20 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:43:20 --> Helper loaded: email_helper
DEBUG - 2010-07-08 09:43:20 --> User Agent Class Initialized
DEBUG - 2010-07-08 09:43:21 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:43:21 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:43:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:43:21 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 09:43:21 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:43:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:43:21 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:43:21 --> Session Class Initialized
DEBUG - 2010-07-08 09:43:21 --> Helper loaded: string_helper
DEBUG - 2010-07-08 09:43:21 --> Session routines successfully run
DEBUG - 2010-07-08 09:43:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:43:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:43:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:43:22 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:43:22 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:43:22 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:43:22 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:43:22 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:43:22 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:43:22 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:43:22 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:43:22 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:43:22 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:44:56 --> Config Class Initialized
DEBUG - 2010-07-08 09:44:56 --> Hooks Class Initialized
DEBUG - 2010-07-08 09:44:56 --> URI Class Initialized
DEBUG - 2010-07-08 09:44:56 --> Router Class Initialized
DEBUG - 2010-07-08 09:44:57 --> Output Class Initialized
DEBUG - 2010-07-08 09:44:57 --> Input Class Initialized
DEBUG - 2010-07-08 09:44:57 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 09:44:57 --> Language Class Initialized
DEBUG - 2010-07-08 09:44:57 --> Loader Class Initialized
DEBUG - 2010-07-08 09:44:57 --> Helper loaded: context_helper
DEBUG - 2010-07-08 09:44:57 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 09:44:57 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 09:44:57 --> Database Driver Class Initialized
DEBUG - 2010-07-08 09:44:57 --> Controller Class Initialized
DEBUG - 2010-07-08 09:44:57 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 09:44:57 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 09:44:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:44:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:44:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:44:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:44:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:44:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:44:58 --> Helper loaded: email_helper
DEBUG - 2010-07-08 09:44:58 --> User Agent Class Initialized
DEBUG - 2010-07-08 09:44:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:44:58 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:44:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:44:58 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 09:44:59 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:44:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:44:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:44:59 --> Session Class Initialized
DEBUG - 2010-07-08 09:44:59 --> Helper loaded: string_helper
DEBUG - 2010-07-08 09:44:59 --> Session routines successfully run
DEBUG - 2010-07-08 09:44:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:44:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:44:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:44:59 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:44:59 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:44:59 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:44:59 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:00 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:00 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:00 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:00 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:00 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:00 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:23 --> Config Class Initialized
DEBUG - 2010-07-08 09:45:23 --> Hooks Class Initialized
DEBUG - 2010-07-08 09:45:24 --> URI Class Initialized
DEBUG - 2010-07-08 09:45:24 --> Router Class Initialized
DEBUG - 2010-07-08 09:45:24 --> Output Class Initialized
DEBUG - 2010-07-08 09:45:24 --> Input Class Initialized
DEBUG - 2010-07-08 09:45:24 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 09:45:24 --> Language Class Initialized
DEBUG - 2010-07-08 09:45:24 --> Loader Class Initialized
DEBUG - 2010-07-08 09:45:24 --> Helper loaded: context_helper
DEBUG - 2010-07-08 09:45:24 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 09:45:24 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 09:45:24 --> Database Driver Class Initialized
DEBUG - 2010-07-08 09:45:24 --> Controller Class Initialized
DEBUG - 2010-07-08 09:45:24 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 09:45:25 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 09:45:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:25 --> Helper loaded: email_helper
DEBUG - 2010-07-08 09:45:25 --> User Agent Class Initialized
DEBUG - 2010-07-08 09:45:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:25 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:26 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 09:45:26 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:26 --> Session Class Initialized
DEBUG - 2010-07-08 09:45:26 --> Helper loaded: string_helper
DEBUG - 2010-07-08 09:45:26 --> Session routines successfully run
DEBUG - 2010-07-08 09:45:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:26 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:26 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:26 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:27 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:27 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:27 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:27 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:27 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:27 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:27 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:27 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:27 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:27 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:27 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:27 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:28 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 09:45:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:28 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:28 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:28 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:28 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:28 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 09:45:28 --> Final output sent to browser
DEBUG - 2010-07-08 09:45:28 --> Total execution time: 4.9243
DEBUG - 2010-07-08 09:45:53 --> Config Class Initialized
DEBUG - 2010-07-08 09:45:53 --> Hooks Class Initialized
DEBUG - 2010-07-08 09:45:53 --> URI Class Initialized
DEBUG - 2010-07-08 09:45:54 --> Router Class Initialized
DEBUG - 2010-07-08 09:45:54 --> Output Class Initialized
DEBUG - 2010-07-08 09:45:54 --> Input Class Initialized
DEBUG - 2010-07-08 09:45:54 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 09:45:54 --> Language Class Initialized
DEBUG - 2010-07-08 09:45:54 --> Loader Class Initialized
DEBUG - 2010-07-08 09:45:54 --> Helper loaded: context_helper
DEBUG - 2010-07-08 09:45:54 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 09:45:54 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 09:45:54 --> Database Driver Class Initialized
DEBUG - 2010-07-08 09:45:54 --> Controller Class Initialized
DEBUG - 2010-07-08 09:45:54 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 09:45:55 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 09:45:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:55 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:55 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:55 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:55 --> Helper loaded: email_helper
DEBUG - 2010-07-08 09:45:55 --> User Agent Class Initialized
DEBUG - 2010-07-08 09:45:55 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:55 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:55 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 09:45:56 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:56 --> Session Class Initialized
DEBUG - 2010-07-08 09:45:56 --> Helper loaded: string_helper
DEBUG - 2010-07-08 09:45:56 --> Session routines successfully run
DEBUG - 2010-07-08 09:45:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:56 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:56 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:56 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:57 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:57 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:57 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:57 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:57 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:57 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:57 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:57 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:57 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:58 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:58 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 09:45:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:58 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:58 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:58 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:58 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:58 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:58 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:59 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:59 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:59 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:45:59 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:18 --> Config Class Initialized
DEBUG - 2010-07-08 09:46:18 --> Hooks Class Initialized
DEBUG - 2010-07-08 09:46:18 --> URI Class Initialized
DEBUG - 2010-07-08 09:46:18 --> Router Class Initialized
DEBUG - 2010-07-08 09:46:18 --> Output Class Initialized
DEBUG - 2010-07-08 09:46:18 --> Input Class Initialized
DEBUG - 2010-07-08 09:46:18 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 09:46:18 --> Language Class Initialized
DEBUG - 2010-07-08 09:46:18 --> Loader Class Initialized
DEBUG - 2010-07-08 09:46:18 --> Helper loaded: context_helper
DEBUG - 2010-07-08 09:46:19 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 09:46:19 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 09:46:19 --> Database Driver Class Initialized
DEBUG - 2010-07-08 09:46:19 --> Controller Class Initialized
DEBUG - 2010-07-08 09:46:19 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 09:46:19 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 09:46:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:19 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:19 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:19 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:19 --> Helper loaded: email_helper
DEBUG - 2010-07-08 09:46:20 --> User Agent Class Initialized
DEBUG - 2010-07-08 09:46:20 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:20 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:20 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 09:46:20 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:20 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:20 --> Session Class Initialized
DEBUG - 2010-07-08 09:46:20 --> Helper loaded: string_helper
DEBUG - 2010-07-08 09:46:20 --> Session routines successfully run
DEBUG - 2010-07-08 09:46:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:21 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:21 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:21 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:21 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:21 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:21 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:21 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:21 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:21 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:21 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:22 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:22 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:22 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:22 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:22 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 09:46:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:22 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:22 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:23 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:23 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:23 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:23 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:23 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:23 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:23 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:34 --> Config Class Initialized
DEBUG - 2010-07-08 09:46:34 --> Hooks Class Initialized
DEBUG - 2010-07-08 09:46:34 --> URI Class Initialized
DEBUG - 2010-07-08 09:46:34 --> Router Class Initialized
DEBUG - 2010-07-08 09:46:34 --> Output Class Initialized
DEBUG - 2010-07-08 09:46:34 --> Input Class Initialized
DEBUG - 2010-07-08 09:46:34 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 09:46:34 --> Language Class Initialized
DEBUG - 2010-07-08 09:46:34 --> Loader Class Initialized
DEBUG - 2010-07-08 09:46:35 --> Helper loaded: context_helper
DEBUG - 2010-07-08 09:46:35 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 09:46:35 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 09:46:35 --> Database Driver Class Initialized
DEBUG - 2010-07-08 09:46:35 --> Controller Class Initialized
DEBUG - 2010-07-08 09:46:35 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 09:46:35 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 09:46:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:35 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:36 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:36 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:36 --> Helper loaded: email_helper
DEBUG - 2010-07-08 09:46:36 --> User Agent Class Initialized
DEBUG - 2010-07-08 09:46:36 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:36 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:36 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 09:46:36 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:36 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:36 --> Session Class Initialized
DEBUG - 2010-07-08 09:46:36 --> Helper loaded: string_helper
DEBUG - 2010-07-08 09:46:37 --> Session routines successfully run
DEBUG - 2010-07-08 09:46:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:37 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:37 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:37 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:37 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:37 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:37 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:37 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:37 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:38 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:38 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:38 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:38 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:38 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:38 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:38 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:38 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 09:46:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:38 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:39 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:39 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:39 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:39 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:39 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:39 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:39 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:39 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:40 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:40 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:40 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:46:40 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 09:46:40 --> Final output sent to browser
DEBUG - 2010-07-08 09:46:40 --> Total execution time: 6.1731
DEBUG - 2010-07-08 09:47:23 --> Config Class Initialized
DEBUG - 2010-07-08 09:47:23 --> Hooks Class Initialized
DEBUG - 2010-07-08 09:47:23 --> URI Class Initialized
DEBUG - 2010-07-08 09:47:23 --> Router Class Initialized
DEBUG - 2010-07-08 09:47:23 --> Output Class Initialized
DEBUG - 2010-07-08 09:47:23 --> Input Class Initialized
DEBUG - 2010-07-08 09:47:24 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 09:47:24 --> Language Class Initialized
DEBUG - 2010-07-08 09:47:24 --> Loader Class Initialized
DEBUG - 2010-07-08 09:47:24 --> Helper loaded: context_helper
DEBUG - 2010-07-08 09:47:24 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 09:47:24 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 09:47:24 --> Database Driver Class Initialized
DEBUG - 2010-07-08 09:47:24 --> Controller Class Initialized
DEBUG - 2010-07-08 09:47:24 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 09:47:24 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 09:47:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:25 --> Helper loaded: email_helper
DEBUG - 2010-07-08 09:47:25 --> User Agent Class Initialized
DEBUG - 2010-07-08 09:47:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:25 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:25 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 09:47:25 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:26 --> Session Class Initialized
DEBUG - 2010-07-08 09:47:26 --> Helper loaded: string_helper
DEBUG - 2010-07-08 09:47:26 --> Session routines successfully run
DEBUG - 2010-07-08 09:47:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:26 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:26 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:26 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:26 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:27 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:27 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:27 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:27 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:27 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:27 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:27 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:27 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:27 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:27 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:28 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:28 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 09:47:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:28 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:28 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:28 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:28 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:28 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:28 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:28 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:29 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:29 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:29 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:29 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:29 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:29 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:29 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 09:47:29 --> Final output sent to browser
DEBUG - 2010-07-08 09:47:29 --> Total execution time: 6.3355
DEBUG - 2010-07-08 09:47:43 --> Config Class Initialized
DEBUG - 2010-07-08 09:47:43 --> Hooks Class Initialized
DEBUG - 2010-07-08 09:47:43 --> URI Class Initialized
DEBUG - 2010-07-08 09:47:43 --> Router Class Initialized
DEBUG - 2010-07-08 09:47:43 --> Output Class Initialized
DEBUG - 2010-07-08 09:47:43 --> Input Class Initialized
DEBUG - 2010-07-08 09:47:43 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 09:47:43 --> Language Class Initialized
DEBUG - 2010-07-08 09:47:43 --> Loader Class Initialized
DEBUG - 2010-07-08 09:47:43 --> Helper loaded: context_helper
DEBUG - 2010-07-08 09:47:43 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 09:47:44 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 09:47:44 --> Database Driver Class Initialized
DEBUG - 2010-07-08 09:47:44 --> Controller Class Initialized
DEBUG - 2010-07-08 09:47:44 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 09:47:44 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 09:47:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:44 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:44 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:44 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:45 --> Helper loaded: email_helper
DEBUG - 2010-07-08 09:47:45 --> User Agent Class Initialized
DEBUG - 2010-07-08 09:47:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:45 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:45 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:45 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 09:47:45 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:45 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:45 --> Session Class Initialized
DEBUG - 2010-07-08 09:47:45 --> Helper loaded: string_helper
DEBUG - 2010-07-08 09:47:45 --> Session routines successfully run
DEBUG - 2010-07-08 09:47:46 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:46 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:46 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:46 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:46 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:46 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:46 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:46 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:46 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:47 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:47 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:47 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:47 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:47 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:47 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:47 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:47 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 09:47:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:47 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:48 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:48 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:48 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:48 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:48 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:48 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:48 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:48 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:48 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:49 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:49 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:49 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:49 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:49 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:47:49 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 09:47:49 --> Final output sent to browser
DEBUG - 2010-07-08 09:47:49 --> Total execution time: 6.6044
DEBUG - 2010-07-08 09:48:26 --> Config Class Initialized
DEBUG - 2010-07-08 09:48:26 --> Hooks Class Initialized
DEBUG - 2010-07-08 09:48:26 --> URI Class Initialized
DEBUG - 2010-07-08 09:48:27 --> Router Class Initialized
DEBUG - 2010-07-08 09:48:27 --> Output Class Initialized
DEBUG - 2010-07-08 09:48:27 --> Input Class Initialized
DEBUG - 2010-07-08 09:48:27 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 09:48:27 --> Language Class Initialized
DEBUG - 2010-07-08 09:48:27 --> Loader Class Initialized
DEBUG - 2010-07-08 09:48:27 --> Helper loaded: context_helper
DEBUG - 2010-07-08 09:48:27 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 09:48:27 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 09:48:28 --> Database Driver Class Initialized
DEBUG - 2010-07-08 09:48:28 --> Controller Class Initialized
DEBUG - 2010-07-08 09:48:28 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 09:48:28 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 09:48:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:28 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:28 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:28 --> Helper loaded: email_helper
DEBUG - 2010-07-08 09:48:29 --> User Agent Class Initialized
DEBUG - 2010-07-08 09:48:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:29 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:29 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 09:48:29 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:29 --> Session Class Initialized
DEBUG - 2010-07-08 09:48:29 --> Helper loaded: string_helper
DEBUG - 2010-07-08 09:48:29 --> Session routines successfully run
DEBUG - 2010-07-08 09:48:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:30 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:30 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:30 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:30 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:30 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:30 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:30 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:30 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:31 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:31 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:31 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:31 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:31 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:31 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 09:48:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:32 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:32 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:32 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:32 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:32 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:32 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:32 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:32 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:33 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:33 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:33 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:33 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:33 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 09:48:33 --> Final output sent to browser
DEBUG - 2010-07-08 09:48:33 --> Total execution time: 6.8327
DEBUG - 2010-07-08 09:48:49 --> Config Class Initialized
DEBUG - 2010-07-08 09:48:49 --> Hooks Class Initialized
DEBUG - 2010-07-08 09:48:50 --> URI Class Initialized
DEBUG - 2010-07-08 09:48:50 --> Router Class Initialized
DEBUG - 2010-07-08 09:48:50 --> Output Class Initialized
DEBUG - 2010-07-08 09:48:50 --> Input Class Initialized
DEBUG - 2010-07-08 09:48:50 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 09:48:50 --> Language Class Initialized
DEBUG - 2010-07-08 09:48:50 --> Loader Class Initialized
DEBUG - 2010-07-08 09:48:50 --> Helper loaded: context_helper
DEBUG - 2010-07-08 09:48:50 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 09:48:50 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 09:48:50 --> Database Driver Class Initialized
DEBUG - 2010-07-08 09:48:51 --> Controller Class Initialized
DEBUG - 2010-07-08 09:48:51 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 09:48:51 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 09:48:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:51 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:51 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:51 --> Helper loaded: email_helper
DEBUG - 2010-07-08 09:48:51 --> User Agent Class Initialized
DEBUG - 2010-07-08 09:48:52 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:52 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:52 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 09:48:52 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:52 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:52 --> Session Class Initialized
DEBUG - 2010-07-08 09:48:52 --> Helper loaded: string_helper
DEBUG - 2010-07-08 09:48:52 --> Session routines successfully run
DEBUG - 2010-07-08 09:48:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:53 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:53 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:53 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:53 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:53 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:53 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:53 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:53 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:53 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:54 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:54 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:54 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:54 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:54 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:54 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:54 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 09:48:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:54 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:55 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:55 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:55 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:55 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:55 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:55 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:55 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:55 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:55 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:56 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:56 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:56 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:56 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:48:56 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 09:48:56 --> Final output sent to browser
DEBUG - 2010-07-08 09:48:56 --> Total execution time: 6.8714
DEBUG - 2010-07-08 09:49:08 --> Config Class Initialized
DEBUG - 2010-07-08 09:49:08 --> Hooks Class Initialized
DEBUG - 2010-07-08 09:49:08 --> URI Class Initialized
DEBUG - 2010-07-08 09:49:09 --> Router Class Initialized
DEBUG - 2010-07-08 09:49:09 --> Output Class Initialized
DEBUG - 2010-07-08 09:49:09 --> Input Class Initialized
DEBUG - 2010-07-08 09:49:09 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 09:49:09 --> Language Class Initialized
DEBUG - 2010-07-08 09:49:09 --> Loader Class Initialized
DEBUG - 2010-07-08 09:49:09 --> Helper loaded: context_helper
DEBUG - 2010-07-08 09:49:09 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 09:49:09 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 09:49:09 --> Database Driver Class Initialized
DEBUG - 2010-07-08 09:49:10 --> Controller Class Initialized
DEBUG - 2010-07-08 09:49:10 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 09:49:10 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 09:49:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:10 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:10 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:10 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:10 --> Helper loaded: email_helper
DEBUG - 2010-07-08 09:49:11 --> User Agent Class Initialized
DEBUG - 2010-07-08 09:49:11 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:11 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:11 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 09:49:11 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:11 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:11 --> Session Class Initialized
DEBUG - 2010-07-08 09:49:11 --> Helper loaded: string_helper
DEBUG - 2010-07-08 09:49:11 --> Session routines successfully run
DEBUG - 2010-07-08 09:49:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:12 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:12 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:12 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:12 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:12 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:12 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:13 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:13 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:13 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:13 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:13 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:13 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:13 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:13 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:13 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:13 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:14 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 09:49:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:14 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:14 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:14 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:14 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:14 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:14 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:15 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:15 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:15 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:15 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:15 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:15 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:15 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:15 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:16 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:16 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:16 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:16 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:16 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:16 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:16 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:16 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:16 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:16 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:17 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:17 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:17 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:17 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:17 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:17 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:17 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:17 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:17 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:17 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:18 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:18 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:18 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:18 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:30 --> Config Class Initialized
DEBUG - 2010-07-08 09:49:30 --> Hooks Class Initialized
DEBUG - 2010-07-08 09:49:30 --> URI Class Initialized
DEBUG - 2010-07-08 09:49:30 --> Router Class Initialized
DEBUG - 2010-07-08 09:49:30 --> Output Class Initialized
DEBUG - 2010-07-08 09:49:30 --> Input Class Initialized
DEBUG - 2010-07-08 09:49:30 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 09:49:31 --> Language Class Initialized
DEBUG - 2010-07-08 09:49:31 --> Loader Class Initialized
DEBUG - 2010-07-08 09:49:31 --> Helper loaded: context_helper
DEBUG - 2010-07-08 09:49:31 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 09:49:31 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 09:49:31 --> Database Driver Class Initialized
DEBUG - 2010-07-08 09:49:31 --> Controller Class Initialized
DEBUG - 2010-07-08 09:49:31 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 09:49:31 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 09:49:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:32 --> Helper loaded: email_helper
DEBUG - 2010-07-08 09:49:32 --> User Agent Class Initialized
DEBUG - 2010-07-08 09:49:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:32 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:32 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 09:49:33 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:33 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:33 --> Session Class Initialized
DEBUG - 2010-07-08 09:49:33 --> Helper loaded: string_helper
DEBUG - 2010-07-08 09:49:33 --> Session routines successfully run
DEBUG - 2010-07-08 09:49:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:33 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:34 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:34 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:34 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:34 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:34 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:34 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:34 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:34 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:34 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:35 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:35 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:35 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:35 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:35 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:35 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 09:49:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:35 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:35 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:36 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:36 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:36 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:36 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:36 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:37 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:37 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:37 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:37 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:37 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:37 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:37 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:38 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:38 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:38 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:38 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:38 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:38 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:38 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:38 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:38 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:38 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:38 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:39 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:39 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:39 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:39 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:39 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:39 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:40 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:40 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:40 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:49:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:04 --> Config Class Initialized
DEBUG - 2010-07-08 09:50:04 --> Hooks Class Initialized
DEBUG - 2010-07-08 09:50:04 --> URI Class Initialized
DEBUG - 2010-07-08 09:50:04 --> Router Class Initialized
DEBUG - 2010-07-08 09:50:04 --> Output Class Initialized
DEBUG - 2010-07-08 09:50:04 --> Input Class Initialized
DEBUG - 2010-07-08 09:50:04 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 09:50:04 --> Language Class Initialized
DEBUG - 2010-07-08 09:50:05 --> Loader Class Initialized
DEBUG - 2010-07-08 09:50:05 --> Helper loaded: context_helper
DEBUG - 2010-07-08 09:50:05 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 09:50:05 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 09:50:05 --> Database Driver Class Initialized
DEBUG - 2010-07-08 09:50:05 --> Controller Class Initialized
DEBUG - 2010-07-08 09:50:05 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 09:50:05 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 09:50:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:06 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:06 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:06 --> Helper loaded: email_helper
DEBUG - 2010-07-08 09:50:06 --> User Agent Class Initialized
DEBUG - 2010-07-08 09:50:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:06 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:06 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 09:50:07 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:07 --> Session Class Initialized
DEBUG - 2010-07-08 09:50:07 --> Helper loaded: string_helper
DEBUG - 2010-07-08 09:50:07 --> Session routines successfully run
DEBUG - 2010-07-08 09:50:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:07 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:08 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:08 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:08 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:08 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:08 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:08 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:08 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:08 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:08 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:09 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:09 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:09 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:09 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:09 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 09:50:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:09 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:09 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:09 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:10 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:10 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:10 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:10 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:10 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:10 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:10 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:10 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:11 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:11 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:11 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:11 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:11 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:11 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:11 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:11 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:12 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:12 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:12 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:12 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:12 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:12 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:12 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:12 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:12 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:12 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:13 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:13 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:13 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:13 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:13 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:13 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:13 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:13 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:13 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:14 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:50:14 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 09:50:14 --> Final output sent to browser
DEBUG - 2010-07-08 09:50:14 --> Total execution time: 10.4208
DEBUG - 2010-07-08 09:51:27 --> Config Class Initialized
DEBUG - 2010-07-08 09:51:28 --> Hooks Class Initialized
DEBUG - 2010-07-08 09:51:28 --> URI Class Initialized
DEBUG - 2010-07-08 09:51:28 --> Router Class Initialized
DEBUG - 2010-07-08 09:51:28 --> Output Class Initialized
DEBUG - 2010-07-08 09:51:28 --> Input Class Initialized
DEBUG - 2010-07-08 09:51:28 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 09:51:28 --> Language Class Initialized
DEBUG - 2010-07-08 09:51:28 --> Loader Class Initialized
DEBUG - 2010-07-08 09:51:28 --> Helper loaded: context_helper
DEBUG - 2010-07-08 09:51:29 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 09:51:29 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 09:51:29 --> Database Driver Class Initialized
DEBUG - 2010-07-08 09:51:29 --> Controller Class Initialized
DEBUG - 2010-07-08 09:51:29 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 09:51:29 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 09:51:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:29 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:30 --> Helper loaded: email_helper
DEBUG - 2010-07-08 09:51:30 --> User Agent Class Initialized
DEBUG - 2010-07-08 09:51:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:30 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:30 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 09:51:31 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:31 --> Session Class Initialized
DEBUG - 2010-07-08 09:51:31 --> Helper loaded: string_helper
DEBUG - 2010-07-08 09:51:31 --> Session routines successfully run
DEBUG - 2010-07-08 09:51:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:31 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:32 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:32 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:32 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:32 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:32 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:32 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:32 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:32 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:32 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:33 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:33 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:33 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:33 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:33 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:33 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 09:51:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:33 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:34 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:34 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:34 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:34 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:34 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:34 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:34 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:35 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:35 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:35 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:35 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:35 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:35 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:35 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:36 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:36 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:36 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:37 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:37 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:37 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:37 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:37 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:37 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:37 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:37 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:37 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:38 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:38 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:38 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:38 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:38 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:51:39 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 09:51:39 --> Final output sent to browser
DEBUG - 2010-07-08 09:51:39 --> Total execution time: 11.2366
DEBUG - 2010-07-08 09:52:03 --> Config Class Initialized
DEBUG - 2010-07-08 09:52:03 --> Hooks Class Initialized
DEBUG - 2010-07-08 09:52:03 --> URI Class Initialized
DEBUG - 2010-07-08 09:52:03 --> Router Class Initialized
DEBUG - 2010-07-08 09:52:03 --> Output Class Initialized
DEBUG - 2010-07-08 09:52:03 --> Input Class Initialized
DEBUG - 2010-07-08 09:52:03 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 09:52:03 --> Language Class Initialized
DEBUG - 2010-07-08 09:52:03 --> Loader Class Initialized
DEBUG - 2010-07-08 09:52:03 --> Helper loaded: context_helper
DEBUG - 2010-07-08 09:52:04 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 09:52:04 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 09:52:04 --> Database Driver Class Initialized
DEBUG - 2010-07-08 09:52:04 --> Controller Class Initialized
DEBUG - 2010-07-08 09:52:04 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 09:52:04 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 09:52:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:04 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:05 --> Helper loaded: email_helper
DEBUG - 2010-07-08 09:52:05 --> User Agent Class Initialized
DEBUG - 2010-07-08 09:52:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:05 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:05 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 09:52:05 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:06 --> Session Class Initialized
DEBUG - 2010-07-08 09:52:06 --> Helper loaded: string_helper
DEBUG - 2010-07-08 09:52:06 --> Session routines successfully run
DEBUG - 2010-07-08 09:52:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:06 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:06 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:07 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:07 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:07 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:07 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:07 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:07 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:07 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:07 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:08 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:08 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:08 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:08 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 09:52:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:09 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:09 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:09 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:09 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:09 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:09 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:09 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:09 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:10 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:10 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:10 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:10 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:10 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:10 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:10 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:11 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:11 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:11 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:11 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:11 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:11 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:11 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:11 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:11 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:12 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:12 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:12 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:12 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:12 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:12 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:12 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:13 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:13 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:13 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:13 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:13 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:13 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:13 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:13 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:13 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:14 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 09:52:14 --> Final output sent to browser
DEBUG - 2010-07-08 09:52:14 --> Total execution time: 11.1710
DEBUG - 2010-07-08 09:52:25 --> Config Class Initialized
DEBUG - 2010-07-08 09:52:25 --> Hooks Class Initialized
DEBUG - 2010-07-08 09:52:25 --> URI Class Initialized
DEBUG - 2010-07-08 09:52:26 --> Router Class Initialized
DEBUG - 2010-07-08 09:52:26 --> Output Class Initialized
DEBUG - 2010-07-08 09:52:26 --> Input Class Initialized
DEBUG - 2010-07-08 09:52:26 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 09:52:26 --> Language Class Initialized
DEBUG - 2010-07-08 09:52:26 --> Loader Class Initialized
DEBUG - 2010-07-08 09:52:26 --> Helper loaded: context_helper
DEBUG - 2010-07-08 09:52:26 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 09:52:26 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 09:52:27 --> Database Driver Class Initialized
DEBUG - 2010-07-08 09:52:27 --> Controller Class Initialized
DEBUG - 2010-07-08 09:52:27 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 09:52:27 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 09:52:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:27 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:28 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:28 --> Helper loaded: email_helper
DEBUG - 2010-07-08 09:52:28 --> User Agent Class Initialized
DEBUG - 2010-07-08 09:52:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:28 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:29 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 09:52:29 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:29 --> Session Class Initialized
DEBUG - 2010-07-08 09:52:29 --> Helper loaded: string_helper
DEBUG - 2010-07-08 09:52:29 --> Session routines successfully run
DEBUG - 2010-07-08 09:52:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:30 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:30 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:30 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:30 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:30 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:30 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:30 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:30 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:31 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:31 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:31 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:31 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:31 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:32 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 09:52:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:32 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:32 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:32 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:32 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:32 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:33 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:33 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:33 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:33 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:33 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:33 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:33 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:34 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:34 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:34 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:34 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:34 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:34 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:34 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:34 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:35 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:35 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:35 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:35 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:35 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:35 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:35 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:35 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:35 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:36 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:36 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:36 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:36 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:37 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:52:37 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 09:52:37 --> Final output sent to browser
DEBUG - 2010-07-08 09:52:37 --> Total execution time: 11.9200
DEBUG - 2010-07-08 09:53:28 --> Config Class Initialized
DEBUG - 2010-07-08 09:53:28 --> Hooks Class Initialized
DEBUG - 2010-07-08 09:53:28 --> URI Class Initialized
DEBUG - 2010-07-08 09:53:28 --> Router Class Initialized
DEBUG - 2010-07-08 09:53:28 --> Output Class Initialized
DEBUG - 2010-07-08 09:53:28 --> Input Class Initialized
DEBUG - 2010-07-08 09:53:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 09:53:29 --> Language Class Initialized
DEBUG - 2010-07-08 09:53:29 --> Loader Class Initialized
DEBUG - 2010-07-08 09:53:29 --> Helper loaded: context_helper
DEBUG - 2010-07-08 09:53:29 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 09:53:29 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 09:53:29 --> Database Driver Class Initialized
DEBUG - 2010-07-08 09:53:29 --> Controller Class Initialized
DEBUG - 2010-07-08 09:53:29 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 09:53:30 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 09:53:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:30 --> Helper loaded: email_helper
DEBUG - 2010-07-08 09:53:30 --> User Agent Class Initialized
DEBUG - 2010-07-08 09:53:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:31 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:31 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 09:53:31 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:31 --> Session Class Initialized
DEBUG - 2010-07-08 09:53:31 --> Helper loaded: string_helper
DEBUG - 2010-07-08 09:53:32 --> Session routines successfully run
DEBUG - 2010-07-08 09:53:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:32 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:32 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:32 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:32 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:32 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:33 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:33 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:33 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:33 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:33 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:33 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:33 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:33 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:34 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:34 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:34 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 09:53:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:34 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:34 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:35 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:35 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:35 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:35 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:35 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:35 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:35 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:36 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:36 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:36 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:36 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:36 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:37 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:37 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:37 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:37 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:37 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:37 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:37 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:37 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:37 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:37 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:38 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:38 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:38 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:38 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:38 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:38 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:38 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:38 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:39 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:39 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:39 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:53:40 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 09:53:40 --> Final output sent to browser
DEBUG - 2010-07-08 09:53:40 --> Total execution time: 11.8102
DEBUG - 2010-07-08 09:54:38 --> Config Class Initialized
DEBUG - 2010-07-08 09:54:38 --> Hooks Class Initialized
DEBUG - 2010-07-08 09:54:38 --> URI Class Initialized
DEBUG - 2010-07-08 09:54:39 --> Router Class Initialized
DEBUG - 2010-07-08 09:54:39 --> Output Class Initialized
DEBUG - 2010-07-08 09:54:39 --> Input Class Initialized
DEBUG - 2010-07-08 09:54:39 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 09:54:39 --> Language Class Initialized
DEBUG - 2010-07-08 09:54:39 --> Loader Class Initialized
DEBUG - 2010-07-08 09:54:39 --> Helper loaded: context_helper
DEBUG - 2010-07-08 09:54:39 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 09:54:39 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 09:54:40 --> Database Driver Class Initialized
DEBUG - 2010-07-08 09:54:40 --> Controller Class Initialized
DEBUG - 2010-07-08 09:54:40 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 09:54:40 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 09:54:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:40 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:40 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:41 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:41 --> Helper loaded: email_helper
DEBUG - 2010-07-08 09:54:41 --> User Agent Class Initialized
DEBUG - 2010-07-08 09:54:41 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:41 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:41 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 09:54:41 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:42 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:42 --> Session Class Initialized
DEBUG - 2010-07-08 09:54:42 --> Helper loaded: string_helper
DEBUG - 2010-07-08 09:54:42 --> Session routines successfully run
DEBUG - 2010-07-08 09:54:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:42 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:42 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:43 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:43 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:43 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:43 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:43 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:43 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:43 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:43 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:43 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:44 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:44 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:44 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:44 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:44 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:44 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:44 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 09:54:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:44 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:45 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:45 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:45 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:45 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:45 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:45 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:45 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:46 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:46 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:46 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:46 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:46 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:46 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:46 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:47 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:47 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:47 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:47 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:47 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:47 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:47 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:47 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:48 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:48 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:48 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:48 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:48 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:48 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:48 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:48 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:49 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:49 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:49 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:49 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:49 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:49 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:49 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:49 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:50 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:50 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:50 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:50 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:54:50 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 09:54:50 --> Final output sent to browser
DEBUG - 2010-07-08 09:54:50 --> Total execution time: 12.1772
DEBUG - 2010-07-08 09:55:19 --> Config Class Initialized
DEBUG - 2010-07-08 09:55:19 --> Hooks Class Initialized
DEBUG - 2010-07-08 09:55:19 --> URI Class Initialized
DEBUG - 2010-07-08 09:55:19 --> Router Class Initialized
DEBUG - 2010-07-08 09:55:19 --> Output Class Initialized
DEBUG - 2010-07-08 09:55:19 --> Input Class Initialized
DEBUG - 2010-07-08 09:55:19 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 09:55:20 --> Language Class Initialized
DEBUG - 2010-07-08 09:55:20 --> Loader Class Initialized
DEBUG - 2010-07-08 09:55:20 --> Helper loaded: context_helper
DEBUG - 2010-07-08 09:55:20 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 09:55:20 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 09:55:20 --> Database Driver Class Initialized
DEBUG - 2010-07-08 09:55:20 --> Controller Class Initialized
DEBUG - 2010-07-08 09:55:20 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 09:55:20 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 09:55:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:21 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:21 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:21 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:21 --> Helper loaded: email_helper
DEBUG - 2010-07-08 09:55:21 --> User Agent Class Initialized
DEBUG - 2010-07-08 09:55:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:22 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:22 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 09:55:22 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:22 --> Session Class Initialized
DEBUG - 2010-07-08 09:55:22 --> Helper loaded: string_helper
DEBUG - 2010-07-08 09:55:23 --> Session routines successfully run
DEBUG - 2010-07-08 09:55:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:23 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:23 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:23 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:24 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:24 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:24 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:24 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:24 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:24 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:24 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:25 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:25 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:25 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:25 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 09:55:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:25 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:26 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:26 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:26 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:26 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:26 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:26 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:26 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:27 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:27 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:27 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:27 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:27 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:27 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:28 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:28 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:28 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:28 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:28 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:28 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:28 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:28 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:29 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:29 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:29 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:29 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:29 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:29 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:29 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:29 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:29 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:30 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:30 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:30 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:30 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:31 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 09:55:31 --> Final output sent to browser
DEBUG - 2010-07-08 09:55:31 --> Total execution time: 12.2726
DEBUG - 2010-07-08 09:55:42 --> Config Class Initialized
DEBUG - 2010-07-08 09:55:42 --> Hooks Class Initialized
DEBUG - 2010-07-08 09:55:42 --> URI Class Initialized
DEBUG - 2010-07-08 09:55:42 --> Router Class Initialized
DEBUG - 2010-07-08 09:55:42 --> Output Class Initialized
DEBUG - 2010-07-08 09:55:42 --> Input Class Initialized
DEBUG - 2010-07-08 09:55:43 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 09:55:43 --> Language Class Initialized
DEBUG - 2010-07-08 09:55:43 --> Loader Class Initialized
DEBUG - 2010-07-08 09:55:43 --> Helper loaded: context_helper
DEBUG - 2010-07-08 09:55:43 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 09:55:43 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 09:55:43 --> Database Driver Class Initialized
DEBUG - 2010-07-08 09:55:43 --> Controller Class Initialized
DEBUG - 2010-07-08 09:55:43 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 09:55:44 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 09:55:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:44 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:44 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:44 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:44 --> Helper loaded: email_helper
DEBUG - 2010-07-08 09:55:45 --> User Agent Class Initialized
DEBUG - 2010-07-08 09:55:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:45 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:45 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:45 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 09:55:45 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:45 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:45 --> Session Class Initialized
DEBUG - 2010-07-08 09:55:46 --> Helper loaded: string_helper
DEBUG - 2010-07-08 09:55:46 --> Session routines successfully run
DEBUG - 2010-07-08 09:55:46 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:46 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:46 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:46 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:46 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:47 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:47 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:47 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:47 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:47 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:47 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:47 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:47 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:48 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:48 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:48 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:48 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:48 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 09:55:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:48 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:49 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:49 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:49 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:49 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:49 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:49 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:49 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:49 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:50 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:50 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:50 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:50 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:50 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:50 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:50 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:50 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:51 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:51 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:51 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:51 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:51 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:51 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:51 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:51 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:51 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:52 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:52 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:52 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:52 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:52 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:52 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:52 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:52 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:53 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:53 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:53 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:53 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:53 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:53 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:53 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:54 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:55:54 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 09:55:54 --> Final output sent to browser
DEBUG - 2010-07-08 09:55:54 --> Total execution time: 12.4675
DEBUG - 2010-07-08 09:57:01 --> Config Class Initialized
DEBUG - 2010-07-08 09:57:01 --> Hooks Class Initialized
DEBUG - 2010-07-08 09:57:01 --> URI Class Initialized
DEBUG - 2010-07-08 09:57:01 --> Router Class Initialized
DEBUG - 2010-07-08 09:57:01 --> Output Class Initialized
DEBUG - 2010-07-08 09:57:01 --> Input Class Initialized
DEBUG - 2010-07-08 09:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 09:57:02 --> Language Class Initialized
DEBUG - 2010-07-08 09:57:02 --> Loader Class Initialized
DEBUG - 2010-07-08 09:57:02 --> Helper loaded: context_helper
DEBUG - 2010-07-08 09:57:02 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 09:57:02 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 09:57:02 --> Database Driver Class Initialized
DEBUG - 2010-07-08 09:57:02 --> Controller Class Initialized
DEBUG - 2010-07-08 09:57:02 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 09:57:03 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 09:57:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:03 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:03 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:03 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:03 --> Helper loaded: email_helper
DEBUG - 2010-07-08 09:57:04 --> User Agent Class Initialized
DEBUG - 2010-07-08 09:57:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:04 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:04 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 09:57:04 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:05 --> Session Class Initialized
DEBUG - 2010-07-08 09:57:05 --> Helper loaded: string_helper
DEBUG - 2010-07-08 09:57:05 --> Session routines successfully run
DEBUG - 2010-07-08 09:57:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:05 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:05 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:05 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:06 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:06 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:06 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:06 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:06 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:06 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:06 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:07 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:07 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:07 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 09:57:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:08 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:08 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:08 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:08 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:08 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:09 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:09 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:09 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:09 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:09 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:09 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:10 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:10 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:10 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:10 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:10 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:11 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:11 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:11 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:11 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:11 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:11 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:11 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:11 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:12 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:12 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:12 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:12 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:12 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:12 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:12 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:13 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:13 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:13 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:13 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:13 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:13 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:13 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:43 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:43 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:43 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:43 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:43 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:43 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:43 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:43 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:44 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:44 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:44 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:44 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:44 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:44 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:44 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:45 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:45 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:45 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:45 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:45 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:45 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:45 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:45 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:46 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:46 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:46 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:46 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:46 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:46 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:46 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:46 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:47 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:47 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:47 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:47 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:47 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:47 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:47 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:48 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:48 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:48 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:48 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:48 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:48 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:48 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:48 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:49 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:49 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:49 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:49 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:49 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:49 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 09:57:49 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:09 --> Config Class Initialized
DEBUG - 2010-07-08 10:00:09 --> Hooks Class Initialized
DEBUG - 2010-07-08 10:00:09 --> URI Class Initialized
DEBUG - 2010-07-08 10:00:09 --> Router Class Initialized
DEBUG - 2010-07-08 10:00:09 --> Output Class Initialized
DEBUG - 2010-07-08 10:00:09 --> Input Class Initialized
DEBUG - 2010-07-08 10:00:09 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 10:00:10 --> Language Class Initialized
DEBUG - 2010-07-08 10:00:10 --> Loader Class Initialized
DEBUG - 2010-07-08 10:00:10 --> Helper loaded: context_helper
DEBUG - 2010-07-08 10:00:10 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 10:00:10 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 10:00:10 --> Database Driver Class Initialized
DEBUG - 2010-07-08 10:00:11 --> Controller Class Initialized
DEBUG - 2010-07-08 10:00:11 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 10:00:11 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 10:00:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:11 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:12 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:12 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:12 --> Helper loaded: email_helper
DEBUG - 2010-07-08 10:00:12 --> User Agent Class Initialized
DEBUG - 2010-07-08 10:00:12 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:12 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:13 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 10:00:13 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:13 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:13 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:13 --> Session Class Initialized
DEBUG - 2010-07-08 10:00:13 --> Helper loaded: string_helper
DEBUG - 2010-07-08 10:00:13 --> Session routines successfully run
DEBUG - 2010-07-08 10:00:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:14 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:14 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:14 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:14 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:15 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:15 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:15 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:15 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:15 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:15 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:15 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:16 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:16 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:16 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:16 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 10:00:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:17 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:17 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:17 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:17 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:17 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:18 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:18 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:18 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:18 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:19 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:19 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:19 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:19 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:38 --> Config Class Initialized
DEBUG - 2010-07-08 10:00:38 --> Hooks Class Initialized
DEBUG - 2010-07-08 10:00:38 --> URI Class Initialized
DEBUG - 2010-07-08 10:00:39 --> Router Class Initialized
DEBUG - 2010-07-08 10:00:39 --> Output Class Initialized
DEBUG - 2010-07-08 10:00:39 --> Input Class Initialized
DEBUG - 2010-07-08 10:00:39 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 10:00:39 --> Language Class Initialized
DEBUG - 2010-07-08 10:00:39 --> Loader Class Initialized
DEBUG - 2010-07-08 10:00:39 --> Helper loaded: context_helper
DEBUG - 2010-07-08 10:00:40 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 10:00:40 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 10:00:40 --> Database Driver Class Initialized
DEBUG - 2010-07-08 10:00:40 --> Controller Class Initialized
DEBUG - 2010-07-08 10:00:40 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 10:00:40 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 10:00:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:41 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:41 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:41 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:41 --> Helper loaded: email_helper
DEBUG - 2010-07-08 10:00:42 --> User Agent Class Initialized
DEBUG - 2010-07-08 10:00:42 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:42 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:42 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 10:00:42 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:42 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:43 --> Session Class Initialized
DEBUG - 2010-07-08 10:00:43 --> Helper loaded: string_helper
DEBUG - 2010-07-08 10:00:43 --> Session routines successfully run
DEBUG - 2010-07-08 10:00:43 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:43 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:43 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:43 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:44 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:44 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:44 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:44 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:44 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:44 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:44 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:44 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:45 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:45 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:45 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:45 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:45 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:45 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:46 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 10:00:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:46 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:46 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:46 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:46 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:46 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:47 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:47 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:47 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:47 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:47 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:47 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:47 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:48 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:48 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:48 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:48 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:48 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:48 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:48 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:49 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:49 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:49 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:49 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:49 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:49 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:49 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:49 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:50 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:50 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:50 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:50 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:50 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:50 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:50 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:51 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:51 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:51 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:51 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:51 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:51 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:52 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:00:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:13 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:13 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:13 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:13 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:13 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:13 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:13 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:01:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:17 --> Config Class Initialized
DEBUG - 2010-07-08 10:02:18 --> Hooks Class Initialized
DEBUG - 2010-07-08 10:02:18 --> URI Class Initialized
DEBUG - 2010-07-08 10:02:18 --> Router Class Initialized
DEBUG - 2010-07-08 10:02:18 --> Output Class Initialized
DEBUG - 2010-07-08 10:02:18 --> Input Class Initialized
DEBUG - 2010-07-08 10:02:18 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 10:02:18 --> Language Class Initialized
DEBUG - 2010-07-08 10:02:19 --> Loader Class Initialized
DEBUG - 2010-07-08 10:02:19 --> Helper loaded: context_helper
DEBUG - 2010-07-08 10:02:19 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 10:02:19 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 10:02:19 --> Database Driver Class Initialized
DEBUG - 2010-07-08 10:02:19 --> Controller Class Initialized
DEBUG - 2010-07-08 10:02:20 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 10:02:20 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 10:02:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:20 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:20 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:21 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:21 --> Helper loaded: email_helper
DEBUG - 2010-07-08 10:02:21 --> User Agent Class Initialized
DEBUG - 2010-07-08 10:02:21 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:21 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:21 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 10:02:22 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:22 --> Session Class Initialized
DEBUG - 2010-07-08 10:02:22 --> Helper loaded: string_helper
DEBUG - 2010-07-08 10:02:22 --> Session routines successfully run
DEBUG - 2010-07-08 10:02:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:23 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:23 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:24 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:24 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:24 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:24 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:24 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:24 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:25 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:25 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:25 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:26 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 10:02:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:26 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:26 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:26 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:27 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:27 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:27 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:27 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:27 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:27 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:28 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:28 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:28 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:28 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:29 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:29 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:29 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:29 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:29 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:29 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:29 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:30 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:30 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:30 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:30 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:30 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:30 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:30 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:31 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:31 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:31 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:31 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:31 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:32 --> Config Class Initialized
DEBUG - 2010-07-08 10:02:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:32 --> Hooks Class Initialized
DEBUG - 2010-07-08 10:02:32 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:32 --> URI Class Initialized
DEBUG - 2010-07-08 10:02:32 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:32 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:32 --> Router Class Initialized
DEBUG - 2010-07-08 10:02:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:32 --> Output Class Initialized
DEBUG - 2010-07-08 10:02:32 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:32 --> Input Class Initialized
DEBUG - 2010-07-08 10:02:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:33 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 10:02:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:33 --> Language Class Initialized
DEBUG - 2010-07-08 10:02:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:33 --> Loader Class Initialized
DEBUG - 2010-07-08 10:02:33 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 10:02:33 --> Final output sent to browser
DEBUG - 2010-07-08 10:02:33 --> Helper loaded: context_helper
DEBUG - 2010-07-08 10:02:33 --> Total execution time: 15.6786
DEBUG - 2010-07-08 10:02:33 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 10:02:34 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 10:02:34 --> Database Driver Class Initialized
DEBUG - 2010-07-08 10:02:34 --> Controller Class Initialized
DEBUG - 2010-07-08 10:02:34 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 10:02:34 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 10:02:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:35 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:35 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:35 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:35 --> Helper loaded: email_helper
DEBUG - 2010-07-08 10:02:35 --> User Agent Class Initialized
DEBUG - 2010-07-08 10:02:36 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:36 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:36 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 10:02:36 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:36 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:37 --> Session Class Initialized
DEBUG - 2010-07-08 10:02:37 --> Helper loaded: string_helper
DEBUG - 2010-07-08 10:02:37 --> Session routines successfully run
DEBUG - 2010-07-08 10:02:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:38 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:38 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:38 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:38 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:38 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:38 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:38 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:39 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:39 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:39 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:39 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:40 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:40 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:40 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:40 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 10:02:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:41 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:41 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:41 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:41 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:41 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:41 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:42 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:42 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:42 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:42 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:42 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:43 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:43 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:43 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:02:43 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 10:02:43 --> Final output sent to browser
DEBUG - 2010-07-08 10:02:43 --> Total execution time: 11.5963
DEBUG - 2010-07-08 10:05:10 --> Config Class Initialized
DEBUG - 2010-07-08 10:05:10 --> Hooks Class Initialized
DEBUG - 2010-07-08 10:05:10 --> URI Class Initialized
DEBUG - 2010-07-08 10:05:10 --> Router Class Initialized
DEBUG - 2010-07-08 10:05:10 --> Output Class Initialized
DEBUG - 2010-07-08 10:05:10 --> Input Class Initialized
DEBUG - 2010-07-08 10:05:10 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 10:05:11 --> Language Class Initialized
DEBUG - 2010-07-08 10:05:11 --> Loader Class Initialized
DEBUG - 2010-07-08 10:05:11 --> Helper loaded: context_helper
DEBUG - 2010-07-08 10:05:11 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 10:05:11 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 10:05:11 --> Database Driver Class Initialized
DEBUG - 2010-07-08 10:05:11 --> Controller Class Initialized
DEBUG - 2010-07-08 10:05:12 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 10:05:12 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 10:05:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:12 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:13 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:13 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:13 --> Helper loaded: email_helper
DEBUG - 2010-07-08 10:05:13 --> User Agent Class Initialized
DEBUG - 2010-07-08 10:05:13 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:13 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:13 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:14 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 10:05:14 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:14 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:14 --> Session Class Initialized
DEBUG - 2010-07-08 10:05:14 --> Helper loaded: string_helper
DEBUG - 2010-07-08 10:05:15 --> Session routines successfully run
DEBUG - 2010-07-08 10:05:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:15 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:15 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:15 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:16 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:16 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:16 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:16 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:16 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:16 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:16 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:17 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:17 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:17 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:17 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:18 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 10:05:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:18 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:18 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:18 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:19 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:19 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:19 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:19 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:19 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:19 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:20 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:20 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:20 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:20 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:20 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 10:05:21 --> Final output sent to browser
DEBUG - 2010-07-08 10:05:21 --> Total execution time: 11.0953
DEBUG - 2010-07-08 10:05:40 --> Config Class Initialized
DEBUG - 2010-07-08 10:05:40 --> Hooks Class Initialized
DEBUG - 2010-07-08 10:05:41 --> URI Class Initialized
DEBUG - 2010-07-08 10:05:41 --> Router Class Initialized
DEBUG - 2010-07-08 10:05:41 --> Output Class Initialized
DEBUG - 2010-07-08 10:05:41 --> Input Class Initialized
DEBUG - 2010-07-08 10:05:41 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 10:05:41 --> Language Class Initialized
DEBUG - 2010-07-08 10:05:42 --> Loader Class Initialized
DEBUG - 2010-07-08 10:05:42 --> Helper loaded: context_helper
DEBUG - 2010-07-08 10:05:42 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 10:05:42 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 10:05:42 --> Database Driver Class Initialized
DEBUG - 2010-07-08 10:05:42 --> Controller Class Initialized
DEBUG - 2010-07-08 10:05:42 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 10:05:43 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 10:05:43 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:43 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:43 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:43 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:43 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:44 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:44 --> Helper loaded: email_helper
DEBUG - 2010-07-08 10:05:44 --> User Agent Class Initialized
DEBUG - 2010-07-08 10:05:44 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:44 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:44 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:45 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 10:05:45 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:45 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:45 --> Session Class Initialized
DEBUG - 2010-07-08 10:05:45 --> Helper loaded: string_helper
DEBUG - 2010-07-08 10:05:45 --> Session routines successfully run
DEBUG - 2010-07-08 10:05:46 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:46 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:46 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:46 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:46 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:47 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:47 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:47 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:47 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:47 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:47 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:47 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:48 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:48 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:48 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:48 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:48 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:49 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 10:05:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:49 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:49 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:49 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:49 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:50 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:50 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:50 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:50 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:50 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:50 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:51 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:51 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:51 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:51 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:51 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:05:52 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 10:05:52 --> Final output sent to browser
DEBUG - 2010-07-08 10:05:52 --> Total execution time: 11.5127
DEBUG - 2010-07-08 10:06:12 --> Config Class Initialized
DEBUG - 2010-07-08 10:06:12 --> Hooks Class Initialized
DEBUG - 2010-07-08 10:06:12 --> URI Class Initialized
DEBUG - 2010-07-08 10:06:12 --> Router Class Initialized
DEBUG - 2010-07-08 10:06:13 --> Output Class Initialized
DEBUG - 2010-07-08 10:06:13 --> Input Class Initialized
DEBUG - 2010-07-08 10:06:13 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 10:06:13 --> Language Class Initialized
DEBUG - 2010-07-08 10:06:13 --> Loader Class Initialized
DEBUG - 2010-07-08 10:06:13 --> Helper loaded: context_helper
DEBUG - 2010-07-08 10:06:14 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 10:06:14 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 10:06:14 --> Database Driver Class Initialized
DEBUG - 2010-07-08 10:06:14 --> Controller Class Initialized
DEBUG - 2010-07-08 10:06:14 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 10:06:14 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 10:06:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:15 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:15 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:15 --> Helper loaded: email_helper
DEBUG - 2010-07-08 10:06:16 --> User Agent Class Initialized
DEBUG - 2010-07-08 10:06:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:16 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:16 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 10:06:16 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:17 --> Session Class Initialized
DEBUG - 2010-07-08 10:06:17 --> Helper loaded: string_helper
DEBUG - 2010-07-08 10:06:17 --> Session routines successfully run
DEBUG - 2010-07-08 10:06:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:18 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:18 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:18 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:18 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:18 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:18 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:19 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:19 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:19 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:19 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:19 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:20 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:20 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:20 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:20 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:20 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 10:06:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:21 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:21 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:21 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:21 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:21 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:22 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:22 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:22 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:22 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:22 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:23 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:23 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:23 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:24 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:24 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:24 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:24 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:24 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:24 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:25 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:25 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:25 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:25 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:25 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:25 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:25 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:26 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:26 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:26 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:26 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:26 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:26 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:27 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:27 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:27 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:27 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:27 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:06:28 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 10:06:28 --> Final output sent to browser
DEBUG - 2010-07-08 10:06:28 --> Total execution time: 16.0779
DEBUG - 2010-07-08 10:06:59 --> Config Class Initialized
DEBUG - 2010-07-08 10:06:59 --> Hooks Class Initialized
DEBUG - 2010-07-08 10:06:59 --> URI Class Initialized
DEBUG - 2010-07-08 10:06:59 --> Router Class Initialized
DEBUG - 2010-07-08 10:07:00 --> Output Class Initialized
DEBUG - 2010-07-08 10:07:00 --> Input Class Initialized
DEBUG - 2010-07-08 10:07:00 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 10:07:00 --> Language Class Initialized
DEBUG - 2010-07-08 10:07:00 --> Loader Class Initialized
DEBUG - 2010-07-08 10:07:00 --> Helper loaded: context_helper
DEBUG - 2010-07-08 10:07:00 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 10:07:01 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 10:07:01 --> Database Driver Class Initialized
DEBUG - 2010-07-08 10:07:01 --> Controller Class Initialized
DEBUG - 2010-07-08 10:07:01 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 10:07:01 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 10:07:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:02 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:02 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:02 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:02 --> Helper loaded: email_helper
DEBUG - 2010-07-08 10:07:02 --> User Agent Class Initialized
DEBUG - 2010-07-08 10:07:03 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:03 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:03 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 10:07:03 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:04 --> Session Class Initialized
DEBUG - 2010-07-08 10:07:04 --> Helper loaded: string_helper
DEBUG - 2010-07-08 10:07:04 --> Session routines successfully run
DEBUG - 2010-07-08 10:07:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:05 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:05 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:05 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:05 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:05 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:06 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:06 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:06 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:06 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:06 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:07 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:07 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:08 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 10:07:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:08 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:09 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:09 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:09 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:09 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:09 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:09 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:10 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:10 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:10 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:10 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:10 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:11 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:11 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:11 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:11 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:11 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:11 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:12 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:12 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:12 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:12 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:12 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:12 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:13 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:13 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:13 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:13 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:13 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:13 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:13 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:14 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:14 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:14 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:14 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:14 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:15 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:15 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 10:07:16 --> Final output sent to browser
DEBUG - 2010-07-08 10:07:16 --> Total execution time: 16.6697
DEBUG - 2010-07-08 10:07:34 --> Config Class Initialized
DEBUG - 2010-07-08 10:07:34 --> Hooks Class Initialized
DEBUG - 2010-07-08 10:07:34 --> URI Class Initialized
DEBUG - 2010-07-08 10:07:34 --> Router Class Initialized
DEBUG - 2010-07-08 10:07:34 --> Output Class Initialized
DEBUG - 2010-07-08 10:07:34 --> Input Class Initialized
DEBUG - 2010-07-08 10:07:34 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 10:07:35 --> Language Class Initialized
DEBUG - 2010-07-08 10:07:35 --> Loader Class Initialized
DEBUG - 2010-07-08 10:07:35 --> Helper loaded: context_helper
DEBUG - 2010-07-08 10:07:35 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 10:07:35 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 10:07:35 --> Database Driver Class Initialized
DEBUG - 2010-07-08 10:07:36 --> Controller Class Initialized
DEBUG - 2010-07-08 10:07:36 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 10:07:36 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 10:07:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:36 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:37 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:37 --> Helper loaded: email_helper
DEBUG - 2010-07-08 10:07:37 --> User Agent Class Initialized
DEBUG - 2010-07-08 10:07:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:38 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:38 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 10:07:38 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:38 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:39 --> Session Class Initialized
DEBUG - 2010-07-08 10:07:39 --> Helper loaded: string_helper
DEBUG - 2010-07-08 10:07:39 --> Session routines successfully run
DEBUG - 2010-07-08 10:07:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:40 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:40 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:40 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:40 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:40 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:40 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:40 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:41 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:41 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:41 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:41 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:41 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:42 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:42 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:42 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:42 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 10:07:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:42 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:43 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:43 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:43 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:43 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:43 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:43 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:44 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:44 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:44 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:44 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:44 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:44 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:45 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:45 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:45 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:45 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:45 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:46 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:46 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:46 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:46 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:46 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:47 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:47 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:47 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:47 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:47 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:47 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:48 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:48 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:48 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:48 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:48 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:49 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:49 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:49 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:49 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:49 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:49 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:50 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:50 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:50 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:50 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:50 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:50 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:07:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:13 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:13 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:13 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:13 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:13 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:13 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:08:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:43 --> Config Class Initialized
DEBUG - 2010-07-08 10:09:43 --> Hooks Class Initialized
DEBUG - 2010-07-08 10:09:43 --> URI Class Initialized
DEBUG - 2010-07-08 10:09:44 --> Router Class Initialized
DEBUG - 2010-07-08 10:09:44 --> Output Class Initialized
DEBUG - 2010-07-08 10:09:44 --> Input Class Initialized
DEBUG - 2010-07-08 10:09:44 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 10:09:44 --> Language Class Initialized
DEBUG - 2010-07-08 10:09:44 --> Loader Class Initialized
DEBUG - 2010-07-08 10:09:45 --> Helper loaded: context_helper
DEBUG - 2010-07-08 10:09:45 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 10:09:45 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 10:09:45 --> Database Driver Class Initialized
DEBUG - 2010-07-08 10:09:45 --> Controller Class Initialized
DEBUG - 2010-07-08 10:09:46 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 10:09:46 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 10:09:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:46 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:47 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:47 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:47 --> Helper loaded: email_helper
DEBUG - 2010-07-08 10:09:47 --> User Agent Class Initialized
DEBUG - 2010-07-08 10:09:47 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:48 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:48 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:48 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 10:09:48 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:48 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:49 --> Session Class Initialized
DEBUG - 2010-07-08 10:09:49 --> Helper loaded: string_helper
DEBUG - 2010-07-08 10:09:49 --> Session routines successfully run
DEBUG - 2010-07-08 10:09:49 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:50 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:50 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:50 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:50 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:50 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:50 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:51 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:51 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:51 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:51 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:51 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:52 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:52 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:52 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:52 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:52 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:53 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 10:09:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:53 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:53 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:53 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:54 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:54 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:54 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:54 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:54 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:55 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:55 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:55 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:55 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:55 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:56 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:56 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:56 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:56 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:57 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:57 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:57 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:57 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:57 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:57 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:58 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:58 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:58 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:58 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:58 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:58 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:59 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:59 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:59 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:59 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:09:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:00 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:00 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:00 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:00 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:00 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:01 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 10:10:01 --> Final output sent to browser
DEBUG - 2010-07-08 10:10:02 --> Total execution time: 18.3942
DEBUG - 2010-07-08 10:10:49 --> Config Class Initialized
DEBUG - 2010-07-08 10:10:49 --> Hooks Class Initialized
DEBUG - 2010-07-08 10:10:50 --> URI Class Initialized
DEBUG - 2010-07-08 10:10:50 --> Router Class Initialized
DEBUG - 2010-07-08 10:10:50 --> Output Class Initialized
DEBUG - 2010-07-08 10:10:50 --> Input Class Initialized
DEBUG - 2010-07-08 10:10:50 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 10:10:50 --> Language Class Initialized
DEBUG - 2010-07-08 10:10:51 --> Loader Class Initialized
DEBUG - 2010-07-08 10:10:51 --> Helper loaded: context_helper
DEBUG - 2010-07-08 10:10:51 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 10:10:51 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 10:10:51 --> Database Driver Class Initialized
DEBUG - 2010-07-08 10:10:52 --> Controller Class Initialized
DEBUG - 2010-07-08 10:10:52 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 10:10:52 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 10:10:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:52 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:53 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:53 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:53 --> Helper loaded: email_helper
DEBUG - 2010-07-08 10:10:53 --> User Agent Class Initialized
DEBUG - 2010-07-08 10:10:53 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:54 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:54 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 10:10:54 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:55 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:55 --> Session Class Initialized
DEBUG - 2010-07-08 10:10:55 --> Helper loaded: string_helper
DEBUG - 2010-07-08 10:10:55 --> Session routines successfully run
DEBUG - 2010-07-08 10:10:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:56 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:56 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:56 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:56 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:57 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:57 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:57 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:57 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:57 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:57 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:58 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:58 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:59 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:59 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 10:10:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:10:59 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:00 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:00 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:00 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:00 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:01 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:01 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:01 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:01 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:01 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:02 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:02 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:02 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:02 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:03 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:03 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:03 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:03 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:03 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:03 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:04 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:04 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:04 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:04 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:04 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:04 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:05 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:05 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:05 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:05 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:05 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:06 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:06 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:06 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:06 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:07 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:34 --> Config Class Initialized
DEBUG - 2010-07-08 10:11:35 --> Hooks Class Initialized
DEBUG - 2010-07-08 10:11:35 --> URI Class Initialized
DEBUG - 2010-07-08 10:11:35 --> Router Class Initialized
DEBUG - 2010-07-08 10:11:35 --> Output Class Initialized
DEBUG - 2010-07-08 10:11:35 --> Input Class Initialized
DEBUG - 2010-07-08 10:11:35 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 10:11:36 --> Language Class Initialized
DEBUG - 2010-07-08 10:11:36 --> Loader Class Initialized
DEBUG - 2010-07-08 10:11:36 --> Helper loaded: context_helper
DEBUG - 2010-07-08 10:11:36 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 10:11:36 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 10:11:37 --> Database Driver Class Initialized
DEBUG - 2010-07-08 10:11:37 --> Controller Class Initialized
DEBUG - 2010-07-08 10:11:37 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 10:11:37 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 10:11:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:38 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:38 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:38 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:38 --> Helper loaded: email_helper
DEBUG - 2010-07-08 10:11:39 --> User Agent Class Initialized
DEBUG - 2010-07-08 10:11:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:39 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:39 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 10:11:39 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:40 --> Session Class Initialized
DEBUG - 2010-07-08 10:11:40 --> Helper loaded: string_helper
DEBUG - 2010-07-08 10:11:40 --> Session routines successfully run
DEBUG - 2010-07-08 10:11:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:41 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:41 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:41 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:42 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:42 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:42 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:42 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:42 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:42 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:43 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:43 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:43 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:43 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:43 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:43 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:44 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:44 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:44 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 10:11:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:45 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:45 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:45 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:45 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:45 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:46 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:46 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:46 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:46 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:47 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:47 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:47 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:47 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:47 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:48 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:48 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:48 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:48 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:49 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:49 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:49 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:49 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:49 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:49 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:50 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:50 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:50 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:50 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:50 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:51 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:51 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:51 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:51 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:51 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:52 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:52 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:52 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:52 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:52 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:53 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:11:54 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 10:11:54 --> Final output sent to browser
DEBUG - 2010-07-08 10:11:54 --> Total execution time: 19.3211
DEBUG - 2010-07-08 10:12:40 --> Config Class Initialized
DEBUG - 2010-07-08 10:12:41 --> Hooks Class Initialized
DEBUG - 2010-07-08 10:12:41 --> URI Class Initialized
DEBUG - 2010-07-08 10:12:41 --> Router Class Initialized
DEBUG - 2010-07-08 10:12:41 --> Output Class Initialized
DEBUG - 2010-07-08 10:12:41 --> Input Class Initialized
DEBUG - 2010-07-08 10:12:42 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 10:12:42 --> Language Class Initialized
DEBUG - 2010-07-08 10:12:42 --> Loader Class Initialized
DEBUG - 2010-07-08 10:12:42 --> Helper loaded: context_helper
DEBUG - 2010-07-08 10:12:42 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 10:12:42 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 10:12:43 --> Database Driver Class Initialized
DEBUG - 2010-07-08 10:12:43 --> Controller Class Initialized
DEBUG - 2010-07-08 10:12:43 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 10:12:43 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 10:12:43 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:44 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:44 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:44 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:44 --> Helper loaded: email_helper
DEBUG - 2010-07-08 10:12:45 --> User Agent Class Initialized
DEBUG - 2010-07-08 10:12:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:45 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:45 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:45 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 10:12:46 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:46 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:46 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:46 --> Session Class Initialized
DEBUG - 2010-07-08 10:12:46 --> Helper loaded: string_helper
DEBUG - 2010-07-08 10:12:46 --> Session routines successfully run
DEBUG - 2010-07-08 10:12:47 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:47 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:47 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:47 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:48 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:48 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:48 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:48 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:48 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:48 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:49 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:49 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:49 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:49 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:49 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:50 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:50 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:50 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:50 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 10:12:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:51 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:51 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:51 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:51 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:52 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:52 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:52 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:52 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:52 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:53 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:53 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:53 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:53 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:54 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:54 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:54 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:54 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:54 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:55 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:55 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:55 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:55 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:55 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:56 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:56 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:56 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:56 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:56 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:57 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:57 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:57 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:57 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:58 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:58 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:58 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:59 --> Annotation class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:12:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 10:13:00 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 10:13:00 --> Final output sent to browser
DEBUG - 2010-07-08 10:13:00 --> Total execution time: 19.2270
DEBUG - 2010-07-08 14:09:48 --> Config Class Initialized
DEBUG - 2010-07-08 14:09:49 --> Hooks Class Initialized
DEBUG - 2010-07-08 14:09:49 --> URI Class Initialized
DEBUG - 2010-07-08 14:09:49 --> Router Class Initialized
DEBUG - 2010-07-08 14:09:49 --> Output Class Initialized
DEBUG - 2010-07-08 14:09:49 --> Input Class Initialized
DEBUG - 2010-07-08 14:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 14:09:50 --> Language Class Initialized
DEBUG - 2010-07-08 14:09:50 --> Loader Class Initialized
DEBUG - 2010-07-08 14:09:50 --> Helper loaded: context_helper
DEBUG - 2010-07-08 14:09:50 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 14:09:51 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 14:09:51 --> Database Driver Class Initialized
DEBUG - 2010-07-08 14:09:51 --> Controller Class Initialized
DEBUG - 2010-07-08 14:09:51 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 14:09:52 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 14:09:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:09:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:09:52 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:09:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:09:53 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:09:53 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:09:53 --> Helper loaded: email_helper
DEBUG - 2010-07-08 14:09:53 --> User Agent Class Initialized
DEBUG - 2010-07-08 14:09:53 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:09:53 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:09:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:09:54 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 14:09:54 --> Session Class Initialized
DEBUG - 2010-07-08 14:09:54 --> Helper loaded: string_helper
DEBUG - 2010-07-08 14:09:55 --> A session cookie was not found.
DEBUG - 2010-07-08 14:09:55 --> Session routines successfully run
DEBUG - 2010-07-08 14:09:55 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:09:55 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:09:55 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:09:55 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:10:39 --> Config Class Initialized
DEBUG - 2010-07-08 14:10:39 --> Hooks Class Initialized
DEBUG - 2010-07-08 14:10:39 --> URI Class Initialized
DEBUG - 2010-07-08 14:10:39 --> Router Class Initialized
DEBUG - 2010-07-08 14:10:39 --> Output Class Initialized
DEBUG - 2010-07-08 14:10:40 --> Input Class Initialized
DEBUG - 2010-07-08 14:10:40 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 14:10:40 --> Language Class Initialized
DEBUG - 2010-07-08 14:10:40 --> Loader Class Initialized
DEBUG - 2010-07-08 14:10:40 --> Helper loaded: context_helper
DEBUG - 2010-07-08 14:10:40 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 14:10:41 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 14:10:41 --> Database Driver Class Initialized
DEBUG - 2010-07-08 14:10:41 --> Controller Class Initialized
DEBUG - 2010-07-08 14:10:41 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 14:10:41 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 14:10:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:10:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:10:42 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:10:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:10:42 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:10:43 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:10:43 --> Helper loaded: email_helper
DEBUG - 2010-07-08 14:10:43 --> User Agent Class Initialized
DEBUG - 2010-07-08 14:10:43 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:10:43 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:10:44 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:10:44 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 14:10:44 --> Session Class Initialized
DEBUG - 2010-07-08 14:10:44 --> Helper loaded: string_helper
DEBUG - 2010-07-08 14:10:44 --> Session routines successfully run
DEBUG - 2010-07-08 14:10:44 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:10:45 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:10:45 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:10:45 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:11:44 --> Config Class Initialized
DEBUG - 2010-07-08 14:11:44 --> Hooks Class Initialized
DEBUG - 2010-07-08 14:11:44 --> URI Class Initialized
DEBUG - 2010-07-08 14:11:44 --> Router Class Initialized
DEBUG - 2010-07-08 14:11:45 --> Output Class Initialized
DEBUG - 2010-07-08 14:11:45 --> Input Class Initialized
DEBUG - 2010-07-08 14:11:45 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 14:11:45 --> Language Class Initialized
DEBUG - 2010-07-08 14:11:45 --> Loader Class Initialized
DEBUG - 2010-07-08 14:11:46 --> Helper loaded: context_helper
DEBUG - 2010-07-08 14:11:46 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 14:11:46 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 14:11:46 --> Database Driver Class Initialized
DEBUG - 2010-07-08 14:11:47 --> Controller Class Initialized
DEBUG - 2010-07-08 14:11:47 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 14:11:47 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 14:11:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:11:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:11:48 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:11:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:11:48 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:11:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:11:48 --> Helper loaded: email_helper
DEBUG - 2010-07-08 14:11:49 --> User Agent Class Initialized
DEBUG - 2010-07-08 14:11:49 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:11:49 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:11:49 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:11:49 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 14:11:50 --> Session Class Initialized
DEBUG - 2010-07-08 14:11:50 --> Helper loaded: string_helper
DEBUG - 2010-07-08 14:11:50 --> Session routines successfully run
DEBUG - 2010-07-08 14:11:50 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:11:50 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:11:51 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:11:51 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:11:51 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-07-08 14:11:51 --> Severity: Notice  --> Undefined property: Annotation_scope_collection::$_members D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Collection.php 80
ERROR - 2010-07-08 14:11:51 --> Severity: Warning  --> array_keys() [<a href='function.array-keys'>function.array-keys</a>]: The first argument should be an array D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Collection.php 80
DEBUG - 2010-07-08 14:11:52 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:11:52 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:11:52 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:11:52 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-08 14:11:52 --> Severity: Notice  --> Undefined property: Annotation_scope_collection::$_members D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Collection.php 80
ERROR - 2010-07-08 14:11:52 --> Severity: Warning  --> array_keys() [<a href='function.array-keys'>function.array-keys</a>]: The first argument should be an array D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Collection.php 80
DEBUG - 2010-07-08 14:11:53 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:11:53 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-08 14:11:53 --> Severity: Notice  --> Undefined property: Annotation_scope_collection::$_members D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Collection.php 80
ERROR - 2010-07-08 14:11:53 --> Severity: Warning  --> array_keys() [<a href='function.array-keys'>function.array-keys</a>]: The first argument should be an array D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Collection.php 80
DEBUG - 2010-07-08 14:11:53 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:11:54 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:11:54 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:11:54 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-08 14:11:54 --> Severity: Notice  --> Undefined property: Annotation_scope_collection::$_members D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Collection.php 80
ERROR - 2010-07-08 14:11:54 --> Severity: Warning  --> array_keys() [<a href='function.array-keys'>function.array-keys</a>]: The first argument should be an array D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Collection.php 80
DEBUG - 2010-07-08 14:11:55 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:11:55 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:11:55 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:11:55 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:11:55 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:11:56 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-08 14:11:56 --> Severity: Notice  --> Undefined property: Annotation_scope_collection::$_members D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Collection.php 80
ERROR - 2010-07-08 14:11:56 --> Severity: Warning  --> array_keys() [<a href='function.array-keys'>function.array-keys</a>]: The first argument should be an array D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Collection.php 80
ERROR - 2010-07-08 14:11:56 --> Severity: Notice  --> Undefined property: Annotation_scope_collection::$_members D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Collection.php 80
ERROR - 2010-07-08 14:11:56 --> Severity: Warning  --> array_keys() [<a href='function.array-keys'>function.array-keys</a>]: The first argument should be an array D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Collection.php 80
DEBUG - 2010-07-08 14:11:57 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 14:11:57 --> Final output sent to browser
DEBUG - 2010-07-08 14:11:57 --> Total execution time: 12.8933
DEBUG - 2010-07-08 14:13:10 --> Config Class Initialized
DEBUG - 2010-07-08 14:13:10 --> Hooks Class Initialized
DEBUG - 2010-07-08 14:13:10 --> URI Class Initialized
DEBUG - 2010-07-08 14:13:11 --> Router Class Initialized
DEBUG - 2010-07-08 14:13:11 --> Output Class Initialized
DEBUG - 2010-07-08 14:13:11 --> Input Class Initialized
DEBUG - 2010-07-08 14:13:11 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 14:13:11 --> Language Class Initialized
DEBUG - 2010-07-08 14:13:11 --> Loader Class Initialized
DEBUG - 2010-07-08 14:13:12 --> Helper loaded: context_helper
DEBUG - 2010-07-08 14:13:12 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 14:13:12 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 14:13:12 --> Database Driver Class Initialized
DEBUG - 2010-07-08 14:13:12 --> Controller Class Initialized
DEBUG - 2010-07-08 14:13:13 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 14:13:13 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 14:13:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:13 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:14 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:14 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:14 --> Helper loaded: email_helper
DEBUG - 2010-07-08 14:13:14 --> User Agent Class Initialized
DEBUG - 2010-07-08 14:13:14 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:15 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:15 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 14:13:15 --> Session Class Initialized
DEBUG - 2010-07-08 14:13:15 --> Helper loaded: string_helper
DEBUG - 2010-07-08 14:13:16 --> Session routines successfully run
DEBUG - 2010-07-08 14:13:16 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:16 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:16 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:16 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:16 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 14:13:17 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:17 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:17 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:17 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:18 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:18 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:18 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:18 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:18 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:19 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:19 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:19 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:19 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:19 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:19 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:20 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:54 --> Config Class Initialized
DEBUG - 2010-07-08 14:13:55 --> Hooks Class Initialized
DEBUG - 2010-07-08 14:13:55 --> URI Class Initialized
DEBUG - 2010-07-08 14:13:55 --> Router Class Initialized
DEBUG - 2010-07-08 14:13:55 --> Output Class Initialized
DEBUG - 2010-07-08 14:13:55 --> Input Class Initialized
DEBUG - 2010-07-08 14:13:56 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 14:13:56 --> Language Class Initialized
DEBUG - 2010-07-08 14:13:56 --> Loader Class Initialized
DEBUG - 2010-07-08 14:13:56 --> Helper loaded: context_helper
DEBUG - 2010-07-08 14:13:56 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 14:13:57 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 14:13:57 --> Database Driver Class Initialized
DEBUG - 2010-07-08 14:13:57 --> Controller Class Initialized
DEBUG - 2010-07-08 14:13:57 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 14:13:57 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 14:13:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:59 --> Helper loaded: email_helper
DEBUG - 2010-07-08 14:13:59 --> User Agent Class Initialized
DEBUG - 2010-07-08 14:13:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:59 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:13:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:14:00 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 14:14:00 --> Session Class Initialized
DEBUG - 2010-07-08 14:14:00 --> Helper loaded: string_helper
DEBUG - 2010-07-08 14:14:00 --> Session routines successfully run
DEBUG - 2010-07-08 14:14:00 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:14:01 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:14:01 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:14:01 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:14:01 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 14:14:01 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:14:01 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:14:02 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:14:02 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:14:02 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:14:02 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:14:02 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:14:03 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:14:03 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:14:03 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:14:03 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:14:03 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:14:03 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:14:04 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:14:04 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:14:04 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:14:04 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 14:14:04 --> Final output sent to browser
DEBUG - 2010-07-08 14:14:05 --> Total execution time: 9.9742
DEBUG - 2010-07-08 14:15:45 --> Config Class Initialized
DEBUG - 2010-07-08 14:15:45 --> Hooks Class Initialized
DEBUG - 2010-07-08 14:15:45 --> URI Class Initialized
DEBUG - 2010-07-08 14:15:45 --> Router Class Initialized
DEBUG - 2010-07-08 14:15:46 --> Output Class Initialized
DEBUG - 2010-07-08 14:15:46 --> Input Class Initialized
DEBUG - 2010-07-08 14:15:46 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 14:15:46 --> Language Class Initialized
DEBUG - 2010-07-08 14:15:46 --> Loader Class Initialized
DEBUG - 2010-07-08 14:15:47 --> Helper loaded: context_helper
DEBUG - 2010-07-08 14:15:47 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 14:15:47 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 14:15:47 --> Database Driver Class Initialized
DEBUG - 2010-07-08 14:15:47 --> Controller Class Initialized
DEBUG - 2010-07-08 14:15:48 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 14:15:48 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 14:15:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:15:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:15:48 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:15:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:15:49 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:15:49 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:15:49 --> Helper loaded: email_helper
DEBUG - 2010-07-08 14:15:49 --> User Agent Class Initialized
DEBUG - 2010-07-08 14:15:49 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:15:50 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:15:50 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:15:50 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 14:15:50 --> Session Class Initialized
DEBUG - 2010-07-08 14:15:50 --> Helper loaded: string_helper
DEBUG - 2010-07-08 14:15:51 --> Session routines successfully run
DEBUG - 2010-07-08 14:15:51 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:15:51 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:15:51 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:15:51 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:15:52 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 14:15:52 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:15:52 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:15:52 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:15:52 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:15:53 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:15:53 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:15:53 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:15:53 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:15:53 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:15:54 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:15:54 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:15:54 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:15:54 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:15:54 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:15:55 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:15:55 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:15:55 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 14:15:55 --> Final output sent to browser
DEBUG - 2010-07-08 14:15:55 --> Total execution time: 10.3852
DEBUG - 2010-07-08 14:17:18 --> Config Class Initialized
DEBUG - 2010-07-08 14:17:18 --> Hooks Class Initialized
DEBUG - 2010-07-08 14:17:18 --> URI Class Initialized
DEBUG - 2010-07-08 14:17:18 --> Router Class Initialized
DEBUG - 2010-07-08 14:17:18 --> Output Class Initialized
DEBUG - 2010-07-08 14:17:19 --> Input Class Initialized
DEBUG - 2010-07-08 14:17:19 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 14:17:19 --> Language Class Initialized
DEBUG - 2010-07-08 14:17:19 --> Loader Class Initialized
DEBUG - 2010-07-08 14:17:19 --> Helper loaded: context_helper
DEBUG - 2010-07-08 14:17:20 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 14:17:20 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 14:17:20 --> Database Driver Class Initialized
DEBUG - 2010-07-08 14:17:20 --> Controller Class Initialized
DEBUG - 2010-07-08 14:17:20 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 14:17:20 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 14:17:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:17:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:17:21 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:17:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:17:21 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:17:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:17:22 --> Helper loaded: email_helper
DEBUG - 2010-07-08 14:17:22 --> User Agent Class Initialized
DEBUG - 2010-07-08 14:17:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:17:22 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:17:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:17:23 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 14:17:23 --> Session Class Initialized
DEBUG - 2010-07-08 14:17:23 --> Helper loaded: string_helper
DEBUG - 2010-07-08 14:17:23 --> Session routines successfully run
DEBUG - 2010-07-08 14:17:24 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:17:24 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:17:24 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:17:24 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:17:24 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 14:17:24 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:17:25 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:17:25 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:17:25 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:17:25 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:17:25 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:17:26 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:17:26 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:17:26 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:17:26 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:17:26 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:17:27 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:17:27 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:17:27 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:17:27 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:17:27 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:17:28 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 14:17:28 --> Final output sent to browser
DEBUG - 2010-07-08 14:17:28 --> Total execution time: 10.2153
DEBUG - 2010-07-08 14:20:02 --> Config Class Initialized
DEBUG - 2010-07-08 14:20:03 --> Hooks Class Initialized
DEBUG - 2010-07-08 14:20:03 --> URI Class Initialized
DEBUG - 2010-07-08 14:20:03 --> Router Class Initialized
DEBUG - 2010-07-08 14:20:03 --> Output Class Initialized
DEBUG - 2010-07-08 14:20:03 --> Input Class Initialized
DEBUG - 2010-07-08 14:20:04 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 14:20:04 --> Language Class Initialized
DEBUG - 2010-07-08 14:20:04 --> Loader Class Initialized
DEBUG - 2010-07-08 14:20:04 --> Helper loaded: context_helper
DEBUG - 2010-07-08 14:20:04 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 14:20:05 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 14:20:05 --> Database Driver Class Initialized
DEBUG - 2010-07-08 14:20:05 --> Controller Class Initialized
DEBUG - 2010-07-08 14:20:05 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 14:20:05 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 14:20:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:06 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:06 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:07 --> Helper loaded: email_helper
DEBUG - 2010-07-08 14:20:07 --> User Agent Class Initialized
DEBUG - 2010-07-08 14:20:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:07 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:08 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 14:20:08 --> Session Class Initialized
DEBUG - 2010-07-08 14:20:08 --> Helper loaded: string_helper
DEBUG - 2010-07-08 14:20:08 --> Session routines successfully run
DEBUG - 2010-07-08 14:20:09 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:09 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:09 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:09 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:09 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 14:20:10 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:10 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:10 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:10 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:10 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:10 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:11 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:11 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:11 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:11 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:11 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:12 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:12 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:12 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:12 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:12 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:13 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 14:20:13 --> Final output sent to browser
DEBUG - 2010-07-08 14:20:13 --> Total execution time: 10.3776
DEBUG - 2010-07-08 14:20:39 --> Config Class Initialized
DEBUG - 2010-07-08 14:20:39 --> Hooks Class Initialized
DEBUG - 2010-07-08 14:20:40 --> URI Class Initialized
DEBUG - 2010-07-08 14:20:40 --> Router Class Initialized
DEBUG - 2010-07-08 14:20:40 --> Output Class Initialized
DEBUG - 2010-07-08 14:20:40 --> Input Class Initialized
DEBUG - 2010-07-08 14:20:40 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 14:20:41 --> Language Class Initialized
DEBUG - 2010-07-08 14:20:41 --> Loader Class Initialized
DEBUG - 2010-07-08 14:20:41 --> Helper loaded: context_helper
DEBUG - 2010-07-08 14:20:41 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 14:20:41 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 14:20:42 --> Database Driver Class Initialized
DEBUG - 2010-07-08 14:20:42 --> Controller Class Initialized
DEBUG - 2010-07-08 14:20:42 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 14:20:42 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 14:20:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:43 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:43 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:43 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:43 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:43 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:44 --> Helper loaded: email_helper
DEBUG - 2010-07-08 14:20:44 --> User Agent Class Initialized
DEBUG - 2010-07-08 14:20:44 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:44 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:44 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:45 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 14:20:45 --> Session Class Initialized
DEBUG - 2010-07-08 14:20:45 --> Helper loaded: string_helper
DEBUG - 2010-07-08 14:20:45 --> Session routines successfully run
DEBUG - 2010-07-08 14:20:45 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:46 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:46 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:46 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 14:20:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:47 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:47 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:47 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:47 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:47 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:48 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:48 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:48 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:48 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:48 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:49 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:49 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:49 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:49 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:49 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:20:50 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 14:20:50 --> Final output sent to browser
DEBUG - 2010-07-08 14:20:50 --> Total execution time: 10.4649
DEBUG - 2010-07-08 14:21:01 --> Config Class Initialized
DEBUG - 2010-07-08 14:21:02 --> Hooks Class Initialized
DEBUG - 2010-07-08 14:21:02 --> URI Class Initialized
DEBUG - 2010-07-08 14:21:02 --> Router Class Initialized
DEBUG - 2010-07-08 14:21:02 --> Output Class Initialized
DEBUG - 2010-07-08 14:21:02 --> Input Class Initialized
DEBUG - 2010-07-08 14:21:03 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 14:21:03 --> Language Class Initialized
DEBUG - 2010-07-08 14:21:03 --> Config Class Initialized
DEBUG - 2010-07-08 14:21:03 --> Loader Class Initialized
DEBUG - 2010-07-08 14:21:03 --> Hooks Class Initialized
DEBUG - 2010-07-08 14:21:03 --> Helper loaded: context_helper
DEBUG - 2010-07-08 14:21:03 --> URI Class Initialized
DEBUG - 2010-07-08 14:21:03 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 14:21:03 --> Router Class Initialized
DEBUG - 2010-07-08 14:21:04 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 14:21:04 --> Output Class Initialized
DEBUG - 2010-07-08 14:21:04 --> Database Driver Class Initialized
DEBUG - 2010-07-08 14:21:04 --> Input Class Initialized
DEBUG - 2010-07-08 14:21:04 --> Controller Class Initialized
DEBUG - 2010-07-08 14:21:04 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 14:21:04 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 14:21:04 --> Language Class Initialized
DEBUG - 2010-07-08 14:21:04 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 14:21:04 --> Loader Class Initialized
DEBUG - 2010-07-08 14:21:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:05 --> Helper loaded: context_helper
DEBUG - 2010-07-08 14:21:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:05 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 14:21:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:05 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 14:21:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:05 --> Database Driver Class Initialized
DEBUG - 2010-07-08 14:21:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:05 --> Controller Class Initialized
DEBUG - 2010-07-08 14:21:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:06 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 14:21:06 --> Helper loaded: email_helper
DEBUG - 2010-07-08 14:21:06 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 14:21:06 --> User Agent Class Initialized
DEBUG - 2010-07-08 14:21:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:06 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:07 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 14:21:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:07 --> Session Class Initialized
DEBUG - 2010-07-08 14:21:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:07 --> Helper loaded: string_helper
DEBUG - 2010-07-08 14:21:07 --> Helper loaded: email_helper
DEBUG - 2010-07-08 14:21:07 --> Session routines successfully run
DEBUG - 2010-07-08 14:21:08 --> User Agent Class Initialized
DEBUG - 2010-07-08 14:21:08 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:08 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:08 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:08 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:08 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:08 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 14:21:09 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 14:21:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:09 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:09 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:09 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:09 --> Session Class Initialized
DEBUG - 2010-07-08 14:21:09 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:09 --> Helper loaded: string_helper
DEBUG - 2010-07-08 14:21:09 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:10 --> Session routines successfully run
DEBUG - 2010-07-08 14:21:10 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:10 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:10 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:10 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:10 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:10 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:11 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:11 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:11 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:11 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:11 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:11 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:11 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:11 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:11 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:11 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:12 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:12 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:12 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:12 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:12 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:12 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:21:12 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 14:21:12 --> Final output sent to browser
DEBUG - 2010-07-08 14:21:13 --> Total execution time: 10.9423
DEBUG - 2010-07-08 14:21:58 --> Config Class Initialized
DEBUG - 2010-07-08 14:21:58 --> Hooks Class Initialized
DEBUG - 2010-07-08 14:21:58 --> URI Class Initialized
DEBUG - 2010-07-08 14:21:58 --> Router Class Initialized
DEBUG - 2010-07-08 14:21:58 --> Output Class Initialized
DEBUG - 2010-07-08 14:21:59 --> Input Class Initialized
DEBUG - 2010-07-08 14:21:59 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 14:21:59 --> Language Class Initialized
DEBUG - 2010-07-08 14:21:59 --> Loader Class Initialized
DEBUG - 2010-07-08 14:21:59 --> Helper loaded: context_helper
DEBUG - 2010-07-08 14:22:00 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 14:22:00 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 14:22:00 --> Database Driver Class Initialized
DEBUG - 2010-07-08 14:22:00 --> Controller Class Initialized
DEBUG - 2010-07-08 14:22:00 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 14:22:01 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 14:22:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:01 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:02 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:02 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:02 --> Helper loaded: email_helper
DEBUG - 2010-07-08 14:22:02 --> User Agent Class Initialized
DEBUG - 2010-07-08 14:22:02 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:03 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:03 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 14:22:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:03 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:04 --> Session Class Initialized
DEBUG - 2010-07-08 14:22:04 --> Helper loaded: string_helper
DEBUG - 2010-07-08 14:22:04 --> Session routines successfully run
DEBUG - 2010-07-08 14:22:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:05 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:05 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:05 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:06 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:06 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:06 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:06 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:06 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:07 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:07 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:08 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:08 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-08 14:22:08 --> Severity: Notice  --> Undefined property: Annotation_scope_collection::$_modified D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_association_collection.php 111
DEBUG - 2010-07-08 14:22:08 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 14:22:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:09 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:09 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:09 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:09 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-08 14:22:09 --> Severity: Notice  --> Undefined property: Annotation_scope_collection::$_modified D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_association_collection.php 111
DEBUG - 2010-07-08 14:22:10 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:10 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:10 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:10 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:11 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:11 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-08 14:22:11 --> Severity: Notice  --> Undefined property: Annotation_scope_collection::$_modified D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_association_collection.php 111
DEBUG - 2010-07-08 14:22:11 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:22:11 --> Segmentor_CKIP class already loaded. Second attempt ignored.
ERROR - 2010-07-08 14:22:12 --> Severity: Notice  --> Undefined property: Annotation_scope_collection::$_modified D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_association_collection.php 111
DEBUG - 2010-07-08 14:22:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:37 --> Config Class Initialized
DEBUG - 2010-07-08 14:23:38 --> Hooks Class Initialized
DEBUG - 2010-07-08 14:23:38 --> URI Class Initialized
DEBUG - 2010-07-08 14:23:38 --> Router Class Initialized
DEBUG - 2010-07-08 14:23:38 --> Output Class Initialized
DEBUG - 2010-07-08 14:23:38 --> Input Class Initialized
DEBUG - 2010-07-08 14:23:39 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 14:23:39 --> Language Class Initialized
DEBUG - 2010-07-08 14:23:39 --> Loader Class Initialized
DEBUG - 2010-07-08 14:23:39 --> Helper loaded: context_helper
DEBUG - 2010-07-08 14:23:39 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 14:23:40 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 14:23:40 --> Database Driver Class Initialized
DEBUG - 2010-07-08 14:23:40 --> Controller Class Initialized
DEBUG - 2010-07-08 14:23:40 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 14:23:40 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 14:23:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:41 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:41 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:42 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:42 --> Helper loaded: email_helper
DEBUG - 2010-07-08 14:23:42 --> User Agent Class Initialized
DEBUG - 2010-07-08 14:23:42 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:42 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:43 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:43 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 14:23:43 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:43 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:43 --> Session Class Initialized
DEBUG - 2010-07-08 14:23:44 --> Helper loaded: string_helper
DEBUG - 2010-07-08 14:23:44 --> Session routines successfully run
DEBUG - 2010-07-08 14:23:44 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:44 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:45 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:45 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:45 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:45 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:45 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:46 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:46 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:46 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:46 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:47 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:47 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:47 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:47 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-08 14:23:48 --> Severity: Notice  --> Undefined property: Annotation_scope_collection::$_modified D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_association_collection.php 111
DEBUG - 2010-07-08 14:23:48 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 14:23:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:48 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:49 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:49 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-08 14:23:49 --> Severity: Notice  --> Undefined property: Annotation_scope_collection::$_modified D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_association_collection.php 111
DEBUG - 2010-07-08 14:23:49 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:49 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:50 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:50 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:50 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:50 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-08 14:23:51 --> Severity: Notice  --> Undefined property: Annotation_scope_collection::$_modified D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_association_collection.php 111
DEBUG - 2010-07-08 14:23:51 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:23:51 --> Segmentor_CKIP class already loaded. Second attempt ignored.
ERROR - 2010-07-08 14:23:51 --> Severity: Notice  --> Undefined property: Annotation_scope_collection::$_modified D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_association_collection.php 111
DEBUG - 2010-07-08 14:23:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:26:15 --> Config Class Initialized
DEBUG - 2010-07-08 14:26:15 --> Hooks Class Initialized
DEBUG - 2010-07-08 14:26:15 --> URI Class Initialized
DEBUG - 2010-07-08 14:26:15 --> Router Class Initialized
DEBUG - 2010-07-08 14:26:16 --> Output Class Initialized
DEBUG - 2010-07-08 14:26:16 --> Input Class Initialized
DEBUG - 2010-07-08 14:26:16 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 14:26:16 --> Language Class Initialized
DEBUG - 2010-07-08 14:26:16 --> Loader Class Initialized
DEBUG - 2010-07-08 14:26:17 --> Helper loaded: context_helper
DEBUG - 2010-07-08 14:26:17 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 14:26:17 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 14:26:17 --> Database Driver Class Initialized
DEBUG - 2010-07-08 14:26:17 --> Controller Class Initialized
DEBUG - 2010-07-08 14:26:18 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 14:26:18 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 14:26:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:26:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:26:18 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:26:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:26:19 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:26:19 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:26:19 --> Helper loaded: email_helper
DEBUG - 2010-07-08 14:26:20 --> User Agent Class Initialized
DEBUG - 2010-07-08 14:26:20 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:26:20 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:26:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:26:20 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 14:26:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:26:21 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:26:21 --> Session Class Initialized
DEBUG - 2010-07-08 14:26:21 --> Helper loaded: string_helper
DEBUG - 2010-07-08 14:26:21 --> Session routines successfully run
DEBUG - 2010-07-08 14:26:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:26:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:26:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:26:22 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:26:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:26:23 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:26:23 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:26:23 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:26:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:26:24 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:26:24 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:26:24 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:26:24 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:26:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:26:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:26:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:26:25 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:26:25 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-08 14:26:26 --> Severity: Notice  --> Undefined variable: new_id_list D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_association_collection.php 125
ERROR - 2010-07-08 14:26:26 --> Severity: Warning  --> array_unique() [<a href='function.array-unique'>function.array-unique</a>]: The argument should be an array D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_association_collection.php 125
ERROR - 2010-07-08 14:26:26 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;foreign_key&quot; does not exist
LINE 1: SELECT DISTINCT &quot;foreign_key&quot;
                        ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-08 14:26:26 --> DB Transaction Failure
ERROR - 2010-07-08 14:26:26 --> Query error: ERROR:  column "foreign_key" does not exist
LINE 1: SELECT DISTINCT "foreign_key"
                        ^
DEBUG - 2010-07-08 14:26:27 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-08 14:26:27 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-08 14:27:58 --> Config Class Initialized
DEBUG - 2010-07-08 14:27:58 --> Hooks Class Initialized
DEBUG - 2010-07-08 14:27:58 --> URI Class Initialized
DEBUG - 2010-07-08 14:27:59 --> Router Class Initialized
DEBUG - 2010-07-08 14:27:59 --> Output Class Initialized
DEBUG - 2010-07-08 14:27:59 --> Input Class Initialized
DEBUG - 2010-07-08 14:27:59 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 14:27:59 --> Language Class Initialized
DEBUG - 2010-07-08 14:28:00 --> Loader Class Initialized
DEBUG - 2010-07-08 14:28:00 --> Helper loaded: context_helper
DEBUG - 2010-07-08 14:28:00 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 14:28:00 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 14:28:00 --> Database Driver Class Initialized
DEBUG - 2010-07-08 14:28:01 --> Controller Class Initialized
DEBUG - 2010-07-08 14:28:01 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 14:28:01 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 14:28:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:02 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:02 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:02 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:02 --> Helper loaded: email_helper
DEBUG - 2010-07-08 14:28:03 --> User Agent Class Initialized
DEBUG - 2010-07-08 14:28:03 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:03 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:04 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 14:28:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:04 --> Session Class Initialized
DEBUG - 2010-07-08 14:28:04 --> Helper loaded: string_helper
DEBUG - 2010-07-08 14:28:05 --> Session routines successfully run
DEBUG - 2010-07-08 14:28:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:06 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:06 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:06 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:06 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:06 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:07 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:07 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:07 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:07 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:07 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:08 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:09 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 14:28:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:09 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:09 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:09 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:10 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:10 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:10 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:11 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:11 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:11 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:12 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:12 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:12 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:12 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:13 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:13 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:13 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:13 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:14 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:14 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:14 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:14 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:15 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:15 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-08 14:28:15 --> Severity: Notice  --> Undefined property: Annotation_scope_collection::$annotation_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Annotation_scope_collection.php 53
DEBUG - 2010-07-08 14:28:42 --> Config Class Initialized
DEBUG - 2010-07-08 14:28:42 --> Hooks Class Initialized
DEBUG - 2010-07-08 14:28:43 --> URI Class Initialized
DEBUG - 2010-07-08 14:28:43 --> Router Class Initialized
DEBUG - 2010-07-08 14:28:43 --> Output Class Initialized
DEBUG - 2010-07-08 14:28:43 --> Input Class Initialized
DEBUG - 2010-07-08 14:28:43 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 14:28:44 --> Language Class Initialized
DEBUG - 2010-07-08 14:28:44 --> Loader Class Initialized
DEBUG - 2010-07-08 14:28:44 --> Helper loaded: context_helper
DEBUG - 2010-07-08 14:28:44 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 14:28:44 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 14:28:45 --> Database Driver Class Initialized
DEBUG - 2010-07-08 14:28:45 --> Controller Class Initialized
DEBUG - 2010-07-08 14:28:45 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 14:28:45 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 14:28:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:46 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:46 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:47 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:47 --> Helper loaded: email_helper
DEBUG - 2010-07-08 14:28:47 --> User Agent Class Initialized
DEBUG - 2010-07-08 14:28:47 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:47 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:48 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:48 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 14:28:48 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:48 --> Session Class Initialized
DEBUG - 2010-07-08 14:28:49 --> Helper loaded: string_helper
DEBUG - 2010-07-08 14:28:49 --> Session routines successfully run
DEBUG - 2010-07-08 14:28:49 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:49 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:50 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:50 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:50 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:50 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:50 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:51 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:51 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:51 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:51 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:51 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:52 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:52 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:52 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:53 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 14:28:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:53 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:53 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:54 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:54 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:54 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:54 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:55 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:55 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:55 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:56 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:56 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:56 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:57 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:57 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:57 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:57 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:57 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:58 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:58 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:59 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:28:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:29:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:29:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:29:00 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 14:29:00 --> Final output sent to browser
DEBUG - 2010-07-08 14:29:00 --> Total execution time: 17.9588
DEBUG - 2010-07-08 14:33:27 --> Config Class Initialized
DEBUG - 2010-07-08 14:33:27 --> Hooks Class Initialized
DEBUG - 2010-07-08 14:33:27 --> URI Class Initialized
DEBUG - 2010-07-08 14:33:28 --> Router Class Initialized
DEBUG - 2010-07-08 14:33:28 --> Output Class Initialized
DEBUG - 2010-07-08 14:33:28 --> Input Class Initialized
DEBUG - 2010-07-08 14:33:28 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 14:33:28 --> Language Class Initialized
DEBUG - 2010-07-08 14:33:29 --> Loader Class Initialized
DEBUG - 2010-07-08 14:33:29 --> Helper loaded: context_helper
DEBUG - 2010-07-08 14:33:29 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 14:33:29 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 14:33:30 --> Database Driver Class Initialized
DEBUG - 2010-07-08 14:33:30 --> Controller Class Initialized
DEBUG - 2010-07-08 14:33:30 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 14:33:30 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 14:33:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:32 --> Helper loaded: email_helper
DEBUG - 2010-07-08 14:33:32 --> User Agent Class Initialized
DEBUG - 2010-07-08 14:33:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:32 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:33 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 14:33:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:33 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:33 --> Session Class Initialized
DEBUG - 2010-07-08 14:33:34 --> Helper loaded: string_helper
DEBUG - 2010-07-08 14:33:34 --> Session routines successfully run
DEBUG - 2010-07-08 14:33:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:35 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:35 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:35 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:35 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:35 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:36 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:36 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:37 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:37 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:38 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 14:33:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:38 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:38 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:39 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:39 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:39 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:40 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:40 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:40 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:40 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:41 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:41 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:41 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:42 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:42 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:42 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:42 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:43 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:43 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:43 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:43 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:44 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:44 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:44 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:44 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:45 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:45 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:33:45 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 14:33:45 --> Final output sent to browser
DEBUG - 2010-07-08 14:33:46 --> Total execution time: 18.3501
DEBUG - 2010-07-08 14:35:21 --> Config Class Initialized
DEBUG - 2010-07-08 14:35:21 --> Hooks Class Initialized
DEBUG - 2010-07-08 14:35:21 --> URI Class Initialized
DEBUG - 2010-07-08 14:35:21 --> Router Class Initialized
DEBUG - 2010-07-08 14:35:22 --> Output Class Initialized
DEBUG - 2010-07-08 14:35:22 --> Input Class Initialized
DEBUG - 2010-07-08 14:35:22 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 14:35:22 --> Language Class Initialized
DEBUG - 2010-07-08 14:35:22 --> Loader Class Initialized
DEBUG - 2010-07-08 14:35:23 --> Helper loaded: context_helper
DEBUG - 2010-07-08 14:35:23 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 14:35:23 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 14:35:23 --> Database Driver Class Initialized
DEBUG - 2010-07-08 14:35:24 --> Controller Class Initialized
DEBUG - 2010-07-08 14:35:24 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 14:35:24 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 14:35:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:26 --> Helper loaded: email_helper
DEBUG - 2010-07-08 14:35:26 --> User Agent Class Initialized
DEBUG - 2010-07-08 14:35:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:26 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:27 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 14:35:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:27 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:27 --> Session Class Initialized
DEBUG - 2010-07-08 14:35:28 --> Helper loaded: string_helper
DEBUG - 2010-07-08 14:35:28 --> Session routines successfully run
DEBUG - 2010-07-08 14:35:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:29 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:29 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:29 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:29 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:30 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:30 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:30 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:30 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:31 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:31 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:32 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:32 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 14:35:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:33 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:33 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:33 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:33 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:34 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:34 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:34 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:35 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:35 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:35 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:37 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:37 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:37 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:38 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:38 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:38 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:38 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:35:40 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 14:35:40 --> Final output sent to browser
DEBUG - 2010-07-08 14:35:40 --> Total execution time: 19.0800
DEBUG - 2010-07-08 14:36:23 --> Config Class Initialized
DEBUG - 2010-07-08 14:36:23 --> Hooks Class Initialized
DEBUG - 2010-07-08 14:36:23 --> URI Class Initialized
DEBUG - 2010-07-08 14:36:23 --> Router Class Initialized
DEBUG - 2010-07-08 14:36:24 --> Output Class Initialized
DEBUG - 2010-07-08 14:36:24 --> Input Class Initialized
DEBUG - 2010-07-08 14:36:24 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 14:36:24 --> Language Class Initialized
DEBUG - 2010-07-08 14:36:25 --> Loader Class Initialized
DEBUG - 2010-07-08 14:36:25 --> Helper loaded: context_helper
DEBUG - 2010-07-08 14:36:25 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 14:36:25 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 14:36:25 --> Database Driver Class Initialized
DEBUG - 2010-07-08 14:36:26 --> Controller Class Initialized
DEBUG - 2010-07-08 14:36:26 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 14:36:26 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 14:36:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:27 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:27 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:28 --> Helper loaded: email_helper
DEBUG - 2010-07-08 14:36:28 --> User Agent Class Initialized
DEBUG - 2010-07-08 14:36:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:28 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:29 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 14:36:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:29 --> Session Class Initialized
DEBUG - 2010-07-08 14:36:30 --> Helper loaded: string_helper
DEBUG - 2010-07-08 14:36:30 --> Session routines successfully run
DEBUG - 2010-07-08 14:36:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:31 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:31 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:31 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:31 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:32 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:32 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:32 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:32 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:32 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:33 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:33 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:33 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:33 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:34 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 14:36:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:34 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:35 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:35 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:37 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:37 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:37 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:38 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:38 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:39 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:39 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:40 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:40 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:40 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:41 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:41 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:41 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:41 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:42 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:42 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:43 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:43 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:43 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:36:43 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 14:36:43 --> Final output sent to browser
DEBUG - 2010-07-08 14:36:44 --> Total execution time: 20.5252
DEBUG - 2010-07-08 14:37:21 --> Config Class Initialized
DEBUG - 2010-07-08 14:37:22 --> Hooks Class Initialized
DEBUG - 2010-07-08 14:37:22 --> URI Class Initialized
DEBUG - 2010-07-08 14:37:22 --> Router Class Initialized
DEBUG - 2010-07-08 14:37:22 --> Output Class Initialized
DEBUG - 2010-07-08 14:37:23 --> Input Class Initialized
DEBUG - 2010-07-08 14:37:23 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 14:37:23 --> Language Class Initialized
DEBUG - 2010-07-08 14:37:23 --> Loader Class Initialized
DEBUG - 2010-07-08 14:37:23 --> Helper loaded: context_helper
DEBUG - 2010-07-08 14:37:24 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 14:37:24 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 14:37:24 --> Database Driver Class Initialized
DEBUG - 2010-07-08 14:37:24 --> Controller Class Initialized
DEBUG - 2010-07-08 14:37:25 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 14:37:25 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 14:37:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:26 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:26 --> Helper loaded: email_helper
DEBUG - 2010-07-08 14:37:27 --> User Agent Class Initialized
DEBUG - 2010-07-08 14:37:27 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:27 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:27 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 14:37:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:28 --> Session Class Initialized
DEBUG - 2010-07-08 14:37:28 --> Helper loaded: string_helper
DEBUG - 2010-07-08 14:37:29 --> Session routines successfully run
DEBUG - 2010-07-08 14:37:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:30 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:30 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:30 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:30 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:30 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:31 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:31 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:31 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:31 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:32 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:33 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:33 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 14:37:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:34 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:34 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:34 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:35 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:35 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:35 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:35 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:37 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:37 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:37 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:37 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:38 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:38 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:38 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:38 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:39 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:39 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:37:41 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 14:37:41 --> Final output sent to browser
DEBUG - 2010-07-08 14:37:41 --> Total execution time: 19.3944
DEBUG - 2010-07-08 14:39:13 --> Config Class Initialized
DEBUG - 2010-07-08 14:39:13 --> Hooks Class Initialized
DEBUG - 2010-07-08 14:39:13 --> URI Class Initialized
DEBUG - 2010-07-08 14:39:13 --> Router Class Initialized
DEBUG - 2010-07-08 14:39:14 --> Output Class Initialized
DEBUG - 2010-07-08 14:39:14 --> Input Class Initialized
DEBUG - 2010-07-08 14:39:14 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 14:39:14 --> Language Class Initialized
DEBUG - 2010-07-08 14:39:14 --> Loader Class Initialized
DEBUG - 2010-07-08 14:39:15 --> Helper loaded: context_helper
DEBUG - 2010-07-08 14:39:15 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 14:39:15 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 14:39:15 --> Database Driver Class Initialized
DEBUG - 2010-07-08 14:39:16 --> Controller Class Initialized
DEBUG - 2010-07-08 14:39:16 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 14:39:16 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 14:39:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:17 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:17 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:18 --> Helper loaded: email_helper
DEBUG - 2010-07-08 14:39:18 --> User Agent Class Initialized
DEBUG - 2010-07-08 14:39:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:18 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:19 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 14:39:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:19 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:19 --> Session Class Initialized
DEBUG - 2010-07-08 14:39:20 --> Helper loaded: string_helper
DEBUG - 2010-07-08 14:39:20 --> Session routines successfully run
DEBUG - 2010-07-08 14:39:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:21 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:21 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:21 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:21 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:22 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:22 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:22 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:22 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:22 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:23 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:23 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:23 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:23 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:24 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 14:39:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:24 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:25 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:25 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:25 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:26 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:26 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:26 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:27 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:27 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:27 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:28 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:28 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:28 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:28 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:29 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:29 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:29 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:30 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:30 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:30 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:39:31 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 14:39:32 --> Final output sent to browser
DEBUG - 2010-07-08 14:39:32 --> Total execution time: 19.0332
DEBUG - 2010-07-08 14:41:32 --> Config Class Initialized
DEBUG - 2010-07-08 14:41:32 --> Hooks Class Initialized
DEBUG - 2010-07-08 14:41:32 --> URI Class Initialized
DEBUG - 2010-07-08 14:41:32 --> Router Class Initialized
DEBUG - 2010-07-08 14:41:33 --> Output Class Initialized
DEBUG - 2010-07-08 14:41:33 --> Input Class Initialized
DEBUG - 2010-07-08 14:41:33 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 14:41:33 --> Language Class Initialized
DEBUG - 2010-07-08 14:41:34 --> Loader Class Initialized
DEBUG - 2010-07-08 14:41:34 --> Helper loaded: context_helper
DEBUG - 2010-07-08 14:41:34 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 14:41:34 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 14:41:34 --> Database Driver Class Initialized
DEBUG - 2010-07-08 14:41:35 --> Controller Class Initialized
DEBUG - 2010-07-08 14:41:35 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 14:41:35 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 14:41:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:36 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:37 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:37 --> Helper loaded: email_helper
DEBUG - 2010-07-08 14:41:37 --> User Agent Class Initialized
DEBUG - 2010-07-08 14:41:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:38 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:38 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 14:41:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:39 --> Session Class Initialized
DEBUG - 2010-07-08 14:41:39 --> Helper loaded: string_helper
DEBUG - 2010-07-08 14:41:39 --> Session routines successfully run
DEBUG - 2010-07-08 14:41:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:40 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:40 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:41 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:41 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:41 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:41 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:41 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:42 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:42 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:42 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:43 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:43 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:43 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:43 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:43 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 14:41:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:44 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:44 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:44 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:45 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:45 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:45 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:45 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:45 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:46 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:46 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:46 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:46 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:47 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-08 14:41:47 --> Severity: Warning  --> call_user_func(load_primary) [<a href='function.call-user-func'>function.call-user-func</a>]: First argument is expected to be a valid callback D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_association_collection.php 62
DEBUG - 2010-07-08 14:41:47 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:47 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:48 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:48 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:48 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:48 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:48 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:49 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:49 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:49 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:49 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:50 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:50 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:50 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:41:51 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 14:41:51 --> Final output sent to browser
DEBUG - 2010-07-08 14:41:52 --> Total execution time: 19.5582
DEBUG - 2010-07-08 14:44:02 --> Config Class Initialized
DEBUG - 2010-07-08 14:44:02 --> Hooks Class Initialized
DEBUG - 2010-07-08 14:44:03 --> URI Class Initialized
DEBUG - 2010-07-08 14:44:03 --> Router Class Initialized
DEBUG - 2010-07-08 14:44:03 --> Output Class Initialized
DEBUG - 2010-07-08 14:44:03 --> Input Class Initialized
DEBUG - 2010-07-08 14:44:03 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 14:44:04 --> Language Class Initialized
DEBUG - 2010-07-08 14:44:04 --> Loader Class Initialized
DEBUG - 2010-07-08 14:44:04 --> Helper loaded: context_helper
DEBUG - 2010-07-08 14:44:04 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 14:44:05 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 14:44:05 --> Database Driver Class Initialized
DEBUG - 2010-07-08 14:44:05 --> Controller Class Initialized
DEBUG - 2010-07-08 14:44:05 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 14:44:06 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 14:44:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:06 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:07 --> Helper loaded: email_helper
DEBUG - 2010-07-08 14:44:08 --> User Agent Class Initialized
DEBUG - 2010-07-08 14:44:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:08 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:08 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 14:44:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:09 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:09 --> Session Class Initialized
DEBUG - 2010-07-08 14:44:09 --> Helper loaded: string_helper
DEBUG - 2010-07-08 14:44:10 --> Session routines successfully run
DEBUG - 2010-07-08 14:44:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:10 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:11 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:11 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:11 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:11 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:12 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:12 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:12 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:12 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:12 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:13 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:13 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:13 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:14 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 14:44:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:14 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:15 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:15 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:15 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:16 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:16 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:16 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:17 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:17 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:17 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-08 14:44:17 --> Severity: Notice  --> Undefined property: Annotation_scope_collection::$primary_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_association_collection.php 77
DEBUG - 2010-07-08 14:44:18 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:18 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:18 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:18 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:19 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:19 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:19 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:20 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:20 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:20 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:20 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:20 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:44:22 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 14:44:22 --> Final output sent to browser
DEBUG - 2010-07-08 14:44:22 --> Total execution time: 19.9122
DEBUG - 2010-07-08 14:45:55 --> Config Class Initialized
DEBUG - 2010-07-08 14:45:55 --> Hooks Class Initialized
DEBUG - 2010-07-08 14:45:55 --> URI Class Initialized
DEBUG - 2010-07-08 14:45:56 --> Router Class Initialized
DEBUG - 2010-07-08 14:45:56 --> Output Class Initialized
DEBUG - 2010-07-08 14:45:56 --> Input Class Initialized
DEBUG - 2010-07-08 14:45:56 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 14:45:57 --> Language Class Initialized
DEBUG - 2010-07-08 14:45:57 --> Loader Class Initialized
DEBUG - 2010-07-08 14:45:57 --> Helper loaded: context_helper
DEBUG - 2010-07-08 14:45:57 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 14:45:58 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 14:45:58 --> Database Driver Class Initialized
DEBUG - 2010-07-08 14:45:58 --> Controller Class Initialized
DEBUG - 2010-07-08 14:45:58 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 14:45:58 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 14:45:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:45:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:45:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:45:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:00 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:00 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:00 --> Helper loaded: email_helper
DEBUG - 2010-07-08 14:46:00 --> User Agent Class Initialized
DEBUG - 2010-07-08 14:46:00 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:01 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:01 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 14:46:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:02 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:02 --> Session Class Initialized
DEBUG - 2010-07-08 14:46:02 --> Helper loaded: string_helper
DEBUG - 2010-07-08 14:46:02 --> Session routines successfully run
DEBUG - 2010-07-08 14:46:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:03 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:03 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:04 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:04 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:04 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:04 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:05 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:05 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:05 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:05 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:06 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:06 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:07 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 14:46:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:08 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:08 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:08 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:09 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:09 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:09 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:10 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:10 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-08 14:46:10 --> Severity: Notice  --> Undefined property: Annotation_scope_collection::$primary_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_association_collection.php 79
DEBUG - 2010-07-08 14:46:10 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:10 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:11 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:11 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:11 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:11 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:12 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:12 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:12 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:13 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:13 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:13 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:13 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:15 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 14:46:15 --> Final output sent to browser
DEBUG - 2010-07-08 14:46:15 --> Total execution time: 19.7713
DEBUG - 2010-07-08 14:46:45 --> Config Class Initialized
DEBUG - 2010-07-08 14:46:45 --> Hooks Class Initialized
DEBUG - 2010-07-08 14:46:45 --> URI Class Initialized
DEBUG - 2010-07-08 14:46:45 --> Router Class Initialized
DEBUG - 2010-07-08 14:46:45 --> Output Class Initialized
DEBUG - 2010-07-08 14:46:46 --> Input Class Initialized
DEBUG - 2010-07-08 14:46:46 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 14:46:46 --> Language Class Initialized
DEBUG - 2010-07-08 14:46:46 --> Loader Class Initialized
DEBUG - 2010-07-08 14:46:47 --> Helper loaded: context_helper
DEBUG - 2010-07-08 14:46:47 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 14:46:47 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 14:46:47 --> Database Driver Class Initialized
DEBUG - 2010-07-08 14:46:47 --> Controller Class Initialized
DEBUG - 2010-07-08 14:46:48 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 14:46:48 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 14:46:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:49 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:49 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:49 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:50 --> Helper loaded: email_helper
DEBUG - 2010-07-08 14:46:50 --> User Agent Class Initialized
DEBUG - 2010-07-08 14:46:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:50 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:51 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 14:46:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:52 --> Session Class Initialized
DEBUG - 2010-07-08 14:46:52 --> Helper loaded: string_helper
DEBUG - 2010-07-08 14:46:52 --> Session routines successfully run
DEBUG - 2010-07-08 14:46:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:53 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:53 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:54 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:54 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:54 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:54 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:55 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:55 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:55 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:55 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:56 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:57 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 14:46:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:58 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:58 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:58 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:59 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:59 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:59 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:46:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:47:00 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:47:00 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:47:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:47:00 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:47:01 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:47:01 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:47:01 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:47:01 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:47:02 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:47:02 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:47:02 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:47:02 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:47:03 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:47:03 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:47:03 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:47:03 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:47:04 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:47:04 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:47:04 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:47:05 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:47:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:47:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:47:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:47:06 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:47:06 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:47:06 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:47:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:47:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:47:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:47:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:47:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:47:08 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 14:47:08 --> Final output sent to browser
DEBUG - 2010-07-08 14:47:08 --> Total execution time: 23.2800
DEBUG - 2010-07-08 14:48:01 --> Config Class Initialized
DEBUG - 2010-07-08 14:48:01 --> Hooks Class Initialized
DEBUG - 2010-07-08 14:48:01 --> URI Class Initialized
DEBUG - 2010-07-08 14:48:01 --> Router Class Initialized
DEBUG - 2010-07-08 14:48:02 --> Output Class Initialized
DEBUG - 2010-07-08 14:48:02 --> Input Class Initialized
DEBUG - 2010-07-08 14:48:02 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 14:48:02 --> Language Class Initialized
DEBUG - 2010-07-08 14:48:03 --> Loader Class Initialized
DEBUG - 2010-07-08 14:48:03 --> Helper loaded: context_helper
DEBUG - 2010-07-08 14:48:03 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 14:48:03 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 14:48:03 --> Database Driver Class Initialized
DEBUG - 2010-07-08 14:48:04 --> Controller Class Initialized
DEBUG - 2010-07-08 14:48:04 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 14:48:04 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 14:48:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:06 --> Helper loaded: email_helper
DEBUG - 2010-07-08 14:48:06 --> User Agent Class Initialized
DEBUG - 2010-07-08 14:48:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:06 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:07 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 14:48:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:08 --> Session Class Initialized
DEBUG - 2010-07-08 14:48:08 --> Helper loaded: string_helper
DEBUG - 2010-07-08 14:48:08 --> Session routines successfully run
DEBUG - 2010-07-08 14:48:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:09 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:09 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:09 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:10 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:10 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:10 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:10 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:11 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:11 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:11 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:12 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:12 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:12 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:12 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 14:48:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:13 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:13 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:13 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:14 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:14 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:14 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:15 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:15 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:15 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:15 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:16 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:16 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:16 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:17 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:17 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:17 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:17 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:18 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:18 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:18 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:18 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:19 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:19 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:19 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:20 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:20 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:20 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:21 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:21 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:21 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:22 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:22 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:23 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 14:48:24 --> Final output sent to browser
DEBUG - 2010-07-08 14:48:24 --> Total execution time: 22.9610
DEBUG - 2010-07-08 14:48:35 --> Config Class Initialized
DEBUG - 2010-07-08 14:48:36 --> Hooks Class Initialized
DEBUG - 2010-07-08 14:48:36 --> URI Class Initialized
DEBUG - 2010-07-08 14:48:36 --> Router Class Initialized
DEBUG - 2010-07-08 14:48:36 --> Output Class Initialized
DEBUG - 2010-07-08 14:48:37 --> Input Class Initialized
DEBUG - 2010-07-08 14:48:37 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 14:48:37 --> Language Class Initialized
DEBUG - 2010-07-08 14:48:37 --> Loader Class Initialized
DEBUG - 2010-07-08 14:48:38 --> Helper loaded: context_helper
DEBUG - 2010-07-08 14:48:38 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 14:48:38 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 14:48:38 --> Database Driver Class Initialized
DEBUG - 2010-07-08 14:48:38 --> Controller Class Initialized
DEBUG - 2010-07-08 14:48:39 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 14:48:39 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 14:48:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:40 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:40 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:41 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:41 --> Helper loaded: email_helper
DEBUG - 2010-07-08 14:48:41 --> User Agent Class Initialized
DEBUG - 2010-07-08 14:48:41 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:41 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:42 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 14:48:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:43 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:43 --> Session Class Initialized
DEBUG - 2010-07-08 14:48:43 --> Helper loaded: string_helper
DEBUG - 2010-07-08 14:48:43 --> Session routines successfully run
DEBUG - 2010-07-08 14:48:43 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:44 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:44 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:44 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:45 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:45 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:45 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:45 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:46 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:46 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:46 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:47 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:47 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:47 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:48 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:48 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 14:48:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:48 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:49 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:49 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:49 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:49 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:50 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:50 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:50 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:50 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:51 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:51 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:51 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:52 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:52 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:52 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:52 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:53 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:53 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:53 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:53 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:54 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:54 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:54 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:54 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:54 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:55 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:55 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:55 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:56 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:56 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:57 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:48:58 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 14:48:58 --> Final output sent to browser
DEBUG - 2010-07-08 14:48:59 --> Total execution time: 22.9926
DEBUG - 2010-07-08 14:49:20 --> Config Class Initialized
DEBUG - 2010-07-08 14:49:21 --> Hooks Class Initialized
DEBUG - 2010-07-08 14:49:21 --> URI Class Initialized
DEBUG - 2010-07-08 14:49:21 --> Router Class Initialized
DEBUG - 2010-07-08 14:49:21 --> Output Class Initialized
DEBUG - 2010-07-08 14:49:22 --> Input Class Initialized
DEBUG - 2010-07-08 14:49:22 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 14:49:22 --> Language Class Initialized
DEBUG - 2010-07-08 14:49:22 --> Loader Class Initialized
DEBUG - 2010-07-08 14:49:23 --> Helper loaded: context_helper
DEBUG - 2010-07-08 14:49:23 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 14:49:23 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 14:49:23 --> Database Driver Class Initialized
DEBUG - 2010-07-08 14:49:24 --> Controller Class Initialized
DEBUG - 2010-07-08 14:49:24 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 14:49:24 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 14:49:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:26 --> Helper loaded: email_helper
DEBUG - 2010-07-08 14:49:26 --> User Agent Class Initialized
DEBUG - 2010-07-08 14:49:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:26 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:27 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 14:49:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:27 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:28 --> Session Class Initialized
DEBUG - 2010-07-08 14:49:28 --> Helper loaded: string_helper
DEBUG - 2010-07-08 14:49:28 --> Session routines successfully run
DEBUG - 2010-07-08 14:49:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:29 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:29 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:30 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:30 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:30 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:30 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:31 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:31 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:31 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:31 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:32 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:33 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 14:49:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:34 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:34 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:35 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:35 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:35 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:35 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:36 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:37 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:37 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:37 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:38 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:38 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:38 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:38 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:39 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:39 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:39 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:39 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:40 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:40 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:40 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:41 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:49:42 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 14:49:42 --> Final output sent to browser
DEBUG - 2010-07-08 14:49:42 --> Total execution time: 21.6913
DEBUG - 2010-07-08 14:53:49 --> Config Class Initialized
DEBUG - 2010-07-08 14:53:49 --> Hooks Class Initialized
DEBUG - 2010-07-08 14:53:49 --> URI Class Initialized
DEBUG - 2010-07-08 14:53:49 --> Router Class Initialized
DEBUG - 2010-07-08 14:53:49 --> Output Class Initialized
DEBUG - 2010-07-08 14:53:50 --> Input Class Initialized
DEBUG - 2010-07-08 14:53:50 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 14:53:50 --> Language Class Initialized
DEBUG - 2010-07-08 14:53:50 --> Loader Class Initialized
DEBUG - 2010-07-08 14:53:51 --> Helper loaded: context_helper
DEBUG - 2010-07-08 14:53:51 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 14:53:51 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 14:53:51 --> Database Driver Class Initialized
DEBUG - 2010-07-08 14:53:52 --> Controller Class Initialized
DEBUG - 2010-07-08 14:53:52 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 14:53:52 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 14:53:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:53:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:53:53 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:53:53 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:53:53 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:53:54 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:53:54 --> Helper loaded: email_helper
DEBUG - 2010-07-08 14:53:54 --> User Agent Class Initialized
DEBUG - 2010-07-08 14:53:54 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:53:55 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:53:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:53:55 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 14:53:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:53:55 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:53:56 --> Session Class Initialized
DEBUG - 2010-07-08 14:53:56 --> Helper loaded: string_helper
DEBUG - 2010-07-08 14:53:56 --> Session routines successfully run
DEBUG - 2010-07-08 14:53:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:53:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:53:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:53:57 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:53:57 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:53:58 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:53:58 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:53:58 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:53:58 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:53:59 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:53:59 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:53:59 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:53:59 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:54:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:54:00 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:54:00 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:54:00 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:54:00 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-08 14:54:01 --> Severity: Notice  --> Undefined property: CI_Unit_test::$benchmark D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 100
DEBUG - 2010-07-08 14:54:52 --> Config Class Initialized
DEBUG - 2010-07-08 14:54:53 --> Hooks Class Initialized
DEBUG - 2010-07-08 14:54:53 --> URI Class Initialized
DEBUG - 2010-07-08 14:54:53 --> Router Class Initialized
DEBUG - 2010-07-08 14:54:53 --> Output Class Initialized
DEBUG - 2010-07-08 14:54:53 --> Input Class Initialized
DEBUG - 2010-07-08 14:54:54 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 14:54:54 --> Language Class Initialized
DEBUG - 2010-07-08 14:54:54 --> Loader Class Initialized
DEBUG - 2010-07-08 14:54:54 --> Helper loaded: context_helper
DEBUG - 2010-07-08 14:54:55 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 14:54:55 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 14:54:55 --> Database Driver Class Initialized
DEBUG - 2010-07-08 14:54:55 --> Controller Class Initialized
DEBUG - 2010-07-08 14:54:56 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 14:54:56 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 14:54:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:54:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:54:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:54:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:54:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:54:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:54:58 --> Helper loaded: email_helper
DEBUG - 2010-07-08 14:54:58 --> User Agent Class Initialized
DEBUG - 2010-07-08 14:54:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:54:58 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:54:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:54:59 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 14:54:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:54:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:54:59 --> Session Class Initialized
DEBUG - 2010-07-08 14:55:00 --> Helper loaded: string_helper
DEBUG - 2010-07-08 14:55:00 --> Session routines successfully run
DEBUG - 2010-07-08 14:55:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:01 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:01 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:01 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:02 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:02 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:02 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:02 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:03 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:03 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:03 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:04 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:04 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:05 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 14:55:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:06 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:06 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:06 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:07 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:07 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:07 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:08 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:08 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:09 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:09 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:09 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:09 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:10 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:10 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:10 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:10 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:11 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:11 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:11 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:11 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:12 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:12 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:12 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:12 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:13 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:13 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:14 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:14 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:14 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:14 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:55:16 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 14:55:16 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 14:55:17 --> Helper loaded: text_helper
DEBUG - 2010-07-08 14:55:17 --> Final output sent to browser
DEBUG - 2010-07-08 14:55:17 --> Total execution time: 24.0105
DEBUG - 2010-07-08 14:58:27 --> Config Class Initialized
DEBUG - 2010-07-08 14:58:27 --> Hooks Class Initialized
DEBUG - 2010-07-08 14:58:27 --> URI Class Initialized
DEBUG - 2010-07-08 14:58:28 --> Router Class Initialized
DEBUG - 2010-07-08 14:58:28 --> Output Class Initialized
DEBUG - 2010-07-08 14:58:28 --> Input Class Initialized
DEBUG - 2010-07-08 14:58:28 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 14:58:29 --> Language Class Initialized
DEBUG - 2010-07-08 14:58:29 --> Loader Class Initialized
DEBUG - 2010-07-08 14:58:29 --> Helper loaded: context_helper
DEBUG - 2010-07-08 14:58:30 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 14:58:30 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 14:58:30 --> Database Driver Class Initialized
DEBUG - 2010-07-08 14:58:30 --> Controller Class Initialized
DEBUG - 2010-07-08 14:58:31 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 14:58:31 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 14:58:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:33 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:33 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:33 --> Helper loaded: email_helper
DEBUG - 2010-07-08 14:58:33 --> User Agent Class Initialized
DEBUG - 2010-07-08 14:58:33 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:34 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:34 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 14:58:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:35 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:35 --> Session Class Initialized
DEBUG - 2010-07-08 14:58:35 --> Helper loaded: string_helper
DEBUG - 2010-07-08 14:58:35 --> Session routines successfully run
DEBUG - 2010-07-08 14:58:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:37 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:37 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:37 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:37 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:38 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:38 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:38 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:38 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:39 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:39 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:40 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:40 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 14:58:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:41 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:41 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:41 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:42 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:42 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:42 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:42 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:43 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:43 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:43 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:44 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:44 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:44 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:44 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:45 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:45 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:45 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:45 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:46 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:46 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:46 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:46 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:47 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:47 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:47 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:47 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:48 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:48 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:48 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:49 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:49 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:49 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:49 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:50 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:50 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:50 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 14:58:51 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 14:58:51 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 14:58:52 --> Helper loaded: text_helper
DEBUG - 2010-07-08 14:58:52 --> Final output sent to browser
DEBUG - 2010-07-08 14:58:52 --> Total execution time: 24.3142
DEBUG - 2010-07-08 15:06:58 --> Config Class Initialized
DEBUG - 2010-07-08 15:06:58 --> Hooks Class Initialized
DEBUG - 2010-07-08 15:06:58 --> URI Class Initialized
DEBUG - 2010-07-08 15:06:59 --> Router Class Initialized
DEBUG - 2010-07-08 15:06:59 --> Output Class Initialized
DEBUG - 2010-07-08 15:06:59 --> Input Class Initialized
DEBUG - 2010-07-08 15:07:00 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 15:07:00 --> Language Class Initialized
DEBUG - 2010-07-08 15:07:00 --> Loader Class Initialized
DEBUG - 2010-07-08 15:07:00 --> Helper loaded: context_helper
DEBUG - 2010-07-08 15:07:01 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 15:07:01 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 15:07:01 --> Database Driver Class Initialized
DEBUG - 2010-07-08 15:07:01 --> Controller Class Initialized
DEBUG - 2010-07-08 15:07:02 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 15:07:02 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 15:07:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:03 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:03 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:04 --> Helper loaded: email_helper
DEBUG - 2010-07-08 15:07:04 --> User Agent Class Initialized
DEBUG - 2010-07-08 15:07:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:05 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:05 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 15:07:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:06 --> Session Class Initialized
DEBUG - 2010-07-08 15:07:06 --> Helper loaded: string_helper
DEBUG - 2010-07-08 15:07:06 --> Session routines successfully run
DEBUG - 2010-07-08 15:07:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:07 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:08 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:08 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:08 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:08 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:09 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:09 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:09 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:09 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:09 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:10 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:10 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:10 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:11 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 15:07:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:11 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:12 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:12 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:12 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:13 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:13 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:13 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:14 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:14 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:14 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:15 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:15 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:15 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:16 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:16 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:16 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:16 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:17 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:17 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:17 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:17 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:17 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:18 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:18 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:18 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:18 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:19 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:19 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:19 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:20 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:20 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:20 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:07:22 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 15:07:22 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 15:07:22 --> Helper loaded: text_helper
DEBUG - 2010-07-08 15:07:22 --> Final output sent to browser
DEBUG - 2010-07-08 15:07:23 --> Total execution time: 23.9463
DEBUG - 2010-07-08 15:11:15 --> Config Class Initialized
DEBUG - 2010-07-08 15:11:15 --> Hooks Class Initialized
DEBUG - 2010-07-08 15:11:16 --> URI Class Initialized
DEBUG - 2010-07-08 15:11:16 --> Router Class Initialized
DEBUG - 2010-07-08 15:11:16 --> Output Class Initialized
DEBUG - 2010-07-08 15:11:16 --> Input Class Initialized
DEBUG - 2010-07-08 15:11:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 15:11:17 --> Language Class Initialized
DEBUG - 2010-07-08 15:11:17 --> Loader Class Initialized
DEBUG - 2010-07-08 15:11:17 --> Helper loaded: context_helper
DEBUG - 2010-07-08 15:11:18 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 15:11:18 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 15:11:18 --> Database Driver Class Initialized
DEBUG - 2010-07-08 15:11:18 --> Controller Class Initialized
DEBUG - 2010-07-08 15:11:19 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 15:11:19 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 15:11:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:20 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:20 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:20 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:21 --> Helper loaded: email_helper
DEBUG - 2010-07-08 15:11:21 --> User Agent Class Initialized
DEBUG - 2010-07-08 15:11:21 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:21 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:22 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 15:11:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:23 --> Session Class Initialized
DEBUG - 2010-07-08 15:11:23 --> Helper loaded: string_helper
DEBUG - 2010-07-08 15:11:23 --> Session routines successfully run
DEBUG - 2010-07-08 15:11:24 --> Config Class Initialized
DEBUG - 2010-07-08 15:11:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:24 --> Hooks Class Initialized
DEBUG - 2010-07-08 15:11:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:24 --> URI Class Initialized
DEBUG - 2010-07-08 15:11:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:24 --> Router Class Initialized
DEBUG - 2010-07-08 15:11:24 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:25 --> Output Class Initialized
DEBUG - 2010-07-08 15:11:25 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:25 --> Input Class Initialized
DEBUG - 2010-07-08 15:11:25 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:25 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 15:11:25 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:25 --> Language Class Initialized
DEBUG - 2010-07-08 15:11:26 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:26 --> Loader Class Initialized
DEBUG - 2010-07-08 15:11:26 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:26 --> Helper loaded: context_helper
DEBUG - 2010-07-08 15:11:26 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:26 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 15:11:27 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 15:11:27 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:27 --> Database Driver Class Initialized
DEBUG - 2010-07-08 15:11:27 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:27 --> Controller Class Initialized
DEBUG - 2010-07-08 15:11:28 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:28 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 15:11:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:28 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 15:11:28 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:29 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:29 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:30 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 15:11:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:30 --> Helper loaded: email_helper
DEBUG - 2010-07-08 15:11:31 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:31 --> User Agent Class Initialized
DEBUG - 2010-07-08 15:11:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:31 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:31 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:32 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:32 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 15:11:32 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:32 --> Session Class Initialized
DEBUG - 2010-07-08 15:11:32 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:33 --> Helper loaded: string_helper
DEBUG - 2010-07-08 15:11:33 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:33 --> Session routines successfully run
DEBUG - 2010-07-08 15:11:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:33 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:33 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:33 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:34 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:34 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:34 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:34 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:34 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 15:11:34 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:34 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:35 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:35 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:35 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:35 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:35 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:35 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:35 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:35 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:36 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:36 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:36 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:36 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:36 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:37 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:37 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:37 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:37 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:37 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:37 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:38 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:38 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:38 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:38 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:38 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:38 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:38 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:38 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:39 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 15:11:39 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:39 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 15:11:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:39 --> Helper loaded: text_helper
DEBUG - 2010-07-08 15:11:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:40 --> Final output sent to browser
DEBUG - 2010-07-08 15:11:40 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:40 --> Total execution time: 15.6732
DEBUG - 2010-07-08 15:11:40 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:11:42 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 15:11:42 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 15:11:42 --> Helper loaded: text_helper
DEBUG - 2010-07-08 15:11:43 --> Final output sent to browser
DEBUG - 2010-07-08 15:11:43 --> Total execution time: 26.9593
DEBUG - 2010-07-08 15:12:27 --> Config Class Initialized
DEBUG - 2010-07-08 15:12:28 --> Hooks Class Initialized
DEBUG - 2010-07-08 15:12:28 --> URI Class Initialized
DEBUG - 2010-07-08 15:12:28 --> Router Class Initialized
DEBUG - 2010-07-08 15:12:28 --> Output Class Initialized
DEBUG - 2010-07-08 15:12:29 --> Input Class Initialized
DEBUG - 2010-07-08 15:12:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 15:12:29 --> Language Class Initialized
DEBUG - 2010-07-08 15:12:29 --> Loader Class Initialized
DEBUG - 2010-07-08 15:12:30 --> Helper loaded: context_helper
DEBUG - 2010-07-08 15:12:30 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 15:12:30 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 15:12:30 --> Database Driver Class Initialized
DEBUG - 2010-07-08 15:12:31 --> Controller Class Initialized
DEBUG - 2010-07-08 15:12:31 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 15:12:31 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 15:12:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:12:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:12:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:12:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:12:33 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:12:33 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:12:33 --> Helper loaded: email_helper
DEBUG - 2010-07-08 15:12:33 --> User Agent Class Initialized
DEBUG - 2010-07-08 15:12:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:12:34 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:12:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:12:34 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 15:12:35 --> Session Class Initialized
DEBUG - 2010-07-08 15:12:35 --> Helper loaded: string_helper
DEBUG - 2010-07-08 15:12:35 --> Session routines successfully run
DEBUG - 2010-07-08 15:12:35 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:12:36 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:12:36 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:12:36 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:12:36 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 15:12:37 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:12:37 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:12:37 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:12:38 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:12:38 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:12:38 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:12:38 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:12:39 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:12:39 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:12:39 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:12:39 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:12:40 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:12:40 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:12:40 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:12:40 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:12:41 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:12:41 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 15:12:41 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 15:12:42 --> Helper loaded: text_helper
DEBUG - 2010-07-08 15:12:42 --> Final output sent to browser
DEBUG - 2010-07-08 15:12:42 --> Total execution time: 13.9500
DEBUG - 2010-07-08 15:13:34 --> Config Class Initialized
DEBUG - 2010-07-08 15:13:35 --> Hooks Class Initialized
DEBUG - 2010-07-08 15:13:35 --> URI Class Initialized
DEBUG - 2010-07-08 15:13:35 --> Router Class Initialized
DEBUG - 2010-07-08 15:13:35 --> Output Class Initialized
DEBUG - 2010-07-08 15:13:36 --> Input Class Initialized
DEBUG - 2010-07-08 15:13:36 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 15:13:36 --> Language Class Initialized
DEBUG - 2010-07-08 15:13:37 --> Loader Class Initialized
DEBUG - 2010-07-08 15:13:37 --> Helper loaded: context_helper
DEBUG - 2010-07-08 15:13:37 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 15:13:38 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 15:13:38 --> Database Driver Class Initialized
DEBUG - 2010-07-08 15:13:38 --> Controller Class Initialized
DEBUG - 2010-07-08 15:13:38 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 15:13:39 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 15:13:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:40 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:40 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:41 --> Helper loaded: email_helper
DEBUG - 2010-07-08 15:13:41 --> User Agent Class Initialized
DEBUG - 2010-07-08 15:13:41 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:42 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:42 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 15:13:43 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:43 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:43 --> Session Class Initialized
DEBUG - 2010-07-08 15:13:43 --> Helper loaded: string_helper
DEBUG - 2010-07-08 15:13:44 --> Session routines successfully run
DEBUG - 2010-07-08 15:13:44 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:45 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:45 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:45 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:46 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:46 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:46 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:47 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:47 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:47 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:48 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:48 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:49 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:49 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:49 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 15:13:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:50 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:50 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:50 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:51 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:51 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:51 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:51 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:52 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:52 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:52 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:53 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:53 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:54 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:54 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:54 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:54 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:55 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:55 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:55 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:55 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:56 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:56 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:56 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:56 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:57 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:57 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:57 --> Annotation_type_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:59 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:59 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:59 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:13:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:14:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:14:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:14:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:14:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:14:01 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 15:14:01 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 15:14:01 --> Helper loaded: text_helper
DEBUG - 2010-07-08 15:14:01 --> Final output sent to browser
DEBUG - 2010-07-08 15:14:02 --> Total execution time: 26.5450
DEBUG - 2010-07-08 15:15:02 --> Config Class Initialized
DEBUG - 2010-07-08 15:15:03 --> Hooks Class Initialized
DEBUG - 2010-07-08 15:15:03 --> URI Class Initialized
DEBUG - 2010-07-08 15:15:03 --> Router Class Initialized
DEBUG - 2010-07-08 15:15:04 --> Output Class Initialized
DEBUG - 2010-07-08 15:15:04 --> Input Class Initialized
DEBUG - 2010-07-08 15:15:04 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 15:15:04 --> Language Class Initialized
DEBUG - 2010-07-08 15:15:05 --> Loader Class Initialized
DEBUG - 2010-07-08 15:15:05 --> Helper loaded: context_helper
DEBUG - 2010-07-08 15:15:05 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 15:15:05 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 15:15:06 --> Database Driver Class Initialized
DEBUG - 2010-07-08 15:15:06 --> Controller Class Initialized
DEBUG - 2010-07-08 15:15:06 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 15:15:07 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 15:15:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:15:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:15:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:15:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:15:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:15:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:15:08 --> Helper loaded: email_helper
DEBUG - 2010-07-08 15:15:09 --> User Agent Class Initialized
DEBUG - 2010-07-08 15:15:09 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:15:09 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:15:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:15:10 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 15:15:10 --> Session Class Initialized
DEBUG - 2010-07-08 15:15:10 --> Helper loaded: string_helper
DEBUG - 2010-07-08 15:15:11 --> Session routines successfully run
DEBUG - 2010-07-08 15:15:11 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:15:11 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:15:12 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:15:12 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:15:12 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 15:15:12 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:15:13 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:15:13 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:15:13 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:15:13 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:15:14 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:15:14 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:15:14 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:15:15 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:15:15 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:15:15 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:15:15 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:15:16 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:15:16 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:15:16 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:15:16 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:15:17 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 15:15:17 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 15:15:17 --> Helper loaded: text_helper
DEBUG - 2010-07-08 15:15:18 --> Final output sent to browser
DEBUG - 2010-07-08 15:15:18 --> Total execution time: 14.5122
DEBUG - 2010-07-08 15:17:16 --> Config Class Initialized
DEBUG - 2010-07-08 15:17:16 --> Hooks Class Initialized
DEBUG - 2010-07-08 15:17:16 --> URI Class Initialized
DEBUG - 2010-07-08 15:17:16 --> Router Class Initialized
DEBUG - 2010-07-08 15:17:17 --> Output Class Initialized
DEBUG - 2010-07-08 15:17:17 --> Input Class Initialized
DEBUG - 2010-07-08 15:17:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 15:17:18 --> Language Class Initialized
DEBUG - 2010-07-08 15:17:18 --> Loader Class Initialized
DEBUG - 2010-07-08 15:17:18 --> Helper loaded: context_helper
DEBUG - 2010-07-08 15:17:18 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 15:17:19 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 15:17:19 --> Database Driver Class Initialized
DEBUG - 2010-07-08 15:17:19 --> Controller Class Initialized
DEBUG - 2010-07-08 15:17:19 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 15:17:20 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 15:17:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:17:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:17:21 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:17:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:17:21 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:17:21 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:17:22 --> Helper loaded: email_helper
DEBUG - 2010-07-08 15:17:22 --> User Agent Class Initialized
DEBUG - 2010-07-08 15:17:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:17:22 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:17:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:17:23 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 15:17:23 --> Session Class Initialized
DEBUG - 2010-07-08 15:17:23 --> Helper loaded: string_helper
DEBUG - 2010-07-08 15:17:24 --> Session routines successfully run
DEBUG - 2010-07-08 15:17:24 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:17:24 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:17:25 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:17:25 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:17:25 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 15:17:25 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:17:26 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:17:26 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:17:26 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:17:27 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:17:27 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:17:27 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:17:27 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:17:28 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:17:28 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:17:28 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:17:29 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:17:29 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:17:29 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:17:30 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:17:30 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:17:30 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 15:17:30 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 15:17:31 --> Helper loaded: text_helper
DEBUG - 2010-07-08 15:17:31 --> Final output sent to browser
DEBUG - 2010-07-08 15:17:31 --> Total execution time: 14.6915
DEBUG - 2010-07-08 15:18:39 --> Config Class Initialized
DEBUG - 2010-07-08 15:18:39 --> Hooks Class Initialized
DEBUG - 2010-07-08 15:18:39 --> URI Class Initialized
DEBUG - 2010-07-08 15:18:39 --> Router Class Initialized
DEBUG - 2010-07-08 15:18:40 --> Output Class Initialized
DEBUG - 2010-07-08 15:18:40 --> Input Class Initialized
DEBUG - 2010-07-08 15:18:40 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 15:18:40 --> Language Class Initialized
DEBUG - 2010-07-08 15:18:41 --> Loader Class Initialized
DEBUG - 2010-07-08 15:18:41 --> Helper loaded: context_helper
DEBUG - 2010-07-08 15:18:41 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 15:18:41 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 15:18:42 --> Database Driver Class Initialized
DEBUG - 2010-07-08 15:18:42 --> Controller Class Initialized
DEBUG - 2010-07-08 15:18:42 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 15:18:42 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 15:18:43 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:18:43 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:18:43 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:18:43 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:18:44 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:18:44 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:18:44 --> Helper loaded: email_helper
DEBUG - 2010-07-08 15:18:45 --> User Agent Class Initialized
DEBUG - 2010-07-08 15:18:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:18:45 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:18:45 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:18:46 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 15:18:46 --> Session Class Initialized
DEBUG - 2010-07-08 15:18:46 --> Helper loaded: string_helper
DEBUG - 2010-07-08 15:18:47 --> Session routines successfully run
DEBUG - 2010-07-08 15:18:47 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 15:18:47 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 15:18:47 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 15:18:48 --> Helper loaded: text_helper
DEBUG - 2010-07-08 15:18:48 --> Final output sent to browser
DEBUG - 2010-07-08 15:18:48 --> Total execution time: 8.8907
DEBUG - 2010-07-08 15:19:52 --> Config Class Initialized
DEBUG - 2010-07-08 15:19:52 --> Hooks Class Initialized
DEBUG - 2010-07-08 15:19:52 --> URI Class Initialized
DEBUG - 2010-07-08 15:19:52 --> Router Class Initialized
DEBUG - 2010-07-08 15:19:53 --> Output Class Initialized
DEBUG - 2010-07-08 15:19:53 --> Input Class Initialized
DEBUG - 2010-07-08 15:19:53 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 15:19:53 --> Language Class Initialized
DEBUG - 2010-07-08 15:19:54 --> Loader Class Initialized
DEBUG - 2010-07-08 15:19:54 --> Helper loaded: context_helper
DEBUG - 2010-07-08 15:19:54 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 15:19:55 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 15:19:55 --> Database Driver Class Initialized
DEBUG - 2010-07-08 15:19:55 --> Controller Class Initialized
DEBUG - 2010-07-08 15:19:55 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 15:19:56 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 15:19:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:19:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:19:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:19:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:19:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:19:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:19:57 --> Helper loaded: email_helper
DEBUG - 2010-07-08 15:19:58 --> User Agent Class Initialized
DEBUG - 2010-07-08 15:19:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:19:58 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:19:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-08 15:19:59 --> Config file loaded: config/kals.php
DEBUG - 2010-07-08 15:19:59 --> Session Class Initialized
DEBUG - 2010-07-08 15:19:59 --> Helper loaded: string_helper
DEBUG - 2010-07-08 15:20:00 --> Session routines successfully run
DEBUG - 2010-07-08 15:20:00 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 15:20:00 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 15:20:00 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 15:20:01 --> Helper loaded: text_helper
DEBUG - 2010-07-08 15:20:01 --> Final output sent to browser
DEBUG - 2010-07-08 15:20:01 --> Total execution time: 8.7700
DEBUG - 2010-07-08 15:23:25 --> Config Class Initialized
DEBUG - 2010-07-08 15:23:25 --> Hooks Class Initialized
DEBUG - 2010-07-08 15:23:26 --> URI Class Initialized
DEBUG - 2010-07-08 15:23:26 --> Router Class Initialized
DEBUG - 2010-07-08 15:23:26 --> Output Class Initialized
DEBUG - 2010-07-08 15:23:26 --> Input Class Initialized
DEBUG - 2010-07-08 15:23:27 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 15:23:27 --> Language Class Initialized
DEBUG - 2010-07-08 15:23:27 --> Loader Class Initialized
DEBUG - 2010-07-08 15:23:27 --> Helper loaded: context_helper
DEBUG - 2010-07-08 15:23:28 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 15:23:28 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 15:23:28 --> Database Driver Class Initialized
DEBUG - 2010-07-08 15:23:29 --> Controller Class Initialized
DEBUG - 2010-07-08 15:23:29 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 15:23:29 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 15:23:29 --> Session Class Initialized
DEBUG - 2010-07-08 15:23:30 --> Helper loaded: string_helper
DEBUG - 2010-07-08 15:23:30 --> Session routines successfully run
DEBUG - 2010-07-08 15:23:30 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 15:23:30 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 15:23:31 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 15:23:31 --> Helper loaded: text_helper
DEBUG - 2010-07-08 15:23:31 --> Final output sent to browser
DEBUG - 2010-07-08 15:23:31 --> Total execution time: 5.6570
DEBUG - 2010-07-08 15:25:28 --> Config Class Initialized
DEBUG - 2010-07-08 15:25:29 --> Hooks Class Initialized
DEBUG - 2010-07-08 15:25:29 --> URI Class Initialized
DEBUG - 2010-07-08 15:25:29 --> Router Class Initialized
DEBUG - 2010-07-08 15:25:29 --> Output Class Initialized
DEBUG - 2010-07-08 15:25:30 --> Input Class Initialized
DEBUG - 2010-07-08 15:25:30 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 15:25:30 --> Language Class Initialized
DEBUG - 2010-07-08 15:25:30 --> Loader Class Initialized
DEBUG - 2010-07-08 15:25:31 --> Helper loaded: context_helper
DEBUG - 2010-07-08 15:25:31 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 15:25:31 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 15:25:31 --> Database Driver Class Initialized
DEBUG - 2010-07-08 15:25:32 --> Controller Class Initialized
DEBUG - 2010-07-08 15:25:32 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 15:25:32 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 15:25:33 --> Session Class Initialized
DEBUG - 2010-07-08 15:25:33 --> Helper loaded: string_helper
DEBUG - 2010-07-08 15:25:33 --> Session routines successfully run
DEBUG - 2010-07-08 15:25:33 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 15:25:34 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 15:25:34 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 15:25:34 --> Helper loaded: text_helper
DEBUG - 2010-07-08 15:25:34 --> Final output sent to browser
DEBUG - 2010-07-08 15:25:35 --> Total execution time: 5.5671
DEBUG - 2010-07-08 15:25:48 --> Config Class Initialized
DEBUG - 2010-07-08 15:25:48 --> Hooks Class Initialized
DEBUG - 2010-07-08 15:25:49 --> URI Class Initialized
DEBUG - 2010-07-08 15:25:49 --> Router Class Initialized
DEBUG - 2010-07-08 15:25:49 --> Output Class Initialized
DEBUG - 2010-07-08 15:25:49 --> Input Class Initialized
DEBUG - 2010-07-08 15:25:50 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 15:25:50 --> Language Class Initialized
DEBUG - 2010-07-08 15:25:50 --> Loader Class Initialized
DEBUG - 2010-07-08 15:25:50 --> Helper loaded: context_helper
DEBUG - 2010-07-08 15:25:51 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 15:25:51 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 15:25:51 --> Database Driver Class Initialized
DEBUG - 2010-07-08 15:25:52 --> Controller Class Initialized
DEBUG - 2010-07-08 15:25:52 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 15:25:52 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 15:25:52 --> Session Class Initialized
DEBUG - 2010-07-08 15:25:53 --> Helper loaded: string_helper
DEBUG - 2010-07-08 15:25:53 --> Session routines successfully run
DEBUG - 2010-07-08 15:25:53 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 15:25:53 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 15:25:54 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 15:25:54 --> Helper loaded: text_helper
DEBUG - 2010-07-08 15:25:54 --> Final output sent to browser
DEBUG - 2010-07-08 15:25:54 --> Total execution time: 5.5249
DEBUG - 2010-07-08 15:26:06 --> Config Class Initialized
DEBUG - 2010-07-08 15:26:06 --> Hooks Class Initialized
DEBUG - 2010-07-08 15:26:06 --> URI Class Initialized
DEBUG - 2010-07-08 15:26:07 --> Router Class Initialized
DEBUG - 2010-07-08 15:26:07 --> Output Class Initialized
DEBUG - 2010-07-08 15:26:07 --> Input Class Initialized
DEBUG - 2010-07-08 15:26:08 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 15:26:08 --> Language Class Initialized
DEBUG - 2010-07-08 15:26:08 --> Loader Class Initialized
DEBUG - 2010-07-08 15:26:08 --> Helper loaded: context_helper
DEBUG - 2010-07-08 15:26:09 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 15:26:09 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 15:26:09 --> Database Driver Class Initialized
DEBUG - 2010-07-08 15:26:09 --> Controller Class Initialized
DEBUG - 2010-07-08 15:26:10 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 15:26:10 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 15:26:20 --> Config Class Initialized
DEBUG - 2010-07-08 15:26:20 --> Hooks Class Initialized
DEBUG - 2010-07-08 15:26:21 --> URI Class Initialized
DEBUG - 2010-07-08 15:26:21 --> Router Class Initialized
DEBUG - 2010-07-08 15:26:21 --> Output Class Initialized
DEBUG - 2010-07-08 15:26:22 --> Input Class Initialized
DEBUG - 2010-07-08 15:26:22 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 15:26:22 --> Language Class Initialized
DEBUG - 2010-07-08 15:26:22 --> Loader Class Initialized
DEBUG - 2010-07-08 15:26:23 --> Helper loaded: context_helper
DEBUG - 2010-07-08 15:26:23 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 15:26:23 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 15:26:24 --> Database Driver Class Initialized
DEBUG - 2010-07-08 15:26:24 --> Controller Class Initialized
DEBUG - 2010-07-08 15:26:24 --> Config Class Initialized
DEBUG - 2010-07-08 15:26:24 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 15:26:24 --> Hooks Class Initialized
DEBUG - 2010-07-08 15:26:24 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 15:26:25 --> URI Class Initialized
DEBUG - 2010-07-08 15:26:25 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 15:26:25 --> Router Class Initialized
DEBUG - 2010-07-08 15:26:25 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 15:26:25 --> Output Class Initialized
DEBUG - 2010-07-08 15:26:25 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 15:26:25 --> Input Class Initialized
DEBUG - 2010-07-08 15:26:25 --> Helper loaded: text_helper
DEBUG - 2010-07-08 15:26:26 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 15:26:26 --> Final output sent to browser
DEBUG - 2010-07-08 15:26:26 --> Language Class Initialized
DEBUG - 2010-07-08 15:26:26 --> Total execution time: 5.0375
DEBUG - 2010-07-08 15:26:26 --> Loader Class Initialized
DEBUG - 2010-07-08 15:26:26 --> Helper loaded: context_helper
DEBUG - 2010-07-08 15:26:27 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 15:26:27 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 15:26:27 --> Database Driver Class Initialized
DEBUG - 2010-07-08 15:26:28 --> Controller Class Initialized
DEBUG - 2010-07-08 15:26:28 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 15:26:28 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 15:26:28 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 15:26:29 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 15:26:29 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 15:26:29 --> Helper loaded: text_helper
DEBUG - 2010-07-08 15:26:30 --> Final output sent to browser
DEBUG - 2010-07-08 15:26:30 --> Total execution time: 5.0075
DEBUG - 2010-07-08 15:26:57 --> Config Class Initialized
DEBUG - 2010-07-08 15:26:57 --> Hooks Class Initialized
DEBUG - 2010-07-08 15:26:57 --> URI Class Initialized
DEBUG - 2010-07-08 15:26:57 --> Router Class Initialized
DEBUG - 2010-07-08 15:26:58 --> Output Class Initialized
DEBUG - 2010-07-08 15:26:58 --> Input Class Initialized
DEBUG - 2010-07-08 15:26:58 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 15:26:59 --> Language Class Initialized
DEBUG - 2010-07-08 15:26:59 --> Loader Class Initialized
DEBUG - 2010-07-08 15:26:59 --> Helper loaded: context_helper
DEBUG - 2010-07-08 15:26:59 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 15:27:00 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 15:27:00 --> Database Driver Class Initialized
DEBUG - 2010-07-08 15:27:00 --> Controller Class Initialized
DEBUG - 2010-07-08 15:27:00 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 15:27:01 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 15:27:01 --> Session Class Initialized
DEBUG - 2010-07-08 15:27:01 --> Helper loaded: string_helper
DEBUG - 2010-07-08 15:27:02 --> Session routines successfully run
DEBUG - 2010-07-08 15:27:02 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 15:27:02 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 15:27:03 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 15:27:03 --> Helper loaded: text_helper
DEBUG - 2010-07-08 15:27:03 --> Final output sent to browser
DEBUG - 2010-07-08 15:27:04 --> Total execution time: 5.8257
DEBUG - 2010-07-08 15:27:23 --> Config Class Initialized
DEBUG - 2010-07-08 15:27:23 --> Hooks Class Initialized
DEBUG - 2010-07-08 15:27:23 --> URI Class Initialized
DEBUG - 2010-07-08 15:27:23 --> Router Class Initialized
DEBUG - 2010-07-08 15:27:24 --> Output Class Initialized
DEBUG - 2010-07-08 15:27:24 --> Input Class Initialized
DEBUG - 2010-07-08 15:27:24 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 15:27:25 --> Language Class Initialized
DEBUG - 2010-07-08 15:27:25 --> Loader Class Initialized
DEBUG - 2010-07-08 15:27:25 --> Helper loaded: context_helper
DEBUG - 2010-07-08 15:27:25 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 15:27:26 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 15:27:26 --> Database Driver Class Initialized
DEBUG - 2010-07-08 15:27:26 --> Controller Class Initialized
DEBUG - 2010-07-08 15:27:26 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 15:27:27 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 15:27:27 --> Session Class Initialized
DEBUG - 2010-07-08 15:27:27 --> Helper loaded: string_helper
DEBUG - 2010-07-08 15:27:28 --> Session routines successfully run
DEBUG - 2010-07-08 15:27:28 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 15:27:28 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 15:27:28 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 15:27:29 --> Helper loaded: text_helper
DEBUG - 2010-07-08 15:27:29 --> Final output sent to browser
DEBUG - 2010-07-08 15:27:29 --> Total execution time: 5.6845
DEBUG - 2010-07-08 15:27:44 --> Config Class Initialized
DEBUG - 2010-07-08 15:27:45 --> Hooks Class Initialized
DEBUG - 2010-07-08 15:27:45 --> URI Class Initialized
DEBUG - 2010-07-08 15:27:45 --> Router Class Initialized
DEBUG - 2010-07-08 15:27:45 --> Output Class Initialized
DEBUG - 2010-07-08 15:27:46 --> Input Class Initialized
DEBUG - 2010-07-08 15:27:46 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 15:27:46 --> Language Class Initialized
DEBUG - 2010-07-08 15:27:47 --> Loader Class Initialized
DEBUG - 2010-07-08 15:27:47 --> Helper loaded: context_helper
DEBUG - 2010-07-08 15:27:47 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 15:27:48 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 15:27:48 --> Database Driver Class Initialized
DEBUG - 2010-07-08 15:27:48 --> Controller Class Initialized
DEBUG - 2010-07-08 15:27:48 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 15:27:49 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 15:27:49 --> Session Class Initialized
DEBUG - 2010-07-08 15:27:49 --> Helper loaded: string_helper
DEBUG - 2010-07-08 15:27:50 --> Session routines successfully run
DEBUG - 2010-07-08 15:27:50 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 15:27:50 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 15:27:50 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 15:27:51 --> Helper loaded: text_helper
DEBUG - 2010-07-08 15:27:51 --> Final output sent to browser
DEBUG - 2010-07-08 15:27:51 --> Total execution time: 5.9973
DEBUG - 2010-07-08 15:27:55 --> Config Class Initialized
DEBUG - 2010-07-08 15:27:55 --> Hooks Class Initialized
DEBUG - 2010-07-08 15:27:55 --> URI Class Initialized
DEBUG - 2010-07-08 15:27:56 --> Router Class Initialized
DEBUG - 2010-07-08 15:27:56 --> Output Class Initialized
DEBUG - 2010-07-08 15:27:56 --> Input Class Initialized
DEBUG - 2010-07-08 15:27:56 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 15:27:57 --> Language Class Initialized
DEBUG - 2010-07-08 15:27:57 --> Loader Class Initialized
DEBUG - 2010-07-08 15:27:57 --> Helper loaded: context_helper
DEBUG - 2010-07-08 15:27:57 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 15:27:58 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 15:27:58 --> Database Driver Class Initialized
DEBUG - 2010-07-08 15:27:58 --> Controller Class Initialized
DEBUG - 2010-07-08 15:27:59 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 15:27:59 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 15:27:59 --> Session Class Initialized
DEBUG - 2010-07-08 15:27:59 --> Helper loaded: string_helper
DEBUG - 2010-07-08 15:28:00 --> Session routines successfully run
DEBUG - 2010-07-08 15:28:00 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 15:28:00 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 15:28:01 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 15:28:01 --> Helper loaded: text_helper
DEBUG - 2010-07-08 15:28:01 --> Final output sent to browser
DEBUG - 2010-07-08 15:28:01 --> Total execution time: 5.8451
DEBUG - 2010-07-08 15:31:47 --> Config Class Initialized
DEBUG - 2010-07-08 15:31:47 --> Hooks Class Initialized
DEBUG - 2010-07-08 15:31:47 --> URI Class Initialized
DEBUG - 2010-07-08 15:31:48 --> Router Class Initialized
DEBUG - 2010-07-08 15:31:48 --> Output Class Initialized
DEBUG - 2010-07-08 15:31:48 --> Input Class Initialized
DEBUG - 2010-07-08 15:31:49 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 15:31:49 --> Language Class Initialized
DEBUG - 2010-07-08 15:31:49 --> Loader Class Initialized
DEBUG - 2010-07-08 15:31:49 --> Helper loaded: context_helper
DEBUG - 2010-07-08 15:31:50 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 15:31:50 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 15:31:50 --> Database Driver Class Initialized
DEBUG - 2010-07-08 15:31:51 --> Controller Class Initialized
DEBUG - 2010-07-08 15:31:51 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 15:31:51 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 15:31:51 --> Session Class Initialized
DEBUG - 2010-07-08 15:31:52 --> Helper loaded: string_helper
DEBUG - 2010-07-08 15:31:52 --> Session routines successfully run
DEBUG - 2010-07-08 15:32:14 --> Config Class Initialized
DEBUG - 2010-07-08 15:32:14 --> Hooks Class Initialized
DEBUG - 2010-07-08 15:32:15 --> URI Class Initialized
DEBUG - 2010-07-08 15:32:15 --> Router Class Initialized
DEBUG - 2010-07-08 15:32:15 --> Output Class Initialized
DEBUG - 2010-07-08 15:32:16 --> Input Class Initialized
DEBUG - 2010-07-08 15:32:16 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 15:32:16 --> Language Class Initialized
DEBUG - 2010-07-08 15:32:16 --> Loader Class Initialized
DEBUG - 2010-07-08 15:32:17 --> Helper loaded: context_helper
DEBUG - 2010-07-08 15:32:17 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 15:32:17 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 15:32:18 --> Database Driver Class Initialized
DEBUG - 2010-07-08 15:32:18 --> Controller Class Initialized
DEBUG - 2010-07-08 15:32:18 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 15:32:18 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 15:32:19 --> Session Class Initialized
DEBUG - 2010-07-08 15:32:19 --> Helper loaded: string_helper
DEBUG - 2010-07-08 15:32:19 --> Session routines successfully run
DEBUG - 2010-07-08 15:32:19 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 15:32:20 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 15:32:20 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 15:32:20 --> Helper loaded: text_helper
DEBUG - 2010-07-08 15:32:21 --> Final output sent to browser
DEBUG - 2010-07-08 15:32:21 --> Total execution time: 5.8530
DEBUG - 2010-07-08 15:33:50 --> Config Class Initialized
DEBUG - 2010-07-08 15:33:50 --> Hooks Class Initialized
DEBUG - 2010-07-08 15:33:50 --> URI Class Initialized
DEBUG - 2010-07-08 15:33:50 --> Router Class Initialized
DEBUG - 2010-07-08 15:33:51 --> Output Class Initialized
DEBUG - 2010-07-08 15:33:51 --> Input Class Initialized
DEBUG - 2010-07-08 15:33:51 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 15:33:51 --> Language Class Initialized
DEBUG - 2010-07-08 15:33:52 --> Loader Class Initialized
DEBUG - 2010-07-08 15:33:52 --> Helper loaded: context_helper
DEBUG - 2010-07-08 15:33:52 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 15:33:52 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 15:33:53 --> Database Driver Class Initialized
DEBUG - 2010-07-08 15:33:53 --> Controller Class Initialized
DEBUG - 2010-07-08 15:33:53 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 15:33:54 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 15:33:54 --> Session Class Initialized
DEBUG - 2010-07-08 15:33:54 --> Helper loaded: string_helper
DEBUG - 2010-07-08 15:33:54 --> A session cookie was not found.
DEBUG - 2010-07-08 15:33:55 --> Session routines successfully run
DEBUG - 2010-07-08 15:33:55 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 15:33:55 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 15:33:55 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 15:33:56 --> Helper loaded: text_helper
DEBUG - 2010-07-08 15:33:56 --> Final output sent to browser
DEBUG - 2010-07-08 15:33:56 --> Total execution time: 5.9690
DEBUG - 2010-07-08 15:40:23 --> Config Class Initialized
DEBUG - 2010-07-08 15:40:24 --> Hooks Class Initialized
DEBUG - 2010-07-08 15:40:24 --> URI Class Initialized
DEBUG - 2010-07-08 15:40:24 --> Router Class Initialized
DEBUG - 2010-07-08 15:40:24 --> Output Class Initialized
DEBUG - 2010-07-08 15:40:25 --> Input Class Initialized
DEBUG - 2010-07-08 15:40:25 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 15:40:25 --> Language Class Initialized
DEBUG - 2010-07-08 15:40:26 --> Loader Class Initialized
DEBUG - 2010-07-08 15:40:26 --> Helper loaded: context_helper
DEBUG - 2010-07-08 15:40:26 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 15:40:27 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 15:40:27 --> Database Driver Class Initialized
DEBUG - 2010-07-08 15:40:27 --> Controller Class Initialized
DEBUG - 2010-07-08 15:40:27 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 15:40:28 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 15:40:28 --> Session Class Initialized
DEBUG - 2010-07-08 15:40:28 --> Helper loaded: string_helper
DEBUG - 2010-07-08 15:40:29 --> Session routines successfully run
DEBUG - 2010-07-08 15:40:29 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 15:40:29 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 15:40:29 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 15:40:30 --> Helper loaded: text_helper
DEBUG - 2010-07-08 15:40:30 --> Final output sent to browser
DEBUG - 2010-07-08 15:40:30 --> Total execution time: 6.1524
DEBUG - 2010-07-08 15:44:46 --> Config Class Initialized
DEBUG - 2010-07-08 15:44:46 --> Hooks Class Initialized
DEBUG - 2010-07-08 15:44:46 --> URI Class Initialized
DEBUG - 2010-07-08 15:44:46 --> Router Class Initialized
DEBUG - 2010-07-08 15:44:47 --> Output Class Initialized
DEBUG - 2010-07-08 15:44:47 --> Input Class Initialized
DEBUG - 2010-07-08 15:44:47 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 15:44:47 --> Language Class Initialized
DEBUG - 2010-07-08 15:44:48 --> Loader Class Initialized
DEBUG - 2010-07-08 15:44:48 --> Helper loaded: context_helper
DEBUG - 2010-07-08 15:44:48 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 15:44:48 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 15:44:49 --> Database Driver Class Initialized
DEBUG - 2010-07-08 15:44:49 --> Controller Class Initialized
DEBUG - 2010-07-08 15:44:49 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 15:44:50 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 15:44:50 --> Session Class Initialized
DEBUG - 2010-07-08 15:44:50 --> Helper loaded: string_helper
DEBUG - 2010-07-08 15:44:50 --> Session routines successfully run
DEBUG - 2010-07-08 15:44:51 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 15:44:51 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 15:44:51 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 15:44:51 --> Helper loaded: text_helper
DEBUG - 2010-07-08 15:44:52 --> Final output sent to browser
DEBUG - 2010-07-08 15:44:52 --> Total execution time: 5.6281
DEBUG - 2010-07-08 15:47:05 --> Config Class Initialized
DEBUG - 2010-07-08 15:47:06 --> Hooks Class Initialized
DEBUG - 2010-07-08 15:47:06 --> URI Class Initialized
DEBUG - 2010-07-08 15:47:06 --> Router Class Initialized
DEBUG - 2010-07-08 15:47:06 --> Output Class Initialized
DEBUG - 2010-07-08 15:47:07 --> Input Class Initialized
DEBUG - 2010-07-08 15:47:07 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 15:47:07 --> Language Class Initialized
DEBUG - 2010-07-08 15:47:07 --> Loader Class Initialized
DEBUG - 2010-07-08 15:47:08 --> Helper loaded: context_helper
DEBUG - 2010-07-08 15:47:08 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 15:47:08 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 15:47:09 --> Database Driver Class Initialized
DEBUG - 2010-07-08 15:47:09 --> Controller Class Initialized
DEBUG - 2010-07-08 15:47:09 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 15:47:09 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 15:47:10 --> Session Class Initialized
DEBUG - 2010-07-08 15:47:10 --> Helper loaded: string_helper
DEBUG - 2010-07-08 15:47:10 --> Session routines successfully run
DEBUG - 2010-07-08 15:47:11 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 15:47:11 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 15:47:11 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 15:47:11 --> Helper loaded: text_helper
DEBUG - 2010-07-08 15:47:12 --> Final output sent to browser
DEBUG - 2010-07-08 15:47:12 --> Total execution time: 5.7763
DEBUG - 2010-07-08 15:53:50 --> Config Class Initialized
DEBUG - 2010-07-08 15:53:51 --> Hooks Class Initialized
DEBUG - 2010-07-08 15:53:51 --> URI Class Initialized
DEBUG - 2010-07-08 15:53:51 --> Router Class Initialized
DEBUG - 2010-07-08 15:53:51 --> Output Class Initialized
DEBUG - 2010-07-08 15:53:52 --> Input Class Initialized
DEBUG - 2010-07-08 15:53:52 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 15:53:52 --> Language Class Initialized
DEBUG - 2010-07-08 15:53:53 --> Loader Class Initialized
DEBUG - 2010-07-08 15:53:53 --> Helper loaded: context_helper
DEBUG - 2010-07-08 15:53:53 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 15:53:53 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 15:53:54 --> Database Driver Class Initialized
DEBUG - 2010-07-08 15:53:54 --> Controller Class Initialized
DEBUG - 2010-07-08 15:53:54 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 15:53:55 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 15:53:55 --> Session Class Initialized
DEBUG - 2010-07-08 15:53:55 --> Helper loaded: string_helper
DEBUG - 2010-07-08 15:53:55 --> Session routines successfully run
DEBUG - 2010-07-08 15:53:56 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 15:53:56 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 15:53:56 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 15:53:57 --> Helper loaded: text_helper
DEBUG - 2010-07-08 15:53:57 --> Final output sent to browser
DEBUG - 2010-07-08 15:53:57 --> Total execution time: 5.8970
DEBUG - 2010-07-08 15:55:52 --> Config Class Initialized
DEBUG - 2010-07-08 15:55:52 --> Hooks Class Initialized
DEBUG - 2010-07-08 15:55:53 --> URI Class Initialized
DEBUG - 2010-07-08 15:55:53 --> Router Class Initialized
DEBUG - 2010-07-08 15:55:53 --> Output Class Initialized
DEBUG - 2010-07-08 15:55:53 --> Input Class Initialized
DEBUG - 2010-07-08 15:55:54 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 15:55:54 --> Language Class Initialized
DEBUG - 2010-07-08 15:55:54 --> Loader Class Initialized
DEBUG - 2010-07-08 15:55:54 --> Helper loaded: context_helper
DEBUG - 2010-07-08 15:55:55 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 15:55:55 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 15:55:55 --> Database Driver Class Initialized
DEBUG - 2010-07-08 15:55:56 --> Controller Class Initialized
DEBUG - 2010-07-08 15:55:56 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 15:55:56 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 15:55:56 --> Session Class Initialized
DEBUG - 2010-07-08 15:55:57 --> Helper loaded: string_helper
DEBUG - 2010-07-08 15:55:57 --> Session routines successfully run
DEBUG - 2010-07-08 15:55:57 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 15:55:57 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 15:55:58 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 15:55:58 --> Helper loaded: text_helper
DEBUG - 2010-07-08 15:55:58 --> Final output sent to browser
DEBUG - 2010-07-08 15:55:59 --> Total execution time: 5.7013
DEBUG - 2010-07-08 15:56:28 --> Config Class Initialized
DEBUG - 2010-07-08 15:56:28 --> Hooks Class Initialized
DEBUG - 2010-07-08 15:56:28 --> URI Class Initialized
DEBUG - 2010-07-08 15:56:29 --> Router Class Initialized
DEBUG - 2010-07-08 15:56:29 --> Output Class Initialized
DEBUG - 2010-07-08 15:56:29 --> Input Class Initialized
DEBUG - 2010-07-08 15:56:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 15:56:30 --> Language Class Initialized
DEBUG - 2010-07-08 15:56:30 --> Loader Class Initialized
DEBUG - 2010-07-08 15:56:30 --> Helper loaded: context_helper
DEBUG - 2010-07-08 15:56:30 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 15:56:31 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 15:56:31 --> Database Driver Class Initialized
DEBUG - 2010-07-08 15:56:31 --> Controller Class Initialized
DEBUG - 2010-07-08 15:56:32 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 15:56:32 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 15:56:32 --> Session Class Initialized
DEBUG - 2010-07-08 15:56:32 --> Helper loaded: string_helper
DEBUG - 2010-07-08 15:56:33 --> Session routines successfully run
DEBUG - 2010-07-08 15:56:33 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 15:56:33 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 15:56:34 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 15:56:34 --> Helper loaded: text_helper
DEBUG - 2010-07-08 15:56:34 --> Final output sent to browser
DEBUG - 2010-07-08 15:56:34 --> Total execution time: 5.8049
DEBUG - 2010-07-08 15:59:52 --> Config Class Initialized
DEBUG - 2010-07-08 15:59:53 --> Hooks Class Initialized
DEBUG - 2010-07-08 15:59:53 --> URI Class Initialized
DEBUG - 2010-07-08 15:59:53 --> Router Class Initialized
DEBUG - 2010-07-08 15:59:54 --> Output Class Initialized
DEBUG - 2010-07-08 15:59:54 --> Input Class Initialized
DEBUG - 2010-07-08 15:59:54 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 15:59:54 --> Language Class Initialized
DEBUG - 2010-07-08 15:59:55 --> Loader Class Initialized
DEBUG - 2010-07-08 15:59:55 --> Helper loaded: context_helper
DEBUG - 2010-07-08 15:59:55 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 15:59:55 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 15:59:56 --> Database Driver Class Initialized
DEBUG - 2010-07-08 15:59:56 --> Controller Class Initialized
DEBUG - 2010-07-08 15:59:56 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 15:59:57 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 15:59:57 --> Session Class Initialized
DEBUG - 2010-07-08 15:59:57 --> Helper loaded: string_helper
DEBUG - 2010-07-08 15:59:57 --> Session routines successfully run
DEBUG - 2010-07-08 15:59:58 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 15:59:58 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 15:59:58 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 15:59:59 --> Helper loaded: text_helper
DEBUG - 2010-07-08 15:59:59 --> Final output sent to browser
DEBUG - 2010-07-08 15:59:59 --> Total execution time: 5.8173
DEBUG - 2010-07-08 16:03:39 --> Config Class Initialized
DEBUG - 2010-07-08 16:03:39 --> Hooks Class Initialized
DEBUG - 2010-07-08 16:03:39 --> URI Class Initialized
DEBUG - 2010-07-08 16:03:40 --> Router Class Initialized
DEBUG - 2010-07-08 16:03:40 --> Output Class Initialized
DEBUG - 2010-07-08 16:03:40 --> Input Class Initialized
DEBUG - 2010-07-08 16:03:41 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 16:03:41 --> Language Class Initialized
DEBUG - 2010-07-08 16:03:41 --> Loader Class Initialized
DEBUG - 2010-07-08 16:03:41 --> Helper loaded: context_helper
DEBUG - 2010-07-08 16:03:42 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 16:03:42 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 16:03:42 --> Database Driver Class Initialized
DEBUG - 2010-07-08 16:03:43 --> Controller Class Initialized
DEBUG - 2010-07-08 16:03:43 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 16:03:43 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 16:03:43 --> Session Class Initialized
DEBUG - 2010-07-08 16:03:44 --> Helper loaded: string_helper
DEBUG - 2010-07-08 16:03:44 --> Session routines successfully run
DEBUG - 2010-07-08 16:03:44 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 16:03:45 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 16:03:45 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 16:03:45 --> Helper loaded: text_helper
DEBUG - 2010-07-08 16:03:45 --> Final output sent to browser
DEBUG - 2010-07-08 16:03:46 --> Total execution time: 5.8971
DEBUG - 2010-07-08 16:04:04 --> Config Class Initialized
DEBUG - 2010-07-08 16:04:04 --> Hooks Class Initialized
DEBUG - 2010-07-08 16:04:05 --> URI Class Initialized
DEBUG - 2010-07-08 16:04:05 --> Router Class Initialized
DEBUG - 2010-07-08 16:04:05 --> Output Class Initialized
DEBUG - 2010-07-08 16:04:05 --> Input Class Initialized
DEBUG - 2010-07-08 16:04:06 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 16:04:06 --> Language Class Initialized
DEBUG - 2010-07-08 16:04:06 --> Loader Class Initialized
DEBUG - 2010-07-08 16:04:06 --> Helper loaded: context_helper
DEBUG - 2010-07-08 16:04:07 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 16:04:07 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 16:04:07 --> Database Driver Class Initialized
DEBUG - 2010-07-08 16:04:08 --> Controller Class Initialized
DEBUG - 2010-07-08 16:04:08 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 16:04:08 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 16:04:08 --> Session Class Initialized
DEBUG - 2010-07-08 16:04:09 --> Helper loaded: string_helper
DEBUG - 2010-07-08 16:04:09 --> Session routines successfully run
DEBUG - 2010-07-08 16:04:09 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 16:04:09 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 16:04:10 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 16:04:10 --> Helper loaded: text_helper
DEBUG - 2010-07-08 16:04:10 --> Final output sent to browser
DEBUG - 2010-07-08 16:04:11 --> Total execution time: 5.7558
DEBUG - 2010-07-08 16:04:22 --> Config Class Initialized
DEBUG - 2010-07-08 16:04:23 --> Hooks Class Initialized
DEBUG - 2010-07-08 16:04:23 --> URI Class Initialized
DEBUG - 2010-07-08 16:04:23 --> Router Class Initialized
DEBUG - 2010-07-08 16:04:23 --> Output Class Initialized
DEBUG - 2010-07-08 16:04:24 --> Input Class Initialized
DEBUG - 2010-07-08 16:04:24 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 16:04:24 --> Language Class Initialized
DEBUG - 2010-07-08 16:04:25 --> Loader Class Initialized
DEBUG - 2010-07-08 16:04:25 --> Helper loaded: context_helper
DEBUG - 2010-07-08 16:04:25 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 16:04:25 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 16:04:26 --> Database Driver Class Initialized
DEBUG - 2010-07-08 16:04:26 --> Controller Class Initialized
DEBUG - 2010-07-08 16:04:26 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 16:04:27 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 16:04:27 --> Session Class Initialized
DEBUG - 2010-07-08 16:04:27 --> Helper loaded: string_helper
DEBUG - 2010-07-08 16:04:27 --> Session routines successfully run
DEBUG - 2010-07-08 16:04:28 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 16:04:28 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 16:04:28 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 16:04:28 --> Helper loaded: text_helper
DEBUG - 2010-07-08 16:04:29 --> Final output sent to browser
DEBUG - 2010-07-08 16:04:29 --> Total execution time: 5.8451
DEBUG - 2010-07-08 16:06:10 --> Config Class Initialized
DEBUG - 2010-07-08 16:06:10 --> Hooks Class Initialized
DEBUG - 2010-07-08 16:06:10 --> URI Class Initialized
DEBUG - 2010-07-08 16:06:11 --> Router Class Initialized
DEBUG - 2010-07-08 16:06:11 --> Output Class Initialized
DEBUG - 2010-07-08 16:06:11 --> Input Class Initialized
DEBUG - 2010-07-08 16:06:11 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 16:06:12 --> Language Class Initialized
DEBUG - 2010-07-08 16:06:12 --> Loader Class Initialized
DEBUG - 2010-07-08 16:06:12 --> Helper loaded: context_helper
DEBUG - 2010-07-08 16:06:13 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 16:06:13 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 16:06:13 --> Database Driver Class Initialized
DEBUG - 2010-07-08 16:06:13 --> Controller Class Initialized
DEBUG - 2010-07-08 16:06:14 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 16:06:14 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 16:06:14 --> Session Class Initialized
DEBUG - 2010-07-08 16:06:14 --> Helper loaded: string_helper
DEBUG - 2010-07-08 16:06:15 --> Session routines successfully run
DEBUG - 2010-07-08 16:06:15 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 16:06:15 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 16:06:16 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 16:06:16 --> Helper loaded: text_helper
DEBUG - 2010-07-08 16:06:16 --> Final output sent to browser
DEBUG - 2010-07-08 16:06:16 --> Total execution time: 5.8093
DEBUG - 2010-07-08 16:11:02 --> Config Class Initialized
DEBUG - 2010-07-08 16:11:02 --> Hooks Class Initialized
DEBUG - 2010-07-08 16:11:02 --> URI Class Initialized
DEBUG - 2010-07-08 16:11:03 --> Router Class Initialized
DEBUG - 2010-07-08 16:11:03 --> Output Class Initialized
DEBUG - 2010-07-08 16:11:03 --> Input Class Initialized
DEBUG - 2010-07-08 16:11:03 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 16:11:04 --> Language Class Initialized
DEBUG - 2010-07-08 16:11:04 --> Loader Class Initialized
DEBUG - 2010-07-08 16:11:04 --> Helper loaded: context_helper
DEBUG - 2010-07-08 16:11:05 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 16:11:05 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 16:11:05 --> Database Driver Class Initialized
DEBUG - 2010-07-08 16:11:05 --> Controller Class Initialized
DEBUG - 2010-07-08 16:11:06 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 16:11:06 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 16:11:06 --> Session Class Initialized
DEBUG - 2010-07-08 16:11:07 --> Helper loaded: string_helper
DEBUG - 2010-07-08 16:11:07 --> Session routines successfully run
DEBUG - 2010-07-08 16:11:07 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 16:11:07 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 16:11:08 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 16:11:08 --> Helper loaded: text_helper
DEBUG - 2010-07-08 16:11:08 --> Final output sent to browser
DEBUG - 2010-07-08 16:11:09 --> Total execution time: 5.8757
DEBUG - 2010-07-08 16:12:02 --> Config Class Initialized
DEBUG - 2010-07-08 16:12:02 --> Hooks Class Initialized
DEBUG - 2010-07-08 16:12:02 --> URI Class Initialized
DEBUG - 2010-07-08 16:12:03 --> Router Class Initialized
DEBUG - 2010-07-08 16:12:03 --> Output Class Initialized
DEBUG - 2010-07-08 16:12:03 --> Input Class Initialized
DEBUG - 2010-07-08 16:12:03 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 16:12:04 --> Language Class Initialized
DEBUG - 2010-07-08 16:12:04 --> Loader Class Initialized
DEBUG - 2010-07-08 16:12:04 --> Helper loaded: context_helper
DEBUG - 2010-07-08 16:12:04 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 16:12:05 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 16:12:05 --> Database Driver Class Initialized
DEBUG - 2010-07-08 16:12:05 --> Controller Class Initialized
DEBUG - 2010-07-08 16:12:06 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 16:12:06 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 16:12:06 --> Session Class Initialized
DEBUG - 2010-07-08 16:12:06 --> Helper loaded: string_helper
DEBUG - 2010-07-08 16:12:07 --> Session routines successfully run
DEBUG - 2010-07-08 16:12:07 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 16:12:07 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 16:12:08 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 16:12:08 --> Helper loaded: text_helper
DEBUG - 2010-07-08 16:12:08 --> Final output sent to browser
DEBUG - 2010-07-08 16:12:08 --> Total execution time: 5.7828
DEBUG - 2010-07-08 16:12:16 --> Config Class Initialized
DEBUG - 2010-07-08 16:12:16 --> Hooks Class Initialized
DEBUG - 2010-07-08 16:12:16 --> URI Class Initialized
DEBUG - 2010-07-08 16:12:17 --> Router Class Initialized
DEBUG - 2010-07-08 16:12:17 --> Output Class Initialized
DEBUG - 2010-07-08 16:12:17 --> Input Class Initialized
DEBUG - 2010-07-08 16:12:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 16:12:18 --> Language Class Initialized
DEBUG - 2010-07-08 16:12:18 --> Loader Class Initialized
DEBUG - 2010-07-08 16:12:18 --> Helper loaded: context_helper
DEBUG - 2010-07-08 16:12:18 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 16:12:19 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 16:12:19 --> Database Driver Class Initialized
DEBUG - 2010-07-08 16:12:19 --> Controller Class Initialized
DEBUG - 2010-07-08 16:12:20 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 16:12:20 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 16:12:20 --> Session Class Initialized
DEBUG - 2010-07-08 16:12:20 --> Helper loaded: string_helper
DEBUG - 2010-07-08 16:12:21 --> Session routines successfully run
DEBUG - 2010-07-08 16:12:21 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 16:12:21 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 16:12:22 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 16:12:22 --> Helper loaded: text_helper
DEBUG - 2010-07-08 16:12:22 --> Final output sent to browser
DEBUG - 2010-07-08 16:12:22 --> Total execution time: 5.7965
DEBUG - 2010-07-08 16:12:44 --> Config Class Initialized
DEBUG - 2010-07-08 16:12:44 --> Hooks Class Initialized
DEBUG - 2010-07-08 16:12:45 --> URI Class Initialized
DEBUG - 2010-07-08 16:12:45 --> Router Class Initialized
DEBUG - 2010-07-08 16:12:45 --> Output Class Initialized
DEBUG - 2010-07-08 16:12:45 --> Input Class Initialized
DEBUG - 2010-07-08 16:12:46 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 16:12:46 --> Language Class Initialized
DEBUG - 2010-07-08 16:12:46 --> Loader Class Initialized
DEBUG - 2010-07-08 16:12:47 --> Helper loaded: context_helper
DEBUG - 2010-07-08 16:12:47 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 16:12:47 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 16:12:47 --> Database Driver Class Initialized
DEBUG - 2010-07-08 16:12:48 --> Controller Class Initialized
DEBUG - 2010-07-08 16:12:48 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 16:12:48 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 16:12:48 --> Session Class Initialized
DEBUG - 2010-07-08 16:12:49 --> Helper loaded: string_helper
DEBUG - 2010-07-08 16:12:49 --> Session routines successfully run
DEBUG - 2010-07-08 16:12:49 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 16:12:50 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 16:12:50 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 16:12:50 --> Helper loaded: text_helper
DEBUG - 2010-07-08 16:12:50 --> Final output sent to browser
DEBUG - 2010-07-08 16:12:51 --> Total execution time: 5.8057
DEBUG - 2010-07-08 16:13:25 --> Config Class Initialized
DEBUG - 2010-07-08 16:13:26 --> Hooks Class Initialized
DEBUG - 2010-07-08 16:13:26 --> URI Class Initialized
DEBUG - 2010-07-08 16:13:26 --> Router Class Initialized
DEBUG - 2010-07-08 16:13:27 --> Output Class Initialized
DEBUG - 2010-07-08 16:13:27 --> Input Class Initialized
DEBUG - 2010-07-08 16:13:27 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 16:13:27 --> Language Class Initialized
DEBUG - 2010-07-08 16:13:28 --> Loader Class Initialized
DEBUG - 2010-07-08 16:13:28 --> Helper loaded: context_helper
DEBUG - 2010-07-08 16:13:28 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 16:13:29 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 16:13:29 --> Database Driver Class Initialized
DEBUG - 2010-07-08 16:13:29 --> Controller Class Initialized
DEBUG - 2010-07-08 16:13:29 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 16:13:30 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 16:13:30 --> Session Class Initialized
DEBUG - 2010-07-08 16:13:30 --> Helper loaded: string_helper
DEBUG - 2010-07-08 16:13:30 --> Session routines successfully run
DEBUG - 2010-07-08 16:13:31 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 16:13:31 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 16:13:31 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 16:13:32 --> Helper loaded: text_helper
DEBUG - 2010-07-08 16:13:32 --> Final output sent to browser
DEBUG - 2010-07-08 16:13:32 --> Total execution time: 5.8243
DEBUG - 2010-07-08 16:14:54 --> Config Class Initialized
DEBUG - 2010-07-08 16:14:54 --> Hooks Class Initialized
DEBUG - 2010-07-08 16:14:55 --> URI Class Initialized
DEBUG - 2010-07-08 16:14:55 --> Router Class Initialized
DEBUG - 2010-07-08 16:14:55 --> Output Class Initialized
DEBUG - 2010-07-08 16:14:55 --> Input Class Initialized
DEBUG - 2010-07-08 16:14:56 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 16:14:56 --> Language Class Initialized
DEBUG - 2010-07-08 16:14:56 --> Loader Class Initialized
DEBUG - 2010-07-08 16:14:57 --> Helper loaded: context_helper
DEBUG - 2010-07-08 16:14:57 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 16:14:57 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 16:14:57 --> Database Driver Class Initialized
DEBUG - 2010-07-08 16:14:58 --> Controller Class Initialized
DEBUG - 2010-07-08 16:14:58 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 16:14:58 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 16:14:58 --> Session Class Initialized
DEBUG - 2010-07-08 16:14:59 --> Helper loaded: string_helper
DEBUG - 2010-07-08 16:14:59 --> Session routines successfully run
DEBUG - 2010-07-08 16:14:59 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 16:15:00 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 16:15:00 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 16:15:00 --> Helper loaded: text_helper
DEBUG - 2010-07-08 16:15:00 --> Final output sent to browser
DEBUG - 2010-07-08 16:15:01 --> Total execution time: 5.8548
DEBUG - 2010-07-08 16:16:33 --> Config Class Initialized
DEBUG - 2010-07-08 16:16:33 --> Hooks Class Initialized
DEBUG - 2010-07-08 16:16:33 --> URI Class Initialized
DEBUG - 2010-07-08 16:16:34 --> Router Class Initialized
DEBUG - 2010-07-08 16:16:34 --> Output Class Initialized
DEBUG - 2010-07-08 16:16:34 --> Input Class Initialized
DEBUG - 2010-07-08 16:16:34 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 16:16:35 --> Language Class Initialized
DEBUG - 2010-07-08 16:16:35 --> Loader Class Initialized
DEBUG - 2010-07-08 16:16:35 --> Helper loaded: context_helper
DEBUG - 2010-07-08 16:16:36 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 16:16:36 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 16:16:36 --> Database Driver Class Initialized
DEBUG - 2010-07-08 16:16:36 --> Controller Class Initialized
DEBUG - 2010-07-08 16:16:37 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 16:16:37 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 16:16:37 --> Session Class Initialized
DEBUG - 2010-07-08 16:16:38 --> Helper loaded: string_helper
DEBUG - 2010-07-08 16:16:38 --> Session routines successfully run
DEBUG - 2010-07-08 16:16:38 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 16:16:38 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 16:16:39 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 16:16:39 --> Helper loaded: text_helper
DEBUG - 2010-07-08 16:16:39 --> Final output sent to browser
DEBUG - 2010-07-08 16:16:40 --> Total execution time: 5.8796
DEBUG - 2010-07-08 16:17:16 --> Config Class Initialized
DEBUG - 2010-07-08 16:17:16 --> Hooks Class Initialized
DEBUG - 2010-07-08 16:17:17 --> URI Class Initialized
DEBUG - 2010-07-08 16:17:17 --> Router Class Initialized
DEBUG - 2010-07-08 16:17:17 --> Output Class Initialized
DEBUG - 2010-07-08 16:17:17 --> Input Class Initialized
DEBUG - 2010-07-08 16:17:18 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 16:17:18 --> Language Class Initialized
DEBUG - 2010-07-08 16:17:18 --> Loader Class Initialized
DEBUG - 2010-07-08 16:17:18 --> Helper loaded: context_helper
DEBUG - 2010-07-08 16:17:19 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 16:17:19 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 16:17:19 --> Database Driver Class Initialized
DEBUG - 2010-07-08 16:17:20 --> Controller Class Initialized
DEBUG - 2010-07-08 16:17:20 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 16:17:20 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 16:17:20 --> Session Class Initialized
DEBUG - 2010-07-08 16:17:21 --> Helper loaded: string_helper
DEBUG - 2010-07-08 16:17:21 --> Session routines successfully run
DEBUG - 2010-07-08 16:17:21 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 16:17:22 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 16:17:22 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 16:17:22 --> Helper loaded: text_helper
DEBUG - 2010-07-08 16:17:22 --> Final output sent to browser
DEBUG - 2010-07-08 16:17:23 --> Total execution time: 5.8840
DEBUG - 2010-07-08 16:17:35 --> Config Class Initialized
DEBUG - 2010-07-08 16:17:35 --> Hooks Class Initialized
DEBUG - 2010-07-08 16:17:35 --> URI Class Initialized
DEBUG - 2010-07-08 16:17:36 --> Router Class Initialized
DEBUG - 2010-07-08 16:17:36 --> Output Class Initialized
DEBUG - 2010-07-08 16:17:36 --> Input Class Initialized
DEBUG - 2010-07-08 16:17:37 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 16:17:37 --> Language Class Initialized
DEBUG - 2010-07-08 16:17:37 --> Loader Class Initialized
DEBUG - 2010-07-08 16:17:37 --> Helper loaded: context_helper
DEBUG - 2010-07-08 16:17:38 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 16:17:38 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 16:17:38 --> Database Driver Class Initialized
DEBUG - 2010-07-08 16:17:38 --> Controller Class Initialized
DEBUG - 2010-07-08 16:17:39 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 16:17:39 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 16:17:39 --> Session Class Initialized
DEBUG - 2010-07-08 16:17:40 --> Helper loaded: string_helper
DEBUG - 2010-07-08 16:17:40 --> Session routines successfully run
DEBUG - 2010-07-08 16:17:40 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 16:17:40 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 16:17:41 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 16:17:41 --> Helper loaded: text_helper
DEBUG - 2010-07-08 16:17:41 --> Final output sent to browser
DEBUG - 2010-07-08 16:17:42 --> Total execution time: 5.8576
DEBUG - 2010-07-08 16:18:02 --> Config Class Initialized
DEBUG - 2010-07-08 16:18:02 --> Hooks Class Initialized
DEBUG - 2010-07-08 16:18:03 --> URI Class Initialized
DEBUG - 2010-07-08 16:18:03 --> Router Class Initialized
DEBUG - 2010-07-08 16:18:03 --> Output Class Initialized
DEBUG - 2010-07-08 16:18:04 --> Input Class Initialized
DEBUG - 2010-07-08 16:18:04 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 16:18:04 --> Language Class Initialized
DEBUG - 2010-07-08 16:18:04 --> Loader Class Initialized
DEBUG - 2010-07-08 16:18:05 --> Helper loaded: context_helper
DEBUG - 2010-07-08 16:18:05 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 16:18:05 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 16:18:06 --> Database Driver Class Initialized
DEBUG - 2010-07-08 16:18:06 --> Controller Class Initialized
DEBUG - 2010-07-08 16:18:06 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 16:18:06 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 16:18:07 --> Session Class Initialized
DEBUG - 2010-07-08 16:18:07 --> Helper loaded: string_helper
DEBUG - 2010-07-08 16:18:07 --> Session routines successfully run
DEBUG - 2010-07-08 16:18:07 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 16:18:08 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 16:18:08 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 16:18:08 --> Helper loaded: text_helper
DEBUG - 2010-07-08 16:18:09 --> Final output sent to browser
DEBUG - 2010-07-08 16:18:09 --> Total execution time: 5.9016
DEBUG - 2010-07-08 16:19:03 --> Config Class Initialized
DEBUG - 2010-07-08 16:19:03 --> Hooks Class Initialized
DEBUG - 2010-07-08 16:19:03 --> URI Class Initialized
DEBUG - 2010-07-08 16:19:04 --> Router Class Initialized
DEBUG - 2010-07-08 16:19:04 --> Output Class Initialized
DEBUG - 2010-07-08 16:19:04 --> Input Class Initialized
DEBUG - 2010-07-08 16:19:05 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-08 16:19:05 --> Language Class Initialized
DEBUG - 2010-07-08 16:19:05 --> Loader Class Initialized
DEBUG - 2010-07-08 16:19:05 --> Helper loaded: context_helper
DEBUG - 2010-07-08 16:19:06 --> Helper loaded: kals_helper
DEBUG - 2010-07-08 16:19:06 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-08 16:19:06 --> Database Driver Class Initialized
DEBUG - 2010-07-08 16:19:07 --> Controller Class Initialized
DEBUG - 2010-07-08 16:19:07 --> Unit Testing Class Initialized
DEBUG - 2010-07-08 16:19:07 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-08 16:19:07 --> Session Class Initialized
DEBUG - 2010-07-08 16:19:08 --> Helper loaded: string_helper
DEBUG - 2010-07-08 16:19:08 --> Session routines successfully run
DEBUG - 2010-07-08 16:19:08 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-08 16:19:09 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-08 16:19:09 --> Language file loaded: language/zh_tw/profiler_lang.php
DEBUG - 2010-07-08 16:19:09 --> Helper loaded: text_helper
DEBUG - 2010-07-08 16:19:09 --> Final output sent to browser
DEBUG - 2010-07-08 16:19:10 --> Total execution time: 6.0821
