<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-07-14 05:00:30 --> Severity: 4096  --> Argument 1 passed to Search_collection::set_target_user() must be an instance of User, integer given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_search\ut_search.php on line 32 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\search\Search_collection.php 377
ERROR - 2010-07-14 05:10:05 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;WHERE&quot;
LINE 5: WHERE &quot;policy2actor&quot;.&quot;actor_id&quot; IS NULL
        ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-14 05:10:05 --> Query error: ERROR:  syntax error at or near "WHERE"
LINE 5: WHERE "policy2actor"."actor_id" IS NULL
        ^
ERROR - 2010-07-14 05:10:52 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;policy2actor_type_id&quot; does not exist
LINE 4: ...icy&quot;.&quot;policy_id&quot; = &quot;policy2actor&quot;.&quot;policy_id&quot; AND policy2act...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-14 05:10:52 --> Query error: ERROR:  column "policy2actor_type_id" does not exist
LINE 4: ...icy"."policy_id" = "policy2actor"."policy_id" AND policy2act...
                                                             ^
ERROR - 2010-07-14 05:11:15 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column policy2actor.type_id does not exist
LINE 4: ...icy&quot;.&quot;policy_id&quot; = &quot;policy2actor&quot;.&quot;policy_id&quot; AND policy2act...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-14 05:11:15 --> Query error: ERROR:  column policy2actor.type_id does not exist
LINE 4: ...icy"."policy_id" = "policy2actor"."policy_id" AND policy2act...
                                                             ^
ERROR - 2010-07-14 05:11:27 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  missing FROM-clause entry for table &quot;annotaiton&quot;
LINE 1: SELECT DISTINCT &quot;annotaiton&quot;.*
                        ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-14 05:11:27 --> Query error: ERROR:  missing FROM-clause entry for table "annotaiton"
LINE 1: SELECT DISTINCT "annotaiton".*
                        ^
ERROR - 2010-07-14 05:11:33 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  missing FROM-clause entry for table &quot;annotaiton&quot;
LINE 1: SELECT DISTINCT &quot;annotaiton&quot;.*
                        ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-14 05:11:33 --> Query error: ERROR:  missing FROM-clause entry for table "annotaiton"
LINE 1: SELECT DISTINCT "annotaiton".*
                        ^
ERROR - 2010-07-14 06:38:38 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/072b030ba126b2f4b2374f342be9ed44) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-14 06:55:15 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/34173cb38f07f89ddbebc2ac9128303f) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-14 07:05:25 --> Severity: 4096  --> Argument 1 passed to Search_collection::set_target_user() must be an instance of User, none given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_search\ut_search.php on line 53 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\search\Search_collection.php 379
ERROR - 2010-07-14 07:05:25 --> Severity: Warning  --> Missing argument 1 for Search_collection::set_target_user(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_search\ut_search.php on line 53 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\search\Search_collection.php 379
ERROR - 2010-07-14 07:05:25 --> Severity: Notice  --> Undefined variable: user D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\search\Search_collection.php 381
ERROR - 2010-07-14 07:05:49 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/a3f390d88e4c41f2747bfa2f1b5f87db) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-14 07:30:40 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 118
ERROR - 2010-07-14 07:30:40 --> Severity: Warning  --> Illegal offset type in isset or empty D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 174
ERROR - 2010-07-14 07:30:40 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 118
ERROR - 2010-07-14 07:31:39 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 118
ERROR - 2010-07-14 07:31:39 --> Severity: Warning  --> Illegal offset type in isset or empty D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 174
ERROR - 2010-07-14 07:31:39 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 118
ERROR - 2010-07-14 07:31:51 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 118
ERROR - 2010-07-14 07:31:51 --> Severity: Warning  --> Illegal offset type in isset or empty D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 174
ERROR - 2010-07-14 07:31:51 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 118
ERROR - 2010-07-14 07:31:52 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 118
ERROR - 2010-07-14 07:31:52 --> Severity: Warning  --> Illegal offset type in isset or empty D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 174
ERROR - 2010-07-14 07:31:52 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 118
ERROR - 2010-07-14 07:32:00 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 118
ERROR - 2010-07-14 07:32:00 --> Severity: Warning  --> Illegal offset type in isset or empty D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 174
ERROR - 2010-07-14 07:32:00 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 118
ERROR - 2010-07-14 07:32:49 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 118
ERROR - 2010-07-14 07:32:49 --> Severity: Warning  --> Illegal offset type in isset or empty D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 174
ERROR - 2010-07-14 07:32:49 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 118
ERROR - 2010-07-14 07:33:19 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 118
ERROR - 2010-07-14 07:33:19 --> Severity: Warning  --> Illegal offset type in isset or empty D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 174
ERROR - 2010-07-14 07:33:19 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 118
ERROR - 2010-07-14 07:34:30 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 118
ERROR - 2010-07-14 07:34:30 --> Severity: Warning  --> Illegal offset type in isset or empty D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 175
ERROR - 2010-07-14 07:34:30 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 118
ERROR - 2010-07-14 07:35:06 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 118
ERROR - 2010-07-14 07:35:06 --> Severity: Warning  --> Illegal offset type in isset or empty D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 175
ERROR - 2010-07-14 07:35:06 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 118
ERROR - 2010-07-14 07:35:48 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 118
ERROR - 2010-07-14 07:35:48 --> Severity: Warning  --> Illegal offset type in isset or empty D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 175
ERROR - 2010-07-14 07:35:48 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 118
ERROR - 2010-07-14 07:36:43 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 118
ERROR - 2010-07-14 07:36:43 --> Severity: Warning  --> Illegal offset type in isset or empty D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 175
ERROR - 2010-07-14 07:36:43 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 118
ERROR - 2010-07-14 07:36:54 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 118
ERROR - 2010-07-14 07:36:54 --> Severity: Warning  --> Illegal offset type in isset or empty D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 175
ERROR - 2010-07-14 07:36:54 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 118
ERROR - 2010-07-14 07:37:50 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 118
ERROR - 2010-07-14 07:37:50 --> Severity: Warning  --> Illegal offset type in isset or empty D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 175
ERROR - 2010-07-14 07:37:50 --> Severity: Warning  --> Illegal offset type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 118
ERROR - 2010-07-14 07:39:40 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/14bfa6bb14875e45bba028a21ed38046) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-14 07:48:01 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column s0.scope does not exist
LINE 5: ...AND s0.from_index = 18 AND s0.to_index = 33 WHERE s0.scope I...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-14 07:48:01 --> Query error: ERROR:  column s0.scope does not exist
LINE 5: ...AND s0.from_index = 18 AND s0.to_index = 33 WHERE s0.scope I...
                                                             ^
ERROR - 2010-07-14 07:52:12 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;\&quot;
LINE 5: JOIN (\nSELECT DISTINCT a2s.annotation_id FROM annotation2sc...
              ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-14 07:52:12 --> Query error: ERROR:  syntax error at or near "\"
LINE 5: JOIN (\nSELECT DISTINCT a2s.annotation_id FROM annotation2sc...
              ^
ERROR - 2010-07-14 07:58:41 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/3ef815416f775098fe977004015c6193) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-14 10:30:03 --> Severity: Notice  --> Object of class Annotation could not be converted to int D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 156
ERROR - 2010-07-14 11:54:24 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/d67d8ab4f4c10bf22aa353e27879133c) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-14 12:06:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\KALS_object.php 29
ERROR - 2010-07-14 12:06:55 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\KALS_object.php 29
ERROR - 2010-07-14 12:07:01 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\KALS_object.php 29
ERROR - 2010-07-14 12:07:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\KALS_object.php 29
ERROR - 2010-07-14 12:07:57 --> Severity: Warning  --> in_array() [<a href='function.in-array'>function.in-array</a>]: Wrong datatype for second argument D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 365
ERROR - 2010-07-14 12:58:03 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  operator does not exist: scope = integer
LINE 6: ..._annotation2scope&quot;.&quot;scope_id&quot; AND overlap_scope_0 = 138 AND ...
                                                             ^
HINT:  No operator matches the given name and argument type(s). You might need to add explicit type casts. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-14 12:58:03 --> Query error: ERROR:  operator does not exist: scope = integer
LINE 6: ..._annotation2scope"."scope_id" AND overlap_scope_0 = 138 AND ...
                                                             ^
HINT:  No operator matches the given name and argument type(s). You might need to add explicit type casts.
ERROR - 2010-07-14 13:10:43 --> Severity: Notice  --> Undefined property: Search_annotation_collection::$annotation_type_factory D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\search\Search_collection.php 394
ERROR - 2010-07-14 13:25:46 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  missing FROM-clause entry for table &quot;scope&quot;
LINE 1: SELECT DISTINCT &quot;scope&quot;.*
                        ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-14 13:25:46 --> Query error: ERROR:  missing FROM-clause entry for table "scope"
LINE 1: SELECT DISTINCT "scope".*
                        ^
ERROR - 2010-07-14 13:31:08 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;搜尋錯誤&quot; does not exist
LINE 7: AND annotation.note_index @@ to_tsquery(搜尋錯誤)
                                                ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-14 13:31:08 --> Query error: ERROR:  column "搜尋錯誤" does not exist
LINE 7: AND annotation.note_index @@ to_tsquery(搜尋錯誤)
                                                ^
ERROR - 2010-07-14 13:36:37 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid reference to FROM-clause entry for table &quot;annotation&quot;
LINE 3: LEFT JOIN &quot;policy&quot; ON &quot;policy&quot;.&quot;resource_id&quot; = &quot;annotation&quot;....
                                                       ^
HINT:  There is an entry for table &quot;annotation&quot;, but it cannot be referenced from this part of the query. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-14 13:36:37 --> Query error: ERROR:  invalid reference to FROM-clause entry for table "annotation"
LINE 3: LEFT JOIN "policy" ON "policy"."resource_id" = "annotation"....
                                                       ^
HINT:  There is an entry for table "annotation", but it cannot be referenced from this part of the query.
ERROR - 2010-07-14 13:36:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:393) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-14 13:36:48 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid reference to FROM-clause entry for table &quot;annotation&quot;
LINE 3: LEFT JOIN &quot;policy&quot; ON &quot;policy&quot;.&quot;resource_id&quot; = &quot;annotation&quot;....
                                                       ^
HINT:  There is an entry for table &quot;annotation&quot;, but it cannot be referenced from this part of the query. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-14 13:36:48 --> Query error: ERROR:  invalid reference to FROM-clause entry for table "annotation"
LINE 3: LEFT JOIN "policy" ON "policy"."resource_id" = "annotation"....
                                                       ^
HINT:  There is an entry for table "annotation", but it cannot be referenced from this part of the query.
ERROR - 2010-07-14 13:36:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:393) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-14 13:53:39 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;搜尋&quot; does not exist
LINE 5: ...ON &quot;search_anchor_text&quot;.&quot;indexed&quot; @@ to_tsquery(( 搜尋 ) | (...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-14 13:53:39 --> Query error: ERROR:  column "搜尋" does not exist
LINE 5: ...ON "search_anchor_text"."indexed" @@ to_tsquery(( 搜尋 ) | (...
                                                             ^
ERROR - 2010-07-14 14:13:34 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column order_score.annotation_di does not exist
LINE 4: JOIN &quot;score&quot; AS order_score ON &quot;order_score&quot;.&quot;annotation_di&quot;...
                                       ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-14 14:13:34 --> Query error: ERROR:  column order_score.annotation_di does not exist
LINE 4: JOIN "score" AS order_score ON "order_score"."annotation_di"...
                                       ^
ERROR - 2010-07-14 14:15:03 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  missing FROM-clause entry for table &quot;order_scroe&quot;
LINE 4: ...annotation_id&quot; = &quot;annotation&quot;.&quot;annotation_id&quot; AND order_scro...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-14 14:15:03 --> Query error: ERROR:  missing FROM-clause entry for table "order_scroe"
LINE 4: ...annotation_id" = "annotation"."annotation_id" AND order_scro...
                                                             ^
ERROR - 2010-07-14 14:15:20 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  missing FROM-clause entry for table &quot;order_scroe&quot;
LINE 6: ORDER BY &quot;order_scroe&quot;.&quot;score&quot; desc
                 ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-14 14:15:21 --> Query error: ERROR:  missing FROM-clause entry for table "order_scroe"
LINE 6: ORDER BY "order_scroe"."score" desc
                 ^
ERROR - 2010-07-14 14:15:30 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  for SELECT DISTINCT, ORDER BY expressions must appear in select list
LINE 6: ORDER BY &quot;order_score&quot;.&quot;score&quot; desc
                 ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-14 14:15:30 --> Query error: ERROR:  for SELECT DISTINCT, ORDER BY expressions must appear in select list
LINE 6: ORDER BY "order_score"."score" desc
                 ^
ERROR - 2010-07-14 14:34:42 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column order_respond.respond_count does not exist
LINE 1: SELECT DISTINCT &quot;order_respond&quot;.&quot;respond_count&quot;, &quot;annotation...
                        ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-14 14:34:42 --> Query error: ERROR:  column order_respond.respond_count does not exist
LINE 1: SELECT DISTINCT "order_respond"."respond_count", "annotation...
                        ^
ERROR - 2010-07-14 15:09:35 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/182be0c5cdcd5072bb1864cdee4d3d6e) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-14 15:09:58 --> Severity: Notice  --> Object of class Search_annotation_id_collection could not be converted to int D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Unit_test.php 156
ERROR - 2010-07-14 15:10:31 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;JOIN&quot;
LINE 2: JOIN (SELECT DISTINCT a2s.annotation_id FROM annotation2scop...
        ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-14 15:10:31 --> Query error: ERROR:  syntax error at or near "JOIN"
LINE 2: JOIN (SELECT DISTINCT a2s.annotation_id FROM annotation2scop...
        ^
ERROR - 2010-07-14 15:10:59 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;JOIN&quot;
LINE 2: JOIN (SELECT DISTINCT a2s.annotation_id FROM annotation2scop...
        ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-14 15:10:59 --> Query error: ERROR:  syntax error at or near "JOIN"
LINE 2: JOIN (SELECT DISTINCT a2s.annotation_id FROM annotation2scop...
        ^
ERROR - 2010-07-14 15:13:05 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;JOIN&quot;
LINE 2: JOIN (SELECT DISTINCT a2s.annotation_id FROM annotation2scop...
        ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-14 15:13:05 --> Query error: ERROR:  syntax error at or near "JOIN"
LINE 2: JOIN (SELECT DISTINCT a2s.annotation_id FROM annotation2scop...
        ^
ERROR - 2010-07-14 15:13:05 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:393) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-14 15:13:38 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;JOIN&quot;
LINE 2: JOIN (SELECT DISTINCT a2s.annotation_id FROM annotation2scop...
        ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-14 15:13:38 --> Query error: ERROR:  syntax error at or near "JOIN"
LINE 2: JOIN (SELECT DISTINCT a2s.annotation_id FROM annotation2scop...
        ^
ERROR - 2010-07-14 15:14:35 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;JOIN&quot;
LINE 2: JOIN (SELECT DISTINCT a2s.annotation_id FROM annotation2scop...
        ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-14 15:14:35 --> Query error: ERROR:  syntax error at or near "JOIN"
LINE 2: JOIN (SELECT DISTINCT a2s.annotation_id FROM annotation2scop...
        ^
ERROR - 2010-07-14 15:14:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:393) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-14 15:15:06 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/d1fe173d08e959397adf34b1d77e88d7) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-14 15:15:06 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;JOIN&quot;
LINE 2: JOIN (SELECT DISTINCT a2s.annotation_id FROM annotation2scop...
        ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-14 15:15:06 --> Query error: ERROR:  syntax error at or near "JOIN"
LINE 2: JOIN (SELECT DISTINCT a2s.annotation_id FROM annotation2scop...
        ^
ERROR - 2010-07-14 15:15:06 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:393) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-14 15:16:47 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;JOIN&quot;
LINE 2: JOIN (SELECT DISTINCT a2s.annotation_id FROM annotation2scop...
        ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-14 15:16:47 --> Query error: ERROR:  syntax error at or near "JOIN"
LINE 2: JOIN (SELECT DISTINCT a2s.annotation_id FROM annotation2scop...
        ^
ERROR - 2010-07-14 15:19:28 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/ac627ab1ccbdb62ec96e702f07f6425b) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-14 15:20:01 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/aab3238922bcc25a6f606eb525ffdc56) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-14 15:58:36 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/c16a5320fa475530d9583c34fd356ef5) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-14 15:59:04 --> Severity: Notice  --> Undefined index:  score D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_annotation.php 315
