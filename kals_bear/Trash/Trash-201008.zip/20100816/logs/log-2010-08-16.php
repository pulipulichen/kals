<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-08-16 03:23:54 --> Severity: Warning  --> chmod() [<a href='function.chmod'>function.chmod</a>]: No error D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 73
ERROR - 2010-08-16 03:23:54 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/c51ce410c124a10e0db5e4b97fc2af39) [<a href='function.unlink'>function.unlink</a>]: No such file or directory D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-08-16 03:38:01 --> The image you are attempting to upload exceedes the maximum height or width.
ERROR - 2010-08-16 06:15:34 --> Severity: Warning  --> Missing argument 1 for load_styles(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\views\qunit\helpers\ajax_upload.php on line 16 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\unit_test_helper.php 78
ERROR - 2010-08-16 06:15:34 --> Severity: Notice  --> Undefined variable: styles D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\unit_test_helper.php 80
ERROR - 2010-08-16 06:15:34 --> Severity: Notice  --> Undefined variable: styles D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\unit_test_helper.php 81
ERROR - 2010-08-16 06:15:36 --> Severity: Warning  --> Missing argument 1 for Web_apps_controller::pack_css() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\web_apps\web_apps_controller.php 98
ERROR - 2010-08-16 06:15:36 --> Severity: Notice  --> Undefined variable: path D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\web_apps\web_apps_controller.php 103
ERROR - 2010-08-16 06:15:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-08-16 07:07:51 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/f033ab37c30201f73f142449d037028d) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-08-16 07:15:26 --> Severity: Warning  --> Missing argument 1 for user_profile::edit_photo() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\web_apps\user_profile.php 265
ERROR - 2010-08-16 07:15:26 --> Severity: Warning  --> Missing argument 2 for user_profile::edit_photo() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\web_apps\user_profile.php 265
ERROR - 2010-08-16 07:15:26 --> Severity: Notice  --> Undefined variable: json D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\web_apps\user_profile.php 267
ERROR - 2010-08-16 07:15:26 --> The path to the image is not correct.
ERROR - 2010-08-16 07:15:26 --> Your server does not support the GD function required to process this type of image.
ERROR - 2010-08-16 07:15:26 --> <p>The path to the image is not correct.</p><p>Your server does not support the GD function required to process this type of image.</p>
ERROR - 2010-08-16 07:15:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-08-16 07:19:12 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 424
ERROR - 2010-08-16 07:20:01 --> The path to the image is not correct.
ERROR - 2010-08-16 07:20:01 --> Your server does not support the GD function required to process this type of image.
ERROR - 2010-08-16 07:20:01 --> <p>The path to the image is not correct.</p><p>Your server does not support the GD function required to process this type of image.</p>
ERROR - 2010-08-16 07:20:01 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:412) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-08-16 07:20:01 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:412) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-08-16 07:20:01 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:412) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-08-16 07:20:01 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:412) D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\errors\error_json.php 14
ERROR - 2010-08-16 07:20:01 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:412) D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\MY_Exceptions.php 36
ERROR - 2010-08-16 08:13:12 --> 404 Page Not Found --> web_apps/CodeIgniter_1.7.2
ERROR - 2010-08-16 08:18:10 --> 404 Page Not Found --> web_apps/CodeIgniter_1.7.2
ERROR - 2010-08-16 08:22:20 --> chech_login_domain_failed
ERROR - 2010-08-16 08:22:20 --> chech_login_domain_failed
ERROR - 2010-08-16 08:22:20 --> 404 Page Not Found --> web_apps/CodeIgniter_1.7.2
ERROR - 2010-08-16 08:22:25 --> 404 Page Not Found --> web_apps/CodeIgniter_1.7.2
