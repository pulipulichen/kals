<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-07-15 07:37:07 --> Severity: Notice  --> Undefined property: Ut_context::$user D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_core\ut_context.php 38
ERROR - 2010-07-15 07:37:47 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/f7177163c833dff4b38fc8d2872f1ec6) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-15 07:38:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:393) D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Session.php 662
ERROR - 2010-07-15 07:38:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:393) D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Session.php 662
ERROR - 2010-07-15 07:39:03 --> 404 Page Not Found --> ut_core/check_user
ERROR - 2010-07-15 07:40:20 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/e4da3b7fbbce2345d7772b0674a318d5) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-15 07:40:20 --> Severity: 4096  --> Argument 1 passed to set_context_user() must be an instance of User, null given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_core\ut_context.php on line 34 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 49
ERROR - 2010-07-15 07:40:20 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Session.php 662
ERROR - 2010-07-15 07:49:31 --> Severity: Notice  --> Undefined index:  score D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_annotation.php 315
ERROR - 2010-07-15 07:50:28 --> Severity: Warning  --> fopen(http://localhost/) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: �s�u���ե��ѡA�]���s�u��H���@�q�ɶ��å����T�^���A�άO�s�u�إߥ��ѡA�]���s�u���D���L�k�^���C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 205
ERROR - 2010-07-15 07:50:28 --> Severity: Warning  --> fread(): supplied argument is not a valid stream resource D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 206
ERROR - 2010-07-15 07:50:28 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 207
ERROR - 2010-07-15 07:51:28 --> Severity: Warning  --> fopen(http://localhost/CodeIgniter_1.7.2/index.php/unit_test) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: �s�u���ե��ѡA�]���s�u��H���@�q�ɶ��å����T�^���A�άO�s�u�إߥ��ѡA�]���s�u���D���L�k�^���C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 205
ERROR - 2010-07-15 07:51:28 --> Severity: Warning  --> fread(): supplied argument is not a valid stream resource D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 206
ERROR - 2010-07-15 07:51:28 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 207
ERROR - 2010-07-15 07:51:28 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Session.php 662
ERROR - 2010-07-15 07:51:28 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Session.php 662
ERROR - 2010-07-15 13:25:39 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  missing FROM-clause entry for table &quot;annotation&quot;
LINE 3: LEFT JOIN &quot;policy&quot; ON &quot;policy&quot;.&quot;resource_id&quot; = &quot;annotation&quot;....
                                                       ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-15 13:25:39 --> Query error: ERROR:  missing FROM-clause entry for table "annotation"
LINE 3: LEFT JOIN "policy" ON "policy"."resource_id" = "annotation"....
                                                       ^
ERROR - 2010-07-15 13:25:42 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  missing FROM-clause entry for table &quot;annotation&quot;
LINE 3: LEFT JOIN &quot;policy&quot; ON &quot;policy&quot;.&quot;resource_id&quot; = &quot;annotation&quot;....
                                                       ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-15 13:25:42 --> Query error: ERROR:  missing FROM-clause entry for table "annotation"
LINE 3: LEFT JOIN "policy" ON "policy"."resource_id" = "annotation"....
                                                       ^
ERROR - 2010-07-15 13:29:29 --> Severity: Notice  --> Undefined index:  score D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_annotation.php 315
ERROR - 2010-07-15 13:30:03 --> Severity: Notice  --> Undefined index:  score D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_annotation.php 315
