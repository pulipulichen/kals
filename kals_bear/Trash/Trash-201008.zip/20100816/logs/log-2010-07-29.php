<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-07-29 03:51:30 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/d3d9446802a44259755d38e6d163e820) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-29 04:41:10 --> Severity: Warning  --> chmod() [<a href='function.chmod'>function.chmod</a>]: No such file or directory D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 73
ERROR - 2010-07-29 04:41:10 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/a87ff679a2f3e71d9181a67b7542122c) [<a href='function.unlink'>function.unlink</a>]: No such file or directory D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-29 06:29:15 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/a87ff679a2f3e71d9181a67b7542122c) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-29 11:26:06 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-29 11:26:10 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-29 11:27:13 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-29 12:00:51 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/c0c7c76d30bd3dcaefc96f40275bdc0a) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-29 12:09:33 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/d2ddea18f00665ce8623e36bd4e3c7c5) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-29 12:22:52 --> 404 Page Not Found --> web_apps/g
ERROR - 2010-07-29 12:23:41 --> 404 Page Not Found --> web_apps/g
ERROR - 2010-07-29 12:23:41 --> 404 Page Not Found --> web_apps/g
ERROR - 2010-07-29 12:36:39 --> 404 Page Not Found --> web_apps/undefinedgeneral
ERROR - 2010-07-29 12:37:37 --> 404 Page Not Found --> web_apps/undefinedgeneral
ERROR - 2010-07-29 12:38:03 --> 404 Page Not Found --> web_apps/http:
ERROR - 2010-07-29 12:38:30 --> 404 Page Not Found --> web_apps/http:
ERROR - 2010-07-29 12:45:43 --> 404 Page Not Found --> web_apps/http:
ERROR - 2010-07-29 13:00:51 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/d82c8d1619ad8176d665453cfb2e55f0) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-29 15:01:43 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/d2ddea18f00665ce8623e36bd4e3c7c5) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-29 15:22:25 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/e369853df766fa44e1ed0ff613f563bd) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
