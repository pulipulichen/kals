<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-07-11 04:02:00 --> Severity: Notice  --> Undefined variable: annotaion D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_actor\ut_notification.php 111
ERROR - 2010-07-11 04:03:09 --> Severity: Notice  --> Undefined property: Ut_notification::$CI D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_actor\ut_notification.php 35
ERROR - 2010-07-11 04:03:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_actor\ut_notification.php 35
ERROR - 2010-07-11 04:03:09 --> Severity: Notice  --> Undefined property: Ut_notification::$CI D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_actor\ut_notification.php 37
ERROR - 2010-07-11 04:03:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_actor\ut_notification.php 37
ERROR - 2010-07-11 04:03:09 --> Severity: Notice  --> Undefined property: Ut_notification::$CI D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_actor\ut_notification.php 39
ERROR - 2010-07-11 04:03:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_actor\ut_notification.php 39
ERROR - 2010-07-11 04:03:25 --> Severity: Notice  --> Undefined index:   D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\KALS_actor.php 138
ERROR - 2010-07-11 04:04:17 --> Severity: Notice  --> Undefined index:  resource_actor_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 322
ERROR - 2010-07-11 04:04:17 --> Unable to load the requested class: kals_resource
ERROR - 2010-07-11 04:04:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-11 04:05:40 --> Severity: Notice  --> Undefined index:  resource_actor_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 322
ERROR - 2010-07-11 04:05:54 --> Severity: Notice  --> Undefined index:  resource_actor_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 322
ERROR - 2010-07-11 04:05:55 --> Severity: Notice  --> Undefined index:  resource_actor_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 322
ERROR - 2010-07-11 04:05:55 --> Severity: Notice  --> Undefined index:  resource_actor_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 322
ERROR - 2010-07-11 04:07:55 --> 
ERROR - 2010-07-11 04:08:23 --> generic_object.get_field.exception
ERROR - 2010-07-11 04:08:36 --> 沒有此欄位的資料
ERROR - 2010-07-11 04:09:52 --> 沒有此欄位的資料
ERROR - 2010-07-11 04:09:57 --> 嘗試取出Notification_liked物件的resource_actor_id欄位，但Notification_liked物件不存在resource_actor_id欄位
ERROR - 2010-07-11 04:15:06 --> Severity: Warning  --> Missing argument 1 for Generic_object::_has_unique_restriction(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php on line 550 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1066
ERROR - 2010-07-11 04:15:06 --> Severity: Notice  --> Undefined variable: unique_restriction D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1068
ERROR - 2010-07-11 04:15:06 --> Severity: Warning  --> Missing argument 1 for Generic_object::_has_unique_restriction(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php on line 550 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1066
ERROR - 2010-07-11 04:15:06 --> Severity: Notice  --> Undefined variable: unique_restriction D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1068
ERROR - 2010-07-11 04:15:06 --> Severity: Warning  --> Missing argument 1 for Generic_object::_has_unique_restriction(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php on line 550 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1066
ERROR - 2010-07-11 04:15:06 --> Severity: Notice  --> Undefined variable: unique_restriction D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1068
ERROR - 2010-07-11 04:15:06 --> Severity: Warning  --> Missing argument 1 for Generic_object::_has_unique_restriction(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php on line 550 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1066
ERROR - 2010-07-11 04:15:06 --> Severity: Notice  --> Undefined variable: unique_restriction D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1068
ERROR - 2010-07-11 04:15:06 --> Severity: Warning  --> Missing argument 1 for Generic_object::_has_unique_restriction(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php on line 550 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1066
ERROR - 2010-07-11 04:15:06 --> Severity: Notice  --> Undefined variable: unique_restriction D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1068
ERROR - 2010-07-11 04:15:06 --> Severity: Warning  --> Missing argument 1 for Generic_object::_has_unique_restriction(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php on line 550 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1066
ERROR - 2010-07-11 04:15:06 --> Severity: Notice  --> Undefined variable: unique_restriction D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1068
ERROR - 2010-07-11 04:15:06 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;notification_type_id&quot; of relation &quot;notification&quot; does not exist
LINE 1: ...trigger_resource_type_id&quot;, &quot;trigger_resource_id&quot;, &quot;notificat...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-11 04:15:06 --> Query error: ERROR:  column "notification_type_id" of relation "notification" does not exist
LINE 1: ...trigger_resource_type_id", "trigger_resource_id", "notificat...
                                                             ^
ERROR - 2010-07-11 04:15:06 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-11 04:15:25 --> Severity: Notice  --> Undefined variable: unique_restriction D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1068
ERROR - 2010-07-11 04:15:25 --> Severity: Notice  --> Undefined variable: unique_restriction D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1068
ERROR - 2010-07-11 04:15:25 --> Severity: Notice  --> Undefined variable: unique_restriction D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1068
ERROR - 2010-07-11 04:15:25 --> Severity: Notice  --> Undefined variable: unique_restriction D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1068
ERROR - 2010-07-11 04:15:26 --> Severity: Notice  --> Undefined variable: unique_restriction D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1068
ERROR - 2010-07-11 04:15:26 --> Severity: Notice  --> Undefined variable: unique_restriction D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1068
ERROR - 2010-07-11 04:15:26 --> Severity: Notice  --> Undefined variable: unique_restriction D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\toolkit\Generic_object.php 1068
ERROR - 2010-07-11 04:15:26 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  duplicate key value violates unique constraint &quot;anchor_text_text_key&quot; D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-11 04:15:26 --> Query error: ERROR:  duplicate key value violates unique constraint "anchor_text_text_key"
ERROR - 2010-07-11 04:15:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-11 04:17:13 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;notification_type_id&quot; of relation &quot;notification&quot; does not exist
LINE 1: ...trigger_resource_type_id&quot;, &quot;trigger_resource_id&quot;, &quot;notificat...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-11 04:17:13 --> Query error: ERROR:  column "notification_type_id" of relation "notification" does not exist
LINE 1: ...trigger_resource_type_id", "trigger_resource_id", "notificat...
                                                             ^
ERROR - 2010-07-11 06:00:18 --> Unable to load the requested class: annotation_score_integrated
ERROR - 2010-07-11 06:01:16 --> Unable to load the requested class: annotation_feature_locationannotation_feature_location
ERROR - 2010-07-11 06:01:34 --> Unable to load the requested class: annotation_score_integrated
ERROR - 2010-07-11 06:02:10 --> Unable to load the requested class: annotation_score_integrated
ERROR - 2010-07-11 06:02:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:387) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-11 06:22:20 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/a87ff679a2f3e71d9181a67b7542122c) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-11 07:57:38 --> Severity: Notice  --> Array to string conversion D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\DB_active_rec.php 906
ERROR - 2010-07-11 07:57:38 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;LIMIT&quot;
LINE 6: LIMIT 20
        ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-11 07:57:38 --> Query error: ERROR:  syntax error at or near "LIMIT"
LINE 6: LIMIT 20
        ^
ERROR - 2010-07-11 07:57:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-11 07:58:05 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;read&quot; is of type boolean but expression is of type integer
LINE 1: ...amp&quot; = '2010-07-11 07:58:05.000000 UTC', &quot;read&quot; = 1, &quot;associ...
                                                             ^
HINT:  You will need to rewrite or cast the expression. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-11 07:58:05 --> Query error: ERROR:  column "read" is of type boolean but expression is of type integer
LINE 1: ...amp" = '2010-07-11 07:58:05.000000 UTC', "read" = 1, "associ...
                                                             ^
HINT:  You will need to rewrite or cast the expression.
ERROR - 2010-07-11 08:50:40 --> Severity: 4096  --> Argument 2 passed to Notification::create_notification() must be an instance of KALSActor, instance of User given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_actor\ut_notification.php on line 76 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\Notification.php 171
ERROR - 2010-07-11 08:50:40 --> Severity: 4096  --> Argument 2 passed to Notification::create_notification() must be an instance of KALSActor, instance of User given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_actor\ut_notification.php on line 104 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\Notification.php 171
ERROR - 2010-07-11 08:50:40 --> Severity: 4096  --> Argument 2 passed to Notification::create_notification() must be an instance of KALSActor, instance of User given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_actor\ut_notification.php on line 128 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\Notification.php 171
ERROR - 2010-07-11 08:50:40 --> Severity: Notice  --> Undefined property: Ut_notification::$like D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_actor\ut_notification.php 161
ERROR - 2010-07-11 08:51:10 --> Severity: Notice  --> Undefined property: Ut_notification::$like D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_actor\ut_notification.php 161
ERROR - 2010-07-11 09:35:22 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/02e74f10e0327ad868d138f2b4fdd6f0) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
