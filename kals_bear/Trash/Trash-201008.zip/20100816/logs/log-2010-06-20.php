<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2010-06-20 17:06:37 --> Config Class Initialized
DEBUG - 2010-06-20 17:06:37 --> Hooks Class Initialized
DEBUG - 2010-06-20 17:06:37 --> URI Class Initialized
DEBUG - 2010-06-20 17:06:37 --> Router Class Initialized
DEBUG - 2010-06-20 17:06:37 --> Output Class Initialized
DEBUG - 2010-06-20 17:06:37 --> Input Class Initialized
DEBUG - 2010-06-20 17:06:37 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-20 17:06:37 --> Language Class Initialized
DEBUG - 2010-06-20 17:06:38 --> Loader Class Initialized
DEBUG - 2010-06-20 17:06:38 --> Controller Class Initialized
DEBUG - 2010-06-20 17:06:38 --> Unit Testing Class Initialized
DEBUG - 2010-06-20 17:06:38 --> Session Class Initialized
DEBUG - 2010-06-20 17:06:38 --> Helper loaded: string_helper
DEBUG - 2010-06-20 17:06:38 --> A session cookie was not found.
DEBUG - 2010-06-20 17:06:38 --> Session routines successfully run
DEBUG - 2010-06-20 17:06:38 --> Helper loaded: kals_helper
DEBUG - 2010-06-20 17:06:38 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-20 17:06:38 --> Database Driver Class Initialized
ERROR - 2010-06-20 17:06:38 --> Severity: Warning  --> pg_pconnect() [<a href='function.pg-pconnect'>function.pg-pconnect</a>]: Unable to connect to PostgreSQL server: FATAL:  database &quot;kals2010&quot; does not exist D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 99
ERROR - 2010-06-20 17:06:38 --> Unable to connect to the database
DEBUG - 2010-06-20 17:06:38 --> Language file loaded: language/english/db_lang.php
DEBUG - 2010-06-20 17:15:12 --> Config Class Initialized
DEBUG - 2010-06-20 17:15:12 --> Hooks Class Initialized
DEBUG - 2010-06-20 17:15:12 --> URI Class Initialized
DEBUG - 2010-06-20 17:15:12 --> Router Class Initialized
DEBUG - 2010-06-20 17:15:12 --> Output Class Initialized
DEBUG - 2010-06-20 17:15:13 --> Input Class Initialized
DEBUG - 2010-06-20 17:15:13 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-20 17:15:13 --> Language Class Initialized
DEBUG - 2010-06-20 17:15:13 --> Loader Class Initialized
DEBUG - 2010-06-20 17:15:13 --> Controller Class Initialized
DEBUG - 2010-06-20 17:15:13 --> Unit Testing Class Initialized
DEBUG - 2010-06-20 17:15:14 --> Session Class Initialized
DEBUG - 2010-06-20 17:15:14 --> Helper loaded: string_helper
DEBUG - 2010-06-20 17:15:14 --> Session routines successfully run
DEBUG - 2010-06-20 17:15:14 --> Helper loaded: kals_helper
DEBUG - 2010-06-20 17:15:14 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-20 17:15:15 --> Database Driver Class Initialized
ERROR - 2010-06-20 17:15:15 --> Severity: Warning  --> pg_pconnect() [<a href='function.pg-pconnect'>function.pg-pconnect</a>]: Unable to connect to PostgreSQL server: FATAL:  database &quot;kals2010&quot; does not exist D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 99
ERROR - 2010-06-20 17:15:15 --> Unable to connect to the database
DEBUG - 2010-06-20 17:15:15 --> Language file loaded: language/english/db_lang.php
DEBUG - 2010-06-20 17:19:20 --> Config Class Initialized
DEBUG - 2010-06-20 17:19:20 --> Hooks Class Initialized
DEBUG - 2010-06-20 17:19:20 --> URI Class Initialized
DEBUG - 2010-06-20 17:19:20 --> Router Class Initialized
DEBUG - 2010-06-20 17:19:20 --> Output Class Initialized
DEBUG - 2010-06-20 17:19:20 --> Input Class Initialized
DEBUG - 2010-06-20 17:19:20 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-20 17:19:20 --> Language Class Initialized
DEBUG - 2010-06-20 17:19:20 --> Loader Class Initialized
DEBUG - 2010-06-20 17:19:20 --> Controller Class Initialized
DEBUG - 2010-06-20 17:19:20 --> Unit Testing Class Initialized
DEBUG - 2010-06-20 17:19:20 --> Session Class Initialized
DEBUG - 2010-06-20 17:19:20 --> Helper loaded: string_helper
DEBUG - 2010-06-20 17:19:20 --> Session routines successfully run
DEBUG - 2010-06-20 17:19:20 --> Helper loaded: kals_helper
DEBUG - 2010-06-20 17:19:20 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-20 17:19:20 --> Database Driver Class Initialized
ERROR - 2010-06-20 17:19:20 --> Severity: Warning  --> pg_pconnect() [<a href='function.pg-pconnect'>function.pg-pconnect</a>]: Unable to connect to PostgreSQL server: FATAL:  database &quot;kals2010&quot; does not exist D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 99
ERROR - 2010-06-20 17:19:20 --> Unable to connect to the database
DEBUG - 2010-06-20 17:19:20 --> Language file loaded: language/english/db_lang.php
DEBUG - 2010-06-20 17:23:07 --> Config Class Initialized
DEBUG - 2010-06-20 17:23:07 --> Hooks Class Initialized
DEBUG - 2010-06-20 17:23:07 --> URI Class Initialized
DEBUG - 2010-06-20 17:23:07 --> Router Class Initialized
DEBUG - 2010-06-20 17:23:07 --> Output Class Initialized
DEBUG - 2010-06-20 17:23:07 --> Input Class Initialized
DEBUG - 2010-06-20 17:23:07 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-20 17:23:07 --> Language Class Initialized
DEBUG - 2010-06-20 17:23:07 --> Loader Class Initialized
DEBUG - 2010-06-20 17:23:07 --> Controller Class Initialized
DEBUG - 2010-06-20 17:23:07 --> Unit Testing Class Initialized
DEBUG - 2010-06-20 17:23:07 --> Session Class Initialized
DEBUG - 2010-06-20 17:23:07 --> Helper loaded: string_helper
DEBUG - 2010-06-20 17:23:07 --> Session routines successfully run
DEBUG - 2010-06-20 17:23:07 --> Helper loaded: kals_helper
DEBUG - 2010-06-20 17:23:07 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-20 17:23:07 --> Database Driver Class Initialized
DEBUG - 2010-06-20 17:23:07 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-20 17:23:37 --> Config Class Initialized
DEBUG - 2010-06-20 17:23:37 --> Hooks Class Initialized
DEBUG - 2010-06-20 17:23:37 --> URI Class Initialized
DEBUG - 2010-06-20 17:23:37 --> Router Class Initialized
DEBUG - 2010-06-20 17:23:37 --> Output Class Initialized
DEBUG - 2010-06-20 17:23:37 --> Input Class Initialized
DEBUG - 2010-06-20 17:23:37 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-20 17:23:37 --> Language Class Initialized
DEBUG - 2010-06-20 17:23:37 --> Loader Class Initialized
DEBUG - 2010-06-20 17:23:37 --> Controller Class Initialized
DEBUG - 2010-06-20 17:23:37 --> Unit Testing Class Initialized
DEBUG - 2010-06-20 17:23:37 --> Session Class Initialized
DEBUG - 2010-06-20 17:23:37 --> Helper loaded: string_helper
DEBUG - 2010-06-20 17:23:37 --> Session routines successfully run
DEBUG - 2010-06-20 17:23:37 --> Helper loaded: kals_helper
DEBUG - 2010-06-20 17:23:37 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-20 17:23:37 --> Database Driver Class Initialized
DEBUG - 2010-06-20 17:23:37 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-20 17:24:41 --> Config Class Initialized
DEBUG - 2010-06-20 17:24:41 --> Hooks Class Initialized
DEBUG - 2010-06-20 17:24:41 --> URI Class Initialized
DEBUG - 2010-06-20 17:24:41 --> Router Class Initialized
DEBUG - 2010-06-20 17:24:41 --> Output Class Initialized
DEBUG - 2010-06-20 17:24:41 --> Input Class Initialized
DEBUG - 2010-06-20 17:24:41 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-20 17:24:41 --> Language Class Initialized
DEBUG - 2010-06-20 17:24:41 --> Loader Class Initialized
DEBUG - 2010-06-20 17:24:41 --> Controller Class Initialized
DEBUG - 2010-06-20 17:24:41 --> Unit Testing Class Initialized
DEBUG - 2010-06-20 17:24:41 --> Session Class Initialized
DEBUG - 2010-06-20 17:24:41 --> Helper loaded: string_helper
DEBUG - 2010-06-20 17:24:41 --> Session routines successfully run
DEBUG - 2010-06-20 17:24:41 --> Helper loaded: kals_helper
DEBUG - 2010-06-20 17:24:41 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-20 17:24:41 --> Database Driver Class Initialized
ERROR - 2010-06-20 17:24:41 --> Severity: Notice  --> Undefined variable: host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 189
DEBUG - 2010-06-20 17:24:41 --> Language file loaded: language/english/unit_test_lang.php
