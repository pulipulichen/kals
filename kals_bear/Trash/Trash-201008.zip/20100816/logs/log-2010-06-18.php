<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
DEBUG - 2010-06-18 09:05:08 --> Config Class Initialized
DEBUG - 2010-06-18 09:05:08 --> Hooks Class Initialized
DEBUG - 2010-06-18 09:05:08 --> URI Class Initialized
DEBUG - 2010-06-18 09:05:08 --> Router Class Initialized
DEBUG - 2010-06-18 09:05:08 --> Output Class Initialized
DEBUG - 2010-06-18 09:05:08 --> Input Class Initialized
DEBUG - 2010-06-18 09:05:08 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 09:05:08 --> Language Class Initialized
DEBUG - 2010-06-18 09:05:08 --> Loader Class Initialized
DEBUG - 2010-06-18 09:05:08 --> Controller Class Initialized
DEBUG - 2010-06-18 09:05:09 --> Model Class Initialized
DEBUG - 2010-06-18 09:07:03 --> Config Class Initialized
DEBUG - 2010-06-18 09:07:03 --> Hooks Class Initialized
DEBUG - 2010-06-18 09:07:03 --> URI Class Initialized
DEBUG - 2010-06-18 09:07:03 --> Router Class Initialized
DEBUG - 2010-06-18 09:07:03 --> Output Class Initialized
DEBUG - 2010-06-18 09:07:03 --> Input Class Initialized
DEBUG - 2010-06-18 09:07:03 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 09:07:03 --> Language Class Initialized
DEBUG - 2010-06-18 09:07:03 --> Loader Class Initialized
DEBUG - 2010-06-18 09:07:03 --> Controller Class Initialized
DEBUG - 2010-06-18 09:07:03 --> Model Class Initialized
DEBUG - 2010-06-18 09:28:31 --> Config Class Initialized
DEBUG - 2010-06-18 09:28:31 --> Hooks Class Initialized
DEBUG - 2010-06-18 09:28:31 --> URI Class Initialized
DEBUG - 2010-06-18 09:28:31 --> Router Class Initialized
DEBUG - 2010-06-18 09:28:31 --> Output Class Initialized
DEBUG - 2010-06-18 09:28:31 --> Input Class Initialized
DEBUG - 2010-06-18 09:28:31 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 09:28:31 --> Language Class Initialized
DEBUG - 2010-06-18 09:28:31 --> Loader Class Initialized
DEBUG - 2010-06-18 09:28:31 --> Controller Class Initialized
DEBUG - 2010-06-18 09:28:31 --> Model Class Initialized
DEBUG - 2010-06-18 09:29:10 --> Config Class Initialized
DEBUG - 2010-06-18 09:29:10 --> Hooks Class Initialized
DEBUG - 2010-06-18 09:29:10 --> URI Class Initialized
DEBUG - 2010-06-18 09:29:10 --> Router Class Initialized
DEBUG - 2010-06-18 09:29:10 --> Output Class Initialized
DEBUG - 2010-06-18 09:29:10 --> Input Class Initialized
DEBUG - 2010-06-18 09:29:10 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 09:29:10 --> Language Class Initialized
DEBUG - 2010-06-18 09:29:10 --> Loader Class Initialized
DEBUG - 2010-06-18 09:29:10 --> Controller Class Initialized
DEBUG - 2010-06-18 09:29:10 --> Model Class Initialized
INFO  - 2010-06-18 09:29:10 --> [Ut_logger] test2
DEBUG - 2010-06-18 09:29:10 --> Final output sent to browser
DEBUG - 2010-06-18 09:29:10 --> Total execution time: 0.1746
DEBUG - 2010-06-18 14:33:51 --> Config Class Initialized
DEBUG - 2010-06-18 14:33:51 --> Hooks Class Initialized
DEBUG - 2010-06-18 14:33:51 --> URI Class Initialized
DEBUG - 2010-06-18 14:33:51 --> Router Class Initialized
DEBUG - 2010-06-18 14:33:51 --> Output Class Initialized
DEBUG - 2010-06-18 14:33:51 --> Input Class Initialized
DEBUG - 2010-06-18 14:33:51 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 14:33:51 --> Language Class Initialized
DEBUG - 2010-06-18 14:33:52 --> Loader Class Initialized
DEBUG - 2010-06-18 14:33:52 --> Controller Class Initialized
DEBUG - 2010-06-18 14:33:52 --> Unit Testing Class Initialized
DEBUG - 2010-06-18 14:34:29 --> Config Class Initialized
DEBUG - 2010-06-18 14:34:29 --> Hooks Class Initialized
DEBUG - 2010-06-18 14:34:29 --> URI Class Initialized
DEBUG - 2010-06-18 14:34:30 --> Router Class Initialized
DEBUG - 2010-06-18 14:34:30 --> Output Class Initialized
DEBUG - 2010-06-18 14:34:30 --> Input Class Initialized
DEBUG - 2010-06-18 14:34:30 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 14:34:30 --> Language Class Initialized
DEBUG - 2010-06-18 14:34:30 --> Loader Class Initialized
DEBUG - 2010-06-18 14:34:30 --> Controller Class Initialized
DEBUG - 2010-06-18 14:34:30 --> Unit Testing Class Initialized
DEBUG - 2010-06-18 14:34:30 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-18 14:34:30 --> Final output sent to browser
DEBUG - 2010-06-18 14:34:30 --> Total execution time: 0.7033
DEBUG - 2010-06-18 14:34:42 --> Config Class Initialized
DEBUG - 2010-06-18 14:34:42 --> Hooks Class Initialized
DEBUG - 2010-06-18 14:34:42 --> URI Class Initialized
DEBUG - 2010-06-18 14:34:42 --> Router Class Initialized
DEBUG - 2010-06-18 14:34:42 --> Output Class Initialized
DEBUG - 2010-06-18 14:34:42 --> Input Class Initialized
DEBUG - 2010-06-18 14:34:42 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 14:34:42 --> Language Class Initialized
DEBUG - 2010-06-18 14:34:42 --> Loader Class Initialized
DEBUG - 2010-06-18 14:34:42 --> Controller Class Initialized
DEBUG - 2010-06-18 14:34:42 --> Unit Testing Class Initialized
DEBUG - 2010-06-18 14:34:42 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-18 14:34:42 --> Final output sent to browser
DEBUG - 2010-06-18 14:34:42 --> Total execution time: 0.1986
DEBUG - 2010-06-18 14:34:58 --> Config Class Initialized
DEBUG - 2010-06-18 14:34:58 --> Hooks Class Initialized
DEBUG - 2010-06-18 14:34:58 --> URI Class Initialized
DEBUG - 2010-06-18 14:34:58 --> Router Class Initialized
DEBUG - 2010-06-18 14:34:58 --> Output Class Initialized
DEBUG - 2010-06-18 14:34:58 --> Input Class Initialized
DEBUG - 2010-06-18 14:34:58 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 14:34:58 --> Language Class Initialized
DEBUG - 2010-06-18 14:34:58 --> Loader Class Initialized
DEBUG - 2010-06-18 14:34:58 --> Controller Class Initialized
DEBUG - 2010-06-18 14:34:58 --> Unit Testing Class Initialized
DEBUG - 2010-06-18 14:34:58 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-18 14:34:58 --> Final output sent to browser
DEBUG - 2010-06-18 14:34:58 --> Total execution time: 0.2034
DEBUG - 2010-06-18 15:03:09 --> Config Class Initialized
DEBUG - 2010-06-18 15:03:09 --> Hooks Class Initialized
DEBUG - 2010-06-18 15:03:09 --> URI Class Initialized
DEBUG - 2010-06-18 15:03:09 --> Router Class Initialized
DEBUG - 2010-06-18 15:03:09 --> Output Class Initialized
DEBUG - 2010-06-18 15:03:09 --> Input Class Initialized
DEBUG - 2010-06-18 15:03:09 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 15:03:09 --> Language Class Initialized
DEBUG - 2010-06-18 15:03:09 --> Loader Class Initialized
DEBUG - 2010-06-18 15:03:09 --> Controller Class Initialized
DEBUG - 2010-06-18 15:03:09 --> Unit Testing Class Initialized
DEBUG - 2010-06-18 15:04:33 --> Config Class Initialized
DEBUG - 2010-06-18 15:04:33 --> Hooks Class Initialized
DEBUG - 2010-06-18 15:04:33 --> URI Class Initialized
DEBUG - 2010-06-18 15:04:34 --> Router Class Initialized
DEBUG - 2010-06-18 15:04:34 --> Output Class Initialized
DEBUG - 2010-06-18 15:04:34 --> Input Class Initialized
DEBUG - 2010-06-18 15:04:34 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 15:04:34 --> Language Class Initialized
DEBUG - 2010-06-18 15:04:34 --> Loader Class Initialized
DEBUG - 2010-06-18 15:04:34 --> Controller Class Initialized
DEBUG - 2010-06-18 15:04:34 --> Unit Testing Class Initialized
DEBUG - 2010-06-18 15:04:34 --> Helper loaded: kals_helper
DEBUG - 2010-06-18 15:04:34 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-18 15:04:34 --> Final output sent to browser
DEBUG - 2010-06-18 15:04:34 --> Total execution time: 0.2230
DEBUG - 2010-06-18 15:04:40 --> Config Class Initialized
DEBUG - 2010-06-18 15:04:40 --> Hooks Class Initialized
DEBUG - 2010-06-18 15:04:40 --> URI Class Initialized
DEBUG - 2010-06-18 15:04:40 --> Router Class Initialized
DEBUG - 2010-06-18 15:04:40 --> Output Class Initialized
DEBUG - 2010-06-18 15:04:40 --> Input Class Initialized
DEBUG - 2010-06-18 15:04:40 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 15:04:40 --> Language Class Initialized
DEBUG - 2010-06-18 15:04:40 --> Loader Class Initialized
DEBUG - 2010-06-18 15:04:40 --> Controller Class Initialized
DEBUG - 2010-06-18 15:04:40 --> Unit Testing Class Initialized
DEBUG - 2010-06-18 15:04:40 --> Helper loaded: kals_helper
DEBUG - 2010-06-18 15:04:40 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-18 15:04:40 --> Final output sent to browser
DEBUG - 2010-06-18 15:04:40 --> Total execution time: 0.2410
DEBUG - 2010-06-18 15:06:25 --> Config Class Initialized
DEBUG - 2010-06-18 15:06:25 --> Hooks Class Initialized
DEBUG - 2010-06-18 15:06:25 --> URI Class Initialized
DEBUG - 2010-06-18 15:06:25 --> Router Class Initialized
DEBUG - 2010-06-18 15:06:25 --> Output Class Initialized
DEBUG - 2010-06-18 15:06:25 --> Input Class Initialized
DEBUG - 2010-06-18 15:06:25 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 15:06:25 --> Language Class Initialized
DEBUG - 2010-06-18 15:06:25 --> Loader Class Initialized
DEBUG - 2010-06-18 15:06:25 --> Controller Class Initialized
DEBUG - 2010-06-18 15:06:38 --> Config Class Initialized
DEBUG - 2010-06-18 15:06:38 --> Hooks Class Initialized
DEBUG - 2010-06-18 15:06:38 --> URI Class Initialized
DEBUG - 2010-06-18 15:06:38 --> Router Class Initialized
DEBUG - 2010-06-18 15:06:38 --> Output Class Initialized
DEBUG - 2010-06-18 15:06:38 --> Input Class Initialized
DEBUG - 2010-06-18 15:06:38 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 15:06:38 --> Language Class Initialized
DEBUG - 2010-06-18 15:06:38 --> Loader Class Initialized
DEBUG - 2010-06-18 15:06:38 --> Controller Class Initialized
DEBUG - 2010-06-18 15:06:38 --> Helper loaded: url_helper
DEBUG - 2010-06-18 15:07:44 --> Config Class Initialized
DEBUG - 2010-06-18 15:07:44 --> Hooks Class Initialized
DEBUG - 2010-06-18 15:07:44 --> URI Class Initialized
DEBUG - 2010-06-18 15:07:44 --> Router Class Initialized
DEBUG - 2010-06-18 15:07:44 --> Output Class Initialized
DEBUG - 2010-06-18 15:07:44 --> Input Class Initialized
DEBUG - 2010-06-18 15:07:44 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 15:07:44 --> Language Class Initialized
DEBUG - 2010-06-18 15:07:44 --> Loader Class Initialized
DEBUG - 2010-06-18 15:07:44 --> Controller Class Initialized
DEBUG - 2010-06-18 15:07:44 --> Helper loaded: url_helper
DEBUG - 2010-06-18 15:07:44 --> Config Class Initialized
DEBUG - 2010-06-18 15:07:44 --> Hooks Class Initialized
DEBUG - 2010-06-18 15:07:44 --> URI Class Initialized
DEBUG - 2010-06-18 15:07:45 --> Router Class Initialized
DEBUG - 2010-06-18 15:07:45 --> Output Class Initialized
DEBUG - 2010-06-18 15:07:45 --> Input Class Initialized
DEBUG - 2010-06-18 15:07:45 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 15:07:45 --> Language Class Initialized
DEBUG - 2010-06-18 15:07:45 --> Loader Class Initialized
DEBUG - 2010-06-18 15:07:45 --> Controller Class Initialized
DEBUG - 2010-06-18 15:07:45 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-18 15:07:45 --> Final output sent to browser
DEBUG - 2010-06-18 15:07:45 --> Total execution time: 0.2099
DEBUG - 2010-06-18 15:08:29 --> Config Class Initialized
DEBUG - 2010-06-18 15:08:29 --> Hooks Class Initialized
DEBUG - 2010-06-18 15:08:29 --> URI Class Initialized
DEBUG - 2010-06-18 15:08:29 --> Router Class Initialized
DEBUG - 2010-06-18 15:08:29 --> Output Class Initialized
DEBUG - 2010-06-18 15:08:29 --> Input Class Initialized
DEBUG - 2010-06-18 15:08:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 15:08:29 --> Language Class Initialized
DEBUG - 2010-06-18 15:08:29 --> Loader Class Initialized
DEBUG - 2010-06-18 15:08:29 --> Controller Class Initialized
DEBUG - 2010-06-18 15:08:29 --> Helper loaded: url_helper
DEBUG - 2010-06-18 15:08:29 --> Config Class Initialized
DEBUG - 2010-06-18 15:08:29 --> Hooks Class Initialized
DEBUG - 2010-06-18 15:08:29 --> URI Class Initialized
DEBUG - 2010-06-18 15:08:29 --> Router Class Initialized
DEBUG - 2010-06-18 15:08:29 --> Output Class Initialized
DEBUG - 2010-06-18 15:08:29 --> Input Class Initialized
DEBUG - 2010-06-18 15:08:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 15:08:29 --> Language Class Initialized
DEBUG - 2010-06-18 15:08:29 --> Loader Class Initialized
DEBUG - 2010-06-18 15:08:29 --> Controller Class Initialized
DEBUG - 2010-06-18 15:08:29 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-18 15:08:29 --> Final output sent to browser
DEBUG - 2010-06-18 15:08:29 --> Total execution time: 0.2031
DEBUG - 2010-06-18 15:09:22 --> Config Class Initialized
DEBUG - 2010-06-18 15:09:22 --> Hooks Class Initialized
DEBUG - 2010-06-18 15:09:22 --> URI Class Initialized
DEBUG - 2010-06-18 15:09:22 --> Router Class Initialized
DEBUG - 2010-06-18 15:09:22 --> Output Class Initialized
DEBUG - 2010-06-18 15:09:22 --> Input Class Initialized
DEBUG - 2010-06-18 15:09:22 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 15:09:22 --> Language Class Initialized
DEBUG - 2010-06-18 15:09:22 --> Loader Class Initialized
DEBUG - 2010-06-18 15:09:22 --> Controller Class Initialized
DEBUG - 2010-06-18 15:09:22 --> Helper loaded: url_helper
DEBUG - 2010-06-18 15:09:23 --> Config Class Initialized
DEBUG - 2010-06-18 15:09:23 --> Hooks Class Initialized
DEBUG - 2010-06-18 15:09:23 --> URI Class Initialized
ERROR - 2010-06-18 15:09:23 --> 404 Page Not Found --> test/ut_kals_helper
DEBUG - 2010-06-18 15:09:39 --> Config Class Initialized
DEBUG - 2010-06-18 15:09:39 --> Hooks Class Initialized
DEBUG - 2010-06-18 15:09:39 --> URI Class Initialized
ERROR - 2010-06-18 15:09:39 --> 404 Page Not Found --> test/ut_kals_helper
DEBUG - 2010-06-18 15:10:07 --> Config Class Initialized
DEBUG - 2010-06-18 15:10:07 --> Hooks Class Initialized
DEBUG - 2010-06-18 15:10:07 --> URI Class Initialized
DEBUG - 2010-06-18 15:10:07 --> Router Class Initialized
DEBUG - 2010-06-18 15:10:07 --> Output Class Initialized
DEBUG - 2010-06-18 15:10:07 --> Input Class Initialized
DEBUG - 2010-06-18 15:10:07 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 15:10:07 --> Language Class Initialized
DEBUG - 2010-06-18 15:10:07 --> Loader Class Initialized
DEBUG - 2010-06-18 15:10:07 --> Controller Class Initialized
DEBUG - 2010-06-18 15:10:07 --> Unit Testing Class Initialized
DEBUG - 2010-06-18 15:10:07 --> Helper loaded: kals_helper
DEBUG - 2010-06-18 15:10:07 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-18 15:10:07 --> Final output sent to browser
DEBUG - 2010-06-18 15:10:07 --> Total execution time: 0.2163
DEBUG - 2010-06-18 15:13:12 --> Config Class Initialized
DEBUG - 2010-06-18 15:13:12 --> Hooks Class Initialized
DEBUG - 2010-06-18 15:13:12 --> URI Class Initialized
DEBUG - 2010-06-18 15:13:12 --> Router Class Initialized
DEBUG - 2010-06-18 15:13:12 --> Output Class Initialized
DEBUG - 2010-06-18 15:13:12 --> Input Class Initialized
DEBUG - 2010-06-18 15:13:12 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 15:13:12 --> Language Class Initialized
DEBUG - 2010-06-18 15:13:12 --> Loader Class Initialized
DEBUG - 2010-06-18 15:13:12 --> Controller Class Initialized
DEBUG - 2010-06-18 15:13:12 --> Unit Testing Class Initialized
DEBUG - 2010-06-18 15:13:12 --> Helper loaded: kals_helper
DEBUG - 2010-06-18 15:13:12 --> Language file loaded: language/english/unit_test_lang.php
ERROR - 2010-06-18 15:13:12 --> Severity: Notice  --> Undefined variable: paramters D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 36
ERROR - 2010-06-18 15:13:12 --> Severity: Notice  --> Undefined index:  port D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 37
ERROR - 2010-06-18 15:13:12 --> Severity: Notice  --> Undefined index:  query D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 55
ERROR - 2010-06-18 15:13:12 --> Severity: Notice  --> Undefined index:  fragment D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 56
ERROR - 2010-06-18 15:13:13 --> Severity: Notice  --> Undefined index:  Content-Type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 158
ERROR - 2010-06-18 15:13:15 --> Severity: Notice  --> Undefined index:  Content-Type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 158
DEBUG - 2010-06-18 15:13:15 --> Final output sent to browser
DEBUG - 2010-06-18 15:13:15 --> Total execution time: 3.3780
DEBUG - 2010-06-18 15:16:04 --> Config Class Initialized
DEBUG - 2010-06-18 15:16:05 --> Hooks Class Initialized
DEBUG - 2010-06-18 15:16:05 --> URI Class Initialized
DEBUG - 2010-06-18 15:16:05 --> Router Class Initialized
DEBUG - 2010-06-18 15:16:05 --> Output Class Initialized
DEBUG - 2010-06-18 15:16:05 --> Input Class Initialized
DEBUG - 2010-06-18 15:16:05 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 15:16:05 --> Language Class Initialized
DEBUG - 2010-06-18 15:16:05 --> Loader Class Initialized
DEBUG - 2010-06-18 15:16:05 --> Controller Class Initialized
DEBUG - 2010-06-18 15:16:05 --> Unit Testing Class Initialized
DEBUG - 2010-06-18 15:16:05 --> Helper loaded: kals_helper
DEBUG - 2010-06-18 15:16:05 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-18 15:16:07 --> Final output sent to browser
DEBUG - 2010-06-18 15:16:07 --> Total execution time: 2.2087
DEBUG - 2010-06-18 15:17:36 --> Config Class Initialized
DEBUG - 2010-06-18 15:17:36 --> Hooks Class Initialized
DEBUG - 2010-06-18 15:17:36 --> URI Class Initialized
DEBUG - 2010-06-18 15:17:36 --> Router Class Initialized
DEBUG - 2010-06-18 15:17:36 --> Output Class Initialized
DEBUG - 2010-06-18 15:17:36 --> Input Class Initialized
DEBUG - 2010-06-18 15:17:36 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 15:17:36 --> Language Class Initialized
DEBUG - 2010-06-18 15:17:36 --> Loader Class Initialized
DEBUG - 2010-06-18 15:17:36 --> Controller Class Initialized
DEBUG - 2010-06-18 15:17:36 --> Unit Testing Class Initialized
DEBUG - 2010-06-18 15:17:36 --> Helper loaded: kals_helper
DEBUG - 2010-06-18 15:17:36 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-18 15:17:45 --> Final output sent to browser
DEBUG - 2010-06-18 15:17:45 --> Total execution time: 9.1424
DEBUG - 2010-06-18 15:19:21 --> Config Class Initialized
DEBUG - 2010-06-18 15:19:21 --> Hooks Class Initialized
DEBUG - 2010-06-18 15:19:21 --> URI Class Initialized
DEBUG - 2010-06-18 15:19:21 --> Router Class Initialized
DEBUG - 2010-06-18 15:19:21 --> Output Class Initialized
DEBUG - 2010-06-18 15:19:21 --> Input Class Initialized
DEBUG - 2010-06-18 15:19:21 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 15:19:21 --> Language Class Initialized
DEBUG - 2010-06-18 15:19:31 --> Config Class Initialized
DEBUG - 2010-06-18 15:19:31 --> Hooks Class Initialized
DEBUG - 2010-06-18 15:19:31 --> URI Class Initialized
DEBUG - 2010-06-18 15:19:31 --> Router Class Initialized
DEBUG - 2010-06-18 15:19:31 --> Output Class Initialized
DEBUG - 2010-06-18 15:19:31 --> Input Class Initialized
DEBUG - 2010-06-18 15:19:31 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 15:19:31 --> Language Class Initialized
DEBUG - 2010-06-18 15:19:31 --> Loader Class Initialized
DEBUG - 2010-06-18 15:19:31 --> Controller Class Initialized
DEBUG - 2010-06-18 15:19:31 --> Unit Testing Class Initialized
DEBUG - 2010-06-18 15:19:31 --> Helper loaded: kals_helper
DEBUG - 2010-06-18 15:19:31 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-18 15:19:33 --> Final output sent to browser
DEBUG - 2010-06-18 15:19:33 --> Total execution time: 2.5222
DEBUG - 2010-06-18 15:19:51 --> Config Class Initialized
DEBUG - 2010-06-18 15:19:51 --> Hooks Class Initialized
DEBUG - 2010-06-18 15:19:51 --> URI Class Initialized
DEBUG - 2010-06-18 15:19:51 --> Router Class Initialized
DEBUG - 2010-06-18 15:19:51 --> Output Class Initialized
DEBUG - 2010-06-18 15:19:51 --> Input Class Initialized
DEBUG - 2010-06-18 15:19:51 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 15:19:51 --> Language Class Initialized
DEBUG - 2010-06-18 15:19:51 --> Loader Class Initialized
DEBUG - 2010-06-18 15:19:51 --> Controller Class Initialized
DEBUG - 2010-06-18 15:19:51 --> Unit Testing Class Initialized
DEBUG - 2010-06-18 15:19:51 --> Helper loaded: kals_helper
DEBUG - 2010-06-18 15:19:51 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-18 15:19:53 --> Final output sent to browser
DEBUG - 2010-06-18 15:19:53 --> Total execution time: 1.8119
DEBUG - 2010-06-18 15:20:01 --> Config Class Initialized
DEBUG - 2010-06-18 15:20:01 --> Hooks Class Initialized
DEBUG - 2010-06-18 15:20:01 --> URI Class Initialized
DEBUG - 2010-06-18 15:20:02 --> Router Class Initialized
DEBUG - 2010-06-18 15:20:02 --> Output Class Initialized
DEBUG - 2010-06-18 15:20:02 --> Input Class Initialized
DEBUG - 2010-06-18 15:20:02 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 15:20:02 --> Language Class Initialized
DEBUG - 2010-06-18 15:20:02 --> Loader Class Initialized
DEBUG - 2010-06-18 15:20:02 --> Controller Class Initialized
DEBUG - 2010-06-18 15:20:02 --> Unit Testing Class Initialized
DEBUG - 2010-06-18 15:20:02 --> Helper loaded: kals_helper
DEBUG - 2010-06-18 15:20:02 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-18 15:20:04 --> Final output sent to browser
DEBUG - 2010-06-18 15:20:04 --> Total execution time: 2.1322
DEBUG - 2010-06-18 15:20:19 --> Config Class Initialized
DEBUG - 2010-06-18 15:20:19 --> Hooks Class Initialized
DEBUG - 2010-06-18 15:20:19 --> URI Class Initialized
DEBUG - 2010-06-18 15:20:19 --> Router Class Initialized
DEBUG - 2010-06-18 15:20:19 --> Output Class Initialized
DEBUG - 2010-06-18 15:20:19 --> Input Class Initialized
DEBUG - 2010-06-18 15:20:19 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 15:20:19 --> Language Class Initialized
DEBUG - 2010-06-18 15:20:19 --> Loader Class Initialized
DEBUG - 2010-06-18 15:20:19 --> Controller Class Initialized
DEBUG - 2010-06-18 15:20:19 --> Unit Testing Class Initialized
DEBUG - 2010-06-18 15:20:19 --> Helper loaded: kals_helper
DEBUG - 2010-06-18 15:20:19 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-18 15:20:23 --> Final output sent to browser
DEBUG - 2010-06-18 15:20:23 --> Total execution time: 3.3566
DEBUG - 2010-06-18 15:20:37 --> Config Class Initialized
DEBUG - 2010-06-18 15:20:37 --> Hooks Class Initialized
DEBUG - 2010-06-18 15:20:37 --> URI Class Initialized
DEBUG - 2010-06-18 15:20:37 --> Router Class Initialized
DEBUG - 2010-06-18 15:20:37 --> Output Class Initialized
DEBUG - 2010-06-18 15:20:37 --> Input Class Initialized
DEBUG - 2010-06-18 15:20:37 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 15:20:37 --> Language Class Initialized
DEBUG - 2010-06-18 15:20:37 --> Loader Class Initialized
DEBUG - 2010-06-18 15:20:37 --> Controller Class Initialized
DEBUG - 2010-06-18 15:20:37 --> Unit Testing Class Initialized
DEBUG - 2010-06-18 15:20:37 --> Helper loaded: kals_helper
DEBUG - 2010-06-18 15:20:37 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-18 15:20:39 --> Final output sent to browser
DEBUG - 2010-06-18 15:20:39 --> Total execution time: 2.3429
DEBUG - 2010-06-18 15:20:52 --> Config Class Initialized
DEBUG - 2010-06-18 15:20:52 --> Hooks Class Initialized
DEBUG - 2010-06-18 15:20:52 --> URI Class Initialized
DEBUG - 2010-06-18 15:20:52 --> Router Class Initialized
DEBUG - 2010-06-18 15:20:52 --> Output Class Initialized
DEBUG - 2010-06-18 15:20:52 --> Input Class Initialized
DEBUG - 2010-06-18 15:20:52 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 15:20:52 --> Language Class Initialized
DEBUG - 2010-06-18 15:20:52 --> Loader Class Initialized
DEBUG - 2010-06-18 15:20:52 --> Controller Class Initialized
DEBUG - 2010-06-18 15:20:52 --> Unit Testing Class Initialized
DEBUG - 2010-06-18 15:20:52 --> Helper loaded: kals_helper
DEBUG - 2010-06-18 15:20:52 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-18 15:20:54 --> Final output sent to browser
DEBUG - 2010-06-18 15:20:54 --> Total execution time: 1.9406
DEBUG - 2010-06-18 15:21:40 --> Config Class Initialized
DEBUG - 2010-06-18 15:21:40 --> Hooks Class Initialized
DEBUG - 2010-06-18 15:21:40 --> URI Class Initialized
DEBUG - 2010-06-18 15:21:40 --> Router Class Initialized
DEBUG - 2010-06-18 15:21:40 --> Output Class Initialized
DEBUG - 2010-06-18 15:21:40 --> Input Class Initialized
DEBUG - 2010-06-18 15:21:40 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 15:21:40 --> Language Class Initialized
DEBUG - 2010-06-18 15:21:40 --> Loader Class Initialized
DEBUG - 2010-06-18 15:21:40 --> Controller Class Initialized
DEBUG - 2010-06-18 15:21:40 --> Unit Testing Class Initialized
DEBUG - 2010-06-18 15:21:40 --> Helper loaded: kals_helper
DEBUG - 2010-06-18 15:21:40 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-18 15:22:01 --> Final output sent to browser
DEBUG - 2010-06-18 15:22:01 --> Total execution time: 21.4673
DEBUG - 2010-06-18 15:22:51 --> Config Class Initialized
DEBUG - 2010-06-18 15:22:51 --> Hooks Class Initialized
DEBUG - 2010-06-18 15:22:51 --> URI Class Initialized
DEBUG - 2010-06-18 15:22:51 --> Router Class Initialized
DEBUG - 2010-06-18 15:22:51 --> Output Class Initialized
DEBUG - 2010-06-18 15:22:51 --> Input Class Initialized
DEBUG - 2010-06-18 15:22:51 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 15:22:51 --> Language Class Initialized
DEBUG - 2010-06-18 15:22:51 --> Loader Class Initialized
DEBUG - 2010-06-18 15:22:51 --> Controller Class Initialized
DEBUG - 2010-06-18 15:22:52 --> Unit Testing Class Initialized
DEBUG - 2010-06-18 15:22:52 --> Helper loaded: kals_helper
DEBUG - 2010-06-18 15:22:52 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-18 15:22:53 --> Final output sent to browser
DEBUG - 2010-06-18 15:22:53 --> Total execution time: 2.1095
DEBUG - 2010-06-18 15:23:12 --> Config Class Initialized
DEBUG - 2010-06-18 15:23:12 --> Hooks Class Initialized
DEBUG - 2010-06-18 15:23:12 --> URI Class Initialized
DEBUG - 2010-06-18 15:23:12 --> Router Class Initialized
DEBUG - 2010-06-18 15:23:12 --> Output Class Initialized
DEBUG - 2010-06-18 15:23:12 --> Input Class Initialized
DEBUG - 2010-06-18 15:23:12 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 15:23:12 --> Language Class Initialized
DEBUG - 2010-06-18 15:23:12 --> Loader Class Initialized
DEBUG - 2010-06-18 15:23:12 --> Controller Class Initialized
DEBUG - 2010-06-18 15:23:12 --> Unit Testing Class Initialized
DEBUG - 2010-06-18 15:23:12 --> Helper loaded: kals_helper
DEBUG - 2010-06-18 15:23:12 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-18 15:23:17 --> Final output sent to browser
DEBUG - 2010-06-18 15:23:17 --> Total execution time: 5.4135
DEBUG - 2010-06-18 15:23:26 --> Config Class Initialized
DEBUG - 2010-06-18 15:23:26 --> Hooks Class Initialized
DEBUG - 2010-06-18 15:23:26 --> URI Class Initialized
DEBUG - 2010-06-18 15:23:26 --> Router Class Initialized
DEBUG - 2010-06-18 15:23:26 --> Output Class Initialized
DEBUG - 2010-06-18 15:23:26 --> Input Class Initialized
DEBUG - 2010-06-18 15:23:26 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 15:23:26 --> Language Class Initialized
DEBUG - 2010-06-18 15:23:26 --> Loader Class Initialized
DEBUG - 2010-06-18 15:23:26 --> Controller Class Initialized
DEBUG - 2010-06-18 15:23:26 --> Unit Testing Class Initialized
DEBUG - 2010-06-18 15:23:26 --> Helper loaded: kals_helper
DEBUG - 2010-06-18 15:23:26 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-18 15:23:29 --> Final output sent to browser
DEBUG - 2010-06-18 15:23:29 --> Total execution time: 2.9210
DEBUG - 2010-06-18 15:23:41 --> Config Class Initialized
DEBUG - 2010-06-18 15:23:41 --> Hooks Class Initialized
DEBUG - 2010-06-18 15:23:41 --> URI Class Initialized
DEBUG - 2010-06-18 15:23:41 --> Router Class Initialized
DEBUG - 2010-06-18 15:23:41 --> Output Class Initialized
DEBUG - 2010-06-18 15:23:41 --> Input Class Initialized
DEBUG - 2010-06-18 15:23:41 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 15:23:41 --> Language Class Initialized
DEBUG - 2010-06-18 15:23:41 --> Loader Class Initialized
DEBUG - 2010-06-18 15:23:41 --> Controller Class Initialized
DEBUG - 2010-06-18 15:23:41 --> Unit Testing Class Initialized
DEBUG - 2010-06-18 15:23:41 --> Helper loaded: kals_helper
DEBUG - 2010-06-18 15:23:41 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-18 15:23:43 --> Final output sent to browser
DEBUG - 2010-06-18 15:23:43 --> Total execution time: 2.0473
DEBUG - 2010-06-18 16:23:16 --> Config Class Initialized
DEBUG - 2010-06-18 16:23:16 --> Hooks Class Initialized
DEBUG - 2010-06-18 16:23:16 --> URI Class Initialized
ERROR - 2010-06-18 16:23:17 --> 404 Page Not Found --> ut/ut_kals_helper
DEBUG - 2010-06-18 16:23:33 --> Config Class Initialized
DEBUG - 2010-06-18 16:23:33 --> Hooks Class Initialized
DEBUG - 2010-06-18 16:23:33 --> URI Class Initialized
ERROR - 2010-06-18 16:23:33 --> 404 Page Not Found --> ut/helper
DEBUG - 2010-06-18 16:24:12 --> Config Class Initialized
DEBUG - 2010-06-18 16:24:12 --> Hooks Class Initialized
DEBUG - 2010-06-18 16:24:12 --> URI Class Initialized
ERROR - 2010-06-18 16:24:12 --> 404 Page Not Found --> ut/helper
DEBUG - 2010-06-18 16:24:31 --> Config Class Initialized
DEBUG - 2010-06-18 16:24:31 --> Hooks Class Initialized
DEBUG - 2010-06-18 16:24:31 --> URI Class Initialized
ERROR - 2010-06-18 16:24:31 --> 404 Page Not Found --> ut/helper
DEBUG - 2010-06-18 16:24:39 --> Config Class Initialized
DEBUG - 2010-06-18 16:24:39 --> Hooks Class Initialized
DEBUG - 2010-06-18 16:24:39 --> URI Class Initialized
ERROR - 2010-06-18 16:24:39 --> 404 Page Not Found --> ut/helper
DEBUG - 2010-06-18 16:24:43 --> Config Class Initialized
DEBUG - 2010-06-18 16:24:43 --> Hooks Class Initialized
DEBUG - 2010-06-18 16:24:43 --> URI Class Initialized
ERROR - 2010-06-18 16:24:43 --> 404 Page Not Found --> ut/helper
DEBUG - 2010-06-18 16:24:57 --> Config Class Initialized
DEBUG - 2010-06-18 16:24:57 --> Hooks Class Initialized
DEBUG - 2010-06-18 16:24:57 --> URI Class Initialized
ERROR - 2010-06-18 16:24:57 --> 404 Page Not Found --> ut/helper
DEBUG - 2010-06-18 16:25:02 --> Config Class Initialized
DEBUG - 2010-06-18 16:25:02 --> Hooks Class Initialized
DEBUG - 2010-06-18 16:25:02 --> URI Class Initialized
DEBUG - 2010-06-18 16:25:02 --> Router Class Initialized
DEBUG - 2010-06-18 16:25:02 --> Output Class Initialized
DEBUG - 2010-06-18 16:25:02 --> Input Class Initialized
DEBUG - 2010-06-18 16:25:02 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 16:25:02 --> Language Class Initialized
DEBUG - 2010-06-18 16:25:02 --> Loader Class Initialized
DEBUG - 2010-06-18 16:25:02 --> Controller Class Initialized
DEBUG - 2010-06-18 16:25:02 --> Helper loaded: url_helper
DEBUG - 2010-06-18 16:25:02 --> Final output sent to browser
DEBUG - 2010-06-18 16:25:02 --> Total execution time: 0.1950
DEBUG - 2010-06-18 16:27:49 --> Config Class Initialized
DEBUG - 2010-06-18 16:27:49 --> Hooks Class Initialized
DEBUG - 2010-06-18 16:27:49 --> URI Class Initialized
DEBUG - 2010-06-18 16:27:49 --> Router Class Initialized
DEBUG - 2010-06-18 16:27:49 --> Output Class Initialized
DEBUG - 2010-06-18 16:27:49 --> Input Class Initialized
DEBUG - 2010-06-18 16:27:49 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 16:27:49 --> Language Class Initialized
DEBUG - 2010-06-18 16:27:49 --> Loader Class Initialized
DEBUG - 2010-06-18 16:27:49 --> Controller Class Initialized
DEBUG - 2010-06-18 16:27:49 --> Helper loaded: url_helper
DEBUG - 2010-06-18 16:27:49 --> Config Class Initialized
DEBUG - 2010-06-18 16:27:49 --> Hooks Class Initialized
DEBUG - 2010-06-18 16:27:49 --> URI Class Initialized
DEBUG - 2010-06-18 16:27:49 --> Router Class Initialized
DEBUG - 2010-06-18 16:27:49 --> Output Class Initialized
DEBUG - 2010-06-18 16:27:49 --> Input Class Initialized
DEBUG - 2010-06-18 16:27:49 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 16:27:49 --> Language Class Initialized
DEBUG - 2010-06-18 16:27:49 --> Loader Class Initialized
DEBUG - 2010-06-18 16:27:49 --> Controller Class Initialized
DEBUG - 2010-06-18 16:27:49 --> Unit Testing Class Initialized
DEBUG - 2010-06-18 16:27:49 --> Helper loaded: kals_helper
DEBUG - 2010-06-18 16:27:49 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-18 16:27:51 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-18 16:27:51 --> Final output sent to browser
DEBUG - 2010-06-18 16:27:51 --> Total execution time: 2.5233
DEBUG - 2010-06-18 16:30:40 --> Config Class Initialized
DEBUG - 2010-06-18 16:30:40 --> Hooks Class Initialized
DEBUG - 2010-06-18 16:30:40 --> URI Class Initialized
DEBUG - 2010-06-18 16:30:40 --> Router Class Initialized
DEBUG - 2010-06-18 16:30:40 --> Output Class Initialized
DEBUG - 2010-06-18 16:30:40 --> Input Class Initialized
DEBUG - 2010-06-18 16:30:40 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 16:30:40 --> Language Class Initialized
DEBUG - 2010-06-18 16:31:04 --> Config Class Initialized
DEBUG - 2010-06-18 16:31:04 --> Hooks Class Initialized
DEBUG - 2010-06-18 16:31:04 --> URI Class Initialized
DEBUG - 2010-06-18 16:31:04 --> Router Class Initialized
DEBUG - 2010-06-18 16:31:04 --> Output Class Initialized
DEBUG - 2010-06-18 16:31:05 --> Input Class Initialized
DEBUG - 2010-06-18 16:31:05 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 16:31:05 --> Language Class Initialized
DEBUG - 2010-06-18 16:31:29 --> Config Class Initialized
DEBUG - 2010-06-18 16:31:29 --> Hooks Class Initialized
DEBUG - 2010-06-18 16:31:29 --> URI Class Initialized
DEBUG - 2010-06-18 16:31:29 --> Router Class Initialized
DEBUG - 2010-06-18 16:31:29 --> Output Class Initialized
DEBUG - 2010-06-18 16:31:29 --> Input Class Initialized
DEBUG - 2010-06-18 16:31:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-18 16:31:29 --> Language Class Initialized
DEBUG - 2010-06-18 16:31:29 --> Loader Class Initialized
DEBUG - 2010-06-18 16:31:29 --> Controller Class Initialized
DEBUG - 2010-06-18 16:31:29 --> Unit Testing Class Initialized
DEBUG - 2010-06-18 16:31:29 --> Helper loaded: kals_helper
DEBUG - 2010-06-18 16:31:29 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-18 16:31:31 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-18 16:31:31 --> Final output sent to browser
DEBUG - 2010-06-18 16:31:31 --> Total execution time: 2.2988
