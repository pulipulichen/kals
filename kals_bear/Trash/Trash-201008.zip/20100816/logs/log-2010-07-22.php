<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-07-22 12:03:51 --> Severity: Warning  --> chmod() [<a href='function.chmod'>function.chmod</a>]: No error D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 73
ERROR - 2010-07-22 12:03:51 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/14bfa6bb14875e45bba028a21ed38046) [<a href='function.unlink'>function.unlink</a>]: No such file or directory D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-22 12:03:52 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-22 12:03:53 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-22 12:06:47 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-22 13:39:35 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/c74d97b01eae257e44aa9d5bade97baf) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-22 13:47:06 --> 404 Page Not Found --> qunit_feeds
ERROR - 2010-07-22 13:55:56 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/f899139df5e1059396431415e770c6dd) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-22 14:02:21 --> 404 Page Not Found --> qunit_feeds
