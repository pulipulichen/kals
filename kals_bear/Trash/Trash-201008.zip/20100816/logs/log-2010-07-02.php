<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2010-07-02 12:19:52 --> Config Class Initialized
DEBUG - 2010-07-02 12:19:52 --> Hooks Class Initialized
DEBUG - 2010-07-02 12:19:52 --> URI Class Initialized
DEBUG - 2010-07-02 12:19:52 --> Router Class Initialized
DEBUG - 2010-07-02 12:19:53 --> Output Class Initialized
DEBUG - 2010-07-02 12:19:53 --> Input Class Initialized
DEBUG - 2010-07-02 12:19:53 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-02 12:19:53 --> Language Class Initialized
DEBUG - 2010-07-02 12:19:53 --> Loader Class Initialized
DEBUG - 2010-07-02 12:19:53 --> Helper loaded: context_helper
DEBUG - 2010-07-02 12:19:53 --> Helper loaded: kals_helper
DEBUG - 2010-07-02 12:19:53 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-02 12:19:53 --> Database Driver Class Initialized
DEBUG - 2010-07-02 12:19:53 --> Controller Class Initialized
DEBUG - 2010-07-02 12:19:53 --> Unit Testing Class Initialized
DEBUG - 2010-07-02 12:19:53 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-02 12:19:53 --> Session Class Initialized
DEBUG - 2010-07-02 12:19:53 --> Helper loaded: string_helper
DEBUG - 2010-07-02 12:19:53 --> A session cookie was not found.
DEBUG - 2010-07-02 12:19:53 --> Session routines successfully run
DEBUG - 2010-07-02 12:19:53 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-02 12:19:54 --> Config file loaded: config/kals.php
DEBUG - 2010-07-02 12:19:54 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-02 12:19:54 --> Final output sent to browser
DEBUG - 2010-07-02 12:19:54 --> Total execution time: 1.7848
DEBUG - 2010-07-02 12:20:30 --> Config Class Initialized
DEBUG - 2010-07-02 12:20:30 --> Hooks Class Initialized
DEBUG - 2010-07-02 12:20:30 --> URI Class Initialized
DEBUG - 2010-07-02 12:20:30 --> Router Class Initialized
DEBUG - 2010-07-02 12:20:30 --> Output Class Initialized
DEBUG - 2010-07-02 12:20:30 --> Input Class Initialized
DEBUG - 2010-07-02 12:20:30 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-02 12:20:30 --> Language Class Initialized
DEBUG - 2010-07-02 12:20:30 --> Loader Class Initialized
DEBUG - 2010-07-02 12:20:30 --> Helper loaded: context_helper
DEBUG - 2010-07-02 12:20:30 --> Helper loaded: kals_helper
DEBUG - 2010-07-02 12:20:30 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-02 12:20:30 --> Database Driver Class Initialized
DEBUG - 2010-07-02 12:20:31 --> Controller Class Initialized
DEBUG - 2010-07-02 12:20:31 --> Unit Testing Class Initialized
DEBUG - 2010-07-02 12:20:31 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-02 12:20:31 --> Session Class Initialized
DEBUG - 2010-07-02 12:20:31 --> Helper loaded: string_helper
DEBUG - 2010-07-02 12:20:31 --> A session cookie was not found.
DEBUG - 2010-07-02 12:20:31 --> Session routines successfully run
DEBUG - 2010-07-02 12:20:31 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-02 12:20:31 --> Config file loaded: config/kals.php
DEBUG - 2010-07-02 12:20:31 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-02 12:20:31 --> Final output sent to browser
DEBUG - 2010-07-02 12:20:31 --> Total execution time: 0.7006
