<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-07-28 04:46:11 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/ad61ab143223efbc24c7d2583be69251) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-28 04:50:30 --> 404 Page Not Found --> web_apps/helpers
ERROR - 2010-07-28 04:50:30 --> 404 Page Not Found --> web_apps/helpers
ERROR - 2010-07-28 04:50:31 --> 404 Page Not Found --> web_apps/core
ERROR - 2010-07-28 04:50:31 --> 404 Page Not Found --> web_apps/helpers
ERROR - 2010-07-28 04:50:31 --> Severity: Warning  --> Missing argument 1 for Web_apps::general() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\web_apps.php 29
ERROR - 2010-07-28 04:50:31 --> Severity: Notice  --> Undefined variable: type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\web_apps.php 32
ERROR - 2010-07-28 04:50:31 --> Severity: Notice  --> Undefined variable: type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\web_apps.php 47
ERROR - 2010-07-28 04:50:31 --> 404 Page Not Found --> web_apps/qunit
ERROR - 2010-07-28 04:50:44 --> 404 Page Not Found --> web_apps/helpers
ERROR - 2010-07-28 04:50:44 --> 404 Page Not Found --> web_apps/helpers
ERROR - 2010-07-28 04:50:45 --> 404 Page Not Found --> web_apps/helpers
ERROR - 2010-07-28 04:50:45 --> 404 Page Not Found --> web_apps/core
ERROR - 2010-07-28 04:50:45 --> Severity: Warning  --> Missing argument 1 for Web_apps::general() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\web_apps.php 29
ERROR - 2010-07-28 04:50:45 --> Severity: Notice  --> Undefined variable: type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\web_apps.php 32
ERROR - 2010-07-28 04:50:45 --> Severity: Notice  --> Undefined variable: type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\web_apps.php 47
ERROR - 2010-07-28 04:50:45 --> 404 Page Not Found --> web_apps/qunit
ERROR - 2010-07-28 04:52:02 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/d1fe173d08e959397adf34b1d77e88d7) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-28 05:14:04 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/3295c76acbf4caaed33c36b1b5fc2cb1) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-28 05:14:04 --> 404 Page Not Found --> web_apps/general
ERROR - 2010-07-28 05:14:04 --> 404 Page Not Found --> web_apps/general
ERROR - 2010-07-28 05:14:10 --> 404 Page Not Found --> web_apps/general
ERROR - 2010-07-28 05:14:10 --> 404 Page Not Found --> web_apps/general
ERROR - 2010-07-28 05:14:16 --> 404 Page Not Found --> web_apps/general
ERROR - 2010-07-28 05:20:11 --> 404 Page Not Found --> web_apps/load_js
ERROR - 2010-07-28 05:20:12 --> 404 Page Not Found --> web_apps/load_js
ERROR - 2010-07-28 05:20:43 --> 404 Page Not Found --> web_apps/load_js
ERROR - 2010-07-28 05:20:44 --> 404 Page Not Found --> web_apps/load_js
ERROR - 2010-07-28 05:22:28 --> 404 Page Not Found --> general
ERROR - 2010-07-28 05:22:29 --> 404 Page Not Found --> general
ERROR - 2010-07-28 05:59:53 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/f4b9ec30ad9f68f89b29639786cb62ef) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-28 06:04:24 --> 404 Page Not Found --> web_apps/load_js
ERROR - 2010-07-28 06:04:24 --> 404 Page Not Found --> web_apps/pack_css
ERROR - 2010-07-28 06:04:25 --> 404 Page Not Found --> web_apps/pack_css
ERROR - 2010-07-28 06:04:25 --> 404 Page Not Found --> web_apps/load_js
ERROR - 2010-07-28 06:04:25 --> 404 Page Not Found --> web_apps/load_js
ERROR - 2010-07-28 06:04:26 --> 404 Page Not Found --> web_apps/load_js
ERROR - 2010-07-28 06:04:26 --> 404 Page Not Found --> web_apps/load_js
ERROR - 2010-07-28 06:04:26 --> 404 Page Not Found --> web_apps/load_js
ERROR - 2010-07-28 06:05:30 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/4e732ced3463d06de0ca9a15b6153677) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-28 06:06:34 --> Severity: Notice  --> Undefined variable: load_raw D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\views\qunit\helpers\jquery_extends.php 15
ERROR - 2010-07-28 06:06:41 --> 404 Page Not Found --> web_apps/load_js
ERROR - 2010-07-28 06:06:41 --> 404 Page Not Found --> web_apps/pack_js
ERROR - 2010-07-28 06:06:41 --> 404 Page Not Found --> web_apps/load_js
ERROR - 2010-07-28 07:10:53 --> Severity: Warning  --> Missing argument 1 for general::info() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\web_apps\general.php 64
ERROR - 2010-07-28 07:10:53 --> Severity: Notice  --> Undefined variable: callback D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\web_apps\general.php 71
ERROR - 2010-07-28 08:49:06 --> Severity: Notice  --> Undefined variable: load_raw D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\views\qunit\helpers\jquery_extends.php 15
ERROR - 2010-07-28 08:49:06 --> 404 Page Not Found --> web_apps/load_js
ERROR - 2010-07-28 08:49:07 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/c7e1249ffc03eb9ded908c236bd1996d) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-28 08:49:07 --> 404 Page Not Found --> web_apps/pack_js
ERROR - 2010-07-28 08:49:07 --> 404 Page Not Found --> web_apps/load_js
ERROR - 2010-07-28 08:49:08 --> 404 Page Not Found --> web_apps/load_js
ERROR - 2010-07-28 08:54:29 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/9f61408e3afb633e50cdf1b20de6f466) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-28 09:00:21 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/2838023a778dfaecdc212708f721b788) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-28 12:02:33 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/9a1158154dfa42caddbd0694a4e9bdc8) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-28 12:03:35 --> 404 Page Not Found --> web_apps/load_js
ERROR - 2010-07-28 12:03:35 --> Severity: Notice  --> Undefined variable: load_raw D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\views\qunit\helpers\jquery_extends.php 15
ERROR - 2010-07-28 12:03:35 --> 404 Page Not Found --> web_apps/pack_js
ERROR - 2010-07-28 12:03:35 --> 404 Page Not Found --> web_apps/load_js
ERROR - 2010-07-28 12:03:35 --> 404 Page Not Found --> web_apps/load_js
ERROR - 2010-07-28 12:03:41 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/f457c545a9ded88f18ecee47145a72c0) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-28 12:07:26 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/28dd2c7955ce926456240b2ff0100bde) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-28 12:20:41 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/fc490ca45c00b1249bbe3554a4fdf6fb) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-28 12:25:56 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/9778d5d219c5080b9a6a17bef029331c) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-28 12:26:29 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/7cbbc409ec990f19c78c75bd1e06f215) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-28 12:28:48 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/ed3d2c21991e3bef5e069713af9fa6ca) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-28 12:31:39 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/9bf31c7ff062936a96d3c8bd1f8f2ff3) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-28 12:44:19 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/c16a5320fa475530d9583c34fd356ef5) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-28 14:57:44 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/c0c7c76d30bd3dcaefc96f40275bdc0a) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-28 14:59:13 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/c9f0f895fb98ab9159f51fd0297e236d) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-28 15:04:31 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/32bb90e8976aab5298d5da10fe66f21d) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-28 15:13:04 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/c51ce410c124a10e0db5e4b97fc2af39) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-28 15:40:34 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/32bb90e8976aab5298d5da10fe66f21d) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-28 15:46:37 --> 404 Page Not Found --> web_apps/generaltoolkit
ERROR - 2010-07-28 15:46:38 --> 404 Page Not Found --> web_apps/generaltoolkit
ERROR - 2010-07-28 15:46:39 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/6364d3f0f495b6ab9dcf8d3b5c6e0b01) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-28 15:46:39 --> 404 Page Not Found --> web_apps/generaltoolkit
ERROR - 2010-07-28 15:46:40 --> 404 Page Not Found --> web_apps/generaltoolkit
ERROR - 2010-07-28 15:46:48 --> 404 Page Not Found --> web_apps/generaltoolkit
ERROR - 2010-07-28 15:46:52 --> 404 Page Not Found --> web_apps/generaltoolkit
ERROR - 2010-07-28 15:46:53 --> 404 Page Not Found --> web_apps/generaltoolkit
ERROR - 2010-07-28 15:48:26 --> 404 Page Not Found --> web_apps/generaltoolkit
ERROR - 2010-07-28 15:50:59 --> 404 Page Not Found --> web_apps/generaltoolkit
ERROR - 2010-07-28 15:52:18 --> 404 Page Not Found --> web_apps/generaltoolkit
ERROR - 2010-07-28 15:52:25 --> 404 Page Not Found --> web_apps/generaltoolkit
ERROR - 2010-07-28 15:52:29 --> 404 Page Not Found --> web_apps/generaltoolkit
ERROR - 2010-07-28 15:52:32 --> 404 Page Not Found --> web_apps/generaltoolkit
ERROR - 2010-07-28 15:52:34 --> 404 Page Not Found --> web_apps/generaltoolkit
ERROR - 2010-07-28 15:53:26 --> 404 Page Not Found --> web_apps/generaltoolkit
ERROR - 2010-07-28 15:53:33 --> 404 Page Not Found --> web_apps/generaltoolkit
ERROR - 2010-07-28 15:54:04 --> 404 Page Not Found --> web_apps/generaltoolkit
ERROR - 2010-07-28 15:54:12 --> 404 Page Not Found --> web_apps/generaltoolkit
ERROR - 2010-07-28 15:55:35 --> 404 Page Not Found --> web_apps/generaltoolkit
ERROR - 2010-07-28 15:55:37 --> 404 Page Not Found --> web_apps/generaltoolkit
ERROR - 2010-07-28 15:55:38 --> 404 Page Not Found --> web_apps/generaltoolkit
ERROR - 2010-07-28 15:55:39 --> 404 Page Not Found --> web_apps/generaltoolkit
ERROR - 2010-07-28 15:56:41 --> 404 Page Not Found --> web_apps/generaltoolkit
ERROR - 2010-07-28 15:57:03 --> 404 Page Not Found --> web_apps/generaltoolkit
ERROR - 2010-07-28 15:57:15 --> 404 Page Not Found --> web_apps/generaltoolkit
ERROR - 2010-07-28 15:57:17 --> 404 Page Not Found --> web_apps/generaltoolkit
ERROR - 2010-07-28 15:57:17 --> 404 Page Not Found --> web_apps/generaltoolkit
ERROR - 2010-07-28 15:57:24 --> 404 Page Not Found --> web_apps/generaltoolkit
ERROR - 2010-07-28 15:59:30 --> 404 Page Not Found --> web_apps/generaltoolkit
ERROR - 2010-07-28 15:59:30 --> 404 Page Not Found --> web_apps/generalstyle
ERROR - 2010-07-28 16:00:45 --> 404 Page Not Found --> web_apps/generaltoolkit
ERROR - 2010-07-28 16:02:37 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/66f041e16a60928b05a7e228a89c3799) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-28 16:03:57 --> Severity: Warning  --> chmod() [<a href='function.chmod'>function.chmod</a>]: No such file or directory D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 73
ERROR - 2010-07-28 16:03:57 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/02e74f10e0327ad868d138f2b4fdd6f0) [<a href='function.unlink'>function.unlink</a>]: No such file or directory D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
