<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2010-07-01 05:43:29 --> Config Class Initialized
DEBUG - 2010-07-01 05:43:29 --> Hooks Class Initialized
DEBUG - 2010-07-01 05:43:29 --> URI Class Initialized
DEBUG - 2010-07-01 05:43:29 --> Router Class Initialized
DEBUG - 2010-07-01 05:43:29 --> Output Class Initialized
DEBUG - 2010-07-01 05:43:29 --> Input Class Initialized
DEBUG - 2010-07-01 05:43:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 05:43:29 --> Language Class Initialized
DEBUG - 2010-07-01 05:43:29 --> Loader Class Initialized
DEBUG - 2010-07-01 05:43:29 --> Helper loaded: context_helper
DEBUG - 2010-07-01 05:43:29 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 05:43:29 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 05:43:29 --> Database Driver Class Initialized
DEBUG - 2010-07-01 05:43:29 --> Controller Class Initialized
DEBUG - 2010-07-01 05:43:29 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 05:43:30 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 05:43:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:43:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:43:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:43:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:43:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:43:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:43:30 --> Helper loaded: email_helper
DEBUG - 2010-07-01 05:43:30 --> User Agent Class Initialized
DEBUG - 2010-07-01 05:43:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:43:30 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:43:30 --> Session Class Initialized
DEBUG - 2010-07-01 05:43:30 --> Helper loaded: string_helper
DEBUG - 2010-07-01 05:43:30 --> A session cookie was not found.
DEBUG - 2010-07-01 05:43:30 --> Session routines successfully run
ERROR - 2010-07-01 05:43:30 --> Severity: Notice  --> Use of undefined constant FASLE - assumed 'FASLE' D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Authorize_manager.php 109
DEBUG - 2010-07-01 05:43:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:43:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:43:31 --> Action_webpage_administration class already loaded. Second attempt ignored.
ERROR - 2010-07-01 05:43:31 --> Severity: Notice  --> Use of undefined constant FASLE - assumed 'FASLE' D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Authorize_manager.php 109
DEBUG - 2010-07-01 05:43:31 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 05:43:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:43:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:43:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:43:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:43:31 --> Action_webpage_administration class already loaded. Second attempt ignored.
ERROR - 2010-07-01 05:43:31 --> Severity: Notice  --> Use of undefined constant FASLE - assumed 'FASLE' D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\policy\Authorize_manager.php 109
DEBUG - 2010-07-01 05:43:31 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 05:43:31 --> Final output sent to browser
DEBUG - 2010-07-01 05:43:31 --> Total execution time: 2.3054
DEBUG - 2010-07-01 05:43:58 --> Config Class Initialized
DEBUG - 2010-07-01 05:43:58 --> Hooks Class Initialized
DEBUG - 2010-07-01 05:43:58 --> URI Class Initialized
DEBUG - 2010-07-01 05:43:58 --> Router Class Initialized
DEBUG - 2010-07-01 05:43:58 --> Output Class Initialized
DEBUG - 2010-07-01 05:43:58 --> Input Class Initialized
DEBUG - 2010-07-01 05:43:58 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 05:43:58 --> Language Class Initialized
DEBUG - 2010-07-01 05:43:58 --> Loader Class Initialized
DEBUG - 2010-07-01 05:43:58 --> Helper loaded: context_helper
DEBUG - 2010-07-01 05:43:58 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 05:43:58 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 05:43:58 --> Database Driver Class Initialized
DEBUG - 2010-07-01 05:43:58 --> Controller Class Initialized
DEBUG - 2010-07-01 05:43:58 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 05:43:58 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 05:43:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:43:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:43:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:43:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:43:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:43:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:43:58 --> Helper loaded: email_helper
DEBUG - 2010-07-01 05:43:58 --> User Agent Class Initialized
DEBUG - 2010-07-01 05:43:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:43:58 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:43:58 --> Session Class Initialized
DEBUG - 2010-07-01 05:43:58 --> Helper loaded: string_helper
DEBUG - 2010-07-01 05:43:58 --> Session routines successfully run
DEBUG - 2010-07-01 05:43:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:43:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:43:59 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:43:59 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 05:43:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:43:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:43:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:43:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:43:59 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:43:59 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 05:43:59 --> Final output sent to browser
DEBUG - 2010-07-01 05:43:59 --> Total execution time: 1.2620
DEBUG - 2010-07-01 05:44:51 --> Config Class Initialized
DEBUG - 2010-07-01 05:44:51 --> Hooks Class Initialized
DEBUG - 2010-07-01 05:44:51 --> URI Class Initialized
DEBUG - 2010-07-01 05:44:51 --> Router Class Initialized
DEBUG - 2010-07-01 05:44:51 --> Output Class Initialized
DEBUG - 2010-07-01 05:44:51 --> Input Class Initialized
DEBUG - 2010-07-01 05:44:51 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 05:44:51 --> Language Class Initialized
DEBUG - 2010-07-01 05:44:51 --> Loader Class Initialized
DEBUG - 2010-07-01 05:44:51 --> Helper loaded: context_helper
DEBUG - 2010-07-01 05:44:51 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 05:44:51 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 05:44:51 --> Database Driver Class Initialized
DEBUG - 2010-07-01 05:44:51 --> Controller Class Initialized
DEBUG - 2010-07-01 05:44:51 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 05:44:51 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 05:44:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:44:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:44:51 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:44:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:44:51 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:44:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:44:51 --> Helper loaded: email_helper
DEBUG - 2010-07-01 05:44:51 --> User Agent Class Initialized
DEBUG - 2010-07-01 05:44:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:44:51 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:44:51 --> Session Class Initialized
DEBUG - 2010-07-01 05:44:51 --> Helper loaded: string_helper
DEBUG - 2010-07-01 05:44:51 --> Session routines successfully run
ERROR - 2010-07-01 05:44:51 --> Severity: Notice  --> Undefined property: Context::$logger D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 169
DEBUG - 2010-07-01 05:46:16 --> Config Class Initialized
DEBUG - 2010-07-01 05:46:16 --> Hooks Class Initialized
DEBUG - 2010-07-01 05:46:16 --> URI Class Initialized
DEBUG - 2010-07-01 05:46:16 --> Router Class Initialized
DEBUG - 2010-07-01 05:46:16 --> Output Class Initialized
DEBUG - 2010-07-01 05:46:16 --> Input Class Initialized
DEBUG - 2010-07-01 05:46:16 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 05:46:16 --> Language Class Initialized
DEBUG - 2010-07-01 05:46:16 --> Loader Class Initialized
DEBUG - 2010-07-01 05:46:16 --> Helper loaded: context_helper
DEBUG - 2010-07-01 05:46:16 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 05:46:16 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 05:46:16 --> Database Driver Class Initialized
DEBUG - 2010-07-01 05:46:16 --> Controller Class Initialized
DEBUG - 2010-07-01 05:46:16 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 05:46:16 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 05:46:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:46:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:46:16 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:46:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:46:16 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:46:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:46:16 --> Helper loaded: email_helper
DEBUG - 2010-07-01 05:46:17 --> User Agent Class Initialized
DEBUG - 2010-07-01 05:46:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:46:17 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:46:17 --> Session Class Initialized
DEBUG - 2010-07-01 05:46:17 --> Helper loaded: string_helper
DEBUG - 2010-07-01 05:46:17 --> Session routines successfully run
ERROR - 2010-07-01 05:46:18 --> 管理Webpage
DEBUG - 2010-07-01 05:46:26 --> Config Class Initialized
DEBUG - 2010-07-01 05:46:26 --> Hooks Class Initialized
DEBUG - 2010-07-01 05:46:26 --> URI Class Initialized
DEBUG - 2010-07-01 05:46:26 --> Router Class Initialized
DEBUG - 2010-07-01 05:46:26 --> Output Class Initialized
DEBUG - 2010-07-01 05:46:26 --> Input Class Initialized
DEBUG - 2010-07-01 05:46:26 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 05:46:26 --> Language Class Initialized
DEBUG - 2010-07-01 05:46:26 --> Loader Class Initialized
DEBUG - 2010-07-01 05:46:26 --> Helper loaded: context_helper
DEBUG - 2010-07-01 05:46:26 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 05:46:26 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 05:46:26 --> Database Driver Class Initialized
DEBUG - 2010-07-01 05:46:26 --> Controller Class Initialized
DEBUG - 2010-07-01 05:46:26 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 05:46:26 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 05:46:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:46:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:46:26 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:46:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:46:26 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:46:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:46:26 --> Helper loaded: email_helper
DEBUG - 2010-07-01 05:46:26 --> User Agent Class Initialized
DEBUG - 2010-07-01 05:46:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:46:26 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:46:26 --> Session Class Initialized
DEBUG - 2010-07-01 05:46:26 --> Helper loaded: string_helper
DEBUG - 2010-07-01 05:46:26 --> Session routines successfully run
ERROR - 2010-07-01 05:46:27 --> 管理Webpage
DEBUG - 2010-07-01 05:46:56 --> Config Class Initialized
DEBUG - 2010-07-01 05:46:56 --> Hooks Class Initialized
DEBUG - 2010-07-01 05:46:56 --> URI Class Initialized
DEBUG - 2010-07-01 05:46:56 --> Router Class Initialized
DEBUG - 2010-07-01 05:46:56 --> Output Class Initialized
DEBUG - 2010-07-01 05:46:56 --> Input Class Initialized
DEBUG - 2010-07-01 05:46:57 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 05:46:57 --> Language Class Initialized
DEBUG - 2010-07-01 05:46:57 --> Loader Class Initialized
DEBUG - 2010-07-01 05:46:57 --> Helper loaded: context_helper
DEBUG - 2010-07-01 05:46:57 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 05:46:57 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 05:46:57 --> Database Driver Class Initialized
DEBUG - 2010-07-01 05:46:57 --> Controller Class Initialized
DEBUG - 2010-07-01 05:46:57 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 05:46:57 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 05:46:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:46:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:46:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:46:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:46:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:46:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:46:57 --> Helper loaded: email_helper
DEBUG - 2010-07-01 05:46:57 --> User Agent Class Initialized
DEBUG - 2010-07-01 05:46:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:46:57 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:46:57 --> Session Class Initialized
DEBUG - 2010-07-01 05:46:57 --> Helper loaded: string_helper
DEBUG - 2010-07-01 05:46:57 --> Session routines successfully run
ERROR - 2010-07-01 05:46:57 --> 管理Webpage錯誤
DEBUG - 2010-07-01 05:48:21 --> Config Class Initialized
DEBUG - 2010-07-01 05:48:21 --> Hooks Class Initialized
DEBUG - 2010-07-01 05:48:21 --> URI Class Initialized
DEBUG - 2010-07-01 05:48:21 --> Router Class Initialized
DEBUG - 2010-07-01 05:48:21 --> Output Class Initialized
DEBUG - 2010-07-01 05:48:21 --> Input Class Initialized
DEBUG - 2010-07-01 05:48:21 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 05:48:21 --> Language Class Initialized
DEBUG - 2010-07-01 05:48:21 --> Loader Class Initialized
DEBUG - 2010-07-01 05:48:21 --> Helper loaded: context_helper
DEBUG - 2010-07-01 05:48:21 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 05:48:21 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 05:48:21 --> Database Driver Class Initialized
DEBUG - 2010-07-01 05:48:22 --> Controller Class Initialized
DEBUG - 2010-07-01 05:48:22 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 05:48:22 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 05:48:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:48:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:48:22 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:48:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:48:22 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:48:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:48:22 --> Helper loaded: email_helper
DEBUG - 2010-07-01 05:48:22 --> User Agent Class Initialized
DEBUG - 2010-07-01 05:48:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:48:22 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:48:22 --> Session Class Initialized
DEBUG - 2010-07-01 05:48:22 --> Helper loaded: string_helper
DEBUG - 2010-07-01 05:48:22 --> Session routines successfully run
ERROR - 2010-07-01 05:48:22 --> 管理Webpage錯誤
DEBUG - 2010-07-01 05:51:28 --> Config Class Initialized
DEBUG - 2010-07-01 05:51:28 --> Hooks Class Initialized
DEBUG - 2010-07-01 05:51:28 --> URI Class Initialized
DEBUG - 2010-07-01 05:51:28 --> Router Class Initialized
DEBUG - 2010-07-01 05:51:28 --> Output Class Initialized
DEBUG - 2010-07-01 05:51:28 --> Input Class Initialized
DEBUG - 2010-07-01 05:51:28 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 05:51:28 --> Language Class Initialized
DEBUG - 2010-07-01 05:51:28 --> Loader Class Initialized
DEBUG - 2010-07-01 05:51:28 --> Helper loaded: context_helper
DEBUG - 2010-07-01 05:51:28 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 05:51:28 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 05:51:28 --> Database Driver Class Initialized
DEBUG - 2010-07-01 05:51:28 --> Controller Class Initialized
DEBUG - 2010-07-01 05:51:28 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 05:51:28 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 05:51:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:51:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:51:28 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:51:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:51:28 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:51:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:51:28 --> Helper loaded: email_helper
DEBUG - 2010-07-01 05:51:28 --> User Agent Class Initialized
DEBUG - 2010-07-01 05:51:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:51:28 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:51:28 --> Session Class Initialized
DEBUG - 2010-07-01 05:51:28 --> Helper loaded: string_helper
DEBUG - 2010-07-01 05:51:28 --> Session routines successfully run
ERROR - 2010-07-01 05:51:28 --> 管理Webpage錯誤
DEBUG - 2010-07-01 05:51:48 --> Config Class Initialized
DEBUG - 2010-07-01 05:51:48 --> Hooks Class Initialized
DEBUG - 2010-07-01 05:51:48 --> URI Class Initialized
DEBUG - 2010-07-01 05:51:48 --> Router Class Initialized
DEBUG - 2010-07-01 05:51:48 --> Output Class Initialized
DEBUG - 2010-07-01 05:51:48 --> Input Class Initialized
DEBUG - 2010-07-01 05:51:48 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 05:51:48 --> Language Class Initialized
DEBUG - 2010-07-01 05:51:48 --> Loader Class Initialized
DEBUG - 2010-07-01 05:51:48 --> Helper loaded: context_helper
DEBUG - 2010-07-01 05:51:48 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 05:51:48 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 05:51:48 --> Database Driver Class Initialized
DEBUG - 2010-07-01 05:51:48 --> Controller Class Initialized
DEBUG - 2010-07-01 05:51:48 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 05:51:48 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 05:51:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:51:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:51:48 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:51:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:51:48 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:51:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:51:48 --> Helper loaded: email_helper
DEBUG - 2010-07-01 05:51:48 --> User Agent Class Initialized
DEBUG - 2010-07-01 05:51:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:51:48 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:51:48 --> Session Class Initialized
DEBUG - 2010-07-01 05:51:48 --> Helper loaded: string_helper
DEBUG - 2010-07-01 05:51:48 --> Session routines successfully run
DEBUG - 2010-07-01 05:51:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:51:49 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:51:49 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:51:49 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 05:51:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:51:49 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:51:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:51:49 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:51:49 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 05:51:49 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 05:51:49 --> Final output sent to browser
DEBUG - 2010-07-01 05:51:49 --> Total execution time: 1.4516
DEBUG - 2010-07-01 06:03:24 --> Config Class Initialized
DEBUG - 2010-07-01 06:03:24 --> Hooks Class Initialized
DEBUG - 2010-07-01 06:03:24 --> URI Class Initialized
DEBUG - 2010-07-01 06:03:24 --> Router Class Initialized
DEBUG - 2010-07-01 06:03:24 --> Output Class Initialized
DEBUG - 2010-07-01 06:03:24 --> Input Class Initialized
DEBUG - 2010-07-01 06:03:24 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 06:03:24 --> Language Class Initialized
DEBUG - 2010-07-01 06:03:24 --> Loader Class Initialized
DEBUG - 2010-07-01 06:03:24 --> Helper loaded: context_helper
DEBUG - 2010-07-01 06:03:24 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 06:03:24 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 06:03:24 --> Database Driver Class Initialized
DEBUG - 2010-07-01 06:03:24 --> Controller Class Initialized
DEBUG - 2010-07-01 06:03:24 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 06:03:24 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 06:03:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:03:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:03:24 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:03:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:03:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:03:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:03:25 --> Helper loaded: email_helper
DEBUG - 2010-07-01 06:03:25 --> User Agent Class Initialized
DEBUG - 2010-07-01 06:03:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:03:25 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:03:25 --> Session Class Initialized
DEBUG - 2010-07-01 06:03:25 --> Helper loaded: string_helper
DEBUG - 2010-07-01 06:03:25 --> Session routines successfully run
DEBUG - 2010-07-01 06:03:59 --> Config Class Initialized
DEBUG - 2010-07-01 06:03:59 --> Hooks Class Initialized
DEBUG - 2010-07-01 06:03:59 --> URI Class Initialized
DEBUG - 2010-07-01 06:03:59 --> Router Class Initialized
DEBUG - 2010-07-01 06:03:59 --> Output Class Initialized
DEBUG - 2010-07-01 06:03:59 --> Input Class Initialized
DEBUG - 2010-07-01 06:03:59 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 06:03:59 --> Language Class Initialized
DEBUG - 2010-07-01 06:03:59 --> Loader Class Initialized
DEBUG - 2010-07-01 06:03:59 --> Helper loaded: context_helper
DEBUG - 2010-07-01 06:03:59 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 06:03:59 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 06:03:59 --> Database Driver Class Initialized
DEBUG - 2010-07-01 06:03:59 --> Controller Class Initialized
DEBUG - 2010-07-01 06:03:59 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 06:03:59 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 06:03:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:03:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:03:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:03:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:03:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:04:00 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:04:00 --> Helper loaded: email_helper
DEBUG - 2010-07-01 06:04:00 --> User Agent Class Initialized
DEBUG - 2010-07-01 06:04:00 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:04:00 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:04:00 --> Session Class Initialized
DEBUG - 2010-07-01 06:04:00 --> Helper loaded: string_helper
DEBUG - 2010-07-01 06:04:00 --> Session routines successfully run
DEBUG - 2010-07-01 06:04:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:04:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:04:01 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:04:01 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 06:04:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:04:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:04:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:04:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:04:01 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:04:01 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 06:04:01 --> Final output sent to browser
DEBUG - 2010-07-01 06:04:01 --> Total execution time: 1.5388
DEBUG - 2010-07-01 06:04:16 --> Config Class Initialized
DEBUG - 2010-07-01 06:04:16 --> Hooks Class Initialized
DEBUG - 2010-07-01 06:04:16 --> URI Class Initialized
DEBUG - 2010-07-01 06:04:16 --> Router Class Initialized
DEBUG - 2010-07-01 06:04:16 --> Output Class Initialized
DEBUG - 2010-07-01 06:04:16 --> Input Class Initialized
DEBUG - 2010-07-01 06:04:16 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 06:04:16 --> Language Class Initialized
DEBUG - 2010-07-01 06:04:16 --> Loader Class Initialized
DEBUG - 2010-07-01 06:04:16 --> Helper loaded: context_helper
DEBUG - 2010-07-01 06:04:16 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 06:04:16 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 06:04:16 --> Database Driver Class Initialized
DEBUG - 2010-07-01 06:04:16 --> Controller Class Initialized
DEBUG - 2010-07-01 06:04:16 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 06:04:16 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 06:04:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:04:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:04:16 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:04:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:04:16 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:04:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:04:16 --> Helper loaded: email_helper
DEBUG - 2010-07-01 06:04:16 --> User Agent Class Initialized
DEBUG - 2010-07-01 06:04:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:04:16 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:04:16 --> Session Class Initialized
DEBUG - 2010-07-01 06:04:16 --> Helper loaded: string_helper
DEBUG - 2010-07-01 06:04:16 --> Session routines successfully run
ERROR - 2010-07-01 06:04:17 --> 管理Webpage錯誤
DEBUG - 2010-07-01 06:27:55 --> Config Class Initialized
DEBUG - 2010-07-01 06:27:55 --> Hooks Class Initialized
DEBUG - 2010-07-01 06:27:55 --> URI Class Initialized
DEBUG - 2010-07-01 06:27:55 --> Router Class Initialized
DEBUG - 2010-07-01 06:27:55 --> Output Class Initialized
DEBUG - 2010-07-01 06:27:55 --> Input Class Initialized
DEBUG - 2010-07-01 06:27:55 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 06:27:55 --> Language Class Initialized
DEBUG - 2010-07-01 06:27:55 --> Loader Class Initialized
DEBUG - 2010-07-01 06:27:55 --> Helper loaded: context_helper
DEBUG - 2010-07-01 06:27:55 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 06:27:55 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 06:27:55 --> Database Driver Class Initialized
DEBUG - 2010-07-01 06:27:55 --> Controller Class Initialized
DEBUG - 2010-07-01 06:27:55 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 06:27:55 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 06:27:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:27:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:27:55 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:27:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:27:55 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:27:55 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:27:55 --> Helper loaded: email_helper
DEBUG - 2010-07-01 06:27:55 --> User Agent Class Initialized
DEBUG - 2010-07-01 06:27:55 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:27:55 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:27:55 --> Session Class Initialized
DEBUG - 2010-07-01 06:27:55 --> Helper loaded: string_helper
DEBUG - 2010-07-01 06:27:55 --> Session routines successfully run
DEBUG - 2010-07-01 06:27:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:27:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:27:56 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:27:57 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 06:27:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:27:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:27:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:27:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:27:57 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:27:57 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 06:27:57 --> Final output sent to browser
DEBUG - 2010-07-01 06:27:57 --> Total execution time: 1.6543
DEBUG - 2010-07-01 06:28:08 --> Config Class Initialized
DEBUG - 2010-07-01 06:28:08 --> Hooks Class Initialized
DEBUG - 2010-07-01 06:28:08 --> URI Class Initialized
DEBUG - 2010-07-01 06:28:08 --> Router Class Initialized
DEBUG - 2010-07-01 06:28:08 --> Output Class Initialized
DEBUG - 2010-07-01 06:28:08 --> Input Class Initialized
DEBUG - 2010-07-01 06:28:08 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 06:28:08 --> Language Class Initialized
DEBUG - 2010-07-01 06:28:08 --> Loader Class Initialized
DEBUG - 2010-07-01 06:28:08 --> Helper loaded: context_helper
DEBUG - 2010-07-01 06:28:08 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 06:28:08 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 06:28:08 --> Database Driver Class Initialized
DEBUG - 2010-07-01 06:28:08 --> Controller Class Initialized
DEBUG - 2010-07-01 06:28:08 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 06:28:08 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 06:28:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:08 --> Helper loaded: email_helper
DEBUG - 2010-07-01 06:28:08 --> User Agent Class Initialized
DEBUG - 2010-07-01 06:28:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:08 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:09 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 06:28:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:09 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 06:28:09 --> Final output sent to browser
DEBUG - 2010-07-01 06:28:09 --> Total execution time: 1.7389
DEBUG - 2010-07-01 06:28:18 --> Config Class Initialized
DEBUG - 2010-07-01 06:28:18 --> Hooks Class Initialized
DEBUG - 2010-07-01 06:28:18 --> URI Class Initialized
DEBUG - 2010-07-01 06:28:18 --> Router Class Initialized
DEBUG - 2010-07-01 06:28:18 --> Output Class Initialized
DEBUG - 2010-07-01 06:28:18 --> Input Class Initialized
DEBUG - 2010-07-01 06:28:18 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 06:28:18 --> Language Class Initialized
DEBUG - 2010-07-01 06:28:18 --> Loader Class Initialized
DEBUG - 2010-07-01 06:28:18 --> Helper loaded: context_helper
DEBUG - 2010-07-01 06:28:18 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 06:28:18 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 06:28:18 --> Database Driver Class Initialized
DEBUG - 2010-07-01 06:28:18 --> Controller Class Initialized
DEBUG - 2010-07-01 06:28:18 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 06:28:18 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 06:28:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:18 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:18 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:18 --> Helper loaded: email_helper
DEBUG - 2010-07-01 06:28:18 --> User Agent Class Initialized
DEBUG - 2010-07-01 06:28:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:18 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:18 --> Session Class Initialized
DEBUG - 2010-07-01 06:28:18 --> Helper loaded: string_helper
DEBUG - 2010-07-01 06:28:18 --> Session routines successfully run
DEBUG - 2010-07-01 06:28:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:20 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:20 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 06:28:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:20 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:20 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 06:28:20 --> Final output sent to browser
DEBUG - 2010-07-01 06:28:20 --> Total execution time: 1.9537
DEBUG - 2010-07-01 06:28:29 --> Config Class Initialized
DEBUG - 2010-07-01 06:28:29 --> Hooks Class Initialized
DEBUG - 2010-07-01 06:28:29 --> URI Class Initialized
DEBUG - 2010-07-01 06:28:29 --> Router Class Initialized
DEBUG - 2010-07-01 06:28:29 --> Output Class Initialized
DEBUG - 2010-07-01 06:28:29 --> Input Class Initialized
DEBUG - 2010-07-01 06:28:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 06:28:29 --> Language Class Initialized
DEBUG - 2010-07-01 06:28:29 --> Loader Class Initialized
DEBUG - 2010-07-01 06:28:29 --> Helper loaded: context_helper
DEBUG - 2010-07-01 06:28:29 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 06:28:29 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 06:28:29 --> Database Driver Class Initialized
DEBUG - 2010-07-01 06:28:29 --> Controller Class Initialized
DEBUG - 2010-07-01 06:28:29 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 06:28:29 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 06:28:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:29 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:29 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:29 --> Helper loaded: email_helper
DEBUG - 2010-07-01 06:28:29 --> User Agent Class Initialized
DEBUG - 2010-07-01 06:28:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:29 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:28:29 --> Session Class Initialized
DEBUG - 2010-07-01 06:28:29 --> Helper loaded: string_helper
DEBUG - 2010-07-01 06:28:30 --> Session routines successfully run
ERROR - 2010-07-01 06:28:30 --> 管理Webpage錯誤
DEBUG - 2010-07-01 06:29:59 --> Config Class Initialized
DEBUG - 2010-07-01 06:29:59 --> Hooks Class Initialized
DEBUG - 2010-07-01 06:29:59 --> URI Class Initialized
DEBUG - 2010-07-01 06:29:59 --> Router Class Initialized
DEBUG - 2010-07-01 06:29:59 --> Output Class Initialized
DEBUG - 2010-07-01 06:29:59 --> Input Class Initialized
DEBUG - 2010-07-01 06:29:59 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 06:29:59 --> Language Class Initialized
DEBUG - 2010-07-01 06:29:59 --> Loader Class Initialized
DEBUG - 2010-07-01 06:29:59 --> Helper loaded: context_helper
DEBUG - 2010-07-01 06:29:59 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 06:29:59 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 06:29:59 --> Database Driver Class Initialized
DEBUG - 2010-07-01 06:29:59 --> Controller Class Initialized
DEBUG - 2010-07-01 06:29:59 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 06:29:59 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 06:29:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:29:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:29:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:29:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:29:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:29:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:29:59 --> Helper loaded: email_helper
DEBUG - 2010-07-01 06:29:59 --> User Agent Class Initialized
DEBUG - 2010-07-01 06:29:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:29:59 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:30:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:30:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:30:00 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:30:00 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 06:30:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:30:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:30:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:30:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:30:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:30:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:30:00 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:30:00 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 06:30:00 --> Final output sent to browser
DEBUG - 2010-07-01 06:30:00 --> Total execution time: 1.8346
DEBUG - 2010-07-01 06:31:56 --> Config Class Initialized
DEBUG - 2010-07-01 06:31:56 --> Hooks Class Initialized
DEBUG - 2010-07-01 06:31:56 --> URI Class Initialized
DEBUG - 2010-07-01 06:31:56 --> Router Class Initialized
DEBUG - 2010-07-01 06:31:56 --> Output Class Initialized
DEBUG - 2010-07-01 06:31:56 --> Input Class Initialized
DEBUG - 2010-07-01 06:31:56 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 06:31:56 --> Language Class Initialized
DEBUG - 2010-07-01 06:31:56 --> Loader Class Initialized
DEBUG - 2010-07-01 06:31:56 --> Helper loaded: context_helper
DEBUG - 2010-07-01 06:31:56 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 06:31:56 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 06:31:56 --> Database Driver Class Initialized
DEBUG - 2010-07-01 06:31:56 --> Controller Class Initialized
DEBUG - 2010-07-01 06:31:56 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 06:31:56 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 06:31:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:31:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:31:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:31:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:31:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:31:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:31:56 --> Helper loaded: email_helper
DEBUG - 2010-07-01 06:31:56 --> User Agent Class Initialized
DEBUG - 2010-07-01 06:31:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:31:56 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:31:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:31:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:31:57 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:31:57 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 06:31:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:31:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:31:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:31:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:31:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:31:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:31:57 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:31:57 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 06:31:58 --> Final output sent to browser
DEBUG - 2010-07-01 06:31:58 --> Total execution time: 1.7918
DEBUG - 2010-07-01 06:32:31 --> Config Class Initialized
DEBUG - 2010-07-01 06:32:31 --> Hooks Class Initialized
DEBUG - 2010-07-01 06:32:31 --> URI Class Initialized
DEBUG - 2010-07-01 06:32:31 --> Router Class Initialized
DEBUG - 2010-07-01 06:32:31 --> Output Class Initialized
DEBUG - 2010-07-01 06:32:31 --> Input Class Initialized
DEBUG - 2010-07-01 06:32:31 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 06:32:31 --> Language Class Initialized
DEBUG - 2010-07-01 06:32:31 --> Loader Class Initialized
DEBUG - 2010-07-01 06:32:31 --> Helper loaded: context_helper
DEBUG - 2010-07-01 06:32:31 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 06:32:31 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 06:32:32 --> Database Driver Class Initialized
DEBUG - 2010-07-01 06:32:32 --> Controller Class Initialized
DEBUG - 2010-07-01 06:32:32 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 06:32:32 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 06:32:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:32 --> Helper loaded: email_helper
DEBUG - 2010-07-01 06:32:32 --> User Agent Class Initialized
DEBUG - 2010-07-01 06:32:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:32 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:33 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:33 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 06:32:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:33 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:33 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 06:32:33 --> Final output sent to browser
DEBUG - 2010-07-01 06:32:33 --> Total execution time: 1.6951
DEBUG - 2010-07-01 06:32:54 --> Config Class Initialized
DEBUG - 2010-07-01 06:32:54 --> Hooks Class Initialized
DEBUG - 2010-07-01 06:32:54 --> URI Class Initialized
DEBUG - 2010-07-01 06:32:54 --> Router Class Initialized
DEBUG - 2010-07-01 06:32:54 --> Output Class Initialized
DEBUG - 2010-07-01 06:32:54 --> Input Class Initialized
DEBUG - 2010-07-01 06:32:54 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 06:32:54 --> Language Class Initialized
DEBUG - 2010-07-01 06:32:54 --> Loader Class Initialized
DEBUG - 2010-07-01 06:32:54 --> Helper loaded: context_helper
DEBUG - 2010-07-01 06:32:55 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 06:32:55 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 06:32:55 --> Database Driver Class Initialized
DEBUG - 2010-07-01 06:32:55 --> Controller Class Initialized
DEBUG - 2010-07-01 06:32:55 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 06:32:55 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 06:32:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:55 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:55 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:55 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:55 --> Helper loaded: email_helper
DEBUG - 2010-07-01 06:32:55 --> User Agent Class Initialized
DEBUG - 2010-07-01 06:32:55 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:55 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:56 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:56 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 06:32:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:56 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:32:56 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 06:32:56 --> Final output sent to browser
DEBUG - 2010-07-01 06:32:56 --> Total execution time: 1.8549
DEBUG - 2010-07-01 06:33:17 --> Config Class Initialized
DEBUG - 2010-07-01 06:33:17 --> Hooks Class Initialized
DEBUG - 2010-07-01 06:33:17 --> URI Class Initialized
DEBUG - 2010-07-01 06:33:17 --> Router Class Initialized
DEBUG - 2010-07-01 06:33:17 --> Output Class Initialized
DEBUG - 2010-07-01 06:33:17 --> Input Class Initialized
DEBUG - 2010-07-01 06:33:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 06:33:17 --> Language Class Initialized
DEBUG - 2010-07-01 06:33:17 --> Loader Class Initialized
DEBUG - 2010-07-01 06:33:17 --> Helper loaded: context_helper
DEBUG - 2010-07-01 06:33:17 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 06:33:18 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 06:33:18 --> Database Driver Class Initialized
DEBUG - 2010-07-01 06:33:18 --> Controller Class Initialized
DEBUG - 2010-07-01 06:33:18 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 06:33:18 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 06:33:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:18 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:18 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:18 --> Helper loaded: email_helper
DEBUG - 2010-07-01 06:33:18 --> User Agent Class Initialized
DEBUG - 2010-07-01 06:33:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:18 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:19 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:19 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 06:33:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:19 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:19 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 06:33:19 --> Final output sent to browser
DEBUG - 2010-07-01 06:33:19 --> Total execution time: 1.7719
DEBUG - 2010-07-01 06:33:44 --> Config Class Initialized
DEBUG - 2010-07-01 06:33:44 --> Hooks Class Initialized
DEBUG - 2010-07-01 06:33:44 --> URI Class Initialized
DEBUG - 2010-07-01 06:33:44 --> Router Class Initialized
DEBUG - 2010-07-01 06:33:44 --> Output Class Initialized
DEBUG - 2010-07-01 06:33:44 --> Input Class Initialized
DEBUG - 2010-07-01 06:33:44 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 06:33:44 --> Language Class Initialized
DEBUG - 2010-07-01 06:33:44 --> Loader Class Initialized
DEBUG - 2010-07-01 06:33:44 --> Helper loaded: context_helper
DEBUG - 2010-07-01 06:33:44 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 06:33:44 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 06:33:44 --> Database Driver Class Initialized
DEBUG - 2010-07-01 06:33:44 --> Controller Class Initialized
DEBUG - 2010-07-01 06:33:44 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 06:33:44 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 06:33:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:45 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:45 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:45 --> Helper loaded: email_helper
DEBUG - 2010-07-01 06:33:45 --> User Agent Class Initialized
DEBUG - 2010-07-01 06:33:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:45 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:45 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:47 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:47 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 06:33:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:47 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:47 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:47 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:47 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:33:47 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 06:33:47 --> Final output sent to browser
DEBUG - 2010-07-01 06:33:47 --> Total execution time: 2.9200
DEBUG - 2010-07-01 06:34:15 --> Config Class Initialized
DEBUG - 2010-07-01 06:34:15 --> Hooks Class Initialized
DEBUG - 2010-07-01 06:34:15 --> URI Class Initialized
DEBUG - 2010-07-01 06:34:15 --> Router Class Initialized
DEBUG - 2010-07-01 06:34:15 --> Output Class Initialized
DEBUG - 2010-07-01 06:34:15 --> Input Class Initialized
DEBUG - 2010-07-01 06:34:15 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 06:34:15 --> Language Class Initialized
DEBUG - 2010-07-01 06:34:15 --> Loader Class Initialized
DEBUG - 2010-07-01 06:34:15 --> Helper loaded: context_helper
DEBUG - 2010-07-01 06:34:15 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 06:34:15 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 06:34:15 --> Database Driver Class Initialized
DEBUG - 2010-07-01 06:34:15 --> Controller Class Initialized
DEBUG - 2010-07-01 06:34:15 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 06:34:15 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 06:34:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:15 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:15 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:15 --> Helper loaded: email_helper
DEBUG - 2010-07-01 06:34:15 --> User Agent Class Initialized
DEBUG - 2010-07-01 06:34:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:15 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:16 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:16 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 06:34:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:16 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:17 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 06:34:17 --> Final output sent to browser
DEBUG - 2010-07-01 06:34:17 --> Total execution time: 1.9049
DEBUG - 2010-07-01 06:34:31 --> Config Class Initialized
DEBUG - 2010-07-01 06:34:31 --> Hooks Class Initialized
DEBUG - 2010-07-01 06:34:31 --> URI Class Initialized
DEBUG - 2010-07-01 06:34:31 --> Router Class Initialized
DEBUG - 2010-07-01 06:34:31 --> Output Class Initialized
DEBUG - 2010-07-01 06:34:31 --> Input Class Initialized
DEBUG - 2010-07-01 06:34:31 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 06:34:31 --> Language Class Initialized
DEBUG - 2010-07-01 06:34:31 --> Loader Class Initialized
DEBUG - 2010-07-01 06:34:31 --> Helper loaded: context_helper
DEBUG - 2010-07-01 06:34:31 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 06:34:31 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 06:34:31 --> Database Driver Class Initialized
DEBUG - 2010-07-01 06:34:31 --> Controller Class Initialized
DEBUG - 2010-07-01 06:34:31 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 06:34:31 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 06:34:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:32 --> Helper loaded: email_helper
DEBUG - 2010-07-01 06:34:32 --> User Agent Class Initialized
DEBUG - 2010-07-01 06:34:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:32 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:32 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:33 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 06:34:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:33 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:34:33 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 06:34:33 --> Final output sent to browser
DEBUG - 2010-07-01 06:34:33 --> Total execution time: 1.8683
DEBUG - 2010-07-01 06:35:35 --> Config Class Initialized
DEBUG - 2010-07-01 06:35:35 --> Hooks Class Initialized
DEBUG - 2010-07-01 06:35:35 --> URI Class Initialized
DEBUG - 2010-07-01 06:35:35 --> Router Class Initialized
DEBUG - 2010-07-01 06:35:35 --> Output Class Initialized
DEBUG - 2010-07-01 06:35:35 --> Input Class Initialized
DEBUG - 2010-07-01 06:35:35 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 06:35:35 --> Language Class Initialized
DEBUG - 2010-07-01 06:35:35 --> Loader Class Initialized
DEBUG - 2010-07-01 06:35:35 --> Helper loaded: context_helper
DEBUG - 2010-07-01 06:35:35 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 06:35:35 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 06:35:35 --> Database Driver Class Initialized
DEBUG - 2010-07-01 06:35:35 --> Controller Class Initialized
DEBUG - 2010-07-01 06:35:35 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 06:35:35 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 06:35:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:35:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:35:35 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:35:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:35:35 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:35:35 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:35:35 --> Helper loaded: email_helper
DEBUG - 2010-07-01 06:35:35 --> User Agent Class Initialized
DEBUG - 2010-07-01 06:35:35 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:35:35 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:39:25 --> Config Class Initialized
DEBUG - 2010-07-01 06:39:25 --> Hooks Class Initialized
DEBUG - 2010-07-01 06:39:25 --> URI Class Initialized
DEBUG - 2010-07-01 06:39:25 --> Router Class Initialized
DEBUG - 2010-07-01 06:39:25 --> Output Class Initialized
ERROR - 2010-07-01 06:39:25 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/66f041e16a60928b05a7e228a89c3799) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
DEBUG - 2010-07-01 06:39:25 --> Input Class Initialized
DEBUG - 2010-07-01 06:39:25 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 06:39:25 --> Language Class Initialized
DEBUG - 2010-07-01 06:39:25 --> Loader Class Initialized
DEBUG - 2010-07-01 06:39:25 --> Helper loaded: context_helper
DEBUG - 2010-07-01 06:39:25 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 06:39:25 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 06:39:25 --> Database Driver Class Initialized
DEBUG - 2010-07-01 06:39:25 --> Controller Class Initialized
DEBUG - 2010-07-01 06:39:25 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 06:39:25 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 06:39:25 --> Helper loaded: cookie_helper
DEBUG - 2010-07-01 06:39:25 --> Session Class Initialized
DEBUG - 2010-07-01 06:39:25 --> Helper loaded: string_helper
DEBUG - 2010-07-01 06:39:25 --> Session routines successfully run
ERROR - 2010-07-01 06:39:25 --> Severity: Notice  --> Undefined property: Domain::$auth D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 51
DEBUG - 2010-07-01 06:40:07 --> Config Class Initialized
DEBUG - 2010-07-01 06:40:07 --> Hooks Class Initialized
DEBUG - 2010-07-01 06:40:07 --> URI Class Initialized
DEBUG - 2010-07-01 06:40:07 --> Router Class Initialized
DEBUG - 2010-07-01 06:40:07 --> Output Class Initialized
DEBUG - 2010-07-01 06:40:07 --> Input Class Initialized
DEBUG - 2010-07-01 06:40:07 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 06:40:07 --> Language Class Initialized
DEBUG - 2010-07-01 06:40:07 --> Loader Class Initialized
DEBUG - 2010-07-01 06:40:07 --> Helper loaded: context_helper
DEBUG - 2010-07-01 06:40:07 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 06:40:07 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 06:40:07 --> Database Driver Class Initialized
DEBUG - 2010-07-01 06:40:07 --> Controller Class Initialized
DEBUG - 2010-07-01 06:40:07 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 06:40:07 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 06:40:07 --> Helper loaded: cookie_helper
DEBUG - 2010-07-01 06:40:07 --> Session Class Initialized
DEBUG - 2010-07-01 06:40:07 --> Helper loaded: string_helper
DEBUG - 2010-07-01 06:40:07 --> Session routines successfully run
DEBUG - 2010-07-01 06:40:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:40:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:40:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:40:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:40:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:40:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:40:08 --> Helper loaded: email_helper
DEBUG - 2010-07-01 06:40:08 --> User Agent Class Initialized
DEBUG - 2010-07-01 06:40:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:40:08 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:40:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:40:08 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 06:40:08 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:40:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:40:08 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:40:09 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:40:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:40:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:40:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:40:09 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:40:09 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 06:40:09 --> Final output sent to browser
DEBUG - 2010-07-01 06:40:09 --> Total execution time: 2.3017
DEBUG - 2010-07-01 06:40:20 --> Config Class Initialized
DEBUG - 2010-07-01 06:40:20 --> Hooks Class Initialized
DEBUG - 2010-07-01 06:40:20 --> URI Class Initialized
DEBUG - 2010-07-01 06:40:20 --> Router Class Initialized
DEBUG - 2010-07-01 06:40:20 --> Output Class Initialized
DEBUG - 2010-07-01 06:40:20 --> Input Class Initialized
DEBUG - 2010-07-01 06:40:20 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 06:40:20 --> Language Class Initialized
DEBUG - 2010-07-01 06:40:20 --> Loader Class Initialized
DEBUG - 2010-07-01 06:40:20 --> Helper loaded: context_helper
DEBUG - 2010-07-01 06:40:20 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 06:40:21 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 06:40:21 --> Database Driver Class Initialized
DEBUG - 2010-07-01 06:40:21 --> Controller Class Initialized
DEBUG - 2010-07-01 06:40:21 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 06:40:21 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 06:40:21 --> Helper loaded: cookie_helper
DEBUG - 2010-07-01 06:40:21 --> Session Class Initialized
DEBUG - 2010-07-01 06:40:21 --> Helper loaded: string_helper
DEBUG - 2010-07-01 06:40:21 --> Session routines successfully run
DEBUG - 2010-07-01 06:40:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:40:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:40:21 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:40:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:40:21 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:40:21 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:40:21 --> Helper loaded: email_helper
DEBUG - 2010-07-01 06:40:21 --> User Agent Class Initialized
DEBUG - 2010-07-01 06:40:21 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:40:21 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:40:21 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-01 06:40:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Logger.php 65
ERROR - 2010-07-01 06:40:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Logger.php 65
ERROR - 2010-07-01 06:40:21 --> Error on line () in (): 管理Domain錯誤
ERROR - 2010-07-01 06:40:21 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-01 06:41:17 --> Config Class Initialized
DEBUG - 2010-07-01 06:41:17 --> Hooks Class Initialized
DEBUG - 2010-07-01 06:41:17 --> URI Class Initialized
DEBUG - 2010-07-01 06:41:17 --> Router Class Initialized
DEBUG - 2010-07-01 06:41:17 --> Output Class Initialized
DEBUG - 2010-07-01 06:41:17 --> Input Class Initialized
DEBUG - 2010-07-01 06:41:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 06:41:17 --> Language Class Initialized
DEBUG - 2010-07-01 06:41:17 --> Loader Class Initialized
DEBUG - 2010-07-01 06:41:17 --> Helper loaded: context_helper
DEBUG - 2010-07-01 06:41:17 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 06:41:17 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 06:41:17 --> Database Driver Class Initialized
DEBUG - 2010-07-01 06:41:17 --> Controller Class Initialized
DEBUG - 2010-07-01 06:41:17 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 06:41:17 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 06:41:17 --> Helper loaded: cookie_helper
DEBUG - 2010-07-01 06:41:17 --> Session Class Initialized
DEBUG - 2010-07-01 06:41:17 --> Helper loaded: string_helper
DEBUG - 2010-07-01 06:41:17 --> Session routines successfully run
DEBUG - 2010-07-01 06:41:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:41:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:41:17 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:41:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:41:17 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:41:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:41:17 --> Helper loaded: email_helper
DEBUG - 2010-07-01 06:41:17 --> User Agent Class Initialized
DEBUG - 2010-07-01 06:41:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:41:18 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:41:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:41:39 --> Config Class Initialized
DEBUG - 2010-07-01 06:41:39 --> Hooks Class Initialized
DEBUG - 2010-07-01 06:41:39 --> URI Class Initialized
DEBUG - 2010-07-01 06:41:39 --> Router Class Initialized
DEBUG - 2010-07-01 06:41:39 --> Output Class Initialized
DEBUG - 2010-07-01 06:41:39 --> Input Class Initialized
DEBUG - 2010-07-01 06:41:39 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 06:41:39 --> Language Class Initialized
DEBUG - 2010-07-01 06:41:39 --> Loader Class Initialized
DEBUG - 2010-07-01 06:41:39 --> Helper loaded: context_helper
DEBUG - 2010-07-01 06:41:39 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 06:41:39 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 06:41:39 --> Database Driver Class Initialized
DEBUG - 2010-07-01 06:41:39 --> Controller Class Initialized
DEBUG - 2010-07-01 06:41:39 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 06:41:39 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 06:41:39 --> Helper loaded: cookie_helper
DEBUG - 2010-07-01 06:41:39 --> Session Class Initialized
DEBUG - 2010-07-01 06:41:40 --> Helper loaded: string_helper
DEBUG - 2010-07-01 06:41:40 --> Session routines successfully run
DEBUG - 2010-07-01 06:41:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:41:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:41:40 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:41:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:41:40 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:41:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:41:40 --> Helper loaded: email_helper
DEBUG - 2010-07-01 06:41:40 --> User Agent Class Initialized
DEBUG - 2010-07-01 06:41:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:41:40 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:41:40 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-01 06:41:40 --> 管理Domain錯誤
DEBUG - 2010-07-01 06:42:20 --> Config Class Initialized
DEBUG - 2010-07-01 06:42:20 --> Hooks Class Initialized
DEBUG - 2010-07-01 06:42:20 --> URI Class Initialized
DEBUG - 2010-07-01 06:42:20 --> Router Class Initialized
DEBUG - 2010-07-01 06:42:20 --> Output Class Initialized
DEBUG - 2010-07-01 06:42:21 --> Input Class Initialized
DEBUG - 2010-07-01 06:42:21 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 06:42:21 --> Language Class Initialized
DEBUG - 2010-07-01 06:42:21 --> Loader Class Initialized
DEBUG - 2010-07-01 06:42:21 --> Helper loaded: context_helper
DEBUG - 2010-07-01 06:42:21 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 06:42:21 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 06:42:21 --> Database Driver Class Initialized
DEBUG - 2010-07-01 06:42:21 --> Controller Class Initialized
DEBUG - 2010-07-01 06:42:21 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 06:42:21 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 06:42:21 --> Helper loaded: cookie_helper
DEBUG - 2010-07-01 06:42:22 --> Session Class Initialized
DEBUG - 2010-07-01 06:42:22 --> Helper loaded: string_helper
DEBUG - 2010-07-01 06:42:22 --> Session routines successfully run
DEBUG - 2010-07-01 06:42:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:42:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:42:23 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:42:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:42:23 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:42:23 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:42:23 --> Helper loaded: email_helper
DEBUG - 2010-07-01 06:42:23 --> User Agent Class Initialized
DEBUG - 2010-07-01 06:42:23 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:42:23 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:42:23 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-01 06:42:23 --> 管理Domain錯誤: 管理Domain錯誤
DEBUG - 2010-07-01 06:51:50 --> Config Class Initialized
DEBUG - 2010-07-01 06:51:50 --> Hooks Class Initialized
DEBUG - 2010-07-01 06:51:50 --> URI Class Initialized
DEBUG - 2010-07-01 06:51:50 --> Router Class Initialized
DEBUG - 2010-07-01 06:51:50 --> Output Class Initialized
DEBUG - 2010-07-01 06:51:50 --> Input Class Initialized
DEBUG - 2010-07-01 06:51:50 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 06:51:50 --> Language Class Initialized
DEBUG - 2010-07-01 06:51:50 --> Loader Class Initialized
DEBUG - 2010-07-01 06:51:50 --> Helper loaded: context_helper
DEBUG - 2010-07-01 06:51:50 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 06:51:50 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 06:51:50 --> Database Driver Class Initialized
DEBUG - 2010-07-01 06:51:50 --> Controller Class Initialized
DEBUG - 2010-07-01 06:51:50 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 06:51:50 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 06:51:50 --> Helper loaded: cookie_helper
DEBUG - 2010-07-01 06:51:50 --> Session Class Initialized
DEBUG - 2010-07-01 06:51:50 --> Helper loaded: string_helper
DEBUG - 2010-07-01 06:51:51 --> Session routines successfully run
DEBUG - 2010-07-01 06:51:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:51:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:51:51 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:51:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:51:51 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:51:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:51:51 --> Helper loaded: email_helper
DEBUG - 2010-07-01 06:51:51 --> User Agent Class Initialized
DEBUG - 2010-07-01 06:51:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:51:51 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-01 06:51:51 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-01 06:51:51 --> 管理Domain錯誤
DEBUG - 2010-07-01 07:37:34 --> Config Class Initialized
DEBUG - 2010-07-01 07:37:34 --> Hooks Class Initialized
DEBUG - 2010-07-01 07:37:34 --> URI Class Initialized
DEBUG - 2010-07-01 07:37:35 --> Router Class Initialized
DEBUG - 2010-07-01 07:37:35 --> Output Class Initialized
DEBUG - 2010-07-01 07:37:35 --> Input Class Initialized
DEBUG - 2010-07-01 07:37:35 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 07:37:35 --> Language Class Initialized
DEBUG - 2010-07-01 07:37:35 --> Loader Class Initialized
DEBUG - 2010-07-01 07:37:35 --> Helper loaded: context_helper
DEBUG - 2010-07-01 07:37:35 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 07:37:35 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 07:37:35 --> Database Driver Class Initialized
DEBUG - 2010-07-01 07:37:35 --> Controller Class Initialized
DEBUG - 2010-07-01 07:37:35 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 07:37:35 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 07:37:35 --> Session Class Initialized
DEBUG - 2010-07-01 07:37:35 --> Helper loaded: string_helper
DEBUG - 2010-07-01 07:37:35 --> Session routines successfully run
DEBUG - 2010-07-01 07:38:17 --> Config Class Initialized
DEBUG - 2010-07-01 07:38:17 --> Hooks Class Initialized
DEBUG - 2010-07-01 07:38:17 --> URI Class Initialized
DEBUG - 2010-07-01 07:38:17 --> Router Class Initialized
DEBUG - 2010-07-01 07:38:17 --> Output Class Initialized
DEBUG - 2010-07-01 07:38:17 --> Input Class Initialized
DEBUG - 2010-07-01 07:38:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 07:38:17 --> Language Class Initialized
DEBUG - 2010-07-01 07:38:17 --> Loader Class Initialized
DEBUG - 2010-07-01 07:38:17 --> Helper loaded: context_helper
DEBUG - 2010-07-01 07:38:17 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 07:38:17 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 07:38:17 --> Database Driver Class Initialized
DEBUG - 2010-07-01 07:38:17 --> Controller Class Initialized
DEBUG - 2010-07-01 07:38:17 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 07:38:17 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 07:38:17 --> Session Class Initialized
DEBUG - 2010-07-01 07:38:17 --> Helper loaded: string_helper
DEBUG - 2010-07-01 07:38:17 --> Session routines successfully run
DEBUG - 2010-07-01 07:38:17 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 07:38:17 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 07:38:17 --> Final output sent to browser
DEBUG - 2010-07-01 07:38:17 --> Total execution time: 0.7942
DEBUG - 2010-07-01 07:44:25 --> Config Class Initialized
DEBUG - 2010-07-01 07:44:25 --> Hooks Class Initialized
DEBUG - 2010-07-01 07:44:25 --> URI Class Initialized
DEBUG - 2010-07-01 07:44:25 --> Router Class Initialized
DEBUG - 2010-07-01 07:44:25 --> Output Class Initialized
DEBUG - 2010-07-01 07:44:25 --> Input Class Initialized
DEBUG - 2010-07-01 07:44:25 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 07:44:25 --> Language Class Initialized
DEBUG - 2010-07-01 07:44:25 --> Loader Class Initialized
DEBUG - 2010-07-01 07:44:25 --> Helper loaded: context_helper
DEBUG - 2010-07-01 07:44:25 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 07:44:25 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 07:44:25 --> Database Driver Class Initialized
DEBUG - 2010-07-01 07:44:25 --> Controller Class Initialized
DEBUG - 2010-07-01 07:44:25 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 07:44:25 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 07:44:25 --> Session Class Initialized
DEBUG - 2010-07-01 07:44:25 --> Helper loaded: string_helper
DEBUG - 2010-07-01 07:44:25 --> Session routines successfully run
DEBUG - 2010-07-01 07:44:26 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-07-01 07:44:26 --> Severity: Warning  --> SimpledCWS::set_dict() [<a href='simpledcws.set-dict'>simpledcws.set-dict</a>]: Failed to set the dict file D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 29
ERROR - 2010-07-01 07:44:26 --> Severity: Warning  --> SimpledCWS::set_rule() [<a href='simpledcws.set-rule'>simpledcws.set-rule</a>]: Failed to load the ruleset file D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 30
ERROR - 2010-07-01 07:44:26 --> Severity: Notice  --> Undefined variable: ignore D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 47
ERROR - 2010-07-01 07:44:26 --> Severity: Warning  --> SimpledCWS::set_dict() [<a href='simpledcws.set-dict'>simpledcws.set-dict</a>]: Failed to set the dict file D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 29
ERROR - 2010-07-01 07:44:26 --> Severity: Warning  --> SimpledCWS::set_rule() [<a href='simpledcws.set-rule'>simpledcws.set-rule</a>]: Failed to load the ruleset file D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 30
ERROR - 2010-07-01 07:44:26 --> Severity: Notice  --> Undefined variable: ignore D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 47
DEBUG - 2010-07-01 07:44:26 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 07:44:26 --> Final output sent to browser
DEBUG - 2010-07-01 07:44:26 --> Total execution time: 1.1783
DEBUG - 2010-07-01 07:45:01 --> Config Class Initialized
DEBUG - 2010-07-01 07:45:01 --> Hooks Class Initialized
DEBUG - 2010-07-01 07:45:01 --> URI Class Initialized
DEBUG - 2010-07-01 07:45:01 --> Router Class Initialized
DEBUG - 2010-07-01 07:45:01 --> Output Class Initialized
DEBUG - 2010-07-01 07:45:01 --> Input Class Initialized
DEBUG - 2010-07-01 07:45:01 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 07:45:01 --> Language Class Initialized
DEBUG - 2010-07-01 07:45:01 --> Loader Class Initialized
DEBUG - 2010-07-01 07:45:01 --> Helper loaded: context_helper
DEBUG - 2010-07-01 07:45:01 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 07:45:01 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 07:45:01 --> Database Driver Class Initialized
DEBUG - 2010-07-01 07:45:01 --> Controller Class Initialized
DEBUG - 2010-07-01 07:45:01 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 07:45:01 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 07:45:01 --> Session Class Initialized
DEBUG - 2010-07-01 07:45:01 --> Helper loaded: string_helper
DEBUG - 2010-07-01 07:45:02 --> Session routines successfully run
DEBUG - 2010-07-01 07:45:02 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-07-01 07:45:02 --> Severity: Warning  --> SimpledCWS::set_dict() [<a href='simpledcws.set-dict'>simpledcws.set-dict</a>]: Failed to set the dict file D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 31
ERROR - 2010-07-01 07:45:02 --> Severity: Warning  --> SimpledCWS::set_rule() [<a href='simpledcws.set-rule'>simpledcws.set-rule</a>]: Failed to load the ruleset file D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 32
ERROR - 2010-07-01 07:45:02 --> Severity: Warning  --> file_get_contents(rules_cht.utf8.ini) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: No such file or directory D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 51
ERROR - 2010-07-01 07:45:02 --> Severity: Warning  --> SimpledCWS::set_dict() [<a href='simpledcws.set-dict'>simpledcws.set-dict</a>]: Failed to set the dict file D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 31
ERROR - 2010-07-01 07:45:02 --> Severity: Warning  --> SimpledCWS::set_rule() [<a href='simpledcws.set-rule'>simpledcws.set-rule</a>]: Failed to load the ruleset file D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 32
ERROR - 2010-07-01 07:45:02 --> Severity: Warning  --> file_get_contents(rules_cht.utf8.ini) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: No such file or directory D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 51
DEBUG - 2010-07-01 07:45:02 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 07:45:02 --> Final output sent to browser
DEBUG - 2010-07-01 07:45:02 --> Total execution time: 1.1377
DEBUG - 2010-07-01 07:46:09 --> Config Class Initialized
DEBUG - 2010-07-01 07:46:09 --> Hooks Class Initialized
DEBUG - 2010-07-01 07:46:09 --> URI Class Initialized
DEBUG - 2010-07-01 07:46:09 --> Router Class Initialized
DEBUG - 2010-07-01 07:46:09 --> Output Class Initialized
DEBUG - 2010-07-01 07:46:09 --> Input Class Initialized
DEBUG - 2010-07-01 07:46:09 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 07:46:09 --> Language Class Initialized
DEBUG - 2010-07-01 07:46:09 --> Loader Class Initialized
DEBUG - 2010-07-01 07:46:09 --> Helper loaded: context_helper
DEBUG - 2010-07-01 07:46:10 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 07:46:10 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 07:46:10 --> Database Driver Class Initialized
DEBUG - 2010-07-01 07:46:10 --> Controller Class Initialized
DEBUG - 2010-07-01 07:46:10 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 07:46:10 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 07:46:10 --> Session Class Initialized
DEBUG - 2010-07-01 07:46:10 --> Helper loaded: string_helper
DEBUG - 2010-07-01 07:46:10 --> Session routines successfully run
DEBUG - 2010-07-01 07:46:10 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-07-01 07:46:10 --> Severity: Warning  --> SimpledCWS::set_dict() [<a href='simpledcws.set-dict'>simpledcws.set-dict</a>]: Failed to set the dict file D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 31
ERROR - 2010-07-01 07:46:10 --> Severity: Warning  --> SimpledCWS::set_rule() [<a href='simpledcws.set-rule'>simpledcws.set-rule</a>]: Failed to load the ruleset file D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 32
ERROR - 2010-07-01 07:46:10 --> Severity: Warning  --> file_get_contents(./rules_cht.utf8.ini) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: No such file or directory D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 51
ERROR - 2010-07-01 07:46:10 --> Severity: Warning  --> SimpledCWS::set_dict() [<a href='simpledcws.set-dict'>simpledcws.set-dict</a>]: Failed to set the dict file D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 31
ERROR - 2010-07-01 07:46:10 --> Severity: Warning  --> SimpledCWS::set_rule() [<a href='simpledcws.set-rule'>simpledcws.set-rule</a>]: Failed to load the ruleset file D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 32
ERROR - 2010-07-01 07:46:10 --> Severity: Warning  --> file_get_contents(./rules_cht.utf8.ini) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: No such file or directory D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_SCWS.php 51
DEBUG - 2010-07-01 07:46:10 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 07:46:10 --> Final output sent to browser
DEBUG - 2010-07-01 07:46:10 --> Total execution time: 1.0890
DEBUG - 2010-07-01 07:49:45 --> Config Class Initialized
DEBUG - 2010-07-01 07:49:45 --> Hooks Class Initialized
DEBUG - 2010-07-01 07:49:45 --> URI Class Initialized
DEBUG - 2010-07-01 07:49:45 --> Router Class Initialized
DEBUG - 2010-07-01 07:49:45 --> Output Class Initialized
DEBUG - 2010-07-01 07:49:45 --> Input Class Initialized
DEBUG - 2010-07-01 07:49:45 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 07:49:45 --> Language Class Initialized
DEBUG - 2010-07-01 07:49:45 --> Loader Class Initialized
DEBUG - 2010-07-01 07:49:45 --> Helper loaded: context_helper
DEBUG - 2010-07-01 07:49:45 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 07:49:45 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 07:49:45 --> Database Driver Class Initialized
DEBUG - 2010-07-01 07:49:45 --> Controller Class Initialized
DEBUG - 2010-07-01 07:49:45 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 07:49:45 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 07:49:45 --> Session Class Initialized
DEBUG - 2010-07-01 07:49:45 --> Helper loaded: string_helper
DEBUG - 2010-07-01 07:49:45 --> Session routines successfully run
DEBUG - 2010-07-01 07:49:45 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 07:51:57 --> Config Class Initialized
DEBUG - 2010-07-01 07:51:57 --> Hooks Class Initialized
DEBUG - 2010-07-01 07:51:57 --> URI Class Initialized
DEBUG - 2010-07-01 07:51:57 --> Router Class Initialized
DEBUG - 2010-07-01 07:51:57 --> Output Class Initialized
DEBUG - 2010-07-01 07:51:57 --> Input Class Initialized
DEBUG - 2010-07-01 07:51:57 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 07:51:57 --> Language Class Initialized
DEBUG - 2010-07-01 07:51:58 --> Loader Class Initialized
DEBUG - 2010-07-01 07:51:58 --> Helper loaded: context_helper
DEBUG - 2010-07-01 07:51:58 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 07:51:58 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 07:51:58 --> Database Driver Class Initialized
DEBUG - 2010-07-01 07:51:58 --> Controller Class Initialized
DEBUG - 2010-07-01 07:51:58 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 07:51:58 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 07:51:58 --> Session Class Initialized
DEBUG - 2010-07-01 07:51:58 --> Helper loaded: string_helper
DEBUG - 2010-07-01 07:51:58 --> Session routines successfully run
DEBUG - 2010-07-01 07:51:58 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 07:51:58 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 07:51:58 --> Final output sent to browser
DEBUG - 2010-07-01 07:51:58 --> Total execution time: 1.0723
DEBUG - 2010-07-01 07:52:47 --> Config Class Initialized
DEBUG - 2010-07-01 07:52:47 --> Hooks Class Initialized
DEBUG - 2010-07-01 07:52:47 --> URI Class Initialized
DEBUG - 2010-07-01 07:52:47 --> Router Class Initialized
DEBUG - 2010-07-01 07:52:48 --> Output Class Initialized
DEBUG - 2010-07-01 07:52:48 --> Input Class Initialized
DEBUG - 2010-07-01 07:52:48 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 07:52:48 --> Language Class Initialized
DEBUG - 2010-07-01 07:52:48 --> Loader Class Initialized
DEBUG - 2010-07-01 07:52:48 --> Helper loaded: context_helper
DEBUG - 2010-07-01 07:52:48 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 07:52:48 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 07:52:48 --> Database Driver Class Initialized
DEBUG - 2010-07-01 07:52:48 --> Controller Class Initialized
DEBUG - 2010-07-01 07:52:48 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 07:52:48 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 07:52:48 --> Session Class Initialized
DEBUG - 2010-07-01 07:52:48 --> Helper loaded: string_helper
DEBUG - 2010-07-01 07:52:48 --> Session routines successfully run
DEBUG - 2010-07-01 07:52:48 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 07:52:48 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 07:52:48 --> Final output sent to browser
DEBUG - 2010-07-01 07:52:48 --> Total execution time: 0.9467
DEBUG - 2010-07-01 07:54:52 --> Config Class Initialized
DEBUG - 2010-07-01 07:54:52 --> Hooks Class Initialized
DEBUG - 2010-07-01 07:54:52 --> URI Class Initialized
DEBUG - 2010-07-01 07:54:52 --> Router Class Initialized
DEBUG - 2010-07-01 07:54:52 --> Output Class Initialized
DEBUG - 2010-07-01 07:54:52 --> Input Class Initialized
DEBUG - 2010-07-01 07:54:52 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 07:54:52 --> Language Class Initialized
DEBUG - 2010-07-01 07:54:52 --> Loader Class Initialized
DEBUG - 2010-07-01 07:54:52 --> Helper loaded: context_helper
DEBUG - 2010-07-01 07:54:52 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 07:54:52 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 07:54:52 --> Database Driver Class Initialized
DEBUG - 2010-07-01 07:54:52 --> Controller Class Initialized
DEBUG - 2010-07-01 07:54:52 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 07:54:52 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 07:54:52 --> Session Class Initialized
DEBUG - 2010-07-01 07:54:52 --> Helper loaded: string_helper
DEBUG - 2010-07-01 07:54:53 --> Session routines successfully run
DEBUG - 2010-07-01 07:54:53 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 07:54:53 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 07:54:53 --> Final output sent to browser
DEBUG - 2010-07-01 07:54:53 --> Total execution time: 0.9331
DEBUG - 2010-07-01 08:09:00 --> Config Class Initialized
DEBUG - 2010-07-01 08:09:00 --> Hooks Class Initialized
DEBUG - 2010-07-01 08:09:00 --> URI Class Initialized
DEBUG - 2010-07-01 08:09:00 --> Router Class Initialized
DEBUG - 2010-07-01 08:09:00 --> Output Class Initialized
DEBUG - 2010-07-01 08:09:00 --> Input Class Initialized
DEBUG - 2010-07-01 08:09:00 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 08:09:00 --> Language Class Initialized
DEBUG - 2010-07-01 08:09:00 --> Loader Class Initialized
DEBUG - 2010-07-01 08:09:00 --> Helper loaded: context_helper
DEBUG - 2010-07-01 08:09:00 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 08:09:00 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 08:09:00 --> Database Driver Class Initialized
DEBUG - 2010-07-01 08:09:01 --> Controller Class Initialized
DEBUG - 2010-07-01 08:09:01 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 08:09:01 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 08:09:01 --> Session Class Initialized
DEBUG - 2010-07-01 08:09:01 --> Helper loaded: string_helper
DEBUG - 2010-07-01 08:09:01 --> Session routines successfully run
DEBUG - 2010-07-01 08:09:01 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 08:09:01 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 08:09:01 --> Final output sent to browser
DEBUG - 2010-07-01 08:09:01 --> Total execution time: 1.0192
DEBUG - 2010-07-01 08:09:38 --> Config Class Initialized
DEBUG - 2010-07-01 08:09:38 --> Hooks Class Initialized
DEBUG - 2010-07-01 08:09:38 --> URI Class Initialized
DEBUG - 2010-07-01 08:09:38 --> Router Class Initialized
DEBUG - 2010-07-01 08:09:38 --> Output Class Initialized
DEBUG - 2010-07-01 08:09:38 --> Input Class Initialized
DEBUG - 2010-07-01 08:09:39 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 08:09:39 --> Language Class Initialized
DEBUG - 2010-07-01 08:09:39 --> Loader Class Initialized
DEBUG - 2010-07-01 08:09:39 --> Helper loaded: context_helper
DEBUG - 2010-07-01 08:09:39 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 08:09:39 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 08:09:39 --> Database Driver Class Initialized
DEBUG - 2010-07-01 08:09:39 --> Controller Class Initialized
DEBUG - 2010-07-01 08:09:39 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 08:09:39 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 08:09:39 --> Session Class Initialized
DEBUG - 2010-07-01 08:09:39 --> Helper loaded: string_helper
DEBUG - 2010-07-01 08:09:39 --> Session routines successfully run
DEBUG - 2010-07-01 08:09:39 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 08:09:39 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 08:09:39 --> Final output sent to browser
DEBUG - 2010-07-01 08:09:39 --> Total execution time: 0.9484
DEBUG - 2010-07-01 08:19:57 --> Config Class Initialized
DEBUG - 2010-07-01 08:19:57 --> Hooks Class Initialized
DEBUG - 2010-07-01 08:19:57 --> URI Class Initialized
DEBUG - 2010-07-01 08:19:57 --> Router Class Initialized
DEBUG - 2010-07-01 08:19:57 --> Output Class Initialized
DEBUG - 2010-07-01 08:19:57 --> Input Class Initialized
DEBUG - 2010-07-01 08:19:57 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 08:19:57 --> Language Class Initialized
DEBUG - 2010-07-01 08:19:57 --> Loader Class Initialized
DEBUG - 2010-07-01 08:19:57 --> Helper loaded: context_helper
DEBUG - 2010-07-01 08:19:57 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 08:19:57 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 08:19:57 --> Database Driver Class Initialized
DEBUG - 2010-07-01 08:19:57 --> Controller Class Initialized
DEBUG - 2010-07-01 08:19:57 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 08:19:57 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 08:19:57 --> Session Class Initialized
DEBUG - 2010-07-01 08:19:57 --> Helper loaded: string_helper
DEBUG - 2010-07-01 08:19:57 --> Session routines successfully run
DEBUG - 2010-07-01 08:19:57 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 08:19:58 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 08:19:58 --> Final output sent to browser
DEBUG - 2010-07-01 08:19:58 --> Total execution time: 1.0303
DEBUG - 2010-07-01 08:32:55 --> Config Class Initialized
DEBUG - 2010-07-01 08:32:56 --> Hooks Class Initialized
DEBUG - 2010-07-01 08:32:56 --> URI Class Initialized
DEBUG - 2010-07-01 08:32:56 --> Router Class Initialized
DEBUG - 2010-07-01 08:32:56 --> Output Class Initialized
DEBUG - 2010-07-01 08:32:56 --> Input Class Initialized
DEBUG - 2010-07-01 08:32:56 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 08:32:56 --> Language Class Initialized
DEBUG - 2010-07-01 08:32:56 --> Loader Class Initialized
DEBUG - 2010-07-01 08:32:56 --> Helper loaded: context_helper
DEBUG - 2010-07-01 08:32:56 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 08:32:56 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 08:32:56 --> Database Driver Class Initialized
DEBUG - 2010-07-01 08:32:56 --> Controller Class Initialized
DEBUG - 2010-07-01 08:32:56 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 08:32:56 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 08:32:56 --> Session Class Initialized
DEBUG - 2010-07-01 08:32:57 --> Helper loaded: string_helper
DEBUG - 2010-07-01 08:32:57 --> Session routines successfully run
DEBUG - 2010-07-01 08:32:57 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 08:33:07 --> Config Class Initialized
DEBUG - 2010-07-01 08:33:07 --> Hooks Class Initialized
DEBUG - 2010-07-01 08:33:07 --> URI Class Initialized
DEBUG - 2010-07-01 08:33:07 --> Router Class Initialized
DEBUG - 2010-07-01 08:33:07 --> Output Class Initialized
DEBUG - 2010-07-01 08:33:07 --> Input Class Initialized
DEBUG - 2010-07-01 08:33:07 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 08:33:07 --> Language Class Initialized
DEBUG - 2010-07-01 08:33:07 --> Loader Class Initialized
DEBUG - 2010-07-01 08:33:07 --> Helper loaded: context_helper
DEBUG - 2010-07-01 08:33:07 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 08:33:07 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 08:33:07 --> Database Driver Class Initialized
DEBUG - 2010-07-01 08:33:07 --> Controller Class Initialized
DEBUG - 2010-07-01 08:33:07 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 08:33:08 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 08:33:08 --> Session Class Initialized
DEBUG - 2010-07-01 08:33:08 --> Helper loaded: string_helper
DEBUG - 2010-07-01 08:33:08 --> Session routines successfully run
DEBUG - 2010-07-01 08:33:08 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 08:33:08 --> Config file loaded: config/kals.php
DEBUG - 2010-07-01 08:33:08 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 08:33:08 --> Final output sent to browser
DEBUG - 2010-07-01 08:33:08 --> Total execution time: 1.0228
DEBUG - 2010-07-01 08:35:11 --> Config Class Initialized
DEBUG - 2010-07-01 08:35:11 --> Hooks Class Initialized
DEBUG - 2010-07-01 08:35:11 --> URI Class Initialized
DEBUG - 2010-07-01 08:35:11 --> Router Class Initialized
DEBUG - 2010-07-01 08:35:11 --> Output Class Initialized
DEBUG - 2010-07-01 08:35:12 --> Input Class Initialized
DEBUG - 2010-07-01 08:35:12 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 08:35:12 --> Language Class Initialized
DEBUG - 2010-07-01 08:35:12 --> Loader Class Initialized
DEBUG - 2010-07-01 08:35:12 --> Helper loaded: context_helper
DEBUG - 2010-07-01 08:35:12 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 08:35:12 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 08:35:12 --> Database Driver Class Initialized
DEBUG - 2010-07-01 08:35:12 --> Controller Class Initialized
DEBUG - 2010-07-01 08:35:12 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 08:35:12 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 08:35:12 --> Session Class Initialized
DEBUG - 2010-07-01 08:35:12 --> Helper loaded: string_helper
DEBUG - 2010-07-01 08:35:12 --> Session routines successfully run
DEBUG - 2010-07-01 08:35:12 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 08:35:12 --> Config file loaded: config/kals.php
ERROR - 2010-07-01 08:35:13 --> Severity: Warning  --> socket_connect() [<a href='function.socket-connect'>function.socket-connect</a>]: unable to connect [0]: ���e���ҭn�D����}�����T�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 81
ERROR - 2010-07-01 08:35:13 --> Severity: Warning  --> socket_write() [<a href='function.socket-write'>function.socket-write</a>]: unable to write to socket [0]: �����\�ǰe�α�����ƪ��n�D�A�]���q�T�ݨå��s�u�A�ӥB (�b��ƥ]�q�T�ݨϥ� sendto �I�s�i��ǰe��) �å����Ѧ�}�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 82
ERROR - 2010-07-01 08:35:13 --> Severity: Warning  --> socket_read() [<a href='function.socket-read'>function.socket-read</a>]: unable to read from socket [0]: �����\�ǰe�α�����ƪ��n�D�A�]���q�T�ݨå��s�u�A�ӥB (�b��ƥ]�q�T�ݨϥ� sendto �I�s�i��ǰe��) �å����Ѧ�}�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 84
ERROR - 2010-07-01 08:35:13 --> Severity: Warning  --> socket_shutdown() [<a href='function.socket-shutdown'>function.socket-shutdown</a>]: unable to shutdown socket [0]: �����\�ǰe�α�����ƪ��n�D�A�]���q�T�ݨå��s�u�A�ӥB (�b��ƥ]�q�T�ݨϥ� sendto �I�s�i��ǰe��) �å����Ѧ�}�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 86
ERROR - 2010-07-01 08:35:13 --> Severity: Warning  --> socket_connect() [<a href='function.socket-connect'>function.socket-connect</a>]: unable to connect [0]: ���e���ҭn�D����}�����T�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 81
ERROR - 2010-07-01 08:35:13 --> Severity: Warning  --> socket_write() [<a href='function.socket-write'>function.socket-write</a>]: unable to write to socket [0]: �����\�ǰe�α�����ƪ��n�D�A�]���q�T�ݨå��s�u�A�ӥB (�b��ƥ]�q�T�ݨϥ� sendto �I�s�i��ǰe��) �å����Ѧ�}�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 82
ERROR - 2010-07-01 08:35:13 --> Severity: Warning  --> socket_read() [<a href='function.socket-read'>function.socket-read</a>]: unable to read from socket [0]: �����\�ǰe�α�����ƪ��n�D�A�]���q�T�ݨå��s�u�A�ӥB (�b��ƥ]�q�T�ݨϥ� sendto �I�s�i��ǰe��) �å����Ѧ�}�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 84
ERROR - 2010-07-01 08:35:13 --> Severity: Warning  --> socket_shutdown() [<a href='function.socket-shutdown'>function.socket-shutdown</a>]: unable to shutdown socket [0]: �����\�ǰe�α�����ƪ��n�D�A�]���q�T�ݨå��s�u�A�ӥB (�b��ƥ]�q�T�ݨϥ� sendto �I�s�i��ǰe��) �å����Ѧ�}�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 86
DEBUG - 2010-07-01 08:35:13 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 08:35:13 --> Final output sent to browser
DEBUG - 2010-07-01 08:35:13 --> Total execution time: 1.6172
DEBUG - 2010-07-01 08:35:47 --> Config Class Initialized
DEBUG - 2010-07-01 08:35:47 --> Hooks Class Initialized
DEBUG - 2010-07-01 08:35:47 --> URI Class Initialized
DEBUG - 2010-07-01 08:35:47 --> Router Class Initialized
DEBUG - 2010-07-01 08:35:47 --> Output Class Initialized
DEBUG - 2010-07-01 08:35:47 --> Input Class Initialized
DEBUG - 2010-07-01 08:35:47 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 08:35:48 --> Language Class Initialized
DEBUG - 2010-07-01 08:35:48 --> Loader Class Initialized
DEBUG - 2010-07-01 08:35:48 --> Helper loaded: context_helper
DEBUG - 2010-07-01 08:35:48 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 08:35:48 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 08:35:48 --> Database Driver Class Initialized
DEBUG - 2010-07-01 08:35:48 --> Controller Class Initialized
DEBUG - 2010-07-01 08:35:48 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 08:35:48 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 08:35:48 --> Session Class Initialized
DEBUG - 2010-07-01 08:35:48 --> Helper loaded: string_helper
DEBUG - 2010-07-01 08:35:48 --> Session routines successfully run
DEBUG - 2010-07-01 08:35:48 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 08:35:48 --> Config file loaded: config/kals.php
ERROR - 2010-07-01 08:35:48 --> Severity: Warning  --> socket_connect() [<a href='function.socket-connect'>function.socket-connect</a>]: unable to connect [0]: ���e���ҭn�D����}�����T�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 82
ERROR - 2010-07-01 08:35:48 --> Severity: Warning  --> socket_write() [<a href='function.socket-write'>function.socket-write</a>]: unable to write to socket [0]: �����\�ǰe�α�����ƪ��n�D�A�]���q�T�ݨå��s�u�A�ӥB (�b��ƥ]�q�T�ݨϥ� sendto �I�s�i��ǰe��) �å����Ѧ�}�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 83
ERROR - 2010-07-01 08:35:48 --> Severity: Warning  --> socket_read() [<a href='function.socket-read'>function.socket-read</a>]: unable to read from socket [0]: �����\�ǰe�α�����ƪ��n�D�A�]���q�T�ݨå��s�u�A�ӥB (�b��ƥ]�q�T�ݨϥ� sendto �I�s�i��ǰe��) �å����Ѧ�}�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 85
ERROR - 2010-07-01 08:35:48 --> Severity: Warning  --> socket_shutdown() [<a href='function.socket-shutdown'>function.socket-shutdown</a>]: unable to shutdown socket [0]: �����\�ǰe�α�����ƪ��n�D�A�]���q�T�ݨå��s�u�A�ӥB (�b��ƥ]�q�T�ݨϥ� sendto �I�s�i��ǰe��) �å����Ѧ�}�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 87
ERROR - 2010-07-01 08:35:48 --> Severity: Warning  --> socket_connect() [<a href='function.socket-connect'>function.socket-connect</a>]: unable to connect [0]: ���e���ҭn�D����}�����T�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 82
ERROR - 2010-07-01 08:35:48 --> Severity: Warning  --> socket_write() [<a href='function.socket-write'>function.socket-write</a>]: unable to write to socket [0]: �����\�ǰe�α�����ƪ��n�D�A�]���q�T�ݨå��s�u�A�ӥB (�b��ƥ]�q�T�ݨϥ� sendto �I�s�i��ǰe��) �å����Ѧ�}�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 83
ERROR - 2010-07-01 08:35:48 --> Severity: Warning  --> socket_read() [<a href='function.socket-read'>function.socket-read</a>]: unable to read from socket [0]: �����\�ǰe�α�����ƪ��n�D�A�]���q�T�ݨå��s�u�A�ӥB (�b��ƥ]�q�T�ݨϥ� sendto �I�s�i��ǰe��) �å����Ѧ�}�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 85
ERROR - 2010-07-01 08:35:48 --> Severity: Warning  --> socket_shutdown() [<a href='function.socket-shutdown'>function.socket-shutdown</a>]: unable to shutdown socket [0]: �����\�ǰe�α�����ƪ��n�D�A�]���q�T�ݨå��s�u�A�ӥB (�b��ƥ]�q�T�ݨϥ� sendto �I�s�i��ǰe��) �å����Ѧ�}�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 87
DEBUG - 2010-07-01 08:35:49 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 08:35:49 --> Final output sent to browser
DEBUG - 2010-07-01 08:35:49 --> Total execution time: 1.3705
DEBUG - 2010-07-01 08:36:40 --> Config Class Initialized
DEBUG - 2010-07-01 08:36:41 --> Hooks Class Initialized
DEBUG - 2010-07-01 08:36:41 --> URI Class Initialized
DEBUG - 2010-07-01 08:36:41 --> Router Class Initialized
DEBUG - 2010-07-01 08:36:41 --> Output Class Initialized
DEBUG - 2010-07-01 08:36:41 --> Input Class Initialized
DEBUG - 2010-07-01 08:36:41 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 08:36:41 --> Language Class Initialized
DEBUG - 2010-07-01 08:36:41 --> Loader Class Initialized
DEBUG - 2010-07-01 08:36:41 --> Helper loaded: context_helper
DEBUG - 2010-07-01 08:36:41 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 08:36:41 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 08:36:41 --> Database Driver Class Initialized
DEBUG - 2010-07-01 08:36:41 --> Controller Class Initialized
DEBUG - 2010-07-01 08:36:41 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 08:36:41 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 08:36:41 --> Session Class Initialized
DEBUG - 2010-07-01 08:36:41 --> Helper loaded: string_helper
DEBUG - 2010-07-01 08:36:41 --> Session routines successfully run
DEBUG - 2010-07-01 08:36:41 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 08:36:41 --> Config file loaded: config/kals.php
ERROR - 2010-07-01 08:36:41 --> Severity: Warning  --> socket_connect() [<a href='function.socket-connect'>function.socket-connect</a>]: unable to connect [0]: ���e���ҭn�D����}�����T�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 83
ERROR - 2010-07-01 08:36:42 --> Severity: Warning  --> socket_write() [<a href='function.socket-write'>function.socket-write</a>]: unable to write to socket [0]: �����\�ǰe�α�����ƪ��n�D�A�]���q�T�ݨå��s�u�A�ӥB (�b��ƥ]�q�T�ݨϥ� sendto �I�s�i��ǰe��) �å����Ѧ�}�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 84
ERROR - 2010-07-01 08:36:42 --> Severity: Warning  --> socket_read() [<a href='function.socket-read'>function.socket-read</a>]: unable to read from socket [0]: �����\�ǰe�α�����ƪ��n�D�A�]���q�T�ݨå��s�u�A�ӥB (�b��ƥ]�q�T�ݨϥ� sendto �I�s�i��ǰe��) �å����Ѧ�}�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 86
ERROR - 2010-07-01 08:36:42 --> Severity: Warning  --> socket_shutdown() [<a href='function.socket-shutdown'>function.socket-shutdown</a>]: unable to shutdown socket [0]: �����\�ǰe�α�����ƪ��n�D�A�]���q�T�ݨå��s�u�A�ӥB (�b��ƥ]�q�T�ݨϥ� sendto �I�s�i��ǰe��) �å����Ѧ�}�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 88
ERROR - 2010-07-01 08:36:42 --> Severity: Warning  --> socket_connect() [<a href='function.socket-connect'>function.socket-connect</a>]: unable to connect [0]: ���e���ҭn�D����}�����T�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 83
ERROR - 2010-07-01 08:36:42 --> Severity: Warning  --> socket_write() [<a href='function.socket-write'>function.socket-write</a>]: unable to write to socket [0]: �����\�ǰe�α�����ƪ��n�D�A�]���q�T�ݨå��s�u�A�ӥB (�b��ƥ]�q�T�ݨϥ� sendto �I�s�i��ǰe��) �å����Ѧ�}�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 84
ERROR - 2010-07-01 08:36:42 --> Severity: Warning  --> socket_read() [<a href='function.socket-read'>function.socket-read</a>]: unable to read from socket [0]: �����\�ǰe�α�����ƪ��n�D�A�]���q�T�ݨå��s�u�A�ӥB (�b��ƥ]�q�T�ݨϥ� sendto �I�s�i��ǰe��) �å����Ѧ�}�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 86
ERROR - 2010-07-01 08:36:42 --> Severity: Warning  --> socket_shutdown() [<a href='function.socket-shutdown'>function.socket-shutdown</a>]: unable to shutdown socket [0]: �����\�ǰe�α�����ƪ��n�D�A�]���q�T�ݨå��s�u�A�ӥB (�b��ƥ]�q�T�ݨϥ� sendto �I�s�i��ǰe��) �å����Ѧ�}�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 88
DEBUG - 2010-07-01 08:36:42 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 08:36:42 --> Final output sent to browser
DEBUG - 2010-07-01 08:36:42 --> Total execution time: 1.4035
DEBUG - 2010-07-01 08:36:53 --> Config Class Initialized
DEBUG - 2010-07-01 08:36:53 --> Hooks Class Initialized
DEBUG - 2010-07-01 08:36:53 --> URI Class Initialized
DEBUG - 2010-07-01 08:36:53 --> Router Class Initialized
DEBUG - 2010-07-01 08:36:53 --> Output Class Initialized
DEBUG - 2010-07-01 08:36:53 --> Input Class Initialized
DEBUG - 2010-07-01 08:36:53 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 08:36:53 --> Language Class Initialized
DEBUG - 2010-07-01 08:36:53 --> Loader Class Initialized
DEBUG - 2010-07-01 08:36:53 --> Helper loaded: context_helper
DEBUG - 2010-07-01 08:36:53 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 08:36:53 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 08:36:53 --> Database Driver Class Initialized
DEBUG - 2010-07-01 08:36:53 --> Controller Class Initialized
DEBUG - 2010-07-01 08:36:53 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 08:36:53 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 08:36:53 --> Session Class Initialized
DEBUG - 2010-07-01 08:36:53 --> Helper loaded: string_helper
DEBUG - 2010-07-01 08:36:54 --> Session routines successfully run
DEBUG - 2010-07-01 08:36:54 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 08:36:54 --> Config file loaded: config/kals.php
ERROR - 2010-07-01 08:36:54 --> Severity: Warning  --> socket_connect() [<a href='function.socket-connect'>function.socket-connect</a>]: unable to connect [0]: ���e���ҭn�D����}�����T�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 83
ERROR - 2010-07-01 08:36:54 --> Severity: Warning  --> socket_write() [<a href='function.socket-write'>function.socket-write</a>]: unable to write to socket [0]: �����\�ǰe�α�����ƪ��n�D�A�]���q�T�ݨå��s�u�A�ӥB (�b��ƥ]�q�T�ݨϥ� sendto �I�s�i��ǰe��) �å����Ѧ�}�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 84
ERROR - 2010-07-01 08:36:54 --> Severity: Warning  --> socket_read() [<a href='function.socket-read'>function.socket-read</a>]: unable to read from socket [0]: �����\�ǰe�α�����ƪ��n�D�A�]���q�T�ݨå��s�u�A�ӥB (�b��ƥ]�q�T�ݨϥ� sendto �I�s�i��ǰe��) �å����Ѧ�}�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 86
ERROR - 2010-07-01 08:36:54 --> Severity: Warning  --> socket_shutdown() [<a href='function.socket-shutdown'>function.socket-shutdown</a>]: unable to shutdown socket [0]: �����\�ǰe�α�����ƪ��n�D�A�]���q�T�ݨå��s�u�A�ӥB (�b��ƥ]�q�T�ݨϥ� sendto �I�s�i��ǰe��) �å����Ѧ�}�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 88
ERROR - 2010-07-01 08:36:54 --> Severity: Warning  --> socket_connect() [<a href='function.socket-connect'>function.socket-connect</a>]: unable to connect [0]: ���e���ҭn�D����}�����T�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 83
ERROR - 2010-07-01 08:36:54 --> Severity: Warning  --> socket_write() [<a href='function.socket-write'>function.socket-write</a>]: unable to write to socket [0]: �����\�ǰe�α�����ƪ��n�D�A�]���q�T�ݨå��s�u�A�ӥB (�b��ƥ]�q�T�ݨϥ� sendto �I�s�i��ǰe��) �å����Ѧ�}�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 84
ERROR - 2010-07-01 08:36:54 --> Severity: Warning  --> socket_read() [<a href='function.socket-read'>function.socket-read</a>]: unable to read from socket [0]: �����\�ǰe�α�����ƪ��n�D�A�]���q�T�ݨå��s�u�A�ӥB (�b��ƥ]�q�T�ݨϥ� sendto �I�s�i��ǰe��) �å����Ѧ�}�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 86
ERROR - 2010-07-01 08:36:54 --> Severity: Warning  --> socket_shutdown() [<a href='function.socket-shutdown'>function.socket-shutdown</a>]: unable to shutdown socket [0]: �����\�ǰe�α�����ƪ��n�D�A�]���q�T�ݨå��s�u�A�ӥB (�b��ƥ]�q�T�ݨϥ� sendto �I�s�i��ǰe��) �å����Ѧ�}�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 88
DEBUG - 2010-07-01 08:36:54 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 08:36:54 --> Final output sent to browser
DEBUG - 2010-07-01 08:36:54 --> Total execution time: 1.6535
DEBUG - 2010-07-01 08:37:16 --> Config Class Initialized
DEBUG - 2010-07-01 08:37:16 --> Hooks Class Initialized
DEBUG - 2010-07-01 08:37:16 --> URI Class Initialized
DEBUG - 2010-07-01 08:37:17 --> Router Class Initialized
DEBUG - 2010-07-01 08:37:17 --> Output Class Initialized
DEBUG - 2010-07-01 08:37:17 --> Input Class Initialized
DEBUG - 2010-07-01 08:37:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 08:37:17 --> Language Class Initialized
DEBUG - 2010-07-01 08:37:17 --> Loader Class Initialized
DEBUG - 2010-07-01 08:37:17 --> Helper loaded: context_helper
DEBUG - 2010-07-01 08:37:17 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 08:37:17 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 08:37:17 --> Database Driver Class Initialized
DEBUG - 2010-07-01 08:37:17 --> Controller Class Initialized
DEBUG - 2010-07-01 08:37:17 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 08:37:17 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 08:37:17 --> Session Class Initialized
DEBUG - 2010-07-01 08:37:17 --> Helper loaded: string_helper
DEBUG - 2010-07-01 08:37:17 --> Session routines successfully run
DEBUG - 2010-07-01 08:37:17 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 08:37:17 --> Config file loaded: config/kals.php
ERROR - 2010-07-01 08:37:18 --> Severity: Warning  --> socket_connect() [<a href='function.socket-connect'>function.socket-connect</a>]: unable to connect [0]: �L�k�s�u�A�]���ؼйq���ڵ��s�u�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 83
ERROR - 2010-07-01 08:37:18 --> Severity: Warning  --> socket_write() [<a href='function.socket-write'>function.socket-write</a>]: unable to write to socket [0]: �����\�ǰe�α�����ƪ��n�D�A�]���q�T�ݨå��s�u�A�ӥB (�b��ƥ]�q�T�ݨϥ� sendto �I�s�i��ǰe��) �å����Ѧ�}�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 84
ERROR - 2010-07-01 08:37:19 --> Severity: Warning  --> socket_read() [<a href='function.socket-read'>function.socket-read</a>]: unable to read from socket [0]: �����\�ǰe�α�����ƪ��n�D�A�]���q�T�ݨå��s�u�A�ӥB (�b��ƥ]�q�T�ݨϥ� sendto �I�s�i��ǰe��) �å����Ѧ�}�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 86
ERROR - 2010-07-01 08:37:19 --> Severity: Warning  --> socket_shutdown() [<a href='function.socket-shutdown'>function.socket-shutdown</a>]: unable to shutdown socket [0]: �����\�ǰe�α�����ƪ��n�D�A�]���q�T�ݨå��s�u�A�ӥB (�b��ƥ]�q�T�ݨϥ� sendto �I�s�i��ǰe��) �å����Ѧ�}�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 88
ERROR - 2010-07-01 08:37:20 --> Severity: Warning  --> socket_connect() [<a href='function.socket-connect'>function.socket-connect</a>]: unable to connect [0]: �L�k�s�u�A�]���ؼйq���ڵ��s�u�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 83
ERROR - 2010-07-01 08:37:20 --> Severity: Warning  --> socket_write() [<a href='function.socket-write'>function.socket-write</a>]: unable to write to socket [0]: �����\�ǰe�α�����ƪ��n�D�A�]���q�T�ݨå��s�u�A�ӥB (�b��ƥ]�q�T�ݨϥ� sendto �I�s�i��ǰe��) �å����Ѧ�}�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 84
ERROR - 2010-07-01 08:37:20 --> Severity: Warning  --> socket_read() [<a href='function.socket-read'>function.socket-read</a>]: unable to read from socket [0]: �����\�ǰe�α�����ƪ��n�D�A�]���q�T�ݨå��s�u�A�ӥB (�b��ƥ]�q�T�ݨϥ� sendto �I�s�i��ǰe��) �å����Ѧ�}�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 86
ERROR - 2010-07-01 08:37:20 --> Severity: Warning  --> socket_shutdown() [<a href='function.socket-shutdown'>function.socket-shutdown</a>]: unable to shutdown socket [0]: �����\�ǰe�α�����ƪ��n�D�A�]���q�T�ݨå��s�u�A�ӥB (�b��ƥ]�q�T�ݨϥ� sendto �I�s�i��ǰe��) �å����Ѧ�}�C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 88
DEBUG - 2010-07-01 08:37:20 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 08:37:20 --> Final output sent to browser
DEBUG - 2010-07-01 08:37:20 --> Total execution time: 3.4731
DEBUG - 2010-07-01 08:37:29 --> Config Class Initialized
DEBUG - 2010-07-01 08:37:29 --> Hooks Class Initialized
DEBUG - 2010-07-01 08:37:29 --> URI Class Initialized
DEBUG - 2010-07-01 08:37:29 --> Router Class Initialized
DEBUG - 2010-07-01 08:37:29 --> Output Class Initialized
DEBUG - 2010-07-01 08:37:29 --> Input Class Initialized
DEBUG - 2010-07-01 08:37:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 08:37:29 --> Language Class Initialized
DEBUG - 2010-07-01 08:37:29 --> Loader Class Initialized
DEBUG - 2010-07-01 08:37:29 --> Helper loaded: context_helper
DEBUG - 2010-07-01 08:37:29 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 08:37:29 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 08:37:29 --> Database Driver Class Initialized
DEBUG - 2010-07-01 08:37:29 --> Controller Class Initialized
DEBUG - 2010-07-01 08:37:29 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 08:37:29 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 08:37:29 --> Session Class Initialized
DEBUG - 2010-07-01 08:37:29 --> Helper loaded: string_helper
DEBUG - 2010-07-01 08:37:29 --> Session routines successfully run
DEBUG - 2010-07-01 08:37:29 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 08:37:30 --> Config file loaded: config/kals.php
DEBUG - 2010-07-01 08:37:30 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 08:37:30 --> Final output sent to browser
DEBUG - 2010-07-01 08:37:30 --> Total execution time: 1.3073
DEBUG - 2010-07-01 08:39:07 --> Config Class Initialized
DEBUG - 2010-07-01 08:39:07 --> Hooks Class Initialized
DEBUG - 2010-07-01 08:39:07 --> URI Class Initialized
DEBUG - 2010-07-01 08:39:07 --> Router Class Initialized
DEBUG - 2010-07-01 08:39:07 --> Output Class Initialized
DEBUG - 2010-07-01 08:39:07 --> Input Class Initialized
DEBUG - 2010-07-01 08:39:07 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 08:39:07 --> Language Class Initialized
DEBUG - 2010-07-01 08:39:07 --> Loader Class Initialized
DEBUG - 2010-07-01 08:39:07 --> Helper loaded: context_helper
DEBUG - 2010-07-01 08:39:07 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 08:39:07 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 08:39:07 --> Database Driver Class Initialized
DEBUG - 2010-07-01 08:39:07 --> Controller Class Initialized
DEBUG - 2010-07-01 08:39:07 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 08:39:08 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 08:39:08 --> Session Class Initialized
DEBUG - 2010-07-01 08:39:08 --> Helper loaded: string_helper
DEBUG - 2010-07-01 08:39:08 --> Session routines successfully run
DEBUG - 2010-07-01 08:39:08 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 08:39:08 --> Config file loaded: config/kals.php
ERROR - 2010-07-01 08:39:08 --> Severity: Warning  --> XMLReader::read() [<a href='xmlreader.read'>xmlreader.read</a>]: file:///D:/xampp/htdocs/CodeIgniter_1.7.2/:1: parser error : Input is not proper UTF-8, indicate encoding !
Bytes: 0xA1 0x40 0xA4 0xB5 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 111
ERROR - 2010-07-01 08:39:08 --> Severity: Warning  --> XMLReader::read() [<a href='xmlreader.read'>xmlreader.read</a>]:  version=&quot;0.1&quot;&gt;&lt;processstatus code=&quot;0&quot;&gt;Success&lt;/processstatus&gt;&lt;result&gt;&lt;sentence&gt; D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 111
ERROR - 2010-07-01 08:39:08 --> Severity: Warning  --> XMLReader::read() [<a href='xmlreader.read'>xmlreader.read</a>]:                                                                                ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 111
ERROR - 2010-07-01 08:39:08 --> Severity: Warning  --> XMLReader::read() [<a href='xmlreader.read'>xmlreader.read</a>]: An Error Occured while reading D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 111
ERROR - 2010-07-01 08:39:08 --> Severity: Warning  --> XMLReader::read() [<a href='xmlreader.read'>xmlreader.read</a>]: file:///D:/xampp/htdocs/CodeIgniter_1.7.2/:1: parser error : Input is not proper UTF-8, indicate encoding !
Bytes: 0xA1 0x40 0xA4 0xB5 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 111
ERROR - 2010-07-01 08:39:08 --> Severity: Warning  --> XMLReader::read() [<a href='xmlreader.read'>xmlreader.read</a>]:  version=&quot;0.1&quot;&gt;&lt;processstatus code=&quot;0&quot;&gt;Success&lt;/processstatus&gt;&lt;result&gt;&lt;sentence&gt; D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 111
ERROR - 2010-07-01 08:39:08 --> Severity: Warning  --> XMLReader::read() [<a href='xmlreader.read'>xmlreader.read</a>]:                                                                                ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 111
ERROR - 2010-07-01 08:39:08 --> Severity: Warning  --> XMLReader::read() [<a href='xmlreader.read'>xmlreader.read</a>]: An Error Occured while reading D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 111
DEBUG - 2010-07-01 08:39:09 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 08:39:09 --> Final output sent to browser
DEBUG - 2010-07-01 08:39:09 --> Total execution time: 1.9133
DEBUG - 2010-07-01 08:40:29 --> Config Class Initialized
DEBUG - 2010-07-01 08:40:29 --> Hooks Class Initialized
DEBUG - 2010-07-01 08:40:29 --> URI Class Initialized
DEBUG - 2010-07-01 08:40:29 --> Router Class Initialized
DEBUG - 2010-07-01 08:40:29 --> Output Class Initialized
DEBUG - 2010-07-01 08:40:29 --> Input Class Initialized
DEBUG - 2010-07-01 08:40:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 08:40:29 --> Language Class Initialized
DEBUG - 2010-07-01 08:40:29 --> Loader Class Initialized
DEBUG - 2010-07-01 08:40:30 --> Helper loaded: context_helper
DEBUG - 2010-07-01 08:40:30 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 08:40:30 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 08:40:30 --> Database Driver Class Initialized
DEBUG - 2010-07-01 08:40:30 --> Controller Class Initialized
DEBUG - 2010-07-01 08:40:30 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 08:40:30 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 08:40:30 --> Session Class Initialized
DEBUG - 2010-07-01 08:40:30 --> Helper loaded: string_helper
DEBUG - 2010-07-01 08:40:30 --> Session routines successfully run
DEBUG - 2010-07-01 08:40:30 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 08:40:30 --> Config file loaded: config/kals.php
ERROR - 2010-07-01 08:40:31 --> Severity: Warning  --> XMLReader::read() [<a href='xmlreader.read'>xmlreader.read</a>]: file:///D:/xampp/htdocs/CodeIgniter_1.7.2/:1: parser error : Input is not proper UTF-8, indicate encoding !
Bytes: 0xA1 0x40 0xA4 0xB5 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 120
ERROR - 2010-07-01 08:40:31 --> Severity: Warning  --> XMLReader::read() [<a href='xmlreader.read'>xmlreader.read</a>]:  version=&quot;0.1&quot;&gt;&lt;processstatus code=&quot;0&quot;&gt;Success&lt;/processstatus&gt;&lt;result&gt;&lt;sentence&gt; D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 120
ERROR - 2010-07-01 08:40:31 --> Severity: Warning  --> XMLReader::read() [<a href='xmlreader.read'>xmlreader.read</a>]:                                                                                ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 120
ERROR - 2010-07-01 08:40:31 --> Severity: Warning  --> XMLReader::read() [<a href='xmlreader.read'>xmlreader.read</a>]: An Error Occured while reading D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 120
ERROR - 2010-07-01 08:40:31 --> Severity: Warning  --> XMLReader::read() [<a href='xmlreader.read'>xmlreader.read</a>]: file:///D:/xampp/htdocs/CodeIgniter_1.7.2/:1: parser error : Input is not proper UTF-8, indicate encoding !
Bytes: 0xA1 0x40 0xA4 0xB5 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 120
ERROR - 2010-07-01 08:40:31 --> Severity: Warning  --> XMLReader::read() [<a href='xmlreader.read'>xmlreader.read</a>]:  version=&quot;0.1&quot;&gt;&lt;processstatus code=&quot;0&quot;&gt;Success&lt;/processstatus&gt;&lt;result&gt;&lt;sentence&gt; D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 120
ERROR - 2010-07-01 08:40:31 --> Severity: Warning  --> XMLReader::read() [<a href='xmlreader.read'>xmlreader.read</a>]:                                                                                ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 120
ERROR - 2010-07-01 08:40:31 --> Severity: Warning  --> XMLReader::read() [<a href='xmlreader.read'>xmlreader.read</a>]: An Error Occured while reading D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_CKIP.php 120
DEBUG - 2010-07-01 08:40:31 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 08:40:31 --> Final output sent to browser
DEBUG - 2010-07-01 08:40:31 --> Total execution time: 2.0771
DEBUG - 2010-07-01 08:41:17 --> Config Class Initialized
DEBUG - 2010-07-01 08:41:17 --> Hooks Class Initialized
DEBUG - 2010-07-01 08:41:17 --> URI Class Initialized
DEBUG - 2010-07-01 08:41:17 --> Router Class Initialized
DEBUG - 2010-07-01 08:41:17 --> Output Class Initialized
DEBUG - 2010-07-01 08:41:17 --> Input Class Initialized
DEBUG - 2010-07-01 08:41:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 08:41:17 --> Language Class Initialized
DEBUG - 2010-07-01 08:41:17 --> Loader Class Initialized
DEBUG - 2010-07-01 08:41:17 --> Helper loaded: context_helper
DEBUG - 2010-07-01 08:41:17 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 08:41:17 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 08:41:17 --> Database Driver Class Initialized
DEBUG - 2010-07-01 08:41:17 --> Controller Class Initialized
DEBUG - 2010-07-01 08:41:17 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 08:41:17 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 08:41:17 --> Session Class Initialized
DEBUG - 2010-07-01 08:41:17 --> Helper loaded: string_helper
DEBUG - 2010-07-01 08:41:17 --> Session routines successfully run
DEBUG - 2010-07-01 08:41:18 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 08:41:18 --> Config file loaded: config/kals.php
DEBUG - 2010-07-01 08:41:18 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 08:41:18 --> Final output sent to browser
DEBUG - 2010-07-01 08:41:18 --> Total execution time: 1.3957
DEBUG - 2010-07-01 08:43:17 --> Config Class Initialized
DEBUG - 2010-07-01 08:43:17 --> Hooks Class Initialized
DEBUG - 2010-07-01 08:43:17 --> URI Class Initialized
DEBUG - 2010-07-01 08:43:18 --> Router Class Initialized
DEBUG - 2010-07-01 08:43:18 --> Output Class Initialized
DEBUG - 2010-07-01 08:43:18 --> Input Class Initialized
DEBUG - 2010-07-01 08:43:18 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 08:43:18 --> Language Class Initialized
DEBUG - 2010-07-01 08:43:18 --> Loader Class Initialized
DEBUG - 2010-07-01 08:43:18 --> Helper loaded: context_helper
DEBUG - 2010-07-01 08:43:18 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 08:43:18 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 08:43:18 --> Database Driver Class Initialized
DEBUG - 2010-07-01 08:43:18 --> Controller Class Initialized
DEBUG - 2010-07-01 08:43:18 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 08:43:18 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 08:43:18 --> Session Class Initialized
DEBUG - 2010-07-01 08:43:18 --> Helper loaded: string_helper
DEBUG - 2010-07-01 08:43:18 --> Session routines successfully run
DEBUG - 2010-07-01 08:43:18 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 08:43:19 --> Config file loaded: config/kals.php
DEBUG - 2010-07-01 08:43:19 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 08:43:19 --> Final output sent to browser
DEBUG - 2010-07-01 08:43:19 --> Total execution time: 1.4378
DEBUG - 2010-07-01 08:43:43 --> Config Class Initialized
DEBUG - 2010-07-01 08:43:43 --> Hooks Class Initialized
DEBUG - 2010-07-01 08:43:43 --> URI Class Initialized
DEBUG - 2010-07-01 08:43:43 --> Router Class Initialized
DEBUG - 2010-07-01 08:43:43 --> Output Class Initialized
DEBUG - 2010-07-01 08:43:43 --> Input Class Initialized
DEBUG - 2010-07-01 08:43:44 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 08:43:44 --> Language Class Initialized
DEBUG - 2010-07-01 08:43:44 --> Loader Class Initialized
DEBUG - 2010-07-01 08:43:44 --> Helper loaded: context_helper
DEBUG - 2010-07-01 08:43:44 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 08:43:44 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 08:43:44 --> Database Driver Class Initialized
DEBUG - 2010-07-01 08:43:44 --> Controller Class Initialized
DEBUG - 2010-07-01 08:43:44 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 08:43:44 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 08:43:44 --> Session Class Initialized
DEBUG - 2010-07-01 08:43:44 --> Helper loaded: string_helper
DEBUG - 2010-07-01 08:43:44 --> Session routines successfully run
DEBUG - 2010-07-01 08:43:44 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 08:43:44 --> Config file loaded: config/kals.php
DEBUG - 2010-07-01 08:43:45 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 08:43:45 --> Final output sent to browser
DEBUG - 2010-07-01 08:43:45 --> Total execution time: 1.4951
DEBUG - 2010-07-01 08:46:03 --> Config Class Initialized
DEBUG - 2010-07-01 08:46:03 --> Hooks Class Initialized
DEBUG - 2010-07-01 08:46:03 --> URI Class Initialized
DEBUG - 2010-07-01 08:46:03 --> Router Class Initialized
DEBUG - 2010-07-01 08:46:03 --> Output Class Initialized
DEBUG - 2010-07-01 08:46:03 --> Input Class Initialized
DEBUG - 2010-07-01 08:46:03 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 08:46:03 --> Language Class Initialized
DEBUG - 2010-07-01 08:46:03 --> Loader Class Initialized
DEBUG - 2010-07-01 08:46:03 --> Helper loaded: context_helper
DEBUG - 2010-07-01 08:46:03 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 08:46:03 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 08:46:03 --> Database Driver Class Initialized
DEBUG - 2010-07-01 08:46:04 --> Controller Class Initialized
DEBUG - 2010-07-01 08:46:04 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 08:46:04 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 08:46:04 --> Session Class Initialized
DEBUG - 2010-07-01 08:46:04 --> Helper loaded: string_helper
DEBUG - 2010-07-01 08:46:04 --> Session routines successfully run
DEBUG - 2010-07-01 08:46:04 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 08:46:04 --> Config file loaded: config/kals.php
DEBUG - 2010-07-01 08:46:04 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 08:46:04 --> Final output sent to browser
DEBUG - 2010-07-01 08:46:04 --> Total execution time: 1.3916
DEBUG - 2010-07-01 08:46:48 --> Config Class Initialized
DEBUG - 2010-07-01 08:46:48 --> Hooks Class Initialized
DEBUG - 2010-07-01 08:46:48 --> URI Class Initialized
DEBUG - 2010-07-01 08:46:48 --> Router Class Initialized
DEBUG - 2010-07-01 08:46:48 --> Output Class Initialized
DEBUG - 2010-07-01 08:46:48 --> Input Class Initialized
DEBUG - 2010-07-01 08:46:48 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 08:46:48 --> Language Class Initialized
DEBUG - 2010-07-01 08:46:48 --> Loader Class Initialized
DEBUG - 2010-07-01 08:46:48 --> Helper loaded: context_helper
DEBUG - 2010-07-01 08:46:48 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 08:46:48 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 08:46:49 --> Database Driver Class Initialized
DEBUG - 2010-07-01 08:46:49 --> Controller Class Initialized
DEBUG - 2010-07-01 08:46:49 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 08:46:49 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 08:46:49 --> Session Class Initialized
DEBUG - 2010-07-01 08:46:49 --> Helper loaded: string_helper
DEBUG - 2010-07-01 08:46:49 --> Session routines successfully run
DEBUG - 2010-07-01 08:46:49 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 08:46:49 --> Config file loaded: config/kals.php
DEBUG - 2010-07-01 08:46:49 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 08:46:49 --> Final output sent to browser
DEBUG - 2010-07-01 08:46:49 --> Total execution time: 1.4429
DEBUG - 2010-07-01 08:47:33 --> Config Class Initialized
DEBUG - 2010-07-01 08:47:33 --> Hooks Class Initialized
DEBUG - 2010-07-01 08:47:33 --> URI Class Initialized
DEBUG - 2010-07-01 08:47:33 --> Router Class Initialized
DEBUG - 2010-07-01 08:47:33 --> Output Class Initialized
DEBUG - 2010-07-01 08:47:33 --> Input Class Initialized
DEBUG - 2010-07-01 08:47:33 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 08:47:34 --> Language Class Initialized
DEBUG - 2010-07-01 08:47:34 --> Loader Class Initialized
DEBUG - 2010-07-01 08:47:34 --> Helper loaded: context_helper
DEBUG - 2010-07-01 08:47:34 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 08:47:34 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 08:47:34 --> Database Driver Class Initialized
DEBUG - 2010-07-01 08:47:34 --> Controller Class Initialized
DEBUG - 2010-07-01 08:47:34 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 08:47:34 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 08:47:34 --> Session Class Initialized
DEBUG - 2010-07-01 08:47:34 --> Helper loaded: string_helper
DEBUG - 2010-07-01 08:47:34 --> Session routines successfully run
DEBUG - 2010-07-01 08:47:34 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 08:47:34 --> Config file loaded: config/kals.php
DEBUG - 2010-07-01 08:47:34 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 08:47:35 --> Final output sent to browser
DEBUG - 2010-07-01 08:47:35 --> Total execution time: 1.3983
DEBUG - 2010-07-01 08:48:11 --> Config Class Initialized
DEBUG - 2010-07-01 08:48:11 --> Hooks Class Initialized
DEBUG - 2010-07-01 08:48:11 --> URI Class Initialized
DEBUG - 2010-07-01 08:48:11 --> Router Class Initialized
DEBUG - 2010-07-01 08:48:11 --> Output Class Initialized
DEBUG - 2010-07-01 08:48:11 --> Input Class Initialized
DEBUG - 2010-07-01 08:48:11 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 08:48:11 --> Language Class Initialized
DEBUG - 2010-07-01 08:48:11 --> Loader Class Initialized
DEBUG - 2010-07-01 08:48:11 --> Helper loaded: context_helper
DEBUG - 2010-07-01 08:48:11 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 08:48:11 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 08:48:12 --> Database Driver Class Initialized
DEBUG - 2010-07-01 08:48:12 --> Controller Class Initialized
DEBUG - 2010-07-01 08:48:12 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 08:48:12 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 08:48:12 --> Session Class Initialized
DEBUG - 2010-07-01 08:48:12 --> Helper loaded: string_helper
DEBUG - 2010-07-01 08:48:12 --> Session routines successfully run
DEBUG - 2010-07-01 08:48:12 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 08:48:12 --> Config file loaded: config/kals.php
DEBUG - 2010-07-01 08:48:12 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 08:48:12 --> Final output sent to browser
DEBUG - 2010-07-01 08:48:12 --> Total execution time: 1.4683
DEBUG - 2010-07-01 09:03:39 --> Config Class Initialized
DEBUG - 2010-07-01 09:03:39 --> Hooks Class Initialized
DEBUG - 2010-07-01 09:03:40 --> URI Class Initialized
DEBUG - 2010-07-01 09:03:40 --> Router Class Initialized
DEBUG - 2010-07-01 09:03:40 --> Output Class Initialized
DEBUG - 2010-07-01 09:03:40 --> Input Class Initialized
DEBUG - 2010-07-01 09:03:40 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 09:03:40 --> Language Class Initialized
DEBUG - 2010-07-01 09:03:40 --> Loader Class Initialized
DEBUG - 2010-07-01 09:03:40 --> Helper loaded: context_helper
DEBUG - 2010-07-01 09:03:40 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 09:03:40 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 09:03:40 --> Database Driver Class Initialized
DEBUG - 2010-07-01 09:03:40 --> Controller Class Initialized
DEBUG - 2010-07-01 09:03:40 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 09:03:40 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 09:03:40 --> Session Class Initialized
DEBUG - 2010-07-01 09:03:41 --> Helper loaded: string_helper
DEBUG - 2010-07-01 09:03:41 --> Session routines successfully run
DEBUG - 2010-07-01 09:03:41 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 09:03:41 --> Config file loaded: config/kals.php
DEBUG - 2010-07-01 09:03:41 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 09:03:41 --> Final output sent to browser
DEBUG - 2010-07-01 09:03:41 --> Total execution time: 1.5994
DEBUG - 2010-07-01 09:04:46 --> Config Class Initialized
DEBUG - 2010-07-01 09:04:46 --> Hooks Class Initialized
DEBUG - 2010-07-01 09:04:46 --> URI Class Initialized
DEBUG - 2010-07-01 09:04:46 --> Router Class Initialized
DEBUG - 2010-07-01 09:04:46 --> Output Class Initialized
DEBUG - 2010-07-01 09:04:46 --> Input Class Initialized
DEBUG - 2010-07-01 09:04:46 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 09:04:46 --> Language Class Initialized
DEBUG - 2010-07-01 09:04:46 --> Loader Class Initialized
DEBUG - 2010-07-01 09:04:46 --> Helper loaded: context_helper
DEBUG - 2010-07-01 09:04:46 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 09:04:46 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 09:04:46 --> Database Driver Class Initialized
DEBUG - 2010-07-01 09:04:46 --> Controller Class Initialized
DEBUG - 2010-07-01 09:04:47 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 09:04:47 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 09:04:47 --> Session Class Initialized
DEBUG - 2010-07-01 09:04:47 --> Helper loaded: string_helper
DEBUG - 2010-07-01 09:04:47 --> Session routines successfully run
DEBUG - 2010-07-01 09:04:47 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 09:04:47 --> Config file loaded: config/kals.php
DEBUG - 2010-07-01 09:13:04 --> Config Class Initialized
DEBUG - 2010-07-01 09:13:04 --> Hooks Class Initialized
DEBUG - 2010-07-01 09:13:04 --> URI Class Initialized
DEBUG - 2010-07-01 09:13:04 --> Router Class Initialized
DEBUG - 2010-07-01 09:13:04 --> Output Class Initialized
DEBUG - 2010-07-01 09:13:04 --> Input Class Initialized
DEBUG - 2010-07-01 09:13:04 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 09:13:04 --> Language Class Initialized
DEBUG - 2010-07-01 09:13:04 --> Loader Class Initialized
DEBUG - 2010-07-01 09:13:04 --> Helper loaded: context_helper
DEBUG - 2010-07-01 09:13:04 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 09:13:04 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 09:13:05 --> Database Driver Class Initialized
DEBUG - 2010-07-01 09:13:05 --> Controller Class Initialized
DEBUG - 2010-07-01 09:13:05 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 09:13:05 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 09:13:05 --> Session Class Initialized
DEBUG - 2010-07-01 09:13:05 --> Helper loaded: string_helper
DEBUG - 2010-07-01 09:13:05 --> Session routines successfully run
DEBUG - 2010-07-01 09:13:05 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 09:13:05 --> Config file loaded: config/kals.php
ERROR - 2010-07-01 09:13:05 --> Severity: Notice  --> Undefined variable: content D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_Yahoo_CAS.php 43
ERROR - 2010-07-01 09:13:06 --> Severity: Notice  --> Undefined variable: content D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Segmentor_Yahoo_CAS.php 43
ERROR - 2010-07-01 09:13:06 --> Severity: Notice  --> Undefined variable: segmentor_name3 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_annotation\ut_segmentor.php 74
DEBUG - 2010-07-01 09:13:22 --> Config Class Initialized
DEBUG - 2010-07-01 09:13:23 --> Hooks Class Initialized
DEBUG - 2010-07-01 09:13:23 --> URI Class Initialized
DEBUG - 2010-07-01 09:13:23 --> Router Class Initialized
DEBUG - 2010-07-01 09:13:23 --> Output Class Initialized
DEBUG - 2010-07-01 09:13:23 --> Input Class Initialized
DEBUG - 2010-07-01 09:13:23 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 09:13:23 --> Language Class Initialized
DEBUG - 2010-07-01 09:13:23 --> Loader Class Initialized
DEBUG - 2010-07-01 09:13:23 --> Helper loaded: context_helper
DEBUG - 2010-07-01 09:13:23 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 09:13:23 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 09:13:23 --> Database Driver Class Initialized
DEBUG - 2010-07-01 09:13:23 --> Controller Class Initialized
DEBUG - 2010-07-01 09:13:23 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 09:13:23 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 09:13:23 --> Session Class Initialized
DEBUG - 2010-07-01 09:13:24 --> Helper loaded: string_helper
DEBUG - 2010-07-01 09:13:24 --> Session routines successfully run
DEBUG - 2010-07-01 09:13:24 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 09:13:24 --> Config file loaded: config/kals.php
ERROR - 2010-07-01 09:13:24 --> Severity: Notice  --> Undefined variable: segmentor_name3 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_annotation\ut_segmentor.php 74
DEBUG - 2010-07-01 09:13:34 --> Config Class Initialized
DEBUG - 2010-07-01 09:13:34 --> Hooks Class Initialized
DEBUG - 2010-07-01 09:13:34 --> URI Class Initialized
DEBUG - 2010-07-01 09:13:34 --> Router Class Initialized
DEBUG - 2010-07-01 09:13:34 --> Output Class Initialized
DEBUG - 2010-07-01 09:13:34 --> Input Class Initialized
DEBUG - 2010-07-01 09:13:35 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 09:13:35 --> Language Class Initialized
DEBUG - 2010-07-01 09:13:35 --> Loader Class Initialized
DEBUG - 2010-07-01 09:13:35 --> Helper loaded: context_helper
DEBUG - 2010-07-01 09:13:35 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 09:13:35 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 09:13:35 --> Database Driver Class Initialized
DEBUG - 2010-07-01 09:13:35 --> Controller Class Initialized
DEBUG - 2010-07-01 09:13:35 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 09:13:35 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 09:13:35 --> Session Class Initialized
DEBUG - 2010-07-01 09:13:35 --> Helper loaded: string_helper
DEBUG - 2010-07-01 09:13:35 --> Session routines successfully run
DEBUG - 2010-07-01 09:13:35 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 09:13:35 --> Config file loaded: config/kals.php
DEBUG - 2010-07-01 09:13:36 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 09:13:36 --> Final output sent to browser
DEBUG - 2010-07-01 09:13:36 --> Total execution time: 1.5457
DEBUG - 2010-07-01 09:14:56 --> Config Class Initialized
DEBUG - 2010-07-01 09:14:56 --> Hooks Class Initialized
DEBUG - 2010-07-01 09:14:56 --> URI Class Initialized
DEBUG - 2010-07-01 09:14:56 --> Router Class Initialized
DEBUG - 2010-07-01 09:14:56 --> Output Class Initialized
DEBUG - 2010-07-01 09:14:56 --> Input Class Initialized
DEBUG - 2010-07-01 09:14:56 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 09:14:56 --> Language Class Initialized
DEBUG - 2010-07-01 09:14:57 --> Loader Class Initialized
DEBUG - 2010-07-01 09:14:57 --> Helper loaded: context_helper
DEBUG - 2010-07-01 09:14:57 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 09:14:57 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 09:14:57 --> Database Driver Class Initialized
DEBUG - 2010-07-01 09:14:57 --> Controller Class Initialized
DEBUG - 2010-07-01 09:14:57 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 09:14:57 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 09:14:57 --> Session Class Initialized
DEBUG - 2010-07-01 09:14:57 --> Helper loaded: string_helper
DEBUG - 2010-07-01 09:14:57 --> Session routines successfully run
DEBUG - 2010-07-01 09:14:57 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 09:14:57 --> Config file loaded: config/kals.php
DEBUG - 2010-07-01 09:14:58 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 09:14:58 --> Final output sent to browser
DEBUG - 2010-07-01 09:14:58 --> Total execution time: 1.7359
DEBUG - 2010-07-01 09:15:21 --> Config Class Initialized
DEBUG - 2010-07-01 09:15:21 --> Hooks Class Initialized
DEBUG - 2010-07-01 09:15:21 --> URI Class Initialized
DEBUG - 2010-07-01 09:15:21 --> Router Class Initialized
DEBUG - 2010-07-01 09:15:21 --> Output Class Initialized
DEBUG - 2010-07-01 09:15:21 --> Input Class Initialized
DEBUG - 2010-07-01 09:15:21 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 09:15:21 --> Language Class Initialized
DEBUG - 2010-07-01 09:15:21 --> Loader Class Initialized
DEBUG - 2010-07-01 09:15:21 --> Helper loaded: context_helper
DEBUG - 2010-07-01 09:15:21 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 09:15:21 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 09:15:21 --> Database Driver Class Initialized
DEBUG - 2010-07-01 09:15:21 --> Controller Class Initialized
DEBUG - 2010-07-01 09:15:21 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 09:15:21 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 09:15:22 --> Session Class Initialized
DEBUG - 2010-07-01 09:15:22 --> Helper loaded: string_helper
DEBUG - 2010-07-01 09:15:22 --> Session routines successfully run
DEBUG - 2010-07-01 09:15:22 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 09:15:22 --> Config file loaded: config/kals.php
DEBUG - 2010-07-01 09:15:22 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 09:15:22 --> Final output sent to browser
DEBUG - 2010-07-01 09:15:22 --> Total execution time: 1.5593
DEBUG - 2010-07-01 09:15:54 --> Config Class Initialized
DEBUG - 2010-07-01 09:15:54 --> Hooks Class Initialized
DEBUG - 2010-07-01 09:15:54 --> URI Class Initialized
DEBUG - 2010-07-01 09:15:54 --> Router Class Initialized
DEBUG - 2010-07-01 09:15:54 --> Output Class Initialized
DEBUG - 2010-07-01 09:15:55 --> Input Class Initialized
DEBUG - 2010-07-01 09:15:55 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 09:15:55 --> Language Class Initialized
DEBUG - 2010-07-01 09:15:55 --> Loader Class Initialized
DEBUG - 2010-07-01 09:15:55 --> Helper loaded: context_helper
DEBUG - 2010-07-01 09:15:55 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 09:15:55 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 09:15:55 --> Database Driver Class Initialized
DEBUG - 2010-07-01 09:15:55 --> Controller Class Initialized
DEBUG - 2010-07-01 09:15:55 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 09:15:55 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 09:15:55 --> Session Class Initialized
DEBUG - 2010-07-01 09:15:55 --> Helper loaded: string_helper
DEBUG - 2010-07-01 09:15:55 --> Session routines successfully run
DEBUG - 2010-07-01 09:15:55 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 09:15:55 --> Config file loaded: config/kals.php
DEBUG - 2010-07-01 09:15:56 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 09:15:56 --> Final output sent to browser
DEBUG - 2010-07-01 09:15:56 --> Total execution time: 1.5915
DEBUG - 2010-07-01 09:16:23 --> Config Class Initialized
DEBUG - 2010-07-01 09:16:24 --> Hooks Class Initialized
DEBUG - 2010-07-01 09:16:24 --> URI Class Initialized
DEBUG - 2010-07-01 09:16:24 --> Router Class Initialized
DEBUG - 2010-07-01 09:16:24 --> Output Class Initialized
DEBUG - 2010-07-01 09:16:24 --> Input Class Initialized
DEBUG - 2010-07-01 09:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 09:16:24 --> Language Class Initialized
DEBUG - 2010-07-01 09:16:24 --> Loader Class Initialized
DEBUG - 2010-07-01 09:16:24 --> Helper loaded: context_helper
DEBUG - 2010-07-01 09:16:24 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 09:16:24 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 09:16:24 --> Database Driver Class Initialized
DEBUG - 2010-07-01 09:16:24 --> Controller Class Initialized
DEBUG - 2010-07-01 09:16:24 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 09:16:24 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 09:16:24 --> Session Class Initialized
DEBUG - 2010-07-01 09:16:25 --> Helper loaded: string_helper
DEBUG - 2010-07-01 09:16:25 --> Session routines successfully run
DEBUG - 2010-07-01 09:16:25 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 09:16:25 --> Config file loaded: config/kals.php
DEBUG - 2010-07-01 09:16:25 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 09:16:25 --> Final output sent to browser
DEBUG - 2010-07-01 09:16:25 --> Total execution time: 1.6016
DEBUG - 2010-07-01 09:18:02 --> Config Class Initialized
DEBUG - 2010-07-01 09:18:02 --> Hooks Class Initialized
DEBUG - 2010-07-01 09:18:02 --> URI Class Initialized
DEBUG - 2010-07-01 09:18:02 --> Router Class Initialized
DEBUG - 2010-07-01 09:18:02 --> Output Class Initialized
DEBUG - 2010-07-01 09:18:02 --> Input Class Initialized
DEBUG - 2010-07-01 09:18:02 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 09:18:02 --> Language Class Initialized
DEBUG - 2010-07-01 09:18:02 --> Loader Class Initialized
DEBUG - 2010-07-01 09:18:02 --> Helper loaded: context_helper
DEBUG - 2010-07-01 09:18:02 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 09:18:02 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 09:18:03 --> Database Driver Class Initialized
DEBUG - 2010-07-01 09:18:03 --> Controller Class Initialized
DEBUG - 2010-07-01 09:18:03 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 09:18:03 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 09:18:03 --> Session Class Initialized
DEBUG - 2010-07-01 09:18:03 --> Helper loaded: string_helper
DEBUG - 2010-07-01 09:18:03 --> Session routines successfully run
DEBUG - 2010-07-01 09:18:03 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 09:18:03 --> Config file loaded: config/kals.php
DEBUG - 2010-07-01 09:18:04 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 09:18:04 --> Final output sent to browser
DEBUG - 2010-07-01 09:18:04 --> Total execution time: 1.8420
DEBUG - 2010-07-01 09:19:33 --> Config Class Initialized
DEBUG - 2010-07-01 09:19:33 --> Hooks Class Initialized
DEBUG - 2010-07-01 09:19:33 --> URI Class Initialized
DEBUG - 2010-07-01 09:19:33 --> Router Class Initialized
DEBUG - 2010-07-01 09:19:33 --> Output Class Initialized
DEBUG - 2010-07-01 09:19:34 --> Input Class Initialized
DEBUG - 2010-07-01 09:19:34 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-01 09:19:34 --> Language Class Initialized
DEBUG - 2010-07-01 09:19:34 --> Loader Class Initialized
DEBUG - 2010-07-01 09:19:34 --> Helper loaded: context_helper
DEBUG - 2010-07-01 09:19:34 --> Helper loaded: kals_helper
DEBUG - 2010-07-01 09:19:34 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-01 09:19:34 --> Database Driver Class Initialized
DEBUG - 2010-07-01 09:19:34 --> Controller Class Initialized
DEBUG - 2010-07-01 09:19:34 --> Unit Testing Class Initialized
DEBUG - 2010-07-01 09:19:34 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-01 09:19:34 --> Session Class Initialized
DEBUG - 2010-07-01 09:19:34 --> Helper loaded: string_helper
DEBUG - 2010-07-01 09:19:34 --> Session routines successfully run
DEBUG - 2010-07-01 09:19:34 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-01 09:19:34 --> Config file loaded: config/kals.php
DEBUG - 2010-07-01 09:19:35 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-01 09:19:35 --> Final output sent to browser
DEBUG - 2010-07-01 09:19:35 --> Total execution time: 1.5836
