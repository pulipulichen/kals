<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-07-19 06:37:10 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-19 06:37:10 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-19 06:37:14 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/fbd7939d674997cdb4692d34de8633c4) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-19 11:40:55 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-19 11:40:56 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-19 12:53:36 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-19 12:53:36 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;&quot;
JOIN &quot;&quot;
LINE 2: FROM &quot;annotation2scope&quot;
                              ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-19 12:53:36 --> Query error: ERROR:  syntax error at or near ""
JOIN ""
LINE 2: FROM "annotation2scope"
                              ^
ERROR - 2010-07-19 12:53:36 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-19 12:53:37 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;&quot;
JOIN &quot;&quot;
LINE 2: FROM &quot;annotation2scope&quot;
                              ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-19 12:53:37 --> Query error: ERROR:  syntax error at or near ""
JOIN ""
LINE 2: FROM "annotation2scope"
                              ^
ERROR - 2010-07-19 12:53:37 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;&quot;
JOIN &quot;&quot;
LINE 2: FROM &quot;annotation2scope&quot;
                              ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-19 12:53:37 --> Query error: ERROR:  syntax error at or near ""
JOIN ""
LINE 2: FROM "annotation2scope"
                              ^
ERROR - 2010-07-19 12:53:40 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;&quot;
JOIN &quot;&quot;
LINE 2: FROM &quot;annotation2scope&quot;
                              ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-19 12:53:40 --> Query error: ERROR:  syntax error at or near ""
JOIN ""
LINE 2: FROM "annotation2scope"
                              ^
ERROR - 2010-07-19 12:53:41 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;&quot;
JOIN &quot;&quot;
LINE 2: FROM &quot;annotation2scope&quot;
                              ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-19 12:53:41 --> Query error: ERROR:  syntax error at or near ""
JOIN ""
LINE 2: FROM "annotation2scope"
                              ^
ERROR - 2010-07-19 12:53:41 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;&quot;
JOIN &quot;&quot;
LINE 2: FROM &quot;annotation2scope&quot;
                              ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-19 12:53:41 --> Query error: ERROR:  syntax error at or near ""
JOIN ""
LINE 2: FROM "annotation2scope"
                              ^
ERROR - 2010-07-19 12:53:41 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;&quot;
JOIN &quot;&quot;
LINE 2: FROM &quot;annotation2scope&quot;
                              ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-19 12:53:41 --> Query error: ERROR:  syntax error at or near ""
JOIN ""
LINE 2: FROM "annotation2scope"
                              ^
ERROR - 2010-07-19 12:53:42 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;&quot;
JOIN &quot;&quot;
LINE 2: FROM &quot;annotation2scope&quot;
                              ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-19 12:53:42 --> Query error: ERROR:  syntax error at or near ""
JOIN ""
LINE 2: FROM "annotation2scope"
                              ^
ERROR - 2010-07-19 12:53:42 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;&quot;
JOIN &quot;&quot;
LINE 2: FROM &quot;annotation2scope&quot;
                              ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-19 12:53:42 --> Query error: ERROR:  syntax error at or near ""
JOIN ""
LINE 2: FROM "annotation2scope"
                              ^
ERROR - 2010-07-19 12:54:04 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;&quot;
JOIN &quot;&quot;
LINE 2: FROM &quot;annotation2scope&quot;
                              ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-19 12:54:04 --> Query error: ERROR:  syntax error at or near ""
JOIN ""
LINE 2: FROM "annotation2scope"
                              ^
ERROR - 2010-07-19 12:55:23 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;&quot;
JOIN &quot;&quot;
LINE 2: FROM &quot;annotation2scope&quot;
                              ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-19 12:55:23 --> Query error: ERROR:  syntax error at or near ""
JOIN ""
LINE 2: FROM "annotation2scope"
                              ^
ERROR - 2010-07-19 12:55:37 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;&quot;
JOIN &quot;&quot;
LINE 2: FROM &quot;annotation2respond&quot;
                                ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-19 12:55:37 --> Query error: ERROR:  syntax error at or near ""
JOIN ""
LINE 2: FROM "annotation2respond"
                                ^
ERROR - 2010-07-19 12:56:25 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;&quot;
JOIN &quot;&quot;
LINE 2: FROM &quot;annotation2respond&quot;
                                ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-19 12:56:25 --> Query error: ERROR:  syntax error at or near ""
JOIN ""
LINE 2: FROM "annotation2respond"
                                ^
ERROR - 2010-07-19 12:57:32 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;&quot;
JOIN &quot;&quot;
LINE 2: FROM &quot;annotation2respond&quot;
                                ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-19 12:57:32 --> Query error: ERROR:  syntax error at or near ""
JOIN ""
LINE 2: FROM "annotation2respond"
                                ^
ERROR - 2010-07-19 12:57:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:395) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-19 12:57:55 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;&quot;
JOIN &quot;&quot;
LINE 2: FROM &quot;annotation2respond&quot;
                                ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-19 12:57:55 --> Query error: ERROR:  syntax error at or near ""
JOIN ""
LINE 2: FROM "annotation2respond"
                                ^
ERROR - 2010-07-19 12:57:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:395) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-19 12:59:10 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/a5771bce93e200c36f7cd9dfd0e5deaa) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-19 12:59:11 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-19 12:59:11 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-19 12:59:12 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/c0c7c76d30bd3dcaefc96f40275bdc0a) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-19 13:42:34 --> Severity: Notice  --> Undefined property: MY_Unit_test::$benchmark_index D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\MY_Unit_test.php 25
ERROR - 2010-07-19 13:42:34 --> Severity: Notice  --> Undefined property: MY_Unit_test::$benchmark_title D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\MY_Unit_test.php 25
ERROR - 2010-07-19 13:42:34 --> Severity: Notice  --> Undefined property: MY_Unit_test::$benchmark_index D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\MY_Unit_test.php 104
ERROR - 2010-07-19 13:42:34 --> Severity: Notice  --> Undefined property: MY_Unit_test::$benchmark_title D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\MY_Unit_test.php 104
ERROR - 2010-07-19 13:42:34 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Session.php 662
ERROR - 2010-07-19 13:42:34 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Session.php 662
ERROR - 2010-07-19 13:58:34 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-19 13:58:38 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-19 13:59:32 --> Severity: Warning  --> fopen(http://localhost/CodeIgniter_1.7.2/unit_test) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: �s�u���ե��ѡA�]���s�u��H���@�q�ɶ��å����T�^���A�άO�s�u�إߥ��ѡA�]���s�u���D���L�k�^���C
 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 207
ERROR - 2010-07-19 13:59:32 --> Severity: Warning  --> fread(): supplied argument is not a valid stream resource D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 208
ERROR - 2010-07-19 13:59:32 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 209
ERROR - 2010-07-19 13:59:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Session.php 662
ERROR - 2010-07-19 13:59:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Session.php 662
ERROR - 2010-07-19 13:59:59 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 14:00:14 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 14:00:48 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 14:02:12 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 14:02:12 --> 404 Page Not Found --> ajax-loader.gif
ERROR - 2010-07-19 14:02:31 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 14:03:17 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 14:03:39 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 14:03:52 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 14:04:50 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-19 14:04:51 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-19 14:04:57 --> Severity: Warning  --> fopen() [<a href='function.fopen'>function.fopen</a>]: php_network_getaddresses: getaddrinfo failed: �n�D���W�٥��T�A���䤣��ҭn�D��������ơC  D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 207
ERROR - 2010-07-19 14:04:57 --> Severity: Warning  --> fopen(http://www.plurk.com/p/6esun8) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: php_network_getaddresses: getaddrinfo failed: �n�D���W�٥��T�A���䤣��ҭn�D��������ơC  D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 207
ERROR - 2010-07-19 14:04:57 --> Severity: Warning  --> fread(): supplied argument is not a valid stream resource D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 208
ERROR - 2010-07-19 14:04:57 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 209
ERROR - 2010-07-19 14:04:58 --> Severity: Warning  --> get_headers() [<a href='function.get-headers'>function.get-headers</a>]: php_network_getaddresses: getaddrinfo failed: �n�D���W�٥��T�A���䤣��ҭn�D��������ơC  D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 119
ERROR - 2010-07-19 14:04:58 --> Severity: Warning  --> get_headers(http://www.plurk.com:80/p/5u89gi) [<a href='function.get-headers'>function.get-headers</a>]: failed to open stream: php_network_getaddresses: getaddrinfo failed: �n�D���W�٥��T�A���䤣��ҭn�D��������ơC  D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 119
ERROR - 2010-07-19 14:05:05 --> Severity: Warning  --> fopen() [<a href='function.fopen'>function.fopen</a>]: php_network_getaddresses: getaddrinfo failed: �n�D���W�٥��T�A���䤣��ҭn�D��������ơC  D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 207
ERROR - 2010-07-19 14:05:05 --> Severity: Warning  --> fopen(http://www.plurk.com/p/6esun8) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: php_network_getaddresses: getaddrinfo failed: �n�D���W�٥��T�A���䤣��ҭn�D��������ơC  D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 207
ERROR - 2010-07-19 14:05:05 --> Severity: Warning  --> fread(): supplied argument is not a valid stream resource D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 208
ERROR - 2010-07-19 14:05:05 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 209
ERROR - 2010-07-19 14:05:06 --> Severity: Warning  --> fopen() [<a href='function.fopen'>function.fopen</a>]: php_network_getaddresses: getaddrinfo failed: �n�D���W�٥��T�A���䤣��ҭn�D��������ơC  D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 207
ERROR - 2010-07-19 14:05:06 --> Severity: Warning  --> fopen(http://www.plurk.com/p/6e8ya0) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: php_network_getaddresses: getaddrinfo failed: �n�D���W�٥��T�A���䤣��ҭn�D��������ơC  D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 207
ERROR - 2010-07-19 14:05:06 --> Severity: Warning  --> fread(): supplied argument is not a valid stream resource D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 208
ERROR - 2010-07-19 14:05:06 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php 209
ERROR - 2010-07-19 14:14:35 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  null value in column &quot;user_data&quot; violates not-null constraint D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-19 14:14:35 --> Query error: ERROR:  null value in column "user_data" violates not-null constraint
ERROR - 2010-07-19 14:15:30 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 14:15:35 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 14:30:11 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-19 14:30:11 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-19 14:30:21 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 14:37:16 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 14:38:02 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 14:47:55 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 14:48:17 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 14:51:34 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 14:52:35 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 14:54:39 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 14:55:53 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 14:56:32 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 14:57:55 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:00:24 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:01:13 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:01:31 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:02:34 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:03:20 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:06:30 --> Severity: Notice  --> Undefined property: Scope_anchor_text::$get_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Scope_anchor_text.php 105
ERROR - 2010-07-19 15:06:30 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  relation &quot;anchor_text_id&quot; does not exist
LINE 2: FROM &quot;anchor_text_id&quot;, &quot;text&quot;, &quot;indexed&quot;, &quot;segmented&quot;
             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-19 15:06:30 --> Query error: ERROR:  relation "anchor_text_id" does not exist
LINE 2: FROM "anchor_text_id", "text", "indexed", "segmented"
             ^
ERROR - 2010-07-19 15:06:30 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:385) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-19 15:06:44 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  relation &quot;anchor_text_id&quot; does not exist
LINE 2: FROM &quot;anchor_text_id&quot;, &quot;text&quot;, &quot;indexed&quot;, &quot;segmented&quot;
             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-19 15:06:44 --> Query error: ERROR:  relation "anchor_text_id" does not exist
LINE 2: FROM "anchor_text_id", "text", "indexed", "segmented"
             ^
ERROR - 2010-07-19 15:06:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:385) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-19 15:07:10 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  relation &quot;anchor_text_id&quot; does not exist
LINE 2: FROM &quot;anchor_text_id&quot;, &quot;text&quot;, &quot;indexed&quot;, &quot;segmented&quot;
             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-19 15:07:10 --> Query error: ERROR:  relation "anchor_text_id" does not exist
LINE 2: FROM "anchor_text_id", "text", "indexed", "segmented"
             ^
ERROR - 2010-07-19 15:07:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:385) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-19 15:07:17 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  relation &quot;anchor_text_id&quot; does not exist
LINE 2: FROM &quot;anchor_text_id&quot;, &quot;text&quot;, &quot;indexed&quot;, &quot;segmented&quot;
             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-19 15:07:17 --> Query error: ERROR:  relation "anchor_text_id" does not exist
LINE 2: FROM "anchor_text_id", "text", "indexed", "segmented"
             ^
ERROR - 2010-07-19 15:07:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:385) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-19 15:07:39 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:08:04 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:10:22 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:10:49 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:14:07 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:17:08 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:17:27 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:17:49 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:19:13 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:19:26 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:23:45 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:24:41 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:27:33 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:28:37 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:29:34 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:30:04 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:30:46 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:30:56 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:31:08 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:34:31 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:34:45 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:36:10 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:36:34 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/c4ca4238a0b923820dcc509a6f75849b) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-19 15:36:34 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:38:04 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:38:45 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:43:21 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:43:56 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:44:15 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:45:58 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:46:17 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:46:55 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:48:15 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:48:52 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  relation &quot;129&quot; does not exist
LINE 2: FROM &quot;129&quot;, &quot;138&quot;, &quot;3&quot;, &quot;20&quot;, &quot;169&quot;, &quot;2175&quot;
             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-19 15:48:52 --> Query error: ERROR:  relation "129" does not exist
LINE 2: FROM "129", "138", "3", "20", "169", "2175"
             ^
ERROR - 2010-07-19 15:48:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:395) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-19 15:49:35 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:50:50 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:51:05 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:51:30 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:57:21 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:58:05 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 15:59:32 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-19 15:59:33 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-19 16:00:16 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 16:00:59 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 16:02:30 --> 404 Page Not Found --> jquery.js
ERROR - 2010-07-19 16:14:15 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-19 16:14:16 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-19 16:14:19 --> Severity: Warning  --> chmod() [<a href='function.chmod'>function.chmod</a>]: No such file or directory D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 73
ERROR - 2010-07-19 16:14:19 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/43ec517d68b6edd3015b3edc9a11367b) [<a href='function.unlink'>function.unlink</a>]: No such file or directory D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-19 16:18:54 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/e2c420d928d4bf8ce0ff2ec19b371514) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-19 16:18:55 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-19 16:18:56 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-19 16:20:23 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-19 16:20:23 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/92cc227532d17e56e07902b254dfad10) [<a href='function.unlink'>function.unlink</a>]: No such file or directory D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-19 16:20:23 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-19 16:20:25 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/c7e1249ffc03eb9ded908c236bd1996d) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-19 16:20:28 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/9778d5d219c5080b9a6a17bef029331c) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
