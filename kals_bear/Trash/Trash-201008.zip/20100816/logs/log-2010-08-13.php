<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-08-13 13:08:36 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/d09bf41544a3365a46c9077ebb5e35c3) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-08-13 13:21:52 --> Severity: Warning  --> chmod() [<a href='function.chmod'>function.chmod</a>]: No such file or directory D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 73
ERROR - 2010-08-13 13:21:52 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/c16a5320fa475530d9583c34fd356ef5) [<a href='function.unlink'>function.unlink</a>]: No such file or directory D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-08-13 13:52:09 --> 404 Page Not Found --> web_apps/CodeIgniter_1.7.2
ERROR - 2010-08-13 13:52:22 --> 404 Page Not Found --> web_apps/CodeIgniter_1.7.2
ERROR - 2010-08-13 13:54:42 --> 404 Page Not Found --> web_apps/CodeIgniter_1.7.2
ERROR - 2010-08-13 13:54:42 --> Severity: Warning  --> Missing argument 1 for authentication::check_user() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\web_apps\authentication.php 72
ERROR - 2010-08-13 13:55:15 --> Cannot get referer url.
ERROR - 2010-08-13 13:55:54 --> 404 Page Not Found --> web_apps/CodeIgniter_1.7.2
ERROR - 2010-08-13 13:56:42 --> 404 Page Not Found --> web_apps/CodeIgniter_1.7.2
ERROR - 2010-08-13 13:57:01 --> 404 Page Not Found --> web_apps/CodeIgniter_1.7.2
