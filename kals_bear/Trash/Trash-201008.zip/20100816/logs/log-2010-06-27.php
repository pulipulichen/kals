<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2010-06-27 05:22:24 --> Config Class Initialized
DEBUG - 2010-06-27 05:22:24 --> Hooks Class Initialized
DEBUG - 2010-06-27 05:22:24 --> URI Class Initialized
DEBUG - 2010-06-27 05:22:24 --> No URI present. Default controller set.
DEBUG - 2010-06-27 05:22:24 --> Router Class Initialized
DEBUG - 2010-06-27 05:22:24 --> Output Class Initialized
DEBUG - 2010-06-27 05:22:24 --> Input Class Initialized
DEBUG - 2010-06-27 05:22:24 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 05:22:24 --> Language Class Initialized
DEBUG - 2010-06-27 05:22:24 --> Loader Class Initialized
DEBUG - 2010-06-27 05:22:24 --> Helper loaded: object_helper
DEBUG - 2010-06-27 05:22:24 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 05:22:24 --> Helper loaded: context_helper
DEBUG - 2010-06-27 05:22:24 --> Session Class Initialized
DEBUG - 2010-06-27 05:22:24 --> Helper loaded: string_helper
DEBUG - 2010-06-27 05:22:24 --> A session cookie was not found.
DEBUG - 2010-06-27 05:22:24 --> Session routines successfully run
DEBUG - 2010-06-27 05:22:24 --> Helper loaded: context_helper
DEBUG - 2010-06-27 05:22:24 --> Controller Class Initialized
DEBUG - 2010-06-27 05:22:24 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-27 05:22:24 --> Database Driver Class Initialized
DEBUG - 2010-06-27 05:22:24 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 05:22:24 --> Config file loaded: config/kals.php
DEBUG - 2010-06-27 05:22:24 --> Final output sent to browser
DEBUG - 2010-06-27 05:22:24 --> Total execution time: 0.7661
DEBUG - 2010-06-27 05:22:40 --> Config Class Initialized
DEBUG - 2010-06-27 05:22:40 --> Hooks Class Initialized
DEBUG - 2010-06-27 05:22:40 --> URI Class Initialized
DEBUG - 2010-06-27 05:22:40 --> No URI present. Default controller set.
DEBUG - 2010-06-27 05:22:40 --> Router Class Initialized
DEBUG - 2010-06-27 05:22:40 --> Output Class Initialized
DEBUG - 2010-06-27 05:22:40 --> Input Class Initialized
DEBUG - 2010-06-27 05:22:40 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 05:22:40 --> Language Class Initialized
DEBUG - 2010-06-27 05:22:40 --> Loader Class Initialized
DEBUG - 2010-06-27 05:22:40 --> Helper loaded: object_helper
DEBUG - 2010-06-27 05:22:40 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 05:22:40 --> Helper loaded: context_helper
DEBUG - 2010-06-27 05:22:40 --> Session Class Initialized
DEBUG - 2010-06-27 05:22:40 --> Helper loaded: string_helper
DEBUG - 2010-06-27 05:22:40 --> Session routines successfully run
DEBUG - 2010-06-27 05:22:40 --> Helper loaded: context_helper
DEBUG - 2010-06-27 05:22:40 --> Controller Class Initialized
DEBUG - 2010-06-27 05:22:40 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-27 05:22:40 --> Database Driver Class Initialized
DEBUG - 2010-06-27 05:22:40 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 05:22:40 --> Final output sent to browser
DEBUG - 2010-06-27 05:22:40 --> Total execution time: 0.1185
DEBUG - 2010-06-27 05:22:48 --> Config Class Initialized
DEBUG - 2010-06-27 05:22:48 --> Hooks Class Initialized
DEBUG - 2010-06-27 05:22:48 --> URI Class Initialized
DEBUG - 2010-06-27 05:22:48 --> No URI present. Default controller set.
DEBUG - 2010-06-27 05:22:48 --> Router Class Initialized
DEBUG - 2010-06-27 05:22:48 --> Output Class Initialized
DEBUG - 2010-06-27 05:22:48 --> Input Class Initialized
DEBUG - 2010-06-27 05:22:48 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 05:22:48 --> Language Class Initialized
DEBUG - 2010-06-27 05:22:48 --> Loader Class Initialized
DEBUG - 2010-06-27 05:22:48 --> Helper loaded: object_helper
DEBUG - 2010-06-27 05:22:48 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 05:22:48 --> Helper loaded: context_helper
DEBUG - 2010-06-27 05:22:48 --> Session Class Initialized
DEBUG - 2010-06-27 05:22:48 --> Helper loaded: string_helper
DEBUG - 2010-06-27 05:22:48 --> Session routines successfully run
DEBUG - 2010-06-27 05:22:48 --> Helper loaded: context_helper
DEBUG - 2010-06-27 05:22:48 --> Controller Class Initialized
DEBUG - 2010-06-27 05:22:48 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-27 05:22:48 --> Database Driver Class Initialized
DEBUG - 2010-06-27 05:22:48 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 05:22:48 --> Final output sent to browser
DEBUG - 2010-06-27 05:22:48 --> Total execution time: 0.1345
DEBUG - 2010-06-27 05:35:04 --> Config Class Initialized
DEBUG - 2010-06-27 05:35:04 --> Hooks Class Initialized
DEBUG - 2010-06-27 05:35:04 --> URI Class Initialized
DEBUG - 2010-06-27 05:35:04 --> No URI present. Default controller set.
DEBUG - 2010-06-27 05:35:04 --> Router Class Initialized
DEBUG - 2010-06-27 05:35:04 --> Output Class Initialized
DEBUG - 2010-06-27 05:35:04 --> Input Class Initialized
DEBUG - 2010-06-27 05:35:04 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 05:35:04 --> Language Class Initialized
DEBUG - 2010-06-27 05:35:04 --> Loader Class Initialized
DEBUG - 2010-06-27 05:35:04 --> Helper loaded: object_helper
DEBUG - 2010-06-27 05:35:04 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 05:35:04 --> Helper loaded: context_helper
DEBUG - 2010-06-27 05:35:04 --> Session Class Initialized
DEBUG - 2010-06-27 05:35:04 --> Helper loaded: string_helper
DEBUG - 2010-06-27 05:35:04 --> Session routines successfully run
DEBUG - 2010-06-27 05:35:04 --> Helper loaded: context_helper
DEBUG - 2010-06-27 05:35:04 --> Controller Class Initialized
DEBUG - 2010-06-27 05:35:04 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-27 05:35:04 --> Database Driver Class Initialized
DEBUG - 2010-06-27 05:35:04 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 05:35:04 --> Final output sent to browser
DEBUG - 2010-06-27 05:35:04 --> Total execution time: 0.1851
DEBUG - 2010-06-27 06:54:35 --> Config Class Initialized
DEBUG - 2010-06-27 06:54:35 --> Hooks Class Initialized
DEBUG - 2010-06-27 06:54:35 --> URI Class Initialized
DEBUG - 2010-06-27 06:54:35 --> No URI present. Default controller set.
DEBUG - 2010-06-27 06:54:35 --> Router Class Initialized
DEBUG - 2010-06-27 06:54:35 --> Output Class Initialized
DEBUG - 2010-06-27 06:54:35 --> Input Class Initialized
DEBUG - 2010-06-27 06:54:35 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 06:54:35 --> Language Class Initialized
DEBUG - 2010-06-27 06:54:35 --> Loader Class Initialized
DEBUG - 2010-06-27 06:54:35 --> Helper loaded: object_helper
DEBUG - 2010-06-27 06:54:35 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 06:54:35 --> Helper loaded: context_helper
DEBUG - 2010-06-27 06:54:35 --> Session Class Initialized
DEBUG - 2010-06-27 06:54:35 --> Helper loaded: string_helper
DEBUG - 2010-06-27 06:54:36 --> Session routines successfully run
DEBUG - 2010-06-27 06:54:36 --> Helper loaded: context_helper
DEBUG - 2010-06-27 06:54:36 --> Controller Class Initialized
DEBUG - 2010-06-27 06:54:36 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-27 06:54:36 --> Database Driver Class Initialized
DEBUG - 2010-06-27 06:54:36 --> Final output sent to browser
DEBUG - 2010-06-27 06:54:36 --> Total execution time: 0.2696
DEBUG - 2010-06-27 06:54:50 --> Config Class Initialized
DEBUG - 2010-06-27 06:54:50 --> Hooks Class Initialized
DEBUG - 2010-06-27 06:54:50 --> URI Class Initialized
DEBUG - 2010-06-27 06:54:50 --> No URI present. Default controller set.
DEBUG - 2010-06-27 06:54:50 --> Router Class Initialized
DEBUG - 2010-06-27 06:54:50 --> Output Class Initialized
DEBUG - 2010-06-27 06:54:50 --> Input Class Initialized
DEBUG - 2010-06-27 06:54:50 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 06:54:50 --> Language Class Initialized
DEBUG - 2010-06-27 06:54:50 --> Loader Class Initialized
DEBUG - 2010-06-27 06:54:50 --> Helper loaded: object_helper
DEBUG - 2010-06-27 06:54:50 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 06:54:50 --> Helper loaded: context_helper
DEBUG - 2010-06-27 06:54:50 --> Session Class Initialized
DEBUG - 2010-06-27 06:54:50 --> Helper loaded: string_helper
DEBUG - 2010-06-27 06:54:50 --> Session routines successfully run
DEBUG - 2010-06-27 06:54:50 --> Helper loaded: context_helper
DEBUG - 2010-06-27 06:54:50 --> Controller Class Initialized
DEBUG - 2010-06-27 06:54:50 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-27 06:54:50 --> Database Driver Class Initialized
DEBUG - 2010-06-27 06:54:50 --> Final output sent to browser
DEBUG - 2010-06-27 06:54:50 --> Total execution time: 0.2839
DEBUG - 2010-06-27 07:09:36 --> Config Class Initialized
DEBUG - 2010-06-27 07:09:36 --> Hooks Class Initialized
DEBUG - 2010-06-27 07:09:36 --> URI Class Initialized
DEBUG - 2010-06-27 07:09:36 --> No URI present. Default controller set.
DEBUG - 2010-06-27 07:09:36 --> Router Class Initialized
DEBUG - 2010-06-27 07:09:36 --> Output Class Initialized
DEBUG - 2010-06-27 07:09:36 --> Input Class Initialized
DEBUG - 2010-06-27 07:09:36 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 07:09:36 --> Language Class Initialized
DEBUG - 2010-06-27 07:09:36 --> Loader Class Initialized
DEBUG - 2010-06-27 07:09:36 --> Helper loaded: object_helper
DEBUG - 2010-06-27 07:09:36 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 07:09:36 --> Helper loaded: context_helper
DEBUG - 2010-06-27 07:09:36 --> Session Class Initialized
DEBUG - 2010-06-27 07:09:36 --> Helper loaded: string_helper
DEBUG - 2010-06-27 07:09:36 --> Session routines successfully run
DEBUG - 2010-06-27 07:09:36 --> Helper loaded: context_helper
DEBUG - 2010-06-27 07:09:36 --> Controller Class Initialized
DEBUG - 2010-06-27 07:09:36 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-27 07:46:28 --> Config Class Initialized
DEBUG - 2010-06-27 07:46:28 --> Hooks Class Initialized
DEBUG - 2010-06-27 07:46:28 --> URI Class Initialized
DEBUG - 2010-06-27 07:46:28 --> No URI present. Default controller set.
DEBUG - 2010-06-27 07:46:28 --> Router Class Initialized
DEBUG - 2010-06-27 07:46:28 --> Output Class Initialized
DEBUG - 2010-06-27 07:46:28 --> Input Class Initialized
DEBUG - 2010-06-27 07:46:28 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 07:46:28 --> Language Class Initialized
DEBUG - 2010-06-27 07:46:28 --> Loader Class Initialized
DEBUG - 2010-06-27 07:46:28 --> Helper loaded: object_helper
DEBUG - 2010-06-27 07:46:28 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 07:46:28 --> Helper loaded: context_helper
DEBUG - 2010-06-27 07:46:28 --> Session Class Initialized
DEBUG - 2010-06-27 07:46:28 --> Helper loaded: string_helper
DEBUG - 2010-06-27 07:46:28 --> Session routines successfully run
DEBUG - 2010-06-27 07:46:28 --> Helper loaded: context_helper
DEBUG - 2010-06-27 07:46:28 --> Database Driver Class Initialized
DEBUG - 2010-06-27 07:46:28 --> Controller Class Initialized
DEBUG - 2010-06-27 07:46:28 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-27 07:46:46 --> Config Class Initialized
DEBUG - 2010-06-27 07:46:46 --> Hooks Class Initialized
DEBUG - 2010-06-27 07:46:46 --> URI Class Initialized
DEBUG - 2010-06-27 07:46:46 --> No URI present. Default controller set.
DEBUG - 2010-06-27 07:46:47 --> Router Class Initialized
DEBUG - 2010-06-27 07:46:47 --> Output Class Initialized
DEBUG - 2010-06-27 07:46:47 --> Input Class Initialized
DEBUG - 2010-06-27 07:46:47 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 07:46:47 --> Language Class Initialized
DEBUG - 2010-06-27 07:46:47 --> Loader Class Initialized
DEBUG - 2010-06-27 07:46:47 --> Helper loaded: object_helper
DEBUG - 2010-06-27 07:46:47 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 07:46:47 --> Helper loaded: context_helper
DEBUG - 2010-06-27 07:46:47 --> Session Class Initialized
DEBUG - 2010-06-27 07:46:47 --> Helper loaded: string_helper
DEBUG - 2010-06-27 07:46:47 --> Session routines successfully run
DEBUG - 2010-06-27 07:46:47 --> Helper loaded: context_helper
DEBUG - 2010-06-27 07:46:47 --> Database Driver Class Initialized
DEBUG - 2010-06-27 07:46:47 --> Controller Class Initialized
DEBUG - 2010-06-27 07:46:47 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-27 07:47:01 --> Config Class Initialized
DEBUG - 2010-06-27 07:47:01 --> Hooks Class Initialized
DEBUG - 2010-06-27 07:47:01 --> URI Class Initialized
DEBUG - 2010-06-27 07:47:01 --> No URI present. Default controller set.
DEBUG - 2010-06-27 07:47:01 --> Router Class Initialized
DEBUG - 2010-06-27 07:47:01 --> Output Class Initialized
DEBUG - 2010-06-27 07:47:01 --> Input Class Initialized
DEBUG - 2010-06-27 07:47:01 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 07:47:01 --> Language Class Initialized
DEBUG - 2010-06-27 07:47:01 --> Loader Class Initialized
DEBUG - 2010-06-27 07:47:01 --> Helper loaded: object_helper
DEBUG - 2010-06-27 07:47:01 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 07:47:01 --> Helper loaded: context_helper
DEBUG - 2010-06-27 07:47:01 --> Session Class Initialized
DEBUG - 2010-06-27 07:47:01 --> Helper loaded: string_helper
DEBUG - 2010-06-27 07:47:01 --> Session routines successfully run
DEBUG - 2010-06-27 07:47:01 --> Helper loaded: context_helper
DEBUG - 2010-06-27 07:47:01 --> Database Driver Class Initialized
DEBUG - 2010-06-27 07:47:01 --> Controller Class Initialized
DEBUG - 2010-06-27 07:47:01 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-27 07:47:08 --> Config Class Initialized
DEBUG - 2010-06-27 07:47:08 --> Hooks Class Initialized
DEBUG - 2010-06-27 07:47:08 --> URI Class Initialized
DEBUG - 2010-06-27 07:47:08 --> No URI present. Default controller set.
DEBUG - 2010-06-27 07:47:08 --> Router Class Initialized
DEBUG - 2010-06-27 07:47:08 --> Output Class Initialized
DEBUG - 2010-06-27 07:47:08 --> Input Class Initialized
DEBUG - 2010-06-27 07:47:08 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 07:47:08 --> Language Class Initialized
DEBUG - 2010-06-27 07:47:08 --> Loader Class Initialized
DEBUG - 2010-06-27 07:47:08 --> Helper loaded: object_helper
DEBUG - 2010-06-27 07:47:08 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 07:47:08 --> Helper loaded: context_helper
DEBUG - 2010-06-27 07:47:08 --> Session Class Initialized
DEBUG - 2010-06-27 07:47:08 --> Helper loaded: string_helper
DEBUG - 2010-06-27 07:47:08 --> Session routines successfully run
DEBUG - 2010-06-27 07:47:08 --> Helper loaded: context_helper
DEBUG - 2010-06-27 07:47:09 --> Database Driver Class Initialized
DEBUG - 2010-06-27 07:47:09 --> Controller Class Initialized
DEBUG - 2010-06-27 07:47:09 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-27 07:47:11 --> Config Class Initialized
DEBUG - 2010-06-27 07:47:11 --> Hooks Class Initialized
DEBUG - 2010-06-27 07:47:11 --> URI Class Initialized
DEBUG - 2010-06-27 07:47:11 --> No URI present. Default controller set.
DEBUG - 2010-06-27 07:47:11 --> Router Class Initialized
DEBUG - 2010-06-27 07:47:11 --> Output Class Initialized
DEBUG - 2010-06-27 07:47:11 --> Input Class Initialized
DEBUG - 2010-06-27 07:47:11 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 07:47:11 --> Language Class Initialized
DEBUG - 2010-06-27 07:47:11 --> Loader Class Initialized
DEBUG - 2010-06-27 07:47:11 --> Helper loaded: object_helper
DEBUG - 2010-06-27 07:47:11 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 07:47:11 --> Helper loaded: context_helper
DEBUG - 2010-06-27 07:47:11 --> Session Class Initialized
DEBUG - 2010-06-27 07:47:11 --> Helper loaded: string_helper
DEBUG - 2010-06-27 07:47:11 --> Session routines successfully run
DEBUG - 2010-06-27 07:47:11 --> Helper loaded: context_helper
DEBUG - 2010-06-27 07:47:11 --> Database Driver Class Initialized
DEBUG - 2010-06-27 07:47:11 --> Controller Class Initialized
DEBUG - 2010-06-27 07:47:11 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-27 07:47:23 --> Config Class Initialized
DEBUG - 2010-06-27 07:47:23 --> Hooks Class Initialized
DEBUG - 2010-06-27 07:47:23 --> URI Class Initialized
DEBUG - 2010-06-27 07:47:23 --> No URI present. Default controller set.
DEBUG - 2010-06-27 07:47:23 --> Router Class Initialized
DEBUG - 2010-06-27 07:47:23 --> Output Class Initialized
DEBUG - 2010-06-27 07:47:23 --> Input Class Initialized
DEBUG - 2010-06-27 07:47:23 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 07:47:23 --> Language Class Initialized
DEBUG - 2010-06-27 07:47:23 --> Loader Class Initialized
DEBUG - 2010-06-27 07:47:23 --> Helper loaded: object_helper
DEBUG - 2010-06-27 07:47:23 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 07:47:23 --> Helper loaded: context_helper
DEBUG - 2010-06-27 07:47:23 --> Session Class Initialized
DEBUG - 2010-06-27 07:47:23 --> Helper loaded: string_helper
DEBUG - 2010-06-27 07:47:23 --> Session routines successfully run
DEBUG - 2010-06-27 07:47:23 --> Helper loaded: context_helper
DEBUG - 2010-06-27 07:47:23 --> Database Driver Class Initialized
DEBUG - 2010-06-27 07:47:23 --> Controller Class Initialized
DEBUG - 2010-06-27 07:47:23 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-27 07:47:52 --> Config Class Initialized
DEBUG - 2010-06-27 07:47:52 --> Hooks Class Initialized
DEBUG - 2010-06-27 07:47:52 --> URI Class Initialized
DEBUG - 2010-06-27 07:47:52 --> No URI present. Default controller set.
DEBUG - 2010-06-27 07:47:52 --> Router Class Initialized
DEBUG - 2010-06-27 07:47:52 --> Output Class Initialized
DEBUG - 2010-06-27 07:47:52 --> Input Class Initialized
DEBUG - 2010-06-27 07:47:52 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 07:47:52 --> Language Class Initialized
DEBUG - 2010-06-27 07:47:52 --> Loader Class Initialized
DEBUG - 2010-06-27 07:47:52 --> Helper loaded: object_helper
DEBUG - 2010-06-27 07:47:52 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 07:47:52 --> Helper loaded: context_helper
DEBUG - 2010-06-27 07:47:52 --> Session Class Initialized
DEBUG - 2010-06-27 07:47:52 --> Helper loaded: string_helper
DEBUG - 2010-06-27 07:47:52 --> Session routines successfully run
DEBUG - 2010-06-27 07:47:52 --> Helper loaded: context_helper
DEBUG - 2010-06-27 07:47:52 --> Database Driver Class Initialized
DEBUG - 2010-06-27 07:47:52 --> Controller Class Initialized
DEBUG - 2010-06-27 07:47:52 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-27 07:48:20 --> Config Class Initialized
DEBUG - 2010-06-27 07:48:20 --> Hooks Class Initialized
DEBUG - 2010-06-27 07:48:20 --> URI Class Initialized
DEBUG - 2010-06-27 07:48:20 --> No URI present. Default controller set.
DEBUG - 2010-06-27 07:48:20 --> Router Class Initialized
DEBUG - 2010-06-27 07:48:20 --> Output Class Initialized
DEBUG - 2010-06-27 07:48:20 --> Input Class Initialized
DEBUG - 2010-06-27 07:48:20 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 07:48:20 --> Language Class Initialized
DEBUG - 2010-06-27 07:48:20 --> Loader Class Initialized
DEBUG - 2010-06-27 07:48:20 --> Helper loaded: object_helper
DEBUG - 2010-06-27 07:48:20 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 07:48:20 --> Helper loaded: context_helper
DEBUG - 2010-06-27 07:48:20 --> Session Class Initialized
DEBUG - 2010-06-27 07:48:20 --> Helper loaded: string_helper
DEBUG - 2010-06-27 07:48:20 --> Session routines successfully run
DEBUG - 2010-06-27 07:48:20 --> Helper loaded: context_helper
DEBUG - 2010-06-27 07:48:21 --> Database Driver Class Initialized
DEBUG - 2010-06-27 07:48:21 --> Controller Class Initialized
DEBUG - 2010-06-27 07:48:21 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-27 07:48:21 --> Final output sent to browser
DEBUG - 2010-06-27 07:48:21 --> Total execution time: 0.2917
DEBUG - 2010-06-27 09:23:04 --> Config Class Initialized
DEBUG - 2010-06-27 09:23:04 --> Hooks Class Initialized
DEBUG - 2010-06-27 09:23:04 --> URI Class Initialized
DEBUG - 2010-06-27 09:23:04 --> No URI present. Default controller set.
DEBUG - 2010-06-27 09:23:04 --> Router Class Initialized
DEBUG - 2010-06-27 09:23:04 --> Output Class Initialized
DEBUG - 2010-06-27 09:23:04 --> Input Class Initialized
DEBUG - 2010-06-27 09:23:04 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 09:23:04 --> Language Class Initialized
DEBUG - 2010-06-27 09:23:14 --> Config Class Initialized
DEBUG - 2010-06-27 09:23:14 --> Hooks Class Initialized
DEBUG - 2010-06-27 09:23:14 --> URI Class Initialized
DEBUG - 2010-06-27 09:23:14 --> No URI present. Default controller set.
DEBUG - 2010-06-27 09:23:14 --> Router Class Initialized
DEBUG - 2010-06-27 09:23:14 --> Output Class Initialized
DEBUG - 2010-06-27 09:23:14 --> Input Class Initialized
DEBUG - 2010-06-27 09:23:14 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 09:23:14 --> Language Class Initialized
DEBUG - 2010-06-27 09:23:14 --> Loader Class Initialized
DEBUG - 2010-06-27 09:23:14 --> Helper loaded: object_helper
DEBUG - 2010-06-27 09:23:28 --> Config Class Initialized
DEBUG - 2010-06-27 09:23:28 --> Hooks Class Initialized
DEBUG - 2010-06-27 09:23:28 --> URI Class Initialized
DEBUG - 2010-06-27 09:23:28 --> No URI present. Default controller set.
DEBUG - 2010-06-27 09:23:28 --> Router Class Initialized
DEBUG - 2010-06-27 09:23:28 --> Output Class Initialized
DEBUG - 2010-06-27 09:23:28 --> Input Class Initialized
DEBUG - 2010-06-27 09:23:28 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 09:23:28 --> Language Class Initialized
DEBUG - 2010-06-27 11:03:14 --> Config Class Initialized
DEBUG - 2010-06-27 11:03:14 --> Hooks Class Initialized
DEBUG - 2010-06-27 11:03:14 --> URI Class Initialized
DEBUG - 2010-06-27 11:03:14 --> No URI present. Default controller set.
DEBUG - 2010-06-27 11:03:14 --> Router Class Initialized
DEBUG - 2010-06-27 11:03:14 --> Output Class Initialized
DEBUG - 2010-06-27 11:03:14 --> Input Class Initialized
DEBUG - 2010-06-27 11:03:14 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 11:03:14 --> Language Class Initialized
DEBUG - 2010-06-27 11:03:14 --> Loader Class Initialized
DEBUG - 2010-06-27 11:03:14 --> Helper loaded: object_helper
DEBUG - 2010-06-27 11:04:29 --> Config Class Initialized
DEBUG - 2010-06-27 11:04:29 --> Hooks Class Initialized
DEBUG - 2010-06-27 11:04:29 --> URI Class Initialized
DEBUG - 2010-06-27 11:04:29 --> No URI present. Default controller set.
DEBUG - 2010-06-27 11:04:29 --> Router Class Initialized
DEBUG - 2010-06-27 11:04:29 --> Output Class Initialized
DEBUG - 2010-06-27 11:04:29 --> Input Class Initialized
DEBUG - 2010-06-27 11:04:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 11:04:29 --> Language Class Initialized
DEBUG - 2010-06-27 11:04:29 --> Loader Class Initialized
DEBUG - 2010-06-27 11:04:29 --> Helper loaded: object_helper
DEBUG - 2010-06-27 12:55:19 --> Config Class Initialized
DEBUG - 2010-06-27 12:55:19 --> Hooks Class Initialized
DEBUG - 2010-06-27 12:55:19 --> URI Class Initialized
DEBUG - 2010-06-27 12:55:19 --> No URI present. Default controller set.
DEBUG - 2010-06-27 12:55:19 --> Router Class Initialized
DEBUG - 2010-06-27 12:55:19 --> Output Class Initialized
DEBUG - 2010-06-27 12:55:19 --> Input Class Initialized
DEBUG - 2010-06-27 12:55:19 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 12:55:19 --> Language Class Initialized
DEBUG - 2010-06-27 12:55:19 --> Loader Class Initialized
DEBUG - 2010-06-27 12:55:19 --> Helper loaded: object_helper
DEBUG - 2010-06-27 12:55:34 --> Config Class Initialized
DEBUG - 2010-06-27 12:55:34 --> Hooks Class Initialized
DEBUG - 2010-06-27 12:55:34 --> URI Class Initialized
DEBUG - 2010-06-27 12:55:34 --> No URI present. Default controller set.
DEBUG - 2010-06-27 12:55:34 --> Router Class Initialized
DEBUG - 2010-06-27 12:55:34 --> Output Class Initialized
DEBUG - 2010-06-27 12:55:34 --> Input Class Initialized
DEBUG - 2010-06-27 12:55:34 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 12:55:34 --> Language Class Initialized
DEBUG - 2010-06-27 12:55:34 --> Loader Class Initialized
DEBUG - 2010-06-27 12:55:34 --> Helper loaded: object_helper
DEBUG - 2010-06-27 12:55:39 --> Config Class Initialized
DEBUG - 2010-06-27 12:55:39 --> Hooks Class Initialized
DEBUG - 2010-06-27 12:55:39 --> URI Class Initialized
DEBUG - 2010-06-27 12:55:39 --> No URI present. Default controller set.
DEBUG - 2010-06-27 12:55:39 --> Router Class Initialized
DEBUG - 2010-06-27 12:55:39 --> Output Class Initialized
DEBUG - 2010-06-27 12:55:39 --> Input Class Initialized
DEBUG - 2010-06-27 12:55:39 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 12:55:39 --> Language Class Initialized
DEBUG - 2010-06-27 12:55:39 --> Loader Class Initialized
DEBUG - 2010-06-27 12:55:39 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 12:55:39 --> Helper loaded: context_helper
DEBUG - 2010-06-27 12:55:39 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 12:55:40 --> Database Driver Class Initialized
ERROR - 2010-06-27 12:55:40 --> Severity: Notice  --> Undefined property: Context::$CI D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 27
ERROR - 2010-06-27 12:55:40 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 27
DEBUG - 2010-06-27 12:55:53 --> Config Class Initialized
DEBUG - 2010-06-27 12:55:53 --> Hooks Class Initialized
DEBUG - 2010-06-27 12:55:53 --> URI Class Initialized
DEBUG - 2010-06-27 12:55:53 --> No URI present. Default controller set.
DEBUG - 2010-06-27 12:55:53 --> Router Class Initialized
DEBUG - 2010-06-27 12:55:53 --> Output Class Initialized
DEBUG - 2010-06-27 12:55:53 --> Input Class Initialized
DEBUG - 2010-06-27 12:55:53 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 12:55:53 --> Language Class Initialized
DEBUG - 2010-06-27 12:55:53 --> Loader Class Initialized
DEBUG - 2010-06-27 12:55:53 --> Controller Class Initialized
DEBUG - 2010-06-27 12:55:53 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-27 12:55:53 --> Final output sent to browser
DEBUG - 2010-06-27 12:55:53 --> Total execution time: 0.1970
DEBUG - 2010-06-27 12:56:06 --> Config Class Initialized
DEBUG - 2010-06-27 12:56:06 --> Hooks Class Initialized
DEBUG - 2010-06-27 12:56:06 --> URI Class Initialized
DEBUG - 2010-06-27 12:56:06 --> No URI present. Default controller set.
DEBUG - 2010-06-27 12:56:06 --> Router Class Initialized
DEBUG - 2010-06-27 12:56:06 --> Output Class Initialized
DEBUG - 2010-06-27 12:56:06 --> Input Class Initialized
DEBUG - 2010-06-27 12:56:06 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 12:56:06 --> Language Class Initialized
DEBUG - 2010-06-27 12:56:06 --> Loader Class Initialized
DEBUG - 2010-06-27 12:57:31 --> Config Class Initialized
DEBUG - 2010-06-27 12:57:31 --> Hooks Class Initialized
DEBUG - 2010-06-27 12:57:31 --> URI Class Initialized
DEBUG - 2010-06-27 12:57:31 --> No URI present. Default controller set.
DEBUG - 2010-06-27 12:57:31 --> Router Class Initialized
DEBUG - 2010-06-27 12:57:31 --> Output Class Initialized
DEBUG - 2010-06-27 12:57:31 --> Input Class Initialized
DEBUG - 2010-06-27 12:57:31 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 12:57:31 --> Language Class Initialized
DEBUG - 2010-06-27 12:57:31 --> Loader Class Initialized
DEBUG - 2010-06-27 12:57:31 --> Helper loaded: object_helper
DEBUG - 2010-06-27 12:57:31 --> Helper loaded: context_helper
DEBUG - 2010-06-27 12:57:31 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 12:57:31 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 12:57:31 --> Database Driver Class Initialized
DEBUG - 2010-06-27 12:57:31 --> Controller Class Initialized
DEBUG - 2010-06-27 12:57:31 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-27 12:57:31 --> Final output sent to browser
DEBUG - 2010-06-27 12:57:31 --> Total execution time: 0.2884
DEBUG - 2010-06-27 14:05:28 --> Config Class Initialized
DEBUG - 2010-06-27 14:05:28 --> Hooks Class Initialized
DEBUG - 2010-06-27 14:05:28 --> URI Class Initialized
DEBUG - 2010-06-27 14:05:28 --> No URI present. Default controller set.
DEBUG - 2010-06-27 14:05:28 --> Router Class Initialized
DEBUG - 2010-06-27 14:05:28 --> Output Class Initialized
DEBUG - 2010-06-27 14:05:28 --> Input Class Initialized
DEBUG - 2010-06-27 14:05:28 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 14:05:28 --> Language Class Initialized
DEBUG - 2010-06-27 14:05:28 --> Loader Class Initialized
DEBUG - 2010-06-27 14:05:28 --> Helper loaded: context_helper
DEBUG - 2010-06-27 14:05:28 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 14:05:28 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 14:05:28 --> Database Driver Class Initialized
DEBUG - 2010-06-27 14:05:28 --> Controller Class Initialized
DEBUG - 2010-06-27 14:05:28 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-27 14:05:39 --> Config Class Initialized
DEBUG - 2010-06-27 14:05:39 --> Hooks Class Initialized
DEBUG - 2010-06-27 14:05:39 --> URI Class Initialized
DEBUG - 2010-06-27 14:05:39 --> No URI present. Default controller set.
DEBUG - 2010-06-27 14:05:39 --> Router Class Initialized
DEBUG - 2010-06-27 14:05:39 --> Output Class Initialized
DEBUG - 2010-06-27 14:05:39 --> Input Class Initialized
DEBUG - 2010-06-27 14:05:39 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 14:05:39 --> Language Class Initialized
DEBUG - 2010-06-27 14:05:39 --> Loader Class Initialized
DEBUG - 2010-06-27 14:05:39 --> Helper loaded: context_helper
DEBUG - 2010-06-27 14:05:39 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 14:05:39 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 14:05:39 --> Database Driver Class Initialized
DEBUG - 2010-06-27 14:05:39 --> Controller Class Initialized
DEBUG - 2010-06-27 14:05:39 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-27 14:05:39 --> Controller Class Initialized
DEBUG - 2010-06-27 14:05:39 --> Final output sent to browser
DEBUG - 2010-06-27 14:05:39 --> Total execution time: 0.3034
DEBUG - 2010-06-27 14:51:15 --> Config Class Initialized
DEBUG - 2010-06-27 14:51:15 --> Hooks Class Initialized
DEBUG - 2010-06-27 14:51:15 --> URI Class Initialized
DEBUG - 2010-06-27 14:51:15 --> No URI present. Default controller set.
DEBUG - 2010-06-27 14:51:15 --> Router Class Initialized
DEBUG - 2010-06-27 14:51:15 --> Output Class Initialized
DEBUG - 2010-06-27 14:51:15 --> Input Class Initialized
DEBUG - 2010-06-27 14:51:15 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 14:51:15 --> Language Class Initialized
DEBUG - 2010-06-27 14:51:15 --> Loader Class Initialized
DEBUG - 2010-06-27 14:51:15 --> Helper loaded: context_helper
DEBUG - 2010-06-27 14:51:15 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 14:51:16 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 14:51:16 --> Database Driver Class Initialized
DEBUG - 2010-06-27 14:51:16 --> Controller Class Initialized
DEBUG - 2010-06-27 14:51:16 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-27 14:51:16 --> Final output sent to browser
DEBUG - 2010-06-27 14:51:16 --> Total execution time: 0.4620
DEBUG - 2010-06-27 15:00:59 --> Config Class Initialized
DEBUG - 2010-06-27 15:00:59 --> Hooks Class Initialized
DEBUG - 2010-06-27 15:00:59 --> URI Class Initialized
DEBUG - 2010-06-27 15:00:59 --> No URI present. Default controller set.
DEBUG - 2010-06-27 15:00:59 --> Router Class Initialized
DEBUG - 2010-06-27 15:00:59 --> Output Class Initialized
DEBUG - 2010-06-27 15:00:59 --> Input Class Initialized
DEBUG - 2010-06-27 15:00:59 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 15:00:59 --> Language Class Initialized
DEBUG - 2010-06-27 15:00:59 --> Loader Class Initialized
DEBUG - 2010-06-27 15:00:59 --> Helper loaded: context_helper
DEBUG - 2010-06-27 15:00:59 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 15:00:59 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 15:00:59 --> Database Driver Class Initialized
DEBUG - 2010-06-27 15:00:59 --> Controller Class Initialized
DEBUG - 2010-06-27 15:00:59 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-27 15:01:22 --> Config Class Initialized
DEBUG - 2010-06-27 15:01:22 --> Hooks Class Initialized
DEBUG - 2010-06-27 15:01:22 --> URI Class Initialized
DEBUG - 2010-06-27 15:01:22 --> No URI present. Default controller set.
DEBUG - 2010-06-27 15:01:22 --> Router Class Initialized
DEBUG - 2010-06-27 15:01:22 --> Output Class Initialized
DEBUG - 2010-06-27 15:01:22 --> Input Class Initialized
DEBUG - 2010-06-27 15:01:22 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 15:01:22 --> Language Class Initialized
DEBUG - 2010-06-27 15:01:22 --> Loader Class Initialized
DEBUG - 2010-06-27 15:01:22 --> Helper loaded: context_helper
DEBUG - 2010-06-27 15:01:22 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 15:01:22 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 15:01:22 --> Database Driver Class Initialized
DEBUG - 2010-06-27 15:01:22 --> Controller Class Initialized
DEBUG - 2010-06-27 15:01:22 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-27 15:01:22 --> Final output sent to browser
DEBUG - 2010-06-27 15:01:22 --> Total execution time: 0.3124
DEBUG - 2010-06-27 15:02:23 --> Config Class Initialized
DEBUG - 2010-06-27 15:02:23 --> Hooks Class Initialized
DEBUG - 2010-06-27 15:02:23 --> URI Class Initialized
DEBUG - 2010-06-27 15:02:23 --> No URI present. Default controller set.
DEBUG - 2010-06-27 15:02:23 --> Router Class Initialized
DEBUG - 2010-06-27 15:02:23 --> Output Class Initialized
DEBUG - 2010-06-27 15:02:23 --> Input Class Initialized
DEBUG - 2010-06-27 15:02:23 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 15:02:23 --> Language Class Initialized
DEBUG - 2010-06-27 15:02:23 --> Loader Class Initialized
DEBUG - 2010-06-27 15:02:23 --> Helper loaded: context_helper
DEBUG - 2010-06-27 15:02:23 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 15:02:23 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 15:02:23 --> Database Driver Class Initialized
DEBUG - 2010-06-27 15:02:23 --> Controller Class Initialized
DEBUG - 2010-06-27 15:02:23 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-27 15:02:23 --> Final output sent to browser
DEBUG - 2010-06-27 15:02:23 --> Total execution time: 0.3236
DEBUG - 2010-06-27 15:02:45 --> Config Class Initialized
DEBUG - 2010-06-27 15:02:45 --> Hooks Class Initialized
DEBUG - 2010-06-27 15:02:45 --> URI Class Initialized
DEBUG - 2010-06-27 15:02:45 --> No URI present. Default controller set.
DEBUG - 2010-06-27 15:02:45 --> Router Class Initialized
DEBUG - 2010-06-27 15:02:45 --> Output Class Initialized
DEBUG - 2010-06-27 15:02:45 --> Input Class Initialized
DEBUG - 2010-06-27 15:02:45 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 15:02:45 --> Language Class Initialized
DEBUG - 2010-06-27 15:02:45 --> Loader Class Initialized
DEBUG - 2010-06-27 15:02:45 --> Helper loaded: context_helper
DEBUG - 2010-06-27 15:02:45 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 15:02:45 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 15:02:45 --> Database Driver Class Initialized
DEBUG - 2010-06-27 15:02:45 --> Controller Class Initialized
DEBUG - 2010-06-27 15:02:45 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-27 15:02:45 --> Final output sent to browser
DEBUG - 2010-06-27 15:02:45 --> Total execution time: 0.3108
DEBUG - 2010-06-27 15:04:02 --> Config Class Initialized
DEBUG - 2010-06-27 15:04:02 --> Hooks Class Initialized
DEBUG - 2010-06-27 15:04:02 --> URI Class Initialized
DEBUG - 2010-06-27 15:04:02 --> No URI present. Default controller set.
DEBUG - 2010-06-27 15:04:02 --> Router Class Initialized
DEBUG - 2010-06-27 15:04:02 --> Output Class Initialized
DEBUG - 2010-06-27 15:04:02 --> Input Class Initialized
DEBUG - 2010-06-27 15:04:02 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 15:04:02 --> Language Class Initialized
DEBUG - 2010-06-27 15:04:02 --> Loader Class Initialized
DEBUG - 2010-06-27 15:04:02 --> Helper loaded: context_helper
DEBUG - 2010-06-27 15:04:02 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 15:04:02 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 15:04:02 --> Database Driver Class Initialized
DEBUG - 2010-06-27 15:04:02 --> Controller Class Initialized
DEBUG - 2010-06-27 15:04:02 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-27 15:08:21 --> Config Class Initialized
DEBUG - 2010-06-27 15:08:21 --> Hooks Class Initialized
DEBUG - 2010-06-27 15:08:21 --> URI Class Initialized
DEBUG - 2010-06-27 15:08:21 --> No URI present. Default controller set.
DEBUG - 2010-06-27 15:08:21 --> Router Class Initialized
DEBUG - 2010-06-27 15:08:21 --> Output Class Initialized
DEBUG - 2010-06-27 15:08:21 --> Input Class Initialized
DEBUG - 2010-06-27 15:08:21 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 15:08:21 --> Language Class Initialized
DEBUG - 2010-06-27 15:08:22 --> Loader Class Initialized
DEBUG - 2010-06-27 15:08:22 --> Helper loaded: context_helper
DEBUG - 2010-06-27 15:08:22 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 15:08:22 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 15:08:22 --> Database Driver Class Initialized
DEBUG - 2010-06-27 15:10:08 --> Config Class Initialized
DEBUG - 2010-06-27 15:10:09 --> Hooks Class Initialized
DEBUG - 2010-06-27 15:10:09 --> URI Class Initialized
DEBUG - 2010-06-27 15:10:09 --> No URI present. Default controller set.
DEBUG - 2010-06-27 15:10:09 --> Router Class Initialized
DEBUG - 2010-06-27 15:10:09 --> Output Class Initialized
DEBUG - 2010-06-27 15:10:09 --> Input Class Initialized
DEBUG - 2010-06-27 15:10:09 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 15:10:09 --> Language Class Initialized
DEBUG - 2010-06-27 15:10:09 --> Loader Class Initialized
DEBUG - 2010-06-27 15:10:09 --> Helper loaded: context_helper
DEBUG - 2010-06-27 15:10:09 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 15:10:09 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 15:10:09 --> Database Driver Class Initialized
DEBUG - 2010-06-27 15:10:09 --> Controller Class Initialized
DEBUG - 2010-06-27 15:10:09 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/welcome_message.php
DEBUG - 2010-06-27 15:10:09 --> Final output sent to browser
DEBUG - 2010-06-27 15:10:09 --> Total execution time: 0.3667
DEBUG - 2010-06-27 15:43:03 --> Config Class Initialized
DEBUG - 2010-06-27 15:43:03 --> Hooks Class Initialized
DEBUG - 2010-06-27 15:43:03 --> URI Class Initialized
DEBUG - 2010-06-27 15:43:03 --> Router Class Initialized
DEBUG - 2010-06-27 15:43:03 --> Output Class Initialized
DEBUG - 2010-06-27 15:43:03 --> Input Class Initialized
DEBUG - 2010-06-27 15:43:03 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 15:43:03 --> Language Class Initialized
DEBUG - 2010-06-27 15:43:03 --> Loader Class Initialized
DEBUG - 2010-06-27 15:43:03 --> Helper loaded: context_helper
DEBUG - 2010-06-27 15:43:03 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 15:43:03 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 15:43:03 --> Database Driver Class Initialized
DEBUG - 2010-06-27 15:43:03 --> Controller Class Initialized
DEBUG - 2010-06-27 15:43:03 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 15:43:03 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 15:43:26 --> Config Class Initialized
DEBUG - 2010-06-27 15:43:26 --> Hooks Class Initialized
DEBUG - 2010-06-27 15:43:26 --> URI Class Initialized
DEBUG - 2010-06-27 15:43:26 --> Router Class Initialized
DEBUG - 2010-06-27 15:43:26 --> Output Class Initialized
DEBUG - 2010-06-27 15:43:27 --> Input Class Initialized
DEBUG - 2010-06-27 15:43:27 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 15:43:27 --> Language Class Initialized
DEBUG - 2010-06-27 15:43:27 --> Loader Class Initialized
DEBUG - 2010-06-27 15:43:27 --> Helper loaded: context_helper
DEBUG - 2010-06-27 15:43:27 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 15:43:27 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 15:43:27 --> Database Driver Class Initialized
DEBUG - 2010-06-27 15:43:27 --> Controller Class Initialized
DEBUG - 2010-06-27 15:43:27 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 15:43:27 --> Helper loaded: unit_test_helper
ERROR - 2010-06-27 15:43:27 --> Severity: 4096  --> Argument 1 passed to Domain::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 43 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 52
ERROR - 2010-06-27 15:43:27 --> Severity: 4096  --> Argument 1 passed to Generic_object::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php on line 55 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-27 15:43:27 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 113
DEBUG - 2010-06-27 15:43:27 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-27 15:44:18 --> Config Class Initialized
DEBUG - 2010-06-27 15:44:18 --> Hooks Class Initialized
DEBUG - 2010-06-27 15:44:18 --> URI Class Initialized
DEBUG - 2010-06-27 15:44:18 --> Router Class Initialized
DEBUG - 2010-06-27 15:44:18 --> Output Class Initialized
DEBUG - 2010-06-27 15:44:18 --> Input Class Initialized
DEBUG - 2010-06-27 15:44:18 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 15:44:18 --> Language Class Initialized
DEBUG - 2010-06-27 15:44:18 --> Loader Class Initialized
DEBUG - 2010-06-27 15:44:18 --> Helper loaded: context_helper
DEBUG - 2010-06-27 15:44:18 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 15:44:18 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 15:44:18 --> Database Driver Class Initialized
DEBUG - 2010-06-27 15:44:18 --> Controller Class Initialized
DEBUG - 2010-06-27 15:44:18 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 15:44:18 --> Helper loaded: unit_test_helper
ERROR - 2010-06-27 15:44:19 --> Severity: 4096  --> Argument 1 passed to Domain::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 43 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 52
ERROR - 2010-06-27 15:44:19 --> Severity: 4096  --> Argument 1 passed to Generic_object::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php on line 55 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-27 15:44:19 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 113
DEBUG - 2010-06-27 15:44:19 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-27 15:44:19 --> Severity: 4096  --> Argument 1 passed to Domain::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 53 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 52
ERROR - 2010-06-27 15:44:19 --> Severity: 4096  --> Argument 1 passed to Generic_object::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php on line 55 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-27 15:44:19 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 113
DEBUG - 2010-06-27 15:44:42 --> Config Class Initialized
DEBUG - 2010-06-27 15:44:42 --> Hooks Class Initialized
DEBUG - 2010-06-27 15:44:42 --> URI Class Initialized
DEBUG - 2010-06-27 15:44:42 --> Router Class Initialized
DEBUG - 2010-06-27 15:44:43 --> Output Class Initialized
DEBUG - 2010-06-27 15:44:43 --> Input Class Initialized
DEBUG - 2010-06-27 15:44:43 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 15:44:43 --> Language Class Initialized
DEBUG - 2010-06-27 15:44:43 --> Loader Class Initialized
DEBUG - 2010-06-27 15:44:43 --> Helper loaded: context_helper
DEBUG - 2010-06-27 15:44:43 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 15:44:43 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 15:44:43 --> Database Driver Class Initialized
DEBUG - 2010-06-27 15:44:43 --> Controller Class Initialized
DEBUG - 2010-06-27 15:44:43 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 15:44:43 --> Helper loaded: unit_test_helper
ERROR - 2010-06-27 15:44:43 --> Severity: 4096  --> Argument 1 passed to Domain::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 43 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 52
ERROR - 2010-06-27 15:44:43 --> Severity: 4096  --> Argument 1 passed to Generic_object::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php on line 55 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-27 15:44:43 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 113
DEBUG - 2010-06-27 15:44:43 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-27 15:44:43 --> Severity: 4096  --> Argument 1 passed to Domain::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 53 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 52
ERROR - 2010-06-27 15:44:43 --> Severity: 4096  --> Argument 1 passed to Generic_object::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php on line 55 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-27 15:44:43 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 113
ERROR - 2010-06-27 15:44:43 --> Severity: 4096  --> Argument 1 passed to Domain::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 58 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 52
ERROR - 2010-06-27 15:44:43 --> Severity: 4096  --> Argument 1 passed to Generic_object::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php on line 55 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-27 15:44:43 --> Severity: Notice  --> Undefined index:  title D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 113
ERROR - 2010-06-27 15:44:43 --> Severity: 4096  --> Argument 1 passed to Domain::find() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 67 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 36
DEBUG - 2010-06-27 15:45:28 --> Config Class Initialized
DEBUG - 2010-06-27 15:45:28 --> Hooks Class Initialized
DEBUG - 2010-06-27 15:45:28 --> URI Class Initialized
DEBUG - 2010-06-27 15:45:28 --> Router Class Initialized
DEBUG - 2010-06-27 15:45:28 --> Output Class Initialized
DEBUG - 2010-06-27 15:45:28 --> Input Class Initialized
DEBUG - 2010-06-27 15:45:28 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 15:45:28 --> Language Class Initialized
DEBUG - 2010-06-27 15:45:28 --> Loader Class Initialized
DEBUG - 2010-06-27 15:45:28 --> Helper loaded: context_helper
DEBUG - 2010-06-27 15:45:28 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 15:45:28 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 15:45:28 --> Database Driver Class Initialized
DEBUG - 2010-06-27 15:45:29 --> Controller Class Initialized
DEBUG - 2010-06-27 15:45:29 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 15:45:29 --> Helper loaded: unit_test_helper
ERROR - 2010-06-27 15:45:29 --> Severity: 4096  --> Argument 1 passed to Domain::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 43 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 52
ERROR - 2010-06-27 15:45:29 --> Severity: 4096  --> Argument 1 passed to Generic_object::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php on line 55 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-27 15:45:29 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 113
DEBUG - 2010-06-27 15:45:29 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-27 15:45:29 --> Severity: 4096  --> Argument 1 passed to Domain::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 53 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 52
ERROR - 2010-06-27 15:45:29 --> Severity: 4096  --> Argument 1 passed to Generic_object::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php on line 55 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-27 15:45:29 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 113
ERROR - 2010-06-27 15:45:29 --> Severity: 4096  --> Argument 1 passed to Domain::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 58 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 52
ERROR - 2010-06-27 15:45:29 --> Severity: 4096  --> Argument 1 passed to Generic_object::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php on line 55 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-27 15:45:29 --> Severity: Notice  --> Undefined index:  title D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 113
ERROR - 2010-06-27 15:45:29 --> Severity: 4096  --> Argument 1 passed to Domain::find() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 67 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 36
ERROR - 2010-06-27 15:45:29 --> Severity: Notice  --> Undefined variable: CI D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 409
ERROR - 2010-06-27 15:45:29 --> Severity: Notice  --> Object of class Ut_domain could not be converted to int D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 409
ERROR - 2010-06-27 15:45:29 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 410
DEBUG - 2010-06-27 15:46:33 --> Config Class Initialized
DEBUG - 2010-06-27 15:46:33 --> Hooks Class Initialized
DEBUG - 2010-06-27 15:46:33 --> URI Class Initialized
DEBUG - 2010-06-27 15:46:33 --> Router Class Initialized
DEBUG - 2010-06-27 15:46:33 --> Output Class Initialized
DEBUG - 2010-06-27 15:46:33 --> Input Class Initialized
DEBUG - 2010-06-27 15:46:33 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 15:46:33 --> Language Class Initialized
DEBUG - 2010-06-27 15:46:33 --> Loader Class Initialized
DEBUG - 2010-06-27 15:46:33 --> Helper loaded: context_helper
DEBUG - 2010-06-27 15:46:33 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 15:46:33 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 15:46:33 --> Database Driver Class Initialized
DEBUG - 2010-06-27 15:46:33 --> Controller Class Initialized
DEBUG - 2010-06-27 15:46:33 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 15:46:33 --> Helper loaded: unit_test_helper
ERROR - 2010-06-27 15:46:33 --> Severity: 4096  --> Argument 1 passed to Domain::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 43 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 52
ERROR - 2010-06-27 15:46:33 --> Severity: 4096  --> Argument 1 passed to Generic_object::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php on line 55 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-27 15:46:33 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 113
DEBUG - 2010-06-27 15:46:33 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-27 15:46:33 --> Severity: 4096  --> Argument 1 passed to Domain::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 53 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 52
ERROR - 2010-06-27 15:46:33 --> Severity: 4096  --> Argument 1 passed to Generic_object::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php on line 55 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-27 15:46:33 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 113
ERROR - 2010-06-27 15:46:33 --> Severity: 4096  --> Argument 1 passed to Domain::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 58 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 52
ERROR - 2010-06-27 15:46:33 --> Severity: 4096  --> Argument 1 passed to Generic_object::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php on line 55 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-27 15:46:33 --> Severity: Notice  --> Undefined index:  title D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 113
ERROR - 2010-06-27 15:46:33 --> Severity: 4096  --> Argument 1 passed to Domain::find() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 67 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 36
ERROR - 2010-06-27 15:46:33 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\DB_active_rec.php 86
ERROR - 2010-06-27 15:46:33 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  SELECT * with no tables specified is not valid
LINE 1: SELECT *
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-27 15:46:33 --> DB Transaction Failure
ERROR - 2010-06-27 15:46:33 --> Query error: ERROR:  SELECT * with no tables specified is not valid
LINE 1: SELECT *
               ^
DEBUG - 2010-06-27 15:46:34 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-06-27 15:46:34 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-27 15:47:06 --> Config Class Initialized
DEBUG - 2010-06-27 15:47:06 --> Hooks Class Initialized
DEBUG - 2010-06-27 15:47:06 --> URI Class Initialized
DEBUG - 2010-06-27 15:47:06 --> Router Class Initialized
DEBUG - 2010-06-27 15:47:06 --> Output Class Initialized
DEBUG - 2010-06-27 15:47:06 --> Input Class Initialized
DEBUG - 2010-06-27 15:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 15:47:06 --> Language Class Initialized
DEBUG - 2010-06-27 15:47:06 --> Loader Class Initialized
DEBUG - 2010-06-27 15:47:06 --> Helper loaded: context_helper
DEBUG - 2010-06-27 15:47:06 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 15:47:06 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 15:47:06 --> Database Driver Class Initialized
DEBUG - 2010-06-27 15:47:06 --> Controller Class Initialized
DEBUG - 2010-06-27 15:47:06 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 15:47:06 --> Helper loaded: unit_test_helper
ERROR - 2010-06-27 15:47:06 --> Severity: 4096  --> Argument 1 passed to Domain::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 43 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 52
ERROR - 2010-06-27 15:47:06 --> Severity: 4096  --> Argument 1 passed to Generic_object::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php on line 55 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-27 15:47:06 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 113
DEBUG - 2010-06-27 15:47:06 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-27 15:47:06 --> Severity: 4096  --> Argument 1 passed to Domain::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 53 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 52
ERROR - 2010-06-27 15:47:06 --> Severity: 4096  --> Argument 1 passed to Generic_object::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php on line 55 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-27 15:47:06 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 113
ERROR - 2010-06-27 15:47:06 --> Severity: 4096  --> Argument 1 passed to Domain::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 58 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 52
ERROR - 2010-06-27 15:47:06 --> Severity: 4096  --> Argument 1 passed to Generic_object::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php on line 55 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-27 15:47:06 --> Severity: Notice  --> Undefined index:  title D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 113
ERROR - 2010-06-27 15:47:06 --> Severity: 4096  --> Argument 1 passed to Domain::find() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 67 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 36
ERROR - 2010-06-27 15:47:06 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\DB_active_rec.php 86
ERROR - 2010-06-27 15:47:07 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  SELECT * with no tables specified is not valid
LINE 1: SELECT *
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-27 15:47:07 --> DB Transaction Failure
ERROR - 2010-06-27 15:47:07 --> Query error: ERROR:  SELECT * with no tables specified is not valid
LINE 1: SELECT *
               ^
DEBUG - 2010-06-27 15:47:07 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-06-27 15:47:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-27 15:48:21 --> Config Class Initialized
DEBUG - 2010-06-27 15:48:21 --> Hooks Class Initialized
DEBUG - 2010-06-27 15:48:21 --> URI Class Initialized
DEBUG - 2010-06-27 15:48:21 --> Router Class Initialized
DEBUG - 2010-06-27 15:48:21 --> Output Class Initialized
DEBUG - 2010-06-27 15:48:21 --> Input Class Initialized
DEBUG - 2010-06-27 15:48:21 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 15:48:21 --> Language Class Initialized
DEBUG - 2010-06-27 15:48:21 --> Loader Class Initialized
DEBUG - 2010-06-27 15:48:21 --> Helper loaded: context_helper
DEBUG - 2010-06-27 15:48:21 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 15:48:21 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 15:48:21 --> Database Driver Class Initialized
DEBUG - 2010-06-27 15:48:21 --> Controller Class Initialized
DEBUG - 2010-06-27 15:48:21 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 15:48:21 --> Helper loaded: unit_test_helper
ERROR - 2010-06-27 15:48:21 --> Severity: 4096  --> Argument 1 passed to Domain::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 43 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 52
ERROR - 2010-06-27 15:48:21 --> Severity: 4096  --> Argument 1 passed to Generic_object::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php on line 55 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-27 15:48:21 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 113
DEBUG - 2010-06-27 15:48:21 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-27 15:48:21 --> Severity: 4096  --> Argument 1 passed to Domain::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 53 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 52
ERROR - 2010-06-27 15:48:21 --> Severity: 4096  --> Argument 1 passed to Generic_object::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php on line 55 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-27 15:48:21 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 113
ERROR - 2010-06-27 15:48:21 --> Severity: 4096  --> Argument 1 passed to Domain::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 58 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 52
ERROR - 2010-06-27 15:48:21 --> Severity: 4096  --> Argument 1 passed to Generic_object::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php on line 55 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-27 15:48:21 --> Severity: Notice  --> Undefined index:  title D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 113
ERROR - 2010-06-27 15:48:21 --> Severity: 4096  --> Argument 1 passed to Domain::find() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 67 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 36
ERROR - 2010-06-27 15:48:21 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\DB_active_rec.php 86
ERROR - 2010-06-27 15:48:22 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  SELECT * with no tables specified is not valid
LINE 1: SELECT *
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-27 15:48:22 --> DB Transaction Failure
ERROR - 2010-06-27 15:48:22 --> Query error: ERROR:  SELECT * with no tables specified is not valid
LINE 1: SELECT *
               ^
DEBUG - 2010-06-27 15:48:22 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-06-27 15:48:22 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-27 15:49:40 --> Config Class Initialized
DEBUG - 2010-06-27 15:49:40 --> Hooks Class Initialized
DEBUG - 2010-06-27 15:49:40 --> URI Class Initialized
DEBUG - 2010-06-27 15:49:40 --> Router Class Initialized
DEBUG - 2010-06-27 15:49:40 --> Output Class Initialized
DEBUG - 2010-06-27 15:49:40 --> Input Class Initialized
DEBUG - 2010-06-27 15:49:40 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 15:49:40 --> Language Class Initialized
DEBUG - 2010-06-27 15:49:40 --> Loader Class Initialized
DEBUG - 2010-06-27 15:49:40 --> Helper loaded: context_helper
DEBUG - 2010-06-27 15:49:40 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 15:49:40 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 15:49:40 --> Database Driver Class Initialized
DEBUG - 2010-06-27 15:49:40 --> Controller Class Initialized
DEBUG - 2010-06-27 15:49:40 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 15:49:40 --> Helper loaded: unit_test_helper
ERROR - 2010-06-27 15:49:40 --> Severity: 4096  --> Argument 1 passed to Domain::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 43 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 52
ERROR - 2010-06-27 15:49:40 --> Severity: 4096  --> Argument 1 passed to Generic_object::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php on line 55 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-27 15:49:40 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 113
DEBUG - 2010-06-27 15:49:40 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-27 15:49:40 --> Severity: 4096  --> Argument 1 passed to Domain::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 53 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 52
ERROR - 2010-06-27 15:49:40 --> Severity: 4096  --> Argument 1 passed to Generic_object::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php on line 55 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-27 15:49:40 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 113
ERROR - 2010-06-27 15:49:40 --> Severity: 4096  --> Argument 1 passed to Domain::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 58 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 52
ERROR - 2010-06-27 15:49:40 --> Severity: 4096  --> Argument 1 passed to Generic_object::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php on line 55 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-27 15:49:40 --> Severity: Notice  --> Undefined index:  title D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 113
ERROR - 2010-06-27 15:49:40 --> Severity: 4096  --> Argument 1 passed to Domain::find() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 67 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 36
ERROR - 2010-06-27 15:49:40 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\DB_active_rec.php 86
ERROR - 2010-06-27 15:49:41 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  SELECT * with no tables specified is not valid
LINE 1: SELECT *
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-27 15:49:41 --> DB Transaction Failure
ERROR - 2010-06-27 15:49:41 --> Query error: ERROR:  SELECT * with no tables specified is not valid
LINE 1: SELECT *
               ^
DEBUG - 2010-06-27 15:49:41 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-06-27 15:49:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-27 15:49:59 --> Config Class Initialized
DEBUG - 2010-06-27 15:49:59 --> Hooks Class Initialized
DEBUG - 2010-06-27 15:49:59 --> URI Class Initialized
DEBUG - 2010-06-27 15:50:00 --> Router Class Initialized
DEBUG - 2010-06-27 15:50:00 --> Output Class Initialized
DEBUG - 2010-06-27 15:50:00 --> Input Class Initialized
DEBUG - 2010-06-27 15:50:00 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 15:50:00 --> Language Class Initialized
DEBUG - 2010-06-27 15:50:00 --> Loader Class Initialized
DEBUG - 2010-06-27 15:50:00 --> Helper loaded: context_helper
DEBUG - 2010-06-27 15:50:00 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 15:50:00 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 15:50:00 --> Database Driver Class Initialized
DEBUG - 2010-06-27 15:50:00 --> Controller Class Initialized
DEBUG - 2010-06-27 15:50:00 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 15:50:00 --> Helper loaded: unit_test_helper
ERROR - 2010-06-27 15:50:00 --> Severity: 4096  --> Argument 1 passed to Domain::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 43 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 52
ERROR - 2010-06-27 15:50:00 --> Severity: 4096  --> Argument 1 passed to Generic_object::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php on line 55 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-27 15:50:00 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 113
DEBUG - 2010-06-27 15:50:00 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-27 15:50:00 --> Severity: 4096  --> Argument 1 passed to Domain::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 53 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 52
ERROR - 2010-06-27 15:50:00 --> Severity: 4096  --> Argument 1 passed to Generic_object::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php on line 55 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-27 15:50:00 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 113
ERROR - 2010-06-27 15:50:00 --> Severity: 4096  --> Argument 1 passed to Domain::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 58 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 52
ERROR - 2010-06-27 15:50:00 --> Severity: 4096  --> Argument 1 passed to Generic_object::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php on line 55 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-27 15:50:00 --> Severity: Notice  --> Undefined index:  title D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 113
ERROR - 2010-06-27 15:50:00 --> Severity: 4096  --> Argument 1 passed to Domain::find() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 67 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 36
ERROR - 2010-06-27 15:50:00 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\DB_active_rec.php 86
ERROR - 2010-06-27 15:50:00 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  SELECT * with no tables specified is not valid
LINE 1: SELECT *
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-27 15:50:00 --> DB Transaction Failure
ERROR - 2010-06-27 15:50:00 --> Query error: ERROR:  SELECT * with no tables specified is not valid
LINE 1: SELECT *
               ^
DEBUG - 2010-06-27 15:50:00 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-06-27 15:50:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-27 15:50:26 --> Config Class Initialized
DEBUG - 2010-06-27 15:50:26 --> Hooks Class Initialized
DEBUG - 2010-06-27 15:50:26 --> URI Class Initialized
DEBUG - 2010-06-27 15:50:26 --> Router Class Initialized
DEBUG - 2010-06-27 15:50:26 --> Output Class Initialized
DEBUG - 2010-06-27 15:50:26 --> Input Class Initialized
DEBUG - 2010-06-27 15:50:26 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 15:50:26 --> Language Class Initialized
DEBUG - 2010-06-27 15:50:26 --> Loader Class Initialized
DEBUG - 2010-06-27 15:50:26 --> Helper loaded: context_helper
DEBUG - 2010-06-27 15:50:26 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 15:50:26 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 15:50:26 --> Database Driver Class Initialized
DEBUG - 2010-06-27 15:50:26 --> Controller Class Initialized
DEBUG - 2010-06-27 15:50:26 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 15:50:26 --> Helper loaded: unit_test_helper
ERROR - 2010-06-27 15:50:26 --> Severity: 4096  --> Argument 1 passed to Domain::get_field() must be an instance of string, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 43 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 52
ERROR - 2010-06-27 15:50:26 --> Severity: 4096  --> Argument 1 passed to Generic_object::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php on line 55 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-27 15:50:26 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 113
DEBUG - 2010-06-27 15:50:26 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-27 15:50:26 --> Severity: 4096  --> Argument 1 passed to Domain::get_field() must be an instance of string, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 53 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 52
ERROR - 2010-06-27 15:50:26 --> Severity: 4096  --> Argument 1 passed to Generic_object::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php on line 55 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-27 15:50:27 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 113
ERROR - 2010-06-27 15:50:27 --> Severity: 4096  --> Argument 1 passed to Domain::get_field() must be an instance of string, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 58 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 52
ERROR - 2010-06-27 15:50:27 --> Severity: 4096  --> Argument 1 passed to Generic_object::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php on line 55 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-27 15:50:27 --> Severity: Notice  --> Undefined index:  title D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 113
ERROR - 2010-06-27 15:50:27 --> Severity: 4096  --> Argument 1 passed to Domain::find() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 67 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 36
ERROR - 2010-06-27 15:50:27 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\DB_active_rec.php 86
ERROR - 2010-06-27 15:50:27 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  SELECT * with no tables specified is not valid
LINE 1: SELECT *
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-27 15:50:27 --> DB Transaction Failure
ERROR - 2010-06-27 15:50:27 --> Query error: ERROR:  SELECT * with no tables specified is not valid
LINE 1: SELECT *
               ^
DEBUG - 2010-06-27 15:50:27 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-06-27 15:50:27 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-27 15:50:34 --> Config Class Initialized
DEBUG - 2010-06-27 15:50:34 --> Hooks Class Initialized
DEBUG - 2010-06-27 15:50:34 --> URI Class Initialized
DEBUG - 2010-06-27 15:50:34 --> Router Class Initialized
DEBUG - 2010-06-27 15:50:34 --> Output Class Initialized
DEBUG - 2010-06-27 15:50:34 --> Input Class Initialized
DEBUG - 2010-06-27 15:50:34 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 15:50:34 --> Language Class Initialized
DEBUG - 2010-06-27 15:50:34 --> Loader Class Initialized
DEBUG - 2010-06-27 15:50:34 --> Helper loaded: context_helper
DEBUG - 2010-06-27 15:50:34 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 15:50:34 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 15:50:34 --> Database Driver Class Initialized
DEBUG - 2010-06-27 15:50:34 --> Controller Class Initialized
DEBUG - 2010-06-27 15:50:34 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 15:50:34 --> Helper loaded: unit_test_helper
ERROR - 2010-06-27 15:50:34 --> Severity: 4096  --> Argument 1 passed to Generic_object::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php on line 55 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-27 15:50:34 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 113
DEBUG - 2010-06-27 15:50:34 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-27 15:50:34 --> Severity: 4096  --> Argument 1 passed to Generic_object::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php on line 55 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-27 15:50:34 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 113
ERROR - 2010-06-27 15:50:34 --> Severity: 4096  --> Argument 1 passed to Generic_object::get_field() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php on line 55 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 105
ERROR - 2010-06-27 15:50:34 --> Severity: Notice  --> Undefined index:  title D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 113
ERROR - 2010-06-27 15:50:34 --> Severity: 4096  --> Argument 1 passed to Domain::find() must be an instance of String, string given, called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_kals_resource\ut_domain.php on line 67 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 36
ERROR - 2010-06-27 15:50:34 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\DB_active_rec.php 86
ERROR - 2010-06-27 15:50:34 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  SELECT * with no tables specified is not valid
LINE 1: SELECT *
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-27 15:50:35 --> DB Transaction Failure
ERROR - 2010-06-27 15:50:35 --> Query error: ERROR:  SELECT * with no tables specified is not valid
LINE 1: SELECT *
               ^
DEBUG - 2010-06-27 15:50:35 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-06-27 15:50:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-27 15:51:25 --> Config Class Initialized
DEBUG - 2010-06-27 15:51:26 --> Hooks Class Initialized
DEBUG - 2010-06-27 15:51:26 --> URI Class Initialized
DEBUG - 2010-06-27 15:51:26 --> Router Class Initialized
DEBUG - 2010-06-27 15:51:26 --> Output Class Initialized
DEBUG - 2010-06-27 15:51:26 --> Input Class Initialized
DEBUG - 2010-06-27 15:51:26 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 15:51:26 --> Language Class Initialized
DEBUG - 2010-06-27 15:51:26 --> Loader Class Initialized
DEBUG - 2010-06-27 15:51:26 --> Helper loaded: context_helper
DEBUG - 2010-06-27 15:51:26 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 15:51:26 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 15:51:26 --> Database Driver Class Initialized
DEBUG - 2010-06-27 15:51:26 --> Controller Class Initialized
DEBUG - 2010-06-27 15:51:26 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 15:51:26 --> Helper loaded: unit_test_helper
ERROR - 2010-06-27 15:51:26 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 113
DEBUG - 2010-06-27 15:51:26 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-27 15:51:26 --> Severity: Notice  --> Undefined index:  host D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 113
ERROR - 2010-06-27 15:51:26 --> Severity: Notice  --> Undefined index:  title D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 113
ERROR - 2010-06-27 15:51:26 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\DB_active_rec.php 86
ERROR - 2010-06-27 15:51:26 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  SELECT * with no tables specified is not valid
LINE 1: SELECT *
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-27 15:51:26 --> DB Transaction Failure
ERROR - 2010-06-27 15:51:26 --> Query error: ERROR:  SELECT * with no tables specified is not valid
LINE 1: SELECT *
               ^
DEBUG - 2010-06-27 15:51:26 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-06-27 15:51:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-27 15:57:29 --> Config Class Initialized
DEBUG - 2010-06-27 15:57:29 --> Hooks Class Initialized
DEBUG - 2010-06-27 15:57:29 --> URI Class Initialized
DEBUG - 2010-06-27 15:57:29 --> Router Class Initialized
DEBUG - 2010-06-27 15:57:29 --> Output Class Initialized
DEBUG - 2010-06-27 15:57:29 --> Input Class Initialized
DEBUG - 2010-06-27 15:57:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 15:57:29 --> Language Class Initialized
DEBUG - 2010-06-27 15:57:30 --> Loader Class Initialized
DEBUG - 2010-06-27 15:57:30 --> Helper loaded: context_helper
DEBUG - 2010-06-27 15:57:30 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 15:57:30 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 15:57:30 --> Database Driver Class Initialized
DEBUG - 2010-06-27 15:57:30 --> Controller Class Initialized
DEBUG - 2010-06-27 15:57:30 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 15:57:30 --> Helper loaded: unit_test_helper
ERROR - 2010-06-27 15:57:30 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:30 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:30 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:30 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:30 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:30 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:30 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:30 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:30 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:30 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:30 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:30 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:30 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:30 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:30 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:30 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:30 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:30 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:30 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:30 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:30 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:30 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:31 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:31 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:31 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:31 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:31 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:31 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:31 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:31 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:31 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:31 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:31 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:31 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:31 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:31 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:31 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:31 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:31 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:31 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:31 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:31 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:31 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:31 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:31 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:31 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:31 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:31 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:31 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:31 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:31 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:31 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:31 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:32 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:32 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:32 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:32 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:32 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:32 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:32 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:32 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:32 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:32 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:32 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:32 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:32 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:32 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:32 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:32 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:32 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:32 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:32 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:32 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:32 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:32 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:32 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:32 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:32 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:32 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:32 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:32 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:32 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:32 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:32 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:33 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:33 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:33 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:33 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:33 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:33 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:33 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:33 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:33 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:33 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:33 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:33 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:33 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:33 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:33 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:33 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:33 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:33 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:33 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:33 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:33 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:33 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:33 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:33 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:33 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:33 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:33 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:33 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:33 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:33 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:34 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:34 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:34 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:34 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:34 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:34 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:34 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:34 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:34 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:34 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:34 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:34 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:34 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:34 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:34 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:34 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:34 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:34 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:34 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:34 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:34 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:34 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:34 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:34 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:34 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:34 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:34 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:35 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:35 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:35 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:35 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:35 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:35 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:35 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:35 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:35 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:35 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:35 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:35 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:35 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:35 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:35 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:35 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:35 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:35 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:35 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:35 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:35 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:35 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:35 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:35 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:35 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:35 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:35 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:35 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:36 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:36 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:36 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:36 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:36 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:36 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:36 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:36 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:36 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:36 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:36 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:36 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:36 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:36 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:36 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:36 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:36 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:36 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:36 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:36 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:36 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:36 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:36 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:36 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:36 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:36 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:36 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:37 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:37 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:37 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:37 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:37 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:37 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:37 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:37 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:37 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:37 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:37 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:37 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:37 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:37 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:37 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:37 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:37 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:37 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:37 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:37 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:37 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:37 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:37 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:37 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:37 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:37 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:38 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:38 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:38 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:38 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:38 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:38 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:38 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:38 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:38 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:38 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:38 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:38 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:38 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:38 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:38 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:38 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:38 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:38 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:38 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:38 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:38 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:38 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:38 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:38 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:38 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:39 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:39 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:39 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:39 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:39 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:39 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:39 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:39 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:39 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:39 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:39 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:39 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:39 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:39 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:39 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:39 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:39 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:39 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:39 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:39 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:39 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:39 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:39 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:39 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:39 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:40 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:40 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:40 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:40 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:40 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:40 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:40 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:40 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:40 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:40 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:40 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:40 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:40 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:40 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:40 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:40 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:40 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:40 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:40 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:40 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:40 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:40 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:40 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:40 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:40 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:41 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:41 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:41 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:41 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:41 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:41 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:41 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:41 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:41 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:41 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:41 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:41 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:41 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:41 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:41 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:41 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:41 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:41 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:41 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:41 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:41 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:41 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:41 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:42 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:42 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:42 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:42 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:42 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:42 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:42 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:42 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:42 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:42 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:42 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:42 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:42 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:42 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:42 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:42 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:42 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:42 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:42 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:42 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:42 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:43 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:43 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:43 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:43 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:43 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:43 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:43 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:43 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:43 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
DEBUG - 2010-06-27 15:57:43 --> Config Class Initialized
ERROR - 2010-06-27 15:57:43 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
DEBUG - 2010-06-27 15:57:43 --> Hooks Class Initialized
ERROR - 2010-06-27 15:57:43 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
DEBUG - 2010-06-27 15:57:43 --> URI Class Initialized
ERROR - 2010-06-27 15:57:43 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
DEBUG - 2010-06-27 15:57:43 --> Router Class Initialized
ERROR - 2010-06-27 15:57:43 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
DEBUG - 2010-06-27 15:57:43 --> Output Class Initialized
ERROR - 2010-06-27 15:57:43 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
DEBUG - 2010-06-27 15:57:43 --> Input Class Initialized
ERROR - 2010-06-27 15:57:43 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
DEBUG - 2010-06-27 15:57:43 --> Global POST and COOKIE data sanitized
ERROR - 2010-06-27 15:57:43 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:43 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
DEBUG - 2010-06-27 15:57:43 --> Language Class Initialized
ERROR - 2010-06-27 15:57:43 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
DEBUG - 2010-06-27 15:57:43 --> Loader Class Initialized
ERROR - 2010-06-27 15:57:43 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
DEBUG - 2010-06-27 15:57:43 --> Helper loaded: context_helper
ERROR - 2010-06-27 15:57:43 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
DEBUG - 2010-06-27 15:57:43 --> Helper loaded: kals_helper
ERROR - 2010-06-27 15:57:43 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
DEBUG - 2010-06-27 15:57:43 --> Language file loaded: language/zh_tw/kals_lang.php
ERROR - 2010-06-27 15:57:43 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:44 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
DEBUG - 2010-06-27 15:57:44 --> Database Driver Class Initialized
ERROR - 2010-06-27 15:57:44 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:44 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
DEBUG - 2010-06-27 15:57:44 --> Controller Class Initialized
ERROR - 2010-06-27 15:57:44 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:44 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
DEBUG - 2010-06-27 15:57:44 --> Unit Testing Class Initialized
ERROR - 2010-06-27 15:57:44 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
DEBUG - 2010-06-27 15:57:44 --> Helper loaded: unit_test_helper
ERROR - 2010-06-27 15:57:44 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:44 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:44 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:44 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:44 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:44 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:44 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:44 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:44 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:44 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:44 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:44 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:44 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
ERROR - 2010-06-27 15:57:44 --> Severity: Notice  --> Undefined variable: id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 38
DEBUG - 2010-06-27 15:58:14 --> Config Class Initialized
DEBUG - 2010-06-27 15:58:14 --> Hooks Class Initialized
DEBUG - 2010-06-27 15:58:14 --> URI Class Initialized
DEBUG - 2010-06-27 15:58:14 --> Router Class Initialized
DEBUG - 2010-06-27 15:58:14 --> Output Class Initialized
DEBUG - 2010-06-27 15:58:14 --> Input Class Initialized
DEBUG - 2010-06-27 15:58:14 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 15:58:14 --> Language Class Initialized
DEBUG - 2010-06-27 15:58:14 --> Loader Class Initialized
DEBUG - 2010-06-27 15:58:14 --> Helper loaded: context_helper
DEBUG - 2010-06-27 15:58:14 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 15:58:14 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 15:58:15 --> Database Driver Class Initialized
DEBUG - 2010-06-27 15:58:15 --> Controller Class Initialized
DEBUG - 2010-06-27 15:58:15 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 15:58:15 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 15:59:08 --> Config Class Initialized
DEBUG - 2010-06-27 15:59:08 --> Hooks Class Initialized
DEBUG - 2010-06-27 15:59:08 --> URI Class Initialized
DEBUG - 2010-06-27 15:59:08 --> Router Class Initialized
DEBUG - 2010-06-27 15:59:08 --> Output Class Initialized
DEBUG - 2010-06-27 15:59:08 --> Input Class Initialized
DEBUG - 2010-06-27 15:59:08 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 15:59:08 --> Language Class Initialized
DEBUG - 2010-06-27 15:59:08 --> Loader Class Initialized
DEBUG - 2010-06-27 15:59:08 --> Helper loaded: context_helper
DEBUG - 2010-06-27 15:59:08 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 15:59:08 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 15:59:09 --> Database Driver Class Initialized
DEBUG - 2010-06-27 15:59:09 --> Controller Class Initialized
DEBUG - 2010-06-27 15:59:09 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 15:59:09 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 15:59:09 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-27 15:59:09 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-27 15:59:09 --> Final output sent to browser
DEBUG - 2010-06-27 15:59:09 --> Total execution time: 0.9829
DEBUG - 2010-06-27 15:59:23 --> Config Class Initialized
DEBUG - 2010-06-27 15:59:23 --> Hooks Class Initialized
DEBUG - 2010-06-27 15:59:23 --> URI Class Initialized
DEBUG - 2010-06-27 15:59:23 --> Router Class Initialized
DEBUG - 2010-06-27 15:59:23 --> Output Class Initialized
DEBUG - 2010-06-27 15:59:24 --> Input Class Initialized
DEBUG - 2010-06-27 15:59:24 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 15:59:24 --> Language Class Initialized
DEBUG - 2010-06-27 15:59:37 --> Config Class Initialized
DEBUG - 2010-06-27 15:59:37 --> Hooks Class Initialized
DEBUG - 2010-06-27 15:59:37 --> URI Class Initialized
DEBUG - 2010-06-27 15:59:37 --> Router Class Initialized
DEBUG - 2010-06-27 15:59:37 --> Output Class Initialized
DEBUG - 2010-06-27 15:59:37 --> Input Class Initialized
DEBUG - 2010-06-27 15:59:37 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 15:59:37 --> Language Class Initialized
DEBUG - 2010-06-27 15:59:37 --> Loader Class Initialized
DEBUG - 2010-06-27 15:59:37 --> Helper loaded: context_helper
DEBUG - 2010-06-27 15:59:37 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 15:59:37 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 15:59:37 --> Database Driver Class Initialized
DEBUG - 2010-06-27 15:59:38 --> Controller Class Initialized
DEBUG - 2010-06-27 15:59:38 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 15:59:38 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 16:00:59 --> Config Class Initialized
DEBUG - 2010-06-27 16:00:59 --> Hooks Class Initialized
DEBUG - 2010-06-27 16:01:00 --> URI Class Initialized
DEBUG - 2010-06-27 16:01:00 --> Router Class Initialized
DEBUG - 2010-06-27 16:01:00 --> Output Class Initialized
DEBUG - 2010-06-27 16:01:00 --> Input Class Initialized
DEBUG - 2010-06-27 16:01:00 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 16:01:00 --> Language Class Initialized
DEBUG - 2010-06-27 16:01:00 --> Loader Class Initialized
DEBUG - 2010-06-27 16:01:00 --> Helper loaded: context_helper
DEBUG - 2010-06-27 16:01:00 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 16:01:00 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 16:01:00 --> Database Driver Class Initialized
DEBUG - 2010-06-27 16:01:00 --> Controller Class Initialized
DEBUG - 2010-06-27 16:01:00 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 16:01:00 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 16:01:40 --> Config Class Initialized
DEBUG - 2010-06-27 16:01:40 --> Hooks Class Initialized
DEBUG - 2010-06-27 16:01:40 --> URI Class Initialized
DEBUG - 2010-06-27 16:01:40 --> Router Class Initialized
DEBUG - 2010-06-27 16:01:40 --> Output Class Initialized
DEBUG - 2010-06-27 16:01:40 --> Input Class Initialized
DEBUG - 2010-06-27 16:01:41 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 16:01:41 --> Language Class Initialized
DEBUG - 2010-06-27 16:01:41 --> Loader Class Initialized
DEBUG - 2010-06-27 16:01:41 --> Helper loaded: context_helper
DEBUG - 2010-06-27 16:01:41 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 16:01:41 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 16:01:41 --> Database Driver Class Initialized
DEBUG - 2010-06-27 16:01:41 --> Controller Class Initialized
DEBUG - 2010-06-27 16:01:41 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 16:01:41 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 16:01:41 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-27 16:01:41 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-27 16:01:41 --> Final output sent to browser
DEBUG - 2010-06-27 16:01:41 --> Total execution time: 0.9593
DEBUG - 2010-06-27 16:02:09 --> Config Class Initialized
DEBUG - 2010-06-27 16:02:09 --> Hooks Class Initialized
DEBUG - 2010-06-27 16:02:09 --> URI Class Initialized
DEBUG - 2010-06-27 16:02:09 --> Router Class Initialized
DEBUG - 2010-06-27 16:02:09 --> Output Class Initialized
DEBUG - 2010-06-27 16:02:09 --> Input Class Initialized
DEBUG - 2010-06-27 16:02:09 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 16:02:09 --> Language Class Initialized
DEBUG - 2010-06-27 16:02:09 --> Loader Class Initialized
DEBUG - 2010-06-27 16:02:10 --> Helper loaded: context_helper
DEBUG - 2010-06-27 16:02:10 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 16:02:10 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 16:02:10 --> Database Driver Class Initialized
DEBUG - 2010-06-27 16:02:10 --> Controller Class Initialized
DEBUG - 2010-06-27 16:02:10 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 16:02:10 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 16:02:10 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-27 16:02:10 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-27 16:02:10 --> Final output sent to browser
DEBUG - 2010-06-27 16:02:10 --> Total execution time: 0.9587
DEBUG - 2010-06-27 16:03:02 --> Config Class Initialized
DEBUG - 2010-06-27 16:03:02 --> Hooks Class Initialized
DEBUG - 2010-06-27 16:03:02 --> URI Class Initialized
DEBUG - 2010-06-27 16:03:02 --> Router Class Initialized
DEBUG - 2010-06-27 16:03:02 --> Output Class Initialized
DEBUG - 2010-06-27 16:03:02 --> Input Class Initialized
DEBUG - 2010-06-27 16:03:02 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 16:03:02 --> Language Class Initialized
DEBUG - 2010-06-27 16:03:02 --> Loader Class Initialized
DEBUG - 2010-06-27 16:03:02 --> Helper loaded: context_helper
DEBUG - 2010-06-27 16:03:02 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 16:03:02 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 16:03:02 --> Database Driver Class Initialized
DEBUG - 2010-06-27 16:03:02 --> Controller Class Initialized
DEBUG - 2010-06-27 16:03:02 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 16:03:02 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 16:03:45 --> Config Class Initialized
DEBUG - 2010-06-27 16:03:45 --> Hooks Class Initialized
DEBUG - 2010-06-27 16:03:45 --> URI Class Initialized
DEBUG - 2010-06-27 16:03:45 --> Router Class Initialized
DEBUG - 2010-06-27 16:03:45 --> Output Class Initialized
DEBUG - 2010-06-27 16:03:45 --> Input Class Initialized
DEBUG - 2010-06-27 16:03:45 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 16:03:45 --> Language Class Initialized
DEBUG - 2010-06-27 16:03:45 --> Loader Class Initialized
DEBUG - 2010-06-27 16:03:45 --> Helper loaded: context_helper
DEBUG - 2010-06-27 16:03:45 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 16:03:45 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 16:03:46 --> Database Driver Class Initialized
DEBUG - 2010-06-27 16:03:46 --> Controller Class Initialized
DEBUG - 2010-06-27 16:03:46 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 16:03:46 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 16:04:06 --> Config Class Initialized
DEBUG - 2010-06-27 16:04:06 --> Hooks Class Initialized
DEBUG - 2010-06-27 16:04:06 --> URI Class Initialized
DEBUG - 2010-06-27 16:04:06 --> Router Class Initialized
DEBUG - 2010-06-27 16:04:07 --> Output Class Initialized
DEBUG - 2010-06-27 16:04:07 --> Input Class Initialized
DEBUG - 2010-06-27 16:04:07 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 16:04:07 --> Language Class Initialized
DEBUG - 2010-06-27 16:04:07 --> Loader Class Initialized
DEBUG - 2010-06-27 16:04:07 --> Helper loaded: context_helper
DEBUG - 2010-06-27 16:04:07 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 16:04:07 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 16:04:07 --> Database Driver Class Initialized
DEBUG - 2010-06-27 16:04:07 --> Controller Class Initialized
DEBUG - 2010-06-27 16:04:07 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 16:04:07 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 16:04:43 --> Config Class Initialized
DEBUG - 2010-06-27 16:04:43 --> Hooks Class Initialized
DEBUG - 2010-06-27 16:04:43 --> URI Class Initialized
DEBUG - 2010-06-27 16:04:43 --> Router Class Initialized
DEBUG - 2010-06-27 16:04:43 --> Output Class Initialized
DEBUG - 2010-06-27 16:04:43 --> Input Class Initialized
DEBUG - 2010-06-27 16:04:43 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 16:04:43 --> Language Class Initialized
DEBUG - 2010-06-27 16:04:43 --> Loader Class Initialized
DEBUG - 2010-06-27 16:04:43 --> Helper loaded: context_helper
DEBUG - 2010-06-27 16:04:43 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 16:04:43 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 16:04:43 --> Database Driver Class Initialized
DEBUG - 2010-06-27 16:04:43 --> Controller Class Initialized
DEBUG - 2010-06-27 16:04:44 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 16:04:44 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 16:04:44 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-27 16:04:44 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-27 16:04:44 --> Final output sent to browser
DEBUG - 2010-06-27 16:04:44 --> Total execution time: 0.9961
DEBUG - 2010-06-27 16:06:04 --> Config Class Initialized
DEBUG - 2010-06-27 16:06:05 --> Hooks Class Initialized
DEBUG - 2010-06-27 16:06:05 --> URI Class Initialized
DEBUG - 2010-06-27 16:06:05 --> Router Class Initialized
DEBUG - 2010-06-27 16:06:05 --> Output Class Initialized
DEBUG - 2010-06-27 16:06:05 --> Input Class Initialized
DEBUG - 2010-06-27 16:06:05 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 16:06:05 --> Language Class Initialized
DEBUG - 2010-06-27 16:06:05 --> Loader Class Initialized
DEBUG - 2010-06-27 16:06:05 --> Helper loaded: context_helper
DEBUG - 2010-06-27 16:06:05 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 16:06:05 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 16:06:05 --> Database Driver Class Initialized
DEBUG - 2010-06-27 16:06:05 --> Controller Class Initialized
DEBUG - 2010-06-27 16:06:05 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 16:06:05 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 16:06:30 --> Config Class Initialized
DEBUG - 2010-06-27 16:06:30 --> Hooks Class Initialized
DEBUG - 2010-06-27 16:06:31 --> URI Class Initialized
DEBUG - 2010-06-27 16:06:31 --> Router Class Initialized
DEBUG - 2010-06-27 16:06:31 --> Output Class Initialized
DEBUG - 2010-06-27 16:06:31 --> Input Class Initialized
DEBUG - 2010-06-27 16:06:31 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 16:06:31 --> Language Class Initialized
DEBUG - 2010-06-27 16:06:31 --> Loader Class Initialized
DEBUG - 2010-06-27 16:06:31 --> Helper loaded: context_helper
DEBUG - 2010-06-27 16:06:31 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 16:06:31 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 16:06:31 --> Database Driver Class Initialized
DEBUG - 2010-06-27 16:06:31 --> Controller Class Initialized
DEBUG - 2010-06-27 16:06:31 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 16:06:31 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 16:07:06 --> Config Class Initialized
DEBUG - 2010-06-27 16:07:06 --> Hooks Class Initialized
DEBUG - 2010-06-27 16:07:06 --> URI Class Initialized
DEBUG - 2010-06-27 16:07:06 --> Router Class Initialized
DEBUG - 2010-06-27 16:07:06 --> Output Class Initialized
DEBUG - 2010-06-27 16:07:06 --> Input Class Initialized
DEBUG - 2010-06-27 16:07:06 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 16:07:06 --> Language Class Initialized
DEBUG - 2010-06-27 16:07:06 --> Loader Class Initialized
DEBUG - 2010-06-27 16:07:07 --> Helper loaded: context_helper
DEBUG - 2010-06-27 16:07:07 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 16:07:07 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 16:07:07 --> Database Driver Class Initialized
DEBUG - 2010-06-27 16:07:07 --> Controller Class Initialized
DEBUG - 2010-06-27 16:07:07 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 16:07:07 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 16:07:46 --> Config Class Initialized
DEBUG - 2010-06-27 16:07:46 --> Hooks Class Initialized
DEBUG - 2010-06-27 16:07:46 --> URI Class Initialized
DEBUG - 2010-06-27 16:07:46 --> Router Class Initialized
DEBUG - 2010-06-27 16:07:46 --> Output Class Initialized
DEBUG - 2010-06-27 16:07:46 --> Input Class Initialized
DEBUG - 2010-06-27 16:07:46 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 16:07:46 --> Language Class Initialized
DEBUG - 2010-06-27 16:07:46 --> Loader Class Initialized
DEBUG - 2010-06-27 16:07:46 --> Helper loaded: context_helper
DEBUG - 2010-06-27 16:07:46 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 16:07:46 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 16:07:46 --> Database Driver Class Initialized
DEBUG - 2010-06-27 16:07:47 --> Controller Class Initialized
DEBUG - 2010-06-27 16:07:47 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 16:07:47 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 16:08:37 --> Config Class Initialized
DEBUG - 2010-06-27 16:08:37 --> Hooks Class Initialized
DEBUG - 2010-06-27 16:08:37 --> URI Class Initialized
DEBUG - 2010-06-27 16:08:37 --> Router Class Initialized
DEBUG - 2010-06-27 16:08:37 --> Output Class Initialized
DEBUG - 2010-06-27 16:08:37 --> Input Class Initialized
DEBUG - 2010-06-27 16:08:37 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 16:08:37 --> Language Class Initialized
DEBUG - 2010-06-27 16:08:37 --> Loader Class Initialized
DEBUG - 2010-06-27 16:08:37 --> Helper loaded: context_helper
DEBUG - 2010-06-27 16:08:37 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 16:08:37 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 16:08:37 --> Database Driver Class Initialized
DEBUG - 2010-06-27 16:08:37 --> Controller Class Initialized
DEBUG - 2010-06-27 16:08:37 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 16:08:37 --> Helper loaded: unit_test_helper
ERROR - 2010-06-27 16:08:38 --> Severity: Notice  --> Undefined property: Generic_object::$db D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 218
DEBUG - 2010-06-27 16:10:46 --> Config Class Initialized
DEBUG - 2010-06-27 16:10:46 --> Hooks Class Initialized
DEBUG - 2010-06-27 16:10:46 --> URI Class Initialized
DEBUG - 2010-06-27 16:10:46 --> Router Class Initialized
DEBUG - 2010-06-27 16:10:46 --> Output Class Initialized
DEBUG - 2010-06-27 16:10:46 --> Input Class Initialized
DEBUG - 2010-06-27 16:10:46 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 16:10:46 --> Language Class Initialized
DEBUG - 2010-06-27 16:10:46 --> Loader Class Initialized
DEBUG - 2010-06-27 16:10:46 --> Helper loaded: context_helper
DEBUG - 2010-06-27 16:10:46 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 16:10:47 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 16:10:47 --> Database Driver Class Initialized
DEBUG - 2010-06-27 16:10:47 --> Controller Class Initialized
DEBUG - 2010-06-27 16:10:47 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 16:10:47 --> Helper loaded: unit_test_helper
ERROR - 2010-06-27 16:10:47 --> Severity: Notice  --> Undefined property: Generic_object::$db D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 225
DEBUG - 2010-06-27 16:11:31 --> Config Class Initialized
DEBUG - 2010-06-27 16:11:31 --> Hooks Class Initialized
DEBUG - 2010-06-27 16:11:31 --> URI Class Initialized
DEBUG - 2010-06-27 16:11:31 --> Router Class Initialized
DEBUG - 2010-06-27 16:11:31 --> Output Class Initialized
DEBUG - 2010-06-27 16:11:31 --> Input Class Initialized
DEBUG - 2010-06-27 16:11:31 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 16:11:31 --> Language Class Initialized
DEBUG - 2010-06-27 16:11:31 --> Loader Class Initialized
DEBUG - 2010-06-27 16:11:31 --> Helper loaded: context_helper
DEBUG - 2010-06-27 16:11:31 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 16:11:31 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 16:11:31 --> Database Driver Class Initialized
DEBUG - 2010-06-27 16:11:31 --> Controller Class Initialized
DEBUG - 2010-06-27 16:11:32 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 16:11:32 --> Helper loaded: unit_test_helper
ERROR - 2010-06-27 16:11:32 --> Severity: Notice  --> Undefined property: Generic_object::$db D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 225
DEBUG - 2010-06-27 16:11:54 --> Config Class Initialized
DEBUG - 2010-06-27 16:11:55 --> Hooks Class Initialized
DEBUG - 2010-06-27 16:11:55 --> URI Class Initialized
DEBUG - 2010-06-27 16:11:55 --> Router Class Initialized
DEBUG - 2010-06-27 16:11:55 --> Output Class Initialized
DEBUG - 2010-06-27 16:11:55 --> Input Class Initialized
DEBUG - 2010-06-27 16:11:55 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 16:11:55 --> Language Class Initialized
DEBUG - 2010-06-27 16:11:55 --> Loader Class Initialized
DEBUG - 2010-06-27 16:11:55 --> Helper loaded: context_helper
DEBUG - 2010-06-27 16:11:55 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 16:11:55 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 16:11:55 --> Database Driver Class Initialized
DEBUG - 2010-06-27 16:11:55 --> Controller Class Initialized
DEBUG - 2010-06-27 16:11:55 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 16:11:55 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 16:11:55 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-06-27 16:11:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php:38) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-27 16:13:45 --> Config Class Initialized
DEBUG - 2010-06-27 16:13:45 --> Hooks Class Initialized
DEBUG - 2010-06-27 16:13:45 --> URI Class Initialized
DEBUG - 2010-06-27 16:13:45 --> Router Class Initialized
DEBUG - 2010-06-27 16:13:45 --> Output Class Initialized
DEBUG - 2010-06-27 16:13:45 --> Input Class Initialized
DEBUG - 2010-06-27 16:13:45 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 16:13:45 --> Language Class Initialized
DEBUG - 2010-06-27 16:13:45 --> Loader Class Initialized
DEBUG - 2010-06-27 16:13:45 --> Helper loaded: context_helper
DEBUG - 2010-06-27 16:13:45 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 16:13:45 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 16:13:45 --> Database Driver Class Initialized
DEBUG - 2010-06-27 16:13:45 --> Controller Class Initialized
DEBUG - 2010-06-27 16:13:45 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 16:13:45 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 16:13:45 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-06-27 16:21:58 --> Config Class Initialized
DEBUG - 2010-06-27 16:21:58 --> Hooks Class Initialized
DEBUG - 2010-06-27 16:21:58 --> URI Class Initialized
DEBUG - 2010-06-27 16:21:58 --> Router Class Initialized
DEBUG - 2010-06-27 16:21:58 --> Output Class Initialized
DEBUG - 2010-06-27 16:21:58 --> Input Class Initialized
DEBUG - 2010-06-27 16:21:59 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 16:21:59 --> Language Class Initialized
DEBUG - 2010-06-27 16:21:59 --> Loader Class Initialized
DEBUG - 2010-06-27 16:21:59 --> Helper loaded: context_helper
DEBUG - 2010-06-27 16:21:59 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 16:21:59 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 16:21:59 --> Database Driver Class Initialized
DEBUG - 2010-06-27 16:21:59 --> Controller Class Initialized
DEBUG - 2010-06-27 16:21:59 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 16:21:59 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 16:21:59 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-06-27 16:22:23 --> Config Class Initialized
DEBUG - 2010-06-27 16:22:23 --> Hooks Class Initialized
DEBUG - 2010-06-27 16:22:23 --> URI Class Initialized
DEBUG - 2010-06-27 16:22:23 --> Router Class Initialized
DEBUG - 2010-06-27 16:22:23 --> Output Class Initialized
DEBUG - 2010-06-27 16:22:23 --> Input Class Initialized
DEBUG - 2010-06-27 16:22:23 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 16:22:23 --> Language Class Initialized
DEBUG - 2010-06-27 16:22:23 --> Loader Class Initialized
DEBUG - 2010-06-27 16:22:23 --> Helper loaded: context_helper
DEBUG - 2010-06-27 16:22:23 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 16:22:23 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 16:22:24 --> Database Driver Class Initialized
DEBUG - 2010-06-27 16:22:24 --> Controller Class Initialized
DEBUG - 2010-06-27 16:22:24 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 16:22:24 --> Helper loaded: unit_test_helper
ERROR - 2010-06-27 16:22:24 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  relation &quot;1212&quot; does not exist
LINE 1: INSERT INTO &quot;1212&quot; (&quot;host&quot;) VALUES ('http://www.lib.nccu.edu...
                    ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-27 16:22:24 --> DB Transaction Failure
ERROR - 2010-06-27 16:22:24 --> Query error: ERROR:  relation "1212" does not exist
LINE 1: INSERT INTO "1212" ("host") VALUES ('http://www.lib.nccu.edu...
                    ^
DEBUG - 2010-06-27 16:22:24 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-06-27 16:22:24 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php:36) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-27 17:00:49 --> Config Class Initialized
DEBUG - 2010-06-27 17:00:50 --> Hooks Class Initialized
DEBUG - 2010-06-27 17:00:50 --> URI Class Initialized
DEBUG - 2010-06-27 17:00:50 --> Router Class Initialized
DEBUG - 2010-06-27 17:00:50 --> Output Class Initialized
DEBUG - 2010-06-27 17:00:50 --> Input Class Initialized
DEBUG - 2010-06-27 17:00:50 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 17:00:50 --> Language Class Initialized
DEBUG - 2010-06-27 17:00:50 --> Loader Class Initialized
DEBUG - 2010-06-27 17:00:50 --> Helper loaded: context_helper
DEBUG - 2010-06-27 17:00:50 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 17:00:50 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 17:00:50 --> Database Driver Class Initialized
DEBUG - 2010-06-27 17:00:50 --> Controller Class Initialized
DEBUG - 2010-06-27 17:00:50 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 17:00:50 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 17:22:16 --> Config Class Initialized
DEBUG - 2010-06-27 17:22:16 --> Hooks Class Initialized
DEBUG - 2010-06-27 17:22:16 --> URI Class Initialized
DEBUG - 2010-06-27 17:22:16 --> Router Class Initialized
DEBUG - 2010-06-27 17:22:16 --> Output Class Initialized
DEBUG - 2010-06-27 17:22:16 --> Input Class Initialized
DEBUG - 2010-06-27 17:22:16 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 17:22:16 --> Language Class Initialized
DEBUG - 2010-06-27 17:22:16 --> Loader Class Initialized
DEBUG - 2010-06-27 17:22:16 --> Helper loaded: context_helper
DEBUG - 2010-06-27 17:22:16 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 17:22:16 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 17:22:16 --> Database Driver Class Initialized
ERROR - 2010-06-27 17:22:16 --> Severity: Warning  --> Missing argument 1 for Generic_object::__construct(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Loader.php on line 928 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 33
ERROR - 2010-06-27 17:22:16 --> Severity: Notice  --> Undefined variable: table_name D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 35
DEBUG - 2010-06-27 17:22:17 --> Controller Class Initialized
DEBUG - 2010-06-27 17:22:17 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 17:22:17 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 17:23:55 --> Config Class Initialized
DEBUG - 2010-06-27 17:23:55 --> Hooks Class Initialized
DEBUG - 2010-06-27 17:23:55 --> URI Class Initialized
DEBUG - 2010-06-27 17:23:55 --> Router Class Initialized
DEBUG - 2010-06-27 17:23:55 --> Output Class Initialized
DEBUG - 2010-06-27 17:23:55 --> Input Class Initialized
DEBUG - 2010-06-27 17:23:55 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 17:23:55 --> Language Class Initialized
DEBUG - 2010-06-27 17:23:55 --> Loader Class Initialized
DEBUG - 2010-06-27 17:23:55 --> Helper loaded: context_helper
DEBUG - 2010-06-27 17:23:55 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 17:23:55 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 17:23:55 --> Database Driver Class Initialized
DEBUG - 2010-06-27 17:23:55 --> Controller Class Initialized
DEBUG - 2010-06-27 17:23:55 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 17:23:55 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 17:25:53 --> Config Class Initialized
DEBUG - 2010-06-27 17:25:53 --> Hooks Class Initialized
DEBUG - 2010-06-27 17:25:53 --> URI Class Initialized
DEBUG - 2010-06-27 17:25:53 --> Router Class Initialized
DEBUG - 2010-06-27 17:25:53 --> Output Class Initialized
DEBUG - 2010-06-27 17:25:53 --> Input Class Initialized
DEBUG - 2010-06-27 17:25:53 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 17:25:53 --> Language Class Initialized
DEBUG - 2010-06-27 17:25:53 --> Loader Class Initialized
DEBUG - 2010-06-27 17:25:53 --> Helper loaded: context_helper
DEBUG - 2010-06-27 17:25:53 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 17:25:53 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 17:25:54 --> Database Driver Class Initialized
DEBUG - 2010-06-27 17:25:54 --> Controller Class Initialized
DEBUG - 2010-06-27 17:25:54 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 17:25:54 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 17:26:19 --> Config Class Initialized
DEBUG - 2010-06-27 17:26:19 --> Hooks Class Initialized
DEBUG - 2010-06-27 17:26:19 --> URI Class Initialized
DEBUG - 2010-06-27 17:26:19 --> Router Class Initialized
DEBUG - 2010-06-27 17:26:19 --> Output Class Initialized
DEBUG - 2010-06-27 17:26:20 --> Input Class Initialized
DEBUG - 2010-06-27 17:26:20 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 17:26:20 --> Language Class Initialized
DEBUG - 2010-06-27 17:26:20 --> Loader Class Initialized
DEBUG - 2010-06-27 17:26:20 --> Helper loaded: context_helper
DEBUG - 2010-06-27 17:26:20 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 17:26:20 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 17:26:20 --> Database Driver Class Initialized
DEBUG - 2010-06-27 17:26:20 --> Controller Class Initialized
DEBUG - 2010-06-27 17:26:20 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 17:26:20 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 17:28:30 --> Config Class Initialized
DEBUG - 2010-06-27 17:28:30 --> Hooks Class Initialized
DEBUG - 2010-06-27 17:28:31 --> URI Class Initialized
DEBUG - 2010-06-27 17:28:31 --> Router Class Initialized
DEBUG - 2010-06-27 17:28:31 --> Output Class Initialized
DEBUG - 2010-06-27 17:28:31 --> Input Class Initialized
DEBUG - 2010-06-27 17:28:31 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 17:28:31 --> Language Class Initialized
DEBUG - 2010-06-27 17:28:47 --> Config Class Initialized
DEBUG - 2010-06-27 17:28:47 --> Hooks Class Initialized
DEBUG - 2010-06-27 17:28:47 --> URI Class Initialized
DEBUG - 2010-06-27 17:28:47 --> Router Class Initialized
DEBUG - 2010-06-27 17:28:47 --> Output Class Initialized
DEBUG - 2010-06-27 17:28:47 --> Input Class Initialized
DEBUG - 2010-06-27 17:28:47 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 17:28:47 --> Language Class Initialized
DEBUG - 2010-06-27 17:28:47 --> Loader Class Initialized
DEBUG - 2010-06-27 17:28:47 --> Helper loaded: context_helper
DEBUG - 2010-06-27 17:28:47 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 17:28:47 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 17:28:47 --> Database Driver Class Initialized
DEBUG - 2010-06-27 17:28:47 --> Controller Class Initialized
DEBUG - 2010-06-27 17:28:47 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 17:28:48 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 17:28:48 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-06-27 17:31:21 --> Config Class Initialized
DEBUG - 2010-06-27 17:31:21 --> Hooks Class Initialized
DEBUG - 2010-06-27 17:31:22 --> URI Class Initialized
DEBUG - 2010-06-27 17:31:22 --> Router Class Initialized
DEBUG - 2010-06-27 17:31:22 --> Output Class Initialized
DEBUG - 2010-06-27 17:31:22 --> Input Class Initialized
DEBUG - 2010-06-27 17:31:22 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 17:31:22 --> Language Class Initialized
DEBUG - 2010-06-27 17:31:22 --> Loader Class Initialized
DEBUG - 2010-06-27 17:31:22 --> Helper loaded: context_helper
DEBUG - 2010-06-27 17:31:22 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 17:31:22 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 17:31:22 --> Database Driver Class Initialized
DEBUG - 2010-06-27 17:31:22 --> Controller Class Initialized
DEBUG - 2010-06-27 17:31:22 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 17:31:22 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 17:31:22 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-06-27 17:31:22 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php:105) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-06-27 17:32:37 --> Config Class Initialized
DEBUG - 2010-06-27 17:32:37 --> Hooks Class Initialized
DEBUG - 2010-06-27 17:32:38 --> URI Class Initialized
DEBUG - 2010-06-27 17:32:38 --> Router Class Initialized
DEBUG - 2010-06-27 17:32:38 --> Output Class Initialized
DEBUG - 2010-06-27 17:32:38 --> Input Class Initialized
DEBUG - 2010-06-27 17:32:38 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 17:32:38 --> Language Class Initialized
DEBUG - 2010-06-27 17:32:38 --> Loader Class Initialized
DEBUG - 2010-06-27 17:32:38 --> Helper loaded: context_helper
DEBUG - 2010-06-27 17:32:38 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 17:32:38 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 17:32:38 --> Database Driver Class Initialized
DEBUG - 2010-06-27 17:32:38 --> Controller Class Initialized
DEBUG - 2010-06-27 17:32:38 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 17:32:38 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 17:32:38 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-06-27 17:33:08 --> Config Class Initialized
DEBUG - 2010-06-27 17:33:08 --> Hooks Class Initialized
DEBUG - 2010-06-27 17:33:08 --> URI Class Initialized
DEBUG - 2010-06-27 17:33:08 --> Router Class Initialized
DEBUG - 2010-06-27 17:33:08 --> Output Class Initialized
DEBUG - 2010-06-27 17:33:08 --> Input Class Initialized
DEBUG - 2010-06-27 17:33:08 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 17:33:08 --> Language Class Initialized
DEBUG - 2010-06-27 17:33:08 --> Loader Class Initialized
DEBUG - 2010-06-27 17:33:08 --> Helper loaded: context_helper
DEBUG - 2010-06-27 17:33:08 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 17:33:08 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 17:33:08 --> Database Driver Class Initialized
DEBUG - 2010-06-27 17:33:23 --> Config Class Initialized
DEBUG - 2010-06-27 17:33:23 --> Hooks Class Initialized
DEBUG - 2010-06-27 17:33:23 --> URI Class Initialized
DEBUG - 2010-06-27 17:33:23 --> Router Class Initialized
DEBUG - 2010-06-27 17:33:23 --> Output Class Initialized
DEBUG - 2010-06-27 17:33:23 --> Input Class Initialized
DEBUG - 2010-06-27 17:33:23 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 17:33:23 --> Language Class Initialized
DEBUG - 2010-06-27 17:33:23 --> Loader Class Initialized
DEBUG - 2010-06-27 17:33:23 --> Helper loaded: context_helper
DEBUG - 2010-06-27 17:33:23 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 17:33:24 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 17:33:24 --> Database Driver Class Initialized
DEBUG - 2010-06-27 17:33:24 --> Controller Class Initialized
DEBUG - 2010-06-27 17:33:24 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 17:33:24 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 17:33:24 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-27 17:33:24 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-27 17:33:24 --> Final output sent to browser
DEBUG - 2010-06-27 17:33:24 --> Total execution time: 1.0943
DEBUG - 2010-06-27 17:34:52 --> Config Class Initialized
DEBUG - 2010-06-27 17:34:52 --> Hooks Class Initialized
DEBUG - 2010-06-27 17:34:52 --> URI Class Initialized
DEBUG - 2010-06-27 17:34:52 --> Router Class Initialized
DEBUG - 2010-06-27 17:34:52 --> Output Class Initialized
DEBUG - 2010-06-27 17:34:52 --> Input Class Initialized
DEBUG - 2010-06-27 17:34:52 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 17:34:52 --> Language Class Initialized
DEBUG - 2010-06-27 17:34:52 --> Loader Class Initialized
DEBUG - 2010-06-27 17:34:52 --> Helper loaded: context_helper
DEBUG - 2010-06-27 17:34:52 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 17:34:53 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 17:34:53 --> Database Driver Class Initialized
DEBUG - 2010-06-27 17:34:53 --> Controller Class Initialized
DEBUG - 2010-06-27 17:34:53 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 17:34:53 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 17:34:53 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-27 17:34:53 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-27 17:34:53 --> Final output sent to browser
DEBUG - 2010-06-27 17:34:53 --> Total execution time: 1.1026
DEBUG - 2010-06-27 17:35:41 --> Config Class Initialized
DEBUG - 2010-06-27 17:35:41 --> Hooks Class Initialized
DEBUG - 2010-06-27 17:35:42 --> URI Class Initialized
DEBUG - 2010-06-27 17:35:42 --> Router Class Initialized
DEBUG - 2010-06-27 17:35:42 --> Output Class Initialized
DEBUG - 2010-06-27 17:35:42 --> Input Class Initialized
DEBUG - 2010-06-27 17:35:42 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 17:35:42 --> Language Class Initialized
DEBUG - 2010-06-27 17:35:42 --> Loader Class Initialized
DEBUG - 2010-06-27 17:35:42 --> Helper loaded: context_helper
DEBUG - 2010-06-27 17:35:42 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 17:35:42 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 17:35:42 --> Database Driver Class Initialized
DEBUG - 2010-06-27 17:35:42 --> Controller Class Initialized
DEBUG - 2010-06-27 17:35:42 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 17:35:42 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 17:36:08 --> Config Class Initialized
DEBUG - 2010-06-27 17:36:08 --> Hooks Class Initialized
DEBUG - 2010-06-27 17:36:08 --> URI Class Initialized
DEBUG - 2010-06-27 17:36:08 --> Router Class Initialized
DEBUG - 2010-06-27 17:36:08 --> Output Class Initialized
DEBUG - 2010-06-27 17:36:08 --> Input Class Initialized
DEBUG - 2010-06-27 17:36:08 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 17:36:08 --> Language Class Initialized
DEBUG - 2010-06-27 17:36:08 --> Loader Class Initialized
DEBUG - 2010-06-27 17:36:08 --> Helper loaded: context_helper
DEBUG - 2010-06-27 17:36:08 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 17:36:08 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 17:36:08 --> Database Driver Class Initialized
DEBUG - 2010-06-27 17:36:08 --> Controller Class Initialized
DEBUG - 2010-06-27 17:36:08 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 17:36:09 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 17:36:09 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-27 17:36:09 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-27 17:36:09 --> Final output sent to browser
DEBUG - 2010-06-27 17:36:09 --> Total execution time: 1.1112
DEBUG - 2010-06-27 17:36:32 --> Config Class Initialized
DEBUG - 2010-06-27 17:36:32 --> Hooks Class Initialized
DEBUG - 2010-06-27 17:36:32 --> URI Class Initialized
DEBUG - 2010-06-27 17:36:32 --> Router Class Initialized
DEBUG - 2010-06-27 17:36:32 --> Output Class Initialized
DEBUG - 2010-06-27 17:36:32 --> Input Class Initialized
DEBUG - 2010-06-27 17:36:33 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 17:36:33 --> Language Class Initialized
DEBUG - 2010-06-27 17:36:33 --> Loader Class Initialized
DEBUG - 2010-06-27 17:36:33 --> Helper loaded: context_helper
DEBUG - 2010-06-27 17:36:33 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 17:36:33 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 17:36:33 --> Database Driver Class Initialized
DEBUG - 2010-06-27 17:36:33 --> Controller Class Initialized
DEBUG - 2010-06-27 17:36:33 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 17:36:33 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 17:36:33 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-27 17:36:33 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-27 17:36:33 --> Final output sent to browser
DEBUG - 2010-06-27 17:36:33 --> Total execution time: 1.1274
DEBUG - 2010-06-27 17:37:25 --> Config Class Initialized
DEBUG - 2010-06-27 17:37:25 --> Hooks Class Initialized
DEBUG - 2010-06-27 17:37:25 --> URI Class Initialized
DEBUG - 2010-06-27 17:37:25 --> Router Class Initialized
DEBUG - 2010-06-27 17:37:25 --> Output Class Initialized
DEBUG - 2010-06-27 17:37:25 --> Input Class Initialized
DEBUG - 2010-06-27 17:37:25 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 17:37:25 --> Language Class Initialized
DEBUG - 2010-06-27 17:37:25 --> Loader Class Initialized
DEBUG - 2010-06-27 17:37:25 --> Helper loaded: context_helper
DEBUG - 2010-06-27 17:37:25 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 17:37:25 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 17:37:25 --> Database Driver Class Initialized
DEBUG - 2010-06-27 17:37:25 --> Controller Class Initialized
DEBUG - 2010-06-27 17:37:26 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 17:37:26 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 17:37:26 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-27 17:37:26 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-27 17:37:26 --> Final output sent to browser
DEBUG - 2010-06-27 17:37:26 --> Total execution time: 1.1418
DEBUG - 2010-06-27 17:38:15 --> Config Class Initialized
DEBUG - 2010-06-27 17:38:15 --> Hooks Class Initialized
DEBUG - 2010-06-27 17:38:15 --> URI Class Initialized
DEBUG - 2010-06-27 17:38:15 --> Router Class Initialized
DEBUG - 2010-06-27 17:38:15 --> Output Class Initialized
DEBUG - 2010-06-27 17:38:16 --> Input Class Initialized
DEBUG - 2010-06-27 17:38:16 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 17:38:16 --> Language Class Initialized
DEBUG - 2010-06-27 17:38:16 --> Loader Class Initialized
DEBUG - 2010-06-27 17:38:16 --> Helper loaded: context_helper
DEBUG - 2010-06-27 17:38:16 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 17:38:16 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 17:38:16 --> Database Driver Class Initialized
DEBUG - 2010-06-27 17:38:16 --> Controller Class Initialized
DEBUG - 2010-06-27 17:38:16 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 17:38:16 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 17:38:16 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-27 17:38:16 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-27 17:38:16 --> Final output sent to browser
DEBUG - 2010-06-27 17:38:16 --> Total execution time: 1.1627
DEBUG - 2010-06-27 17:39:02 --> Config Class Initialized
DEBUG - 2010-06-27 17:39:02 --> Hooks Class Initialized
DEBUG - 2010-06-27 17:39:02 --> URI Class Initialized
DEBUG - 2010-06-27 17:39:02 --> Router Class Initialized
DEBUG - 2010-06-27 17:39:03 --> Output Class Initialized
DEBUG - 2010-06-27 17:39:03 --> Input Class Initialized
DEBUG - 2010-06-27 17:39:03 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 17:39:03 --> Language Class Initialized
DEBUG - 2010-06-27 17:39:03 --> Loader Class Initialized
DEBUG - 2010-06-27 17:39:03 --> Helper loaded: context_helper
DEBUG - 2010-06-27 17:39:03 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 17:39:03 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 17:39:03 --> Database Driver Class Initialized
DEBUG - 2010-06-27 17:39:03 --> Controller Class Initialized
DEBUG - 2010-06-27 17:39:03 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 17:39:03 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 17:39:03 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-27 17:39:03 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-27 17:39:03 --> Final output sent to browser
DEBUG - 2010-06-27 17:39:04 --> Total execution time: 1.1535
DEBUG - 2010-06-27 17:39:20 --> Config Class Initialized
DEBUG - 2010-06-27 17:39:20 --> Hooks Class Initialized
DEBUG - 2010-06-27 17:39:20 --> URI Class Initialized
DEBUG - 2010-06-27 17:39:20 --> Router Class Initialized
DEBUG - 2010-06-27 17:39:20 --> Output Class Initialized
DEBUG - 2010-06-27 17:39:20 --> Input Class Initialized
DEBUG - 2010-06-27 17:39:20 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 17:39:20 --> Language Class Initialized
DEBUG - 2010-06-27 17:39:20 --> Loader Class Initialized
DEBUG - 2010-06-27 17:39:20 --> Helper loaded: context_helper
DEBUG - 2010-06-27 17:39:20 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 17:39:20 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 17:39:21 --> Database Driver Class Initialized
DEBUG - 2010-06-27 17:39:21 --> Controller Class Initialized
DEBUG - 2010-06-27 17:39:21 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 17:39:21 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 17:39:21 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-27 17:39:21 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-27 17:39:21 --> Final output sent to browser
DEBUG - 2010-06-27 17:39:21 --> Total execution time: 1.1600
DEBUG - 2010-06-27 17:39:48 --> Config Class Initialized
DEBUG - 2010-06-27 17:39:48 --> Hooks Class Initialized
DEBUG - 2010-06-27 17:39:48 --> URI Class Initialized
DEBUG - 2010-06-27 17:39:48 --> Router Class Initialized
DEBUG - 2010-06-27 17:39:48 --> Output Class Initialized
DEBUG - 2010-06-27 17:39:48 --> Input Class Initialized
DEBUG - 2010-06-27 17:39:48 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 17:39:48 --> Language Class Initialized
DEBUG - 2010-06-27 17:39:48 --> Loader Class Initialized
DEBUG - 2010-06-27 17:39:48 --> Helper loaded: context_helper
DEBUG - 2010-06-27 17:39:49 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 17:39:49 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 17:39:49 --> Database Driver Class Initialized
DEBUG - 2010-06-27 17:39:49 --> Controller Class Initialized
DEBUG - 2010-06-27 17:39:49 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 17:39:49 --> Helper loaded: unit_test_helper
ERROR - 2010-06-27 17:39:49 --> Severity: Notice  --> Undefined variable: cond D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 446
DEBUG - 2010-06-27 17:39:49 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-27 17:39:49 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-27 17:39:49 --> Final output sent to browser
DEBUG - 2010-06-27 17:39:49 --> Total execution time: 1.2423
DEBUG - 2010-06-27 17:40:01 --> Config Class Initialized
DEBUG - 2010-06-27 17:40:01 --> Hooks Class Initialized
DEBUG - 2010-06-27 17:40:01 --> URI Class Initialized
DEBUG - 2010-06-27 17:40:01 --> Router Class Initialized
DEBUG - 2010-06-27 17:40:01 --> Output Class Initialized
DEBUG - 2010-06-27 17:40:01 --> Input Class Initialized
DEBUG - 2010-06-27 17:40:01 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 17:40:01 --> Language Class Initialized
DEBUG - 2010-06-27 17:40:01 --> Loader Class Initialized
DEBUG - 2010-06-27 17:40:01 --> Helper loaded: context_helper
DEBUG - 2010-06-27 17:40:01 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 17:40:01 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 17:40:01 --> Database Driver Class Initialized
DEBUG - 2010-06-27 17:40:02 --> Controller Class Initialized
DEBUG - 2010-06-27 17:40:02 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 17:40:02 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 17:40:02 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-27 17:40:02 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-27 17:40:02 --> Final output sent to browser
DEBUG - 2010-06-27 17:40:02 --> Total execution time: 1.2060
DEBUG - 2010-06-27 17:40:27 --> Config Class Initialized
DEBUG - 2010-06-27 17:40:27 --> Hooks Class Initialized
DEBUG - 2010-06-27 17:40:27 --> URI Class Initialized
DEBUG - 2010-06-27 17:40:27 --> Router Class Initialized
DEBUG - 2010-06-27 17:40:27 --> Output Class Initialized
DEBUG - 2010-06-27 17:40:27 --> Input Class Initialized
DEBUG - 2010-06-27 17:40:27 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 17:40:27 --> Language Class Initialized
DEBUG - 2010-06-27 17:40:27 --> Loader Class Initialized
DEBUG - 2010-06-27 17:40:27 --> Helper loaded: context_helper
DEBUG - 2010-06-27 17:40:27 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 17:40:27 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 17:40:27 --> Database Driver Class Initialized
DEBUG - 2010-06-27 17:40:27 --> Controller Class Initialized
DEBUG - 2010-06-27 17:40:28 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 17:40:28 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 17:40:28 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-27 17:40:28 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-27 17:40:28 --> Final output sent to browser
DEBUG - 2010-06-27 17:40:28 --> Total execution time: 1.1942
DEBUG - 2010-06-27 17:40:48 --> Config Class Initialized
DEBUG - 2010-06-27 17:40:48 --> Hooks Class Initialized
DEBUG - 2010-06-27 17:40:48 --> URI Class Initialized
DEBUG - 2010-06-27 17:40:48 --> Router Class Initialized
DEBUG - 2010-06-27 17:40:48 --> Output Class Initialized
DEBUG - 2010-06-27 17:40:48 --> Input Class Initialized
DEBUG - 2010-06-27 17:40:48 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 17:40:49 --> Language Class Initialized
DEBUG - 2010-06-27 17:40:49 --> Loader Class Initialized
DEBUG - 2010-06-27 17:40:49 --> Helper loaded: context_helper
DEBUG - 2010-06-27 17:40:49 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 17:40:49 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 17:40:49 --> Database Driver Class Initialized
DEBUG - 2010-06-27 17:40:49 --> Controller Class Initialized
DEBUG - 2010-06-27 17:40:49 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 17:40:49 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 17:41:53 --> Config Class Initialized
DEBUG - 2010-06-27 17:41:53 --> Hooks Class Initialized
DEBUG - 2010-06-27 17:41:53 --> URI Class Initialized
DEBUG - 2010-06-27 17:41:53 --> Router Class Initialized
DEBUG - 2010-06-27 17:41:53 --> Output Class Initialized
DEBUG - 2010-06-27 17:41:53 --> Input Class Initialized
DEBUG - 2010-06-27 17:41:53 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 17:41:53 --> Language Class Initialized
DEBUG - 2010-06-27 17:41:53 --> Loader Class Initialized
DEBUG - 2010-06-27 17:41:53 --> Helper loaded: context_helper
DEBUG - 2010-06-27 17:41:53 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 17:41:53 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 17:41:53 --> Database Driver Class Initialized
DEBUG - 2010-06-27 17:41:53 --> Controller Class Initialized
DEBUG - 2010-06-27 17:41:53 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 17:41:54 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 17:41:54 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-27 17:41:54 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-27 17:41:54 --> Final output sent to browser
DEBUG - 2010-06-27 17:41:54 --> Total execution time: 1.2094
DEBUG - 2010-06-27 17:42:58 --> Config Class Initialized
DEBUG - 2010-06-27 17:42:58 --> Hooks Class Initialized
DEBUG - 2010-06-27 17:42:58 --> URI Class Initialized
DEBUG - 2010-06-27 17:42:58 --> Router Class Initialized
DEBUG - 2010-06-27 17:42:58 --> Output Class Initialized
DEBUG - 2010-06-27 17:42:58 --> Input Class Initialized
DEBUG - 2010-06-27 17:42:58 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 17:42:58 --> Language Class Initialized
DEBUG - 2010-06-27 17:42:58 --> Loader Class Initialized
DEBUG - 2010-06-27 17:42:58 --> Helper loaded: context_helper
DEBUG - 2010-06-27 17:42:58 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 17:42:58 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 17:42:58 --> Database Driver Class Initialized
DEBUG - 2010-06-27 17:42:58 --> Controller Class Initialized
DEBUG - 2010-06-27 17:42:58 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 17:42:59 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 17:42:59 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-27 17:42:59 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-27 17:42:59 --> Final output sent to browser
DEBUG - 2010-06-27 17:42:59 --> Total execution time: 1.2220
DEBUG - 2010-06-27 17:44:16 --> Config Class Initialized
DEBUG - 2010-06-27 17:44:16 --> Hooks Class Initialized
DEBUG - 2010-06-27 17:44:16 --> URI Class Initialized
DEBUG - 2010-06-27 17:44:16 --> Router Class Initialized
DEBUG - 2010-06-27 17:44:16 --> Output Class Initialized
DEBUG - 2010-06-27 17:44:16 --> Input Class Initialized
DEBUG - 2010-06-27 17:44:16 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 17:44:16 --> Language Class Initialized
DEBUG - 2010-06-27 17:44:16 --> Loader Class Initialized
DEBUG - 2010-06-27 17:44:16 --> Helper loaded: context_helper
DEBUG - 2010-06-27 17:44:16 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 17:44:16 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 17:44:16 --> Database Driver Class Initialized
DEBUG - 2010-06-27 17:44:16 --> Controller Class Initialized
DEBUG - 2010-06-27 17:44:17 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 17:44:17 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 17:44:17 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-06-27 17:44:52 --> Config Class Initialized
DEBUG - 2010-06-27 17:44:52 --> Hooks Class Initialized
DEBUG - 2010-06-27 17:44:52 --> URI Class Initialized
DEBUG - 2010-06-27 17:44:52 --> Router Class Initialized
DEBUG - 2010-06-27 17:44:53 --> Output Class Initialized
DEBUG - 2010-06-27 17:44:53 --> Input Class Initialized
DEBUG - 2010-06-27 17:44:53 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 17:44:53 --> Language Class Initialized
DEBUG - 2010-06-27 17:44:53 --> Loader Class Initialized
DEBUG - 2010-06-27 17:44:53 --> Helper loaded: context_helper
DEBUG - 2010-06-27 17:44:53 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 17:44:53 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 17:44:53 --> Database Driver Class Initialized
DEBUG - 2010-06-27 17:44:53 --> Controller Class Initialized
DEBUG - 2010-06-27 17:44:53 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 17:44:53 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 17:44:53 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-06-27 17:45:15 --> Config Class Initialized
DEBUG - 2010-06-27 17:45:16 --> Hooks Class Initialized
DEBUG - 2010-06-27 17:45:16 --> URI Class Initialized
DEBUG - 2010-06-27 17:45:16 --> Router Class Initialized
DEBUG - 2010-06-27 17:45:16 --> Output Class Initialized
DEBUG - 2010-06-27 17:45:16 --> Input Class Initialized
DEBUG - 2010-06-27 17:45:16 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 17:45:16 --> Language Class Initialized
DEBUG - 2010-06-27 17:45:16 --> Loader Class Initialized
DEBUG - 2010-06-27 17:45:16 --> Helper loaded: context_helper
DEBUG - 2010-06-27 17:45:16 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 17:45:16 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 17:45:16 --> Database Driver Class Initialized
DEBUG - 2010-06-27 17:45:16 --> Controller Class Initialized
DEBUG - 2010-06-27 17:45:16 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 17:45:16 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 17:45:17 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-06-27 17:45:39 --> Config Class Initialized
DEBUG - 2010-06-27 17:45:39 --> Hooks Class Initialized
DEBUG - 2010-06-27 17:45:39 --> URI Class Initialized
DEBUG - 2010-06-27 17:45:39 --> Router Class Initialized
DEBUG - 2010-06-27 17:45:39 --> Output Class Initialized
DEBUG - 2010-06-27 17:45:39 --> Input Class Initialized
DEBUG - 2010-06-27 17:45:39 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 17:45:39 --> Language Class Initialized
DEBUG - 2010-06-27 17:45:39 --> Loader Class Initialized
DEBUG - 2010-06-27 17:45:39 --> Helper loaded: context_helper
DEBUG - 2010-06-27 17:45:39 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 17:45:39 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 17:45:40 --> Database Driver Class Initialized
DEBUG - 2010-06-27 17:45:40 --> Controller Class Initialized
DEBUG - 2010-06-27 17:45:40 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 17:45:40 --> Helper loaded: unit_test_helper
ERROR - 2010-06-27 17:45:40 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;domain_id&quot; does not exist
LINE 1: SELECT &quot;domain_id&quot;
               ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 176
DEBUG - 2010-06-27 17:45:40 --> DB Transaction Failure
ERROR - 2010-06-27 17:45:40 --> Query error: ERROR:  column "domain_id" does not exist
LINE 1: SELECT "domain_id"
               ^
DEBUG - 2010-06-27 17:45:40 --> Language file loaded: language/zh_tw/db_lang.php
DEBUG - 2010-06-27 17:46:15 --> Config Class Initialized
DEBUG - 2010-06-27 17:46:15 --> Hooks Class Initialized
DEBUG - 2010-06-27 17:46:15 --> URI Class Initialized
DEBUG - 2010-06-27 17:46:15 --> Router Class Initialized
DEBUG - 2010-06-27 17:46:15 --> Output Class Initialized
DEBUG - 2010-06-27 17:46:15 --> Input Class Initialized
DEBUG - 2010-06-27 17:46:15 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-27 17:46:15 --> Language Class Initialized
DEBUG - 2010-06-27 17:46:15 --> Loader Class Initialized
DEBUG - 2010-06-27 17:46:16 --> Helper loaded: context_helper
DEBUG - 2010-06-27 17:46:16 --> Helper loaded: kals_helper
DEBUG - 2010-06-27 17:46:16 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-27 17:46:16 --> Database Driver Class Initialized
DEBUG - 2010-06-27 17:46:16 --> Controller Class Initialized
DEBUG - 2010-06-27 17:46:16 --> Unit Testing Class Initialized
DEBUG - 2010-06-27 17:46:16 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-27 17:46:16 --> Language file loaded: language/zh_tw/db_lang.php
