<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2010-06-21 08:57:21 --> Config Class Initialized
DEBUG - 2010-06-21 08:57:21 --> Hooks Class Initialized
DEBUG - 2010-06-21 08:57:21 --> URI Class Initialized
DEBUG - 2010-06-21 08:57:21 --> Router Class Initialized
DEBUG - 2010-06-21 08:57:21 --> Output Class Initialized
DEBUG - 2010-06-21 08:57:21 --> Input Class Initialized
DEBUG - 2010-06-21 08:57:21 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 08:57:21 --> Language Class Initialized
DEBUG - 2010-06-21 08:57:21 --> Loader Class Initialized
DEBUG - 2010-06-21 08:57:21 --> Controller Class Initialized
DEBUG - 2010-06-21 08:57:21 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 08:57:22 --> Session Class Initialized
DEBUG - 2010-06-21 08:57:22 --> Helper loaded: string_helper
DEBUG - 2010-06-21 08:57:22 --> A session cookie was not found.
DEBUG - 2010-06-21 08:57:22 --> Session routines successfully run
DEBUG - 2010-06-21 08:57:22 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 08:57:22 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 08:57:22 --> Database Driver Class Initialized
DEBUG - 2010-06-21 08:57:22 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-21 08:59:15 --> Config Class Initialized
DEBUG - 2010-06-21 08:59:15 --> Hooks Class Initialized
DEBUG - 2010-06-21 08:59:15 --> URI Class Initialized
DEBUG - 2010-06-21 08:59:15 --> Router Class Initialized
DEBUG - 2010-06-21 08:59:15 --> Output Class Initialized
DEBUG - 2010-06-21 08:59:15 --> Input Class Initialized
DEBUG - 2010-06-21 08:59:15 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 08:59:15 --> Language Class Initialized
DEBUG - 2010-06-21 08:59:15 --> Loader Class Initialized
DEBUG - 2010-06-21 08:59:15 --> Controller Class Initialized
DEBUG - 2010-06-21 08:59:15 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 08:59:15 --> Session Class Initialized
DEBUG - 2010-06-21 08:59:15 --> Helper loaded: string_helper
DEBUG - 2010-06-21 08:59:15 --> Session routines successfully run
DEBUG - 2010-06-21 08:59:15 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 08:59:15 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 08:59:15 --> Database Driver Class Initialized
DEBUG - 2010-06-21 08:59:15 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-21 08:59:38 --> Config Class Initialized
DEBUG - 2010-06-21 08:59:38 --> Hooks Class Initialized
DEBUG - 2010-06-21 08:59:38 --> URI Class Initialized
DEBUG - 2010-06-21 08:59:38 --> Router Class Initialized
DEBUG - 2010-06-21 08:59:38 --> Output Class Initialized
DEBUG - 2010-06-21 08:59:38 --> Input Class Initialized
DEBUG - 2010-06-21 08:59:38 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 08:59:38 --> Language Class Initialized
DEBUG - 2010-06-21 08:59:38 --> Loader Class Initialized
DEBUG - 2010-06-21 08:59:38 --> Controller Class Initialized
DEBUG - 2010-06-21 08:59:38 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 08:59:38 --> Session Class Initialized
DEBUG - 2010-06-21 08:59:38 --> Helper loaded: string_helper
DEBUG - 2010-06-21 08:59:38 --> Session routines successfully run
DEBUG - 2010-06-21 08:59:38 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 08:59:38 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 08:59:38 --> Database Driver Class Initialized
DEBUG - 2010-06-21 08:59:38 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-21 08:59:38 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-21 08:59:38 --> Final output sent to browser
DEBUG - 2010-06-21 08:59:38 --> Total execution time: 0.1154
DEBUG - 2010-06-21 09:11:10 --> Config Class Initialized
DEBUG - 2010-06-21 09:11:10 --> Hooks Class Initialized
DEBUG - 2010-06-21 09:11:10 --> URI Class Initialized
DEBUG - 2010-06-21 09:11:10 --> Router Class Initialized
DEBUG - 2010-06-21 09:11:10 --> Output Class Initialized
DEBUG - 2010-06-21 09:11:10 --> Input Class Initialized
DEBUG - 2010-06-21 09:11:10 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 09:11:10 --> Language Class Initialized
DEBUG - 2010-06-21 09:11:10 --> Loader Class Initialized
DEBUG - 2010-06-21 09:11:10 --> Controller Class Initialized
DEBUG - 2010-06-21 09:11:10 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 09:11:10 --> Session Class Initialized
DEBUG - 2010-06-21 09:11:10 --> Helper loaded: string_helper
DEBUG - 2010-06-21 09:11:10 --> Session routines successfully run
DEBUG - 2010-06-21 09:11:10 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 09:11:10 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:11:10 --> Database Driver Class Initialized
DEBUG - 2010-06-21 09:11:10 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-21 09:11:10 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-21 09:11:10 --> Final output sent to browser
DEBUG - 2010-06-21 09:11:10 --> Total execution time: 0.1813
DEBUG - 2010-06-21 09:11:13 --> Config Class Initialized
DEBUG - 2010-06-21 09:11:13 --> Hooks Class Initialized
DEBUG - 2010-06-21 09:11:13 --> URI Class Initialized
DEBUG - 2010-06-21 09:11:13 --> Router Class Initialized
DEBUG - 2010-06-21 09:11:13 --> Output Class Initialized
DEBUG - 2010-06-21 09:11:13 --> Input Class Initialized
DEBUG - 2010-06-21 09:11:13 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 09:11:13 --> Language Class Initialized
DEBUG - 2010-06-21 09:11:13 --> Loader Class Initialized
DEBUG - 2010-06-21 09:11:13 --> Controller Class Initialized
DEBUG - 2010-06-21 09:11:13 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 09:11:13 --> Session Class Initialized
DEBUG - 2010-06-21 09:11:13 --> Helper loaded: string_helper
DEBUG - 2010-06-21 09:11:13 --> Session routines successfully run
DEBUG - 2010-06-21 09:11:13 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 09:11:13 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:11:13 --> Database Driver Class Initialized
DEBUG - 2010-06-21 09:11:13 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-21 09:11:13 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-21 09:11:13 --> Final output sent to browser
DEBUG - 2010-06-21 09:11:13 --> Total execution time: 0.1362
DEBUG - 2010-06-21 09:11:25 --> Config Class Initialized
DEBUG - 2010-06-21 09:11:25 --> Hooks Class Initialized
DEBUG - 2010-06-21 09:11:25 --> URI Class Initialized
DEBUG - 2010-06-21 09:11:25 --> Router Class Initialized
DEBUG - 2010-06-21 09:11:25 --> Output Class Initialized
DEBUG - 2010-06-21 09:11:25 --> Input Class Initialized
DEBUG - 2010-06-21 09:11:25 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 09:11:25 --> Language Class Initialized
DEBUG - 2010-06-21 09:11:25 --> Loader Class Initialized
DEBUG - 2010-06-21 09:11:25 --> Controller Class Initialized
DEBUG - 2010-06-21 09:11:25 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 09:11:25 --> Session Class Initialized
DEBUG - 2010-06-21 09:11:25 --> Helper loaded: string_helper
DEBUG - 2010-06-21 09:11:25 --> Session routines successfully run
DEBUG - 2010-06-21 09:11:25 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 09:11:25 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:11:25 --> Database Driver Class Initialized
DEBUG - 2010-06-21 09:11:25 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-21 09:11:25 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-21 09:11:25 --> Final output sent to browser
DEBUG - 2010-06-21 09:11:25 --> Total execution time: 0.1467
DEBUG - 2010-06-21 09:11:55 --> Config Class Initialized
DEBUG - 2010-06-21 09:11:55 --> Hooks Class Initialized
DEBUG - 2010-06-21 09:11:55 --> URI Class Initialized
DEBUG - 2010-06-21 09:11:55 --> Router Class Initialized
DEBUG - 2010-06-21 09:11:55 --> Output Class Initialized
DEBUG - 2010-06-21 09:11:55 --> Input Class Initialized
DEBUG - 2010-06-21 09:11:55 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 09:11:55 --> Language Class Initialized
DEBUG - 2010-06-21 09:11:55 --> Loader Class Initialized
DEBUG - 2010-06-21 09:11:55 --> Controller Class Initialized
DEBUG - 2010-06-21 09:11:55 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 09:11:55 --> Session Class Initialized
DEBUG - 2010-06-21 09:11:55 --> Helper loaded: string_helper
DEBUG - 2010-06-21 09:11:55 --> Session routines successfully run
DEBUG - 2010-06-21 09:11:55 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 09:11:55 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:11:55 --> Database Driver Class Initialized
DEBUG - 2010-06-21 09:11:55 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-21 09:11:55 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-21 09:11:55 --> Final output sent to browser
DEBUG - 2010-06-21 09:11:55 --> Total execution time: 0.1888
DEBUG - 2010-06-21 09:34:38 --> Config Class Initialized
DEBUG - 2010-06-21 09:34:38 --> Hooks Class Initialized
DEBUG - 2010-06-21 09:34:38 --> URI Class Initialized
DEBUG - 2010-06-21 09:34:38 --> Router Class Initialized
DEBUG - 2010-06-21 09:34:38 --> Output Class Initialized
DEBUG - 2010-06-21 09:34:38 --> Input Class Initialized
DEBUG - 2010-06-21 09:34:38 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 09:34:38 --> Language Class Initialized
DEBUG - 2010-06-21 09:34:38 --> Loader Class Initialized
DEBUG - 2010-06-21 09:34:38 --> Controller Class Initialized
DEBUG - 2010-06-21 09:34:38 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 09:34:38 --> Helper loaded: context_helper
ERROR - 2010-06-21 09:34:38 --> Severity: Notice  --> Undefined variable: CI D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 20
ERROR - 2010-06-21 09:34:38 --> Severity: Notice  --> Object of class Ut_domain could not be converted to int D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 20
ERROR - 2010-06-21 09:34:38 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 21
DEBUG - 2010-06-21 09:35:48 --> Config Class Initialized
DEBUG - 2010-06-21 09:35:48 --> Hooks Class Initialized
DEBUG - 2010-06-21 09:35:48 --> URI Class Initialized
DEBUG - 2010-06-21 09:35:48 --> Router Class Initialized
DEBUG - 2010-06-21 09:35:48 --> Output Class Initialized
DEBUG - 2010-06-21 09:35:49 --> Input Class Initialized
DEBUG - 2010-06-21 09:35:49 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 09:35:49 --> Language Class Initialized
DEBUG - 2010-06-21 09:35:49 --> Loader Class Initialized
DEBUG - 2010-06-21 09:35:49 --> Controller Class Initialized
DEBUG - 2010-06-21 09:35:49 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 09:35:49 --> Helper loaded: context_helper
DEBUG - 2010-06-21 09:35:49 --> Session Class Initialized
DEBUG - 2010-06-21 09:35:49 --> Helper loaded: string_helper
DEBUG - 2010-06-21 09:35:49 --> Session routines successfully run
DEBUG - 2010-06-21 09:35:49 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 09:35:49 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:35:49 --> Database Driver Class Initialized
DEBUG - 2010-06-21 09:35:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:35:49 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-21 09:36:32 --> Config Class Initialized
DEBUG - 2010-06-21 09:36:32 --> Hooks Class Initialized
DEBUG - 2010-06-21 09:36:32 --> URI Class Initialized
DEBUG - 2010-06-21 09:36:32 --> Router Class Initialized
DEBUG - 2010-06-21 09:36:32 --> Output Class Initialized
DEBUG - 2010-06-21 09:36:32 --> Input Class Initialized
DEBUG - 2010-06-21 09:36:32 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 09:36:32 --> Language Class Initialized
DEBUG - 2010-06-21 09:36:32 --> Loader Class Initialized
DEBUG - 2010-06-21 09:36:32 --> Controller Class Initialized
DEBUG - 2010-06-21 09:36:32 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 09:36:32 --> Helper loaded: context_helper
DEBUG - 2010-06-21 09:36:32 --> Session Class Initialized
DEBUG - 2010-06-21 09:36:32 --> Helper loaded: string_helper
DEBUG - 2010-06-21 09:36:32 --> Session routines successfully run
DEBUG - 2010-06-21 09:36:32 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 09:36:32 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:36:32 --> Database Driver Class Initialized
DEBUG - 2010-06-21 09:36:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:36:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:36:32 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-21 09:36:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:36:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:36:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:36:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:36:32 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-21 09:36:32 --> Final output sent to browser
DEBUG - 2010-06-21 09:36:32 --> Total execution time: 0.2371
DEBUG - 2010-06-21 09:37:55 --> Config Class Initialized
DEBUG - 2010-06-21 09:37:55 --> Hooks Class Initialized
DEBUG - 2010-06-21 09:37:55 --> URI Class Initialized
DEBUG - 2010-06-21 09:37:55 --> Router Class Initialized
DEBUG - 2010-06-21 09:37:55 --> Output Class Initialized
DEBUG - 2010-06-21 09:37:55 --> Input Class Initialized
DEBUG - 2010-06-21 09:37:55 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 09:37:55 --> Language Class Initialized
DEBUG - 2010-06-21 09:37:55 --> Loader Class Initialized
DEBUG - 2010-06-21 09:37:55 --> Controller Class Initialized
DEBUG - 2010-06-21 09:37:55 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 09:37:55 --> Helper loaded: context_helper
DEBUG - 2010-06-21 09:37:55 --> Session Class Initialized
DEBUG - 2010-06-21 09:37:55 --> Helper loaded: string_helper
DEBUG - 2010-06-21 09:37:55 --> Session routines successfully run
DEBUG - 2010-06-21 09:37:55 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 09:37:55 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:37:56 --> Database Driver Class Initialized
DEBUG - 2010-06-21 09:37:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:37:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:37:56 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-21 09:37:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:37:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:37:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:37:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:37:56 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-21 09:37:56 --> Final output sent to browser
DEBUG - 2010-06-21 09:37:56 --> Total execution time: 0.2592
DEBUG - 2010-06-21 09:38:23 --> Config Class Initialized
DEBUG - 2010-06-21 09:38:23 --> Hooks Class Initialized
DEBUG - 2010-06-21 09:38:23 --> URI Class Initialized
DEBUG - 2010-06-21 09:38:23 --> Router Class Initialized
DEBUG - 2010-06-21 09:38:23 --> Output Class Initialized
DEBUG - 2010-06-21 09:38:23 --> Input Class Initialized
DEBUG - 2010-06-21 09:38:23 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 09:38:23 --> Language Class Initialized
DEBUG - 2010-06-21 09:38:23 --> Loader Class Initialized
DEBUG - 2010-06-21 09:38:23 --> Controller Class Initialized
DEBUG - 2010-06-21 09:38:23 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 09:38:23 --> Helper loaded: context_helper
DEBUG - 2010-06-21 09:38:23 --> Session Class Initialized
DEBUG - 2010-06-21 09:38:23 --> Helper loaded: string_helper
DEBUG - 2010-06-21 09:38:23 --> Session routines successfully run
DEBUG - 2010-06-21 09:38:23 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 09:38:23 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:38:23 --> Database Driver Class Initialized
DEBUG - 2010-06-21 09:38:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:38:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:38:23 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-21 09:38:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:38:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:38:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:38:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:38:23 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-21 09:38:23 --> Final output sent to browser
DEBUG - 2010-06-21 09:38:23 --> Total execution time: 0.2935
DEBUG - 2010-06-21 09:38:42 --> Config Class Initialized
DEBUG - 2010-06-21 09:38:42 --> Hooks Class Initialized
DEBUG - 2010-06-21 09:38:42 --> URI Class Initialized
DEBUG - 2010-06-21 09:38:42 --> Router Class Initialized
DEBUG - 2010-06-21 09:38:42 --> Output Class Initialized
DEBUG - 2010-06-21 09:38:42 --> Input Class Initialized
DEBUG - 2010-06-21 09:38:42 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 09:38:42 --> Language Class Initialized
DEBUG - 2010-06-21 09:38:42 --> Loader Class Initialized
DEBUG - 2010-06-21 09:38:42 --> Controller Class Initialized
DEBUG - 2010-06-21 09:38:42 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 09:38:42 --> Helper loaded: context_helper
DEBUG - 2010-06-21 09:38:42 --> Session Class Initialized
DEBUG - 2010-06-21 09:38:42 --> Helper loaded: string_helper
DEBUG - 2010-06-21 09:38:42 --> Session routines successfully run
DEBUG - 2010-06-21 09:38:42 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 09:38:42 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:38:42 --> Database Driver Class Initialized
DEBUG - 2010-06-21 09:38:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:38:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:38:42 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-21 09:38:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:38:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:38:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:38:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:38:42 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-21 09:38:42 --> Final output sent to browser
DEBUG - 2010-06-21 09:38:42 --> Total execution time: 0.2978
DEBUG - 2010-06-21 09:40:25 --> Config Class Initialized
DEBUG - 2010-06-21 09:40:25 --> Hooks Class Initialized
DEBUG - 2010-06-21 09:40:25 --> URI Class Initialized
DEBUG - 2010-06-21 09:40:25 --> Router Class Initialized
DEBUG - 2010-06-21 09:40:25 --> Output Class Initialized
DEBUG - 2010-06-21 09:40:25 --> Input Class Initialized
DEBUG - 2010-06-21 09:40:25 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 09:40:25 --> Language Class Initialized
DEBUG - 2010-06-21 09:40:25 --> Loader Class Initialized
DEBUG - 2010-06-21 09:40:25 --> Controller Class Initialized
DEBUG - 2010-06-21 09:40:25 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 09:40:25 --> Helper loaded: context_helper
DEBUG - 2010-06-21 09:40:25 --> Session Class Initialized
DEBUG - 2010-06-21 09:40:25 --> Helper loaded: string_helper
DEBUG - 2010-06-21 09:40:25 --> Session routines successfully run
DEBUG - 2010-06-21 09:40:25 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 09:40:25 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:40:25 --> Database Driver Class Initialized
DEBUG - 2010-06-21 09:40:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:40:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:40:25 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-21 09:40:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:40:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:40:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:40:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:40:25 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-21 09:40:25 --> Final output sent to browser
DEBUG - 2010-06-21 09:40:25 --> Total execution time: 0.3120
DEBUG - 2010-06-21 09:40:56 --> Config Class Initialized
DEBUG - 2010-06-21 09:40:56 --> Hooks Class Initialized
DEBUG - 2010-06-21 09:40:56 --> URI Class Initialized
DEBUG - 2010-06-21 09:40:56 --> Router Class Initialized
DEBUG - 2010-06-21 09:40:56 --> Output Class Initialized
DEBUG - 2010-06-21 09:40:56 --> Input Class Initialized
DEBUG - 2010-06-21 09:40:56 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 09:40:56 --> Language Class Initialized
DEBUG - 2010-06-21 09:40:56 --> Loader Class Initialized
DEBUG - 2010-06-21 09:40:56 --> Controller Class Initialized
DEBUG - 2010-06-21 09:40:56 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 09:40:56 --> Helper loaded: context_helper
DEBUG - 2010-06-21 09:40:56 --> Session Class Initialized
DEBUG - 2010-06-21 09:40:56 --> Helper loaded: string_helper
DEBUG - 2010-06-21 09:40:56 --> Session routines successfully run
DEBUG - 2010-06-21 09:40:56 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 09:40:56 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:40:56 --> Database Driver Class Initialized
DEBUG - 2010-06-21 09:40:56 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:40:56 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 73
DEBUG - 2010-06-21 09:40:56 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:40:56 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 73
DEBUG - 2010-06-21 09:40:56 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-21 09:40:56 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:40:56 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 73
DEBUG - 2010-06-21 09:40:56 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:40:56 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 73
DEBUG - 2010-06-21 09:40:56 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:40:56 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 73
DEBUG - 2010-06-21 09:40:56 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:40:56 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 73
DEBUG - 2010-06-21 09:40:56 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-21 09:40:56 --> Final output sent to browser
DEBUG - 2010-06-21 09:40:56 --> Total execution time: 0.3980
DEBUG - 2010-06-21 09:41:55 --> Config Class Initialized
DEBUG - 2010-06-21 09:41:55 --> Hooks Class Initialized
DEBUG - 2010-06-21 09:41:56 --> URI Class Initialized
DEBUG - 2010-06-21 09:41:56 --> Router Class Initialized
DEBUG - 2010-06-21 09:41:56 --> Output Class Initialized
DEBUG - 2010-06-21 09:41:56 --> Input Class Initialized
DEBUG - 2010-06-21 09:41:56 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 09:41:56 --> Language Class Initialized
DEBUG - 2010-06-21 09:41:56 --> Loader Class Initialized
DEBUG - 2010-06-21 09:41:56 --> Controller Class Initialized
DEBUG - 2010-06-21 09:41:56 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 09:41:56 --> Helper loaded: context_helper
DEBUG - 2010-06-21 09:41:56 --> Session Class Initialized
DEBUG - 2010-06-21 09:41:56 --> Helper loaded: string_helper
DEBUG - 2010-06-21 09:41:56 --> Session routines successfully run
DEBUG - 2010-06-21 09:41:56 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 09:41:56 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:41:56 --> Database Driver Class Initialized
DEBUG - 2010-06-21 09:41:56 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:41:56 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 73
DEBUG - 2010-06-21 09:41:56 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:41:56 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 73
DEBUG - 2010-06-21 09:41:56 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-21 09:41:56 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:41:56 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 73
DEBUG - 2010-06-21 09:41:56 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:41:56 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 73
DEBUG - 2010-06-21 09:41:56 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:41:56 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 73
DEBUG - 2010-06-21 09:41:56 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:41:56 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 73
DEBUG - 2010-06-21 09:41:56 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-21 09:41:56 --> Final output sent to browser
DEBUG - 2010-06-21 09:41:56 --> Total execution time: 0.4129
DEBUG - 2010-06-21 09:42:36 --> Config Class Initialized
DEBUG - 2010-06-21 09:42:36 --> Hooks Class Initialized
DEBUG - 2010-06-21 09:42:36 --> URI Class Initialized
DEBUG - 2010-06-21 09:42:36 --> Router Class Initialized
DEBUG - 2010-06-21 09:42:36 --> Output Class Initialized
DEBUG - 2010-06-21 09:42:36 --> Input Class Initialized
DEBUG - 2010-06-21 09:42:36 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 09:42:36 --> Language Class Initialized
DEBUG - 2010-06-21 09:42:36 --> Loader Class Initialized
DEBUG - 2010-06-21 09:42:36 --> Controller Class Initialized
DEBUG - 2010-06-21 09:42:36 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 09:42:36 --> Helper loaded: context_helper
DEBUG - 2010-06-21 09:42:36 --> Session Class Initialized
DEBUG - 2010-06-21 09:42:36 --> Helper loaded: string_helper
DEBUG - 2010-06-21 09:42:36 --> Session routines successfully run
DEBUG - 2010-06-21 09:42:36 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 09:42:36 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:42:36 --> Database Driver Class Initialized
DEBUG - 2010-06-21 09:42:36 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:42:36 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 73
DEBUG - 2010-06-21 09:42:36 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:42:36 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 73
DEBUG - 2010-06-21 09:42:36 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-21 09:42:36 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:42:36 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 73
DEBUG - 2010-06-21 09:42:36 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:42:36 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 73
DEBUG - 2010-06-21 09:42:36 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:42:36 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 73
DEBUG - 2010-06-21 09:42:36 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:42:36 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 73
DEBUG - 2010-06-21 09:42:36 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-21 09:42:36 --> Final output sent to browser
DEBUG - 2010-06-21 09:42:36 --> Total execution time: 0.4525
DEBUG - 2010-06-21 09:43:18 --> Config Class Initialized
DEBUG - 2010-06-21 09:43:18 --> Hooks Class Initialized
DEBUG - 2010-06-21 09:43:19 --> URI Class Initialized
DEBUG - 2010-06-21 09:43:19 --> Router Class Initialized
DEBUG - 2010-06-21 09:43:19 --> Output Class Initialized
DEBUG - 2010-06-21 09:43:19 --> Input Class Initialized
DEBUG - 2010-06-21 09:43:19 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 09:43:19 --> Language Class Initialized
DEBUG - 2010-06-21 09:43:19 --> Loader Class Initialized
DEBUG - 2010-06-21 09:43:19 --> Controller Class Initialized
DEBUG - 2010-06-21 09:43:19 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 09:43:19 --> Helper loaded: context_helper
DEBUG - 2010-06-21 09:43:19 --> Session Class Initialized
DEBUG - 2010-06-21 09:43:19 --> Helper loaded: string_helper
DEBUG - 2010-06-21 09:43:19 --> Session routines successfully run
DEBUG - 2010-06-21 09:43:19 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 09:43:19 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:43:19 --> Database Driver Class Initialized
DEBUG - 2010-06-21 09:43:19 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:43:19 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 73
DEBUG - 2010-06-21 09:43:19 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:43:19 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 73
DEBUG - 2010-06-21 09:43:19 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-21 09:43:19 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:43:19 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 73
DEBUG - 2010-06-21 09:43:19 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:43:19 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 73
DEBUG - 2010-06-21 09:43:19 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:43:19 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 73
DEBUG - 2010-06-21 09:43:19 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:43:19 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 73
DEBUG - 2010-06-21 09:43:19 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-21 09:43:19 --> Final output sent to browser
DEBUG - 2010-06-21 09:43:19 --> Total execution time: 0.5262
DEBUG - 2010-06-21 09:43:26 --> Config Class Initialized
DEBUG - 2010-06-21 09:43:26 --> Hooks Class Initialized
DEBUG - 2010-06-21 09:43:26 --> URI Class Initialized
DEBUG - 2010-06-21 09:43:26 --> Router Class Initialized
DEBUG - 2010-06-21 09:43:26 --> Output Class Initialized
DEBUG - 2010-06-21 09:43:26 --> Input Class Initialized
DEBUG - 2010-06-21 09:43:26 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 09:43:26 --> Language Class Initialized
DEBUG - 2010-06-21 09:43:26 --> Loader Class Initialized
DEBUG - 2010-06-21 09:43:26 --> Controller Class Initialized
DEBUG - 2010-06-21 09:43:26 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 09:43:26 --> Helper loaded: context_helper
DEBUG - 2010-06-21 09:43:26 --> Session Class Initialized
DEBUG - 2010-06-21 09:43:26 --> Helper loaded: string_helper
DEBUG - 2010-06-21 09:43:26 --> Session routines successfully run
DEBUG - 2010-06-21 09:43:26 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 09:43:26 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:43:26 --> Database Driver Class Initialized
DEBUG - 2010-06-21 09:43:26 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:43:26 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 73
DEBUG - 2010-06-21 09:43:26 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:43:26 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 73
DEBUG - 2010-06-21 09:43:26 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-21 09:43:26 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:43:26 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 73
DEBUG - 2010-06-21 09:43:26 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:43:26 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 73
DEBUG - 2010-06-21 09:43:26 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:43:27 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 73
DEBUG - 2010-06-21 09:43:27 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:43:27 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 73
DEBUG - 2010-06-21 09:43:27 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-21 09:43:27 --> Final output sent to browser
DEBUG - 2010-06-21 09:43:27 --> Total execution time: 0.4993
DEBUG - 2010-06-21 09:44:34 --> Config Class Initialized
DEBUG - 2010-06-21 09:44:34 --> Hooks Class Initialized
DEBUG - 2010-06-21 09:44:34 --> URI Class Initialized
DEBUG - 2010-06-21 09:44:34 --> Router Class Initialized
DEBUG - 2010-06-21 09:44:34 --> Output Class Initialized
DEBUG - 2010-06-21 09:44:34 --> Input Class Initialized
DEBUG - 2010-06-21 09:44:34 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 09:44:34 --> Language Class Initialized
DEBUG - 2010-06-21 09:44:34 --> Loader Class Initialized
DEBUG - 2010-06-21 09:44:34 --> Controller Class Initialized
DEBUG - 2010-06-21 09:44:34 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 09:44:34 --> Helper loaded: context_helper
DEBUG - 2010-06-21 09:44:34 --> Session Class Initialized
DEBUG - 2010-06-21 09:44:34 --> Helper loaded: string_helper
DEBUG - 2010-06-21 09:44:34 --> Session routines successfully run
DEBUG - 2010-06-21 09:44:34 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 09:44:34 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:44:34 --> Database Driver Class Initialized
DEBUG - 2010-06-21 09:44:34 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:44:34 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 74
DEBUG - 2010-06-21 09:44:34 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:44:34 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 74
DEBUG - 2010-06-21 09:44:34 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-21 09:44:34 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:44:34 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 74
DEBUG - 2010-06-21 09:44:34 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:44:35 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 74
DEBUG - 2010-06-21 09:44:35 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:44:35 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 74
DEBUG - 2010-06-21 09:44:35 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:44:35 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 74
DEBUG - 2010-06-21 09:44:35 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-21 09:44:35 --> Final output sent to browser
DEBUG - 2010-06-21 09:44:35 --> Total execution time: 0.5422
DEBUG - 2010-06-21 09:45:58 --> Config Class Initialized
DEBUG - 2010-06-21 09:45:58 --> Hooks Class Initialized
DEBUG - 2010-06-21 09:45:58 --> URI Class Initialized
DEBUG - 2010-06-21 09:45:58 --> Router Class Initialized
DEBUG - 2010-06-21 09:45:58 --> Output Class Initialized
DEBUG - 2010-06-21 09:45:58 --> Input Class Initialized
DEBUG - 2010-06-21 09:45:58 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 09:45:58 --> Language Class Initialized
DEBUG - 2010-06-21 09:45:58 --> Loader Class Initialized
DEBUG - 2010-06-21 09:45:58 --> Controller Class Initialized
DEBUG - 2010-06-21 09:45:58 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 09:45:58 --> Helper loaded: context_helper
DEBUG - 2010-06-21 09:45:58 --> Session Class Initialized
DEBUG - 2010-06-21 09:45:58 --> Helper loaded: string_helper
DEBUG - 2010-06-21 09:45:58 --> Session routines successfully run
DEBUG - 2010-06-21 09:45:58 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 09:45:58 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:45:58 --> Database Driver Class Initialized
DEBUG - 2010-06-21 09:45:58 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:45:59 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 76
DEBUG - 2010-06-21 09:45:59 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:45:59 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 76
DEBUG - 2010-06-21 09:45:59 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-21 09:45:59 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:45:59 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 76
DEBUG - 2010-06-21 09:45:59 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:45:59 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 76
DEBUG - 2010-06-21 09:45:59 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:45:59 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 76
DEBUG - 2010-06-21 09:45:59 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:45:59 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 76
DEBUG - 2010-06-21 09:45:59 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-21 09:45:59 --> Final output sent to browser
DEBUG - 2010-06-21 09:45:59 --> Total execution time: 0.5521
DEBUG - 2010-06-21 09:47:07 --> Config Class Initialized
DEBUG - 2010-06-21 09:47:07 --> Hooks Class Initialized
DEBUG - 2010-06-21 09:47:07 --> URI Class Initialized
DEBUG - 2010-06-21 09:47:07 --> Router Class Initialized
DEBUG - 2010-06-21 09:47:07 --> Output Class Initialized
DEBUG - 2010-06-21 09:47:07 --> Input Class Initialized
DEBUG - 2010-06-21 09:47:07 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 09:47:07 --> Language Class Initialized
DEBUG - 2010-06-21 09:47:07 --> Loader Class Initialized
DEBUG - 2010-06-21 09:47:07 --> Controller Class Initialized
DEBUG - 2010-06-21 09:47:07 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 09:47:07 --> Helper loaded: context_helper
DEBUG - 2010-06-21 09:47:07 --> Session Class Initialized
DEBUG - 2010-06-21 09:47:07 --> Helper loaded: string_helper
DEBUG - 2010-06-21 09:47:07 --> Session routines successfully run
DEBUG - 2010-06-21 09:47:07 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 09:47:07 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:47:07 --> Database Driver Class Initialized
DEBUG - 2010-06-21 09:47:07 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:47:07 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 76
DEBUG - 2010-06-21 09:47:07 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:47:07 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 76
DEBUG - 2010-06-21 09:47:07 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-21 09:47:07 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:47:07 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 76
DEBUG - 2010-06-21 09:47:07 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:47:07 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 76
DEBUG - 2010-06-21 09:47:07 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:47:07 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 76
DEBUG - 2010-06-21 09:47:07 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:47:07 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 76
DEBUG - 2010-06-21 09:47:07 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-21 09:47:07 --> Final output sent to browser
DEBUG - 2010-06-21 09:47:07 --> Total execution time: 0.5888
DEBUG - 2010-06-21 09:47:23 --> Config Class Initialized
DEBUG - 2010-06-21 09:47:23 --> Hooks Class Initialized
DEBUG - 2010-06-21 09:47:23 --> URI Class Initialized
DEBUG - 2010-06-21 09:47:23 --> Router Class Initialized
DEBUG - 2010-06-21 09:47:23 --> Output Class Initialized
DEBUG - 2010-06-21 09:47:23 --> Input Class Initialized
DEBUG - 2010-06-21 09:47:23 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 09:47:23 --> Language Class Initialized
DEBUG - 2010-06-21 09:47:23 --> Loader Class Initialized
DEBUG - 2010-06-21 09:47:23 --> Controller Class Initialized
DEBUG - 2010-06-21 09:47:23 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 09:47:23 --> Helper loaded: context_helper
DEBUG - 2010-06-21 09:47:23 --> Session Class Initialized
DEBUG - 2010-06-21 09:47:23 --> Helper loaded: string_helper
DEBUG - 2010-06-21 09:47:23 --> Session routines successfully run
DEBUG - 2010-06-21 09:47:23 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 09:47:23 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:47:23 --> Database Driver Class Initialized
DEBUG - 2010-06-21 09:47:23 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:47:23 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 76
DEBUG - 2010-06-21 09:47:23 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:47:23 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 76
DEBUG - 2010-06-21 09:47:23 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-21 09:47:23 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:47:23 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 76
DEBUG - 2010-06-21 09:47:23 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:47:24 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 76
DEBUG - 2010-06-21 09:47:24 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:47:24 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 76
DEBUG - 2010-06-21 09:47:24 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:47:24 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 76
DEBUG - 2010-06-21 09:47:24 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-21 09:47:24 --> Final output sent to browser
DEBUG - 2010-06-21 09:47:24 --> Total execution time: 0.6157
DEBUG - 2010-06-21 09:48:42 --> Config Class Initialized
DEBUG - 2010-06-21 09:48:42 --> Hooks Class Initialized
DEBUG - 2010-06-21 09:48:42 --> URI Class Initialized
DEBUG - 2010-06-21 09:48:42 --> Router Class Initialized
DEBUG - 2010-06-21 09:48:42 --> Output Class Initialized
DEBUG - 2010-06-21 09:48:42 --> Input Class Initialized
DEBUG - 2010-06-21 09:48:42 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 09:48:42 --> Language Class Initialized
DEBUG - 2010-06-21 09:48:42 --> Loader Class Initialized
DEBUG - 2010-06-21 09:48:42 --> Controller Class Initialized
DEBUG - 2010-06-21 09:48:42 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 09:48:42 --> Helper loaded: context_helper
DEBUG - 2010-06-21 09:48:42 --> Session Class Initialized
DEBUG - 2010-06-21 09:48:42 --> Helper loaded: string_helper
DEBUG - 2010-06-21 09:48:43 --> Session routines successfully run
DEBUG - 2010-06-21 09:48:43 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 09:48:43 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:48:43 --> Database Driver Class Initialized
DEBUG - 2010-06-21 09:48:43 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:48:43 --> Severity: Notice  --> Undefined variable: context D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 81
DEBUG - 2010-06-21 09:50:01 --> Config Class Initialized
DEBUG - 2010-06-21 09:50:01 --> Hooks Class Initialized
DEBUG - 2010-06-21 09:50:01 --> URI Class Initialized
DEBUG - 2010-06-21 09:50:01 --> Router Class Initialized
DEBUG - 2010-06-21 09:50:01 --> Output Class Initialized
DEBUG - 2010-06-21 09:50:01 --> Input Class Initialized
DEBUG - 2010-06-21 09:50:01 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 09:50:01 --> Language Class Initialized
DEBUG - 2010-06-21 09:50:01 --> Loader Class Initialized
DEBUG - 2010-06-21 09:50:01 --> Controller Class Initialized
DEBUG - 2010-06-21 09:50:01 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 09:50:01 --> Helper loaded: context_helper
DEBUG - 2010-06-21 09:50:01 --> Session Class Initialized
DEBUG - 2010-06-21 09:50:01 --> Helper loaded: string_helper
DEBUG - 2010-06-21 09:50:01 --> Session routines successfully run
DEBUG - 2010-06-21 09:50:01 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 09:50:01 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:50:01 --> Database Driver Class Initialized
DEBUG - 2010-06-21 09:50:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:50:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:50:01 --> Language file loaded: language/english/unit_test_lang.php
ERROR - 2010-06-21 09:50:01 --> Severity: Warning  --> Missing argument 1 for Context::get_cache(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php on line 89 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 102
ERROR - 2010-06-21 09:50:01 --> Severity: Warning  --> Missing argument 2 for Context::get_cache(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php on line 89 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 102
ERROR - 2010-06-21 09:50:01 --> Severity: Notice  --> Undefined variable: type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 104
ERROR - 2010-06-21 09:50:01 --> Severity: Notice  --> Undefined variable: type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 107
ERROR - 2010-06-21 09:50:01 --> Severity: Notice  --> Undefined variable: type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 115
ERROR - 2010-06-21 09:50:01 --> Severity: Notice  --> Undefined variable: key D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 115
DEBUG - 2010-06-21 09:50:02 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:50:02 --> Severity: Warning  --> Missing argument 1 for Context::get_cache(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php on line 89 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 102
ERROR - 2010-06-21 09:50:02 --> Severity: Warning  --> Missing argument 2 for Context::get_cache(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php on line 89 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 102
ERROR - 2010-06-21 09:50:02 --> Severity: Notice  --> Undefined variable: type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 104
ERROR - 2010-06-21 09:50:02 --> Severity: Notice  --> Undefined variable: type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 107
ERROR - 2010-06-21 09:50:02 --> Severity: Notice  --> Undefined variable: type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 115
ERROR - 2010-06-21 09:50:02 --> Severity: Notice  --> Undefined variable: key D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 115
DEBUG - 2010-06-21 09:50:02 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:50:02 --> Severity: Warning  --> Missing argument 1 for Context::get_cache(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php on line 89 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 102
ERROR - 2010-06-21 09:50:02 --> Severity: Warning  --> Missing argument 2 for Context::get_cache(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php on line 89 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 102
ERROR - 2010-06-21 09:50:02 --> Severity: Notice  --> Undefined variable: type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 104
ERROR - 2010-06-21 09:50:02 --> Severity: Notice  --> Undefined variable: type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 107
ERROR - 2010-06-21 09:50:02 --> Severity: Notice  --> Undefined variable: type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 115
ERROR - 2010-06-21 09:50:02 --> Severity: Notice  --> Undefined variable: key D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 115
DEBUG - 2010-06-21 09:50:02 --> Domain class already loaded. Second attempt ignored.
ERROR - 2010-06-21 09:50:02 --> Severity: Warning  --> Missing argument 1 for Context::get_cache(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php on line 89 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 102
ERROR - 2010-06-21 09:50:02 --> Severity: Warning  --> Missing argument 2 for Context::get_cache(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php on line 89 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 102
ERROR - 2010-06-21 09:50:02 --> Severity: Notice  --> Undefined variable: type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 104
ERROR - 2010-06-21 09:50:02 --> Severity: Notice  --> Undefined variable: type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 107
ERROR - 2010-06-21 09:50:02 --> Severity: Notice  --> Undefined variable: type D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 115
ERROR - 2010-06-21 09:50:02 --> Severity: Notice  --> Undefined variable: key D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 115
DEBUG - 2010-06-21 09:50:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:50:02 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-21 09:50:02 --> Final output sent to browser
DEBUG - 2010-06-21 09:50:02 --> Total execution time: 0.9910
DEBUG - 2010-06-21 09:51:10 --> Config Class Initialized
DEBUG - 2010-06-21 09:51:10 --> Hooks Class Initialized
DEBUG - 2010-06-21 09:51:10 --> URI Class Initialized
DEBUG - 2010-06-21 09:51:10 --> Router Class Initialized
DEBUG - 2010-06-21 09:51:10 --> Output Class Initialized
DEBUG - 2010-06-21 09:51:10 --> Input Class Initialized
DEBUG - 2010-06-21 09:51:10 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 09:51:10 --> Language Class Initialized
DEBUG - 2010-06-21 09:51:10 --> Loader Class Initialized
DEBUG - 2010-06-21 09:51:10 --> Controller Class Initialized
DEBUG - 2010-06-21 09:51:10 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 09:51:10 --> Helper loaded: context_helper
DEBUG - 2010-06-21 09:51:10 --> Session Class Initialized
DEBUG - 2010-06-21 09:51:10 --> Helper loaded: string_helper
DEBUG - 2010-06-21 09:51:10 --> Session routines successfully run
DEBUG - 2010-06-21 09:51:10 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 09:51:10 --> Logger class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:51:10 --> Database Driver Class Initialized
DEBUG - 2010-06-21 09:51:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:51:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 09:51:11 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-21 09:51:11 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-21 09:51:11 --> Final output sent to browser
DEBUG - 2010-06-21 09:51:11 --> Total execution time: 0.4903
DEBUG - 2010-06-21 11:41:38 --> Config Class Initialized
DEBUG - 2010-06-21 11:41:38 --> Hooks Class Initialized
DEBUG - 2010-06-21 11:41:39 --> URI Class Initialized
DEBUG - 2010-06-21 11:41:39 --> Router Class Initialized
DEBUG - 2010-06-21 11:41:39 --> Output Class Initialized
DEBUG - 2010-06-21 11:41:39 --> Input Class Initialized
DEBUG - 2010-06-21 11:41:39 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 11:41:39 --> Language Class Initialized
DEBUG - 2010-06-21 11:41:39 --> Loader Class Initialized
DEBUG - 2010-06-21 11:41:39 --> Controller Class Initialized
DEBUG - 2010-06-21 11:41:39 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 11:41:39 --> Helper loaded: context_helper
DEBUG - 2010-06-21 11:41:39 --> Session Class Initialized
DEBUG - 2010-06-21 11:41:39 --> Helper loaded: string_helper
DEBUG - 2010-06-21 11:41:39 --> Session routines successfully run
DEBUG - 2010-06-21 11:41:39 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 11:41:39 --> Database Driver Class Initialized
DEBUG - 2010-06-21 11:41:58 --> Config Class Initialized
DEBUG - 2010-06-21 11:41:58 --> Hooks Class Initialized
DEBUG - 2010-06-21 11:41:58 --> URI Class Initialized
DEBUG - 2010-06-21 11:41:58 --> Router Class Initialized
DEBUG - 2010-06-21 11:41:58 --> Output Class Initialized
DEBUG - 2010-06-21 11:41:58 --> Input Class Initialized
DEBUG - 2010-06-21 11:41:58 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 11:41:58 --> Language Class Initialized
DEBUG - 2010-06-21 11:41:58 --> Loader Class Initialized
DEBUG - 2010-06-21 11:41:58 --> Controller Class Initialized
DEBUG - 2010-06-21 11:41:58 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 11:41:58 --> Helper loaded: context_helper
DEBUG - 2010-06-21 11:41:59 --> Session Class Initialized
DEBUG - 2010-06-21 11:41:59 --> Helper loaded: string_helper
DEBUG - 2010-06-21 11:41:59 --> Session routines successfully run
DEBUG - 2010-06-21 11:41:59 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 11:41:59 --> Database Driver Class Initialized
DEBUG - 2010-06-21 11:41:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 11:41:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 11:41:59 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-21 11:41:59 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-21 11:41:59 --> Final output sent to browser
DEBUG - 2010-06-21 11:41:59 --> Total execution time: 0.5175
DEBUG - 2010-06-21 11:49:00 --> Config Class Initialized
DEBUG - 2010-06-21 11:49:00 --> Hooks Class Initialized
DEBUG - 2010-06-21 11:49:00 --> URI Class Initialized
DEBUG - 2010-06-21 11:49:00 --> Router Class Initialized
DEBUG - 2010-06-21 11:49:00 --> Output Class Initialized
DEBUG - 2010-06-21 11:49:00 --> Input Class Initialized
DEBUG - 2010-06-21 11:49:00 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 11:49:00 --> Language Class Initialized
DEBUG - 2010-06-21 11:49:00 --> Loader Class Initialized
DEBUG - 2010-06-21 11:49:00 --> Controller Class Initialized
DEBUG - 2010-06-21 11:49:00 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 11:49:00 --> Helper loaded: context_helper
DEBUG - 2010-06-21 11:49:00 --> Session Class Initialized
DEBUG - 2010-06-21 11:49:00 --> Helper loaded: string_helper
DEBUG - 2010-06-21 11:49:00 --> Session routines successfully run
DEBUG - 2010-06-21 11:49:00 --> Helper loaded: kals_helper
ERROR - 2010-06-21 11:49:00 --> Severity: Warning  --> require_once(../KALSObject.php) [<a href='function.require-once'>function.require-once</a>]: failed to open stream: No such file or directory D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\KALSResource.php 15
DEBUG - 2010-06-21 11:49:32 --> Config Class Initialized
DEBUG - 2010-06-21 11:49:32 --> Hooks Class Initialized
DEBUG - 2010-06-21 11:49:32 --> URI Class Initialized
DEBUG - 2010-06-21 11:49:32 --> Router Class Initialized
DEBUG - 2010-06-21 11:49:32 --> Output Class Initialized
DEBUG - 2010-06-21 11:49:32 --> Input Class Initialized
DEBUG - 2010-06-21 11:49:32 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 11:49:32 --> Language Class Initialized
DEBUG - 2010-06-21 11:49:32 --> Loader Class Initialized
DEBUG - 2010-06-21 11:49:32 --> Controller Class Initialized
DEBUG - 2010-06-21 11:49:32 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 11:49:32 --> Helper loaded: context_helper
DEBUG - 2010-06-21 11:49:32 --> Session Class Initialized
DEBUG - 2010-06-21 11:49:32 --> Helper loaded: string_helper
DEBUG - 2010-06-21 11:49:32 --> Session routines successfully run
DEBUG - 2010-06-21 11:49:32 --> Helper loaded: kals_helper
ERROR - 2010-06-21 11:49:32 --> Severity: Warning  --> require_once(KALSObject.php) [<a href='function.require-once'>function.require-once</a>]: failed to open stream: No such file or directory D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\KALSResource.php 15
DEBUG - 2010-06-21 11:49:40 --> Config Class Initialized
DEBUG - 2010-06-21 11:49:40 --> Hooks Class Initialized
DEBUG - 2010-06-21 11:49:40 --> URI Class Initialized
DEBUG - 2010-06-21 11:49:40 --> Router Class Initialized
DEBUG - 2010-06-21 11:49:40 --> Output Class Initialized
DEBUG - 2010-06-21 11:49:40 --> Input Class Initialized
DEBUG - 2010-06-21 11:49:40 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 11:49:40 --> Language Class Initialized
DEBUG - 2010-06-21 11:49:40 --> Loader Class Initialized
DEBUG - 2010-06-21 11:49:40 --> Controller Class Initialized
DEBUG - 2010-06-21 11:49:40 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 11:49:40 --> Helper loaded: context_helper
DEBUG - 2010-06-21 11:49:40 --> Session Class Initialized
DEBUG - 2010-06-21 11:49:40 --> Helper loaded: string_helper
DEBUG - 2010-06-21 11:49:40 --> Session routines successfully run
DEBUG - 2010-06-21 11:49:40 --> Helper loaded: kals_helper
ERROR - 2010-06-21 11:49:40 --> Severity: Warning  --> require_once(../KALSObject.php) [<a href='function.require-once'>function.require-once</a>]: failed to open stream: No such file or directory D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\KALSResource.php 15
DEBUG - 2010-06-21 11:49:47 --> Config Class Initialized
DEBUG - 2010-06-21 11:49:47 --> Hooks Class Initialized
DEBUG - 2010-06-21 11:49:47 --> URI Class Initialized
DEBUG - 2010-06-21 11:49:47 --> Router Class Initialized
DEBUG - 2010-06-21 11:49:47 --> Output Class Initialized
DEBUG - 2010-06-21 11:49:47 --> Input Class Initialized
DEBUG - 2010-06-21 11:49:47 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 11:49:47 --> Language Class Initialized
DEBUG - 2010-06-21 11:49:47 --> Loader Class Initialized
DEBUG - 2010-06-21 11:49:47 --> Controller Class Initialized
DEBUG - 2010-06-21 11:49:47 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 11:49:47 --> Helper loaded: context_helper
DEBUG - 2010-06-21 11:49:47 --> Session Class Initialized
DEBUG - 2010-06-21 11:49:47 --> Helper loaded: string_helper
DEBUG - 2010-06-21 11:49:47 --> Session routines successfully run
DEBUG - 2010-06-21 11:49:47 --> Helper loaded: kals_helper
ERROR - 2010-06-21 11:49:47 --> Severity: Warning  --> require_once(../../KALSObject.php) [<a href='function.require-once'>function.require-once</a>]: failed to open stream: No such file or directory D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\KALSResource.php 15
DEBUG - 2010-06-21 12:08:33 --> Config Class Initialized
DEBUG - 2010-06-21 12:08:33 --> Hooks Class Initialized
DEBUG - 2010-06-21 12:08:33 --> URI Class Initialized
DEBUG - 2010-06-21 12:08:33 --> Router Class Initialized
DEBUG - 2010-06-21 12:08:33 --> Output Class Initialized
DEBUG - 2010-06-21 12:08:33 --> Input Class Initialized
DEBUG - 2010-06-21 12:08:33 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 12:08:33 --> Language Class Initialized
DEBUG - 2010-06-21 12:08:33 --> Loader Class Initialized
DEBUG - 2010-06-21 12:08:34 --> Controller Class Initialized
DEBUG - 2010-06-21 12:08:34 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 12:08:34 --> Helper loaded: context_helper
DEBUG - 2010-06-21 12:08:34 --> Session Class Initialized
DEBUG - 2010-06-21 12:08:34 --> Helper loaded: string_helper
DEBUG - 2010-06-21 12:08:34 --> Session routines successfully run
DEBUG - 2010-06-21 12:08:34 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 12:08:34 --> Database Driver Class Initialized
DEBUG - 2010-06-21 12:09:27 --> Config Class Initialized
DEBUG - 2010-06-21 12:09:27 --> Hooks Class Initialized
DEBUG - 2010-06-21 12:09:27 --> URI Class Initialized
DEBUG - 2010-06-21 12:09:27 --> Router Class Initialized
DEBUG - 2010-06-21 12:09:27 --> Output Class Initialized
DEBUG - 2010-06-21 12:09:27 --> Input Class Initialized
DEBUG - 2010-06-21 12:09:27 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 12:09:27 --> Language Class Initialized
DEBUG - 2010-06-21 12:09:27 --> Loader Class Initialized
DEBUG - 2010-06-21 12:09:27 --> Controller Class Initialized
DEBUG - 2010-06-21 12:09:27 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 12:09:27 --> Helper loaded: context_helper
DEBUG - 2010-06-21 12:09:27 --> Session Class Initialized
DEBUG - 2010-06-21 12:09:27 --> Helper loaded: string_helper
DEBUG - 2010-06-21 12:09:27 --> Session routines successfully run
DEBUG - 2010-06-21 12:09:28 --> Helper loaded: kals_helper
ERROR - 2010-06-21 12:09:28 --> Unable to load the requested class: kalresource
DEBUG - 2010-06-21 12:09:35 --> Config Class Initialized
DEBUG - 2010-06-21 12:09:35 --> Hooks Class Initialized
DEBUG - 2010-06-21 12:09:35 --> URI Class Initialized
DEBUG - 2010-06-21 12:09:35 --> Router Class Initialized
DEBUG - 2010-06-21 12:09:35 --> Output Class Initialized
DEBUG - 2010-06-21 12:09:35 --> Input Class Initialized
DEBUG - 2010-06-21 12:09:35 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 12:09:35 --> Language Class Initialized
DEBUG - 2010-06-21 12:09:35 --> Loader Class Initialized
DEBUG - 2010-06-21 12:09:35 --> Controller Class Initialized
DEBUG - 2010-06-21 12:09:35 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 12:09:35 --> Helper loaded: context_helper
DEBUG - 2010-06-21 12:09:35 --> Session Class Initialized
DEBUG - 2010-06-21 12:09:35 --> Helper loaded: string_helper
DEBUG - 2010-06-21 12:09:35 --> Session routines successfully run
DEBUG - 2010-06-21 12:09:35 --> Helper loaded: kals_helper
ERROR - 2010-06-21 12:09:35 --> Unable to load the requested class: kalresource
DEBUG - 2010-06-21 12:09:41 --> Config Class Initialized
DEBUG - 2010-06-21 12:09:41 --> Hooks Class Initialized
DEBUG - 2010-06-21 12:09:41 --> URI Class Initialized
DEBUG - 2010-06-21 12:09:41 --> Router Class Initialized
DEBUG - 2010-06-21 12:09:41 --> Output Class Initialized
DEBUG - 2010-06-21 12:09:41 --> Input Class Initialized
DEBUG - 2010-06-21 12:09:41 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 12:09:41 --> Language Class Initialized
DEBUG - 2010-06-21 12:09:41 --> Loader Class Initialized
DEBUG - 2010-06-21 12:09:41 --> Controller Class Initialized
DEBUG - 2010-06-21 12:09:41 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 12:09:41 --> Helper loaded: context_helper
DEBUG - 2010-06-21 12:09:41 --> Session Class Initialized
DEBUG - 2010-06-21 12:09:41 --> Helper loaded: string_helper
DEBUG - 2010-06-21 12:09:41 --> Session routines successfully run
DEBUG - 2010-06-21 12:09:41 --> Helper loaded: kals_helper
ERROR - 2010-06-21 12:09:41 --> Unable to load the requested class: kalresource
DEBUG - 2010-06-21 12:09:49 --> Config Class Initialized
DEBUG - 2010-06-21 12:09:49 --> Hooks Class Initialized
DEBUG - 2010-06-21 12:09:49 --> URI Class Initialized
DEBUG - 2010-06-21 12:09:49 --> Router Class Initialized
DEBUG - 2010-06-21 12:09:49 --> Output Class Initialized
DEBUG - 2010-06-21 12:09:49 --> Input Class Initialized
DEBUG - 2010-06-21 12:09:49 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 12:09:49 --> Language Class Initialized
DEBUG - 2010-06-21 12:09:49 --> Loader Class Initialized
DEBUG - 2010-06-21 12:09:49 --> Controller Class Initialized
DEBUG - 2010-06-21 12:09:49 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 12:09:49 --> Helper loaded: context_helper
DEBUG - 2010-06-21 12:09:49 --> Session Class Initialized
DEBUG - 2010-06-21 12:09:49 --> Helper loaded: string_helper
DEBUG - 2010-06-21 12:09:49 --> Session routines successfully run
DEBUG - 2010-06-21 12:09:49 --> Helper loaded: kals_helper
ERROR - 2010-06-21 12:09:50 --> Unable to load the requested class: kalresource
DEBUG - 2010-06-21 12:15:17 --> Config Class Initialized
DEBUG - 2010-06-21 12:15:17 --> Hooks Class Initialized
DEBUG - 2010-06-21 12:15:17 --> URI Class Initialized
DEBUG - 2010-06-21 12:15:17 --> Router Class Initialized
DEBUG - 2010-06-21 12:15:17 --> Output Class Initialized
DEBUG - 2010-06-21 12:15:17 --> Input Class Initialized
DEBUG - 2010-06-21 12:15:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 12:15:17 --> Language Class Initialized
DEBUG - 2010-06-21 12:15:17 --> Loader Class Initialized
DEBUG - 2010-06-21 12:15:17 --> Controller Class Initialized
DEBUG - 2010-06-21 12:15:17 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 12:15:17 --> Helper loaded: context_helper
DEBUG - 2010-06-21 12:15:17 --> Session Class Initialized
DEBUG - 2010-06-21 12:15:17 --> Helper loaded: string_helper
DEBUG - 2010-06-21 12:15:17 --> Session routines successfully run
DEBUG - 2010-06-21 12:15:17 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 12:15:32 --> Config Class Initialized
DEBUG - 2010-06-21 12:15:32 --> Hooks Class Initialized
DEBUG - 2010-06-21 12:15:32 --> URI Class Initialized
DEBUG - 2010-06-21 12:15:32 --> Router Class Initialized
DEBUG - 2010-06-21 12:15:32 --> Output Class Initialized
DEBUG - 2010-06-21 12:15:32 --> Input Class Initialized
DEBUG - 2010-06-21 12:15:32 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 12:15:32 --> Language Class Initialized
DEBUG - 2010-06-21 12:15:32 --> Loader Class Initialized
DEBUG - 2010-06-21 12:15:32 --> Controller Class Initialized
DEBUG - 2010-06-21 12:15:32 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 12:15:32 --> Helper loaded: context_helper
DEBUG - 2010-06-21 12:15:33 --> Session Class Initialized
DEBUG - 2010-06-21 12:15:33 --> Helper loaded: string_helper
DEBUG - 2010-06-21 12:15:33 --> Session routines successfully run
DEBUG - 2010-06-21 12:15:33 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 12:15:34 --> Config Class Initialized
DEBUG - 2010-06-21 12:15:34 --> Hooks Class Initialized
DEBUG - 2010-06-21 12:15:34 --> URI Class Initialized
DEBUG - 2010-06-21 12:15:34 --> Router Class Initialized
DEBUG - 2010-06-21 12:15:34 --> Output Class Initialized
DEBUG - 2010-06-21 12:15:34 --> Input Class Initialized
DEBUG - 2010-06-21 12:15:34 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 12:15:34 --> Language Class Initialized
DEBUG - 2010-06-21 12:15:34 --> Loader Class Initialized
DEBUG - 2010-06-21 12:15:34 --> Controller Class Initialized
DEBUG - 2010-06-21 12:15:34 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 12:15:34 --> Helper loaded: context_helper
DEBUG - 2010-06-21 12:15:34 --> Session Class Initialized
DEBUG - 2010-06-21 12:15:34 --> Helper loaded: string_helper
DEBUG - 2010-06-21 12:15:35 --> Session routines successfully run
DEBUG - 2010-06-21 12:15:35 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 12:15:43 --> Config Class Initialized
DEBUG - 2010-06-21 12:15:43 --> Hooks Class Initialized
DEBUG - 2010-06-21 12:15:43 --> URI Class Initialized
DEBUG - 2010-06-21 12:15:43 --> Router Class Initialized
DEBUG - 2010-06-21 12:15:43 --> Output Class Initialized
DEBUG - 2010-06-21 12:15:43 --> Input Class Initialized
DEBUG - 2010-06-21 12:15:43 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 12:15:43 --> Language Class Initialized
DEBUG - 2010-06-21 12:15:43 --> Loader Class Initialized
DEBUG - 2010-06-21 12:15:43 --> Controller Class Initialized
DEBUG - 2010-06-21 12:15:43 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 12:15:43 --> Helper loaded: context_helper
DEBUG - 2010-06-21 12:15:43 --> Session Class Initialized
DEBUG - 2010-06-21 12:15:43 --> Helper loaded: string_helper
DEBUG - 2010-06-21 12:15:43 --> Session routines successfully run
DEBUG - 2010-06-21 12:15:43 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 12:15:49 --> Config Class Initialized
DEBUG - 2010-06-21 12:15:49 --> Hooks Class Initialized
DEBUG - 2010-06-21 12:15:49 --> URI Class Initialized
DEBUG - 2010-06-21 12:15:49 --> Router Class Initialized
DEBUG - 2010-06-21 12:15:49 --> Output Class Initialized
DEBUG - 2010-06-21 12:15:50 --> Input Class Initialized
DEBUG - 2010-06-21 12:15:50 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 12:15:50 --> Language Class Initialized
DEBUG - 2010-06-21 12:15:50 --> Loader Class Initialized
DEBUG - 2010-06-21 12:15:50 --> Controller Class Initialized
DEBUG - 2010-06-21 12:15:50 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 12:15:50 --> Helper loaded: context_helper
DEBUG - 2010-06-21 12:15:50 --> Session Class Initialized
DEBUG - 2010-06-21 12:15:50 --> Helper loaded: string_helper
DEBUG - 2010-06-21 12:15:50 --> Session routines successfully run
DEBUG - 2010-06-21 12:15:50 --> Helper loaded: kals_helper
ERROR - 2010-06-21 12:15:50 --> Severity: Notice  --> Undefined variable: system_folder D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\Domain.php 16
DEBUG - 2010-06-21 12:16:06 --> Config Class Initialized
DEBUG - 2010-06-21 12:16:06 --> Hooks Class Initialized
DEBUG - 2010-06-21 12:16:06 --> URI Class Initialized
DEBUG - 2010-06-21 12:16:06 --> Router Class Initialized
DEBUG - 2010-06-21 12:16:06 --> Output Class Initialized
DEBUG - 2010-06-21 12:16:06 --> Input Class Initialized
DEBUG - 2010-06-21 12:16:06 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 12:16:06 --> Language Class Initialized
DEBUG - 2010-06-21 12:16:06 --> Loader Class Initialized
DEBUG - 2010-06-21 12:16:06 --> Controller Class Initialized
DEBUG - 2010-06-21 12:16:06 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 12:16:06 --> Helper loaded: context_helper
DEBUG - 2010-06-21 12:16:06 --> Session Class Initialized
DEBUG - 2010-06-21 12:16:06 --> Helper loaded: string_helper
DEBUG - 2010-06-21 12:16:06 --> Session routines successfully run
DEBUG - 2010-06-21 12:16:06 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 12:16:14 --> Config Class Initialized
DEBUG - 2010-06-21 12:16:14 --> Hooks Class Initialized
DEBUG - 2010-06-21 12:16:14 --> URI Class Initialized
DEBUG - 2010-06-21 12:16:14 --> Router Class Initialized
DEBUG - 2010-06-21 12:16:14 --> Output Class Initialized
DEBUG - 2010-06-21 12:16:14 --> Input Class Initialized
DEBUG - 2010-06-21 12:16:14 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 12:16:14 --> Language Class Initialized
DEBUG - 2010-06-21 12:16:14 --> Loader Class Initialized
DEBUG - 2010-06-21 12:16:14 --> Controller Class Initialized
DEBUG - 2010-06-21 12:16:14 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 12:16:14 --> Helper loaded: context_helper
DEBUG - 2010-06-21 12:16:14 --> Session Class Initialized
DEBUG - 2010-06-21 12:16:14 --> Helper loaded: string_helper
DEBUG - 2010-06-21 12:16:14 --> Session routines successfully run
DEBUG - 2010-06-21 12:16:14 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 12:17:53 --> Config Class Initialized
DEBUG - 2010-06-21 12:17:53 --> Hooks Class Initialized
DEBUG - 2010-06-21 12:17:53 --> URI Class Initialized
DEBUG - 2010-06-21 12:17:53 --> Router Class Initialized
DEBUG - 2010-06-21 12:17:53 --> Output Class Initialized
DEBUG - 2010-06-21 12:17:53 --> Input Class Initialized
DEBUG - 2010-06-21 12:17:53 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 12:17:53 --> Language Class Initialized
DEBUG - 2010-06-21 12:17:53 --> Loader Class Initialized
DEBUG - 2010-06-21 12:17:53 --> Controller Class Initialized
DEBUG - 2010-06-21 12:17:53 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 12:17:53 --> Helper loaded: context_helper
DEBUG - 2010-06-21 12:17:53 --> Session Class Initialized
DEBUG - 2010-06-21 12:17:53 --> Helper loaded: string_helper
DEBUG - 2010-06-21 12:17:53 --> Session routines successfully run
DEBUG - 2010-06-21 12:17:53 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 12:20:38 --> Config Class Initialized
DEBUG - 2010-06-21 12:20:38 --> Hooks Class Initialized
DEBUG - 2010-06-21 12:20:38 --> URI Class Initialized
DEBUG - 2010-06-21 12:20:38 --> Router Class Initialized
DEBUG - 2010-06-21 12:20:38 --> Output Class Initialized
DEBUG - 2010-06-21 12:20:38 --> Input Class Initialized
DEBUG - 2010-06-21 12:20:38 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 12:20:38 --> Language Class Initialized
DEBUG - 2010-06-21 12:20:38 --> Loader Class Initialized
DEBUG - 2010-06-21 12:20:38 --> Controller Class Initialized
DEBUG - 2010-06-21 12:20:38 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 12:20:38 --> Helper loaded: context_helper
DEBUG - 2010-06-21 12:20:38 --> Session Class Initialized
DEBUG - 2010-06-21 12:20:38 --> Helper loaded: string_helper
DEBUG - 2010-06-21 12:20:38 --> Session routines successfully run
DEBUG - 2010-06-21 12:20:38 --> Helper loaded: kals_helper
ERROR - 2010-06-21 12:20:38 --> Severity: Warning  --> require_once(../KALSObject.php) [<a href='function.require-once'>function.require-once</a>]: failed to open stream: No such file or directory D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\KALSResource.php 15
DEBUG - 2010-06-21 12:21:29 --> Config Class Initialized
DEBUG - 2010-06-21 12:21:29 --> Hooks Class Initialized
DEBUG - 2010-06-21 12:21:29 --> URI Class Initialized
DEBUG - 2010-06-21 12:21:29 --> Router Class Initialized
DEBUG - 2010-06-21 12:21:29 --> Output Class Initialized
DEBUG - 2010-06-21 12:21:29 --> Input Class Initialized
DEBUG - 2010-06-21 12:21:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 12:21:29 --> Language Class Initialized
DEBUG - 2010-06-21 12:21:29 --> Loader Class Initialized
DEBUG - 2010-06-21 12:21:29 --> Controller Class Initialized
DEBUG - 2010-06-21 12:21:29 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 12:21:29 --> Helper loaded: context_helper
DEBUG - 2010-06-21 12:21:29 --> Session Class Initialized
DEBUG - 2010-06-21 12:21:29 --> Helper loaded: string_helper
DEBUG - 2010-06-21 12:21:29 --> Session routines successfully run
DEBUG - 2010-06-21 12:21:29 --> Helper loaded: kals_helper
ERROR - 2010-06-21 12:21:29 --> Severity: Warning  --> include_once(../KALSObject.php) [<a href='function.include-once'>function.include-once</a>]: failed to open stream: No such file or directory D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\KALSResource.php 15
ERROR - 2010-06-21 12:21:30 --> Severity: Warning  --> include_once() [<a href='function.include'>function.include</a>]: Failed opening '../KALSObject.php' for inclusion (include_path='.;D:\xampp\php\pear\') D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_resource\KALSResource.php 15
DEBUG - 2010-06-21 12:23:16 --> Config Class Initialized
DEBUG - 2010-06-21 12:23:16 --> Hooks Class Initialized
DEBUG - 2010-06-21 12:23:16 --> URI Class Initialized
DEBUG - 2010-06-21 12:23:16 --> Router Class Initialized
DEBUG - 2010-06-21 12:23:16 --> Output Class Initialized
DEBUG - 2010-06-21 12:23:16 --> Input Class Initialized
DEBUG - 2010-06-21 12:23:16 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 12:23:16 --> Language Class Initialized
DEBUG - 2010-06-21 12:23:16 --> Loader Class Initialized
DEBUG - 2010-06-21 12:23:16 --> Controller Class Initialized
DEBUG - 2010-06-21 12:23:16 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 12:23:16 --> Helper loaded: context_helper
DEBUG - 2010-06-21 12:23:17 --> Session Class Initialized
DEBUG - 2010-06-21 12:23:17 --> Helper loaded: string_helper
DEBUG - 2010-06-21 12:23:17 --> Session routines successfully run
DEBUG - 2010-06-21 12:23:17 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 12:25:16 --> Config Class Initialized
DEBUG - 2010-06-21 12:25:16 --> Hooks Class Initialized
DEBUG - 2010-06-21 12:25:16 --> URI Class Initialized
DEBUG - 2010-06-21 12:25:16 --> Router Class Initialized
DEBUG - 2010-06-21 12:25:16 --> Output Class Initialized
DEBUG - 2010-06-21 12:25:16 --> Input Class Initialized
DEBUG - 2010-06-21 12:25:16 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 12:25:16 --> Language Class Initialized
DEBUG - 2010-06-21 12:25:16 --> Loader Class Initialized
DEBUG - 2010-06-21 12:25:16 --> Controller Class Initialized
DEBUG - 2010-06-21 12:25:16 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 12:25:16 --> Helper loaded: context_helper
DEBUG - 2010-06-21 12:25:16 --> Session Class Initialized
DEBUG - 2010-06-21 12:25:16 --> Helper loaded: string_helper
DEBUG - 2010-06-21 12:25:16 --> Session routines successfully run
DEBUG - 2010-06-21 12:25:16 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 12:25:55 --> Config Class Initialized
DEBUG - 2010-06-21 12:25:55 --> Hooks Class Initialized
DEBUG - 2010-06-21 12:25:55 --> URI Class Initialized
DEBUG - 2010-06-21 12:25:55 --> Router Class Initialized
DEBUG - 2010-06-21 12:25:55 --> Output Class Initialized
DEBUG - 2010-06-21 12:25:55 --> Input Class Initialized
DEBUG - 2010-06-21 12:25:55 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 12:25:55 --> Language Class Initialized
DEBUG - 2010-06-21 12:25:55 --> Loader Class Initialized
DEBUG - 2010-06-21 12:25:55 --> Controller Class Initialized
DEBUG - 2010-06-21 12:25:55 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 12:25:55 --> Helper loaded: context_helper
DEBUG - 2010-06-21 12:25:55 --> Session Class Initialized
DEBUG - 2010-06-21 12:25:55 --> Helper loaded: string_helper
DEBUG - 2010-06-21 12:25:55 --> Session routines successfully run
DEBUG - 2010-06-21 12:25:55 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 12:25:55 --> Database Driver Class Initialized
DEBUG - 2010-06-21 12:25:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 12:25:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 12:25:55 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-21 12:25:55 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-21 12:25:55 --> Final output sent to browser
DEBUG - 2010-06-21 12:25:55 --> Total execution time: 0.7081
DEBUG - 2010-06-21 14:10:49 --> Config Class Initialized
DEBUG - 2010-06-21 14:10:49 --> Hooks Class Initialized
DEBUG - 2010-06-21 14:10:49 --> URI Class Initialized
DEBUG - 2010-06-21 14:10:49 --> Router Class Initialized
DEBUG - 2010-06-21 14:10:50 --> Output Class Initialized
DEBUG - 2010-06-21 14:10:50 --> Input Class Initialized
DEBUG - 2010-06-21 14:10:50 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 14:10:50 --> Language Class Initialized
DEBUG - 2010-06-21 14:10:50 --> Loader Class Initialized
DEBUG - 2010-06-21 14:11:09 --> Config Class Initialized
DEBUG - 2010-06-21 14:11:09 --> Hooks Class Initialized
DEBUG - 2010-06-21 14:11:09 --> URI Class Initialized
DEBUG - 2010-06-21 14:11:09 --> Router Class Initialized
DEBUG - 2010-06-21 14:11:10 --> Output Class Initialized
DEBUG - 2010-06-21 14:11:10 --> Input Class Initialized
DEBUG - 2010-06-21 14:11:10 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 14:11:10 --> Language Class Initialized
DEBUG - 2010-06-21 14:11:10 --> Loader Class Initialized
DEBUG - 2010-06-21 14:11:10 --> Helper loaded: object_helper
DEBUG - 2010-06-21 14:11:10 --> Controller Class Initialized
DEBUG - 2010-06-21 14:11:10 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 14:11:10 --> Helper loaded: context_helper
DEBUG - 2010-06-21 14:11:10 --> Session Class Initialized
DEBUG - 2010-06-21 14:11:10 --> Helper loaded: string_helper
DEBUG - 2010-06-21 14:11:10 --> Session routines successfully run
DEBUG - 2010-06-21 14:11:10 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 14:11:24 --> Config Class Initialized
DEBUG - 2010-06-21 14:11:24 --> Hooks Class Initialized
DEBUG - 2010-06-21 14:11:24 --> URI Class Initialized
DEBUG - 2010-06-21 14:11:24 --> Router Class Initialized
DEBUG - 2010-06-21 14:11:24 --> Output Class Initialized
DEBUG - 2010-06-21 14:11:24 --> Input Class Initialized
DEBUG - 2010-06-21 14:11:24 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 14:11:24 --> Language Class Initialized
DEBUG - 2010-06-21 14:11:24 --> Loader Class Initialized
DEBUG - 2010-06-21 14:11:24 --> Helper loaded: object_helper
DEBUG - 2010-06-21 14:11:24 --> Controller Class Initialized
DEBUG - 2010-06-21 14:11:24 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 14:11:24 --> Helper loaded: context_helper
DEBUG - 2010-06-21 14:11:24 --> Session Class Initialized
DEBUG - 2010-06-21 14:11:25 --> Helper loaded: string_helper
DEBUG - 2010-06-21 14:11:25 --> Session routines successfully run
DEBUG - 2010-06-21 14:11:25 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 14:11:29 --> Config Class Initialized
DEBUG - 2010-06-21 14:11:29 --> Hooks Class Initialized
DEBUG - 2010-06-21 14:11:29 --> URI Class Initialized
DEBUG - 2010-06-21 14:11:29 --> Router Class Initialized
DEBUG - 2010-06-21 14:11:29 --> Output Class Initialized
DEBUG - 2010-06-21 14:11:29 --> Input Class Initialized
DEBUG - 2010-06-21 14:11:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 14:11:29 --> Language Class Initialized
DEBUG - 2010-06-21 14:11:29 --> Loader Class Initialized
DEBUG - 2010-06-21 14:11:29 --> Helper loaded: object_helper
DEBUG - 2010-06-21 14:11:29 --> Controller Class Initialized
DEBUG - 2010-06-21 14:11:29 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 14:11:29 --> Helper loaded: context_helper
DEBUG - 2010-06-21 14:11:29 --> Session Class Initialized
DEBUG - 2010-06-21 14:11:29 --> Helper loaded: string_helper
DEBUG - 2010-06-21 14:11:29 --> Session routines successfully run
DEBUG - 2010-06-21 14:11:29 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 14:11:37 --> Config Class Initialized
DEBUG - 2010-06-21 14:11:37 --> Hooks Class Initialized
DEBUG - 2010-06-21 14:11:37 --> URI Class Initialized
DEBUG - 2010-06-21 14:11:37 --> Router Class Initialized
DEBUG - 2010-06-21 14:11:37 --> Output Class Initialized
DEBUG - 2010-06-21 14:11:37 --> Input Class Initialized
DEBUG - 2010-06-21 14:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 14:11:38 --> Language Class Initialized
DEBUG - 2010-06-21 14:11:38 --> Loader Class Initialized
DEBUG - 2010-06-21 14:11:38 --> Helper loaded: object_helper
DEBUG - 2010-06-21 14:11:38 --> Controller Class Initialized
DEBUG - 2010-06-21 14:11:38 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 14:11:38 --> Helper loaded: context_helper
DEBUG - 2010-06-21 14:11:38 --> Session Class Initialized
DEBUG - 2010-06-21 14:11:38 --> Helper loaded: string_helper
DEBUG - 2010-06-21 14:11:38 --> Session routines successfully run
DEBUG - 2010-06-21 14:11:38 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 14:11:38 --> Database Driver Class Initialized
DEBUG - 2010-06-21 14:11:57 --> Config Class Initialized
DEBUG - 2010-06-21 14:11:57 --> Hooks Class Initialized
DEBUG - 2010-06-21 14:11:57 --> URI Class Initialized
DEBUG - 2010-06-21 14:11:57 --> Router Class Initialized
DEBUG - 2010-06-21 14:11:57 --> Output Class Initialized
DEBUG - 2010-06-21 14:11:57 --> Input Class Initialized
DEBUG - 2010-06-21 14:11:57 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 14:11:57 --> Language Class Initialized
DEBUG - 2010-06-21 14:11:57 --> Loader Class Initialized
DEBUG - 2010-06-21 14:11:57 --> Helper loaded: object_helper
DEBUG - 2010-06-21 14:11:57 --> Controller Class Initialized
DEBUG - 2010-06-21 14:11:57 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 14:11:57 --> Helper loaded: context_helper
DEBUG - 2010-06-21 14:11:57 --> Session Class Initialized
DEBUG - 2010-06-21 14:11:57 --> Helper loaded: string_helper
DEBUG - 2010-06-21 14:11:57 --> Session routines successfully run
DEBUG - 2010-06-21 14:11:57 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 14:11:57 --> Database Driver Class Initialized
DEBUG - 2010-06-21 14:11:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 14:11:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 14:11:57 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-21 14:11:57 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-21 14:11:58 --> Final output sent to browser
DEBUG - 2010-06-21 14:11:58 --> Total execution time: 0.7850
DEBUG - 2010-06-21 14:15:44 --> Config Class Initialized
DEBUG - 2010-06-21 14:15:44 --> Hooks Class Initialized
DEBUG - 2010-06-21 14:15:44 --> URI Class Initialized
DEBUG - 2010-06-21 14:15:44 --> Router Class Initialized
DEBUG - 2010-06-21 14:15:44 --> Output Class Initialized
DEBUG - 2010-06-21 14:15:44 --> Input Class Initialized
DEBUG - 2010-06-21 14:15:44 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 14:15:44 --> Language Class Initialized
DEBUG - 2010-06-21 14:15:44 --> Loader Class Initialized
DEBUG - 2010-06-21 14:15:44 --> Helper loaded: object_helper
DEBUG - 2010-06-21 14:15:44 --> Controller Class Initialized
DEBUG - 2010-06-21 14:15:44 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 14:15:44 --> Helper loaded: context_helper
DEBUG - 2010-06-21 14:15:44 --> Session Class Initialized
DEBUG - 2010-06-21 14:15:44 --> Helper loaded: string_helper
DEBUG - 2010-06-21 14:15:44 --> Session routines successfully run
DEBUG - 2010-06-21 14:15:44 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 14:15:44 --> Database Driver Class Initialized
DEBUG - 2010-06-21 14:15:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 14:15:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 14:15:44 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-21 14:15:44 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-21 14:15:44 --> Final output sent to browser
DEBUG - 2010-06-21 14:15:44 --> Total execution time: 0.7810
DEBUG - 2010-06-21 14:23:09 --> Config Class Initialized
DEBUG - 2010-06-21 14:23:09 --> Hooks Class Initialized
DEBUG - 2010-06-21 14:23:09 --> URI Class Initialized
DEBUG - 2010-06-21 14:23:09 --> Router Class Initialized
DEBUG - 2010-06-21 14:23:09 --> Output Class Initialized
DEBUG - 2010-06-21 14:23:09 --> Input Class Initialized
DEBUG - 2010-06-21 14:23:09 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 14:23:09 --> Language Class Initialized
DEBUG - 2010-06-21 14:23:09 --> Loader Class Initialized
DEBUG - 2010-06-21 14:23:09 --> Helper loaded: object_helper
DEBUG - 2010-06-21 14:23:09 --> Controller Class Initialized
DEBUG - 2010-06-21 14:23:09 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 14:23:09 --> Helper loaded: context_helper
DEBUG - 2010-06-21 14:23:09 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 14:23:09 --> Session Class Initialized
DEBUG - 2010-06-21 14:23:09 --> Helper loaded: string_helper
DEBUG - 2010-06-21 14:23:09 --> Session routines successfully run
DEBUG - 2010-06-21 14:23:09 --> Database Driver Class Initialized
ERROR - 2010-06-21 14:23:09 --> Severity: Notice  --> Undefined property: Context::$logger D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\context_helper.php 108
DEBUG - 2010-06-21 14:26:26 --> Config Class Initialized
DEBUG - 2010-06-21 14:26:26 --> Hooks Class Initialized
DEBUG - 2010-06-21 14:26:26 --> URI Class Initialized
DEBUG - 2010-06-21 14:26:26 --> Router Class Initialized
DEBUG - 2010-06-21 14:26:26 --> Output Class Initialized
DEBUG - 2010-06-21 14:26:26 --> Input Class Initialized
DEBUG - 2010-06-21 14:26:26 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 14:26:26 --> Language Class Initialized
DEBUG - 2010-06-21 14:26:26 --> Loader Class Initialized
DEBUG - 2010-06-21 14:26:26 --> Helper loaded: object_helper
DEBUG - 2010-06-21 14:26:26 --> Controller Class Initialized
DEBUG - 2010-06-21 14:26:26 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 14:26:26 --> Helper loaded: context_helper
DEBUG - 2010-06-21 14:26:26 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 14:26:27 --> Session Class Initialized
DEBUG - 2010-06-21 14:26:27 --> Helper loaded: string_helper
DEBUG - 2010-06-21 14:26:27 --> Session routines successfully run
ERROR - 2010-06-21 14:26:27 --> Severity: Notice  --> Undefined variable: object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\core\Context.php 35
DEBUG - 2010-06-21 14:26:27 --> Database Driver Class Initialized
DEBUG - 2010-06-21 14:26:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 14:26:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 14:26:27 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-21 14:26:27 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-21 14:26:27 --> Final output sent to browser
DEBUG - 2010-06-21 14:26:27 --> Total execution time: 0.8470
DEBUG - 2010-06-21 14:26:41 --> Config Class Initialized
DEBUG - 2010-06-21 14:26:41 --> Hooks Class Initialized
DEBUG - 2010-06-21 14:26:41 --> URI Class Initialized
DEBUG - 2010-06-21 14:26:41 --> Router Class Initialized
DEBUG - 2010-06-21 14:26:41 --> Output Class Initialized
DEBUG - 2010-06-21 14:26:41 --> Input Class Initialized
DEBUG - 2010-06-21 14:26:41 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-21 14:26:41 --> Language Class Initialized
DEBUG - 2010-06-21 14:26:41 --> Loader Class Initialized
DEBUG - 2010-06-21 14:26:41 --> Helper loaded: object_helper
DEBUG - 2010-06-21 14:26:41 --> Controller Class Initialized
DEBUG - 2010-06-21 14:26:41 --> Unit Testing Class Initialized
DEBUG - 2010-06-21 14:26:41 --> Helper loaded: context_helper
DEBUG - 2010-06-21 14:26:41 --> Helper loaded: kals_helper
DEBUG - 2010-06-21 14:26:41 --> Session Class Initialized
DEBUG - 2010-06-21 14:26:41 --> Helper loaded: string_helper
DEBUG - 2010-06-21 14:26:41 --> Session routines successfully run
DEBUG - 2010-06-21 14:26:41 --> Database Driver Class Initialized
DEBUG - 2010-06-21 14:26:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 14:26:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-21 14:26:41 --> Language file loaded: language/english/unit_test_lang.php
DEBUG - 2010-06-21 14:26:41 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-21 14:26:41 --> Final output sent to browser
DEBUG - 2010-06-21 14:26:41 --> Total execution time: 0.8218
