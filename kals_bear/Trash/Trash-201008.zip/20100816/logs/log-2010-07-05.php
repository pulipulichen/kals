<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2010-07-05 02:53:07 --> Config Class Initialized
DEBUG - 2010-07-05 02:53:07 --> Hooks Class Initialized
DEBUG - 2010-07-05 02:53:07 --> URI Class Initialized
DEBUG - 2010-07-05 02:53:07 --> Router Class Initialized
DEBUG - 2010-07-05 02:53:07 --> Output Class Initialized
DEBUG - 2010-07-05 02:53:07 --> Input Class Initialized
DEBUG - 2010-07-05 02:53:07 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 02:53:07 --> Language Class Initialized
DEBUG - 2010-07-05 02:53:07 --> Loader Class Initialized
DEBUG - 2010-07-05 02:53:07 --> Helper loaded: context_helper
DEBUG - 2010-07-05 02:53:07 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 02:53:07 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 02:53:07 --> Database Driver Class Initialized
DEBUG - 2010-07-05 02:53:07 --> Controller Class Initialized
DEBUG - 2010-07-05 02:53:07 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 02:53:07 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 02:53:07 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 02:53:07 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 02:53:07 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 02:53:07 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 02:53:07 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 02:53:07 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 02:53:07 --> Final output sent to browser
DEBUG - 2010-07-05 02:53:07 --> Total execution time: 0.3624
DEBUG - 2010-07-05 02:56:26 --> Config Class Initialized
DEBUG - 2010-07-05 02:56:26 --> Hooks Class Initialized
DEBUG - 2010-07-05 02:56:26 --> URI Class Initialized
DEBUG - 2010-07-05 02:56:26 --> Router Class Initialized
DEBUG - 2010-07-05 02:56:26 --> Output Class Initialized
DEBUG - 2010-07-05 02:56:26 --> Input Class Initialized
DEBUG - 2010-07-05 02:56:26 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 02:56:26 --> Language Class Initialized
DEBUG - 2010-07-05 02:56:26 --> Loader Class Initialized
DEBUG - 2010-07-05 02:56:26 --> Helper loaded: context_helper
DEBUG - 2010-07-05 02:56:26 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 02:56:26 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 02:56:26 --> Database Driver Class Initialized
DEBUG - 2010-07-05 02:56:26 --> Controller Class Initialized
DEBUG - 2010-07-05 02:56:26 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 02:56:26 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 02:56:26 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 02:56:26 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 02:56:26 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 02:56:26 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 02:56:26 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 02:56:26 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 02:56:26 --> Final output sent to browser
DEBUG - 2010-07-05 02:56:26 --> Total execution time: 0.1460
DEBUG - 2010-07-05 02:56:40 --> Config Class Initialized
DEBUG - 2010-07-05 02:56:40 --> Hooks Class Initialized
DEBUG - 2010-07-05 02:56:40 --> URI Class Initialized
DEBUG - 2010-07-05 02:56:40 --> Router Class Initialized
DEBUG - 2010-07-05 02:56:40 --> Output Class Initialized
DEBUG - 2010-07-05 02:56:40 --> Input Class Initialized
DEBUG - 2010-07-05 02:56:40 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 02:56:40 --> Language Class Initialized
DEBUG - 2010-07-05 02:56:40 --> Loader Class Initialized
DEBUG - 2010-07-05 02:56:40 --> Helper loaded: context_helper
DEBUG - 2010-07-05 02:56:40 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 02:56:40 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 02:56:40 --> Database Driver Class Initialized
DEBUG - 2010-07-05 02:56:40 --> Controller Class Initialized
DEBUG - 2010-07-05 02:56:40 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 02:56:40 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 02:56:40 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 02:56:40 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 02:56:40 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 02:56:40 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 02:56:40 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 02:56:40 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 02:56:40 --> Final output sent to browser
DEBUG - 2010-07-05 02:56:40 --> Total execution time: 0.1721
DEBUG - 2010-07-05 02:56:56 --> Config Class Initialized
DEBUG - 2010-07-05 02:56:56 --> Hooks Class Initialized
DEBUG - 2010-07-05 02:56:56 --> URI Class Initialized
DEBUG - 2010-07-05 02:56:56 --> Router Class Initialized
DEBUG - 2010-07-05 02:56:56 --> Output Class Initialized
DEBUG - 2010-07-05 02:56:56 --> Input Class Initialized
DEBUG - 2010-07-05 02:56:56 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 02:56:56 --> Language Class Initialized
DEBUG - 2010-07-05 02:56:56 --> Loader Class Initialized
DEBUG - 2010-07-05 02:56:56 --> Helper loaded: context_helper
DEBUG - 2010-07-05 02:56:56 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 02:56:57 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 02:56:57 --> Database Driver Class Initialized
DEBUG - 2010-07-05 02:56:57 --> Controller Class Initialized
DEBUG - 2010-07-05 02:56:57 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 02:56:57 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 02:56:57 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 02:56:57 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 02:56:57 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 02:56:57 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 02:56:57 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 02:56:57 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 02:56:57 --> Final output sent to browser
DEBUG - 2010-07-05 02:56:57 --> Total execution time: 0.1669
DEBUG - 2010-07-05 02:57:05 --> Config Class Initialized
DEBUG - 2010-07-05 02:57:05 --> Hooks Class Initialized
DEBUG - 2010-07-05 02:57:05 --> URI Class Initialized
DEBUG - 2010-07-05 02:57:05 --> Router Class Initialized
DEBUG - 2010-07-05 02:57:05 --> Output Class Initialized
DEBUG - 2010-07-05 02:57:05 --> Input Class Initialized
DEBUG - 2010-07-05 02:57:06 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 02:57:06 --> Language Class Initialized
DEBUG - 2010-07-05 02:57:06 --> Loader Class Initialized
DEBUG - 2010-07-05 02:57:06 --> Helper loaded: context_helper
DEBUG - 2010-07-05 02:57:06 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 02:57:06 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 02:57:06 --> Database Driver Class Initialized
DEBUG - 2010-07-05 02:57:06 --> Controller Class Initialized
DEBUG - 2010-07-05 02:57:06 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 02:57:06 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 02:57:06 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 02:57:06 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 02:57:06 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 02:57:06 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 02:57:06 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 02:57:06 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 02:57:06 --> Final output sent to browser
DEBUG - 2010-07-05 02:57:06 --> Total execution time: 0.1810
DEBUG - 2010-07-05 02:57:12 --> Config Class Initialized
DEBUG - 2010-07-05 02:57:12 --> Hooks Class Initialized
DEBUG - 2010-07-05 02:57:12 --> URI Class Initialized
DEBUG - 2010-07-05 02:57:12 --> Router Class Initialized
DEBUG - 2010-07-05 02:57:12 --> Output Class Initialized
DEBUG - 2010-07-05 02:57:12 --> Input Class Initialized
DEBUG - 2010-07-05 02:57:12 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 02:57:12 --> Language Class Initialized
DEBUG - 2010-07-05 02:57:12 --> Loader Class Initialized
DEBUG - 2010-07-05 02:57:12 --> Helper loaded: context_helper
DEBUG - 2010-07-05 02:57:12 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 02:57:12 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 02:57:12 --> Database Driver Class Initialized
DEBUG - 2010-07-05 02:57:12 --> Controller Class Initialized
DEBUG - 2010-07-05 02:57:12 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 02:57:12 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 02:57:12 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 02:57:12 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 02:57:12 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 02:57:12 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 02:57:12 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 02:57:12 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 02:57:12 --> Final output sent to browser
DEBUG - 2010-07-05 02:57:12 --> Total execution time: 0.2083
DEBUG - 2010-07-05 02:57:20 --> Config Class Initialized
DEBUG - 2010-07-05 02:57:20 --> Hooks Class Initialized
DEBUG - 2010-07-05 02:57:20 --> URI Class Initialized
DEBUG - 2010-07-05 02:57:20 --> Router Class Initialized
DEBUG - 2010-07-05 02:57:20 --> Output Class Initialized
DEBUG - 2010-07-05 02:57:20 --> Input Class Initialized
DEBUG - 2010-07-05 02:57:20 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 02:57:20 --> Language Class Initialized
DEBUG - 2010-07-05 02:57:20 --> Loader Class Initialized
DEBUG - 2010-07-05 02:57:20 --> Helper loaded: context_helper
DEBUG - 2010-07-05 02:57:20 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 02:57:20 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 02:57:20 --> Database Driver Class Initialized
DEBUG - 2010-07-05 02:57:20 --> Controller Class Initialized
DEBUG - 2010-07-05 02:57:20 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 02:57:20 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 02:57:20 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 02:57:20 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 02:57:20 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 02:57:20 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 02:57:20 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 02:57:21 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 02:57:21 --> Final output sent to browser
DEBUG - 2010-07-05 02:57:21 --> Total execution time: 0.2198
DEBUG - 2010-07-05 02:57:34 --> Config Class Initialized
DEBUG - 2010-07-05 02:57:34 --> Hooks Class Initialized
DEBUG - 2010-07-05 02:57:34 --> URI Class Initialized
DEBUG - 2010-07-05 02:57:34 --> Router Class Initialized
DEBUG - 2010-07-05 02:57:34 --> Output Class Initialized
DEBUG - 2010-07-05 02:57:34 --> Input Class Initialized
DEBUG - 2010-07-05 02:57:34 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 02:57:34 --> Language Class Initialized
DEBUG - 2010-07-05 02:57:34 --> Loader Class Initialized
DEBUG - 2010-07-05 02:57:34 --> Helper loaded: context_helper
DEBUG - 2010-07-05 02:57:34 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 02:57:34 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 02:57:35 --> Database Driver Class Initialized
DEBUG - 2010-07-05 02:57:35 --> Controller Class Initialized
DEBUG - 2010-07-05 02:57:35 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 02:57:35 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 02:57:35 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 02:57:35 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 02:57:35 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 02:57:35 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 02:57:35 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 02:57:35 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 02:57:35 --> Final output sent to browser
DEBUG - 2010-07-05 02:57:35 --> Total execution time: 0.2491
DEBUG - 2010-07-05 02:57:46 --> Config Class Initialized
DEBUG - 2010-07-05 02:57:46 --> Hooks Class Initialized
DEBUG - 2010-07-05 02:57:46 --> URI Class Initialized
DEBUG - 2010-07-05 02:57:46 --> Router Class Initialized
DEBUG - 2010-07-05 02:57:46 --> Output Class Initialized
DEBUG - 2010-07-05 02:57:46 --> Input Class Initialized
DEBUG - 2010-07-05 02:57:46 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 02:57:46 --> Language Class Initialized
DEBUG - 2010-07-05 02:57:46 --> Loader Class Initialized
DEBUG - 2010-07-05 02:57:46 --> Helper loaded: context_helper
DEBUG - 2010-07-05 02:57:46 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 02:57:46 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 02:57:46 --> Database Driver Class Initialized
DEBUG - 2010-07-05 02:57:46 --> Controller Class Initialized
DEBUG - 2010-07-05 02:57:46 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 02:57:46 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 02:57:46 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 02:57:46 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 02:57:46 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 02:57:46 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 02:57:46 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 02:57:46 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 02:57:46 --> Final output sent to browser
DEBUG - 2010-07-05 02:57:46 --> Total execution time: 0.2373
DEBUG - 2010-07-05 02:59:47 --> Config Class Initialized
DEBUG - 2010-07-05 02:59:47 --> Hooks Class Initialized
DEBUG - 2010-07-05 02:59:47 --> URI Class Initialized
DEBUG - 2010-07-05 02:59:47 --> Router Class Initialized
DEBUG - 2010-07-05 02:59:47 --> Output Class Initialized
DEBUG - 2010-07-05 02:59:47 --> Input Class Initialized
DEBUG - 2010-07-05 02:59:47 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 02:59:47 --> Language Class Initialized
DEBUG - 2010-07-05 02:59:47 --> Loader Class Initialized
DEBUG - 2010-07-05 02:59:47 --> Helper loaded: context_helper
DEBUG - 2010-07-05 02:59:47 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 02:59:47 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 02:59:47 --> Database Driver Class Initialized
DEBUG - 2010-07-05 02:59:47 --> Controller Class Initialized
DEBUG - 2010-07-05 02:59:47 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 02:59:47 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 02:59:47 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 02:59:47 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 02:59:47 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 02:59:47 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 02:59:47 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 02:59:47 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 02:59:47 --> Final output sent to browser
DEBUG - 2010-07-05 02:59:47 --> Total execution time: 0.3580
DEBUG - 2010-07-05 03:00:02 --> Config Class Initialized
DEBUG - 2010-07-05 03:00:02 --> Hooks Class Initialized
DEBUG - 2010-07-05 03:00:02 --> URI Class Initialized
DEBUG - 2010-07-05 03:00:02 --> Router Class Initialized
DEBUG - 2010-07-05 03:00:02 --> Output Class Initialized
DEBUG - 2010-07-05 03:00:02 --> Input Class Initialized
DEBUG - 2010-07-05 03:00:02 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 03:00:02 --> Language Class Initialized
DEBUG - 2010-07-05 03:00:02 --> Loader Class Initialized
DEBUG - 2010-07-05 03:00:02 --> Helper loaded: context_helper
DEBUG - 2010-07-05 03:00:02 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 03:00:02 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 03:00:02 --> Database Driver Class Initialized
DEBUG - 2010-07-05 03:00:02 --> Controller Class Initialized
DEBUG - 2010-07-05 03:00:02 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 03:00:02 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 03:00:02 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 03:00:02 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:00:02 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:00:02 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:00:02 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 03:00:02 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 03:00:02 --> Final output sent to browser
DEBUG - 2010-07-05 03:00:02 --> Total execution time: 0.2823
DEBUG - 2010-07-05 03:00:35 --> Config Class Initialized
DEBUG - 2010-07-05 03:00:35 --> Hooks Class Initialized
DEBUG - 2010-07-05 03:00:35 --> URI Class Initialized
DEBUG - 2010-07-05 03:00:35 --> Router Class Initialized
DEBUG - 2010-07-05 03:00:35 --> Output Class Initialized
DEBUG - 2010-07-05 03:00:35 --> Input Class Initialized
DEBUG - 2010-07-05 03:00:35 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 03:00:35 --> Language Class Initialized
DEBUG - 2010-07-05 03:00:35 --> Loader Class Initialized
DEBUG - 2010-07-05 03:00:36 --> Helper loaded: context_helper
DEBUG - 2010-07-05 03:00:36 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 03:00:36 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 03:00:36 --> Database Driver Class Initialized
DEBUG - 2010-07-05 03:00:36 --> Controller Class Initialized
DEBUG - 2010-07-05 03:00:36 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 03:00:36 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 03:00:36 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 03:00:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:00:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:00:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:00:36 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 03:00:36 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 03:00:36 --> Final output sent to browser
DEBUG - 2010-07-05 03:00:36 --> Total execution time: 0.2945
DEBUG - 2010-07-05 03:00:52 --> Config Class Initialized
DEBUG - 2010-07-05 03:00:52 --> Hooks Class Initialized
DEBUG - 2010-07-05 03:00:52 --> URI Class Initialized
DEBUG - 2010-07-05 03:00:52 --> Router Class Initialized
DEBUG - 2010-07-05 03:00:52 --> Output Class Initialized
DEBUG - 2010-07-05 03:00:52 --> Input Class Initialized
DEBUG - 2010-07-05 03:00:52 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 03:00:52 --> Language Class Initialized
DEBUG - 2010-07-05 03:00:52 --> Loader Class Initialized
DEBUG - 2010-07-05 03:00:52 --> Helper loaded: context_helper
DEBUG - 2010-07-05 03:00:52 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 03:00:52 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 03:00:52 --> Database Driver Class Initialized
DEBUG - 2010-07-05 03:00:52 --> Controller Class Initialized
DEBUG - 2010-07-05 03:00:52 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 03:00:52 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 03:00:52 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 03:00:52 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:00:52 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:00:52 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:00:52 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 03:00:52 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 03:00:52 --> Final output sent to browser
DEBUG - 2010-07-05 03:00:52 --> Total execution time: 0.3048
DEBUG - 2010-07-05 03:01:19 --> Config Class Initialized
DEBUG - 2010-07-05 03:01:19 --> Hooks Class Initialized
DEBUG - 2010-07-05 03:01:19 --> URI Class Initialized
DEBUG - 2010-07-05 03:01:19 --> Router Class Initialized
DEBUG - 2010-07-05 03:01:19 --> Output Class Initialized
DEBUG - 2010-07-05 03:01:19 --> Input Class Initialized
DEBUG - 2010-07-05 03:01:19 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 03:01:19 --> Language Class Initialized
DEBUG - 2010-07-05 03:01:19 --> Loader Class Initialized
DEBUG - 2010-07-05 03:01:19 --> Helper loaded: context_helper
DEBUG - 2010-07-05 03:01:19 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 03:01:20 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 03:01:20 --> Database Driver Class Initialized
DEBUG - 2010-07-05 03:01:20 --> Controller Class Initialized
DEBUG - 2010-07-05 03:01:20 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 03:01:20 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 03:01:20 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 03:01:20 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:01:20 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:01:20 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:01:20 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 03:01:20 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 03:01:20 --> Final output sent to browser
DEBUG - 2010-07-05 03:01:20 --> Total execution time: 0.3153
DEBUG - 2010-07-05 03:02:48 --> Config Class Initialized
DEBUG - 2010-07-05 03:02:48 --> Hooks Class Initialized
DEBUG - 2010-07-05 03:02:48 --> URI Class Initialized
DEBUG - 2010-07-05 03:02:48 --> Router Class Initialized
DEBUG - 2010-07-05 03:02:48 --> Output Class Initialized
DEBUG - 2010-07-05 03:02:48 --> Input Class Initialized
DEBUG - 2010-07-05 03:02:48 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 03:02:48 --> Language Class Initialized
DEBUG - 2010-07-05 03:02:48 --> Loader Class Initialized
DEBUG - 2010-07-05 03:02:48 --> Helper loaded: context_helper
DEBUG - 2010-07-05 03:02:48 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 03:02:48 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 03:02:48 --> Database Driver Class Initialized
DEBUG - 2010-07-05 03:02:49 --> Controller Class Initialized
DEBUG - 2010-07-05 03:02:49 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 03:02:49 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 03:02:49 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 03:02:49 --> Session Class Initialized
DEBUG - 2010-07-05 03:02:49 --> Helper loaded: string_helper
DEBUG - 2010-07-05 03:02:49 --> A session cookie was not found.
DEBUG - 2010-07-05 03:02:49 --> Session routines successfully run
DEBUG - 2010-07-05 03:02:49 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:02:49 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:02:49 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:02:49 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 03:02:49 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:02:49 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:02:49 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:02:49 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 03:02:49 --> Final output sent to browser
DEBUG - 2010-07-05 03:02:49 --> Total execution time: 0.5546
DEBUG - 2010-07-05 03:04:25 --> Config Class Initialized
DEBUG - 2010-07-05 03:04:25 --> Hooks Class Initialized
DEBUG - 2010-07-05 03:04:25 --> URI Class Initialized
DEBUG - 2010-07-05 03:04:25 --> Router Class Initialized
DEBUG - 2010-07-05 03:04:25 --> Output Class Initialized
DEBUG - 2010-07-05 03:04:25 --> Input Class Initialized
DEBUG - 2010-07-05 03:04:25 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 03:04:25 --> Language Class Initialized
DEBUG - 2010-07-05 03:04:25 --> Loader Class Initialized
DEBUG - 2010-07-05 03:04:25 --> Helper loaded: context_helper
DEBUG - 2010-07-05 03:04:25 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 03:04:25 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 03:04:25 --> Database Driver Class Initialized
DEBUG - 2010-07-05 03:04:25 --> Controller Class Initialized
DEBUG - 2010-07-05 03:04:25 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 03:04:25 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 03:04:25 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 03:04:25 --> Session Class Initialized
DEBUG - 2010-07-05 03:04:25 --> Helper loaded: string_helper
DEBUG - 2010-07-05 03:04:25 --> Session routines successfully run
DEBUG - 2010-07-05 03:04:25 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:04:25 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:04:25 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:04:25 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 03:04:25 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:04:25 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:04:25 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:04:25 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 03:04:25 --> Final output sent to browser
DEBUG - 2010-07-05 03:04:25 --> Total execution time: 0.4941
DEBUG - 2010-07-05 03:07:27 --> Config Class Initialized
DEBUG - 2010-07-05 03:07:27 --> Hooks Class Initialized
DEBUG - 2010-07-05 03:07:27 --> URI Class Initialized
DEBUG - 2010-07-05 03:07:27 --> Router Class Initialized
DEBUG - 2010-07-05 03:07:27 --> Output Class Initialized
DEBUG - 2010-07-05 03:07:27 --> Input Class Initialized
DEBUG - 2010-07-05 03:07:27 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 03:07:27 --> Language Class Initialized
DEBUG - 2010-07-05 03:07:27 --> Loader Class Initialized
DEBUG - 2010-07-05 03:07:27 --> Helper loaded: context_helper
DEBUG - 2010-07-05 03:07:27 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 03:07:27 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 03:07:27 --> Database Driver Class Initialized
DEBUG - 2010-07-05 03:07:27 --> Controller Class Initialized
DEBUG - 2010-07-05 03:07:27 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 03:07:27 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 03:07:27 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 03:07:27 --> Session Class Initialized
DEBUG - 2010-07-05 03:07:27 --> Helper loaded: string_helper
DEBUG - 2010-07-05 03:07:27 --> A session cookie was not found.
DEBUG - 2010-07-05 03:07:27 --> Session routines successfully run
DEBUG - 2010-07-05 03:07:27 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:07:27 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:07:27 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:07:27 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 03:07:27 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:07:27 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:07:27 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:07:27 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 03:07:27 --> Final output sent to browser
DEBUG - 2010-07-05 03:07:28 --> Total execution time: 0.5738
DEBUG - 2010-07-05 03:08:58 --> Config Class Initialized
DEBUG - 2010-07-05 03:08:58 --> Hooks Class Initialized
DEBUG - 2010-07-05 03:08:58 --> URI Class Initialized
DEBUG - 2010-07-05 03:08:58 --> Router Class Initialized
DEBUG - 2010-07-05 03:08:58 --> Output Class Initialized
DEBUG - 2010-07-05 03:08:58 --> Input Class Initialized
DEBUG - 2010-07-05 03:08:58 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 03:08:58 --> Language Class Initialized
DEBUG - 2010-07-05 03:08:58 --> Loader Class Initialized
DEBUG - 2010-07-05 03:08:58 --> Helper loaded: context_helper
DEBUG - 2010-07-05 03:08:58 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 03:08:58 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 03:08:58 --> Database Driver Class Initialized
DEBUG - 2010-07-05 03:08:58 --> Controller Class Initialized
DEBUG - 2010-07-05 03:08:58 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 03:08:58 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 03:08:58 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 03:08:58 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:08:58 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:08:58 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:08:58 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 03:08:58 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:08:58 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:08:58 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:08:58 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 03:08:58 --> Final output sent to browser
DEBUG - 2010-07-05 03:08:58 --> Total execution time: 0.4718
DEBUG - 2010-07-05 03:10:14 --> Config Class Initialized
DEBUG - 2010-07-05 03:10:14 --> Hooks Class Initialized
DEBUG - 2010-07-05 03:10:14 --> URI Class Initialized
DEBUG - 2010-07-05 03:10:14 --> Router Class Initialized
DEBUG - 2010-07-05 03:10:14 --> Output Class Initialized
DEBUG - 2010-07-05 03:10:14 --> Input Class Initialized
DEBUG - 2010-07-05 03:10:14 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 03:10:14 --> Language Class Initialized
DEBUG - 2010-07-05 03:10:14 --> Loader Class Initialized
DEBUG - 2010-07-05 03:10:14 --> Helper loaded: context_helper
DEBUG - 2010-07-05 03:10:14 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 03:10:14 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 03:10:14 --> Database Driver Class Initialized
DEBUG - 2010-07-05 03:10:14 --> Controller Class Initialized
DEBUG - 2010-07-05 03:10:14 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 03:10:14 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 03:10:14 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 03:10:14 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:10:14 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:10:14 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:10:14 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 03:10:14 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:10:14 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:10:14 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:10:14 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 03:10:14 --> Final output sent to browser
DEBUG - 2010-07-05 03:10:14 --> Total execution time: 0.4949
DEBUG - 2010-07-05 03:11:17 --> Config Class Initialized
DEBUG - 2010-07-05 03:11:17 --> Hooks Class Initialized
DEBUG - 2010-07-05 03:11:17 --> URI Class Initialized
DEBUG - 2010-07-05 03:11:17 --> Router Class Initialized
DEBUG - 2010-07-05 03:11:17 --> Output Class Initialized
DEBUG - 2010-07-05 03:11:17 --> Input Class Initialized
DEBUG - 2010-07-05 03:11:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 03:11:17 --> Language Class Initialized
DEBUG - 2010-07-05 03:11:17 --> Loader Class Initialized
DEBUG - 2010-07-05 03:11:17 --> Helper loaded: context_helper
DEBUG - 2010-07-05 03:11:17 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 03:11:17 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 03:11:17 --> Database Driver Class Initialized
DEBUG - 2010-07-05 03:11:17 --> Controller Class Initialized
DEBUG - 2010-07-05 03:11:17 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 03:11:17 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 03:11:17 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 03:11:17 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:11:17 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:11:17 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:11:17 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 03:11:17 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:11:17 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:11:17 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:11:17 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 03:11:17 --> Final output sent to browser
DEBUG - 2010-07-05 03:11:17 --> Total execution time: 0.4451
DEBUG - 2010-07-05 03:11:36 --> Config Class Initialized
DEBUG - 2010-07-05 03:11:36 --> Hooks Class Initialized
DEBUG - 2010-07-05 03:11:36 --> URI Class Initialized
DEBUG - 2010-07-05 03:11:36 --> Router Class Initialized
DEBUG - 2010-07-05 03:11:36 --> Output Class Initialized
DEBUG - 2010-07-05 03:11:36 --> Input Class Initialized
DEBUG - 2010-07-05 03:11:36 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 03:11:36 --> Language Class Initialized
DEBUG - 2010-07-05 03:11:36 --> Loader Class Initialized
DEBUG - 2010-07-05 03:11:36 --> Helper loaded: context_helper
DEBUG - 2010-07-05 03:11:36 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 03:11:36 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 03:11:36 --> Database Driver Class Initialized
DEBUG - 2010-07-05 03:11:36 --> Controller Class Initialized
DEBUG - 2010-07-05 03:11:36 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 03:11:36 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 03:11:37 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 03:11:37 --> Session Class Initialized
DEBUG - 2010-07-05 03:11:37 --> Helper loaded: string_helper
DEBUG - 2010-07-05 03:11:37 --> Session routines successfully run
DEBUG - 2010-07-05 03:11:37 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:11:37 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:11:37 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:11:37 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 03:11:37 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:11:37 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:11:37 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:11:37 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 03:11:37 --> Final output sent to browser
DEBUG - 2010-07-05 03:11:37 --> Total execution time: 0.5888
DEBUG - 2010-07-05 03:12:32 --> Config Class Initialized
DEBUG - 2010-07-05 03:12:32 --> Hooks Class Initialized
DEBUG - 2010-07-05 03:12:32 --> URI Class Initialized
DEBUG - 2010-07-05 03:12:32 --> Router Class Initialized
DEBUG - 2010-07-05 03:12:32 --> Output Class Initialized
DEBUG - 2010-07-05 03:12:32 --> Input Class Initialized
DEBUG - 2010-07-05 03:12:32 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 03:12:32 --> Language Class Initialized
DEBUG - 2010-07-05 03:12:32 --> Loader Class Initialized
DEBUG - 2010-07-05 03:12:32 --> Helper loaded: context_helper
DEBUG - 2010-07-05 03:12:32 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 03:12:32 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 03:12:32 --> Database Driver Class Initialized
DEBUG - 2010-07-05 03:12:32 --> Controller Class Initialized
DEBUG - 2010-07-05 03:12:32 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 03:12:32 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 03:12:32 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 03:12:32 --> Session Class Initialized
DEBUG - 2010-07-05 03:12:32 --> Helper loaded: string_helper
DEBUG - 2010-07-05 03:12:32 --> Session routines successfully run
DEBUG - 2010-07-05 03:12:32 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:12:32 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:12:32 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:12:32 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 03:12:32 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:12:32 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:12:32 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:12:32 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 03:12:32 --> Final output sent to browser
DEBUG - 2010-07-05 03:12:32 --> Total execution time: 0.6369
DEBUG - 2010-07-05 03:58:22 --> Config Class Initialized
DEBUG - 2010-07-05 03:58:22 --> Hooks Class Initialized
DEBUG - 2010-07-05 03:58:22 --> URI Class Initialized
DEBUG - 2010-07-05 03:58:22 --> Router Class Initialized
DEBUG - 2010-07-05 03:58:22 --> Output Class Initialized
DEBUG - 2010-07-05 03:58:23 --> Input Class Initialized
DEBUG - 2010-07-05 03:58:23 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 03:58:23 --> Language Class Initialized
DEBUG - 2010-07-05 03:58:23 --> Loader Class Initialized
DEBUG - 2010-07-05 03:58:23 --> Helper loaded: context_helper
DEBUG - 2010-07-05 03:58:23 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 03:58:23 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 03:58:23 --> Database Driver Class Initialized
DEBUG - 2010-07-05 03:58:23 --> Controller Class Initialized
DEBUG - 2010-07-05 03:58:23 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 03:58:23 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 03:58:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:23 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:23 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:23 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:23 --> Helper loaded: email_helper
DEBUG - 2010-07-05 03:58:23 --> User Agent Class Initialized
DEBUG - 2010-07-05 03:58:23 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:23 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:23 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-05 03:58:23 --> Unable to load the requested class: scope_anchor_text
DEBUG - 2010-07-05 03:58:48 --> Config Class Initialized
DEBUG - 2010-07-05 03:58:48 --> Hooks Class Initialized
DEBUG - 2010-07-05 03:58:48 --> URI Class Initialized
DEBUG - 2010-07-05 03:58:48 --> Router Class Initialized
DEBUG - 2010-07-05 03:58:48 --> Output Class Initialized
DEBUG - 2010-07-05 03:58:48 --> Input Class Initialized
DEBUG - 2010-07-05 03:58:48 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 03:58:48 --> Language Class Initialized
DEBUG - 2010-07-05 03:58:48 --> Loader Class Initialized
DEBUG - 2010-07-05 03:58:48 --> Helper loaded: context_helper
DEBUG - 2010-07-05 03:58:48 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 03:58:48 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 03:58:48 --> Database Driver Class Initialized
DEBUG - 2010-07-05 03:58:48 --> Controller Class Initialized
DEBUG - 2010-07-05 03:58:48 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 03:58:48 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 03:58:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:48 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:48 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:48 --> Helper loaded: email_helper
DEBUG - 2010-07-05 03:58:48 --> User Agent Class Initialized
DEBUG - 2010-07-05 03:58:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:48 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:48 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:48 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 03:58:48 --> Session Class Initialized
DEBUG - 2010-07-05 03:58:48 --> Helper loaded: string_helper
DEBUG - 2010-07-05 03:58:48 --> Session routines successfully run
DEBUG - 2010-07-05 03:58:48 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:48 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:49 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:49 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:49 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-05 03:58:49 --> Severity: Notice  --> Undefined variable: text D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Scope_anchor_text.php 94
DEBUG - 2010-07-05 03:58:49 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:49 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:49 --> Segmentor class already loaded. Second attempt ignored.
ERROR - 2010-07-05 03:58:49 --> Severity: Notice  --> Undefined variable: form D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Annotation_scope.php 88
DEBUG - 2010-07-05 03:58:49 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:49 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:49 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 03:58:49 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:49 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:49 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:49 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:49 --> Action_domain_administration class already loaded. Second attempt ignored.
ERROR - 2010-07-05 03:58:49 --> Severity: Notice  --> Undefined variable: text D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Scope_anchor_text.php 94
DEBUG - 2010-07-05 03:58:49 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:49 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:49 --> Segmentor class already loaded. Second attempt ignored.
ERROR - 2010-07-05 03:58:49 --> Severity: Notice  --> Undefined variable: form D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Annotation_scope.php 88
DEBUG - 2010-07-05 03:58:49 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:49 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:49 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:49 --> Action_domain_administration class already loaded. Second attempt ignored.
ERROR - 2010-07-05 03:58:49 --> Severity: Notice  --> Undefined variable: text D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Scope_anchor_text.php 94
DEBUG - 2010-07-05 03:58:49 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:49 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:49 --> Segmentor class already loaded. Second attempt ignored.
ERROR - 2010-07-05 03:58:50 --> Severity: Notice  --> Undefined variable: form D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Annotation_scope.php 88
DEBUG - 2010-07-05 03:58:50 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:50 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:58:50 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 03:58:50 --> Final output sent to browser
DEBUG - 2010-07-05 03:58:50 --> Total execution time: 1.9832
DEBUG - 2010-07-05 03:59:31 --> Config Class Initialized
DEBUG - 2010-07-05 03:59:31 --> Hooks Class Initialized
DEBUG - 2010-07-05 03:59:31 --> URI Class Initialized
DEBUG - 2010-07-05 03:59:31 --> Router Class Initialized
DEBUG - 2010-07-05 03:59:31 --> Output Class Initialized
DEBUG - 2010-07-05 03:59:31 --> Input Class Initialized
DEBUG - 2010-07-05 03:59:31 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 03:59:31 --> Language Class Initialized
DEBUG - 2010-07-05 03:59:31 --> Loader Class Initialized
DEBUG - 2010-07-05 03:59:31 --> Helper loaded: context_helper
DEBUG - 2010-07-05 03:59:31 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 03:59:31 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 03:59:31 --> Database Driver Class Initialized
DEBUG - 2010-07-05 03:59:32 --> Controller Class Initialized
DEBUG - 2010-07-05 03:59:32 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 03:59:32 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 03:59:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:32 --> Helper loaded: email_helper
DEBUG - 2010-07-05 03:59:32 --> User Agent Class Initialized
DEBUG - 2010-07-05 03:59:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:32 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:32 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 03:59:32 --> Session Class Initialized
DEBUG - 2010-07-05 03:59:32 --> Helper loaded: string_helper
DEBUG - 2010-07-05 03:59:32 --> Session routines successfully run
DEBUG - 2010-07-05 03:59:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:32 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:32 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:33 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:33 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:33 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:33 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:33 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:33 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 03:59:33 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:33 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:33 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:33 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:33 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:33 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:33 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:33 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:33 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:33 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:33 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:33 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:33 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:33 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:33 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:33 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:33 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 03:59:33 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 03:59:33 --> Final output sent to browser
DEBUG - 2010-07-05 03:59:33 --> Total execution time: 1.9964
DEBUG - 2010-07-05 05:00:58 --> Config Class Initialized
DEBUG - 2010-07-05 05:00:58 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:00:58 --> URI Class Initialized
DEBUG - 2010-07-05 05:00:58 --> Router Class Initialized
DEBUG - 2010-07-05 05:00:58 --> Output Class Initialized
DEBUG - 2010-07-05 05:00:58 --> Input Class Initialized
DEBUG - 2010-07-05 05:00:58 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:00:58 --> Language Class Initialized
DEBUG - 2010-07-05 05:00:58 --> Loader Class Initialized
DEBUG - 2010-07-05 05:00:58 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:00:58 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:00:58 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:00:58 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:00:58 --> Controller Class Initialized
DEBUG - 2010-07-05 05:00:58 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:00:58 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:00:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:00:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:00:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:00:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:00:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:00:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:00:58 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:00:58 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:00:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:00:58 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:00:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:00:58 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:00:58 --> Session Class Initialized
DEBUG - 2010-07-05 05:00:58 --> Helper loaded: string_helper
DEBUG - 2010-07-05 05:00:58 --> Session routines successfully run
DEBUG - 2010-07-05 05:00:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:00:59 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:00:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:00:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:00:59 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:00:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:00:59 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:00:59 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:00:59 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:00:59 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:00:59 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:00:59 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 05:00:59 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:00:59 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:00:59 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:00:59 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:00:59 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:00:59 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:00:59 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:00:59 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:00:59 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:00:59 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:00 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:00 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:00 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:00 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:00 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:00 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:00 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:00 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 05:01:00 --> Final output sent to browser
DEBUG - 2010-07-05 05:01:00 --> Total execution time: 2.0008
DEBUG - 2010-07-05 05:01:25 --> Config Class Initialized
DEBUG - 2010-07-05 05:01:25 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:01:25 --> URI Class Initialized
DEBUG - 2010-07-05 05:01:25 --> Router Class Initialized
DEBUG - 2010-07-05 05:01:25 --> Output Class Initialized
DEBUG - 2010-07-05 05:01:25 --> Input Class Initialized
DEBUG - 2010-07-05 05:01:25 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:01:25 --> Language Class Initialized
DEBUG - 2010-07-05 05:01:25 --> Loader Class Initialized
DEBUG - 2010-07-05 05:01:25 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:01:25 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:01:25 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:01:25 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:01:25 --> Controller Class Initialized
DEBUG - 2010-07-05 05:01:25 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:01:25 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:01:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:25 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:01:25 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:01:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:25 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:25 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:01:25 --> Session Class Initialized
DEBUG - 2010-07-05 05:01:25 --> Helper loaded: string_helper
DEBUG - 2010-07-05 05:01:26 --> Session routines successfully run
DEBUG - 2010-07-05 05:01:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:26 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:26 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:26 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:26 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:26 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:26 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:26 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 05:01:26 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid input syntax for integer: &quot;[CODING D15] 嗯，今天乖乖地集中在一串。&quot;
LINE 1: ... &quot;to_index&quot;, &quot;anchor_text_id&quot;) VALUES (89, 2, 18, '[CODING D...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-05 05:01:26 --> DB Transaction Failure
ERROR - 2010-07-05 05:01:26 --> Query error: ERROR:  invalid input syntax for integer: "[CODING D15] 嗯，今天乖乖地集中在一串。"
LINE 1: ... "to_index", "anchor_text_id") VALUES (89, 2, 18, '[CODING D...
                                                             ^
DEBUG - 2010-07-05 05:01:26 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-05 05:01:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:377) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-05 05:01:58 --> Config Class Initialized
DEBUG - 2010-07-05 05:01:58 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:01:58 --> URI Class Initialized
DEBUG - 2010-07-05 05:01:58 --> Router Class Initialized
DEBUG - 2010-07-05 05:01:58 --> Output Class Initialized
DEBUG - 2010-07-05 05:01:58 --> Input Class Initialized
DEBUG - 2010-07-05 05:01:58 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:01:58 --> Language Class Initialized
DEBUG - 2010-07-05 05:01:58 --> Loader Class Initialized
DEBUG - 2010-07-05 05:01:58 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:01:58 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:01:58 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:01:58 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:01:58 --> Controller Class Initialized
DEBUG - 2010-07-05 05:01:58 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:01:58 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:01:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:59 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:01:59 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:01:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:59 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:59 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:01:59 --> Session Class Initialized
DEBUG - 2010-07-05 05:01:59 --> Helper loaded: string_helper
DEBUG - 2010-07-05 05:01:59 --> Session routines successfully run
DEBUG - 2010-07-05 05:01:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:59 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:59 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:59 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:59 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:01:59 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:02:00 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:02:00 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:02:00 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 05:02:00 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:02:00 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:02:00 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:02:00 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:02:00 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:02:00 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:02:00 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:02:00 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:02:00 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:02:00 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:02:00 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:02:00 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:02:00 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:02:00 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:02:00 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:02:00 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:02:00 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:02:00 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 05:02:00 --> Final output sent to browser
DEBUG - 2010-07-05 05:02:00 --> Total execution time: 2.1292
DEBUG - 2010-07-05 05:06:26 --> Config Class Initialized
DEBUG - 2010-07-05 05:06:26 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:06:26 --> URI Class Initialized
DEBUG - 2010-07-05 05:06:26 --> Router Class Initialized
DEBUG - 2010-07-05 05:06:26 --> Output Class Initialized
DEBUG - 2010-07-05 05:06:26 --> Input Class Initialized
DEBUG - 2010-07-05 05:06:26 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:06:26 --> Language Class Initialized
DEBUG - 2010-07-05 05:06:26 --> Loader Class Initialized
DEBUG - 2010-07-05 05:06:26 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:06:26 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:06:26 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:06:26 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:06:27 --> Controller Class Initialized
DEBUG - 2010-07-05 05:06:27 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:06:27 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:06:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:27 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:27 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:27 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:27 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:06:27 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:06:27 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:27 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:27 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:06:27 --> Session Class Initialized
DEBUG - 2010-07-05 05:06:27 --> Helper loaded: string_helper
DEBUG - 2010-07-05 05:06:27 --> Session routines successfully run
DEBUG - 2010-07-05 05:06:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:27 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:28 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:28 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:28 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:28 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:28 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:28 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 05:06:28 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:28 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:28 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:28 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:28 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:28 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:28 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:28 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:28 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:28 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:28 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:28 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:28 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:28 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:28 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:06:28 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 05:06:28 --> Final output sent to browser
DEBUG - 2010-07-05 05:06:28 --> Total execution time: 2.2862
DEBUG - 2010-07-05 05:12:47 --> Config Class Initialized
DEBUG - 2010-07-05 05:12:47 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:12:47 --> URI Class Initialized
DEBUG - 2010-07-05 05:12:47 --> Router Class Initialized
DEBUG - 2010-07-05 05:12:47 --> Output Class Initialized
DEBUG - 2010-07-05 05:12:47 --> Input Class Initialized
DEBUG - 2010-07-05 05:12:47 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:12:47 --> Language Class Initialized
DEBUG - 2010-07-05 05:12:47 --> Loader Class Initialized
DEBUG - 2010-07-05 05:12:47 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:12:47 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:12:48 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:12:48 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:12:48 --> Controller Class Initialized
DEBUG - 2010-07-05 05:12:48 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:12:48 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:12:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:48 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:48 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:48 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:12:48 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:12:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:48 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:48 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:48 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:12:48 --> Session Class Initialized
DEBUG - 2010-07-05 05:12:48 --> Helper loaded: string_helper
DEBUG - 2010-07-05 05:12:48 --> Session routines successfully run
DEBUG - 2010-07-05 05:12:48 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:48 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:49 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:49 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:49 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:49 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:49 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:49 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:49 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:49 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:49 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 05:12:49 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:49 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:49 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:49 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:49 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:49 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:49 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:49 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:49 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:49 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:49 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:49 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:49 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:49 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:49 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:50 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:50 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:12:50 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 05:12:50 --> Final output sent to browser
DEBUG - 2010-07-05 05:12:50 --> Total execution time: 2.4659
DEBUG - 2010-07-05 05:13:21 --> Config Class Initialized
DEBUG - 2010-07-05 05:13:21 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:13:21 --> URI Class Initialized
DEBUG - 2010-07-05 05:13:21 --> Router Class Initialized
DEBUG - 2010-07-05 05:13:21 --> Output Class Initialized
DEBUG - 2010-07-05 05:13:21 --> Input Class Initialized
DEBUG - 2010-07-05 05:13:22 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:13:22 --> Language Class Initialized
DEBUG - 2010-07-05 05:13:22 --> Loader Class Initialized
DEBUG - 2010-07-05 05:13:22 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:13:22 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:13:22 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:13:22 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:13:22 --> Controller Class Initialized
DEBUG - 2010-07-05 05:13:22 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:13:22 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:13:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:22 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:22 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:22 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:13:22 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:13:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:22 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:22 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:13:22 --> Session Class Initialized
DEBUG - 2010-07-05 05:13:22 --> Helper loaded: string_helper
DEBUG - 2010-07-05 05:13:22 --> Session routines successfully run
DEBUG - 2010-07-05 05:13:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:22 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:23 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:23 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:23 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:23 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:23 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 05:13:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:23 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:23 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:23 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:23 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:23 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:23 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:23 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:24 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:24 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:24 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:24 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:24 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:24 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:13:24 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 05:13:24 --> Final output sent to browser
DEBUG - 2010-07-05 05:13:24 --> Total execution time: 2.4294
DEBUG - 2010-07-05 05:14:29 --> Config Class Initialized
DEBUG - 2010-07-05 05:14:29 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:14:29 --> URI Class Initialized
DEBUG - 2010-07-05 05:14:29 --> Router Class Initialized
DEBUG - 2010-07-05 05:14:29 --> Output Class Initialized
DEBUG - 2010-07-05 05:14:29 --> Input Class Initialized
DEBUG - 2010-07-05 05:14:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:14:29 --> Language Class Initialized
DEBUG - 2010-07-05 05:14:29 --> Loader Class Initialized
DEBUG - 2010-07-05 05:14:29 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:14:29 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:14:29 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:14:29 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:14:29 --> Controller Class Initialized
DEBUG - 2010-07-05 05:14:29 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:14:29 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:14:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:30 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:14:30 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:14:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:30 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:30 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:14:30 --> Session Class Initialized
DEBUG - 2010-07-05 05:14:30 --> Helper loaded: string_helper
DEBUG - 2010-07-05 05:14:30 --> Session routines successfully run
DEBUG - 2010-07-05 05:14:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:30 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:31 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:31 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:31 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:31 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:31 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:31 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:31 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 05:14:31 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:31 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:31 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:31 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:31 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:31 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:31 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:31 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:31 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:31 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:31 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:31 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:31 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:31 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:31 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:31 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:31 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:14:31 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 05:14:31 --> Final output sent to browser
DEBUG - 2010-07-05 05:14:32 --> Total execution time: 2.5135
DEBUG - 2010-07-05 05:15:39 --> Config Class Initialized
DEBUG - 2010-07-05 05:15:39 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:15:39 --> URI Class Initialized
DEBUG - 2010-07-05 05:15:39 --> Router Class Initialized
DEBUG - 2010-07-05 05:15:39 --> Output Class Initialized
DEBUG - 2010-07-05 05:15:39 --> Input Class Initialized
DEBUG - 2010-07-05 05:15:39 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:15:39 --> Language Class Initialized
DEBUG - 2010-07-05 05:15:39 --> Loader Class Initialized
DEBUG - 2010-07-05 05:15:39 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:15:40 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:15:40 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:15:40 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:15:40 --> Controller Class Initialized
DEBUG - 2010-07-05 05:15:40 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:15:40 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:15:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:40 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:40 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:40 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:15:40 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:15:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:40 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:40 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:15:40 --> Session Class Initialized
DEBUG - 2010-07-05 05:15:40 --> Helper loaded: string_helper
DEBUG - 2010-07-05 05:15:40 --> Session routines successfully run
DEBUG - 2010-07-05 05:15:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:40 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:41 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:41 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:41 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:41 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:41 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:41 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:41 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 05:15:41 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:41 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:41 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:41 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:41 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:41 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:41 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:41 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:41 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:42 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:42 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:42 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:42 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:42 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:42 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:42 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:42 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:15:42 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 05:15:42 --> Final output sent to browser
DEBUG - 2010-07-05 05:15:42 --> Total execution time: 2.7041
DEBUG - 2010-07-05 05:16:06 --> Config Class Initialized
DEBUG - 2010-07-05 05:16:06 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:16:06 --> URI Class Initialized
DEBUG - 2010-07-05 05:16:06 --> Router Class Initialized
DEBUG - 2010-07-05 05:16:06 --> Output Class Initialized
DEBUG - 2010-07-05 05:16:07 --> Input Class Initialized
DEBUG - 2010-07-05 05:16:07 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:16:07 --> Language Class Initialized
DEBUG - 2010-07-05 05:16:07 --> Loader Class Initialized
DEBUG - 2010-07-05 05:16:07 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:16:07 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:16:07 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:16:07 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:16:07 --> Controller Class Initialized
DEBUG - 2010-07-05 05:16:07 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:16:07 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:16:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:07 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:16:07 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:16:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:07 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:07 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:16:07 --> Session Class Initialized
DEBUG - 2010-07-05 05:16:07 --> Helper loaded: string_helper
DEBUG - 2010-07-05 05:16:07 --> Session routines successfully run
DEBUG - 2010-07-05 05:16:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:08 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:08 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:08 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:08 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:08 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:08 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:08 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:08 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 05:16:08 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:08 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:08 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:08 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:08 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:09 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:09 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:09 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:09 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:09 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:09 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:09 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:09 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:09 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:09 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:09 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:16:09 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 05:16:09 --> Final output sent to browser
DEBUG - 2010-07-05 05:16:09 --> Total execution time: 2.6838
DEBUG - 2010-07-05 05:17:24 --> Config Class Initialized
DEBUG - 2010-07-05 05:17:24 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:17:24 --> URI Class Initialized
DEBUG - 2010-07-05 05:17:24 --> Router Class Initialized
DEBUG - 2010-07-05 05:17:24 --> Output Class Initialized
DEBUG - 2010-07-05 05:17:24 --> Input Class Initialized
DEBUG - 2010-07-05 05:17:24 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:17:24 --> Language Class Initialized
DEBUG - 2010-07-05 05:17:25 --> Loader Class Initialized
DEBUG - 2010-07-05 05:17:25 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:17:25 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:17:25 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:17:25 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:17:25 --> Controller Class Initialized
DEBUG - 2010-07-05 05:17:25 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:17:25 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:17:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:25 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:17:25 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:17:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:25 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:25 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:17:25 --> Session Class Initialized
DEBUG - 2010-07-05 05:17:25 --> Helper loaded: string_helper
DEBUG - 2010-07-05 05:17:25 --> Session routines successfully run
DEBUG - 2010-07-05 05:17:25 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:25 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:26 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:26 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:26 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:26 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:26 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:26 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:26 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 05:17:26 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:26 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:26 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:26 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:27 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:27 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:27 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:27 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:27 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:27 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:27 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:27 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:27 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:27 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:27 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:27 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:27 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:17:27 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 05:17:27 --> Final output sent to browser
DEBUG - 2010-07-05 05:17:27 --> Total execution time: 2.8293
DEBUG - 2010-07-05 05:18:42 --> Config Class Initialized
DEBUG - 2010-07-05 05:18:42 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:18:42 --> URI Class Initialized
DEBUG - 2010-07-05 05:18:42 --> Router Class Initialized
DEBUG - 2010-07-05 05:18:43 --> Output Class Initialized
DEBUG - 2010-07-05 05:18:43 --> Input Class Initialized
DEBUG - 2010-07-05 05:18:43 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:18:43 --> Language Class Initialized
DEBUG - 2010-07-05 05:18:43 --> Loader Class Initialized
DEBUG - 2010-07-05 05:18:43 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:18:43 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:18:43 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:18:43 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:18:43 --> Controller Class Initialized
DEBUG - 2010-07-05 05:18:43 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:18:43 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:18:43 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:43 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:43 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:43 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:43 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:43 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:43 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:18:43 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:18:43 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:43 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:43 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:43 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:18:44 --> Session Class Initialized
DEBUG - 2010-07-05 05:18:44 --> Helper loaded: string_helper
DEBUG - 2010-07-05 05:18:44 --> Session routines successfully run
DEBUG - 2010-07-05 05:18:44 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:44 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:44 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:44 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:44 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:44 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:44 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:44 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:44 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:44 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:45 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 05:18:45 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:45 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:45 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:45 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:45 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:45 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:45 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:45 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:45 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:45 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:45 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:45 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:45 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:45 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:45 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:45 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:45 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:18:45 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 05:18:45 --> Final output sent to browser
DEBUG - 2010-07-05 05:18:45 --> Total execution time: 2.9408
DEBUG - 2010-07-05 05:19:20 --> Config Class Initialized
DEBUG - 2010-07-05 05:19:20 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:19:20 --> URI Class Initialized
DEBUG - 2010-07-05 05:19:20 --> Router Class Initialized
DEBUG - 2010-07-05 05:19:20 --> Output Class Initialized
DEBUG - 2010-07-05 05:19:20 --> Input Class Initialized
DEBUG - 2010-07-05 05:19:20 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:19:20 --> Language Class Initialized
DEBUG - 2010-07-05 05:19:20 --> Loader Class Initialized
DEBUG - 2010-07-05 05:19:20 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:19:20 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:19:21 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:19:21 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:19:21 --> Controller Class Initialized
DEBUG - 2010-07-05 05:19:21 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:19:21 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:19:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:21 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:21 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:21 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:21 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:19:21 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:19:21 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:21 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:21 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:19:21 --> Session Class Initialized
DEBUG - 2010-07-05 05:19:21 --> Helper loaded: string_helper
DEBUG - 2010-07-05 05:19:21 --> Session routines successfully run
DEBUG - 2010-07-05 05:19:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:21 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:22 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:22 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:22 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:22 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:23 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:23 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:23 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 05:19:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:23 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:23 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:23 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:23 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:23 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:23 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:23 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:23 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:23 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:23 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:23 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:23 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 05:19:23 --> Final output sent to browser
DEBUG - 2010-07-05 05:19:23 --> Total execution time: 3.3969
DEBUG - 2010-07-05 05:19:36 --> Config Class Initialized
DEBUG - 2010-07-05 05:19:36 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:19:36 --> URI Class Initialized
DEBUG - 2010-07-05 05:19:36 --> Router Class Initialized
DEBUG - 2010-07-05 05:19:36 --> Output Class Initialized
DEBUG - 2010-07-05 05:19:36 --> Input Class Initialized
DEBUG - 2010-07-05 05:19:36 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:19:36 --> Language Class Initialized
DEBUG - 2010-07-05 05:19:36 --> Loader Class Initialized
DEBUG - 2010-07-05 05:19:36 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:19:36 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:19:36 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:19:36 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:19:36 --> Controller Class Initialized
DEBUG - 2010-07-05 05:19:36 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:19:37 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:19:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:37 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:37 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:37 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:19:37 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:19:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:37 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:37 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:19:37 --> Session Class Initialized
DEBUG - 2010-07-05 05:19:37 --> Helper loaded: string_helper
DEBUG - 2010-07-05 05:19:37 --> Session routines successfully run
DEBUG - 2010-07-05 05:19:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:37 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:38 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:38 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:38 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:38 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:38 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:38 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:38 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 05:19:38 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:38 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:38 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:38 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:38 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:38 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:38 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:39 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:39 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:39 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:39 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:39 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:39 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:39 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:39 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:39 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:39 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:39 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 05:19:39 --> Final output sent to browser
DEBUG - 2010-07-05 05:19:39 --> Total execution time: 3.1066
DEBUG - 2010-07-05 05:19:50 --> Config Class Initialized
DEBUG - 2010-07-05 05:19:50 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:19:50 --> URI Class Initialized
DEBUG - 2010-07-05 05:19:50 --> Router Class Initialized
DEBUG - 2010-07-05 05:19:50 --> Output Class Initialized
DEBUG - 2010-07-05 05:19:50 --> Input Class Initialized
DEBUG - 2010-07-05 05:19:50 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:19:51 --> Language Class Initialized
DEBUG - 2010-07-05 05:19:51 --> Loader Class Initialized
DEBUG - 2010-07-05 05:19:51 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:19:51 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:19:51 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:19:51 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:19:51 --> Controller Class Initialized
DEBUG - 2010-07-05 05:19:51 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:19:51 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:19:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:51 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:51 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:51 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:19:51 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:19:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:51 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:51 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:19:52 --> Session Class Initialized
DEBUG - 2010-07-05 05:19:52 --> Helper loaded: string_helper
DEBUG - 2010-07-05 05:19:52 --> Session routines successfully run
DEBUG - 2010-07-05 05:19:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:52 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:52 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:52 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:52 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:52 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:52 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:53 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:53 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 05:19:53 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:53 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:53 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:53 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:53 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:53 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:53 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:53 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:53 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:53 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:53 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:53 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:53 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:53 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:53 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:53 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:53 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:19:53 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 05:19:53 --> Final output sent to browser
DEBUG - 2010-07-05 05:19:53 --> Total execution time: 3.1920
DEBUG - 2010-07-05 05:24:12 --> Config Class Initialized
DEBUG - 2010-07-05 05:24:12 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:24:12 --> URI Class Initialized
DEBUG - 2010-07-05 05:24:12 --> Router Class Initialized
DEBUG - 2010-07-05 05:24:12 --> Output Class Initialized
DEBUG - 2010-07-05 05:24:12 --> Input Class Initialized
DEBUG - 2010-07-05 05:24:12 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:24:12 --> Language Class Initialized
DEBUG - 2010-07-05 05:24:13 --> Loader Class Initialized
DEBUG - 2010-07-05 05:24:13 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:24:13 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:24:13 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:24:13 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:24:13 --> Controller Class Initialized
DEBUG - 2010-07-05 05:24:13 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:24:13 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:24:13 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:24:13 --> Session Class Initialized
DEBUG - 2010-07-05 05:24:13 --> Helper loaded: string_helper
DEBUG - 2010-07-05 05:24:13 --> Session routines successfully run
DEBUG - 2010-07-05 05:24:13 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:13 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:13 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:13 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 05:24:13 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:13 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:13 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:14 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 05:24:14 --> Final output sent to browser
DEBUG - 2010-07-05 05:24:14 --> Total execution time: 1.4542
DEBUG - 2010-07-05 05:24:28 --> Config Class Initialized
DEBUG - 2010-07-05 05:24:28 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:24:28 --> URI Class Initialized
DEBUG - 2010-07-05 05:24:28 --> Router Class Initialized
DEBUG - 2010-07-05 05:24:29 --> Output Class Initialized
DEBUG - 2010-07-05 05:24:29 --> Input Class Initialized
DEBUG - 2010-07-05 05:24:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:24:29 --> Language Class Initialized
DEBUG - 2010-07-05 05:24:29 --> Loader Class Initialized
DEBUG - 2010-07-05 05:24:29 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:24:29 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:24:29 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:24:29 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:24:29 --> Controller Class Initialized
DEBUG - 2010-07-05 05:24:29 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:24:29 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:24:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:29 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:29 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:29 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:24:30 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:24:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:30 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:30 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:24:30 --> Session Class Initialized
DEBUG - 2010-07-05 05:24:30 --> Helper loaded: string_helper
DEBUG - 2010-07-05 05:24:30 --> Session routines successfully run
DEBUG - 2010-07-05 05:24:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:30 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:31 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:31 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:31 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:31 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:31 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:31 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:31 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 05:24:31 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:31 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:31 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:31 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:31 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:31 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:31 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:31 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:31 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:31 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:31 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:31 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:32 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:32 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:32 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:32 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:32 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:24:32 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 05:24:32 --> Final output sent to browser
DEBUG - 2010-07-05 05:24:32 --> Total execution time: 3.4664
DEBUG - 2010-07-05 05:27:20 --> Config Class Initialized
DEBUG - 2010-07-05 05:27:20 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:27:20 --> URI Class Initialized
DEBUG - 2010-07-05 05:27:20 --> Router Class Initialized
DEBUG - 2010-07-05 05:27:20 --> Output Class Initialized
DEBUG - 2010-07-05 05:27:20 --> Input Class Initialized
DEBUG - 2010-07-05 05:27:20 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:27:20 --> Language Class Initialized
DEBUG - 2010-07-05 05:27:20 --> Loader Class Initialized
DEBUG - 2010-07-05 05:27:20 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:27:20 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:27:21 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:27:21 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:27:21 --> Controller Class Initialized
DEBUG - 2010-07-05 05:27:21 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:27:21 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:27:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:21 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:21 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:21 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:21 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:27:21 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:27:21 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:21 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:22 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:27:22 --> Session Class Initialized
DEBUG - 2010-07-05 05:27:22 --> Helper loaded: string_helper
DEBUG - 2010-07-05 05:27:22 --> Session routines successfully run
DEBUG - 2010-07-05 05:27:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:22 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:22 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:22 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:23 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:23 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:23 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:23 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 05:27:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:23 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:23 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:23 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:23 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:23 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:23 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:23 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:23 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:23 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:24 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:24 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:27:24 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 05:27:24 --> Final output sent to browser
DEBUG - 2010-07-05 05:27:24 --> Total execution time: 3.7334
DEBUG - 2010-07-05 05:29:18 --> Config Class Initialized
DEBUG - 2010-07-05 05:29:18 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:29:18 --> URI Class Initialized
DEBUG - 2010-07-05 05:29:18 --> Router Class Initialized
DEBUG - 2010-07-05 05:29:18 --> Output Class Initialized
DEBUG - 2010-07-05 05:29:18 --> Input Class Initialized
DEBUG - 2010-07-05 05:29:18 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:29:18 --> Language Class Initialized
DEBUG - 2010-07-05 05:29:18 --> Loader Class Initialized
DEBUG - 2010-07-05 05:29:18 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:29:18 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:29:18 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:29:18 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:29:18 --> Controller Class Initialized
DEBUG - 2010-07-05 05:29:18 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:29:18 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:29:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:19 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:19 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:19 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:19 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:29:19 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:29:19 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:19 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:19 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:29:19 --> Session Class Initialized
DEBUG - 2010-07-05 05:29:19 --> Helper loaded: string_helper
DEBUG - 2010-07-05 05:29:19 --> Session routines successfully run
DEBUG - 2010-07-05 05:29:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:19 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:20 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:20 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:20 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:20 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:20 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:20 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:20 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 05:29:20 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:20 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:20 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:20 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:20 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:21 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:21 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:21 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:21 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:21 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:21 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:21 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:21 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:21 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:21 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:21 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:21 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:21 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:21 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:21 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:21 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:21 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:21 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:21 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:29:22 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 05:29:22 --> Final output sent to browser
DEBUG - 2010-07-05 05:29:22 --> Total execution time: 3.9927
DEBUG - 2010-07-05 05:31:20 --> Config Class Initialized
DEBUG - 2010-07-05 05:31:20 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:31:20 --> URI Class Initialized
DEBUG - 2010-07-05 05:31:20 --> Router Class Initialized
DEBUG - 2010-07-05 05:31:20 --> Output Class Initialized
DEBUG - 2010-07-05 05:31:20 --> Input Class Initialized
DEBUG - 2010-07-05 05:31:20 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:31:20 --> Language Class Initialized
DEBUG - 2010-07-05 05:31:20 --> Loader Class Initialized
DEBUG - 2010-07-05 05:31:20 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:31:20 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:31:20 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:31:20 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:31:20 --> Controller Class Initialized
DEBUG - 2010-07-05 05:31:20 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:31:20 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:31:20 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:31:20 --> Session Class Initialized
DEBUG - 2010-07-05 05:31:20 --> Helper loaded: string_helper
DEBUG - 2010-07-05 05:31:21 --> Session routines successfully run
DEBUG - 2010-07-05 05:31:21 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:31:21 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:31:21 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:31:21 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 05:31:21 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:31:21 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:31:21 --> Segmentor class already loaded. Second attempt ignored.
ERROR - 2010-07-05 05:31:21 --> Severity: Notice  --> Undefined variable: text2 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_annotation\ut_scope_anchor_text.php 61
DEBUG - 2010-07-05 05:31:21 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:31:21 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:31:21 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:31:21 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 05:31:21 --> Final output sent to browser
DEBUG - 2010-07-05 05:31:21 --> Total execution time: 1.8016
DEBUG - 2010-07-05 05:31:31 --> Config Class Initialized
DEBUG - 2010-07-05 05:31:31 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:31:31 --> URI Class Initialized
DEBUG - 2010-07-05 05:31:31 --> Router Class Initialized
DEBUG - 2010-07-05 05:31:31 --> Output Class Initialized
DEBUG - 2010-07-05 05:31:31 --> Input Class Initialized
DEBUG - 2010-07-05 05:31:31 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:31:31 --> Language Class Initialized
DEBUG - 2010-07-05 05:31:32 --> Loader Class Initialized
DEBUG - 2010-07-05 05:31:32 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:31:32 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:31:32 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:31:32 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:31:32 --> Controller Class Initialized
DEBUG - 2010-07-05 05:31:32 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:31:32 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:31:32 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:31:32 --> Session Class Initialized
DEBUG - 2010-07-05 05:31:32 --> Helper loaded: string_helper
DEBUG - 2010-07-05 05:31:32 --> Session routines successfully run
DEBUG - 2010-07-05 05:31:32 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:31:32 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:31:32 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:31:32 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 05:31:33 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:31:33 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:31:33 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:31:33 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:31:33 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:31:33 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:31:33 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 05:31:33 --> Final output sent to browser
DEBUG - 2010-07-05 05:31:33 --> Total execution time: 1.8008
DEBUG - 2010-07-05 05:32:44 --> Config Class Initialized
DEBUG - 2010-07-05 05:32:44 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:32:44 --> URI Class Initialized
DEBUG - 2010-07-05 05:32:44 --> Router Class Initialized
DEBUG - 2010-07-05 05:32:44 --> Output Class Initialized
DEBUG - 2010-07-05 05:32:44 --> Input Class Initialized
DEBUG - 2010-07-05 05:32:44 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:32:44 --> Language Class Initialized
DEBUG - 2010-07-05 05:32:44 --> Loader Class Initialized
DEBUG - 2010-07-05 05:32:44 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:32:44 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:32:44 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:32:44 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:32:44 --> Controller Class Initialized
DEBUG - 2010-07-05 05:32:44 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:32:44 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:32:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:45 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:45 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:45 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:32:45 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:32:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:45 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:45 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:45 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:32:45 --> Session Class Initialized
DEBUG - 2010-07-05 05:32:45 --> Helper loaded: string_helper
DEBUG - 2010-07-05 05:32:45 --> Session routines successfully run
DEBUG - 2010-07-05 05:32:45 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:45 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:46 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:46 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:46 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:46 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:46 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:46 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:46 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:46 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 05:32:47 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:47 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:47 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:47 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:47 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:47 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:47 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:47 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:47 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:47 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:47 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:47 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:47 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:47 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:47 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:47 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:47 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:47 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:47 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:48 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:48 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:48 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:48 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:48 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:32:48 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 05:32:48 --> Final output sent to browser
DEBUG - 2010-07-05 05:32:48 --> Total execution time: 4.3823
DEBUG - 2010-07-05 05:33:15 --> Config Class Initialized
DEBUG - 2010-07-05 05:33:15 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:33:15 --> URI Class Initialized
DEBUG - 2010-07-05 05:33:15 --> Router Class Initialized
DEBUG - 2010-07-05 05:33:15 --> Output Class Initialized
DEBUG - 2010-07-05 05:33:15 --> Input Class Initialized
DEBUG - 2010-07-05 05:33:15 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:33:15 --> Language Class Initialized
DEBUG - 2010-07-05 05:33:15 --> Loader Class Initialized
DEBUG - 2010-07-05 05:33:15 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:33:15 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:33:15 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:33:15 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:33:15 --> Controller Class Initialized
DEBUG - 2010-07-05 05:33:15 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:33:15 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:33:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:16 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:16 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:16 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:33:16 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:33:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:16 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:16 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:33:16 --> Session Class Initialized
DEBUG - 2010-07-05 05:33:16 --> Helper loaded: string_helper
DEBUG - 2010-07-05 05:33:16 --> Session routines successfully run
DEBUG - 2010-07-05 05:33:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:16 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:17 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:17 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:17 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:17 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:17 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:17 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:17 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 05:33:18 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:18 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:18 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:18 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:18 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:18 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:18 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:18 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:18 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:18 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:18 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:18 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:18 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:18 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:18 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:18 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:18 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:18 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:19 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:19 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:19 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:19 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:19 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:19 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:33:19 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 05:33:19 --> Final output sent to browser
DEBUG - 2010-07-05 05:33:19 --> Total execution time: 4.4160
DEBUG - 2010-07-05 05:34:31 --> Config Class Initialized
DEBUG - 2010-07-05 05:34:31 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:34:31 --> URI Class Initialized
DEBUG - 2010-07-05 05:34:31 --> Router Class Initialized
DEBUG - 2010-07-05 05:34:31 --> Output Class Initialized
DEBUG - 2010-07-05 05:34:31 --> Input Class Initialized
DEBUG - 2010-07-05 05:34:31 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:34:32 --> Language Class Initialized
DEBUG - 2010-07-05 05:34:32 --> Loader Class Initialized
DEBUG - 2010-07-05 05:34:32 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:34:32 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:34:32 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:34:32 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:34:32 --> Controller Class Initialized
DEBUG - 2010-07-05 05:34:32 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:34:32 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:34:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:32 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:34:33 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:34:33 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:33 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:33 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:34:33 --> Session Class Initialized
DEBUG - 2010-07-05 05:34:33 --> Helper loaded: string_helper
DEBUG - 2010-07-05 05:34:33 --> Session routines successfully run
DEBUG - 2010-07-05 05:34:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:33 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:34 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:34 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:34 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:34 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:34 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:34 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:34 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 05:34:34 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:34 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:34 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:34 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:34 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:34 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:34 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:35 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:35 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:35 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:35 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:35 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:35 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:35 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:35 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:35 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:35 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:35 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:35 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:35 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:35 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:35 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:35 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:35 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:34:36 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 05:34:36 --> Final output sent to browser
DEBUG - 2010-07-05 05:34:36 --> Total execution time: 4.4659
DEBUG - 2010-07-05 05:37:29 --> Config Class Initialized
DEBUG - 2010-07-05 05:37:29 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:37:29 --> URI Class Initialized
DEBUG - 2010-07-05 05:37:29 --> Router Class Initialized
DEBUG - 2010-07-05 05:37:29 --> Output Class Initialized
DEBUG - 2010-07-05 05:37:30 --> Input Class Initialized
DEBUG - 2010-07-05 05:37:30 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:37:30 --> Language Class Initialized
DEBUG - 2010-07-05 05:37:30 --> Loader Class Initialized
DEBUG - 2010-07-05 05:37:30 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:37:30 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:37:30 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:37:30 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:37:30 --> Controller Class Initialized
DEBUG - 2010-07-05 05:37:30 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:37:30 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:37:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:31 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:37:31 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:37:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:31 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:31 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:37:31 --> Session Class Initialized
DEBUG - 2010-07-05 05:37:31 --> Helper loaded: string_helper
DEBUG - 2010-07-05 05:37:31 --> Session routines successfully run
DEBUG - 2010-07-05 05:37:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:31 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:32 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:32 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:32 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:32 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:32 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:32 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:32 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 05:37:32 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:32 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:33 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:33 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:33 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:33 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:33 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:33 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:33 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:33 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:33 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:33 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:33 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:33 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:33 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:33 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:33 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:33 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:33 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:34 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:34 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:34 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:34 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:34 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:37:34 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 05:37:34 --> Final output sent to browser
DEBUG - 2010-07-05 05:37:34 --> Total execution time: 4.7181
DEBUG - 2010-07-05 05:38:35 --> Config Class Initialized
DEBUG - 2010-07-05 05:38:35 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:38:35 --> URI Class Initialized
DEBUG - 2010-07-05 05:38:35 --> Router Class Initialized
DEBUG - 2010-07-05 05:38:35 --> Output Class Initialized
DEBUG - 2010-07-05 05:38:35 --> Input Class Initialized
DEBUG - 2010-07-05 05:38:35 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:38:35 --> Language Class Initialized
DEBUG - 2010-07-05 05:38:35 --> Loader Class Initialized
DEBUG - 2010-07-05 05:38:35 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:38:35 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:38:35 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:38:35 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:38:35 --> Controller Class Initialized
DEBUG - 2010-07-05 05:38:36 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:38:36 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:38:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:36 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:36 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:36 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:36 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:38:36 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:38:36 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:36 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:36 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:38:36 --> Session Class Initialized
DEBUG - 2010-07-05 05:38:37 --> Helper loaded: string_helper
DEBUG - 2010-07-05 05:38:37 --> Session routines successfully run
DEBUG - 2010-07-05 05:38:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:37 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:37 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:37 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:37 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:38 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:38 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:38 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:38 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 05:38:38 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:38 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:38 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:38 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:38 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:38 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:38 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:38 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:38 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:38 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:38 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:38 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:39 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:39 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:39 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:39 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:39 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:39 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:39 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:39 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:39 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:39 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:39 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:39 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:38:39 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 05:38:39 --> Final output sent to browser
DEBUG - 2010-07-05 05:38:39 --> Total execution time: 4.6800
DEBUG - 2010-07-05 05:39:39 --> Config Class Initialized
DEBUG - 2010-07-05 05:39:39 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:39:39 --> URI Class Initialized
DEBUG - 2010-07-05 05:39:39 --> Router Class Initialized
DEBUG - 2010-07-05 05:39:40 --> Output Class Initialized
DEBUG - 2010-07-05 05:39:40 --> Input Class Initialized
DEBUG - 2010-07-05 05:39:40 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:39:40 --> Language Class Initialized
DEBUG - 2010-07-05 05:39:40 --> Loader Class Initialized
DEBUG - 2010-07-05 05:39:40 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:39:40 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:39:40 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:39:40 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:39:40 --> Controller Class Initialized
DEBUG - 2010-07-05 05:39:40 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:39:40 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:39:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:40 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:41 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:41 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:41 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:39:41 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:39:41 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:41 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:41 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:39:41 --> Session Class Initialized
DEBUG - 2010-07-05 05:39:41 --> Helper loaded: string_helper
DEBUG - 2010-07-05 05:39:41 --> Session routines successfully run
DEBUG - 2010-07-05 05:39:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:41 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:42 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:42 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:42 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:42 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:42 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:42 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:42 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 05:39:42 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:43 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:43 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:43 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:43 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:43 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:43 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:43 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:43 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:43 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:43 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:43 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:43 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:43 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:43 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:43 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:44 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:44 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:44 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:44 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:44 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:44 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:44 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:44 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:39:44 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 05:39:44 --> Final output sent to browser
DEBUG - 2010-07-05 05:39:44 --> Total execution time: 4.8714
DEBUG - 2010-07-05 05:41:32 --> Config Class Initialized
DEBUG - 2010-07-05 05:41:32 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:41:32 --> URI Class Initialized
DEBUG - 2010-07-05 05:41:32 --> Router Class Initialized
DEBUG - 2010-07-05 05:41:32 --> Output Class Initialized
DEBUG - 2010-07-05 05:41:32 --> Input Class Initialized
DEBUG - 2010-07-05 05:41:33 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:41:33 --> Language Class Initialized
DEBUG - 2010-07-05 05:41:33 --> Loader Class Initialized
DEBUG - 2010-07-05 05:41:33 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:41:33 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:41:33 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:41:33 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:41:33 --> Controller Class Initialized
DEBUG - 2010-07-05 05:41:33 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:41:33 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:41:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:33 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:33 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:34 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:41:34 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:41:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:34 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:34 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:41:34 --> Session Class Initialized
DEBUG - 2010-07-05 05:41:34 --> Helper loaded: string_helper
DEBUG - 2010-07-05 05:41:34 --> Session routines successfully run
DEBUG - 2010-07-05 05:41:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:34 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:35 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:35 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:35 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:35 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:35 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:35 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:35 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 05:41:35 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:36 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:36 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:36 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:36 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:36 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:36 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:37 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:37 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:37 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:37 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:37 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:37 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:37 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:37 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:37 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:41:37 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 05:41:37 --> Final output sent to browser
DEBUG - 2010-07-05 05:41:37 --> Total execution time: 5.0783
DEBUG - 2010-07-05 05:43:45 --> Config Class Initialized
DEBUG - 2010-07-05 05:43:45 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:43:45 --> URI Class Initialized
DEBUG - 2010-07-05 05:43:45 --> Router Class Initialized
DEBUG - 2010-07-05 05:43:45 --> Output Class Initialized
DEBUG - 2010-07-05 05:43:45 --> Input Class Initialized
DEBUG - 2010-07-05 05:43:45 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:43:45 --> Language Class Initialized
DEBUG - 2010-07-05 05:43:45 --> Loader Class Initialized
DEBUG - 2010-07-05 05:43:45 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:43:45 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:43:45 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:43:45 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:43:46 --> Controller Class Initialized
DEBUG - 2010-07-05 05:43:46 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:43:46 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:43:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:46 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:46 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:46 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:46 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:43:46 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:43:46 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:46 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:46 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:46 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:43:47 --> Session Class Initialized
DEBUG - 2010-07-05 05:43:47 --> Helper loaded: string_helper
DEBUG - 2010-07-05 05:43:47 --> Session routines successfully run
DEBUG - 2010-07-05 05:43:47 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:47 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:47 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:47 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:48 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:48 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:48 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:48 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:48 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:48 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:48 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 05:43:48 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:48 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:48 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:48 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:48 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:48 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:48 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:48 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:49 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:49 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:49 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:49 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:49 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:49 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:49 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:49 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:49 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:49 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:49 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:49 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:49 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:50 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:50 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:50 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:43:50 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 05:43:50 --> Final output sent to browser
DEBUG - 2010-07-05 05:43:50 --> Total execution time: 5.1571
DEBUG - 2010-07-05 05:46:48 --> Config Class Initialized
DEBUG - 2010-07-05 05:46:48 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:46:48 --> URI Class Initialized
DEBUG - 2010-07-05 05:46:48 --> Router Class Initialized
DEBUG - 2010-07-05 05:46:48 --> Output Class Initialized
DEBUG - 2010-07-05 05:46:48 --> Input Class Initialized
DEBUG - 2010-07-05 05:46:48 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:46:48 --> Language Class Initialized
DEBUG - 2010-07-05 05:46:48 --> Loader Class Initialized
DEBUG - 2010-07-05 05:46:48 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:46:49 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:46:49 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:46:49 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:46:49 --> Controller Class Initialized
DEBUG - 2010-07-05 05:46:49 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:46:49 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:46:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:49 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:49 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:49 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:49 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:46:50 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:46:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:50 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:50 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:50 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:46:50 --> Session Class Initialized
DEBUG - 2010-07-05 05:46:50 --> Helper loaded: string_helper
DEBUG - 2010-07-05 05:46:50 --> Session routines successfully run
DEBUG - 2010-07-05 05:46:50 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:50 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:51 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:51 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:51 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:51 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:51 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:51 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 05:46:52 --> Severity: Notice  --> Undefined index:  to_index D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Annotation_scope.php 166
ERROR - 2010-07-05 05:46:52 --> Severity: Notice  --> Undefined index:  to_index D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Annotation_scope.php 169
DEBUG - 2010-07-05 05:46:52 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 05:46:52 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:52 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:52 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:52 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:52 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:52 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:52 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:52 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:52 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:52 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 05:46:52 --> Severity: Notice  --> Undefined index:  to_index D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Annotation_scope.php 166
ERROR - 2010-07-05 05:46:52 --> Severity: Notice  --> Undefined index:  to_index D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Annotation_scope.php 169
DEBUG - 2010-07-05 05:46:53 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:53 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:53 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:53 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:53 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:53 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:53 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 05:46:53 --> Severity: Notice  --> Undefined index:  to_index D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Annotation_scope.php 166
ERROR - 2010-07-05 05:46:53 --> Severity: Notice  --> Undefined index:  to_index D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Annotation_scope.php 169
DEBUG - 2010-07-05 05:46:53 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:53 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:53 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:53 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:53 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:54 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:46:54 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 05:46:54 --> Severity: Notice  --> Undefined index:  to_index D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Annotation_scope.php 166
ERROR - 2010-07-05 05:46:54 --> Severity: Notice  --> Undefined index:  to_index D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\annotation\Annotation_scope.php 169
DEBUG - 2010-07-05 05:46:54 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 05:46:54 --> Final output sent to browser
DEBUG - 2010-07-05 05:46:54 --> Total execution time: 6.0656
DEBUG - 2010-07-05 05:47:13 --> Config Class Initialized
DEBUG - 2010-07-05 05:47:13 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:47:13 --> URI Class Initialized
DEBUG - 2010-07-05 05:47:13 --> Router Class Initialized
DEBUG - 2010-07-05 05:47:13 --> Output Class Initialized
DEBUG - 2010-07-05 05:47:13 --> Input Class Initialized
DEBUG - 2010-07-05 05:47:13 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:47:13 --> Language Class Initialized
DEBUG - 2010-07-05 05:47:14 --> Loader Class Initialized
DEBUG - 2010-07-05 05:47:14 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:47:14 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:47:14 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:47:14 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:47:14 --> Controller Class Initialized
DEBUG - 2010-07-05 05:47:14 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:47:14 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:47:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:14 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:14 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:15 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:47:15 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:47:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:15 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:15 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:47:15 --> Session Class Initialized
DEBUG - 2010-07-05 05:47:15 --> Helper loaded: string_helper
DEBUG - 2010-07-05 05:47:15 --> Session routines successfully run
DEBUG - 2010-07-05 05:47:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:15 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:16 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:16 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:16 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:17 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:17 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:17 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:17 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 05:47:17 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:17 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:17 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:17 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:17 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:17 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:17 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:17 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:17 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:17 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:18 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:18 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:18 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:18 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:18 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:18 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:18 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:18 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:18 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:18 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:18 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:18 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:18 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:18 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:47:19 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 05:47:19 --> Final output sent to browser
DEBUG - 2010-07-05 05:47:19 --> Total execution time: 5.6111
DEBUG - 2010-07-05 05:48:51 --> Config Class Initialized
DEBUG - 2010-07-05 05:48:51 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:48:51 --> URI Class Initialized
DEBUG - 2010-07-05 05:48:51 --> Router Class Initialized
DEBUG - 2010-07-05 05:48:51 --> Output Class Initialized
DEBUG - 2010-07-05 05:48:51 --> Input Class Initialized
DEBUG - 2010-07-05 05:48:51 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:48:51 --> Language Class Initialized
DEBUG - 2010-07-05 05:48:51 --> Loader Class Initialized
DEBUG - 2010-07-05 05:48:51 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:48:51 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:48:51 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:48:51 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:48:52 --> Controller Class Initialized
DEBUG - 2010-07-05 05:48:52 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:48:52 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:48:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:52 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:52 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:52 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:52 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:48:52 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:48:52 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:53 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:53 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:48:53 --> Session Class Initialized
DEBUG - 2010-07-05 05:48:53 --> Helper loaded: string_helper
DEBUG - 2010-07-05 05:48:53 --> Session routines successfully run
DEBUG - 2010-07-05 05:48:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:53 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:54 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:54 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:54 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:54 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:54 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:54 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:54 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 05:48:54 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:54 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:54 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:55 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:55 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:55 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:55 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:55 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:55 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:55 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:55 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:55 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:55 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:55 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:55 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:55 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:56 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:56 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:56 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:56 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:56 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:56 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:56 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:56 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:48:56 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 05:48:56 --> Final output sent to browser
DEBUG - 2010-07-05 05:48:56 --> Total execution time: 5.7163
DEBUG - 2010-07-05 05:49:20 --> Config Class Initialized
DEBUG - 2010-07-05 05:49:20 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:49:20 --> URI Class Initialized
DEBUG - 2010-07-05 05:49:20 --> Router Class Initialized
DEBUG - 2010-07-05 05:49:20 --> Output Class Initialized
DEBUG - 2010-07-05 05:49:20 --> Input Class Initialized
DEBUG - 2010-07-05 05:49:20 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:49:20 --> Language Class Initialized
DEBUG - 2010-07-05 05:49:20 --> Loader Class Initialized
DEBUG - 2010-07-05 05:49:20 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:49:21 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:49:21 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:49:21 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:49:21 --> Controller Class Initialized
DEBUG - 2010-07-05 05:49:21 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:49:21 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:49:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:49:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:49:21 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:49:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:49:21 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:49:21 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:49:22 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:49:22 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:49:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:49:22 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:49:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:49:22 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:50:29 --> Config Class Initialized
DEBUG - 2010-07-05 05:50:29 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:50:29 --> URI Class Initialized
DEBUG - 2010-07-05 05:50:29 --> Router Class Initialized
DEBUG - 2010-07-05 05:50:29 --> Output Class Initialized
DEBUG - 2010-07-05 05:50:29 --> Input Class Initialized
DEBUG - 2010-07-05 05:50:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:50:29 --> Language Class Initialized
DEBUG - 2010-07-05 05:50:29 --> Loader Class Initialized
DEBUG - 2010-07-05 05:50:29 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:50:29 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:50:29 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:50:29 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:50:30 --> Controller Class Initialized
DEBUG - 2010-07-05 05:50:30 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:50:30 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:50:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:50:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:50:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:50:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:50:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:50:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:50:30 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:50:30 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:50:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:50:30 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:50:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:50:31 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:50:41 --> Config Class Initialized
DEBUG - 2010-07-05 05:50:41 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:50:41 --> URI Class Initialized
DEBUG - 2010-07-05 05:50:41 --> Router Class Initialized
DEBUG - 2010-07-05 05:50:41 --> Output Class Initialized
DEBUG - 2010-07-05 05:50:41 --> Input Class Initialized
DEBUG - 2010-07-05 05:50:41 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:50:42 --> Language Class Initialized
DEBUG - 2010-07-05 05:50:42 --> Loader Class Initialized
DEBUG - 2010-07-05 05:50:42 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:50:42 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:50:42 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:50:42 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:50:42 --> Controller Class Initialized
DEBUG - 2010-07-05 05:50:42 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:50:42 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:50:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:50:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:50:42 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:50:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:50:43 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:50:43 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:50:43 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:50:43 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:50:43 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:50:43 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:50:43 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:50:43 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:50:43 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:50:43 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:50:59 --> Config Class Initialized
DEBUG - 2010-07-05 05:50:59 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:50:59 --> URI Class Initialized
DEBUG - 2010-07-05 05:50:59 --> Router Class Initialized
DEBUG - 2010-07-05 05:50:59 --> Output Class Initialized
DEBUG - 2010-07-05 05:50:59 --> Input Class Initialized
DEBUG - 2010-07-05 05:50:59 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:51:00 --> Language Class Initialized
DEBUG - 2010-07-05 05:51:00 --> Loader Class Initialized
DEBUG - 2010-07-05 05:51:00 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:51:00 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:51:00 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:51:00 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:51:00 --> Controller Class Initialized
DEBUG - 2010-07-05 05:51:00 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:51:00 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:51:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:51:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:51:00 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:51:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:51:01 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:51:01 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:51:01 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:51:01 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:51:01 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:51:01 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:51:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:51:01 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:51:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:51:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:51:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:51:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:51:02 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:51:02 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:51:02 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:51:02 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:51:02 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:51:02 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 05:51:02 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:51:03 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:51:03 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:51:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:51:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:51:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:51:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:51:03 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:51:03 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:51:04 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:51:04 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:51:04 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 05:51:04 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  insert or update on table &quot;scope&quot; violates foreign key constraint &quot;scope_webpage_id_fkey&quot;
DETAIL:  Key (webpage_id)=(26) is not present in table &quot;webpage&quot;. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-05 05:51:04 --> DB Transaction Failure
ERROR - 2010-07-05 05:51:04 --> Query error: ERROR:  insert or update on table "scope" violates foreign key constraint "scope_webpage_id_fkey"
DETAIL:  Key (webpage_id)=(26) is not present in table "webpage".
DEBUG - 2010-07-05 05:51:04 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-05 05:51:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:377) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-05 05:54:35 --> Config Class Initialized
DEBUG - 2010-07-05 05:54:35 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:54:35 --> URI Class Initialized
DEBUG - 2010-07-05 05:54:35 --> Router Class Initialized
DEBUG - 2010-07-05 05:54:35 --> Output Class Initialized
DEBUG - 2010-07-05 05:54:35 --> Input Class Initialized
DEBUG - 2010-07-05 05:54:35 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:54:36 --> Language Class Initialized
DEBUG - 2010-07-05 05:54:36 --> Loader Class Initialized
DEBUG - 2010-07-05 05:54:36 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:54:36 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:54:36 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:54:36 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:54:36 --> Controller Class Initialized
DEBUG - 2010-07-05 05:54:36 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:54:36 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:54:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:54:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:54:36 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:54:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:54:37 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:54:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:54:37 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:54:37 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:54:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:54:37 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:54:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:54:37 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:54:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:54:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:54:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:54:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:54:38 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:54:38 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:54:38 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:54:38 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:54:38 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 05:54:38 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  insert or update on table &quot;scope&quot; violates foreign key constraint &quot;scope_webpage_id_fkey&quot;
DETAIL:  Key (webpage_id)=(27) is not present in table &quot;webpage&quot;. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-05 05:54:38 --> DB Transaction Failure
ERROR - 2010-07-05 05:54:39 --> Query error: ERROR:  insert or update on table "scope" violates foreign key constraint "scope_webpage_id_fkey"
DETAIL:  Key (webpage_id)=(27) is not present in table "webpage".
DEBUG - 2010-07-05 05:54:39 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-05 05:54:39 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:377) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-05 05:55:45 --> Config Class Initialized
DEBUG - 2010-07-05 05:55:45 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:55:45 --> URI Class Initialized
DEBUG - 2010-07-05 05:55:45 --> Router Class Initialized
DEBUG - 2010-07-05 05:55:45 --> Output Class Initialized
DEBUG - 2010-07-05 05:55:45 --> Input Class Initialized
DEBUG - 2010-07-05 05:55:45 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:55:45 --> Language Class Initialized
DEBUG - 2010-07-05 05:55:45 --> Loader Class Initialized
DEBUG - 2010-07-05 05:55:45 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:55:45 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:55:46 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:55:46 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:55:46 --> Controller Class Initialized
DEBUG - 2010-07-05 05:55:46 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:55:46 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:55:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:55:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:55:46 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:55:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:55:46 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:55:46 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:55:46 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:55:47 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:55:47 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:55:47 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:55:47 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:55:47 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:55:47 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:55:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:55:48 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:55:48 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:55:48 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:55:48 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:55:48 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:55:48 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:55:48 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 05:55:48 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  insert or update on table &quot;scope&quot; violates foreign key constraint &quot;scope_webpage_id_fkey&quot;
DETAIL:  Key (webpage_id)=(25) is not present in table &quot;webpage&quot;. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-05 05:55:48 --> DB Transaction Failure
ERROR - 2010-07-05 05:55:48 --> Query error: ERROR:  insert or update on table "scope" violates foreign key constraint "scope_webpage_id_fkey"
DETAIL:  Key (webpage_id)=(25) is not present in table "webpage".
DEBUG - 2010-07-05 05:55:48 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-05 05:55:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:377) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-05 05:55:57 --> Config Class Initialized
DEBUG - 2010-07-05 05:55:57 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:55:58 --> URI Class Initialized
DEBUG - 2010-07-05 05:55:58 --> Router Class Initialized
DEBUG - 2010-07-05 05:55:58 --> Output Class Initialized
DEBUG - 2010-07-05 05:55:58 --> Input Class Initialized
DEBUG - 2010-07-05 05:55:58 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:55:58 --> Language Class Initialized
DEBUG - 2010-07-05 05:55:58 --> Loader Class Initialized
DEBUG - 2010-07-05 05:55:58 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:55:58 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:55:58 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:55:58 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:55:58 --> Controller Class Initialized
DEBUG - 2010-07-05 05:55:59 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:55:59 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:55:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:55:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:55:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:55:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:55:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:55:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:55:59 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:55:59 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:55:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:55:59 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:00 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:56:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:00 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:00 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:01 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:01 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:01 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 05:56:01 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  insert or update on table &quot;scope&quot; violates foreign key constraint &quot;scope_webpage_id_fkey&quot;
DETAIL:  Key (webpage_id)=(28) is not present in table &quot;webpage&quot;. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-05 05:56:01 --> DB Transaction Failure
ERROR - 2010-07-05 05:56:01 --> Query error: ERROR:  insert or update on table "scope" violates foreign key constraint "scope_webpage_id_fkey"
DETAIL:  Key (webpage_id)=(28) is not present in table "webpage".
DEBUG - 2010-07-05 05:56:01 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-05 05:56:01 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:377) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-05 05:56:20 --> Config Class Initialized
DEBUG - 2010-07-05 05:56:20 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:56:20 --> URI Class Initialized
DEBUG - 2010-07-05 05:56:20 --> Router Class Initialized
DEBUG - 2010-07-05 05:56:21 --> Output Class Initialized
DEBUG - 2010-07-05 05:56:21 --> Input Class Initialized
DEBUG - 2010-07-05 05:56:21 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:56:21 --> Language Class Initialized
DEBUG - 2010-07-05 05:56:21 --> Loader Class Initialized
DEBUG - 2010-07-05 05:56:21 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:56:21 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:56:21 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:56:21 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:56:21 --> Controller Class Initialized
DEBUG - 2010-07-05 05:56:21 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:56:21 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:56:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:22 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:22 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:22 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:56:22 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:56:22 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:22 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:22 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:56:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:23 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:24 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:24 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 05:56:24 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  insert or update on table &quot;scope&quot; violates foreign key constraint &quot;scope_webpage_id_fkey&quot;
DETAIL:  Key (webpage_id)=(29) is not present in table &quot;webpage&quot;. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-05 05:56:24 --> DB Transaction Failure
ERROR - 2010-07-05 05:56:24 --> Query error: ERROR:  insert or update on table "scope" violates foreign key constraint "scope_webpage_id_fkey"
DETAIL:  Key (webpage_id)=(29) is not present in table "webpage".
DEBUG - 2010-07-05 05:56:24 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-05 05:56:24 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:377) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-05 05:56:39 --> Config Class Initialized
DEBUG - 2010-07-05 05:56:39 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:56:39 --> URI Class Initialized
DEBUG - 2010-07-05 05:56:39 --> Router Class Initialized
DEBUG - 2010-07-05 05:56:39 --> Output Class Initialized
DEBUG - 2010-07-05 05:56:39 --> Input Class Initialized
DEBUG - 2010-07-05 05:56:40 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:56:40 --> Language Class Initialized
DEBUG - 2010-07-05 05:56:40 --> Loader Class Initialized
DEBUG - 2010-07-05 05:56:40 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:56:40 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:56:40 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:56:40 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:56:40 --> Controller Class Initialized
DEBUG - 2010-07-05 05:56:40 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:56:40 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:56:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:41 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:41 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:41 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:41 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:56:41 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:56:41 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:41 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:41 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:56:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:42 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:42 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:42 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:42 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:56:42 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 05:56:43 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  insert or update on table &quot;scope&quot; violates foreign key constraint &quot;scope_webpage_id_fkey&quot;
DETAIL:  Key (webpage_id)=(30) is not present in table &quot;webpage&quot;. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-05 05:56:43 --> DB Transaction Failure
ERROR - 2010-07-05 05:56:43 --> Query error: ERROR:  insert or update on table "scope" violates foreign key constraint "scope_webpage_id_fkey"
DETAIL:  Key (webpage_id)=(30) is not present in table "webpage".
DEBUG - 2010-07-05 05:56:43 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-05 05:56:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:377) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-05 05:57:06 --> Config Class Initialized
DEBUG - 2010-07-05 05:57:06 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:57:06 --> URI Class Initialized
DEBUG - 2010-07-05 05:57:06 --> Router Class Initialized
DEBUG - 2010-07-05 05:57:06 --> Output Class Initialized
DEBUG - 2010-07-05 05:57:06 --> Input Class Initialized
DEBUG - 2010-07-05 05:57:06 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:57:06 --> Language Class Initialized
DEBUG - 2010-07-05 05:57:07 --> Loader Class Initialized
DEBUG - 2010-07-05 05:57:07 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:57:07 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:57:07 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:57:07 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:57:07 --> Controller Class Initialized
DEBUG - 2010-07-05 05:57:07 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:57:07 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:57:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:57:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:57:07 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:57:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:57:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:57:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:57:08 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:57:08 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:57:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:57:08 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:57:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:57:08 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:57:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:57:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:57:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:57:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:57:33 --> Config Class Initialized
DEBUG - 2010-07-05 05:57:33 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:57:33 --> URI Class Initialized
DEBUG - 2010-07-05 05:57:33 --> Router Class Initialized
DEBUG - 2010-07-05 05:57:33 --> Output Class Initialized
DEBUG - 2010-07-05 05:57:33 --> Input Class Initialized
DEBUG - 2010-07-05 05:57:33 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:57:33 --> Language Class Initialized
DEBUG - 2010-07-05 05:57:33 --> Loader Class Initialized
DEBUG - 2010-07-05 05:57:33 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:57:33 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:57:34 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:57:34 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:57:34 --> Controller Class Initialized
DEBUG - 2010-07-05 05:57:34 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:57:34 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:57:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:57:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:57:34 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:57:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:57:34 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:57:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:57:34 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:57:35 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:57:35 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:57:35 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:57:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:57:35 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:57:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:57:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:57:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:57:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:57:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:57:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:57:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:57:36 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:57:36 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 05:57:36 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  insert or update on table &quot;scope&quot; violates foreign key constraint &quot;scope_webpage_id_fkey&quot;
DETAIL:  Key (webpage_id)=(32) is not present in table &quot;webpage&quot;. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-05 05:57:36 --> DB Transaction Failure
ERROR - 2010-07-05 05:57:36 --> Query error: ERROR:  insert or update on table "scope" violates foreign key constraint "scope_webpage_id_fkey"
DETAIL:  Key (webpage_id)=(32) is not present in table "webpage".
DEBUG - 2010-07-05 05:57:36 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-05 05:57:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:377) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-05 05:58:29 --> Config Class Initialized
DEBUG - 2010-07-05 05:58:29 --> Hooks Class Initialized
DEBUG - 2010-07-05 05:58:29 --> URI Class Initialized
DEBUG - 2010-07-05 05:58:30 --> Router Class Initialized
DEBUG - 2010-07-05 05:58:30 --> Output Class Initialized
DEBUG - 2010-07-05 05:58:30 --> Input Class Initialized
DEBUG - 2010-07-05 05:58:30 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 05:58:30 --> Language Class Initialized
DEBUG - 2010-07-05 05:58:30 --> Loader Class Initialized
DEBUG - 2010-07-05 05:58:30 --> Helper loaded: context_helper
DEBUG - 2010-07-05 05:58:30 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 05:58:30 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 05:58:30 --> Database Driver Class Initialized
DEBUG - 2010-07-05 05:58:30 --> Controller Class Initialized
DEBUG - 2010-07-05 05:58:31 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 05:58:31 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 05:58:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:58:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:58:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:58:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:58:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:58:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:58:31 --> Helper loaded: email_helper
DEBUG - 2010-07-05 05:58:31 --> User Agent Class Initialized
DEBUG - 2010-07-05 05:58:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:58:31 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:58:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:58:32 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 05:58:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:58:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:58:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:58:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:58:32 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:58:33 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:58:33 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:58:33 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 05:58:33 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 05:58:33 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  insert or update on table &quot;scope&quot; violates foreign key constraint &quot;scope_webpage_id_fkey&quot;
DETAIL:  Key (webpage_id)=(31) is not present in table &quot;webpage&quot;. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-05 05:58:33 --> DB Transaction Failure
ERROR - 2010-07-05 05:58:33 --> Query error: ERROR:  insert or update on table "scope" violates foreign key constraint "scope_webpage_id_fkey"
DETAIL:  Key (webpage_id)=(31) is not present in table "webpage".
DEBUG - 2010-07-05 05:58:33 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-05 05:58:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:377) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-05 06:00:19 --> Config Class Initialized
DEBUG - 2010-07-05 06:00:19 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:00:19 --> URI Class Initialized
DEBUG - 2010-07-05 06:00:19 --> Router Class Initialized
DEBUG - 2010-07-05 06:00:19 --> Output Class Initialized
DEBUG - 2010-07-05 06:00:19 --> Input Class Initialized
DEBUG - 2010-07-05 06:00:20 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:00:20 --> Language Class Initialized
DEBUG - 2010-07-05 06:00:20 --> Loader Class Initialized
DEBUG - 2010-07-05 06:00:20 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:00:20 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:00:20 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:00:20 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:00:20 --> Controller Class Initialized
DEBUG - 2010-07-05 06:00:20 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:00:20 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:00:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:00:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:00:21 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:00:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:00:21 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:00:21 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:00:21 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:00:21 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:00:21 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:00:21 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:00:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:00:22 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:00:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:00:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:00:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:00:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:00:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:00:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:00:23 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:00:23 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:00:23 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 06:00:23 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  insert or update on table &quot;scope&quot; violates foreign key constraint &quot;scope_webpage_id_fkey&quot;
DETAIL:  Key (webpage_id)=(33) is not present in table &quot;webpage&quot;. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-05 06:00:23 --> DB Transaction Failure
ERROR - 2010-07-05 06:00:23 --> Query error: ERROR:  insert or update on table "scope" violates foreign key constraint "scope_webpage_id_fkey"
DETAIL:  Key (webpage_id)=(33) is not present in table "webpage".
DEBUG - 2010-07-05 06:00:23 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-05 06:00:23 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:377) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-05 06:02:12 --> Config Class Initialized
DEBUG - 2010-07-05 06:02:12 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:02:13 --> URI Class Initialized
DEBUG - 2010-07-05 06:02:13 --> Router Class Initialized
DEBUG - 2010-07-05 06:02:13 --> Output Class Initialized
DEBUG - 2010-07-05 06:02:13 --> Input Class Initialized
DEBUG - 2010-07-05 06:02:13 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:02:13 --> Language Class Initialized
DEBUG - 2010-07-05 06:02:13 --> Loader Class Initialized
DEBUG - 2010-07-05 06:02:13 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:02:13 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:02:13 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:02:14 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:02:14 --> Controller Class Initialized
DEBUG - 2010-07-05 06:02:14 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:02:14 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:02:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:02:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:02:14 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:02:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:02:14 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:02:14 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:02:15 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:02:15 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:02:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:02:15 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:02:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:02:15 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:02:15 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-05 06:02:15 --> Severity: Notice  --> Undefined variable: Domain::$id= D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:02:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:02:15 --> Severity: Notice  --> Undefined variable: Domain::$id= D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:02:15 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
DEBUG - 2010-07-05 06:02:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:02:16 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-05 06:02:16 --> Severity: Notice  --> Undefined variable: Webpage::$id= D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:02:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:02:16 --> Severity: Notice  --> Undefined variable: Webpage::$id= D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:02:16 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:02:16 --> Severity: Notice  --> Undefined variable: Webpage::$id= D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:02:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
DEBUG - 2010-07-05 06:02:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:02:17 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:02:17 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:02:17 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:02:17 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:02:17 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 06:02:17 --> Severity: Notice  --> Undefined variable: Annotation_scope::$id= D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:02:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:02:17 --> Severity: Notice  --> Undefined variable: Annotation_scope::$id= D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:02:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:02:18 --> Severity: Notice  --> Undefined variable: Annotation_scope::$id= D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:02:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:02:18 --> Severity: Notice  --> Undefined variable: Annotation_scope::$id= D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:02:18 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:02:18 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  insert or update on table &quot;scope&quot; violates foreign key constraint &quot;scope_webpage_id_fkey&quot;
DETAIL:  Key (webpage_id)=(34) is not present in table &quot;webpage&quot;. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-05 06:02:18 --> DB Transaction Failure
ERROR - 2010-07-05 06:02:18 --> Query error: ERROR:  insert or update on table "scope" violates foreign key constraint "scope_webpage_id_fkey"
DETAIL:  Key (webpage_id)=(34) is not present in table "webpage".
DEBUG - 2010-07-05 06:02:18 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-05 06:02:18 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-05 06:03:02 --> Config Class Initialized
DEBUG - 2010-07-05 06:03:02 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:03:02 --> URI Class Initialized
DEBUG - 2010-07-05 06:03:02 --> Router Class Initialized
DEBUG - 2010-07-05 06:03:02 --> Output Class Initialized
DEBUG - 2010-07-05 06:03:02 --> Input Class Initialized
DEBUG - 2010-07-05 06:03:02 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:03:02 --> Language Class Initialized
DEBUG - 2010-07-05 06:03:03 --> Loader Class Initialized
DEBUG - 2010-07-05 06:03:03 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:03:03 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:03:03 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:03:03 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:03:03 --> Controller Class Initialized
DEBUG - 2010-07-05 06:03:03 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:03:03 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:03:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:04 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:04 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:04 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:03:04 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:03:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:04 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:04 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:03:04 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-05 06:03:05 --> Severity: Notice  --> Undefined variable: Domain::$id= D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:03:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:03:05 --> Severity: Notice  --> Undefined variable: Domain::$id= D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:03:05 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
DEBUG - 2010-07-05 06:03:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:05 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-05 06:03:05 --> Severity: Notice  --> Undefined variable: Webpage::$id= D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:03:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:03:06 --> Severity: Notice  --> Undefined variable: Webpage::$id= D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:03:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:03:06 --> Severity: Notice  --> Undefined variable: Webpage::$id= D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:03:06 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
DEBUG - 2010-07-05 06:03:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:06 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:06 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:06 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:06 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:07 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 06:03:07 --> Severity: Notice  --> Undefined variable: Annotation_scope::$id= D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:03:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:03:07 --> Severity: Notice  --> Undefined variable: Annotation_scope::$id= D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:03:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:03:07 --> Severity: Notice  --> Undefined variable: Annotation_scope::$id= D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:03:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:03:07 --> Severity: Notice  --> Undefined variable: Annotation_scope::$id= D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:03:07 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:03:07 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  insert or update on table &quot;scope&quot; violates foreign key constraint &quot;scope_webpage_id_fkey&quot;
DETAIL:  Key (webpage_id)=(35) is not present in table &quot;webpage&quot;. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-05 06:03:07 --> DB Transaction Failure
ERROR - 2010-07-05 06:03:08 --> Query error: ERROR:  insert or update on table "scope" violates foreign key constraint "scope_webpage_id_fkey"
DETAIL:  Key (webpage_id)=(35) is not present in table "webpage".
DEBUG - 2010-07-05 06:03:08 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-05 06:03:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-05 06:03:17 --> Config Class Initialized
DEBUG - 2010-07-05 06:03:17 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:03:17 --> URI Class Initialized
DEBUG - 2010-07-05 06:03:17 --> Router Class Initialized
DEBUG - 2010-07-05 06:03:17 --> Output Class Initialized
DEBUG - 2010-07-05 06:03:17 --> Input Class Initialized
DEBUG - 2010-07-05 06:03:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:03:17 --> Language Class Initialized
DEBUG - 2010-07-05 06:03:17 --> Loader Class Initialized
DEBUG - 2010-07-05 06:03:17 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:03:17 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:03:18 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:03:18 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:03:18 --> Controller Class Initialized
DEBUG - 2010-07-05 06:03:18 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:03:18 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:03:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:18 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:18 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:19 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:19 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:03:19 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:03:19 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:19 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:19 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:03:19 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-05 06:03:19 --> Severity: Notice  --> Undefined variable: Domain::$id= D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:03:19 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:03:20 --> Severity: Notice  --> Undefined variable: Domain::$id= D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:03:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
DEBUG - 2010-07-05 06:03:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:20 --> Authorize_manager class already loaded. Second attempt ignored.
ERROR - 2010-07-05 06:03:20 --> Severity: Notice  --> Undefined variable: Webpage::$id= D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:03:20 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:03:20 --> Severity: Notice  --> Undefined variable: Webpage::$id= D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:03:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:03:21 --> Severity: Notice  --> Undefined variable: Webpage::$id= D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:03:21 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
DEBUG - 2010-07-05 06:03:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:21 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:21 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:21 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:21 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:21 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 06:03:21 --> Severity: Notice  --> Undefined variable: Annotation_scope::$id= D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:03:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:03:22 --> Severity: Notice  --> Undefined variable: Annotation_scope::$id= D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:03:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:03:22 --> Severity: Notice  --> Undefined variable: Annotation_scope::$id= D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:03:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:03:22 --> Severity: Notice  --> Undefined variable: Annotation_scope::$id= D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:03:22 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 330
ERROR - 2010-07-05 06:03:22 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  insert or update on table &quot;scope&quot; violates foreign key constraint &quot;scope_webpage_id_fkey&quot;
DETAIL:  Key (webpage_id)=(36) is not present in table &quot;webpage&quot;. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-05 06:03:22 --> DB Transaction Failure
ERROR - 2010-07-05 06:03:22 --> Query error: ERROR:  insert or update on table "scope" violates foreign key constraint "scope_webpage_id_fkey"
DETAIL:  Key (webpage_id)=(36) is not present in table "webpage".
DEBUG - 2010-07-05 06:03:22 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-05 06:03:23 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-05 06:03:40 --> Config Class Initialized
DEBUG - 2010-07-05 06:03:40 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:03:40 --> URI Class Initialized
DEBUG - 2010-07-05 06:03:40 --> Router Class Initialized
DEBUG - 2010-07-05 06:03:40 --> Output Class Initialized
DEBUG - 2010-07-05 06:03:40 --> Input Class Initialized
DEBUG - 2010-07-05 06:03:40 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:03:40 --> Language Class Initialized
DEBUG - 2010-07-05 06:03:40 --> Loader Class Initialized
DEBUG - 2010-07-05 06:03:40 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:03:40 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:03:41 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:03:41 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:03:41 --> Controller Class Initialized
DEBUG - 2010-07-05 06:03:41 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:03:41 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:03:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:41 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:42 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:42 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:42 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:03:42 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:03:42 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:42 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:42 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:03:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:43 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:43 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:43 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:43 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:43 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:43 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:43 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:03:43 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 06:03:44 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  insert or update on table &quot;scope&quot; violates foreign key constraint &quot;scope_webpage_id_fkey&quot;
DETAIL:  Key (webpage_id)=(38) is not present in table &quot;webpage&quot;. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-05 06:03:44 --> DB Transaction Failure
ERROR - 2010-07-05 06:03:44 --> Query error: ERROR:  insert or update on table "scope" violates foreign key constraint "scope_webpage_id_fkey"
DETAIL:  Key (webpage_id)=(38) is not present in table "webpage".
DEBUG - 2010-07-05 06:03:44 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-05 06:03:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:377) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-05 06:04:55 --> Config Class Initialized
DEBUG - 2010-07-05 06:04:55 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:04:55 --> URI Class Initialized
DEBUG - 2010-07-05 06:04:56 --> Router Class Initialized
DEBUG - 2010-07-05 06:04:56 --> Output Class Initialized
DEBUG - 2010-07-05 06:04:56 --> Input Class Initialized
DEBUG - 2010-07-05 06:04:56 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:04:56 --> Language Class Initialized
DEBUG - 2010-07-05 06:04:56 --> Loader Class Initialized
DEBUG - 2010-07-05 06:04:56 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:04:56 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:04:56 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:04:56 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:04:57 --> Controller Class Initialized
DEBUG - 2010-07-05 06:04:57 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:04:57 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:04:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:04:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:04:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:04:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:04:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:04:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:04:57 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:04:58 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:04:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:04:58 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:04:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:04:58 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:04:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:04:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:04:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:04:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:04:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:04:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:04:59 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:04:59 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:04:59 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:04:59 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:04:59 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 06:04:59 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  insert or update on table &quot;scope&quot; violates foreign key constraint &quot;scope_webpage_id_fkey&quot;
DETAIL:  Key (webpage_id)=(37) is not present in table &quot;webpage&quot;. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-05 06:05:00 --> DB Transaction Failure
ERROR - 2010-07-05 06:05:00 --> Query error: ERROR:  insert or update on table "scope" violates foreign key constraint "scope_webpage_id_fkey"
DETAIL:  Key (webpage_id)=(37) is not present in table "webpage".
DEBUG - 2010-07-05 06:05:00 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-05 06:05:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:377) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-05 06:05:19 --> Config Class Initialized
DEBUG - 2010-07-05 06:05:19 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:05:19 --> URI Class Initialized
DEBUG - 2010-07-05 06:05:19 --> Router Class Initialized
DEBUG - 2010-07-05 06:05:19 --> Output Class Initialized
DEBUG - 2010-07-05 06:05:19 --> Input Class Initialized
DEBUG - 2010-07-05 06:05:19 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:05:19 --> Language Class Initialized
DEBUG - 2010-07-05 06:05:19 --> Loader Class Initialized
DEBUG - 2010-07-05 06:05:20 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:05:20 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:05:20 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:05:20 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:05:20 --> Controller Class Initialized
DEBUG - 2010-07-05 06:05:20 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:05:20 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:05:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:20 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:21 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:21 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:21 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:05:21 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:05:21 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:21 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:21 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:05:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:22 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:23 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:23 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:23 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 06:05:23 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  insert or update on table &quot;scope&quot; violates foreign key constraint &quot;scope_webpage_id_fkey&quot;
DETAIL:  Key (webpage_id)=(39) is not present in table &quot;webpage&quot;. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-05 06:05:23 --> DB Transaction Failure
ERROR - 2010-07-05 06:05:23 --> Query error: ERROR:  insert or update on table "scope" violates foreign key constraint "scope_webpage_id_fkey"
DETAIL:  Key (webpage_id)=(39) is not present in table "webpage".
DEBUG - 2010-07-05 06:05:23 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-05 06:05:23 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:377) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-05 06:05:38 --> Config Class Initialized
DEBUG - 2010-07-05 06:05:38 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:05:38 --> URI Class Initialized
DEBUG - 2010-07-05 06:05:38 --> Router Class Initialized
DEBUG - 2010-07-05 06:05:38 --> Output Class Initialized
DEBUG - 2010-07-05 06:05:39 --> Input Class Initialized
DEBUG - 2010-07-05 06:05:39 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:05:39 --> Language Class Initialized
DEBUG - 2010-07-05 06:05:39 --> Loader Class Initialized
DEBUG - 2010-07-05 06:05:39 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:05:39 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:05:39 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:05:39 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:05:39 --> Controller Class Initialized
DEBUG - 2010-07-05 06:05:39 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:05:40 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:05:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:40 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:40 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:40 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:05:40 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:05:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:41 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:41 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:05:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:42 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:42 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:42 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:42 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:05:42 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 06:05:42 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  insert or update on table &quot;scope&quot; violates foreign key constraint &quot;scope_webpage_id_fkey&quot;
DETAIL:  Key (webpage_id)=(40) is not present in table &quot;webpage&quot;. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-05 06:05:42 --> DB Transaction Failure
ERROR - 2010-07-05 06:05:43 --> Query error: ERROR:  insert or update on table "scope" violates foreign key constraint "scope_webpage_id_fkey"
DETAIL:  Key (webpage_id)=(40) is not present in table "webpage".
DEBUG - 2010-07-05 06:05:43 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-05 06:05:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:377) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-05 06:06:17 --> Config Class Initialized
DEBUG - 2010-07-05 06:06:17 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:06:18 --> URI Class Initialized
DEBUG - 2010-07-05 06:06:18 --> Router Class Initialized
DEBUG - 2010-07-05 06:06:18 --> Output Class Initialized
DEBUG - 2010-07-05 06:06:18 --> Input Class Initialized
DEBUG - 2010-07-05 06:06:18 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:06:18 --> Language Class Initialized
DEBUG - 2010-07-05 06:06:18 --> Loader Class Initialized
DEBUG - 2010-07-05 06:06:18 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:06:18 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:06:18 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:06:19 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:06:19 --> Controller Class Initialized
DEBUG - 2010-07-05 06:06:19 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:06:19 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:06:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:06:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:06:19 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:06:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:06:19 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:06:20 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:06:20 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:06:20 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:06:20 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:06:20 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:06:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:06:20 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:06:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:06:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:06:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:06:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:06:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:06:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:06:21 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:06:21 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:06:21 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:06:22 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:06:22 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 06:06:22 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  insert or update on table &quot;scope&quot; violates foreign key constraint &quot;scope_webpage_id_fkey&quot;
DETAIL:  Key (webpage_id)=(42) is not present in table &quot;webpage&quot;. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-05 06:06:22 --> DB Transaction Failure
ERROR - 2010-07-05 06:06:22 --> Query error: ERROR:  insert or update on table "scope" violates foreign key constraint "scope_webpage_id_fkey"
DETAIL:  Key (webpage_id)=(42) is not present in table "webpage".
DEBUG - 2010-07-05 06:06:22 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-05 06:06:22 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:377) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-05 06:07:15 --> Config Class Initialized
DEBUG - 2010-07-05 06:07:15 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:07:15 --> URI Class Initialized
DEBUG - 2010-07-05 06:07:16 --> Router Class Initialized
DEBUG - 2010-07-05 06:07:16 --> Output Class Initialized
DEBUG - 2010-07-05 06:07:16 --> Input Class Initialized
DEBUG - 2010-07-05 06:07:16 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:07:16 --> Language Class Initialized
DEBUG - 2010-07-05 06:07:16 --> Loader Class Initialized
DEBUG - 2010-07-05 06:07:16 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:07:16 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:07:17 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:07:17 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:07:17 --> Controller Class Initialized
DEBUG - 2010-07-05 06:07:17 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:07:17 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:07:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:07:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:07:17 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:07:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:07:17 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:07:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:07:18 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:07:18 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:07:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:07:18 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:07:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:07:18 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:07:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:07:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:07:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:07:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:07:19 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:07:19 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:07:19 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:07:19 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:07:19 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 06:07:20 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  insert or update on table &quot;scope&quot; violates foreign key constraint &quot;scope_webpage_id_fkey&quot;
DETAIL:  Key (webpage_id)=(41) is not present in table &quot;webpage&quot;. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-05 06:07:20 --> DB Transaction Failure
ERROR - 2010-07-05 06:07:20 --> Query error: ERROR:  insert or update on table "scope" violates foreign key constraint "scope_webpage_id_fkey"
DETAIL:  Key (webpage_id)=(41) is not present in table "webpage".
DEBUG - 2010-07-05 06:07:20 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-05 06:07:20 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:377) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-05 06:07:43 --> Config Class Initialized
DEBUG - 2010-07-05 06:07:43 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:07:43 --> URI Class Initialized
DEBUG - 2010-07-05 06:07:43 --> Router Class Initialized
DEBUG - 2010-07-05 06:07:43 --> Output Class Initialized
DEBUG - 2010-07-05 06:07:43 --> Input Class Initialized
DEBUG - 2010-07-05 06:07:43 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:07:43 --> Language Class Initialized
DEBUG - 2010-07-05 06:07:44 --> Loader Class Initialized
DEBUG - 2010-07-05 06:07:44 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:07:44 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:07:44 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:07:44 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:07:44 --> Controller Class Initialized
DEBUG - 2010-07-05 06:07:44 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:07:44 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:07:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:07:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:07:45 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:07:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:07:45 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:07:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:07:45 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:07:45 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:07:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:07:45 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:07:46 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:07:46 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:07:46 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:07:46 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:07:46 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:07:47 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:07:47 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:07:47 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:07:47 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:07:47 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:07:47 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 06:07:47 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  insert or update on table &quot;scope&quot; violates foreign key constraint &quot;scope_webpage_id_fkey&quot;
DETAIL:  Key (webpage_id)=(44) is not present in table &quot;webpage&quot;. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-05 06:07:47 --> DB Transaction Failure
ERROR - 2010-07-05 06:07:47 --> Query error: ERROR:  insert or update on table "scope" violates foreign key constraint "scope_webpage_id_fkey"
DETAIL:  Key (webpage_id)=(44) is not present in table "webpage".
DEBUG - 2010-07-05 06:07:47 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-05 06:07:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:377) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-05 06:08:03 --> Config Class Initialized
DEBUG - 2010-07-05 06:08:03 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:08:03 --> URI Class Initialized
DEBUG - 2010-07-05 06:08:04 --> Router Class Initialized
DEBUG - 2010-07-05 06:08:04 --> Output Class Initialized
DEBUG - 2010-07-05 06:08:04 --> Input Class Initialized
DEBUG - 2010-07-05 06:08:04 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:08:04 --> Language Class Initialized
DEBUG - 2010-07-05 06:08:04 --> Loader Class Initialized
DEBUG - 2010-07-05 06:08:04 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:08:04 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:08:04 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:08:05 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:08:05 --> Controller Class Initialized
DEBUG - 2010-07-05 06:08:05 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:08:05 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:08:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:08:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:08:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:08:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:08:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:08:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:08:06 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:08:06 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:08:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:08:06 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:08:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:08:06 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:08:06 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:08:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:08:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:08:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:08:07 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:08:07 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:08:07 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:08:07 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:08:07 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 06:08:08 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  insert or update on table &quot;scope&quot; violates foreign key constraint &quot;scope_webpage_id_fkey&quot;
DETAIL:  Key (webpage_id)=(45) is not present in table &quot;webpage&quot;. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-05 06:08:08 --> DB Transaction Failure
ERROR - 2010-07-05 06:08:08 --> Query error: ERROR:  insert or update on table "scope" violates foreign key constraint "scope_webpage_id_fkey"
DETAIL:  Key (webpage_id)=(45) is not present in table "webpage".
DEBUG - 2010-07-05 06:08:08 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-05 06:08:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:377) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-05 06:09:10 --> Config Class Initialized
DEBUG - 2010-07-05 06:09:10 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:09:10 --> URI Class Initialized
DEBUG - 2010-07-05 06:09:10 --> Router Class Initialized
DEBUG - 2010-07-05 06:09:10 --> Output Class Initialized
DEBUG - 2010-07-05 06:09:11 --> Input Class Initialized
DEBUG - 2010-07-05 06:09:11 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:09:11 --> Language Class Initialized
DEBUG - 2010-07-05 06:09:11 --> Loader Class Initialized
DEBUG - 2010-07-05 06:09:11 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:09:11 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:09:11 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:09:11 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:09:12 --> Controller Class Initialized
DEBUG - 2010-07-05 06:09:12 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:09:12 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:09:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:09:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:09:12 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:09:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:09:12 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:09:12 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:09:13 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:09:13 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:09:13 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:09:13 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:09:13 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:09:13 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:09:13 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:09:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:09:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:09:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:09:14 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:09:14 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:09:14 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:09:15 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:09:15 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 06:09:15 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  insert or update on table &quot;scope&quot; violates foreign key constraint &quot;scope_webpage_id_fkey&quot;
DETAIL:  Key (webpage_id)=(46) is not present in table &quot;webpage&quot;. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-05 06:09:15 --> DB Transaction Failure
ERROR - 2010-07-05 06:09:15 --> Query error: ERROR:  insert or update on table "scope" violates foreign key constraint "scope_webpage_id_fkey"
DETAIL:  Key (webpage_id)=(46) is not present in table "webpage".
DEBUG - 2010-07-05 06:09:15 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-05 06:09:15 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:377) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-05 06:10:30 --> Config Class Initialized
DEBUG - 2010-07-05 06:10:30 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:10:30 --> URI Class Initialized
DEBUG - 2010-07-05 06:10:30 --> Router Class Initialized
DEBUG - 2010-07-05 06:10:30 --> Output Class Initialized
DEBUG - 2010-07-05 06:10:30 --> Input Class Initialized
DEBUG - 2010-07-05 06:10:30 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:10:30 --> Language Class Initialized
DEBUG - 2010-07-05 06:10:30 --> Loader Class Initialized
DEBUG - 2010-07-05 06:10:31 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:10:31 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:10:31 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:10:31 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:10:31 --> Controller Class Initialized
DEBUG - 2010-07-05 06:10:31 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:10:31 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:10:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:32 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:10:32 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:10:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:32 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:32 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:10:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:34 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:34 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:34 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:34 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:34 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:34 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 06:10:34 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:35 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:35 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:36 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:36 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:38 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:38 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:38 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:38 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:38 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:40 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:40 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:40 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:40 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:10:40 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 06:10:40 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid input syntax for integer: &quot;w&quot;
LINE 3: WHERE &quot;webpage_id&quot; = 'w'
                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-05 06:10:40 --> DB Transaction Failure
ERROR - 2010-07-05 06:10:40 --> Query error: ERROR:  invalid input syntax for integer: "w"
LINE 3: WHERE "webpage_id" = 'w'
                             ^
DEBUG - 2010-07-05 06:10:40 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-05 06:10:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:377) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-05 06:10:58 --> Config Class Initialized
DEBUG - 2010-07-05 06:10:58 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:10:58 --> URI Class Initialized
DEBUG - 2010-07-05 06:10:58 --> Router Class Initialized
DEBUG - 2010-07-05 06:10:59 --> Output Class Initialized
DEBUG - 2010-07-05 06:10:59 --> Input Class Initialized
DEBUG - 2010-07-05 06:10:59 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:10:59 --> Language Class Initialized
DEBUG - 2010-07-05 06:10:59 --> Loader Class Initialized
DEBUG - 2010-07-05 06:10:59 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:10:59 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:10:59 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:11:00 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:11:00 --> Controller Class Initialized
DEBUG - 2010-07-05 06:11:00 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:11:00 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:11:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:00 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:00 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:01 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:01 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:11:01 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:11:01 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:01 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:01 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:11:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:03 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:03 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:03 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:03 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:03 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:03 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 06:11:03 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:03 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:03 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:08 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:08 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:08 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:08 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:08 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:10 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:10 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:10 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:10 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:10 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:12 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:12 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:12 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:12 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:11:12 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 06:11:12 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid input syntax for integer: &quot;w&quot;
LINE 3: WHERE &quot;webpage_id&quot; = 'w'
                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-05 06:11:12 --> DB Transaction Failure
ERROR - 2010-07-05 06:11:12 --> Query error: ERROR:  invalid input syntax for integer: "w"
LINE 3: WHERE "webpage_id" = 'w'
                             ^
DEBUG - 2010-07-05 06:11:12 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-05 06:11:13 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:377) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-05 06:12:01 --> Config Class Initialized
DEBUG - 2010-07-05 06:12:02 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:12:02 --> URI Class Initialized
DEBUG - 2010-07-05 06:12:02 --> Router Class Initialized
DEBUG - 2010-07-05 06:12:02 --> Output Class Initialized
DEBUG - 2010-07-05 06:12:02 --> Input Class Initialized
DEBUG - 2010-07-05 06:12:02 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:12:02 --> Language Class Initialized
DEBUG - 2010-07-05 06:12:02 --> Loader Class Initialized
DEBUG - 2010-07-05 06:12:02 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:12:03 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:12:03 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:12:03 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:12:03 --> Controller Class Initialized
DEBUG - 2010-07-05 06:12:03 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:12:03 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:12:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:04 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:04 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:04 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:12:04 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:12:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:04 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:05 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:12:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:06 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:06 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:06 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:06 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:06 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:06 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 06:12:07 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:07 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:07 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:08 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:08 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:08 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:08 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:09 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:10 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:10 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:10 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:10 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:10 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:12 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:12 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:12 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:12 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:12 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 06:12:12 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid input syntax for integer: &quot;w&quot;
LINE 3: WHERE &quot;webpage_id&quot; = 'w'
                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-05 06:12:12 --> DB Transaction Failure
ERROR - 2010-07-05 06:12:13 --> Query error: ERROR:  invalid input syntax for integer: "w"
LINE 3: WHERE "webpage_id" = 'w'
                             ^
DEBUG - 2010-07-05 06:12:13 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-05 06:12:13 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:377) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-05 06:12:20 --> Config Class Initialized
DEBUG - 2010-07-05 06:12:20 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:12:20 --> URI Class Initialized
DEBUG - 2010-07-05 06:12:20 --> Router Class Initialized
DEBUG - 2010-07-05 06:12:21 --> Output Class Initialized
DEBUG - 2010-07-05 06:12:21 --> Input Class Initialized
DEBUG - 2010-07-05 06:12:21 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:12:21 --> Language Class Initialized
DEBUG - 2010-07-05 06:12:21 --> Loader Class Initialized
DEBUG - 2010-07-05 06:12:21 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:12:21 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:12:21 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:12:22 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:12:22 --> Controller Class Initialized
DEBUG - 2010-07-05 06:12:22 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:12:22 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:12:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:22 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:22 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:23 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:23 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:12:23 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:12:23 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:23 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:23 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:12:23 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:25 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:25 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:25 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:25 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:25 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:25 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 06:12:25 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:25 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:25 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:27 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:27 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:27 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:27 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:27 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:29 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:29 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:29 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:29 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:29 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:29 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:31 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:31 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:31 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:31 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:12:31 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 06:12:31 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid input syntax for integer: &quot;w&quot;
LINE 3: WHERE &quot;webpage_id&quot; = 'w'
                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-05 06:12:31 --> DB Transaction Failure
ERROR - 2010-07-05 06:12:31 --> Query error: ERROR:  invalid input syntax for integer: "w"
LINE 3: WHERE "webpage_id" = 'w'
                             ^
DEBUG - 2010-07-05 06:12:31 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-05 06:12:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:377) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-05 06:13:01 --> Config Class Initialized
DEBUG - 2010-07-05 06:13:01 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:13:01 --> URI Class Initialized
DEBUG - 2010-07-05 06:13:01 --> Router Class Initialized
DEBUG - 2010-07-05 06:13:01 --> Output Class Initialized
DEBUG - 2010-07-05 06:13:02 --> Input Class Initialized
DEBUG - 2010-07-05 06:13:02 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:13:02 --> Language Class Initialized
DEBUG - 2010-07-05 06:13:02 --> Loader Class Initialized
DEBUG - 2010-07-05 06:13:02 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:13:02 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:13:02 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:13:02 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:13:03 --> Controller Class Initialized
DEBUG - 2010-07-05 06:13:03 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:13:03 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:13:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:03 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:03 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:03 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:04 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:13:04 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:13:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:04 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:04 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:13:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:06 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:06 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:06 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:06 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:06 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:06 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 06:13:06 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:06 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:06 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:08 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:08 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:08 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:08 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:08 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:10 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:10 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:10 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:10 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:10 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:11 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:12 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:12 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:12 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:12 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:13:12 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 06:13:12 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid input syntax for integer: &quot;w&quot;
LINE 3: WHERE &quot;webpage_id&quot; = 'w'
                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-05 06:13:12 --> DB Transaction Failure
ERROR - 2010-07-05 06:13:12 --> Query error: ERROR:  invalid input syntax for integer: "w"
LINE 3: WHERE "webpage_id" = 'w'
                             ^
DEBUG - 2010-07-05 06:13:13 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-05 06:13:13 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:377) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-05 06:14:05 --> Config Class Initialized
DEBUG - 2010-07-05 06:14:06 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:14:06 --> URI Class Initialized
DEBUG - 2010-07-05 06:14:06 --> Router Class Initialized
DEBUG - 2010-07-05 06:14:06 --> Output Class Initialized
DEBUG - 2010-07-05 06:14:06 --> Input Class Initialized
DEBUG - 2010-07-05 06:14:06 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:14:06 --> Language Class Initialized
DEBUG - 2010-07-05 06:14:06 --> Loader Class Initialized
DEBUG - 2010-07-05 06:14:07 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:14:07 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:14:07 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:14:07 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:14:07 --> Controller Class Initialized
DEBUG - 2010-07-05 06:14:07 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:14:07 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:14:07 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:08 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:08 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:14:08 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:14:08 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:09 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:09 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:14:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:10 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:10 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:10 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:10 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:11 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:11 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:11 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 06:14:11 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:11 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:11 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:13 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:13 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:13 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:13 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:13 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:13 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:14 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:15 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:15 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:15 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:15 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:16 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:16 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:16 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:17 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:14:17 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 06:14:17 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid input syntax for integer: &quot;w&quot;
LINE 3: WHERE &quot;webpage_id&quot; = 'w'
                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-05 06:14:17 --> DB Transaction Failure
ERROR - 2010-07-05 06:14:17 --> Query error: ERROR:  invalid input syntax for integer: "w"
LINE 3: WHERE "webpage_id" = 'w'
                             ^
DEBUG - 2010-07-05 06:14:17 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-05 06:14:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:377) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-05 06:15:54 --> Config Class Initialized
DEBUG - 2010-07-05 06:15:54 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:15:55 --> URI Class Initialized
DEBUG - 2010-07-05 06:15:55 --> Router Class Initialized
DEBUG - 2010-07-05 06:15:55 --> Output Class Initialized
DEBUG - 2010-07-05 06:15:55 --> Input Class Initialized
DEBUG - 2010-07-05 06:15:55 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:15:55 --> Language Class Initialized
DEBUG - 2010-07-05 06:15:55 --> Loader Class Initialized
DEBUG - 2010-07-05 06:15:55 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:15:56 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:15:56 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:15:56 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:15:56 --> Controller Class Initialized
DEBUG - 2010-07-05 06:15:56 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:15:56 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:15:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:15:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:15:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:15:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:15:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:15:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:15:57 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:15:57 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:15:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:15:57 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:15:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:15:58 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:15:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:15:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:15:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:15:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:15:59 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:15:59 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:15:59 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:15:59 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:00 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:00 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 06:16:00 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:00 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:00 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:02 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:02 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:02 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:02 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:02 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:02 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:04 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:04 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:04 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:04 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:04 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:06 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:06 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:06 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:06 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:06 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:06 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 06:16:06 --> Final output sent to browser
DEBUG - 2010-07-05 06:16:06 --> Total execution time: 11.9520
DEBUG - 2010-07-05 06:16:28 --> Config Class Initialized
DEBUG - 2010-07-05 06:16:28 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:16:28 --> URI Class Initialized
DEBUG - 2010-07-05 06:16:28 --> Router Class Initialized
DEBUG - 2010-07-05 06:16:28 --> Output Class Initialized
DEBUG - 2010-07-05 06:16:28 --> Input Class Initialized
DEBUG - 2010-07-05 06:16:28 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:16:28 --> Language Class Initialized
DEBUG - 2010-07-05 06:16:29 --> Loader Class Initialized
DEBUG - 2010-07-05 06:16:29 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:16:29 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:16:29 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:16:29 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:16:29 --> Controller Class Initialized
DEBUG - 2010-07-05 06:16:29 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:16:29 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:16:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:30 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:30 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:30 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:16:30 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:16:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:31 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:31 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:16:31 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:32 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:32 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:33 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:33 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:33 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:33 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 06:16:33 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:33 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:33 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:35 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:35 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:35 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:35 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:35 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:37 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:37 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:37 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:37 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:37 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:39 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:39 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:39 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:39 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:39 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:16:39 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 06:16:39 --> Final output sent to browser
DEBUG - 2010-07-05 06:16:40 --> Total execution time: 11.7523
DEBUG - 2010-07-05 06:17:33 --> Config Class Initialized
DEBUG - 2010-07-05 06:17:33 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:17:34 --> URI Class Initialized
DEBUG - 2010-07-05 06:17:34 --> Router Class Initialized
DEBUG - 2010-07-05 06:17:34 --> Output Class Initialized
DEBUG - 2010-07-05 06:17:34 --> Input Class Initialized
DEBUG - 2010-07-05 06:17:34 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:17:34 --> Language Class Initialized
DEBUG - 2010-07-05 06:17:34 --> Loader Class Initialized
DEBUG - 2010-07-05 06:17:35 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:17:35 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:17:35 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:17:35 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:17:35 --> Controller Class Initialized
DEBUG - 2010-07-05 06:17:35 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:17:35 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:17:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:36 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:36 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:36 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:36 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:17:36 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:17:36 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:36 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:37 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:17:37 --> Session Class Initialized
DEBUG - 2010-07-05 06:17:37 --> Helper loaded: string_helper
DEBUG - 2010-07-05 06:17:37 --> Session routines successfully run
DEBUG - 2010-07-05 06:17:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:39 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:39 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:39 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:39 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:39 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:39 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 06:17:39 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:40 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:40 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:40 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:40 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:40 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:40 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:40 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:40 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:41 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:41 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:41 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:41 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:41 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:41 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:41 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:41 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:42 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:17:42 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 06:17:42 --> Final output sent to browser
DEBUG - 2010-07-05 06:17:42 --> Total execution time: 8.4600
DEBUG - 2010-07-05 06:19:24 --> Config Class Initialized
DEBUG - 2010-07-05 06:19:24 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:19:24 --> URI Class Initialized
DEBUG - 2010-07-05 06:19:24 --> Router Class Initialized
DEBUG - 2010-07-05 06:19:24 --> Output Class Initialized
DEBUG - 2010-07-05 06:19:24 --> Input Class Initialized
DEBUG - 2010-07-05 06:19:24 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:19:24 --> Language Class Initialized
DEBUG - 2010-07-05 06:19:25 --> Loader Class Initialized
DEBUG - 2010-07-05 06:19:25 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:19:25 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:19:25 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:19:25 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:19:25 --> Controller Class Initialized
DEBUG - 2010-07-05 06:19:25 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:19:25 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:19:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:26 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:26 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:26 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:19:26 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:19:27 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:27 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:27 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:19:27 --> Session Class Initialized
DEBUG - 2010-07-05 06:19:27 --> Helper loaded: string_helper
DEBUG - 2010-07-05 06:19:27 --> Session routines successfully run
DEBUG - 2010-07-05 06:19:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:28 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:29 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:29 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:29 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:29 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:30 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:30 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 06:19:30 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:30 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:30 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:30 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:30 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:30 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:31 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:31 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:31 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:31 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:31 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:31 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:31 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:31 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:32 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:32 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:32 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:32 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:19:32 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 06:19:32 --> Final output sent to browser
DEBUG - 2010-07-05 06:19:32 --> Total execution time: 8.7283
DEBUG - 2010-07-05 06:22:04 --> Config Class Initialized
DEBUG - 2010-07-05 06:22:04 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:22:04 --> URI Class Initialized
DEBUG - 2010-07-05 06:22:04 --> Router Class Initialized
DEBUG - 2010-07-05 06:22:04 --> Output Class Initialized
DEBUG - 2010-07-05 06:22:04 --> Input Class Initialized
DEBUG - 2010-07-05 06:22:04 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:22:04 --> Language Class Initialized
DEBUG - 2010-07-05 06:22:05 --> Loader Class Initialized
DEBUG - 2010-07-05 06:22:05 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:22:05 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:22:05 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:22:05 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:22:05 --> Controller Class Initialized
DEBUG - 2010-07-05 06:22:06 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:22:06 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:22:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:06 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:06 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:06 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:07 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:22:07 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:22:07 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:07 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:07 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:22:07 --> Session Class Initialized
DEBUG - 2010-07-05 06:22:08 --> Helper loaded: string_helper
DEBUG - 2010-07-05 06:22:08 --> Session routines successfully run
DEBUG - 2010-07-05 06:22:08 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:08 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:09 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:09 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:09 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:10 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:10 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:10 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:10 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 06:22:10 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:10 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:10 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:10 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:11 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:11 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:11 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:11 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:11 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:11 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:11 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:11 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:12 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:12 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:12 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:12 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:12 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:12 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:22:12 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 06:22:12 --> Final output sent to browser
DEBUG - 2010-07-05 06:22:13 --> Total execution time: 8.9023
DEBUG - 2010-07-05 06:23:10 --> Config Class Initialized
DEBUG - 2010-07-05 06:23:11 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:23:11 --> URI Class Initialized
DEBUG - 2010-07-05 06:23:11 --> Router Class Initialized
DEBUG - 2010-07-05 06:23:11 --> Output Class Initialized
DEBUG - 2010-07-05 06:23:11 --> Input Class Initialized
DEBUG - 2010-07-05 06:23:11 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:23:11 --> Language Class Initialized
DEBUG - 2010-07-05 06:23:12 --> Loader Class Initialized
DEBUG - 2010-07-05 06:23:12 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:23:12 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:23:12 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:23:12 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:23:12 --> Controller Class Initialized
DEBUG - 2010-07-05 06:23:12 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:23:13 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:23:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:13 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:13 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:13 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:13 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:23:14 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:23:14 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:14 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:14 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:23:14 --> Session Class Initialized
DEBUG - 2010-07-05 06:23:14 --> Helper loaded: string_helper
DEBUG - 2010-07-05 06:23:14 --> Session routines successfully run
DEBUG - 2010-07-05 06:23:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:16 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:16 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:16 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:16 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:17 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:17 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 06:23:17 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:17 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:17 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:17 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:17 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:18 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:18 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:18 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:18 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:18 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:18 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:18 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:18 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:19 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:19 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:19 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:19 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:19 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:19 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 06:23:19 --> Final output sent to browser
DEBUG - 2010-07-05 06:23:20 --> Total execution time: 8.9067
DEBUG - 2010-07-05 06:23:47 --> Config Class Initialized
DEBUG - 2010-07-05 06:23:48 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:23:48 --> URI Class Initialized
DEBUG - 2010-07-05 06:23:48 --> Router Class Initialized
DEBUG - 2010-07-05 06:23:48 --> Output Class Initialized
DEBUG - 2010-07-05 06:23:48 --> Input Class Initialized
DEBUG - 2010-07-05 06:23:48 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:23:48 --> Language Class Initialized
DEBUG - 2010-07-05 06:23:48 --> Loader Class Initialized
DEBUG - 2010-07-05 06:23:49 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:23:49 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:23:49 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:23:49 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:23:49 --> Controller Class Initialized
DEBUG - 2010-07-05 06:23:49 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:23:49 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:23:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:50 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:50 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:50 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:23:50 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:23:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:51 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:51 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:23:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:52 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:53 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:53 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:53 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:53 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:53 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 06:23:53 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:53 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:53 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:55 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:55 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:55 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:55 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:56 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:57 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:57 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:57 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:57 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:58 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:59 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:59 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:59 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:23:59 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:24:00 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:24:00 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 06:24:00 --> Final output sent to browser
DEBUG - 2010-07-05 06:24:00 --> Total execution time: 12.4372
DEBUG - 2010-07-05 06:26:07 --> Config Class Initialized
DEBUG - 2010-07-05 06:26:07 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:26:07 --> URI Class Initialized
DEBUG - 2010-07-05 06:26:08 --> Router Class Initialized
DEBUG - 2010-07-05 06:26:08 --> Output Class Initialized
DEBUG - 2010-07-05 06:26:08 --> Input Class Initialized
DEBUG - 2010-07-05 06:26:08 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:26:08 --> Language Class Initialized
DEBUG - 2010-07-05 06:26:08 --> Loader Class Initialized
DEBUG - 2010-07-05 06:26:08 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:26:09 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:26:09 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:26:09 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:26:09 --> Controller Class Initialized
DEBUG - 2010-07-05 06:26:09 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:26:09 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:26:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:10 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:10 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:10 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:10 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:26:11 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:26:11 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:11 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:11 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:26:11 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:13 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:13 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:13 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:13 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:13 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:13 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 06:26:14 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:14 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:14 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:15 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:15 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:16 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:16 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:16 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:17 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:17 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:18 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:18 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:18 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:19 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:20 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:20 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:20 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:20 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:26:20 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 06:26:20 --> Final output sent to browser
DEBUG - 2010-07-05 06:26:20 --> Total execution time: 13.1969
DEBUG - 2010-07-05 06:27:28 --> Config Class Initialized
DEBUG - 2010-07-05 06:27:28 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:27:29 --> URI Class Initialized
DEBUG - 2010-07-05 06:27:29 --> Router Class Initialized
DEBUG - 2010-07-05 06:27:29 --> Output Class Initialized
DEBUG - 2010-07-05 06:27:29 --> Input Class Initialized
DEBUG - 2010-07-05 06:27:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:27:29 --> Language Class Initialized
DEBUG - 2010-07-05 06:27:29 --> Loader Class Initialized
DEBUG - 2010-07-05 06:27:30 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:27:30 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:27:30 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:27:30 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:27:30 --> Controller Class Initialized
DEBUG - 2010-07-05 06:27:30 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:27:30 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:27:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:31 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:27:32 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:27:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:32 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:32 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:27:32 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:34 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:34 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:34 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:34 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:34 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:34 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 06:27:34 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:35 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:35 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:37 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:37 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:37 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:37 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:37 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:39 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:39 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:39 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:39 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:39 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:41 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:41 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:41 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:41 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:27:41 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 06:27:41 --> Severity: Notice  --> Undefined index:  scope_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 458
DEBUG - 2010-07-05 06:27:41 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 06:27:42 --> Final output sent to browser
DEBUG - 2010-07-05 06:27:42 --> Total execution time: 13.3250
DEBUG - 2010-07-05 06:28:30 --> Config Class Initialized
DEBUG - 2010-07-05 06:28:30 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:28:30 --> URI Class Initialized
DEBUG - 2010-07-05 06:28:30 --> Router Class Initialized
DEBUG - 2010-07-05 06:28:30 --> Output Class Initialized
DEBUG - 2010-07-05 06:28:30 --> Input Class Initialized
DEBUG - 2010-07-05 06:28:31 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:28:31 --> Language Class Initialized
DEBUG - 2010-07-05 06:28:31 --> Loader Class Initialized
DEBUG - 2010-07-05 06:28:31 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:28:31 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:28:31 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:28:31 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:28:32 --> Controller Class Initialized
DEBUG - 2010-07-05 06:28:32 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:28:32 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:28:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:33 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:33 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:33 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:28:33 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:28:33 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:33 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:34 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:28:34 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:35 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:36 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:36 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:36 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 06:28:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:36 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:37 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:38 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:38 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:38 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:38 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:39 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:40 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:40 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:40 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:40 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:41 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:42 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:42 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:42 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:42 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:28:43 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 06:28:43 --> Severity: Notice  --> Undefined index:  scope_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 458
DEBUG - 2010-07-05 06:28:43 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 06:28:43 --> Final output sent to browser
DEBUG - 2010-07-05 06:28:43 --> Total execution time: 13.3497
DEBUG - 2010-07-05 06:29:43 --> Config Class Initialized
DEBUG - 2010-07-05 06:29:43 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:29:43 --> URI Class Initialized
DEBUG - 2010-07-05 06:29:43 --> Router Class Initialized
DEBUG - 2010-07-05 06:29:43 --> Output Class Initialized
DEBUG - 2010-07-05 06:29:44 --> Input Class Initialized
DEBUG - 2010-07-05 06:29:44 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:29:44 --> Language Class Initialized
DEBUG - 2010-07-05 06:29:44 --> Loader Class Initialized
DEBUG - 2010-07-05 06:29:44 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:29:44 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:29:44 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:29:45 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:29:45 --> Controller Class Initialized
DEBUG - 2010-07-05 06:29:45 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:29:45 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:29:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:45 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:46 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:46 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:46 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:29:46 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:29:46 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:46 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:46 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:47 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:29:47 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:47 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:48 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:48 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:49 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:49 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:49 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:49 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:49 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 06:29:49 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:49 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:50 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:50 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:50 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:50 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:51 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:51 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:51 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:51 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:52 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:53 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:53 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:54 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:54 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:54 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:55 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:56 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:56 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:56 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:29:56 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 06:29:56 --> Severity: Notice  --> Undefined index:  scope_id D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\Generic_object.php 459
DEBUG - 2010-07-05 06:29:56 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 06:29:56 --> Final output sent to browser
DEBUG - 2010-07-05 06:29:57 --> Total execution time: 13.6435
DEBUG - 2010-07-05 06:30:42 --> Config Class Initialized
DEBUG - 2010-07-05 06:30:42 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:30:42 --> URI Class Initialized
DEBUG - 2010-07-05 06:30:43 --> Router Class Initialized
DEBUG - 2010-07-05 06:30:43 --> Output Class Initialized
DEBUG - 2010-07-05 06:30:43 --> Input Class Initialized
DEBUG - 2010-07-05 06:30:43 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:30:43 --> Language Class Initialized
DEBUG - 2010-07-05 06:30:43 --> Loader Class Initialized
DEBUG - 2010-07-05 06:30:43 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:30:44 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:30:44 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:30:44 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:30:44 --> Controller Class Initialized
DEBUG - 2010-07-05 06:30:44 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:30:44 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:30:44 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:45 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:45 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:45 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:30:45 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:30:45 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:46 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:46 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:46 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:30:46 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:47 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:47 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:48 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:48 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:48 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:48 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:48 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:48 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 06:30:49 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:49 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:49 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:49 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:50 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:50 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:50 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:50 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:51 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:51 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:51 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:52 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:52 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:53 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:53 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:53 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:53 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:55 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:55 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:55 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:55 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:55 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:30:55 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 06:30:55 --> Final output sent to browser
DEBUG - 2010-07-05 06:30:56 --> Total execution time: 13.2905
DEBUG - 2010-07-05 06:34:54 --> Config Class Initialized
DEBUG - 2010-07-05 06:34:54 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:34:54 --> URI Class Initialized
DEBUG - 2010-07-05 06:34:55 --> Router Class Initialized
DEBUG - 2010-07-05 06:34:55 --> Output Class Initialized
DEBUG - 2010-07-05 06:34:55 --> Input Class Initialized
DEBUG - 2010-07-05 06:34:55 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:34:55 --> Language Class Initialized
DEBUG - 2010-07-05 06:34:55 --> Loader Class Initialized
DEBUG - 2010-07-05 06:34:55 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:34:56 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:34:56 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:34:56 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:34:56 --> Controller Class Initialized
DEBUG - 2010-07-05 06:34:56 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:34:56 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:34:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:34:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:34:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:34:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:34:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:34:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:34:57 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:34:58 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:34:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:34:58 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:34:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:34:58 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:34:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:34:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:34:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:36:08 --> Config Class Initialized
DEBUG - 2010-07-05 06:36:08 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:36:08 --> URI Class Initialized
DEBUG - 2010-07-05 06:36:08 --> Router Class Initialized
DEBUG - 2010-07-05 06:36:08 --> Output Class Initialized
DEBUG - 2010-07-05 06:36:08 --> Input Class Initialized
DEBUG - 2010-07-05 06:36:09 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:36:09 --> Language Class Initialized
DEBUG - 2010-07-05 06:36:09 --> Loader Class Initialized
DEBUG - 2010-07-05 06:36:09 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:36:09 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:36:09 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:36:09 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:36:10 --> Controller Class Initialized
DEBUG - 2010-07-05 06:36:10 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:36:10 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:36:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:36:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:36:10 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:36:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:36:11 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:36:11 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:36:11 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:36:11 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:36:11 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:36:12 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:36:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:36:12 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:36:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:36:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:36:13 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:36:59 --> Config Class Initialized
DEBUG - 2010-07-05 06:37:00 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:37:00 --> URI Class Initialized
DEBUG - 2010-07-05 06:37:00 --> Router Class Initialized
DEBUG - 2010-07-05 06:37:00 --> Output Class Initialized
DEBUG - 2010-07-05 06:37:00 --> Input Class Initialized
DEBUG - 2010-07-05 06:37:00 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:37:00 --> Language Class Initialized
DEBUG - 2010-07-05 06:37:01 --> Loader Class Initialized
DEBUG - 2010-07-05 06:37:01 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:37:01 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:37:01 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:37:01 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:37:01 --> Controller Class Initialized
DEBUG - 2010-07-05 06:37:01 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:37:02 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:37:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:37:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:37:02 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:37:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:37:02 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:37:03 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:37:03 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:37:03 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:37:03 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:37:03 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:37:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:37:04 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:37:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:37:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:37:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:40:38 --> Config Class Initialized
DEBUG - 2010-07-05 06:40:38 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:40:38 --> URI Class Initialized
DEBUG - 2010-07-05 06:40:38 --> Router Class Initialized
DEBUG - 2010-07-05 06:40:38 --> Output Class Initialized
DEBUG - 2010-07-05 06:40:38 --> Input Class Initialized
DEBUG - 2010-07-05 06:40:39 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:40:39 --> Language Class Initialized
DEBUG - 2010-07-05 06:40:39 --> Loader Class Initialized
DEBUG - 2010-07-05 06:40:39 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:40:39 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:40:39 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:40:39 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:40:40 --> Controller Class Initialized
DEBUG - 2010-07-05 06:40:40 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:40:40 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:40:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:40:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:40:40 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:40:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:40:41 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:40:41 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:40:41 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:40:41 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:40:41 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:40:41 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:40:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:40:42 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:40:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:40:43 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:40:43 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:41:31 --> Config Class Initialized
DEBUG - 2010-07-05 06:41:31 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:41:31 --> URI Class Initialized
DEBUG - 2010-07-05 06:41:31 --> Router Class Initialized
DEBUG - 2010-07-05 06:41:32 --> Output Class Initialized
DEBUG - 2010-07-05 06:41:32 --> Input Class Initialized
DEBUG - 2010-07-05 06:41:32 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:41:32 --> Language Class Initialized
DEBUG - 2010-07-05 06:41:32 --> Loader Class Initialized
DEBUG - 2010-07-05 06:41:32 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:41:32 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:41:33 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:41:33 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:41:33 --> Controller Class Initialized
DEBUG - 2010-07-05 06:41:33 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:41:33 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:41:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:41:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:41:34 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:41:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:41:34 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:41:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:41:34 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:41:34 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:41:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:41:35 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:41:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:41:35 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:41:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:41:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:41:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:42:55 --> Config Class Initialized
DEBUG - 2010-07-05 06:42:55 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:42:55 --> URI Class Initialized
DEBUG - 2010-07-05 06:42:55 --> Router Class Initialized
DEBUG - 2010-07-05 06:42:55 --> Output Class Initialized
DEBUG - 2010-07-05 06:42:56 --> Input Class Initialized
DEBUG - 2010-07-05 06:42:56 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:42:56 --> Language Class Initialized
DEBUG - 2010-07-05 06:42:56 --> Loader Class Initialized
DEBUG - 2010-07-05 06:42:56 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:42:56 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:42:56 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:42:57 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:42:57 --> Controller Class Initialized
DEBUG - 2010-07-05 06:42:57 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:42:57 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:42:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:42:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:42:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:42:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:42:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:42:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:42:58 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:42:58 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:42:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:42:58 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:42:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:42:59 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:42:59 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:42:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:43:00 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:47 --> Config Class Initialized
DEBUG - 2010-07-05 06:45:47 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:45:47 --> URI Class Initialized
DEBUG - 2010-07-05 06:45:47 --> Router Class Initialized
DEBUG - 2010-07-05 06:45:48 --> Output Class Initialized
DEBUG - 2010-07-05 06:45:48 --> Input Class Initialized
DEBUG - 2010-07-05 06:45:48 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:45:48 --> Language Class Initialized
DEBUG - 2010-07-05 06:45:48 --> Loader Class Initialized
DEBUG - 2010-07-05 06:45:48 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:45:48 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:45:49 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:45:49 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:45:49 --> Controller Class Initialized
DEBUG - 2010-07-05 06:45:49 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:45:49 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:45:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:50 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:50 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:50 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:45:50 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:45:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:51 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:51 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:45:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:51 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:52 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:52 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:52 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:52 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:53 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:53 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 06:45:53 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:53 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:53 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:53 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:54 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:54 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:55 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:55 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:55 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:55 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:56 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:56 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:56 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:57 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:57 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:57 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:58 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:58 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:58 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:58 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:45:58 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 06:45:59 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid input syntax for integer: &quot;w&quot;
LINE 3: WHERE &quot;webpage_id&quot; = 'w'
                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-05 06:45:59 --> DB Transaction Failure
ERROR - 2010-07-05 06:45:59 --> Query error: ERROR:  invalid input syntax for integer: "w"
LINE 3: WHERE "webpage_id" = 'w'
                             ^
DEBUG - 2010-07-05 06:45:59 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-05 06:45:59 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:377) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-05 06:46:32 --> Config Class Initialized
DEBUG - 2010-07-05 06:46:32 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:46:32 --> URI Class Initialized
DEBUG - 2010-07-05 06:46:32 --> Router Class Initialized
DEBUG - 2010-07-05 06:46:32 --> Output Class Initialized
DEBUG - 2010-07-05 06:46:32 --> Input Class Initialized
DEBUG - 2010-07-05 06:46:33 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:46:33 --> Language Class Initialized
DEBUG - 2010-07-05 06:46:33 --> Loader Class Initialized
DEBUG - 2010-07-05 06:46:33 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:46:33 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:46:33 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:46:33 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:46:34 --> Controller Class Initialized
DEBUG - 2010-07-05 06:46:34 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:46:34 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:46:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:34 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:35 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:35 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:35 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:35 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:46:35 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:46:35 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:36 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:36 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:46:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:37 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:37 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:37 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:37 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:38 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:38 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 06:46:38 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:38 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:38 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:39 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:40 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:40 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:40 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:40 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:41 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:41 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:42 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:42 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:42 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:42 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:43 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:43 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:43 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:43 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:44 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:46:44 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 06:46:44 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid input syntax for integer: &quot;w&quot;
LINE 3: WHERE &quot;webpage_id&quot; = 'w'
                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-05 06:46:44 --> DB Transaction Failure
ERROR - 2010-07-05 06:46:44 --> Query error: ERROR:  invalid input syntax for integer: "w"
LINE 3: WHERE "webpage_id" = 'w'
                             ^
DEBUG - 2010-07-05 06:46:44 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-05 06:46:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:377) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-05 06:49:31 --> Config Class Initialized
DEBUG - 2010-07-05 06:49:32 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:49:32 --> URI Class Initialized
DEBUG - 2010-07-05 06:49:32 --> Router Class Initialized
DEBUG - 2010-07-05 06:49:32 --> Output Class Initialized
DEBUG - 2010-07-05 06:49:32 --> Input Class Initialized
DEBUG - 2010-07-05 06:49:32 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:49:32 --> Language Class Initialized
DEBUG - 2010-07-05 06:49:33 --> Loader Class Initialized
DEBUG - 2010-07-05 06:49:33 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:49:33 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:49:33 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:49:33 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:49:33 --> Controller Class Initialized
DEBUG - 2010-07-05 06:49:34 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:49:34 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:49:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:34 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:34 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:35 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:35 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:49:35 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:49:35 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:35 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:35 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:35 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:49:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:36 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:36 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:36 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:37 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:37 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:37 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:37 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 06:49:37 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:37 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:37 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:38 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:38 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:38 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:39 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:39 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:39 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:40 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:40 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:40 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:40 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:40 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:40 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:41 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:41 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:41 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:41 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:41 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:42 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:49:42 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 06:49:42 --> Final output sent to browser
DEBUG - 2010-07-05 06:49:42 --> Total execution time: 10.4508
DEBUG - 2010-07-05 06:51:13 --> Config Class Initialized
DEBUG - 2010-07-05 06:51:13 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:51:13 --> URI Class Initialized
DEBUG - 2010-07-05 06:51:13 --> Router Class Initialized
DEBUG - 2010-07-05 06:51:13 --> Output Class Initialized
DEBUG - 2010-07-05 06:51:14 --> Input Class Initialized
DEBUG - 2010-07-05 06:51:14 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:51:14 --> Language Class Initialized
DEBUG - 2010-07-05 06:51:14 --> Loader Class Initialized
DEBUG - 2010-07-05 06:51:14 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:51:14 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:51:15 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:51:15 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:51:15 --> Controller Class Initialized
DEBUG - 2010-07-05 06:51:15 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:51:15 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:51:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:16 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:16 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:16 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:51:16 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:51:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:17 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:17 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:51:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:18 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:18 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:18 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:18 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:18 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:19 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 06:51:19 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:19 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:19 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:20 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:20 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:20 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:20 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:20 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:21 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:21 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:21 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:22 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:22 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:23 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:23 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:23 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:51:23 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 06:51:23 --> Final output sent to browser
DEBUG - 2010-07-05 06:51:24 --> Total execution time: 10.6167
DEBUG - 2010-07-05 06:57:12 --> Config Class Initialized
DEBUG - 2010-07-05 06:57:12 --> Hooks Class Initialized
DEBUG - 2010-07-05 06:57:12 --> URI Class Initialized
DEBUG - 2010-07-05 06:57:13 --> Router Class Initialized
DEBUG - 2010-07-05 06:57:13 --> Output Class Initialized
DEBUG - 2010-07-05 06:57:13 --> Input Class Initialized
DEBUG - 2010-07-05 06:57:13 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 06:57:13 --> Language Class Initialized
DEBUG - 2010-07-05 06:57:13 --> Loader Class Initialized
DEBUG - 2010-07-05 06:57:14 --> Helper loaded: context_helper
DEBUG - 2010-07-05 06:57:14 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 06:57:14 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 06:57:14 --> Database Driver Class Initialized
DEBUG - 2010-07-05 06:57:14 --> Controller Class Initialized
DEBUG - 2010-07-05 06:57:14 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 06:57:15 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 06:57:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:15 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:15 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:16 --> Helper loaded: email_helper
DEBUG - 2010-07-05 06:57:16 --> User Agent Class Initialized
DEBUG - 2010-07-05 06:57:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:16 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:16 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 06:57:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:17 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:17 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:17 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:17 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:18 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:18 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:18 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 06:57:18 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:18 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:18 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:19 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:19 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:19 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:19 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:20 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:20 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:20 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:20 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:21 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:21 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:21 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:21 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:22 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:22 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:22 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:22 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:23 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 06:57:23 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 06:57:23 --> Final output sent to browser
DEBUG - 2010-07-05 06:57:23 --> Total execution time: 10.7212
DEBUG - 2010-07-05 07:01:16 --> Config Class Initialized
DEBUG - 2010-07-05 07:01:16 --> Hooks Class Initialized
DEBUG - 2010-07-05 07:01:17 --> URI Class Initialized
DEBUG - 2010-07-05 07:01:17 --> Router Class Initialized
DEBUG - 2010-07-05 07:01:17 --> Output Class Initialized
DEBUG - 2010-07-05 07:01:17 --> Input Class Initialized
DEBUG - 2010-07-05 07:01:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 07:01:17 --> Language Class Initialized
DEBUG - 2010-07-05 07:01:18 --> Loader Class Initialized
DEBUG - 2010-07-05 07:01:18 --> Helper loaded: context_helper
DEBUG - 2010-07-05 07:01:18 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 07:01:18 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 07:01:18 --> Database Driver Class Initialized
DEBUG - 2010-07-05 07:01:18 --> Controller Class Initialized
DEBUG - 2010-07-05 07:01:19 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 07:01:19 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 07:01:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:19 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:19 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:19 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:20 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:20 --> Helper loaded: email_helper
DEBUG - 2010-07-05 07:01:20 --> User Agent Class Initialized
DEBUG - 2010-07-05 07:01:20 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:20 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:20 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:21 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 07:01:21 --> Session Class Initialized
DEBUG - 2010-07-05 07:01:21 --> Helper loaded: string_helper
DEBUG - 2010-07-05 07:01:21 --> Session routines successfully run
DEBUG - 2010-07-05 07:01:21 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:21 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:22 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:22 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:22 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:23 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:23 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:23 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:23 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 07:01:23 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:23 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:24 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:24 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:24 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:24 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:24 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:25 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:25 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:25 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:25 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:25 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:25 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:26 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:26 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:26 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:26 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:26 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 07:01:26 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 07:01:27 --> Final output sent to browser
DEBUG - 2010-07-05 07:01:27 --> Total execution time: 10.2585
DEBUG - 2010-07-05 12:23:45 --> Config Class Initialized
DEBUG - 2010-07-05 12:23:45 --> Hooks Class Initialized
DEBUG - 2010-07-05 12:23:45 --> URI Class Initialized
DEBUG - 2010-07-05 12:23:45 --> Router Class Initialized
DEBUG - 2010-07-05 12:23:45 --> Output Class Initialized
DEBUG - 2010-07-05 12:23:46 --> Input Class Initialized
DEBUG - 2010-07-05 12:23:46 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 12:23:46 --> Language Class Initialized
DEBUG - 2010-07-05 12:23:46 --> Loader Class Initialized
DEBUG - 2010-07-05 12:23:46 --> Helper loaded: context_helper
DEBUG - 2010-07-05 12:23:46 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 12:23:47 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 12:23:47 --> Database Driver Class Initialized
DEBUG - 2010-07-05 12:23:47 --> Controller Class Initialized
DEBUG - 2010-07-05 12:23:47 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 12:23:47 --> Helper loaded: unit_test_helper
ERROR - 2010-07-05 12:23:47 --> Unable to load the requested class: annotation_scope
DEBUG - 2010-07-05 12:24:11 --> Config Class Initialized
DEBUG - 2010-07-05 12:24:11 --> Hooks Class Initialized
DEBUG - 2010-07-05 12:24:11 --> URI Class Initialized
DEBUG - 2010-07-05 12:24:11 --> Router Class Initialized
DEBUG - 2010-07-05 12:24:11 --> Output Class Initialized
DEBUG - 2010-07-05 12:24:11 --> Input Class Initialized
DEBUG - 2010-07-05 12:24:12 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 12:24:12 --> Language Class Initialized
DEBUG - 2010-07-05 12:24:12 --> Loader Class Initialized
DEBUG - 2010-07-05 12:24:12 --> Helper loaded: context_helper
DEBUG - 2010-07-05 12:24:12 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 12:24:12 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 12:24:13 --> Database Driver Class Initialized
DEBUG - 2010-07-05 12:24:13 --> Controller Class Initialized
DEBUG - 2010-07-05 12:24:13 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 12:24:13 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 12:24:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:14 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:14 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:14 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:14 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:14 --> Helper loaded: email_helper
DEBUG - 2010-07-05 12:24:14 --> User Agent Class Initialized
DEBUG - 2010-07-05 12:24:14 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:15 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:15 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:15 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 12:24:15 --> Session Class Initialized
DEBUG - 2010-07-05 12:24:15 --> Helper loaded: string_helper
DEBUG - 2010-07-05 12:24:15 --> A session cookie was not found.
DEBUG - 2010-07-05 12:24:16 --> Session routines successfully run
DEBUG - 2010-07-05 12:24:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:16 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:17 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:17 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:17 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:17 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:17 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:18 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 12:24:18 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:18 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:18 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:19 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:19 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:19 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:19 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:19 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:19 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:19 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:20 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:20 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:20 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:20 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:20 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:20 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:21 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:21 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:24:21 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 12:24:21 --> Final output sent to browser
DEBUG - 2010-07-05 12:24:21 --> Total execution time: 10.3959
DEBUG - 2010-07-05 12:34:49 --> Config Class Initialized
DEBUG - 2010-07-05 12:34:49 --> Hooks Class Initialized
DEBUG - 2010-07-05 12:34:49 --> URI Class Initialized
DEBUG - 2010-07-05 12:34:49 --> Router Class Initialized
DEBUG - 2010-07-05 12:34:49 --> Output Class Initialized
DEBUG - 2010-07-05 12:34:49 --> Input Class Initialized
DEBUG - 2010-07-05 12:34:50 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 12:34:50 --> Language Class Initialized
DEBUG - 2010-07-05 12:34:58 --> Config Class Initialized
DEBUG - 2010-07-05 12:34:59 --> Hooks Class Initialized
DEBUG - 2010-07-05 12:34:59 --> URI Class Initialized
DEBUG - 2010-07-05 12:34:59 --> Router Class Initialized
DEBUG - 2010-07-05 12:34:59 --> Output Class Initialized
DEBUG - 2010-07-05 12:34:59 --> Input Class Initialized
DEBUG - 2010-07-05 12:34:59 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 12:35:00 --> Language Class Initialized
DEBUG - 2010-07-05 12:35:00 --> Loader Class Initialized
DEBUG - 2010-07-05 12:35:00 --> Helper loaded: context_helper
DEBUG - 2010-07-05 12:35:00 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 12:35:00 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 12:35:01 --> Database Driver Class Initialized
DEBUG - 2010-07-05 12:35:01 --> Controller Class Initialized
DEBUG - 2010-07-05 12:35:01 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 12:35:01 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 12:35:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:01 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:02 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:02 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:02 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:02 --> Helper loaded: email_helper
DEBUG - 2010-07-05 12:35:02 --> User Agent Class Initialized
DEBUG - 2010-07-05 12:35:03 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:03 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:03 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:03 --> Config file loaded: config/kals.php
ERROR - 2010-07-05 12:35:03 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Annotation_scope_collection.php 26
DEBUG - 2010-07-05 12:35:34 --> Config Class Initialized
DEBUG - 2010-07-05 12:35:34 --> Hooks Class Initialized
DEBUG - 2010-07-05 12:35:34 --> URI Class Initialized
DEBUG - 2010-07-05 12:35:34 --> Router Class Initialized
DEBUG - 2010-07-05 12:35:34 --> Output Class Initialized
DEBUG - 2010-07-05 12:35:34 --> Input Class Initialized
DEBUG - 2010-07-05 12:35:35 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 12:35:35 --> Language Class Initialized
DEBUG - 2010-07-05 12:35:35 --> Loader Class Initialized
DEBUG - 2010-07-05 12:35:35 --> Helper loaded: context_helper
DEBUG - 2010-07-05 12:35:35 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 12:35:35 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 12:35:35 --> Database Driver Class Initialized
DEBUG - 2010-07-05 12:35:36 --> Controller Class Initialized
DEBUG - 2010-07-05 12:35:36 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 12:35:36 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 12:35:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:36 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:36 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:37 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:37 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:37 --> Helper loaded: email_helper
DEBUG - 2010-07-05 12:35:37 --> User Agent Class Initialized
DEBUG - 2010-07-05 12:35:37 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:38 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:38 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:38 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 12:35:38 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:38 --> Session Class Initialized
DEBUG - 2010-07-05 12:35:38 --> Helper loaded: string_helper
DEBUG - 2010-07-05 12:35:39 --> Session routines successfully run
DEBUG - 2010-07-05 12:35:39 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:39 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:39 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:39 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:39 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:39 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 12:35:40 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:40 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:40 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:40 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:40 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:40 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:41 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:41 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:41 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:41 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:41 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:41 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:42 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:42 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:42 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:42 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:42 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:42 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:43 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:43 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:35:43 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 12:35:43 --> Final output sent to browser
DEBUG - 2010-07-05 12:35:43 --> Total execution time: 9.5875
DEBUG - 2010-07-05 12:41:57 --> Config Class Initialized
DEBUG - 2010-07-05 12:41:57 --> Hooks Class Initialized
DEBUG - 2010-07-05 12:41:57 --> URI Class Initialized
DEBUG - 2010-07-05 12:41:57 --> Router Class Initialized
DEBUG - 2010-07-05 12:41:57 --> Output Class Initialized
DEBUG - 2010-07-05 12:41:58 --> Input Class Initialized
DEBUG - 2010-07-05 12:41:58 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 12:41:58 --> Language Class Initialized
DEBUG - 2010-07-05 12:41:58 --> Loader Class Initialized
DEBUG - 2010-07-05 12:41:58 --> Helper loaded: context_helper
DEBUG - 2010-07-05 12:41:58 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 12:41:59 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 12:41:59 --> Database Driver Class Initialized
DEBUG - 2010-07-05 12:41:59 --> Controller Class Initialized
DEBUG - 2010-07-05 12:41:59 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 12:41:59 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 12:41:59 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:00 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:00 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:00 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:00 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:00 --> Helper loaded: email_helper
DEBUG - 2010-07-05 12:42:01 --> User Agent Class Initialized
DEBUG - 2010-07-05 12:42:01 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:01 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:01 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:01 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 12:42:01 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:02 --> Session Class Initialized
DEBUG - 2010-07-05 12:42:02 --> Helper loaded: string_helper
DEBUG - 2010-07-05 12:42:02 --> Session routines successfully run
DEBUG - 2010-07-05 12:42:02 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:02 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:02 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:03 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:03 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:03 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 12:42:03 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:03 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:03 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:04 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:04 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:04 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:04 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:04 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:04 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:04 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:05 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:05 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:05 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:05 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:05 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:06 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:06 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:06 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:06 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:06 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:42:06 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 12:42:07 --> Final output sent to browser
DEBUG - 2010-07-05 12:42:07 --> Total execution time: 9.8690
DEBUG - 2010-07-05 12:43:22 --> Config Class Initialized
DEBUG - 2010-07-05 12:43:22 --> Hooks Class Initialized
DEBUG - 2010-07-05 12:43:22 --> URI Class Initialized
DEBUG - 2010-07-05 12:43:22 --> Router Class Initialized
DEBUG - 2010-07-05 12:43:22 --> Output Class Initialized
DEBUG - 2010-07-05 12:43:22 --> Input Class Initialized
DEBUG - 2010-07-05 12:43:23 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 12:43:23 --> Language Class Initialized
DEBUG - 2010-07-05 12:43:23 --> Loader Class Initialized
DEBUG - 2010-07-05 12:43:23 --> Helper loaded: context_helper
DEBUG - 2010-07-05 12:43:23 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 12:43:23 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 12:43:24 --> Database Driver Class Initialized
DEBUG - 2010-07-05 12:43:24 --> Controller Class Initialized
DEBUG - 2010-07-05 12:43:24 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 12:43:24 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 12:43:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:25 --> Helper loaded: email_helper
DEBUG - 2010-07-05 12:43:25 --> User Agent Class Initialized
DEBUG - 2010-07-05 12:43:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:26 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:26 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 12:43:26 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:26 --> Session Class Initialized
DEBUG - 2010-07-05 12:43:27 --> Helper loaded: string_helper
DEBUG - 2010-07-05 12:43:27 --> Session routines successfully run
DEBUG - 2010-07-05 12:43:27 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:27 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:27 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:27 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:28 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:28 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 12:43:28 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:28 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:28 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:28 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:29 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:29 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:29 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:29 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:29 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:29 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:30 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:30 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:30 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:30 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:30 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:30 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:31 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:31 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:31 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:31 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:31 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 12:43:31 --> Final output sent to browser
DEBUG - 2010-07-05 12:43:32 --> Total execution time: 9.8289
DEBUG - 2010-07-05 12:43:52 --> Config Class Initialized
DEBUG - 2010-07-05 12:43:52 --> Hooks Class Initialized
DEBUG - 2010-07-05 12:43:52 --> URI Class Initialized
DEBUG - 2010-07-05 12:43:52 --> Router Class Initialized
DEBUG - 2010-07-05 12:43:52 --> Output Class Initialized
DEBUG - 2010-07-05 12:43:53 --> Input Class Initialized
DEBUG - 2010-07-05 12:43:53 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 12:43:53 --> Language Class Initialized
DEBUG - 2010-07-05 12:43:53 --> Loader Class Initialized
DEBUG - 2010-07-05 12:43:53 --> Helper loaded: context_helper
DEBUG - 2010-07-05 12:43:53 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 12:43:53 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 12:43:54 --> Database Driver Class Initialized
DEBUG - 2010-07-05 12:43:54 --> Controller Class Initialized
DEBUG - 2010-07-05 12:43:54 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 12:43:54 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 12:43:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:54 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:55 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:55 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:55 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:55 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:55 --> Helper loaded: email_helper
DEBUG - 2010-07-05 12:43:55 --> User Agent Class Initialized
DEBUG - 2010-07-05 12:43:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:56 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:56 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:56 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 12:43:56 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:56 --> Session Class Initialized
DEBUG - 2010-07-05 12:43:57 --> Helper loaded: string_helper
DEBUG - 2010-07-05 12:43:57 --> Session routines successfully run
DEBUG - 2010-07-05 12:43:57 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:57 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:57 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:57 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:58 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:58 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 12:43:58 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:58 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:43:58 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 12:43:58 --> Final output sent to browser
DEBUG - 2010-07-05 12:43:59 --> Total execution time: 6.7319
DEBUG - 2010-07-05 12:45:20 --> Config Class Initialized
DEBUG - 2010-07-05 12:45:20 --> Hooks Class Initialized
DEBUG - 2010-07-05 12:45:20 --> URI Class Initialized
DEBUG - 2010-07-05 12:45:20 --> Router Class Initialized
DEBUG - 2010-07-05 12:45:20 --> Output Class Initialized
DEBUG - 2010-07-05 12:45:20 --> Input Class Initialized
DEBUG - 2010-07-05 12:45:21 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 12:45:21 --> Language Class Initialized
DEBUG - 2010-07-05 12:45:21 --> Loader Class Initialized
DEBUG - 2010-07-05 12:45:21 --> Helper loaded: context_helper
DEBUG - 2010-07-05 12:45:21 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 12:45:21 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 12:45:22 --> Database Driver Class Initialized
DEBUG - 2010-07-05 12:45:22 --> Controller Class Initialized
DEBUG - 2010-07-05 12:45:22 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 12:45:22 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 12:45:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:45:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:45:23 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:45:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:45:23 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:45:23 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:45:23 --> Helper loaded: email_helper
DEBUG - 2010-07-05 12:45:23 --> User Agent Class Initialized
DEBUG - 2010-07-05 12:45:24 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:45:24 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:45:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:45:24 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 12:45:24 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:45:24 --> Session Class Initialized
DEBUG - 2010-07-05 12:45:25 --> Helper loaded: string_helper
DEBUG - 2010-07-05 12:45:25 --> Session routines successfully run
DEBUG - 2010-07-05 12:45:25 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:45:25 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:45:25 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:45:25 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:45:26 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:45:26 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 12:45:26 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:45:26 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:45:26 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 12:45:26 --> Final output sent to browser
DEBUG - 2010-07-05 12:45:27 --> Total execution time: 6.7644
DEBUG - 2010-07-05 12:47:02 --> Config Class Initialized
DEBUG - 2010-07-05 12:47:02 --> Hooks Class Initialized
DEBUG - 2010-07-05 12:47:02 --> URI Class Initialized
DEBUG - 2010-07-05 12:47:03 --> Router Class Initialized
DEBUG - 2010-07-05 12:47:03 --> Output Class Initialized
DEBUG - 2010-07-05 12:47:03 --> Input Class Initialized
DEBUG - 2010-07-05 12:47:03 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 12:47:03 --> Language Class Initialized
DEBUG - 2010-07-05 12:47:03 --> Loader Class Initialized
DEBUG - 2010-07-05 12:47:04 --> Helper loaded: context_helper
DEBUG - 2010-07-05 12:47:04 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 12:47:04 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 12:47:04 --> Database Driver Class Initialized
DEBUG - 2010-07-05 12:47:04 --> Controller Class Initialized
DEBUG - 2010-07-05 12:47:05 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 12:47:05 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 12:47:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:47:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:47:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:47:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:47:06 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:47:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:47:06 --> Helper loaded: email_helper
DEBUG - 2010-07-05 12:47:06 --> User Agent Class Initialized
DEBUG - 2010-07-05 12:47:06 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:47:06 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:47:07 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:47:07 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 12:47:07 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:47:07 --> Session Class Initialized
DEBUG - 2010-07-05 12:47:07 --> Helper loaded: string_helper
DEBUG - 2010-07-05 12:47:07 --> Session routines successfully run
DEBUG - 2010-07-05 12:47:08 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:47:08 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:47:08 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:47:08 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:47:08 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:47:08 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 12:47:09 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:47:09 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:47:09 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 12:47:09 --> Final output sent to browser
DEBUG - 2010-07-05 12:47:09 --> Total execution time: 7.0138
DEBUG - 2010-07-05 12:47:53 --> Config Class Initialized
DEBUG - 2010-07-05 12:47:53 --> Hooks Class Initialized
DEBUG - 2010-07-05 12:47:54 --> URI Class Initialized
DEBUG - 2010-07-05 12:47:54 --> Router Class Initialized
DEBUG - 2010-07-05 12:47:54 --> Output Class Initialized
DEBUG - 2010-07-05 12:47:54 --> Input Class Initialized
DEBUG - 2010-07-05 12:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 12:47:54 --> Language Class Initialized
DEBUG - 2010-07-05 12:47:55 --> Loader Class Initialized
DEBUG - 2010-07-05 12:47:55 --> Helper loaded: context_helper
DEBUG - 2010-07-05 12:47:55 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 12:47:55 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 12:47:55 --> Database Driver Class Initialized
DEBUG - 2010-07-05 12:47:56 --> Controller Class Initialized
DEBUG - 2010-07-05 12:47:56 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 12:47:56 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 12:47:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:47:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:47:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:47:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:47:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:47:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:47:57 --> Helper loaded: email_helper
DEBUG - 2010-07-05 12:47:57 --> User Agent Class Initialized
DEBUG - 2010-07-05 12:47:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:47:58 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:47:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:47:58 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 12:47:58 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:47:58 --> Session Class Initialized
DEBUG - 2010-07-05 12:47:59 --> Helper loaded: string_helper
DEBUG - 2010-07-05 12:47:59 --> Session routines successfully run
DEBUG - 2010-07-05 12:47:59 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:47:59 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:47:59 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:47:59 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:00 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:00 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 12:48:00 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:00 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:00 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 12:48:00 --> Final output sent to browser
DEBUG - 2010-07-05 12:48:01 --> Total execution time: 7.0870
DEBUG - 2010-07-05 12:48:26 --> Config Class Initialized
DEBUG - 2010-07-05 12:48:26 --> Hooks Class Initialized
DEBUG - 2010-07-05 12:48:26 --> URI Class Initialized
DEBUG - 2010-07-05 12:48:26 --> Router Class Initialized
DEBUG - 2010-07-05 12:48:26 --> Output Class Initialized
DEBUG - 2010-07-05 12:48:26 --> Input Class Initialized
DEBUG - 2010-07-05 12:48:27 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 12:48:27 --> Language Class Initialized
DEBUG - 2010-07-05 12:48:27 --> Loader Class Initialized
DEBUG - 2010-07-05 12:48:27 --> Helper loaded: context_helper
DEBUG - 2010-07-05 12:48:27 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 12:48:27 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 12:48:28 --> Database Driver Class Initialized
DEBUG - 2010-07-05 12:48:28 --> Controller Class Initialized
DEBUG - 2010-07-05 12:48:28 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 12:48:28 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 12:48:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:29 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:29 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:29 --> Helper loaded: email_helper
DEBUG - 2010-07-05 12:48:30 --> User Agent Class Initialized
DEBUG - 2010-07-05 12:48:30 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:30 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:30 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:30 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 12:48:30 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:31 --> Session Class Initialized
DEBUG - 2010-07-05 12:48:31 --> Helper loaded: string_helper
DEBUG - 2010-07-05 12:48:31 --> Session routines successfully run
DEBUG - 2010-07-05 12:48:31 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:31 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:31 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:32 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:32 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:32 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 12:48:32 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:32 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:32 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 12:48:33 --> Final output sent to browser
DEBUG - 2010-07-05 12:48:33 --> Total execution time: 6.9332
DEBUG - 2010-07-05 12:48:44 --> Config Class Initialized
DEBUG - 2010-07-05 12:48:44 --> Hooks Class Initialized
DEBUG - 2010-07-05 12:48:44 --> URI Class Initialized
DEBUG - 2010-07-05 12:48:44 --> Router Class Initialized
DEBUG - 2010-07-05 12:48:45 --> Output Class Initialized
DEBUG - 2010-07-05 12:48:45 --> Input Class Initialized
DEBUG - 2010-07-05 12:48:45 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 12:48:45 --> Language Class Initialized
DEBUG - 2010-07-05 12:48:45 --> Loader Class Initialized
DEBUG - 2010-07-05 12:48:46 --> Helper loaded: context_helper
DEBUG - 2010-07-05 12:48:46 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 12:48:46 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 12:48:46 --> Database Driver Class Initialized
DEBUG - 2010-07-05 12:48:46 --> Controller Class Initialized
DEBUG - 2010-07-05 12:48:46 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 12:48:47 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 12:48:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:47 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:48 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:48 --> Helper loaded: email_helper
DEBUG - 2010-07-05 12:48:48 --> User Agent Class Initialized
DEBUG - 2010-07-05 12:48:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:48 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:49 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:49 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 12:48:49 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:49 --> Session Class Initialized
DEBUG - 2010-07-05 12:48:49 --> Helper loaded: string_helper
DEBUG - 2010-07-05 12:48:49 --> Session routines successfully run
DEBUG - 2010-07-05 12:48:50 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:50 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:50 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:50 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:50 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:51 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 12:48:51 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:51 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:48:51 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 12:48:51 --> Final output sent to browser
DEBUG - 2010-07-05 12:48:51 --> Total execution time: 7.2908
DEBUG - 2010-07-05 12:50:22 --> Config Class Initialized
DEBUG - 2010-07-05 12:50:22 --> Hooks Class Initialized
DEBUG - 2010-07-05 12:50:22 --> URI Class Initialized
DEBUG - 2010-07-05 12:50:22 --> Router Class Initialized
DEBUG - 2010-07-05 12:50:23 --> Output Class Initialized
DEBUG - 2010-07-05 12:50:23 --> Input Class Initialized
DEBUG - 2010-07-05 12:50:23 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 12:50:23 --> Language Class Initialized
DEBUG - 2010-07-05 12:50:23 --> Loader Class Initialized
DEBUG - 2010-07-05 12:50:23 --> Helper loaded: context_helper
DEBUG - 2010-07-05 12:50:24 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 12:50:24 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 12:50:24 --> Database Driver Class Initialized
DEBUG - 2010-07-05 12:50:24 --> Controller Class Initialized
DEBUG - 2010-07-05 12:50:24 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 12:50:25 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 12:50:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:26 --> Helper loaded: email_helper
DEBUG - 2010-07-05 12:50:26 --> User Agent Class Initialized
DEBUG - 2010-07-05 12:50:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:26 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:26 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:27 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 12:50:27 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:27 --> Session Class Initialized
DEBUG - 2010-07-05 12:50:27 --> Helper loaded: string_helper
DEBUG - 2010-07-05 12:50:27 --> Session routines successfully run
DEBUG - 2010-07-05 12:50:27 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:28 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:28 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:28 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:28 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:28 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-07-05 12:50:29 --> Severity: Notice  --> Undefined variable: sort_array D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Annotation_scope_collection.php 171
DEBUG - 2010-07-05 12:50:29 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:29 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:29 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:29 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:30 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:30 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:30 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:30 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:30 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:30 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 12:50:31 --> Severity: Notice  --> Undefined variable: sort_array D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Annotation_scope_collection.php 171
DEBUG - 2010-07-05 12:50:31 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:31 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:31 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:31 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:31 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:32 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:32 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:32 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:32 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 12:50:32 --> Final output sent to browser
DEBUG - 2010-07-05 12:50:33 --> Total execution time: 10.7290
DEBUG - 2010-07-05 12:50:53 --> Config Class Initialized
DEBUG - 2010-07-05 12:50:53 --> Hooks Class Initialized
DEBUG - 2010-07-05 12:50:54 --> URI Class Initialized
DEBUG - 2010-07-05 12:50:54 --> Router Class Initialized
DEBUG - 2010-07-05 12:50:54 --> Output Class Initialized
DEBUG - 2010-07-05 12:50:54 --> Input Class Initialized
DEBUG - 2010-07-05 12:50:54 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 12:50:55 --> Language Class Initialized
DEBUG - 2010-07-05 12:50:55 --> Loader Class Initialized
DEBUG - 2010-07-05 12:50:55 --> Helper loaded: context_helper
DEBUG - 2010-07-05 12:50:55 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 12:50:55 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 12:50:55 --> Database Driver Class Initialized
DEBUG - 2010-07-05 12:50:56 --> Controller Class Initialized
DEBUG - 2010-07-05 12:50:56 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 12:50:56 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 12:50:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:57 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:57 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:57 --> Helper loaded: email_helper
DEBUG - 2010-07-05 12:50:57 --> User Agent Class Initialized
DEBUG - 2010-07-05 12:50:57 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:58 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:58 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:58 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 12:50:58 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:58 --> Session Class Initialized
DEBUG - 2010-07-05 12:50:59 --> Helper loaded: string_helper
DEBUG - 2010-07-05 12:50:59 --> Session routines successfully run
DEBUG - 2010-07-05 12:50:59 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:59 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:59 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:50:59 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:51:00 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:51:00 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 12:51:00 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:51:00 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:51:00 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:51:01 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:51:01 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:51:01 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:51:01 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:51:01 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:51:01 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:51:02 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:51:02 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:51:02 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:51:02 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:51:02 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:51:02 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:51:03 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:51:03 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:51:03 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:51:03 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 12:51:03 --> Final output sent to browser
DEBUG - 2010-07-05 12:51:03 --> Total execution time: 9.9648
DEBUG - 2010-07-05 12:54:46 --> Config Class Initialized
DEBUG - 2010-07-05 12:54:46 --> Hooks Class Initialized
DEBUG - 2010-07-05 12:54:46 --> URI Class Initialized
DEBUG - 2010-07-05 12:54:46 --> Router Class Initialized
DEBUG - 2010-07-05 12:54:46 --> Output Class Initialized
DEBUG - 2010-07-05 12:54:47 --> Input Class Initialized
DEBUG - 2010-07-05 12:54:47 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 12:54:47 --> Language Class Initialized
DEBUG - 2010-07-05 12:54:47 --> Loader Class Initialized
DEBUG - 2010-07-05 12:54:47 --> Helper loaded: context_helper
DEBUG - 2010-07-05 12:54:48 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 12:54:48 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 12:54:48 --> Database Driver Class Initialized
DEBUG - 2010-07-05 12:54:48 --> Controller Class Initialized
DEBUG - 2010-07-05 12:54:48 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 12:54:48 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 12:54:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:54:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:54:49 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:54:49 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:54:49 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:54:49 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:54:50 --> Helper loaded: email_helper
DEBUG - 2010-07-05 12:54:50 --> User Agent Class Initialized
DEBUG - 2010-07-05 12:54:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:54:50 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:54:50 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:54:50 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 12:54:51 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:54:51 --> Session Class Initialized
DEBUG - 2010-07-05 12:54:51 --> Helper loaded: string_helper
DEBUG - 2010-07-05 12:54:51 --> Session routines successfully run
DEBUG - 2010-07-05 12:54:51 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:54:52 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:54:52 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:54:52 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:54:52 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:54:52 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 12:54:52 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:54:53 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:54:53 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 12:54:53 --> Final output sent to browser
DEBUG - 2010-07-05 12:54:53 --> Total execution time: 7.1576
DEBUG - 2010-07-05 12:57:42 --> Config Class Initialized
DEBUG - 2010-07-05 12:57:42 --> Hooks Class Initialized
DEBUG - 2010-07-05 12:57:42 --> URI Class Initialized
DEBUG - 2010-07-05 12:57:42 --> Router Class Initialized
DEBUG - 2010-07-05 12:57:43 --> Output Class Initialized
DEBUG - 2010-07-05 12:57:43 --> Input Class Initialized
DEBUG - 2010-07-05 12:57:43 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 12:57:43 --> Language Class Initialized
DEBUG - 2010-07-05 12:57:43 --> Loader Class Initialized
DEBUG - 2010-07-05 12:57:43 --> Helper loaded: context_helper
DEBUG - 2010-07-05 12:57:44 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 12:57:44 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 12:57:44 --> Database Driver Class Initialized
DEBUG - 2010-07-05 12:57:44 --> Controller Class Initialized
DEBUG - 2010-07-05 12:57:44 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 12:57:45 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 12:57:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:57:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:57:45 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:57:45 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:57:46 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:57:46 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:57:46 --> Helper loaded: email_helper
DEBUG - 2010-07-05 12:57:46 --> User Agent Class Initialized
DEBUG - 2010-07-05 12:57:46 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:57:46 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:57:47 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:57:47 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 12:57:47 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:57:47 --> Session Class Initialized
DEBUG - 2010-07-05 12:57:47 --> Helper loaded: string_helper
DEBUG - 2010-07-05 12:57:48 --> Session routines successfully run
DEBUG - 2010-07-05 12:57:48 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:57:48 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:57:48 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:57:48 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:57:48 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:57:49 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 12:57:49 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:57:49 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 12:57:49 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 12:57:49 --> Final output sent to browser
DEBUG - 2010-07-05 12:57:50 --> Total execution time: 7.5920
DEBUG - 2010-07-05 13:00:14 --> Config Class Initialized
DEBUG - 2010-07-05 13:00:14 --> Hooks Class Initialized
DEBUG - 2010-07-05 13:00:14 --> URI Class Initialized
DEBUG - 2010-07-05 13:00:14 --> Router Class Initialized
DEBUG - 2010-07-05 13:00:14 --> Output Class Initialized
DEBUG - 2010-07-05 13:00:15 --> Input Class Initialized
DEBUG - 2010-07-05 13:00:15 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 13:00:15 --> Language Class Initialized
DEBUG - 2010-07-05 13:00:15 --> Loader Class Initialized
DEBUG - 2010-07-05 13:00:15 --> Helper loaded: context_helper
DEBUG - 2010-07-05 13:00:15 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 13:00:16 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 13:00:16 --> Database Driver Class Initialized
DEBUG - 2010-07-05 13:00:16 --> Controller Class Initialized
DEBUG - 2010-07-05 13:00:16 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 13:00:16 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 13:00:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:17 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:17 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:18 --> Helper loaded: email_helper
DEBUG - 2010-07-05 13:00:18 --> User Agent Class Initialized
DEBUG - 2010-07-05 13:00:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:18 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:18 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:19 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 13:00:19 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:19 --> Session Class Initialized
DEBUG - 2010-07-05 13:00:19 --> Helper loaded: string_helper
DEBUG - 2010-07-05 13:00:19 --> Session routines successfully run
DEBUG - 2010-07-05 13:00:20 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:20 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:20 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:20 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:20 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:20 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-07-05 13:00:21 --> Severity: Notice  --> Undefined offset:  2 D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Annotation_scope_collection.php 184
DEBUG - 2010-07-05 13:00:39 --> Config Class Initialized
DEBUG - 2010-07-05 13:00:39 --> Hooks Class Initialized
DEBUG - 2010-07-05 13:00:39 --> URI Class Initialized
DEBUG - 2010-07-05 13:00:39 --> Router Class Initialized
DEBUG - 2010-07-05 13:00:40 --> Output Class Initialized
DEBUG - 2010-07-05 13:00:40 --> Input Class Initialized
DEBUG - 2010-07-05 13:00:40 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 13:00:40 --> Language Class Initialized
DEBUG - 2010-07-05 13:00:40 --> Loader Class Initialized
DEBUG - 2010-07-05 13:00:40 --> Helper loaded: context_helper
DEBUG - 2010-07-05 13:00:41 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 13:00:41 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 13:00:41 --> Database Driver Class Initialized
DEBUG - 2010-07-05 13:00:41 --> Controller Class Initialized
DEBUG - 2010-07-05 13:00:41 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 13:00:42 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 13:00:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:42 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:43 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:43 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:43 --> Helper loaded: email_helper
DEBUG - 2010-07-05 13:00:43 --> User Agent Class Initialized
DEBUG - 2010-07-05 13:00:43 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:43 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:44 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:44 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 13:00:44 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:44 --> Session Class Initialized
DEBUG - 2010-07-05 13:00:44 --> Helper loaded: string_helper
DEBUG - 2010-07-05 13:00:44 --> Session routines successfully run
DEBUG - 2010-07-05 13:00:45 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:45 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:45 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:45 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:45 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:46 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 13:00:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:46 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:46 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:46 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:47 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:47 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:47 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:47 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:47 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:00:48 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 13:00:48 --> Final output sent to browser
DEBUG - 2010-07-05 13:00:48 --> Total execution time: 9.0231
DEBUG - 2010-07-05 13:01:19 --> Config Class Initialized
DEBUG - 2010-07-05 13:01:19 --> Hooks Class Initialized
DEBUG - 2010-07-05 13:01:20 --> URI Class Initialized
DEBUG - 2010-07-05 13:01:20 --> Router Class Initialized
DEBUG - 2010-07-05 13:01:20 --> Output Class Initialized
DEBUG - 2010-07-05 13:01:20 --> Input Class Initialized
DEBUG - 2010-07-05 13:01:20 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 13:01:20 --> Language Class Initialized
DEBUG - 2010-07-05 13:01:21 --> Loader Class Initialized
DEBUG - 2010-07-05 13:01:21 --> Helper loaded: context_helper
DEBUG - 2010-07-05 13:01:21 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 13:01:21 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 13:01:21 --> Database Driver Class Initialized
DEBUG - 2010-07-05 13:01:22 --> Controller Class Initialized
DEBUG - 2010-07-05 13:01:22 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 13:01:22 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 13:01:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:01:22 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:01:22 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:01:23 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:01:23 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:01:23 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:01:23 --> Helper loaded: email_helper
DEBUG - 2010-07-05 13:01:23 --> User Agent Class Initialized
DEBUG - 2010-07-05 13:01:24 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:01:24 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:01:24 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:01:24 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 13:01:24 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:01:24 --> Session Class Initialized
DEBUG - 2010-07-05 13:01:25 --> Helper loaded: string_helper
DEBUG - 2010-07-05 13:01:25 --> Session routines successfully run
DEBUG - 2010-07-05 13:01:25 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:01:25 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:01:25 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:01:25 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:01:26 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:01:26 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 13:01:26 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:01:26 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:01:26 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:01:27 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:01:27 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:01:27 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:01:27 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:01:27 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:01:27 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:01:28 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:01:28 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 13:01:28 --> Final output sent to browser
DEBUG - 2010-07-05 13:01:28 --> Total execution time: 8.7760
DEBUG - 2010-07-05 13:07:49 --> Config Class Initialized
DEBUG - 2010-07-05 13:07:49 --> Hooks Class Initialized
DEBUG - 2010-07-05 13:07:49 --> URI Class Initialized
DEBUG - 2010-07-05 13:07:49 --> Router Class Initialized
DEBUG - 2010-07-05 13:07:49 --> Output Class Initialized
DEBUG - 2010-07-05 13:07:49 --> Input Class Initialized
DEBUG - 2010-07-05 13:07:50 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 13:07:50 --> Language Class Initialized
DEBUG - 2010-07-05 13:07:50 --> Loader Class Initialized
DEBUG - 2010-07-05 13:07:50 --> Helper loaded: context_helper
DEBUG - 2010-07-05 13:07:51 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 13:07:51 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 13:07:51 --> Database Driver Class Initialized
DEBUG - 2010-07-05 13:07:51 --> Controller Class Initialized
DEBUG - 2010-07-05 13:07:51 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 13:07:52 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 13:07:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:07:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:07:52 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:07:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:07:53 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:07:53 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:07:53 --> Helper loaded: email_helper
DEBUG - 2010-07-05 13:07:53 --> User Agent Class Initialized
DEBUG - 2010-07-05 13:07:53 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:07:54 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:07:54 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:07:54 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 13:07:54 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:07:54 --> Session Class Initialized
DEBUG - 2010-07-05 13:07:55 --> Helper loaded: string_helper
DEBUG - 2010-07-05 13:07:55 --> Session routines successfully run
DEBUG - 2010-07-05 13:07:55 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:07:55 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:07:55 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:07:55 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:07:56 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:07:56 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 13:07:56 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:07:56 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:07:56 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:07:56 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:07:57 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:07:57 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:07:57 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:07:57 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:07:57 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:07:58 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:07:58 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:07:58 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:07:58 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:07:58 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:07:58 --> Segmentor_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:07:59 --> Segmentor_CKIP class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:07:59 --> Segmentor class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:07:59 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:07:59 --> Scope_anchor_text class already loaded. Second attempt ignored.
ERROR - 2010-07-05 13:07:59 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  operator does not exist: text = integer
LINE 3: WHERE &quot;text&quot; = 0
                     ^
HINT:  No operator matches the given name and argument type(s). You might need to add explicit type casts. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2010-07-05 13:08:00 --> DB Transaction Failure
ERROR - 2010-07-05 13:08:00 --> Query error: ERROR:  operator does not exist: text = integer
LINE 3: WHERE "text" = 0
                     ^
HINT:  No operator matches the given name and argument type(s). You might need to add explicit type casts.
DEBUG - 2010-07-05 13:08:00 --> Language file loaded: language/zh_tw/db_lang.php
ERROR - 2010-07-05 13:08:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\helpers\kals_helper.php:383) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-05 13:09:28 --> Config Class Initialized
DEBUG - 2010-07-05 13:09:28 --> Hooks Class Initialized
DEBUG - 2010-07-05 13:09:29 --> URI Class Initialized
DEBUG - 2010-07-05 13:09:29 --> Router Class Initialized
DEBUG - 2010-07-05 13:09:29 --> Output Class Initialized
DEBUG - 2010-07-05 13:09:29 --> Input Class Initialized
DEBUG - 2010-07-05 13:09:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 13:09:29 --> Language Class Initialized
DEBUG - 2010-07-05 13:09:30 --> Loader Class Initialized
DEBUG - 2010-07-05 13:09:30 --> Helper loaded: context_helper
DEBUG - 2010-07-05 13:09:30 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 13:09:30 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 13:09:30 --> Database Driver Class Initialized
DEBUG - 2010-07-05 13:09:31 --> Controller Class Initialized
DEBUG - 2010-07-05 13:09:31 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 13:09:31 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 13:09:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:09:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:09:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:09:32 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:09:32 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:09:32 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:09:32 --> Helper loaded: email_helper
DEBUG - 2010-07-05 13:09:32 --> User Agent Class Initialized
DEBUG - 2010-07-05 13:09:33 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:09:33 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:09:33 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:09:33 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 13:09:33 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:09:34 --> Session Class Initialized
DEBUG - 2010-07-05 13:09:34 --> Helper loaded: string_helper
DEBUG - 2010-07-05 13:09:34 --> Session routines successfully run
DEBUG - 2010-07-05 13:09:34 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:09:34 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:09:35 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:09:35 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:09:35 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:09:35 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 13:09:35 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:09:36 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:09:36 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:09:36 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:17:07 --> Config Class Initialized
DEBUG - 2010-07-05 13:17:07 --> Hooks Class Initialized
DEBUG - 2010-07-05 13:17:07 --> URI Class Initialized
DEBUG - 2010-07-05 13:17:07 --> Router Class Initialized
DEBUG - 2010-07-05 13:17:08 --> Output Class Initialized
DEBUG - 2010-07-05 13:17:08 --> Input Class Initialized
DEBUG - 2010-07-05 13:17:08 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 13:17:08 --> Language Class Initialized
DEBUG - 2010-07-05 13:17:08 --> Loader Class Initialized
DEBUG - 2010-07-05 13:17:08 --> Helper loaded: context_helper
DEBUG - 2010-07-05 13:17:09 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 13:17:09 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 13:17:09 --> Database Driver Class Initialized
DEBUG - 2010-07-05 13:17:09 --> Controller Class Initialized
DEBUG - 2010-07-05 13:17:09 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 13:17:10 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 13:17:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:17:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:17:10 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:17:10 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:17:11 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:17:11 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:17:11 --> Helper loaded: email_helper
DEBUG - 2010-07-05 13:17:11 --> User Agent Class Initialized
DEBUG - 2010-07-05 13:17:11 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:17:11 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:17:12 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:17:12 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 13:17:12 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:17:12 --> Session Class Initialized
DEBUG - 2010-07-05 13:17:12 --> Helper loaded: string_helper
DEBUG - 2010-07-05 13:17:13 --> Session routines successfully run
DEBUG - 2010-07-05 13:17:13 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:17:13 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:17:13 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:17:13 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:17:14 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:17:14 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 13:17:14 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:17:14 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:17:15 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:17:15 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:17:15 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:17:15 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:17:15 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:17:15 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:17:16 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:17:16 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:17:16 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:17:16 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:17:16 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:17:17 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:17:17 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:17:17 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:17:17 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 13:17:17 --> Final output sent to browser
DEBUG - 2010-07-05 13:17:18 --> Total execution time: 10.5740
DEBUG - 2010-07-05 13:18:09 --> Config Class Initialized
DEBUG - 2010-07-05 13:18:09 --> Hooks Class Initialized
DEBUG - 2010-07-05 13:18:10 --> URI Class Initialized
DEBUG - 2010-07-05 13:18:10 --> Router Class Initialized
DEBUG - 2010-07-05 13:18:10 --> Output Class Initialized
DEBUG - 2010-07-05 13:18:10 --> Input Class Initialized
DEBUG - 2010-07-05 13:18:10 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 13:18:10 --> Language Class Initialized
DEBUG - 2010-07-05 13:18:11 --> Loader Class Initialized
DEBUG - 2010-07-05 13:18:11 --> Helper loaded: context_helper
DEBUG - 2010-07-05 13:18:11 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 13:18:11 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 13:18:11 --> Database Driver Class Initialized
DEBUG - 2010-07-05 13:18:12 --> Controller Class Initialized
DEBUG - 2010-07-05 13:18:12 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 13:18:12 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 13:18:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:18:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:18:13 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:18:13 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:18:13 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:18:13 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:18:13 --> Helper loaded: email_helper
DEBUG - 2010-07-05 13:18:13 --> User Agent Class Initialized
DEBUG - 2010-07-05 13:18:14 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:18:14 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:18:14 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:18:14 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 13:18:14 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:18:15 --> Session Class Initialized
DEBUG - 2010-07-05 13:18:15 --> Helper loaded: string_helper
DEBUG - 2010-07-05 13:18:15 --> Session routines successfully run
DEBUG - 2010-07-05 13:18:15 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:18:15 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:18:15 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:18:16 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:18:16 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:18:16 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 13:18:16 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:18:16 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:18:17 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:18:17 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:18:17 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:18:17 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:18:17 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:18:18 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:18:18 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:18:18 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:18:18 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:18:18 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:18:18 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:18:19 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:18:19 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:18:19 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:18:19 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 13:18:19 --> Final output sent to browser
DEBUG - 2010-07-05 13:18:20 --> Total execution time: 10.1742
DEBUG - 2010-07-05 13:19:38 --> Config Class Initialized
DEBUG - 2010-07-05 13:19:39 --> Hooks Class Initialized
DEBUG - 2010-07-05 13:19:39 --> URI Class Initialized
DEBUG - 2010-07-05 13:19:39 --> Router Class Initialized
DEBUG - 2010-07-05 13:19:39 --> Output Class Initialized
DEBUG - 2010-07-05 13:19:39 --> Input Class Initialized
DEBUG - 2010-07-05 13:19:40 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-05 13:19:40 --> Language Class Initialized
DEBUG - 2010-07-05 13:19:40 --> Loader Class Initialized
DEBUG - 2010-07-05 13:19:40 --> Helper loaded: context_helper
DEBUG - 2010-07-05 13:19:40 --> Helper loaded: kals_helper
DEBUG - 2010-07-05 13:19:40 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-05 13:19:41 --> Database Driver Class Initialized
DEBUG - 2010-07-05 13:19:41 --> Controller Class Initialized
DEBUG - 2010-07-05 13:19:41 --> Unit Testing Class Initialized
DEBUG - 2010-07-05 13:19:41 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-05 13:19:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:19:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:19:42 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:19:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:19:42 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:19:42 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:19:43 --> Helper loaded: email_helper
DEBUG - 2010-07-05 13:19:43 --> User Agent Class Initialized
DEBUG - 2010-07-05 13:19:43 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:19:43 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:19:43 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:19:43 --> Config file loaded: config/kals.php
DEBUG - 2010-07-05 13:19:44 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:19:44 --> Session Class Initialized
DEBUG - 2010-07-05 13:19:44 --> Helper loaded: string_helper
DEBUG - 2010-07-05 13:19:44 --> Session routines successfully run
DEBUG - 2010-07-05 13:19:44 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:19:45 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:19:45 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:19:45 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:19:45 --> Annotation_scope class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:19:45 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-05 13:19:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:19:46 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:19:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:19:46 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:19:46 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:19:46 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:19:47 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:19:47 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:19:47 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:19:47 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:19:47 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:19:48 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:19:48 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:19:48 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:19:48 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:19:49 --> Scope_anchor_text class already loaded. Second attempt ignored.
DEBUG - 2010-07-05 13:19:49 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-05 13:19:49 --> Final output sent to browser
DEBUG - 2010-07-05 13:19:49 --> Total execution time: 10.4928
