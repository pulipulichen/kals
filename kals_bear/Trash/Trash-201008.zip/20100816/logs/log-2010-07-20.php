<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-07-20 04:50:33 --> Severity: Warning  --> Missing argument 2 for CI_DB_active_record::join(), called in D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\search\Search_engine.php on line 423 and defined D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\DB_active_rec.php 321
ERROR - 2010-07-20 04:50:33 --> Severity: Notice  --> Undefined variable: cond D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\DB_active_rec.php 342
ERROR - 2010-07-20 04:50:33 --> Severity: Notice  --> Undefined variable: cond D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\DB_active_rec.php 351
ERROR - 2010-07-20 04:50:33 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;WHERE&quot;
LINE 6: WHERE &quot;annotation&quot;.&quot;deleted&quot; = 'FALSE'
        ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-20 04:50:33 --> Query error: ERROR:  syntax error at or near "WHERE"
LINE 6: WHERE "annotation"."deleted" = 'FALSE'
        ^
ERROR - 2010-07-20 04:50:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\libraries\Exceptions.php:166) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
ERROR - 2010-07-20 04:51:22 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;WHERE&quot;
LINE 6: WHERE &quot;annotation&quot;.&quot;deleted&quot; = 'FALSE'
        ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-20 04:51:22 --> Query error: ERROR:  syntax error at or near "WHERE"
LINE 6: WHERE "annotation"."deleted" = 'FALSE'
        ^
ERROR - 2010-07-20 04:52:07 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;WHERE&quot;
LINE 6: WHERE &quot;annotation&quot;.&quot;deleted&quot; = 'FALSE'
        ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-20 04:52:07 --> Query error: ERROR:  syntax error at or near "WHERE"
LINE 6: WHERE "annotation"."deleted" = 'FALSE'
        ^
ERROR - 2010-07-20 04:53:17 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;search_note_query&quot; does not exist
LINE 7: AND annotation.note_index @@ search_note_query
                                     ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-20 04:53:17 --> Query error: ERROR:  column "search_note_query" does not exist
LINE 7: AND annotation.note_index @@ search_note_query
                                     ^
ERROR - 2010-07-20 04:58:05 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid reference to FROM-clause entry for table &quot;annotation&quot;
LINE 3: LEFT JOIN &quot;policy&quot; ON &quot;policy&quot;.&quot;resource_id&quot; = &quot;annotation&quot;....
                                                       ^
HINT:  There is an entry for table &quot;annotation&quot;, but it cannot be referenced from this part of the query. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-20 04:58:05 --> Query error: ERROR:  invalid reference to FROM-clause entry for table "annotation"
LINE 3: LEFT JOIN "policy" ON "policy"."resource_id" = "annotation"....
                                                       ^
HINT:  There is an entry for table "annotation", but it cannot be referenced from this part of the query.
ERROR - 2010-07-20 05:02:54 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  invalid reference to FROM-clause entry for table &quot;annotation&quot;
LINE 3: LEFT JOIN &quot;policy&quot; ON &quot;policy&quot;.&quot;resource_id&quot; = &quot;annotation&quot;....
                                                       ^
HINT:  There is an entry for table &quot;annotation&quot;, but it cannot be referenced from this part of the query. D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-20 05:02:54 --> Query error: ERROR:  invalid reference to FROM-clause entry for table "annotation"
LINE 3: LEFT JOIN "policy" ON "policy"."resource_id" = "annotation"....
                                                       ^
HINT:  There is an entry for table "annotation", but it cannot be referenced from this part of the query.
ERROR - 2010-07-20 05:04:03 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;desc&quot;
LINE 8: ...ank_cd(annotation.note_index, &quot;search_note_query&quot;, &quot;1)&quot; desc
                                                                   ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-20 05:04:03 --> Query error: ERROR:  syntax error at or near "desc"
LINE 8: ...ank_cd(annotation.note_index, "search_note_query", "1)" desc
                                                                   ^
ERROR - 2010-07-20 05:05:52 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;AS&quot;
LINE 1: ...(annotation.note_index, &quot;search_note_query&quot;, &quot;1)&quot; AS search_...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-20 05:05:52 --> Query error: ERROR:  syntax error at or near "AS"
LINE 1: ...(annotation.note_index, "search_note_query", "1)" AS search_...
                                                             ^
ERROR - 2010-07-20 05:06:12 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;AS&quot;
LINE 1: ...nk_cd(annotation.note_index, &quot;search_note_query)&quot; AS search_...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-20 05:06:12 --> Query error: ERROR:  syntax error at or near "AS"
LINE 1: ...nk_cd(annotation.note_index, "search_note_query)" AS search_...
                                                             ^
ERROR - 2010-07-20 05:06:27 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  syntax error at or near &quot;annotation&quot;
LINE 1: ...ndex, &quot;search_note_query&quot;)&quot; AS search_note_rank, &quot;annotation...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-20 05:06:27 --> Query error: ERROR:  syntax error at or near "annotation"
LINE 1: ...ndex, "search_note_query")" AS search_note_rank, "annotation...
                                                             ^
ERROR - 2010-07-20 05:07:04 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;search_anchor_text_query&quot; does not exist
LINE 5: ...n.annotation_id AND search_anchor_text.indexed @@ search_anc...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-20 05:07:04 --> Query error: ERROR:  column "search_anchor_text_query" does not exist
LINE 5: ...n.annotation_id AND search_anchor_text.indexed @@ search_anc...
                                                             ^
ERROR - 2010-07-20 05:07:47 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column &quot;search_anchor_text_query&quot; does not exist
LINE 5: ...n.annotation_id AND search_anchor_text.indexed @@ search_anc...
                                                             ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-20 05:07:47 --> Query error: ERROR:  column "search_anchor_text_query" does not exist
LINE 5: ...n.annotation_id AND search_anchor_text.indexed @@ search_anc...
                                                             ^
ERROR - 2010-07-20 05:11:16 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column notation .user_id applied to type name, which is not a composite type
LINE 6: JOIN user AS select_user ON annotation.user_id = select_user...
                                                         ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-20 05:11:16 --> Query error: ERROR:  column notation .user_id applied to type name, which is not a composite type
LINE 6: JOIN user AS select_user ON annotation.user_id = select_user...
                                                         ^
ERROR - 2010-07-20 05:15:24 --> Severity: Warning  --> pg_query() [<a href='function.pg-query'>function.pg-query</a>]: Query failed: ERROR:  column notation .user_id applied to type name, which is not a composite type
LINE 6: JOIN user AS select_user ON annotation.user_id = select_user...
                                                         ^ D:\xampp\htdocs\CodeIgniter_1.7.2\system\database\drivers\postgre\postgre_driver.php 177
ERROR - 2010-07-20 05:15:24 --> Query error: ERROR:  column notation .user_id applied to type name, which is not a composite type
LINE 6: JOIN user AS select_user ON annotation.user_id = select_user...
                                                         ^
ERROR - 2010-07-20 05:27:16 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-20 05:27:17 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an illegal character in input string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\scope\Segmentor_CKIP.php 125
ERROR - 2010-07-20 07:09:51 --> 404 Page Not Found --> Module_B:_some_other_test
ERROR - 2010-07-20 07:37:05 --> 404 Page Not Found --> utjs/index
ERROR - 2010-07-20 07:56:32 --> 404 Page Not Found --> xxs_getter.js
ERROR - 2010-07-20 07:57:31 --> 404 Page Not Found --> xxs_getter.js
ERROR - 2010-07-20 07:57:49 --> 404 Page Not Found --> xxs_getter.js
ERROR - 2010-07-20 08:04:57 --> Severity: Warning  --> Missing argument 1 for qunit_feed::index() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\qunit_feed.php 22
ERROR - 2010-07-20 08:04:57 --> Severity: Notice  --> Undefined variable: callback D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\qunit_feed.php 24
ERROR - 2010-07-20 08:05:07 --> 404 Page Not Found --> qunit_feed/aas
ERROR - 2010-07-20 08:05:36 --> Severity: Warning  --> Missing argument 1 for qunit_feed::index() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\qunit_feed.php 22
ERROR - 2010-07-20 08:05:36 --> Severity: Notice  --> Undefined variable: callback D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\qunit_feed.php 24
ERROR - 2010-07-20 08:06:39 --> Severity: Warning  --> Missing argument 1 for qunit_feed::index() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\qunit_feed.php 22
ERROR - 2010-07-20 08:06:39 --> Severity: Notice  --> Undefined variable: callback D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\qunit_feed.php 24
ERROR - 2010-07-20 08:06:46 --> Severity: Warning  --> Missing argument 1 for qunit_feed::index() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\qunit_feed.php 22
ERROR - 2010-07-20 08:06:46 --> Severity: Notice  --> Undefined variable: callback D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\qunit_feed.php 24
ERROR - 2010-07-20 08:38:40 --> Severity: Warning  --> Missing argument 1 for qunit_feed::index() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\qunit_feed.php 22
ERROR - 2010-07-20 08:38:40 --> Severity: Notice  --> Undefined variable: callback D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\qunit_feed.php 26
ERROR - 2010-07-20 08:44:01 --> 404 Page Not Found --> callback
ERROR - 2010-07-20 08:44:04 --> 404 Page Not Found --> callback
ERROR - 2010-07-20 08:51:26 --> 404 Page Not Found --> callback
ERROR - 2010-07-20 08:51:58 --> Severity: Warning  --> Missing argument 1 for qunit_feed::index() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\qunit_feed.php 22
ERROR - 2010-07-20 08:51:58 --> Severity: Notice  --> Undefined index:  callback D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\qunit_feed.php 26
ERROR - 2010-07-20 08:52:10 --> 404 Page Not Found --> callback
ERROR - 2010-07-20 08:52:24 --> 404 Page Not Found --> callback
ERROR - 2010-07-20 08:53:00 --> 404 Page Not Found --> callback
ERROR - 2010-07-20 08:53:38 --> 404 Page Not Found --> callback
ERROR - 2010-07-20 08:54:02 --> Severity: Notice  --> Undefined index:  callback D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\qunit_feed.php 26
ERROR - 2010-07-20 08:54:52 --> Severity: Notice  --> Undefined index:  callback D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\qunit_feed.php 26
ERROR - 2010-07-20 08:54:56 --> 404 Page Not Found --> callback
ERROR - 2010-07-20 08:57:51 --> 404 Page Not Found --> callback
ERROR - 2010-07-20 08:58:06 --> 404 Page Not Found --> callback
ERROR - 2010-07-20 09:02:35 --> 404 Page Not Found --> callback
ERROR - 2010-07-20 09:02:38 --> 404 Page Not Found --> callback
ERROR - 2010-07-20 09:17:38 --> 404 Page Not Found --> callback
ERROR - 2010-07-20 09:18:02 --> 404 Page Not Found --> qunit_feed~test
ERROR - 2010-07-20 09:18:38 --> 404 Page Not Found --> callback
ERROR - 2010-07-20 09:18:47 --> 404 Page Not Found --> callback
ERROR - 2010-07-20 09:18:51 --> 404 Page Not Found --> callback
ERROR - 2010-07-20 09:19:26 --> 404 Page Not Found --> qunit_feed~test
ERROR - 2010-07-20 09:19:38 --> 404 Page Not Found --> callback
ERROR - 2010-07-20 09:19:42 --> 404 Page Not Found --> callback
ERROR - 2010-07-20 09:20:16 --> 404 Page Not Found --> jsoncallback
ERROR - 2010-07-20 09:21:01 --> 404 Page Not Found --> jsoncallback
ERROR - 2010-07-20 09:21:06 --> 404 Page Not Found --> jsoncallback
ERROR - 2010-07-20 09:22:46 --> 404 Page Not Found --> jsoncallback
ERROR - 2010-07-20 09:25:51 --> 404 Page Not Found --> jsoncallback
ERROR - 2010-07-20 09:25:59 --> 404 Page Not Found --> callback
ERROR - 2010-07-20 11:50:38 --> 404 Page Not Found --> ut
ERROR - 2010-07-20 13:26:06 --> Severity: Warning  --> Missing argument 2 for qunit_feed::index() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\qunit_feed.php 23
ERROR - 2010-07-20 13:26:06 --> Severity: Notice  --> Undefined variable: callback D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\qunit_feed.php 42
ERROR - 2010-07-20 13:31:12 --> Severity: Warning  --> Missing argument 1 for qunit_feed::index() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\qunit_feed.php 23
ERROR - 2010-07-20 13:31:12 --> Severity: Warning  --> Missing argument 2 for qunit_feed::index() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\qunit_feed.php 23
ERROR - 2010-07-20 13:31:12 --> Severity: Notice  --> Undefined variable: json D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\qunit_feed.php 27
ERROR - 2010-07-20 13:31:12 --> Severity: Notice  --> Undefined variable: callback D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\qunit_feed.php 42
ERROR - 2010-07-20 14:09:34 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/34173cb38f07f89ddbebc2ac9128303f) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
ERROR - 2010-07-20 14:16:39 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\qunit_feed.php 29
ERROR - 2010-07-20 14:16:51 --> Severity: Notice  --> Use of undefined constant value - assumed 'value' D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\qunit_feed.php 31
ERROR - 2010-07-20 14:16:51 --> Severity: 4096  --> Object of class stdClass could not be converted to string D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\qunit_feed.php 31
ERROR - 2010-07-20 15:00:14 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/c51ce410c124a10e0db5e4b97fc2af39) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
