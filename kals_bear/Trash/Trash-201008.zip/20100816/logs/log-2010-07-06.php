<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2010-07-06 13:28:32 --> Config Class Initialized
DEBUG - 2010-07-06 13:28:32 --> Hooks Class Initialized
DEBUG - 2010-07-06 13:28:32 --> URI Class Initialized
DEBUG - 2010-07-06 13:28:32 --> Router Class Initialized
DEBUG - 2010-07-06 13:28:32 --> Output Class Initialized
DEBUG - 2010-07-06 13:28:32 --> Input Class Initialized
DEBUG - 2010-07-06 13:28:32 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-06 13:28:33 --> Language Class Initialized
DEBUG - 2010-07-06 13:28:33 --> Loader Class Initialized
DEBUG - 2010-07-06 13:28:33 --> Helper loaded: context_helper
DEBUG - 2010-07-06 13:28:33 --> Helper loaded: kals_helper
DEBUG - 2010-07-06 13:28:33 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-06 13:28:33 --> Database Driver Class Initialized
DEBUG - 2010-07-06 13:28:33 --> Controller Class Initialized
DEBUG - 2010-07-06 13:28:33 --> Unit Testing Class Initialized
DEBUG - 2010-07-06 13:28:33 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-06 13:28:33 --> Session Class Initialized
DEBUG - 2010-07-06 13:28:33 --> Helper loaded: string_helper
DEBUG - 2010-07-06 13:28:33 --> A session cookie was not found.
DEBUG - 2010-07-06 13:28:33 --> Session routines successfully run
ERROR - 2010-07-06 13:28:33 --> Unable to load the requested class: annotation_type_annotation.type.confusion
DEBUG - 2010-07-06 13:29:12 --> Config Class Initialized
DEBUG - 2010-07-06 13:29:12 --> Hooks Class Initialized
DEBUG - 2010-07-06 13:29:12 --> URI Class Initialized
DEBUG - 2010-07-06 13:29:12 --> Router Class Initialized
DEBUG - 2010-07-06 13:29:12 --> Output Class Initialized
DEBUG - 2010-07-06 13:29:12 --> Input Class Initialized
DEBUG - 2010-07-06 13:29:12 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-06 13:29:12 --> Language Class Initialized
DEBUG - 2010-07-06 13:29:12 --> Loader Class Initialized
DEBUG - 2010-07-06 13:29:12 --> Helper loaded: context_helper
DEBUG - 2010-07-06 13:29:12 --> Helper loaded: kals_helper
DEBUG - 2010-07-06 13:29:12 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-06 13:29:12 --> Database Driver Class Initialized
DEBUG - 2010-07-06 13:29:12 --> Controller Class Initialized
DEBUG - 2010-07-06 13:29:12 --> Unit Testing Class Initialized
DEBUG - 2010-07-06 13:29:13 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-06 13:29:13 --> Session Class Initialized
DEBUG - 2010-07-06 13:29:13 --> Helper loaded: string_helper
DEBUG - 2010-07-06 13:29:13 --> Session routines successfully run
ERROR - 2010-07-06 13:29:13 --> Unable to load the requested class: annotation_type_annotation.type.confusion
DEBUG - 2010-07-06 13:29:19 --> Config Class Initialized
DEBUG - 2010-07-06 13:29:19 --> Hooks Class Initialized
DEBUG - 2010-07-06 13:29:19 --> URI Class Initialized
DEBUG - 2010-07-06 13:29:19 --> Router Class Initialized
DEBUG - 2010-07-06 13:29:19 --> Output Class Initialized
DEBUG - 2010-07-06 13:29:19 --> Input Class Initialized
DEBUG - 2010-07-06 13:29:19 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-06 13:29:19 --> Language Class Initialized
DEBUG - 2010-07-06 13:29:19 --> Loader Class Initialized
DEBUG - 2010-07-06 13:29:19 --> Helper loaded: context_helper
DEBUG - 2010-07-06 13:29:19 --> Helper loaded: kals_helper
DEBUG - 2010-07-06 13:29:19 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-06 13:29:19 --> Database Driver Class Initialized
DEBUG - 2010-07-06 13:29:19 --> Controller Class Initialized
DEBUG - 2010-07-06 13:29:19 --> Unit Testing Class Initialized
DEBUG - 2010-07-06 13:29:19 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-06 13:29:19 --> Session Class Initialized
DEBUG - 2010-07-06 13:29:19 --> Helper loaded: string_helper
DEBUG - 2010-07-06 13:29:19 --> Session routines successfully run
ERROR - 2010-07-06 13:29:19 --> Unable to load the requested class: annotation_type_annotation.type.confusion
ERROR - 2010-07-06 13:29:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\type\Annotation_type_factory.php:80) D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 360
DEBUG - 2010-07-06 13:31:38 --> Config Class Initialized
DEBUG - 2010-07-06 13:31:38 --> Hooks Class Initialized
DEBUG - 2010-07-06 13:31:38 --> URI Class Initialized
DEBUG - 2010-07-06 13:31:38 --> Router Class Initialized
DEBUG - 2010-07-06 13:31:38 --> Output Class Initialized
DEBUG - 2010-07-06 13:31:38 --> Input Class Initialized
DEBUG - 2010-07-06 13:31:38 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-06 13:31:38 --> Language Class Initialized
DEBUG - 2010-07-06 13:31:38 --> Loader Class Initialized
DEBUG - 2010-07-06 13:31:38 --> Helper loaded: context_helper
DEBUG - 2010-07-06 13:31:38 --> Helper loaded: kals_helper
DEBUG - 2010-07-06 13:31:38 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-06 13:31:38 --> Database Driver Class Initialized
DEBUG - 2010-07-06 13:31:38 --> Controller Class Initialized
DEBUG - 2010-07-06 13:31:38 --> Unit Testing Class Initialized
DEBUG - 2010-07-06 13:31:38 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-06 13:31:38 --> Session Class Initialized
DEBUG - 2010-07-06 13:31:38 --> Helper loaded: string_helper
DEBUG - 2010-07-06 13:31:38 --> Session routines successfully run
DEBUG - 2010-07-06 13:31:38 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-06 13:31:38 --> Annotation_type_confusion class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 13:31:38 --> Annotation_type_custom class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 13:31:38 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-06 13:31:38 --> Final output sent to browser
DEBUG - 2010-07-06 13:31:38 --> Total execution time: 0.2445
DEBUG - 2010-07-06 13:32:16 --> Config Class Initialized
DEBUG - 2010-07-06 13:32:16 --> Hooks Class Initialized
DEBUG - 2010-07-06 13:32:16 --> URI Class Initialized
DEBUG - 2010-07-06 13:32:16 --> Router Class Initialized
DEBUG - 2010-07-06 13:32:16 --> Output Class Initialized
DEBUG - 2010-07-06 13:32:16 --> Input Class Initialized
DEBUG - 2010-07-06 13:32:16 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-06 13:32:16 --> Language Class Initialized
DEBUG - 2010-07-06 13:32:16 --> Loader Class Initialized
DEBUG - 2010-07-06 13:32:16 --> Helper loaded: context_helper
DEBUG - 2010-07-06 13:32:16 --> Helper loaded: kals_helper
DEBUG - 2010-07-06 13:32:16 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-06 13:32:16 --> Database Driver Class Initialized
DEBUG - 2010-07-06 13:32:16 --> Controller Class Initialized
DEBUG - 2010-07-06 13:32:16 --> Unit Testing Class Initialized
DEBUG - 2010-07-06 13:32:16 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-06 13:32:16 --> Session Class Initialized
DEBUG - 2010-07-06 13:32:16 --> Helper loaded: string_helper
DEBUG - 2010-07-06 13:32:16 --> Session routines successfully run
DEBUG - 2010-07-06 13:32:16 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-06 13:32:16 --> Annotation_type_confusion class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 13:32:16 --> Annotation_type_custom class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 13:32:16 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-06 13:32:16 --> Final output sent to browser
DEBUG - 2010-07-06 13:32:16 --> Total execution time: 0.2268
DEBUG - 2010-07-06 13:33:00 --> Config Class Initialized
DEBUG - 2010-07-06 13:33:00 --> Hooks Class Initialized
DEBUG - 2010-07-06 13:33:00 --> URI Class Initialized
DEBUG - 2010-07-06 13:33:00 --> Router Class Initialized
DEBUG - 2010-07-06 13:33:00 --> Output Class Initialized
DEBUG - 2010-07-06 13:33:00 --> Input Class Initialized
DEBUG - 2010-07-06 13:33:00 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-06 13:33:00 --> Language Class Initialized
DEBUG - 2010-07-06 13:33:00 --> Loader Class Initialized
DEBUG - 2010-07-06 13:33:00 --> Helper loaded: context_helper
DEBUG - 2010-07-06 13:33:00 --> Helper loaded: kals_helper
DEBUG - 2010-07-06 13:33:00 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-06 13:33:00 --> Database Driver Class Initialized
DEBUG - 2010-07-06 13:33:00 --> Controller Class Initialized
DEBUG - 2010-07-06 13:33:00 --> Unit Testing Class Initialized
DEBUG - 2010-07-06 13:33:00 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-06 13:33:00 --> Session Class Initialized
DEBUG - 2010-07-06 13:33:00 --> Helper loaded: string_helper
DEBUG - 2010-07-06 13:33:00 --> Session routines successfully run
DEBUG - 2010-07-06 13:33:00 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-06 13:33:00 --> Annotation_type_confusion class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 13:33:00 --> Annotation_type_custom class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 13:33:00 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-06 13:33:00 --> Final output sent to browser
DEBUG - 2010-07-06 13:33:00 --> Total execution time: 0.2228
DEBUG - 2010-07-06 13:33:24 --> Config Class Initialized
DEBUG - 2010-07-06 13:33:24 --> Hooks Class Initialized
DEBUG - 2010-07-06 13:33:24 --> URI Class Initialized
DEBUG - 2010-07-06 13:33:24 --> Router Class Initialized
DEBUG - 2010-07-06 13:33:24 --> Output Class Initialized
DEBUG - 2010-07-06 13:33:24 --> Input Class Initialized
DEBUG - 2010-07-06 13:33:24 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-06 13:33:24 --> Language Class Initialized
DEBUG - 2010-07-06 13:33:24 --> Loader Class Initialized
DEBUG - 2010-07-06 13:33:24 --> Helper loaded: context_helper
DEBUG - 2010-07-06 13:33:24 --> Helper loaded: kals_helper
DEBUG - 2010-07-06 13:33:24 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-06 13:33:24 --> Database Driver Class Initialized
DEBUG - 2010-07-06 13:33:24 --> Controller Class Initialized
DEBUG - 2010-07-06 13:33:24 --> Unit Testing Class Initialized
DEBUG - 2010-07-06 13:33:24 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-06 13:33:24 --> Session Class Initialized
DEBUG - 2010-07-06 13:33:24 --> Helper loaded: string_helper
DEBUG - 2010-07-06 13:33:24 --> Session routines successfully run
DEBUG - 2010-07-06 13:33:24 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-06 13:33:24 --> Annotation_type_confusion class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 13:33:24 --> Annotation_type_custom class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 13:33:24 --> Config Class Initialized
DEBUG - 2010-07-06 13:33:24 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-06 13:33:24 --> Hooks Class Initialized
DEBUG - 2010-07-06 13:33:24 --> Final output sent to browser
DEBUG - 2010-07-06 13:33:24 --> URI Class Initialized
DEBUG - 2010-07-06 13:33:24 --> Total execution time: 0.2504
DEBUG - 2010-07-06 13:33:24 --> Router Class Initialized
DEBUG - 2010-07-06 13:33:24 --> Output Class Initialized
DEBUG - 2010-07-06 13:33:24 --> Input Class Initialized
DEBUG - 2010-07-06 13:33:24 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-06 13:33:24 --> Language Class Initialized
DEBUG - 2010-07-06 13:33:24 --> Loader Class Initialized
DEBUG - 2010-07-06 13:33:24 --> Helper loaded: context_helper
DEBUG - 2010-07-06 13:33:24 --> Helper loaded: kals_helper
DEBUG - 2010-07-06 13:33:24 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-06 13:33:24 --> Database Driver Class Initialized
DEBUG - 2010-07-06 13:33:24 --> Controller Class Initialized
DEBUG - 2010-07-06 13:33:24 --> Unit Testing Class Initialized
DEBUG - 2010-07-06 13:33:24 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-06 13:33:24 --> Session Class Initialized
DEBUG - 2010-07-06 13:33:24 --> Helper loaded: string_helper
DEBUG - 2010-07-06 13:33:24 --> Session routines successfully run
DEBUG - 2010-07-06 13:33:24 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-06 13:33:24 --> Annotation_type_confusion class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 13:33:24 --> Annotation_type_custom class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 13:33:24 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-06 13:33:24 --> Final output sent to browser
DEBUG - 2010-07-06 13:33:24 --> Total execution time: 0.2492
DEBUG - 2010-07-06 13:34:52 --> Config Class Initialized
DEBUG - 2010-07-06 13:34:52 --> Hooks Class Initialized
DEBUG - 2010-07-06 13:34:52 --> URI Class Initialized
DEBUG - 2010-07-06 13:34:52 --> Router Class Initialized
DEBUG - 2010-07-06 13:34:52 --> Output Class Initialized
DEBUG - 2010-07-06 13:34:52 --> Input Class Initialized
DEBUG - 2010-07-06 13:34:52 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-06 13:34:52 --> Language Class Initialized
DEBUG - 2010-07-06 13:34:52 --> Loader Class Initialized
DEBUG - 2010-07-06 13:34:52 --> Helper loaded: context_helper
DEBUG - 2010-07-06 13:34:52 --> Helper loaded: kals_helper
DEBUG - 2010-07-06 13:34:52 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-06 13:34:52 --> Database Driver Class Initialized
DEBUG - 2010-07-06 13:34:52 --> Controller Class Initialized
DEBUG - 2010-07-06 13:34:52 --> Unit Testing Class Initialized
DEBUG - 2010-07-06 13:34:52 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-06 13:34:52 --> Session Class Initialized
DEBUG - 2010-07-06 13:34:52 --> Helper loaded: string_helper
DEBUG - 2010-07-06 13:34:52 --> Session routines successfully run
DEBUG - 2010-07-06 13:34:52 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-06 13:35:18 --> Config Class Initialized
DEBUG - 2010-07-06 13:35:18 --> Hooks Class Initialized
DEBUG - 2010-07-06 13:35:18 --> URI Class Initialized
DEBUG - 2010-07-06 13:35:18 --> Router Class Initialized
DEBUG - 2010-07-06 13:35:18 --> Output Class Initialized
DEBUG - 2010-07-06 13:35:19 --> Input Class Initialized
DEBUG - 2010-07-06 13:35:19 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-06 13:35:19 --> Language Class Initialized
DEBUG - 2010-07-06 13:35:19 --> Loader Class Initialized
DEBUG - 2010-07-06 13:35:19 --> Helper loaded: context_helper
DEBUG - 2010-07-06 13:35:19 --> Helper loaded: kals_helper
DEBUG - 2010-07-06 13:35:19 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-06 13:35:19 --> Database Driver Class Initialized
DEBUG - 2010-07-06 13:35:19 --> Controller Class Initialized
DEBUG - 2010-07-06 13:35:19 --> Unit Testing Class Initialized
DEBUG - 2010-07-06 13:35:19 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-06 13:35:19 --> Session Class Initialized
DEBUG - 2010-07-06 13:35:19 --> Helper loaded: string_helper
DEBUG - 2010-07-06 13:35:19 --> Session routines successfully run
DEBUG - 2010-07-06 13:35:19 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-06 13:35:19 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-06 13:35:19 --> Final output sent to browser
DEBUG - 2010-07-06 13:35:19 --> Total execution time: 0.2443
DEBUG - 2010-07-06 13:36:43 --> Config Class Initialized
DEBUG - 2010-07-06 13:36:43 --> Hooks Class Initialized
DEBUG - 2010-07-06 13:36:43 --> URI Class Initialized
DEBUG - 2010-07-06 13:36:43 --> Router Class Initialized
DEBUG - 2010-07-06 13:36:43 --> Output Class Initialized
DEBUG - 2010-07-06 13:36:43 --> Input Class Initialized
DEBUG - 2010-07-06 13:36:43 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-06 13:36:43 --> Language Class Initialized
DEBUG - 2010-07-06 13:36:43 --> Loader Class Initialized
DEBUG - 2010-07-06 13:36:43 --> Helper loaded: context_helper
DEBUG - 2010-07-06 13:36:43 --> Helper loaded: kals_helper
DEBUG - 2010-07-06 13:36:43 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-06 13:36:43 --> Database Driver Class Initialized
DEBUG - 2010-07-06 13:36:43 --> Controller Class Initialized
DEBUG - 2010-07-06 13:36:43 --> Unit Testing Class Initialized
DEBUG - 2010-07-06 13:36:43 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-06 13:36:43 --> Session Class Initialized
DEBUG - 2010-07-06 13:36:43 --> Helper loaded: string_helper
DEBUG - 2010-07-06 13:36:43 --> Session routines successfully run
DEBUG - 2010-07-06 13:36:43 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-06 13:36:43 --> Annotation_type_confusion class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 13:36:43 --> Annotation_type_custom class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 13:36:43 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-06 13:36:43 --> Final output sent to browser
DEBUG - 2010-07-06 13:36:43 --> Total execution time: 0.2929
DEBUG - 2010-07-06 13:37:46 --> Config Class Initialized
DEBUG - 2010-07-06 13:37:46 --> Hooks Class Initialized
DEBUG - 2010-07-06 13:37:46 --> URI Class Initialized
DEBUG - 2010-07-06 13:37:46 --> Router Class Initialized
DEBUG - 2010-07-06 13:37:46 --> Output Class Initialized
DEBUG - 2010-07-06 13:37:46 --> Input Class Initialized
DEBUG - 2010-07-06 13:37:46 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-06 13:37:46 --> Language Class Initialized
DEBUG - 2010-07-06 13:37:46 --> Loader Class Initialized
DEBUG - 2010-07-06 13:37:46 --> Helper loaded: context_helper
DEBUG - 2010-07-06 13:37:46 --> Helper loaded: kals_helper
DEBUG - 2010-07-06 13:37:46 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-06 13:37:46 --> Database Driver Class Initialized
DEBUG - 2010-07-06 13:37:46 --> Controller Class Initialized
DEBUG - 2010-07-06 13:37:46 --> Unit Testing Class Initialized
DEBUG - 2010-07-06 13:37:46 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-06 13:37:46 --> Session Class Initialized
DEBUG - 2010-07-06 13:37:46 --> Helper loaded: string_helper
DEBUG - 2010-07-06 13:37:46 --> Session routines successfully run
DEBUG - 2010-07-06 13:37:46 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-06 13:37:46 --> Annotation_type_confusion class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 13:37:46 --> Annotation_type_custom class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 13:37:46 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-06 13:37:46 --> Final output sent to browser
DEBUG - 2010-07-06 13:37:46 --> Total execution time: 0.3149
DEBUG - 2010-07-06 13:38:03 --> Config Class Initialized
DEBUG - 2010-07-06 13:38:03 --> Hooks Class Initialized
DEBUG - 2010-07-06 13:38:03 --> URI Class Initialized
DEBUG - 2010-07-06 13:38:03 --> Router Class Initialized
DEBUG - 2010-07-06 13:38:03 --> Output Class Initialized
DEBUG - 2010-07-06 13:38:03 --> Input Class Initialized
DEBUG - 2010-07-06 13:38:03 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-06 13:38:03 --> Language Class Initialized
DEBUG - 2010-07-06 13:38:03 --> Loader Class Initialized
DEBUG - 2010-07-06 13:38:03 --> Helper loaded: context_helper
DEBUG - 2010-07-06 13:38:03 --> Helper loaded: kals_helper
DEBUG - 2010-07-06 13:38:03 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-06 13:38:03 --> Database Driver Class Initialized
DEBUG - 2010-07-06 13:38:03 --> Controller Class Initialized
DEBUG - 2010-07-06 13:38:04 --> Unit Testing Class Initialized
DEBUG - 2010-07-06 13:38:04 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-06 13:38:04 --> Session Class Initialized
DEBUG - 2010-07-06 13:38:04 --> Helper loaded: string_helper
DEBUG - 2010-07-06 13:38:04 --> Session routines successfully run
DEBUG - 2010-07-06 13:38:04 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-06 13:38:04 --> Annotation_type_confusion class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 13:38:04 --> Annotation_type_custom class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 13:38:04 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-06 13:38:04 --> Final output sent to browser
DEBUG - 2010-07-06 13:38:04 --> Total execution time: 0.3140
DEBUG - 2010-07-06 13:39:32 --> Config Class Initialized
DEBUG - 2010-07-06 13:39:32 --> Hooks Class Initialized
DEBUG - 2010-07-06 13:39:32 --> URI Class Initialized
DEBUG - 2010-07-06 13:39:32 --> Router Class Initialized
DEBUG - 2010-07-06 13:39:32 --> Output Class Initialized
DEBUG - 2010-07-06 13:39:32 --> Input Class Initialized
DEBUG - 2010-07-06 13:39:32 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-06 13:39:32 --> Language Class Initialized
DEBUG - 2010-07-06 13:39:32 --> Loader Class Initialized
DEBUG - 2010-07-06 13:39:32 --> Helper loaded: context_helper
DEBUG - 2010-07-06 13:39:32 --> Helper loaded: kals_helper
DEBUG - 2010-07-06 13:39:32 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-06 13:39:32 --> Database Driver Class Initialized
DEBUG - 2010-07-06 13:39:32 --> Controller Class Initialized
DEBUG - 2010-07-06 13:39:32 --> Unit Testing Class Initialized
DEBUG - 2010-07-06 13:39:32 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-06 13:39:32 --> Session Class Initialized
DEBUG - 2010-07-06 13:39:32 --> Helper loaded: string_helper
DEBUG - 2010-07-06 13:39:32 --> Session routines successfully run
DEBUG - 2010-07-06 13:39:32 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-06 13:39:32 --> Annotation_type_confusion class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 13:39:32 --> Annotation_type_custom class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 13:39:32 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-06 13:39:32 --> Final output sent to browser
DEBUG - 2010-07-06 13:39:32 --> Total execution time: 0.3494
DEBUG - 2010-07-06 13:40:13 --> Config Class Initialized
DEBUG - 2010-07-06 13:40:13 --> Hooks Class Initialized
DEBUG - 2010-07-06 13:40:13 --> URI Class Initialized
DEBUG - 2010-07-06 13:40:13 --> Router Class Initialized
DEBUG - 2010-07-06 13:40:13 --> Output Class Initialized
DEBUG - 2010-07-06 13:40:13 --> Input Class Initialized
DEBUG - 2010-07-06 13:40:13 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-06 13:40:13 --> Language Class Initialized
DEBUG - 2010-07-06 13:40:14 --> Loader Class Initialized
DEBUG - 2010-07-06 13:40:14 --> Helper loaded: context_helper
DEBUG - 2010-07-06 13:40:14 --> Helper loaded: kals_helper
DEBUG - 2010-07-06 13:40:14 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-06 13:40:14 --> Database Driver Class Initialized
DEBUG - 2010-07-06 13:40:14 --> Controller Class Initialized
DEBUG - 2010-07-06 13:40:14 --> Unit Testing Class Initialized
DEBUG - 2010-07-06 13:40:14 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-06 13:40:14 --> Session Class Initialized
DEBUG - 2010-07-06 13:40:14 --> Helper loaded: string_helper
DEBUG - 2010-07-06 13:40:14 --> Session routines successfully run
DEBUG - 2010-07-06 13:40:14 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-06 13:40:14 --> Annotation_type_confusion class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 13:40:14 --> Annotation_type_custom class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 13:40:14 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-06 13:40:14 --> Final output sent to browser
DEBUG - 2010-07-06 13:40:14 --> Total execution time: 0.3488
DEBUG - 2010-07-06 13:41:43 --> Config Class Initialized
DEBUG - 2010-07-06 13:41:43 --> Hooks Class Initialized
DEBUG - 2010-07-06 13:41:43 --> URI Class Initialized
DEBUG - 2010-07-06 13:41:43 --> Router Class Initialized
DEBUG - 2010-07-06 13:41:43 --> Output Class Initialized
DEBUG - 2010-07-06 13:41:43 --> Input Class Initialized
DEBUG - 2010-07-06 13:41:43 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-06 13:41:43 --> Language Class Initialized
DEBUG - 2010-07-06 13:41:43 --> Loader Class Initialized
DEBUG - 2010-07-06 13:41:43 --> Helper loaded: context_helper
DEBUG - 2010-07-06 13:41:43 --> Helper loaded: kals_helper
DEBUG - 2010-07-06 13:41:43 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-06 13:41:43 --> Database Driver Class Initialized
DEBUG - 2010-07-06 13:41:43 --> Controller Class Initialized
DEBUG - 2010-07-06 13:41:43 --> Unit Testing Class Initialized
DEBUG - 2010-07-06 13:41:43 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-06 13:41:43 --> Session Class Initialized
DEBUG - 2010-07-06 13:41:43 --> Helper loaded: string_helper
DEBUG - 2010-07-06 13:41:43 --> Session routines successfully run
DEBUG - 2010-07-06 13:41:43 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-06 13:41:43 --> Annotation_type_confusion class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 13:41:43 --> Annotation_type_custom class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 13:41:43 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-06 13:41:43 --> Final output sent to browser
DEBUG - 2010-07-06 13:41:43 --> Total execution time: 0.3746
DEBUG - 2010-07-06 13:42:17 --> Config Class Initialized
DEBUG - 2010-07-06 13:42:17 --> Hooks Class Initialized
DEBUG - 2010-07-06 13:42:17 --> URI Class Initialized
DEBUG - 2010-07-06 13:42:17 --> Router Class Initialized
DEBUG - 2010-07-06 13:42:17 --> Output Class Initialized
DEBUG - 2010-07-06 13:42:17 --> Input Class Initialized
DEBUG - 2010-07-06 13:42:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-06 13:42:17 --> Language Class Initialized
DEBUG - 2010-07-06 13:42:17 --> Loader Class Initialized
DEBUG - 2010-07-06 13:42:17 --> Helper loaded: context_helper
DEBUG - 2010-07-06 13:42:17 --> Helper loaded: kals_helper
DEBUG - 2010-07-06 13:42:17 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-06 13:42:17 --> Database Driver Class Initialized
DEBUG - 2010-07-06 13:42:17 --> Controller Class Initialized
DEBUG - 2010-07-06 13:42:17 --> Unit Testing Class Initialized
DEBUG - 2010-07-06 13:42:17 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-06 13:42:17 --> Session Class Initialized
DEBUG - 2010-07-06 13:42:17 --> Helper loaded: string_helper
DEBUG - 2010-07-06 13:42:17 --> Session routines successfully run
DEBUG - 2010-07-06 13:42:17 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-06 13:42:17 --> Annotation_type_confusion class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 13:42:17 --> Annotation_type_custom class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 13:42:17 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-06 13:42:17 --> Final output sent to browser
DEBUG - 2010-07-06 13:42:17 --> Total execution time: 0.3697
DEBUG - 2010-07-06 13:42:29 --> Config Class Initialized
DEBUG - 2010-07-06 13:42:29 --> Hooks Class Initialized
DEBUG - 2010-07-06 13:42:29 --> URI Class Initialized
DEBUG - 2010-07-06 13:42:29 --> Router Class Initialized
DEBUG - 2010-07-06 13:42:29 --> Output Class Initialized
ERROR - 2010-07-06 13:42:29 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/28dd2c7955ce926456240b2ff0100bde) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
DEBUG - 2010-07-06 13:42:29 --> Input Class Initialized
DEBUG - 2010-07-06 13:42:29 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-06 13:42:29 --> Language Class Initialized
DEBUG - 2010-07-06 13:42:29 --> Loader Class Initialized
DEBUG - 2010-07-06 13:42:29 --> Helper loaded: context_helper
DEBUG - 2010-07-06 13:42:29 --> Helper loaded: kals_helper
DEBUG - 2010-07-06 13:42:29 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-06 13:42:29 --> Database Driver Class Initialized
DEBUG - 2010-07-06 13:42:29 --> Controller Class Initialized
DEBUG - 2010-07-06 13:42:30 --> Unit Testing Class Initialized
DEBUG - 2010-07-06 13:42:30 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-06 13:42:47 --> Config Class Initialized
DEBUG - 2010-07-06 13:42:47 --> Hooks Class Initialized
DEBUG - 2010-07-06 13:42:47 --> URI Class Initialized
DEBUG - 2010-07-06 13:42:47 --> Router Class Initialized
DEBUG - 2010-07-06 13:42:47 --> Output Class Initialized
DEBUG - 2010-07-06 13:42:47 --> Input Class Initialized
DEBUG - 2010-07-06 13:42:47 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-06 13:42:47 --> Language Class Initialized
DEBUG - 2010-07-06 13:42:47 --> Loader Class Initialized
DEBUG - 2010-07-06 13:42:47 --> Helper loaded: context_helper
DEBUG - 2010-07-06 13:42:47 --> Helper loaded: kals_helper
DEBUG - 2010-07-06 13:42:47 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-06 13:42:47 --> Database Driver Class Initialized
DEBUG - 2010-07-06 13:42:47 --> Controller Class Initialized
DEBUG - 2010-07-06 13:42:47 --> Unit Testing Class Initialized
DEBUG - 2010-07-06 13:42:47 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-06 13:42:48 --> Session Class Initialized
DEBUG - 2010-07-06 13:42:48 --> Helper loaded: string_helper
DEBUG - 2010-07-06 13:42:48 --> Session routines successfully run
DEBUG - 2010-07-06 13:42:48 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-06 13:42:48 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-06 13:42:48 --> Final output sent to browser
DEBUG - 2010-07-06 13:42:48 --> Total execution time: 0.3769
DEBUG - 2010-07-06 13:43:16 --> Config Class Initialized
DEBUG - 2010-07-06 13:43:16 --> Hooks Class Initialized
DEBUG - 2010-07-06 13:43:16 --> URI Class Initialized
DEBUG - 2010-07-06 13:43:16 --> Router Class Initialized
DEBUG - 2010-07-06 13:43:16 --> Output Class Initialized
DEBUG - 2010-07-06 13:43:16 --> Input Class Initialized
DEBUG - 2010-07-06 13:43:16 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-06 13:43:16 --> Language Class Initialized
DEBUG - 2010-07-06 13:43:16 --> Loader Class Initialized
DEBUG - 2010-07-06 13:43:16 --> Helper loaded: context_helper
DEBUG - 2010-07-06 13:43:16 --> Helper loaded: kals_helper
DEBUG - 2010-07-06 13:43:16 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-06 13:43:16 --> Database Driver Class Initialized
DEBUG - 2010-07-06 13:43:16 --> Controller Class Initialized
DEBUG - 2010-07-06 13:43:16 --> Unit Testing Class Initialized
DEBUG - 2010-07-06 13:43:16 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-06 13:43:16 --> Session Class Initialized
DEBUG - 2010-07-06 13:43:16 --> Helper loaded: string_helper
DEBUG - 2010-07-06 13:43:16 --> Session routines successfully run
DEBUG - 2010-07-06 13:43:16 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-06 13:43:16 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-06 13:43:16 --> Final output sent to browser
DEBUG - 2010-07-06 13:43:16 --> Total execution time: 0.4122
DEBUG - 2010-07-06 13:43:33 --> Config Class Initialized
DEBUG - 2010-07-06 13:43:33 --> Hooks Class Initialized
DEBUG - 2010-07-06 13:43:33 --> URI Class Initialized
DEBUG - 2010-07-06 13:43:33 --> Router Class Initialized
DEBUG - 2010-07-06 13:43:33 --> Output Class Initialized
DEBUG - 2010-07-06 13:43:33 --> Input Class Initialized
DEBUG - 2010-07-06 13:43:33 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-06 13:43:33 --> Language Class Initialized
DEBUG - 2010-07-06 13:43:33 --> Loader Class Initialized
DEBUG - 2010-07-06 13:43:33 --> Helper loaded: context_helper
DEBUG - 2010-07-06 13:43:33 --> Helper loaded: kals_helper
DEBUG - 2010-07-06 13:43:33 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-06 13:43:33 --> Database Driver Class Initialized
DEBUG - 2010-07-06 13:43:33 --> Controller Class Initialized
DEBUG - 2010-07-06 13:43:33 --> Unit Testing Class Initialized
DEBUG - 2010-07-06 13:43:33 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-06 13:43:33 --> Session Class Initialized
DEBUG - 2010-07-06 13:43:33 --> Helper loaded: string_helper
DEBUG - 2010-07-06 13:43:33 --> Session routines successfully run
DEBUG - 2010-07-06 13:43:33 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-06 13:43:33 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-06 13:43:33 --> Final output sent to browser
DEBUG - 2010-07-06 13:43:33 --> Total execution time: 0.4190
DEBUG - 2010-07-06 15:04:03 --> Config Class Initialized
DEBUG - 2010-07-06 15:04:03 --> Hooks Class Initialized
DEBUG - 2010-07-06 15:04:03 --> URI Class Initialized
DEBUG - 2010-07-06 15:04:03 --> Router Class Initialized
DEBUG - 2010-07-06 15:04:03 --> Output Class Initialized
DEBUG - 2010-07-06 15:04:03 --> Input Class Initialized
DEBUG - 2010-07-06 15:04:03 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-06 15:04:03 --> Language Class Initialized
DEBUG - 2010-07-06 15:04:03 --> Loader Class Initialized
DEBUG - 2010-07-06 15:04:03 --> Helper loaded: context_helper
DEBUG - 2010-07-06 15:04:03 --> Helper loaded: kals_helper
DEBUG - 2010-07-06 15:04:03 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-06 15:04:03 --> Database Driver Class Initialized
DEBUG - 2010-07-06 15:04:03 --> Controller Class Initialized
DEBUG - 2010-07-06 15:04:03 --> Unit Testing Class Initialized
DEBUG - 2010-07-06 15:04:03 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-06 15:04:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:04 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:04 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:04 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:04 --> Helper loaded: email_helper
DEBUG - 2010-07-06 15:04:04 --> User Agent Class Initialized
DEBUG - 2010-07-06 15:04:04 --> Session Class Initialized
DEBUG - 2010-07-06 15:04:04 --> Helper loaded: string_helper
DEBUG - 2010-07-06 15:04:04 --> Session routines successfully run
DEBUG - 2010-07-06 15:04:04 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:05 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-06 15:04:05 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:05 --> Config file loaded: config/kals.php
DEBUG - 2010-07-06 15:04:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:05 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:05 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:05 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:05 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-06 15:04:05 --> Final output sent to browser
DEBUG - 2010-07-06 15:04:05 --> Total execution time: 2.5048
DEBUG - 2010-07-06 15:04:27 --> Config Class Initialized
DEBUG - 2010-07-06 15:04:27 --> Hooks Class Initialized
DEBUG - 2010-07-06 15:04:27 --> URI Class Initialized
DEBUG - 2010-07-06 15:04:27 --> Router Class Initialized
DEBUG - 2010-07-06 15:04:27 --> Output Class Initialized
DEBUG - 2010-07-06 15:04:27 --> Input Class Initialized
DEBUG - 2010-07-06 15:04:27 --> Global POST and COOKIE data sanitized
DEBUG - 2010-07-06 15:04:27 --> Language Class Initialized
DEBUG - 2010-07-06 15:04:27 --> Loader Class Initialized
DEBUG - 2010-07-06 15:04:27 --> Helper loaded: context_helper
DEBUG - 2010-07-06 15:04:27 --> Helper loaded: kals_helper
DEBUG - 2010-07-06 15:04:27 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-07-06 15:04:27 --> Database Driver Class Initialized
DEBUG - 2010-07-06 15:04:27 --> Controller Class Initialized
DEBUG - 2010-07-06 15:04:27 --> Unit Testing Class Initialized
DEBUG - 2010-07-06 15:04:27 --> Helper loaded: unit_test_helper
DEBUG - 2010-07-06 15:04:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:27 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:27 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:27 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:27 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:27 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:27 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:27 --> Helper loaded: email_helper
DEBUG - 2010-07-06 15:04:27 --> User Agent Class Initialized
DEBUG - 2010-07-06 15:04:27 --> Session Class Initialized
DEBUG - 2010-07-06 15:04:27 --> Helper loaded: string_helper
DEBUG - 2010-07-06 15:04:27 --> Session routines successfully run
DEBUG - 2010-07-06 15:04:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:27 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:27 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:27 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:27 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-07-06 15:04:27 --> Authorize_manager class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:27 --> Config file loaded: config/kals.php
DEBUG - 2010-07-06 15:04:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:28 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:28 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:28 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:28 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:28 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:28 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:28 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:28 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:28 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2010-07-06 15:04:28 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-07-06 15:04:28 --> Final output sent to browser
DEBUG - 2010-07-06 15:04:28 --> Total execution time: 1.1217
