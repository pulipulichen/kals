<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2010-06-25 02:59:33 --> Config Class Initialized
DEBUG - 2010-06-25 02:59:33 --> Hooks Class Initialized
DEBUG - 2010-06-25 02:59:33 --> URI Class Initialized
DEBUG - 2010-06-25 02:59:33 --> Router Class Initialized
DEBUG - 2010-06-25 02:59:33 --> Output Class Initialized
DEBUG - 2010-06-25 02:59:33 --> Input Class Initialized
DEBUG - 2010-06-25 02:59:33 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 02:59:33 --> Language Class Initialized
DEBUG - 2010-06-25 02:59:33 --> Loader Class Initialized
DEBUG - 2010-06-25 02:59:33 --> Helper loaded: object_helper
DEBUG - 2010-06-25 02:59:33 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 02:59:33 --> Helper loaded: context_helper
DEBUG - 2010-06-25 02:59:33 --> Session Class Initialized
DEBUG - 2010-06-25 02:59:33 --> Helper loaded: string_helper
DEBUG - 2010-06-25 02:59:33 --> A session cookie was not found.
DEBUG - 2010-06-25 02:59:33 --> Session routines successfully run
DEBUG - 2010-06-25 02:59:33 --> Helper loaded: context_helper
DEBUG - 2010-06-25 02:59:33 --> Controller Class Initialized
DEBUG - 2010-06-25 02:59:33 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 02:59:33 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 02:59:33 --> Database Driver Class Initialized
DEBUG - 2010-06-25 02:59:33 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-25 02:59:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 02:59:34 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-25 02:59:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 02:59:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 02:59:34 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 02:59:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 02:59:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 02:59:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 02:59:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 02:59:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 02:59:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 02:59:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 02:59:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 02:59:34 --> Config file loaded: config/kals.php
DEBUG - 2010-06-25 02:59:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 02:59:34 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 02:59:34 --> Final output sent to browser
DEBUG - 2010-06-25 02:59:34 --> Total execution time: 0.7619
DEBUG - 2010-06-25 03:02:02 --> Config Class Initialized
DEBUG - 2010-06-25 03:02:02 --> Hooks Class Initialized
DEBUG - 2010-06-25 03:02:02 --> URI Class Initialized
DEBUG - 2010-06-25 03:02:02 --> Router Class Initialized
DEBUG - 2010-06-25 03:02:02 --> Output Class Initialized
DEBUG - 2010-06-25 03:02:02 --> Input Class Initialized
DEBUG - 2010-06-25 03:02:02 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 03:02:02 --> Language Class Initialized
DEBUG - 2010-06-25 03:02:02 --> Loader Class Initialized
DEBUG - 2010-06-25 03:02:02 --> Helper loaded: object_helper
DEBUG - 2010-06-25 03:02:02 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 03:02:02 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:02:02 --> Session Class Initialized
DEBUG - 2010-06-25 03:02:02 --> Helper loaded: string_helper
DEBUG - 2010-06-25 03:02:02 --> Session routines successfully run
DEBUG - 2010-06-25 03:02:02 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:02:02 --> Controller Class Initialized
DEBUG - 2010-06-25 03:02:02 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 03:02:02 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 03:02:02 --> Database Driver Class Initialized
DEBUG - 2010-06-25 03:02:02 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-25 03:02:02 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:02:02 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-25 03:02:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:02:02 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:02:02 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 03:02:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:02:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:02:02 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:02:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:02:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:02:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:02:02 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:02:02 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:02:02 --> Config file loaded: config/kals.php
DEBUG - 2010-06-25 03:02:02 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:02:02 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 03:02:02 --> Final output sent to browser
DEBUG - 2010-06-25 03:02:02 --> Total execution time: 0.3217
DEBUG - 2010-06-25 03:02:42 --> Config Class Initialized
DEBUG - 2010-06-25 03:02:42 --> Hooks Class Initialized
DEBUG - 2010-06-25 03:02:42 --> URI Class Initialized
DEBUG - 2010-06-25 03:02:42 --> Router Class Initialized
DEBUG - 2010-06-25 03:02:42 --> Output Class Initialized
ERROR - 2010-06-25 03:02:42 --> Severity: Warning  --> unlink(D:\xampp\htdocs\CodeIgniter_1.7.2/system/cache/d67d8ab4f4c10bf22aa353e27879133c) [<a href='function.unlink'>function.unlink</a>]: Permission denied D:\xampp\htdocs\CodeIgniter_1.7.2\system\codeigniter\Common.php 74
DEBUG - 2010-06-25 03:02:42 --> Input Class Initialized
DEBUG - 2010-06-25 03:02:42 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 03:02:42 --> Language Class Initialized
DEBUG - 2010-06-25 03:02:42 --> Loader Class Initialized
DEBUG - 2010-06-25 03:02:42 --> Helper loaded: object_helper
DEBUG - 2010-06-25 03:02:42 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 03:02:42 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:02:42 --> Session Class Initialized
DEBUG - 2010-06-25 03:02:42 --> Helper loaded: string_helper
DEBUG - 2010-06-25 03:02:42 --> Session routines successfully run
DEBUG - 2010-06-25 03:02:42 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:02:42 --> Controller Class Initialized
DEBUG - 2010-06-25 03:02:42 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 03:02:42 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 03:02:42 --> Database Driver Class Initialized
DEBUG - 2010-06-25 03:02:42 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-25 03:02:42 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:02:42 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-25 03:02:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:02:42 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:02:42 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 03:02:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:02:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:02:42 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:02:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:02:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:02:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:02:42 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:02:42 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:02:42 --> Config file loaded: config/kals.php
DEBUG - 2010-06-25 03:02:42 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:02:42 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 03:02:42 --> Final output sent to browser
DEBUG - 2010-06-25 03:02:42 --> Total execution time: 0.2475
DEBUG - 2010-06-25 03:03:02 --> Config Class Initialized
DEBUG - 2010-06-25 03:03:02 --> Hooks Class Initialized
DEBUG - 2010-06-25 03:03:02 --> URI Class Initialized
DEBUG - 2010-06-25 03:03:02 --> Router Class Initialized
DEBUG - 2010-06-25 03:03:02 --> Output Class Initialized
DEBUG - 2010-06-25 03:03:03 --> Input Class Initialized
DEBUG - 2010-06-25 03:03:03 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 03:03:03 --> Language Class Initialized
DEBUG - 2010-06-25 03:03:03 --> Loader Class Initialized
DEBUG - 2010-06-25 03:03:03 --> Helper loaded: object_helper
DEBUG - 2010-06-25 03:03:03 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 03:03:03 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:03:03 --> Session Class Initialized
DEBUG - 2010-06-25 03:03:03 --> Helper loaded: string_helper
DEBUG - 2010-06-25 03:03:03 --> Session routines successfully run
DEBUG - 2010-06-25 03:03:03 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:03:03 --> Controller Class Initialized
DEBUG - 2010-06-25 03:03:03 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 03:03:03 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 03:03:03 --> Database Driver Class Initialized
DEBUG - 2010-06-25 03:03:03 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-25 03:03:03 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:03:03 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-25 03:03:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:03:03 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:03:03 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 03:03:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:03:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:03:03 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:03:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:03:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:03:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:03:03 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:03:03 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:03:03 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:03:03 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 03:03:03 --> Final output sent to browser
DEBUG - 2010-06-25 03:03:03 --> Total execution time: 0.2727
DEBUG - 2010-06-25 03:04:15 --> Config Class Initialized
DEBUG - 2010-06-25 03:04:15 --> Hooks Class Initialized
DEBUG - 2010-06-25 03:04:15 --> URI Class Initialized
DEBUG - 2010-06-25 03:04:15 --> Router Class Initialized
DEBUG - 2010-06-25 03:04:15 --> Output Class Initialized
DEBUG - 2010-06-25 03:04:15 --> Input Class Initialized
DEBUG - 2010-06-25 03:04:15 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 03:04:15 --> Language Class Initialized
DEBUG - 2010-06-25 03:04:15 --> Loader Class Initialized
DEBUG - 2010-06-25 03:04:15 --> Helper loaded: object_helper
DEBUG - 2010-06-25 03:04:15 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 03:04:15 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:04:15 --> Session Class Initialized
DEBUG - 2010-06-25 03:04:15 --> Helper loaded: string_helper
DEBUG - 2010-06-25 03:04:15 --> Session routines successfully run
DEBUG - 2010-06-25 03:04:15 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:04:15 --> Controller Class Initialized
DEBUG - 2010-06-25 03:04:15 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 03:04:15 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 03:04:15 --> Database Driver Class Initialized
DEBUG - 2010-06-25 03:04:15 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-25 03:04:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:04:15 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-25 03:04:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:04:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:04:15 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 03:04:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:04:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:04:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:04:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:04:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:04:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:04:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:04:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:04:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:04:15 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 03:04:15 --> Final output sent to browser
DEBUG - 2010-06-25 03:04:15 --> Total execution time: 0.3233
DEBUG - 2010-06-25 03:07:33 --> Config Class Initialized
DEBUG - 2010-06-25 03:07:33 --> Hooks Class Initialized
DEBUG - 2010-06-25 03:07:33 --> URI Class Initialized
DEBUG - 2010-06-25 03:07:33 --> Router Class Initialized
DEBUG - 2010-06-25 03:07:33 --> Output Class Initialized
DEBUG - 2010-06-25 03:07:33 --> Input Class Initialized
DEBUG - 2010-06-25 03:07:33 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 03:07:33 --> Language Class Initialized
DEBUG - 2010-06-25 03:07:33 --> Loader Class Initialized
DEBUG - 2010-06-25 03:07:33 --> Helper loaded: object_helper
DEBUG - 2010-06-25 03:07:33 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 03:07:33 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:07:33 --> Session Class Initialized
DEBUG - 2010-06-25 03:07:33 --> Helper loaded: string_helper
DEBUG - 2010-06-25 03:07:33 --> Session routines successfully run
DEBUG - 2010-06-25 03:07:33 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:07:33 --> Controller Class Initialized
DEBUG - 2010-06-25 03:07:33 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 03:07:33 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 03:07:33 --> Database Driver Class Initialized
DEBUG - 2010-06-25 03:07:33 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-25 03:07:33 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:33 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-25 03:07:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:33 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:33 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 03:07:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:33 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:33 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:34 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:34 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:34 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 03:07:34 --> Final output sent to browser
DEBUG - 2010-06-25 03:07:34 --> Total execution time: 0.4175
DEBUG - 2010-06-25 03:07:37 --> Config Class Initialized
DEBUG - 2010-06-25 03:07:37 --> Hooks Class Initialized
DEBUG - 2010-06-25 03:07:37 --> URI Class Initialized
DEBUG - 2010-06-25 03:07:37 --> Router Class Initialized
DEBUG - 2010-06-25 03:07:37 --> Output Class Initialized
DEBUG - 2010-06-25 03:07:37 --> Input Class Initialized
DEBUG - 2010-06-25 03:07:37 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 03:07:37 --> Language Class Initialized
DEBUG - 2010-06-25 03:07:37 --> Loader Class Initialized
DEBUG - 2010-06-25 03:07:37 --> Helper loaded: object_helper
DEBUG - 2010-06-25 03:07:37 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 03:07:37 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:07:37 --> Session Class Initialized
DEBUG - 2010-06-25 03:07:37 --> Helper loaded: string_helper
DEBUG - 2010-06-25 03:07:37 --> Session routines successfully run
DEBUG - 2010-06-25 03:07:37 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:07:37 --> Controller Class Initialized
DEBUG - 2010-06-25 03:07:37 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 03:07:37 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 03:07:37 --> Database Driver Class Initialized
DEBUG - 2010-06-25 03:07:38 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-25 03:07:38 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:38 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-25 03:07:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:38 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:38 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 03:07:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:38 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:38 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:38 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:38 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 03:07:38 --> Final output sent to browser
DEBUG - 2010-06-25 03:07:38 --> Total execution time: 0.3792
DEBUG - 2010-06-25 03:07:39 --> Config Class Initialized
DEBUG - 2010-06-25 03:07:39 --> Hooks Class Initialized
DEBUG - 2010-06-25 03:07:39 --> URI Class Initialized
DEBUG - 2010-06-25 03:07:39 --> Router Class Initialized
DEBUG - 2010-06-25 03:07:39 --> Output Class Initialized
DEBUG - 2010-06-25 03:07:39 --> Input Class Initialized
DEBUG - 2010-06-25 03:07:39 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 03:07:39 --> Language Class Initialized
DEBUG - 2010-06-25 03:07:39 --> Loader Class Initialized
DEBUG - 2010-06-25 03:07:39 --> Helper loaded: object_helper
DEBUG - 2010-06-25 03:07:39 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 03:07:39 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:07:39 --> Session Class Initialized
DEBUG - 2010-06-25 03:07:39 --> Helper loaded: string_helper
DEBUG - 2010-06-25 03:07:39 --> Session routines successfully run
DEBUG - 2010-06-25 03:07:39 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:07:39 --> Controller Class Initialized
DEBUG - 2010-06-25 03:07:39 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 03:07:39 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 03:07:39 --> Database Driver Class Initialized
DEBUG - 2010-06-25 03:07:39 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-25 03:07:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:39 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-25 03:07:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:39 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 03:07:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:39 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 03:07:39 --> Final output sent to browser
DEBUG - 2010-06-25 03:07:39 --> Total execution time: 0.4032
DEBUG - 2010-06-25 03:07:40 --> Config Class Initialized
DEBUG - 2010-06-25 03:07:40 --> Hooks Class Initialized
DEBUG - 2010-06-25 03:07:40 --> URI Class Initialized
DEBUG - 2010-06-25 03:07:40 --> Router Class Initialized
DEBUG - 2010-06-25 03:07:40 --> Output Class Initialized
DEBUG - 2010-06-25 03:07:40 --> Input Class Initialized
DEBUG - 2010-06-25 03:07:40 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 03:07:40 --> Language Class Initialized
DEBUG - 2010-06-25 03:07:40 --> Loader Class Initialized
DEBUG - 2010-06-25 03:07:40 --> Helper loaded: object_helper
DEBUG - 2010-06-25 03:07:40 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 03:07:40 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:07:40 --> Session Class Initialized
DEBUG - 2010-06-25 03:07:40 --> Helper loaded: string_helper
DEBUG - 2010-06-25 03:07:40 --> Session routines successfully run
DEBUG - 2010-06-25 03:07:40 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:07:40 --> Controller Class Initialized
DEBUG - 2010-06-25 03:07:40 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 03:07:40 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 03:07:40 --> Database Driver Class Initialized
DEBUG - 2010-06-25 03:07:40 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-25 03:07:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:40 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-25 03:07:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:40 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 03:07:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:40 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 03:07:40 --> Final output sent to browser
DEBUG - 2010-06-25 03:07:40 --> Total execution time: 0.4327
DEBUG - 2010-06-25 03:07:41 --> Config Class Initialized
DEBUG - 2010-06-25 03:07:41 --> Hooks Class Initialized
DEBUG - 2010-06-25 03:07:41 --> URI Class Initialized
DEBUG - 2010-06-25 03:07:41 --> Router Class Initialized
DEBUG - 2010-06-25 03:07:41 --> Output Class Initialized
DEBUG - 2010-06-25 03:07:41 --> Input Class Initialized
DEBUG - 2010-06-25 03:07:41 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 03:07:41 --> Language Class Initialized
DEBUG - 2010-06-25 03:07:41 --> Loader Class Initialized
DEBUG - 2010-06-25 03:07:41 --> Helper loaded: object_helper
DEBUG - 2010-06-25 03:07:41 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 03:07:41 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:07:41 --> Session Class Initialized
DEBUG - 2010-06-25 03:07:41 --> Helper loaded: string_helper
DEBUG - 2010-06-25 03:07:41 --> Session routines successfully run
DEBUG - 2010-06-25 03:07:41 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:07:41 --> Controller Class Initialized
DEBUG - 2010-06-25 03:07:41 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 03:07:41 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 03:07:41 --> Database Driver Class Initialized
DEBUG - 2010-06-25 03:07:41 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-25 03:07:41 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:41 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-25 03:07:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:41 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:41 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 03:07:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:41 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:41 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:41 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:41 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:07:41 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 03:07:41 --> Final output sent to browser
DEBUG - 2010-06-25 03:07:41 --> Total execution time: 0.4692
DEBUG - 2010-06-25 03:09:47 --> Config Class Initialized
DEBUG - 2010-06-25 03:09:47 --> Hooks Class Initialized
DEBUG - 2010-06-25 03:09:47 --> URI Class Initialized
DEBUG - 2010-06-25 03:09:47 --> Router Class Initialized
DEBUG - 2010-06-25 03:09:47 --> Output Class Initialized
DEBUG - 2010-06-25 03:09:47 --> Input Class Initialized
DEBUG - 2010-06-25 03:09:47 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 03:09:47 --> Language Class Initialized
DEBUG - 2010-06-25 03:09:47 --> Loader Class Initialized
DEBUG - 2010-06-25 03:09:47 --> Helper loaded: object_helper
DEBUG - 2010-06-25 03:09:47 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 03:09:47 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:09:47 --> Session Class Initialized
DEBUG - 2010-06-25 03:09:47 --> Helper loaded: string_helper
DEBUG - 2010-06-25 03:09:47 --> Session routines successfully run
DEBUG - 2010-06-25 03:09:47 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:09:47 --> Controller Class Initialized
DEBUG - 2010-06-25 03:09:47 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 03:09:47 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 03:09:47 --> Database Driver Class Initialized
DEBUG - 2010-06-25 03:09:47 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-25 03:09:47 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:47 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-25 03:09:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:47 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:47 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 03:09:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:47 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:47 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:47 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:47 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:47 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 03:09:47 --> Final output sent to browser
DEBUG - 2010-06-25 03:09:47 --> Total execution time: 0.5165
DEBUG - 2010-06-25 03:09:48 --> Config Class Initialized
DEBUG - 2010-06-25 03:09:48 --> Hooks Class Initialized
DEBUG - 2010-06-25 03:09:48 --> URI Class Initialized
DEBUG - 2010-06-25 03:09:48 --> Router Class Initialized
DEBUG - 2010-06-25 03:09:48 --> Output Class Initialized
DEBUG - 2010-06-25 03:09:48 --> Input Class Initialized
DEBUG - 2010-06-25 03:09:48 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 03:09:48 --> Language Class Initialized
DEBUG - 2010-06-25 03:09:48 --> Loader Class Initialized
DEBUG - 2010-06-25 03:09:48 --> Helper loaded: object_helper
DEBUG - 2010-06-25 03:09:48 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 03:09:48 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:09:48 --> Session Class Initialized
DEBUG - 2010-06-25 03:09:48 --> Helper loaded: string_helper
DEBUG - 2010-06-25 03:09:48 --> Session routines successfully run
DEBUG - 2010-06-25 03:09:48 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:09:48 --> Controller Class Initialized
DEBUG - 2010-06-25 03:09:48 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 03:09:48 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 03:09:48 --> Database Driver Class Initialized
DEBUG - 2010-06-25 03:09:48 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-25 03:09:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:48 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-25 03:09:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:48 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 03:09:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:48 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 03:09:49 --> Final output sent to browser
DEBUG - 2010-06-25 03:09:49 --> Total execution time: 0.5276
DEBUG - 2010-06-25 03:09:49 --> Config Class Initialized
DEBUG - 2010-06-25 03:09:49 --> Hooks Class Initialized
DEBUG - 2010-06-25 03:09:49 --> URI Class Initialized
DEBUG - 2010-06-25 03:09:50 --> Router Class Initialized
DEBUG - 2010-06-25 03:09:50 --> Output Class Initialized
DEBUG - 2010-06-25 03:09:50 --> Input Class Initialized
DEBUG - 2010-06-25 03:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 03:09:50 --> Language Class Initialized
DEBUG - 2010-06-25 03:09:50 --> Loader Class Initialized
DEBUG - 2010-06-25 03:09:50 --> Helper loaded: object_helper
DEBUG - 2010-06-25 03:09:50 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 03:09:50 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:09:50 --> Session Class Initialized
DEBUG - 2010-06-25 03:09:50 --> Helper loaded: string_helper
DEBUG - 2010-06-25 03:09:50 --> Session routines successfully run
DEBUG - 2010-06-25 03:09:50 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:09:50 --> Controller Class Initialized
DEBUG - 2010-06-25 03:09:50 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 03:09:50 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 03:09:50 --> Database Driver Class Initialized
DEBUG - 2010-06-25 03:09:50 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-25 03:09:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:50 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-25 03:09:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:50 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 03:09:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:50 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:50 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:50 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 03:09:50 --> Final output sent to browser
DEBUG - 2010-06-25 03:09:50 --> Total execution time: 0.5900
DEBUG - 2010-06-25 03:09:51 --> Config Class Initialized
DEBUG - 2010-06-25 03:09:51 --> Hooks Class Initialized
DEBUG - 2010-06-25 03:09:51 --> URI Class Initialized
DEBUG - 2010-06-25 03:09:51 --> Router Class Initialized
DEBUG - 2010-06-25 03:09:51 --> Output Class Initialized
DEBUG - 2010-06-25 03:09:51 --> Input Class Initialized
DEBUG - 2010-06-25 03:09:51 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 03:09:51 --> Language Class Initialized
DEBUG - 2010-06-25 03:09:51 --> Loader Class Initialized
DEBUG - 2010-06-25 03:09:51 --> Helper loaded: object_helper
DEBUG - 2010-06-25 03:09:51 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 03:09:51 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:09:51 --> Session Class Initialized
DEBUG - 2010-06-25 03:09:51 --> Helper loaded: string_helper
DEBUG - 2010-06-25 03:09:51 --> Session routines successfully run
DEBUG - 2010-06-25 03:09:51 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:09:51 --> Controller Class Initialized
DEBUG - 2010-06-25 03:09:51 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 03:09:51 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 03:09:51 --> Database Driver Class Initialized
DEBUG - 2010-06-25 03:09:51 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-25 03:09:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:51 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-25 03:09:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:51 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 03:09:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:51 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 03:09:51 --> Final output sent to browser
DEBUG - 2010-06-25 03:09:51 --> Total execution time: 0.6358
DEBUG - 2010-06-25 03:09:52 --> Config Class Initialized
DEBUG - 2010-06-25 03:09:52 --> Hooks Class Initialized
DEBUG - 2010-06-25 03:09:52 --> URI Class Initialized
DEBUG - 2010-06-25 03:09:52 --> Router Class Initialized
DEBUG - 2010-06-25 03:09:52 --> Output Class Initialized
DEBUG - 2010-06-25 03:09:52 --> Input Class Initialized
DEBUG - 2010-06-25 03:09:52 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 03:09:52 --> Language Class Initialized
DEBUG - 2010-06-25 03:09:52 --> Loader Class Initialized
DEBUG - 2010-06-25 03:09:52 --> Helper loaded: object_helper
DEBUG - 2010-06-25 03:09:52 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 03:09:52 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:09:52 --> Session Class Initialized
DEBUG - 2010-06-25 03:09:52 --> Helper loaded: string_helper
DEBUG - 2010-06-25 03:09:52 --> Session routines successfully run
DEBUG - 2010-06-25 03:09:52 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:09:52 --> Controller Class Initialized
DEBUG - 2010-06-25 03:09:52 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 03:09:52 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 03:09:52 --> Database Driver Class Initialized
DEBUG - 2010-06-25 03:09:52 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-25 03:09:52 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:52 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-25 03:09:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:52 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:52 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 03:09:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:52 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:52 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:52 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:52 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:09:52 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 03:09:52 --> Final output sent to browser
DEBUG - 2010-06-25 03:09:52 --> Total execution time: 0.6518
DEBUG - 2010-06-25 03:10:26 --> Config Class Initialized
DEBUG - 2010-06-25 03:10:26 --> Hooks Class Initialized
DEBUG - 2010-06-25 03:10:26 --> URI Class Initialized
DEBUG - 2010-06-25 03:10:26 --> Router Class Initialized
DEBUG - 2010-06-25 03:10:26 --> Output Class Initialized
DEBUG - 2010-06-25 03:10:26 --> Input Class Initialized
DEBUG - 2010-06-25 03:10:26 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 03:10:26 --> Language Class Initialized
DEBUG - 2010-06-25 03:10:26 --> Loader Class Initialized
DEBUG - 2010-06-25 03:10:26 --> Helper loaded: object_helper
DEBUG - 2010-06-25 03:10:26 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 03:10:26 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:10:26 --> Session Class Initialized
DEBUG - 2010-06-25 03:10:26 --> Helper loaded: string_helper
DEBUG - 2010-06-25 03:10:26 --> Session routines successfully run
DEBUG - 2010-06-25 03:10:26 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:10:26 --> Controller Class Initialized
DEBUG - 2010-06-25 03:10:26 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 03:10:26 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 03:10:26 --> Database Driver Class Initialized
DEBUG - 2010-06-25 03:10:26 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-25 03:10:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:10:26 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-25 03:10:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:10:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:10:26 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 03:10:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:10:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:10:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:10:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:10:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:10:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:10:26 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:10:26 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:10:27 --> User class already loaded. Second attempt ignored.
ERROR - 2010-06-25 03:10:27 --> Severity: Warning  --> array_key_exists() [<a href='function.array-key-exists'>function.array-key-exists</a>]: The first argument should be either a string or an integer D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\Group.php 388
ERROR - 2010-06-25 03:10:27 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\Group.php 389
DEBUG - 2010-06-25 03:10:27 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:10:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:10:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:10:27 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:10:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:10:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:10:27 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:10:27 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:10:27 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:10:27 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:10:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:10:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:10:27 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:10:27 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:10:27 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:10:27 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 03:10:27 --> Final output sent to browser
DEBUG - 2010-06-25 03:10:27 --> Total execution time: 1.0448
DEBUG - 2010-06-25 03:15:11 --> Config Class Initialized
DEBUG - 2010-06-25 03:15:11 --> Hooks Class Initialized
DEBUG - 2010-06-25 03:15:11 --> URI Class Initialized
DEBUG - 2010-06-25 03:15:11 --> Router Class Initialized
DEBUG - 2010-06-25 03:15:11 --> Output Class Initialized
DEBUG - 2010-06-25 03:15:11 --> Input Class Initialized
DEBUG - 2010-06-25 03:15:11 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 03:15:11 --> Language Class Initialized
DEBUG - 2010-06-25 03:15:11 --> Loader Class Initialized
DEBUG - 2010-06-25 03:15:11 --> Helper loaded: object_helper
DEBUG - 2010-06-25 03:15:11 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 03:15:11 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:15:11 --> Session Class Initialized
DEBUG - 2010-06-25 03:15:11 --> Helper loaded: string_helper
DEBUG - 2010-06-25 03:15:11 --> Session routines successfully run
DEBUG - 2010-06-25 03:15:11 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:15:11 --> Controller Class Initialized
DEBUG - 2010-06-25 03:15:11 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 03:15:11 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 03:15:11 --> Database Driver Class Initialized
DEBUG - 2010-06-25 03:15:12 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-25 03:15:12 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:15:12 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-25 03:15:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:15:12 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:15:12 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 03:15:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:15:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:15:12 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:15:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:15:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:15:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:15:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:15:12 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:15:12 --> User class already loaded. Second attempt ignored.
ERROR - 2010-06-25 03:15:12 --> Severity: Warning  --> array_key_exists() [<a href='function.array-key-exists'>function.array-key-exists</a>]: The first argument should be either a string or an integer D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\Group.php 388
ERROR - 2010-06-25 03:15:12 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\libraries\kals_actor\Group.php 389
DEBUG - 2010-06-25 03:15:12 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:15:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:15:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:15:12 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:15:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:15:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:15:12 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:15:12 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:15:12 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:15:12 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:15:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:15:12 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:15:12 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:15:12 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:15:12 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:15:12 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 03:15:12 --> Final output sent to browser
DEBUG - 2010-06-25 03:15:12 --> Total execution time: 1.0932
DEBUG - 2010-06-25 03:19:30 --> Config Class Initialized
DEBUG - 2010-06-25 03:19:30 --> Hooks Class Initialized
DEBUG - 2010-06-25 03:19:30 --> URI Class Initialized
DEBUG - 2010-06-25 03:19:30 --> Router Class Initialized
DEBUG - 2010-06-25 03:19:30 --> Output Class Initialized
DEBUG - 2010-06-25 03:19:30 --> Input Class Initialized
DEBUG - 2010-06-25 03:19:31 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 03:19:31 --> Language Class Initialized
DEBUG - 2010-06-25 03:19:31 --> Loader Class Initialized
DEBUG - 2010-06-25 03:19:31 --> Helper loaded: object_helper
DEBUG - 2010-06-25 03:19:31 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 03:19:31 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:19:31 --> Session Class Initialized
DEBUG - 2010-06-25 03:19:31 --> Helper loaded: string_helper
DEBUG - 2010-06-25 03:19:31 --> Session routines successfully run
DEBUG - 2010-06-25 03:19:31 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:19:31 --> Controller Class Initialized
DEBUG - 2010-06-25 03:19:31 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 03:19:31 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 03:19:31 --> Database Driver Class Initialized
DEBUG - 2010-06-25 03:19:31 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-25 03:19:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:19:31 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-25 03:19:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:19:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:19:31 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 03:19:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:19:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:19:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:19:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:19:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:19:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:19:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:19:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:19:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:19:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:19:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:19:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:19:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:19:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:19:31 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:19:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:19:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:19:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:19:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:19:31 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:19:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:19:31 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:19:31 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 03:19:32 --> Final output sent to browser
DEBUG - 2010-06-25 03:19:32 --> Total execution time: 1.1367
DEBUG - 2010-06-25 03:22:57 --> Config Class Initialized
DEBUG - 2010-06-25 03:22:57 --> Hooks Class Initialized
DEBUG - 2010-06-25 03:22:58 --> URI Class Initialized
DEBUG - 2010-06-25 03:22:58 --> Router Class Initialized
DEBUG - 2010-06-25 03:22:58 --> Output Class Initialized
DEBUG - 2010-06-25 03:22:58 --> Input Class Initialized
DEBUG - 2010-06-25 03:22:58 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 03:22:58 --> Language Class Initialized
DEBUG - 2010-06-25 03:22:58 --> Loader Class Initialized
DEBUG - 2010-06-25 03:22:58 --> Helper loaded: object_helper
DEBUG - 2010-06-25 03:22:58 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 03:22:58 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:22:58 --> Session Class Initialized
DEBUG - 2010-06-25 03:22:58 --> Helper loaded: string_helper
DEBUG - 2010-06-25 03:22:58 --> Session routines successfully run
DEBUG - 2010-06-25 03:22:58 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:22:58 --> Controller Class Initialized
DEBUG - 2010-06-25 03:22:58 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 03:22:58 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 03:22:58 --> Database Driver Class Initialized
DEBUG - 2010-06-25 03:22:58 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-25 03:22:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:22:58 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-25 03:22:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:22:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:22:58 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 03:22:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:22:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:22:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:22:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:22:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:22:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:22:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:22:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:22:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:22:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:22:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:22:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:22:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:22:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:22:58 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:22:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:22:58 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:22:58 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:22:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:22:59 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:22:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:22:59 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:22:59 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 03:22:59 --> Final output sent to browser
DEBUG - 2010-06-25 03:22:59 --> Total execution time: 1.1681
DEBUG - 2010-06-25 03:24:28 --> Config Class Initialized
DEBUG - 2010-06-25 03:24:28 --> Hooks Class Initialized
DEBUG - 2010-06-25 03:24:28 --> URI Class Initialized
DEBUG - 2010-06-25 03:24:28 --> Router Class Initialized
DEBUG - 2010-06-25 03:24:28 --> Output Class Initialized
DEBUG - 2010-06-25 03:24:28 --> Input Class Initialized
DEBUG - 2010-06-25 03:24:28 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 03:24:28 --> Language Class Initialized
DEBUG - 2010-06-25 03:24:28 --> Loader Class Initialized
DEBUG - 2010-06-25 03:24:28 --> Helper loaded: object_helper
DEBUG - 2010-06-25 03:24:28 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 03:24:28 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:24:28 --> Session Class Initialized
DEBUG - 2010-06-25 03:24:28 --> Helper loaded: string_helper
DEBUG - 2010-06-25 03:24:28 --> Session routines successfully run
DEBUG - 2010-06-25 03:24:28 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:24:28 --> Controller Class Initialized
DEBUG - 2010-06-25 03:24:28 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 03:24:28 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 03:24:28 --> Database Driver Class Initialized
DEBUG - 2010-06-25 03:24:28 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-25 03:24:28 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:24:29 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-25 03:24:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:24:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:24:29 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 03:24:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:24:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:24:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:24:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:24:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:24:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:24:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:24:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:24:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:24:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:24:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:24:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:24:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:24:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:24:29 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:24:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:24:29 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:24:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:24:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:24:29 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:24:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:24:29 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:24:29 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 03:24:29 --> Final output sent to browser
DEBUG - 2010-06-25 03:24:29 --> Total execution time: 1.1995
DEBUG - 2010-06-25 03:25:03 --> Config Class Initialized
DEBUG - 2010-06-25 03:25:03 --> Hooks Class Initialized
DEBUG - 2010-06-25 03:25:03 --> URI Class Initialized
DEBUG - 2010-06-25 03:25:03 --> Router Class Initialized
DEBUG - 2010-06-25 03:25:03 --> Output Class Initialized
DEBUG - 2010-06-25 03:25:03 --> Input Class Initialized
DEBUG - 2010-06-25 03:25:03 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 03:25:03 --> Language Class Initialized
DEBUG - 2010-06-25 03:25:03 --> Loader Class Initialized
DEBUG - 2010-06-25 03:25:03 --> Helper loaded: object_helper
DEBUG - 2010-06-25 03:25:03 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 03:25:03 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:25:03 --> Session Class Initialized
DEBUG - 2010-06-25 03:25:03 --> Helper loaded: string_helper
DEBUG - 2010-06-25 03:25:04 --> Session routines successfully run
DEBUG - 2010-06-25 03:25:04 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:25:04 --> Controller Class Initialized
DEBUG - 2010-06-25 03:25:04 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 03:25:04 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 03:25:04 --> Database Driver Class Initialized
DEBUG - 2010-06-25 03:25:04 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-25 03:25:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:04 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-25 03:25:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:04 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 03:25:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:04 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:04 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:04 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:04 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:04 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 03:25:04 --> Final output sent to browser
DEBUG - 2010-06-25 03:25:04 --> Total execution time: 1.2420
DEBUG - 2010-06-25 03:25:55 --> Config Class Initialized
DEBUG - 2010-06-25 03:25:55 --> Hooks Class Initialized
DEBUG - 2010-06-25 03:25:55 --> URI Class Initialized
DEBUG - 2010-06-25 03:25:55 --> Router Class Initialized
DEBUG - 2010-06-25 03:25:55 --> Output Class Initialized
DEBUG - 2010-06-25 03:25:55 --> Input Class Initialized
DEBUG - 2010-06-25 03:25:55 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 03:25:55 --> Language Class Initialized
DEBUG - 2010-06-25 03:25:55 --> Loader Class Initialized
DEBUG - 2010-06-25 03:25:55 --> Helper loaded: object_helper
DEBUG - 2010-06-25 03:25:55 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 03:25:55 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:25:55 --> Session Class Initialized
DEBUG - 2010-06-25 03:25:55 --> Helper loaded: string_helper
DEBUG - 2010-06-25 03:25:55 --> Session routines successfully run
DEBUG - 2010-06-25 03:25:55 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:25:55 --> Controller Class Initialized
DEBUG - 2010-06-25 03:25:55 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 03:25:56 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 03:25:56 --> Database Driver Class Initialized
DEBUG - 2010-06-25 03:25:56 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-25 03:25:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:56 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-25 03:25:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:56 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 03:25:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:56 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:56 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:56 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:25:56 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 03:25:56 --> Final output sent to browser
DEBUG - 2010-06-25 03:25:56 --> Total execution time: 1.3342
DEBUG - 2010-06-25 03:26:47 --> Config Class Initialized
DEBUG - 2010-06-25 03:26:47 --> Hooks Class Initialized
DEBUG - 2010-06-25 03:26:47 --> URI Class Initialized
DEBUG - 2010-06-25 03:26:47 --> Router Class Initialized
DEBUG - 2010-06-25 03:26:47 --> Output Class Initialized
DEBUG - 2010-06-25 03:26:47 --> Input Class Initialized
DEBUG - 2010-06-25 03:26:47 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 03:26:47 --> Language Class Initialized
DEBUG - 2010-06-25 03:26:47 --> Loader Class Initialized
DEBUG - 2010-06-25 03:26:47 --> Helper loaded: object_helper
DEBUG - 2010-06-25 03:26:47 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 03:26:47 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:26:47 --> Session Class Initialized
DEBUG - 2010-06-25 03:26:47 --> Helper loaded: string_helper
DEBUG - 2010-06-25 03:26:47 --> Session routines successfully run
DEBUG - 2010-06-25 03:26:47 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:26:47 --> Controller Class Initialized
DEBUG - 2010-06-25 03:26:48 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 03:26:48 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 03:26:48 --> Database Driver Class Initialized
DEBUG - 2010-06-25 03:26:48 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-25 03:26:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:26:48 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-25 03:26:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:26:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:26:48 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 03:26:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:26:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:26:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:26:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:26:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:26:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:26:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:26:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:26:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:26:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:26:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:26:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:26:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:26:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:26:48 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:26:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:26:48 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:26:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:26:48 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:26:49 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:26:49 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:26:49 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:26:49 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 03:26:49 --> Final output sent to browser
DEBUG - 2010-06-25 03:26:49 --> Total execution time: 2.2559
DEBUG - 2010-06-25 03:27:37 --> Config Class Initialized
DEBUG - 2010-06-25 03:27:37 --> Hooks Class Initialized
DEBUG - 2010-06-25 03:27:37 --> URI Class Initialized
DEBUG - 2010-06-25 03:27:37 --> Router Class Initialized
DEBUG - 2010-06-25 03:27:37 --> Output Class Initialized
DEBUG - 2010-06-25 03:27:37 --> Input Class Initialized
DEBUG - 2010-06-25 03:27:37 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 03:27:37 --> Language Class Initialized
DEBUG - 2010-06-25 03:27:37 --> Loader Class Initialized
DEBUG - 2010-06-25 03:27:37 --> Helper loaded: object_helper
DEBUG - 2010-06-25 03:27:37 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 03:27:37 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:27:37 --> Session Class Initialized
DEBUG - 2010-06-25 03:27:37 --> Helper loaded: string_helper
DEBUG - 2010-06-25 03:27:37 --> Session routines successfully run
DEBUG - 2010-06-25 03:27:38 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:27:38 --> Controller Class Initialized
DEBUG - 2010-06-25 03:27:38 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 03:27:38 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 03:27:38 --> Database Driver Class Initialized
DEBUG - 2010-06-25 03:27:38 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-25 03:27:38 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:27:38 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-25 03:27:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:27:38 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:27:38 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 03:27:38 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:27:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:27:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:27:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:27:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:27:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:27:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:27:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:27:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:27:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:27:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:27:39 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:27:39 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:27:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:27:40 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:27:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:27:40 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:27:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:27:40 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:27:41 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:27:41 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:27:41 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:27:41 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 03:27:41 --> Final output sent to browser
DEBUG - 2010-06-25 03:27:41 --> Total execution time: 3.8888
DEBUG - 2010-06-25 03:28:24 --> Config Class Initialized
DEBUG - 2010-06-25 03:28:24 --> Hooks Class Initialized
DEBUG - 2010-06-25 03:28:24 --> URI Class Initialized
DEBUG - 2010-06-25 03:28:24 --> Router Class Initialized
DEBUG - 2010-06-25 03:28:24 --> Output Class Initialized
DEBUG - 2010-06-25 03:28:24 --> Input Class Initialized
DEBUG - 2010-06-25 03:28:24 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 03:28:24 --> Language Class Initialized
DEBUG - 2010-06-25 03:28:24 --> Loader Class Initialized
DEBUG - 2010-06-25 03:28:24 --> Helper loaded: object_helper
DEBUG - 2010-06-25 03:28:24 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 03:28:24 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:28:24 --> Session Class Initialized
DEBUG - 2010-06-25 03:28:24 --> Helper loaded: string_helper
DEBUG - 2010-06-25 03:28:24 --> Session routines successfully run
DEBUG - 2010-06-25 03:28:24 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:28:24 --> Controller Class Initialized
DEBUG - 2010-06-25 03:28:24 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 03:28:24 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 03:28:24 --> Database Driver Class Initialized
DEBUG - 2010-06-25 03:28:24 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-25 03:28:24 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:28:24 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-25 03:28:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:28:24 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:28:24 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 03:28:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:28:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:28:24 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:28:24 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:28:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:28:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:28:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:28:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:28:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:28:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:28:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:28:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:28:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:28:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:28:25 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:28:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:28:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:28:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:28:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:28:25 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:28:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:28:25 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:28:25 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 03:28:25 --> Final output sent to browser
DEBUG - 2010-06-25 03:28:25 --> Total execution time: 1.4911
DEBUG - 2010-06-25 03:30:16 --> Config Class Initialized
DEBUG - 2010-06-25 03:30:16 --> Hooks Class Initialized
DEBUG - 2010-06-25 03:30:17 --> URI Class Initialized
DEBUG - 2010-06-25 03:30:17 --> Router Class Initialized
DEBUG - 2010-06-25 03:30:17 --> Output Class Initialized
DEBUG - 2010-06-25 03:30:17 --> Input Class Initialized
DEBUG - 2010-06-25 03:30:17 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 03:30:17 --> Language Class Initialized
DEBUG - 2010-06-25 03:30:17 --> Loader Class Initialized
DEBUG - 2010-06-25 03:30:17 --> Helper loaded: object_helper
DEBUG - 2010-06-25 03:30:17 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 03:30:17 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:30:17 --> Session Class Initialized
DEBUG - 2010-06-25 03:30:17 --> Helper loaded: string_helper
DEBUG - 2010-06-25 03:30:17 --> Session routines successfully run
DEBUG - 2010-06-25 03:30:17 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:30:17 --> Controller Class Initialized
DEBUG - 2010-06-25 03:30:17 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 03:30:17 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 03:30:17 --> Database Driver Class Initialized
DEBUG - 2010-06-25 03:30:17 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-25 03:30:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:17 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-25 03:30:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:17 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 03:30:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:17 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:17 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:18 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:18 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:18 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:18 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:18 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 03:30:18 --> Final output sent to browser
DEBUG - 2010-06-25 03:30:18 --> Total execution time: 1.6059
DEBUG - 2010-06-25 03:30:50 --> Config Class Initialized
DEBUG - 2010-06-25 03:30:50 --> Hooks Class Initialized
DEBUG - 2010-06-25 03:30:50 --> URI Class Initialized
DEBUG - 2010-06-25 03:30:50 --> Router Class Initialized
DEBUG - 2010-06-25 03:30:50 --> Output Class Initialized
DEBUG - 2010-06-25 03:30:50 --> Input Class Initialized
DEBUG - 2010-06-25 03:30:50 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 03:30:50 --> Language Class Initialized
DEBUG - 2010-06-25 03:30:50 --> Loader Class Initialized
DEBUG - 2010-06-25 03:30:50 --> Helper loaded: object_helper
DEBUG - 2010-06-25 03:30:50 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 03:30:50 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:30:50 --> Session Class Initialized
DEBUG - 2010-06-25 03:30:51 --> Helper loaded: string_helper
DEBUG - 2010-06-25 03:30:51 --> Session routines successfully run
DEBUG - 2010-06-25 03:30:51 --> Helper loaded: context_helper
DEBUG - 2010-06-25 03:30:51 --> Controller Class Initialized
DEBUG - 2010-06-25 03:30:51 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 03:30:51 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 03:30:51 --> Database Driver Class Initialized
DEBUG - 2010-06-25 03:30:51 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-25 03:30:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:51 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-25 03:30:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:51 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 03:30:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:51 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:51 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:51 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:52 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:52 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:52 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:52 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:52 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 03:30:52 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 03:30:52 --> Final output sent to browser
DEBUG - 2010-06-25 03:30:52 --> Total execution time: 1.6181
DEBUG - 2010-06-25 08:10:14 --> Config Class Initialized
DEBUG - 2010-06-25 08:10:14 --> Hooks Class Initialized
DEBUG - 2010-06-25 08:10:14 --> URI Class Initialized
DEBUG - 2010-06-25 08:10:14 --> Router Class Initialized
DEBUG - 2010-06-25 08:10:14 --> Output Class Initialized
DEBUG - 2010-06-25 08:10:14 --> Input Class Initialized
DEBUG - 2010-06-25 08:10:14 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 08:10:14 --> Language Class Initialized
DEBUG - 2010-06-25 08:10:14 --> Loader Class Initialized
DEBUG - 2010-06-25 08:10:15 --> Helper loaded: object_helper
DEBUG - 2010-06-25 08:10:15 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 08:10:15 --> Helper loaded: context_helper
DEBUG - 2010-06-25 08:10:15 --> Session Class Initialized
DEBUG - 2010-06-25 08:10:15 --> Helper loaded: string_helper
DEBUG - 2010-06-25 08:10:15 --> A session cookie was not found.
DEBUG - 2010-06-25 08:10:15 --> Session routines successfully run
DEBUG - 2010-06-25 08:10:15 --> Helper loaded: context_helper
DEBUG - 2010-06-25 08:10:15 --> Controller Class Initialized
DEBUG - 2010-06-25 08:10:15 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 08:10:15 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 08:10:15 --> Database Driver Class Initialized
DEBUG - 2010-06-25 08:10:15 --> Language file loaded: language/zh_tw/kals_actor_lang.php
DEBUG - 2010-06-25 08:10:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 08:10:15 --> Language file loaded: language/zh_tw/kals_resource_lang.php
DEBUG - 2010-06-25 08:10:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 08:10:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 08:10:15 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 08:10:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 08:10:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 08:10:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 08:10:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 08:10:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 08:10:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 08:10:15 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 08:10:15 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 08:10:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 08:10:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 08:10:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 08:10:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 08:10:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 08:10:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 08:10:16 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 08:10:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 08:10:16 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 08:10:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 08:10:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 08:10:16 --> Group class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 08:10:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 08:10:16 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 08:10:16 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 08:10:16 --> Final output sent to browser
DEBUG - 2010-06-25 08:10:16 --> Total execution time: 1.9376
DEBUG - 2010-06-25 09:46:28 --> Config Class Initialized
DEBUG - 2010-06-25 09:46:28 --> Hooks Class Initialized
DEBUG - 2010-06-25 09:46:28 --> URI Class Initialized
ERROR - 2010-06-25 09:46:28 --> 404 Page Not Found --> ut_policy/ut_action
DEBUG - 2010-06-25 09:47:33 --> Config Class Initialized
DEBUG - 2010-06-25 09:47:33 --> Hooks Class Initialized
DEBUG - 2010-06-25 09:47:33 --> URI Class Initialized
DEBUG - 2010-06-25 09:47:33 --> Router Class Initialized
DEBUG - 2010-06-25 09:47:33 --> Output Class Initialized
DEBUG - 2010-06-25 09:47:33 --> Input Class Initialized
DEBUG - 2010-06-25 09:47:33 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 09:47:33 --> Language Class Initialized
DEBUG - 2010-06-25 09:47:33 --> Loader Class Initialized
DEBUG - 2010-06-25 09:47:33 --> Helper loaded: object_helper
DEBUG - 2010-06-25 09:47:34 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 09:47:34 --> Helper loaded: context_helper
DEBUG - 2010-06-25 09:47:34 --> Session Class Initialized
DEBUG - 2010-06-25 09:47:34 --> Helper loaded: string_helper
DEBUG - 2010-06-25 09:47:34 --> Session routines successfully run
DEBUG - 2010-06-25 09:47:34 --> Helper loaded: context_helper
DEBUG - 2010-06-25 09:47:34 --> Controller Class Initialized
DEBUG - 2010-06-25 09:47:34 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 09:47:34 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 09:48:11 --> Config Class Initialized
DEBUG - 2010-06-25 09:48:11 --> Hooks Class Initialized
DEBUG - 2010-06-25 09:48:11 --> URI Class Initialized
DEBUG - 2010-06-25 09:48:11 --> Router Class Initialized
DEBUG - 2010-06-25 09:48:11 --> Output Class Initialized
DEBUG - 2010-06-25 09:48:11 --> Input Class Initialized
DEBUG - 2010-06-25 09:48:11 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 09:48:11 --> Language Class Initialized
DEBUG - 2010-06-25 09:48:11 --> Loader Class Initialized
DEBUG - 2010-06-25 09:48:11 --> Helper loaded: object_helper
DEBUG - 2010-06-25 09:48:11 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 09:48:11 --> Helper loaded: context_helper
DEBUG - 2010-06-25 09:48:11 --> Session Class Initialized
DEBUG - 2010-06-25 09:48:11 --> Helper loaded: string_helper
DEBUG - 2010-06-25 09:48:11 --> Session routines successfully run
DEBUG - 2010-06-25 09:48:11 --> Helper loaded: context_helper
DEBUG - 2010-06-25 09:48:11 --> Controller Class Initialized
DEBUG - 2010-06-25 09:48:11 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 09:48:11 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 09:49:06 --> Config Class Initialized
DEBUG - 2010-06-25 09:49:06 --> Hooks Class Initialized
DEBUG - 2010-06-25 09:49:06 --> URI Class Initialized
DEBUG - 2010-06-25 09:49:06 --> Router Class Initialized
DEBUG - 2010-06-25 09:49:06 --> Output Class Initialized
DEBUG - 2010-06-25 09:49:06 --> Input Class Initialized
DEBUG - 2010-06-25 09:49:06 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 09:49:06 --> Language Class Initialized
DEBUG - 2010-06-25 09:49:07 --> Loader Class Initialized
DEBUG - 2010-06-25 09:49:07 --> Helper loaded: object_helper
DEBUG - 2010-06-25 09:49:07 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 09:49:07 --> Helper loaded: context_helper
DEBUG - 2010-06-25 09:49:07 --> Session Class Initialized
DEBUG - 2010-06-25 09:49:07 --> Helper loaded: string_helper
DEBUG - 2010-06-25 09:49:07 --> Session routines successfully run
DEBUG - 2010-06-25 09:49:07 --> Helper loaded: context_helper
DEBUG - 2010-06-25 09:49:07 --> Controller Class Initialized
DEBUG - 2010-06-25 09:49:07 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 09:49:07 --> Helper loaded: unit_test_helper
ERROR - 2010-06-25 09:49:07 --> Severity: Notice  --> Undefined variable: test_name D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_policy\ut_action.php 39
DEBUG - 2010-06-25 09:49:07 --> Language file loaded: language/zh_tw/unit_test_lang.php
ERROR - 2010-06-25 09:49:07 --> Severity: Notice  --> Undefined variable: test_name D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_policy\ut_action.php 45
ERROR - 2010-06-25 09:49:07 --> Severity: Notice  --> Undefined variable: test_name D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_policy\ut_action.php 51
DEBUG - 2010-06-25 09:49:07 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 09:49:07 --> Final output sent to browser
DEBUG - 2010-06-25 09:49:07 --> Total execution time: 0.8629
DEBUG - 2010-06-25 09:50:03 --> Config Class Initialized
DEBUG - 2010-06-25 09:50:03 --> Hooks Class Initialized
DEBUG - 2010-06-25 09:50:03 --> URI Class Initialized
DEBUG - 2010-06-25 09:50:03 --> Router Class Initialized
DEBUG - 2010-06-25 09:50:03 --> Output Class Initialized
DEBUG - 2010-06-25 09:50:03 --> Input Class Initialized
DEBUG - 2010-06-25 09:50:03 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 09:50:03 --> Language Class Initialized
DEBUG - 2010-06-25 09:50:03 --> Loader Class Initialized
DEBUG - 2010-06-25 09:50:03 --> Helper loaded: object_helper
DEBUG - 2010-06-25 09:50:03 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 09:50:03 --> Helper loaded: context_helper
DEBUG - 2010-06-25 09:50:04 --> Session Class Initialized
DEBUG - 2010-06-25 09:50:04 --> Helper loaded: string_helper
DEBUG - 2010-06-25 09:50:04 --> Session routines successfully run
DEBUG - 2010-06-25 09:50:04 --> Helper loaded: context_helper
DEBUG - 2010-06-25 09:50:04 --> Controller Class Initialized
DEBUG - 2010-06-25 09:50:04 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 09:50:04 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 09:50:04 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 09:50:04 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 09:50:04 --> Final output sent to browser
DEBUG - 2010-06-25 09:50:04 --> Total execution time: 0.7715
DEBUG - 2010-06-25 09:50:13 --> Config Class Initialized
DEBUG - 2010-06-25 09:50:14 --> Hooks Class Initialized
DEBUG - 2010-06-25 09:50:14 --> URI Class Initialized
DEBUG - 2010-06-25 09:50:14 --> Router Class Initialized
DEBUG - 2010-06-25 09:50:14 --> Output Class Initialized
DEBUG - 2010-06-25 09:50:14 --> Input Class Initialized
DEBUG - 2010-06-25 09:50:14 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 09:50:14 --> Language Class Initialized
DEBUG - 2010-06-25 09:50:14 --> Loader Class Initialized
DEBUG - 2010-06-25 09:50:14 --> Helper loaded: object_helper
DEBUG - 2010-06-25 09:50:14 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 09:50:14 --> Helper loaded: context_helper
DEBUG - 2010-06-25 09:50:14 --> Session Class Initialized
DEBUG - 2010-06-25 09:50:14 --> Helper loaded: string_helper
DEBUG - 2010-06-25 09:50:14 --> Session routines successfully run
DEBUG - 2010-06-25 09:50:14 --> Helper loaded: context_helper
DEBUG - 2010-06-25 09:50:14 --> Controller Class Initialized
DEBUG - 2010-06-25 09:50:14 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 09:50:14 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 09:50:14 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 09:50:14 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 09:50:14 --> Final output sent to browser
DEBUG - 2010-06-25 09:50:14 --> Total execution time: 0.7910
DEBUG - 2010-06-25 14:25:25 --> Config Class Initialized
DEBUG - 2010-06-25 14:25:25 --> Hooks Class Initialized
DEBUG - 2010-06-25 14:25:26 --> URI Class Initialized
DEBUG - 2010-06-25 14:25:26 --> Router Class Initialized
DEBUG - 2010-06-25 14:25:26 --> Output Class Initialized
DEBUG - 2010-06-25 14:25:26 --> Input Class Initialized
DEBUG - 2010-06-25 14:25:26 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 14:25:26 --> Language Class Initialized
DEBUG - 2010-06-25 14:25:26 --> Loader Class Initialized
DEBUG - 2010-06-25 14:25:26 --> Helper loaded: object_helper
DEBUG - 2010-06-25 14:25:26 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 14:25:26 --> Helper loaded: context_helper
DEBUG - 2010-06-25 14:25:26 --> Session Class Initialized
DEBUG - 2010-06-25 14:25:26 --> Helper loaded: string_helper
DEBUG - 2010-06-25 14:25:26 --> A session cookie was not found.
DEBUG - 2010-06-25 14:25:26 --> Session routines successfully run
DEBUG - 2010-06-25 14:25:26 --> Helper loaded: context_helper
DEBUG - 2010-06-25 14:25:26 --> Controller Class Initialized
DEBUG - 2010-06-25 14:25:26 --> Database Driver Class Initialized
DEBUG - 2010-06-25 14:25:26 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 14:25:26 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 14:25:27 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-25 14:25:27 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:25:27 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:25:27 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:25:27 --> Domain class already loaded. Second attempt ignored.
INFO  - 2010-06-25 14:25:27 --> Webpage Create: (15) /p/5zb6um#response-1672175356 PHP布丁 說 [CODING D7] 我得了一種不做Unit Test就無法安心，可是Test不過又大受打擊的病。 - #5zb6um
DEBUG - 2010-06-25 14:25:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:25:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:25:27 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:25:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:25:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:25:27 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:25:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:25:27 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:25:27 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:25:28 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 14:25:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:25:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:25:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:25:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:25:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:25:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:25:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:25:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:25:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:25:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
ERROR - 2010-06-25 14:25:28 --> Severity: Notice  --> Undefined variable: action D:\xampp\htdocs\CodeIgniter_1.7.2\system\application\controllers\ut_policy\ut_auth.php 131
DEBUG - 2010-06-25 14:25:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:25:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:25:28 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:26:08 --> Config Class Initialized
DEBUG - 2010-06-25 14:26:08 --> Hooks Class Initialized
DEBUG - 2010-06-25 14:26:08 --> URI Class Initialized
DEBUG - 2010-06-25 14:26:08 --> Router Class Initialized
DEBUG - 2010-06-25 14:26:08 --> Output Class Initialized
DEBUG - 2010-06-25 14:26:08 --> Input Class Initialized
DEBUG - 2010-06-25 14:26:08 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 14:26:08 --> Language Class Initialized
DEBUG - 2010-06-25 14:26:08 --> Loader Class Initialized
DEBUG - 2010-06-25 14:26:08 --> Helper loaded: object_helper
DEBUG - 2010-06-25 14:26:08 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 14:26:08 --> Helper loaded: context_helper
DEBUG - 2010-06-25 14:26:08 --> Session Class Initialized
DEBUG - 2010-06-25 14:26:08 --> Helper loaded: string_helper
DEBUG - 2010-06-25 14:26:09 --> Session routines successfully run
DEBUG - 2010-06-25 14:26:09 --> Helper loaded: context_helper
DEBUG - 2010-06-25 14:26:09 --> Controller Class Initialized
DEBUG - 2010-06-25 14:26:09 --> Database Driver Class Initialized
DEBUG - 2010-06-25 14:26:09 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 14:26:09 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 14:26:09 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-25 14:26:09 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:26:09 --> Action_factory class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:26:09 --> Webpage class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:26:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:26:09 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:26:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:26:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:26:09 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:26:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:26:09 --> Domain class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:26:09 --> User class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:26:09 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 14:26:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:26:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:26:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:26:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:26:09 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:26:10 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:26:10 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:26:10 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:26:10 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:26:10 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:26:10 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:26:10 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:26:10 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 14:26:10 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 16:13:17 --> Config Class Initialized
DEBUG - 2010-06-25 16:13:18 --> Hooks Class Initialized
DEBUG - 2010-06-25 16:13:18 --> URI Class Initialized
DEBUG - 2010-06-25 16:13:18 --> Router Class Initialized
DEBUG - 2010-06-25 16:13:18 --> Output Class Initialized
DEBUG - 2010-06-25 16:13:18 --> Input Class Initialized
DEBUG - 2010-06-25 16:13:18 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 16:13:18 --> Language Class Initialized
DEBUG - 2010-06-25 16:13:18 --> Loader Class Initialized
DEBUG - 2010-06-25 16:13:18 --> Helper loaded: object_helper
DEBUG - 2010-06-25 16:13:18 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 16:13:18 --> Helper loaded: context_helper
DEBUG - 2010-06-25 16:13:18 --> Session Class Initialized
DEBUG - 2010-06-25 16:13:18 --> Helper loaded: string_helper
DEBUG - 2010-06-25 16:13:18 --> Session routines successfully run
DEBUG - 2010-06-25 16:13:18 --> Helper loaded: context_helper
DEBUG - 2010-06-25 16:13:18 --> Controller Class Initialized
DEBUG - 2010-06-25 16:13:18 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 16:13:18 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 16:13:18 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 16:13:18 --> Database Driver Class Initialized
DEBUG - 2010-06-25 16:13:19 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-25 16:13:53 --> Config Class Initialized
DEBUG - 2010-06-25 16:13:53 --> Hooks Class Initialized
DEBUG - 2010-06-25 16:13:53 --> URI Class Initialized
DEBUG - 2010-06-25 16:13:53 --> Router Class Initialized
DEBUG - 2010-06-25 16:13:53 --> Output Class Initialized
DEBUG - 2010-06-25 16:13:53 --> Input Class Initialized
DEBUG - 2010-06-25 16:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 16:13:53 --> Language Class Initialized
DEBUG - 2010-06-25 16:13:53 --> Loader Class Initialized
DEBUG - 2010-06-25 16:13:53 --> Helper loaded: object_helper
DEBUG - 2010-06-25 16:13:53 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 16:13:53 --> Helper loaded: context_helper
DEBUG - 2010-06-25 16:13:53 --> Session Class Initialized
DEBUG - 2010-06-25 16:13:53 --> Helper loaded: string_helper
DEBUG - 2010-06-25 16:13:53 --> Session routines successfully run
DEBUG - 2010-06-25 16:13:53 --> Helper loaded: context_helper
DEBUG - 2010-06-25 16:13:53 --> Controller Class Initialized
DEBUG - 2010-06-25 16:13:53 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 16:13:53 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 16:13:53 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 16:13:53 --> Database Driver Class Initialized
DEBUG - 2010-06-25 16:13:54 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-25 16:13:54 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 16:13:54 --> Final output sent to browser
DEBUG - 2010-06-25 16:13:54 --> Total execution time: 0.9855
DEBUG - 2010-06-25 16:15:04 --> Config Class Initialized
DEBUG - 2010-06-25 16:15:04 --> Hooks Class Initialized
DEBUG - 2010-06-25 16:15:04 --> URI Class Initialized
DEBUG - 2010-06-25 16:15:04 --> Router Class Initialized
DEBUG - 2010-06-25 16:15:04 --> Output Class Initialized
DEBUG - 2010-06-25 16:15:04 --> Input Class Initialized
DEBUG - 2010-06-25 16:15:04 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 16:15:04 --> Language Class Initialized
DEBUG - 2010-06-25 16:15:04 --> Loader Class Initialized
DEBUG - 2010-06-25 16:15:04 --> Helper loaded: object_helper
DEBUG - 2010-06-25 16:15:04 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 16:15:04 --> Helper loaded: context_helper
DEBUG - 2010-06-25 16:15:04 --> Session Class Initialized
DEBUG - 2010-06-25 16:15:04 --> Helper loaded: string_helper
DEBUG - 2010-06-25 16:15:04 --> Session routines successfully run
DEBUG - 2010-06-25 16:15:04 --> Helper loaded: context_helper
DEBUG - 2010-06-25 16:15:04 --> Controller Class Initialized
DEBUG - 2010-06-25 16:15:04 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 16:15:04 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 16:15:04 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 16:15:04 --> Database Driver Class Initialized
DEBUG - 2010-06-25 16:15:04 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-25 16:15:05 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 16:15:05 --> Final output sent to browser
DEBUG - 2010-06-25 16:15:05 --> Total execution time: 1.0129
DEBUG - 2010-06-25 16:17:04 --> Config Class Initialized
DEBUG - 2010-06-25 16:17:04 --> Hooks Class Initialized
DEBUG - 2010-06-25 16:17:04 --> URI Class Initialized
DEBUG - 2010-06-25 16:17:04 --> Router Class Initialized
DEBUG - 2010-06-25 16:17:04 --> Output Class Initialized
DEBUG - 2010-06-25 16:17:04 --> Input Class Initialized
DEBUG - 2010-06-25 16:17:04 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 16:17:04 --> Language Class Initialized
DEBUG - 2010-06-25 16:17:04 --> Loader Class Initialized
DEBUG - 2010-06-25 16:17:04 --> Helper loaded: object_helper
DEBUG - 2010-06-25 16:17:04 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 16:17:04 --> Helper loaded: context_helper
DEBUG - 2010-06-25 16:17:04 --> Session Class Initialized
DEBUG - 2010-06-25 16:17:04 --> Helper loaded: string_helper
DEBUG - 2010-06-25 16:17:04 --> Session routines successfully run
DEBUG - 2010-06-25 16:17:04 --> Helper loaded: context_helper
DEBUG - 2010-06-25 16:17:05 --> Controller Class Initialized
DEBUG - 2010-06-25 16:17:05 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 16:17:05 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 16:17:05 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 16:17:05 --> Database Driver Class Initialized
DEBUG - 2010-06-25 16:17:05 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-25 16:17:05 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 16:17:05 --> Final output sent to browser
DEBUG - 2010-06-25 16:17:05 --> Total execution time: 1.0257
DEBUG - 2010-06-25 16:17:27 --> Config Class Initialized
DEBUG - 2010-06-25 16:17:27 --> Hooks Class Initialized
DEBUG - 2010-06-25 16:17:27 --> URI Class Initialized
DEBUG - 2010-06-25 16:17:27 --> Router Class Initialized
DEBUG - 2010-06-25 16:17:27 --> Output Class Initialized
DEBUG - 2010-06-25 16:17:27 --> Input Class Initialized
DEBUG - 2010-06-25 16:17:27 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 16:17:27 --> Language Class Initialized
DEBUG - 2010-06-25 16:17:27 --> Loader Class Initialized
DEBUG - 2010-06-25 16:17:27 --> Helper loaded: object_helper
DEBUG - 2010-06-25 16:17:27 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 16:17:27 --> Helper loaded: context_helper
DEBUG - 2010-06-25 16:17:27 --> Session Class Initialized
DEBUG - 2010-06-25 16:17:27 --> Helper loaded: string_helper
DEBUG - 2010-06-25 16:17:27 --> Session routines successfully run
DEBUG - 2010-06-25 16:17:27 --> Helper loaded: context_helper
DEBUG - 2010-06-25 16:17:28 --> Controller Class Initialized
DEBUG - 2010-06-25 16:17:28 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 16:17:28 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 16:17:28 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 16:17:28 --> Database Driver Class Initialized
DEBUG - 2010-06-25 16:17:28 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-25 16:17:28 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 16:17:28 --> Final output sent to browser
DEBUG - 2010-06-25 16:17:28 --> Total execution time: 1.0150
DEBUG - 2010-06-25 16:17:38 --> Config Class Initialized
DEBUG - 2010-06-25 16:17:38 --> Hooks Class Initialized
DEBUG - 2010-06-25 16:17:38 --> URI Class Initialized
DEBUG - 2010-06-25 16:17:38 --> Router Class Initialized
DEBUG - 2010-06-25 16:17:38 --> Output Class Initialized
DEBUG - 2010-06-25 16:17:38 --> Input Class Initialized
DEBUG - 2010-06-25 16:17:38 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 16:17:38 --> Language Class Initialized
DEBUG - 2010-06-25 16:17:38 --> Loader Class Initialized
DEBUG - 2010-06-25 16:17:38 --> Helper loaded: object_helper
DEBUG - 2010-06-25 16:17:38 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 16:17:38 --> Helper loaded: context_helper
DEBUG - 2010-06-25 16:17:38 --> Session Class Initialized
DEBUG - 2010-06-25 16:17:38 --> Helper loaded: string_helper
DEBUG - 2010-06-25 16:17:38 --> Session routines successfully run
DEBUG - 2010-06-25 16:17:38 --> Helper loaded: context_helper
DEBUG - 2010-06-25 16:17:38 --> Controller Class Initialized
DEBUG - 2010-06-25 16:17:39 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 16:17:39 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 16:17:39 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 16:17:39 --> Database Driver Class Initialized
DEBUG - 2010-06-25 16:17:39 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-25 16:17:39 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 16:17:39 --> Final output sent to browser
DEBUG - 2010-06-25 16:17:39 --> Total execution time: 1.0284
DEBUG - 2010-06-25 16:46:59 --> Config Class Initialized
DEBUG - 2010-06-25 16:46:59 --> Hooks Class Initialized
DEBUG - 2010-06-25 16:46:59 --> URI Class Initialized
DEBUG - 2010-06-25 16:46:59 --> Router Class Initialized
DEBUG - 2010-06-25 16:46:59 --> Output Class Initialized
DEBUG - 2010-06-25 16:46:59 --> Input Class Initialized
DEBUG - 2010-06-25 16:46:59 --> Global POST and COOKIE data sanitized
DEBUG - 2010-06-25 16:46:59 --> Language Class Initialized
DEBUG - 2010-06-25 16:46:59 --> Loader Class Initialized
DEBUG - 2010-06-25 16:46:59 --> Helper loaded: object_helper
DEBUG - 2010-06-25 16:46:59 --> Helper loaded: kals_helper
DEBUG - 2010-06-25 16:47:00 --> Helper loaded: context_helper
DEBUG - 2010-06-25 16:47:00 --> Session Class Initialized
DEBUG - 2010-06-25 16:47:00 --> Helper loaded: string_helper
DEBUG - 2010-06-25 16:47:00 --> Session routines successfully run
DEBUG - 2010-06-25 16:47:00 --> Helper loaded: context_helper
DEBUG - 2010-06-25 16:47:00 --> Controller Class Initialized
DEBUG - 2010-06-25 16:47:00 --> Unit Testing Class Initialized
DEBUG - 2010-06-25 16:47:00 --> Helper loaded: unit_test_helper
DEBUG - 2010-06-25 16:47:00 --> Language file loaded: language/zh_tw/unit_test_lang.php
DEBUG - 2010-06-25 16:47:00 --> Database Driver Class Initialized
DEBUG - 2010-06-25 16:47:00 --> Language file loaded: language/zh_tw/kals_lang.php
DEBUG - 2010-06-25 16:47:00 --> Action_domain_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 16:47:00 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 16:47:00 --> Action_annotation_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 16:47:00 --> Action_webpage_administration class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 16:47:00 --> Action_webpage_read class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 16:47:00 --> Action_webpage_recommend_show class already loaded. Second attempt ignored.
DEBUG - 2010-06-25 16:47:00 --> File loaded: D:\xampp\htdocs\CodeIgniter_1.7.2/system/application/views/misc/unit_test.php
DEBUG - 2010-06-25 16:47:00 --> Final output sent to browser
DEBUG - 2010-06-25 16:47:00 --> Total execution time: 1.3705
