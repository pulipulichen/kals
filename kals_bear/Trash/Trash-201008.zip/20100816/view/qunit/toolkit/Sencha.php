<?php
/**
 * jQTouch Unit Test
 *
 * @package             KALS
 * @category		Webpage Application QUnit
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/7/20 上午 12:17:29
 */

$title = 'jQTouch';
@load_scripts('jQTouch', $load_raw);
?>
  <link rel="stylesheet" href="http://192.168.11.2/CodeIgniter_1.7.2/js/ext-touch.css" type="text/css" /> 
  <script type="text/javascript" src="http://192.168.11.2/CodeIgniter_1.7.2/js/ext-touch-debug.js"></script> 
  
<script type="text/javascript">
QUNIT_TITLE = "<?= $title ?>";

//setup = function () {
//    $.getScript('http://192.168.11.2/CodeIgniter_1.7.2/js/ext-touch-debug.js', setup_ext);
//};

setup_onready = function () {
    
    alert('有沒有被覆寫？');
};

//setup_ext = function(){
Ext.setup({
    //icon: 'icon.png',
    //fullscreen: false,
    //addMetaTags: false,
    glossOnIcon: false,
    tabletStartupScreen: 'http://192.168.11.2/CodeIgniter_1.7.2/js/tablet_startup.png',
    phoneStartupScreen: 'http://192.168.11.2/CodeIgniter_1.7.2/js/phone_startup.png',
    onReady: function(){
        //alert('onReady');
         setup_onready = function(){
            Ext.TouchEventManager.enable = true;
            //Ext.setup({
            //    addMetaTags: true
            //});
            var overlayTb = new Ext.Toolbar({
                dock: 'top'
            });
            
            var overlay = new Ext.Panel({
                floating: true,
                modal: true,
                centered: false,
                width: Ext.platform.isPhone ? 260 : 400,
                height: Ext.platform.isPhone ? 220 : 400,
                styleHtmlContent: true,
                dockedItems: overlayTb,
                scroll: 'vertical',
                contentEl: 'lipsum',
                cls: 'htmlcontent'
            });
            
            var showOverlay = function(btn, event){
                overlay.setCentered(false);
                overlayTb.setTitle('Attached Overlay');
                overlay.showBy(btn);
            };
            
            var showCenteredOverlay = function(btn, event){
                overlay.setCentered(true);
                overlayTb.setTitle('Centered Overlay');
                overlay.show();
                
                overlay.addListener('hide', function () {
                    panel.destroy();
                    Ext.TouchEventManager.enable = false;
                });
                
                //$('.x-panel').remove();
                //panel.update();
            };
            
            if (Ext.platform.isPhone) {
                var dockedItems = [{
                    dock: 'top',
                    xtype: 'toolbar',
                    items: [{
                        text: 'showBy',
                        handler: showOverlay
                    }]
                }, {
                    dock: 'bottom',
                    xtype: 'toolbar',
                    items: [{
                        text: 'show (centered)',
                        handler: showCenteredOverlay
                    }, {
                        xtype: 'spacer'
                    }, {
                        text: 'showBy',
                        handler: showOverlay
                    }]
                }];
            }
            else {
                var dockedItems = [{
                    dock: 'top',
                    xtype: 'toolbar',
                    items: [{
                        text: 'showBy',
                        handler: showOverlay
                    }, {
                        xtype: 'spacer'
                    }, {
                        text: 'show (centered)',
                        handler: showCenteredOverlay
                    }, {
                        xtype: 'spacer'
                    }, {
                        text: 'showBy',
                        handler: showOverlay
                    }]
                }];
            }
            
            var panel = 
                new Ext.Panel({
                    fullscreen: true,
                    dockedItems: dockedItems,
                    html: "Test the overlay by using the buttons above."
                });
        }    //setup_ready
    }    //onReady: function(){
});

//}    //setup

</script>
<style type="text/css">



</style>

<br /><br /><br /><br />

  <div style="display: none;"> 
    <div id="lipsum"> 
      <p><em>This content is in a scrollable panel. It also makes use of the <code>htmlcontent</code> class, which will automatically apply some basic typography to the content. Some filler text:</em></p> 
      <h2>This is a title</h2> 
      <h3>This is a subhead</h3> 
      <p>This is some text of dubious character. Isn&rsquo;t the use
      of &ldquo;quotes&rdquo; just lazy writing&mdash;and theft of &lsquo;intellectual
      property&rsquo; besides? I think the time has come to see a block quote.</p> 
 
      <blockquote> 
        <p lang="fr" xml:lang="fr">This is a block quote. I&rsquo;ll admit it&rsquo;s not
        the most exciting block quote ever devised.</p> 
      </blockquote> 
 
      <p>Simple list:</p> 
 
      <ol style="color:blue;"> 
        <li>one</li> 
        <li>two</li> 
      </ol> 
 
      <ol> 
        <li>three
          <p>Multi-level list:</p> 
        </li> 
 
        <li>one
          <ol> 
            <li>aye</li> 
            <li>bee</li> 
          </ol> 
 
          <ol> 
            <li>see</li> 
            <li>two</li> 
            <li>x</li> 
          </ol> 
 
          <ol> 
            <li>y</li> 
          </ol> 
        </li> 
      </ol> 
 
      <ol> 
        <li>three
          <p>Mixed list:</p> 
          <ul> 
            <li>Point one</li> 
            <li>Point two
              <ol> 
                <li>Step 1</li> 
                <li>Step 2</li> 
              </ol> 
            </li> 
 
            <li style="list-style: none; display: inline"> 
              <ol> 
                <li>Step 3</li> 
                <li>Point three
                  <ul> 
                    <li>Sub point 1</li> 
                  </ul> 
                </li> 
              </ol> 
            </li> 
          </ul> 
        </li> 
      </ol> 
 
      <ul> 
        <li>Sub point 2
          <p>Well, that went well. How about we insert an <a href="/" title=
          "watch out">old-fashioned hypertext link</a>? Will the quote marks in the tags
          get messed up? No!</p> 
 
          <p><a href="http://www.textism.com" title="optional title">This is a
          link</a></p> 
 
          <table style="border:1px solid black;"> 
            <tr> 
              <th>this</th> 
 
              <th>is</th> 
 
              <th>a</th> 
 
              <th>header</th> 
            </tr> 
 
            <tr style="background:gray;text-align:left;"> 
              <td colspan="2">this is</td> 
 
              <td style="background:red;width:200px;">a</td> 
 
              <td style="vertical-align:top;height:200px;text-align:justify;">row</td> 
            </tr> 
 
            <tr> 
              <td>this</td> 
 
              <td style="padding:10px;text-align:justify;">is</td> 
 
              <td style="vertical-align:top;">another</td> 
 
              <td class="bob" id="bob">row</td> 
            </tr> 
          </table> 
 
          <p>An image:</p> 
 
          <p><img src="icon.png" title="optional alt text" alt="optional alt text" /></p> 
 
          <ol> 
            <li>Librarians rule</li> 
          </ol> 
        </li> 
      </ul> 
 
      <ul> 
        <li>Yes they do</li> 
 
        <li style="list-style: none; display: inline"> 
          <ol> 
            <li>But you knew that
 
              <p>Some more text of dubious character. Here is a noisome string of CAPITAL
              letters. Here is something we want to <em>emphasize</em>.<br /> 
              That was a linebreak. And something to indicate <strong>strength</strong>.
              Of course I could use <em>my own HTML tags</em> if I <strong>felt</strong> 
              like it.</p> 
 
              <h3>Coding</h3> 
 
              <p>This <code>is some code, "isn't it"</code>. Watch those quote marks! Now
              for some preformatted text:</p> 
              <pre> 
            <code> 
            $text = str_replace("&lt;p&gt;%::%&lt;/p&gt;","",$text);
            $text = str_replace("%::%&lt;/p&gt;","",$text);
            $text = str_replace("%::%","",$text);
 
            </code> 
            
</pre> 
 
              <p>This isn&rsquo;t code.</p> 
 
              <p>So you see, my friends:</p> 
 
              <ul> 
                <li>The time is now</li> 
 
                <li>The time is not later</li> 
 
                <li>The time is not yesterday</li> 
              </ul> 
            </li> 
          </ol> 
 
          <ul> 
            <li>We must act</li> 
          </ul> 
        </li> 
      </ul> 
    </div> 
  </div> 

<img src="http://img1.uploadscreenshot.com/images/orig/8/21409232974-orig.jpg" />
<div style="width: 1000px"><em>◆《仙境傳說》世界盃公開賽 台灣選手實力強</em><br /> <button onclick="setup_onready();alert('setup 順利執行');">setup</button></div>

<br /> 
　　遊戲新幹線超人氣線上遊戲《<a class="acglink" href="http://acg.gamer.com.tw/search.php?encode=utf8&kw=%E4%BB%99%E5%A2%83%E5%82%B3%E8%AA%AA" target="_blank">仙境傳說</a>》推出至今 8 年，人氣依舊歷久彌新，8 年來累積超過 700 萬名會員，每年舉辦的「RO 世界盃公開賽」，更如同大型網聚派對般熱鬧，都吸引超過上千玩家報名。而今年 10 月在印尼舉辦第 5 屆「2010 RWC 世界盃公開賽...<br /> 
<br /> 
<em>◆《嬌蠻貓娘大橫行》創作團隊 矢吹健太朗首度登台</em><br /> 
<br /> 
　　第11屆漫畫博覽會人潮爆滿，累計 5 天已有逼近 50 萬人次入館，創歷屆新高。開館前各入口處就大排長龍，一開館漫迷全往內衝，隨即館內已萬頭攢動，甚至還因館內一度因湧進太多人、二氧化碳濃度飆高，主辦單位立即管制進場人數。而這次漫博會青文...<br /> 
<br /> 
<em>◆《CRASH！》漫畫家藤原友佳簽名會甜美開場</em><br /> 
<br /> 
　　尖端出版在漫博會，邀請到《<a class="acglink" href="http://acg.gamer.com.tw/search.php?encode=utf8&kw=CRASH%EF%BC%81" target="_blank">CRASH！</a>》漫畫家藤原友佳老師來台辦簽名會，第一次到台灣來的藤原友佳老師，老師長相甜美可愛，就像作品中的女主角白星花一樣，一登台立即驚豔全場，主持人還安排一位熱情粉絲裝扮黑瀨桐上台獻上禮物與老師合影...<br /> 
<br /> 
<em>◆ 美女漫畫家咲坂芽亞登台 漫畫人物走出來</em><br /> 
<br /> 
　　天氣熱爆了，漫畫博覽會現場也擠爆了。漫畫迷為了到現場搶好康，把現場擠得水泄不通，而長長的排隊人潮就像貪吃蛇遊戲，隊伍越排越長，漫博會人數創下歷年來新高。而長鴻出版《<a class="acglink" href="http://acg.gamer.com.tw/search.php?encode=utf8&kw=%E8%A6%AA%E8%A6%AA%E8%99%8E%E7%89%99%E5%92%AC%E4%B8%80%E5%8F%A3" target="_blank">親親虎牙咬一口</a>》日本美女漫畫家咲坂芽亞也在現場引發大騷動...<br /> 
<br /> 
<em>◆《彩雲國物語》漫畫家由羅海里簽名會</em><br /> 
<br /> 
　　在日本與台灣都大受歡迎的《<a class="acglink" href="http://acg.gamer.com.tw/search.php?encode=utf8&kw=%E5%BD%A9%E9%9B%B2%E5%9C%8B%E7%89%A9%E8%AA%9E" target="_blank">彩雲國物語</a>》，作者由羅海里受角川出版邀請來台與漫畫迷相見歡。由羅海里是一位短髮氣質的女性作家，一出場就很有風度的向讀者問好。當問起老師在作品中最喜歡的男角色是誰？由羅老師表示，最喜歡的是黃奇人，但...<br /> 
<br /> 
<em>◆ 熱情杉井光超興奮 大玩合體遊戲</em><br /> 
<br /> 
　　東立出版的知名輕小說作家杉井光，靠著《<a class="acglink" href="http://acg.gamer.com.tw/search.php?encode=utf8&kw=%E7%81%AB%E7%9B%AE%E7%9A%84%E5%B7%AB%E5%A5%B3" target="_blank">火目的巫女</a>》一砲而紅，而他也首次來台非常興奮。一出場看到台下讀者，先來個飛吻，台下讀者大喊老師名字熱情回應。東立出版也安排 Cosplay 扮成女主角獻花給老師，此外這次簽名板做成 3D 圖畫本，一位...<br /> 
<br /> 
<em>◆ 傑尼斯系聲優浪川大輔帥氣登場</em><br /> 
<br /> 
　　木棉花人氣動畫《<a class="acglink" href="http://acg.gamer.com.tw/search.php?encode=utf8&kw=%E7%BE%A9%E5%91%86%E5%88%A9" target="_blank">義呆利</a>》中的帥氣聲優浪川大輔，有著如同偶像般的外型，而他一出場以宏亮的聲音大喊「PASTA」，現場女性粉絲為之瘋狂，浪川大輔帥氣迷人的五官，搭上簡單的日本披肩，後面還有義大利的圖案，拿著可愛方型抱枕，投出瞬間在場...<br /> 
<br /> 
　　以上為摘錄內容，完整內容請參閱影片。<br /><br />


<?php
/* End of file jQTouch.php */
/* Location: ./system/application/views/qunit/core/jQTouch.php */