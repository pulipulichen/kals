<?php
/**
 * Zoom_observable Unit Test
 *
 * @package             KALS
 * @category		Webpage Application QUnit
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/7/20 上午 12:17:29
 */

$title = 'Zoom_observable';
@load_scripts('toolkit/jquery.extends', $load_raw);
@load_scripts('toolkit/Observable', $load_raw);
@load_scripts('toolkit/Viewportmove_observable', $load_raw);
@load_scripts('toolkit/Viewportmove_observer', $load_raw);
?>
<script type="text/javascript">
QUNIT_TITLE = "<?= $title ?>";

test("Zoom_observable", function() {
    
    //$('body').css('margin', 0).css('padding', 0);
    var zoom_obs = new Viewportmove_observable(true);
    
    var observer = $.create_once('<div>?????????</div>')
        .css('background-color', 'white')
        .css('font-size', '30px')
        .click(function () {
            alert('偵測大小');
        })
        .prependTo($('body'));
        
    var button = $.create_once('<button>按鈕</button>')
        //.css('background-color', 'white')
        .css('font-size', '30px')
        .css('border', '1px solid black')
        .css('background-color', 'white')
        .css('padding', '5px')
        .css('margin', '10px')
        .css('-moz-border-radius-topleft', '10px')
        .css('-moz-border-radius-topright', '10px')
        .css('-moz-border-radius-bottomleft', '10px')
        .css('-moz-border-radius-bottomright', '10px')
        .css('border-top-left-radius', '10px 10px')
        .css('border-top-right-radius', '10px 10px')
        .css('border-bottom-left-radius', '10px 10px')
        .css('border-bottom-right-radius', '10px 10px')
        .click(function () {
            $(this).css('border-top-left-radius', '20px 20px')
                .css('border-top-right-radius', '20px 20px')
                .css('border-bottom-left-radius', '20px 20px')
                .css('border-bottom-right-radius', '20px 20px');
            alert('偵測大小');
            var _this = $(this);
             _this.html(_this.css('font-size')
               + ' : ' 
               + _this.css('border-bottom-right-radius'));
        })
        .prependTo($('body'));
    
    /**
     * 
     * @param {Zoom_observable} _zoom_observable
     */
    observer.onviewportmove = function (_zoom_observable) {
        var _this = $(this);
        var _scale = _zoom_observable.zoom_scale;
        var _view_width = _zoom_observable.get_viewport_width();
        _this.html('scale: ' + _scale + ' <br /> viewport with: ' + _view_width 
            + ' <br /> innerWidth: ' + window.innerWidth
            + ' <br /> outerWidth: ' + window.outerWidth 
            + ' <br /> screenWidth: ' + screen.width
            + ' <br /> sreenleft: '+window.screenLeft);
        
        //var _font_size = 40;
        //_font_size = _font_size * _scale;
        //_this.css('font-size', _font_size + 'px');
        _this.css_scale('font-size', '30px', _scale);
    };
    
    button.onviewportmove = function (_zoom_observable) {
        var _this = $(this);
        var _scale = _zoom_observable.zoom_scale;
        var _view_width = _zoom_observable.get_viewport_width();
        //_this.html(_scale + ' : ' + _view_width + ' : ' + window.outerWidth);
        
        //var _font_size = 40;
        //_font_size = _font_size * _scale;
        //_this.css('font-size', _font_size + 'px');
        
        /*
        _this.css_scale('font-size', '30px', _scale);
        _this.css_scale('border-width', '3px', _scale);
        _this.css_scale('padding', '5px', _scale);
        _this.css_scale($.css_border_radius, '10px', _scale);
        */
       
       _this.css_scale($.css_finger_friendly.button, _scale);
       //_this.html(_this.css('border-width'));
           /*
       $.test_msg([typeof(_this.css('border-bottom-right-radius'))
           , _this.css('border-bottom-right-radius').indexOf(' ')
           , _this.css('border-bottom-right-radius')
           
       ]);*/
    };
    
    zoom_obs.add_observer(observer);
    zoom_obs.add_observer(button);
    zoom_obs.set_changed();
    zoom_obs.notify_observers();
    
    /*
    var result = null;
    var expected = null;
    equals( result
        , expected
        , "Zoom_observable" );
    */
//    equals( result
//        , expected
//        , "Zoom_observable" );

});
</script>
<style type="text/css">
/**
 * 您可以在此寫入CSS內容
 */
</style>

<!--
 您可以在此寫入HTML內容
  -->

<?php
/* End of file Zoom_observable.php */
/* Location: ./system/application/views/qunit/core/Zoom_observable.php */