/**
 * test
 *
 * @package		KALS
 * @category		JavaScript Libraries
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/7/26 下午 07:10:20
 * @constructor test()
 * @requires jQuery
 * @requires Other_class
 */

// Deny defined again.

/**
 * @class test
 * @constructor test
 */
Test = function () {
    return this;
};

//test.prototype.attribute = "";

/**
 * Method Name
 *
 * @param param Description about param.
 * @return Description about return value.
 * @type string
 */
Test.prototype.t = function ($param)
{
    return $param;
};

//test.prototype.method = function (param)
//{
//    return param;
//}

/* End of file test */
/* Location: ./libraries/.../test.js */