/**
 * Viewportmove_listener
 *
 * Interface
 *
 * @package		KALS
 * @category		Webpage Application Libraries
 * @author		Pudding Chen <puddingchen.35@gmail.com>
 * @copyright		Copyright (c) 2010, Pudding Chen
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link		http://sites.google.com/site/puddingkals/
 * @version		1.0 2010/7/28 下午 03:55:07
 */

if (typeof INTERFACES == 'undefined') INTERFACES = {};
INTERFACES.Viewportmove_listener = {
    onviewportmove: function () {}
};

function Viewportmove_listener(_elem, _onviewportmove)
{
    this.element = _elem;
    this.onviewportmove_event = _onviewportmove;
    KALS_context.get_viewportmove_dispatcher().add_listener(this);
    return this;
}

/**
 * 執行onviewportmove事件
 * @param {Viewportmove_dispatcher} _vp_obs
 */
Viewportmove_listener.prototype.onviewportmove = function (_vp_obs)
{
    if ($.is_function(this.onviewportmove_event))
        this.onviewportmove_event(this.element, _vp_obs);
};

/* End of file Viewportmove_listener */
/* Location: ./system/application/views/web_apps/toolkit/Viewportmove_listener.js */