<?php
if (isset($js_file))
    include_once $js_file;
